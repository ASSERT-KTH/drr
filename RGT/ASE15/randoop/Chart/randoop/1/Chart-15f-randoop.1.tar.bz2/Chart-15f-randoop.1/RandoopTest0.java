
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(-1));
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder((-1.0d), 100.0d, (-1.0d), 10.0d, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPadding(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "hi!"+ "'", var0.equals("hi!"));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-1.0d), 0.0d, 1, (java.lang.Comparable)0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeHeight(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     var1.setParent((org.jfree.chart.plot.Plot)var3);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemShape(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.lang.String var1 = var0.getID();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var3 = null;
//     float[] var4 = new float[] { };
//     float[] var5 = var2.getColorComponents(var3, var4);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var7 = var6.getColorSpace();
    float[] var8 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var9 = var2.getColorComponents(var7, var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var5 = var4.getHeightRange();
    org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var4);
    org.jfree.data.Range var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var8 = var4.toRangeHeight(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
//     java.awt.Font var6 = var4.getNoDataMessageFont();
//     float var7 = var4.getForegroundAlpha();
//     var1.setParent((org.jfree.chart.plot.Plot)var4);
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("hi!", var1, (java.awt.Paint)var4, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var5 = var2.toRangeWidth(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var6 = var5.getColorSpace();
    float[] var7 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var8 = var2.getColorComponents(var6, var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "", "");

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.awt.Color var3 = java.awt.Color.getColor("hi!", 1);
    java.awt.Stroke var4 = null;
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var8 = var7.getColorSpace();
    java.lang.String var9 = var7.toString();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(1.0d, (java.awt.Paint)var3, var4, (java.awt.Paint)var7, var12, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var9.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var8 = var7.getColorSpace();
//     java.lang.String var9 = var7.toString();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.text.G2TextMeasurer var13 = new org.jfree.chart.text.G2TextMeasurer(var12);
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var4, (java.awt.Paint)var7, 100.0f, 1, (org.jfree.chart.text.TextMeasurer)var13);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, 100.0d);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = var2.toRangeHeight(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var6 = var5.getColorSpace();
    float[] var10 = new float[] { (-1.0f), 100.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var11 = var2.getComponents(var6, var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation(var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0f, 0.0f, var4, 1.0d, var6);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var2 = var1.getValue();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
//     double var4 = var3.getRight();
//     java.awt.geom.Rectangle2D var5 = null;
//     var3.trim(var5);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var2 = var1.getValue();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
    org.jfree.chart.util.RectangleAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var2 = var1.getValue();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
    double var4 = var3.getRight();
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var3.createOutsetRectangle(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint var4 = null;
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Stroke var8 = null;
//     java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
//     java.awt.Shape var10 = null;
//     java.awt.Shape[] var11 = new java.awt.Shape[] { var10};
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var19.setShadowXOffset(100.0d);
//     var19.setNoDataMessage("hi!");
//     java.awt.Stroke var25 = var19.getLabelOutlineStroke();
//     var17.setDomainZeroBaselineStroke(var25);
//     java.awt.Paint var27 = var17.getDomainGridlinePaint();
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     java.awt.Paint var33 = null;
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Paint var37 = null;
//     java.awt.Paint[] var38 = new java.awt.Paint[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Stroke var41 = null;
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     java.awt.Shape var43 = null;
//     java.awt.Shape[] var44 = new java.awt.Shape[] { var43};
//     org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var36, var38, var40, var42, var44);
//     java.awt.Paint var46 = null;
//     java.awt.Paint[] var47 = new java.awt.Paint[] { var46};
//     java.awt.Paint var48 = null;
//     java.awt.Paint[] var49 = new java.awt.Paint[] { var48};
//     java.awt.Paint var50 = null;
//     java.awt.Paint[] var51 = new java.awt.Paint[] { var50};
//     java.awt.Stroke var52 = null;
//     java.awt.Stroke[] var53 = new java.awt.Stroke[] { var52};
//     java.awt.Stroke var54 = null;
//     java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
//     java.awt.Shape var56 = null;
//     java.awt.Shape[] var57 = new java.awt.Shape[] { var56};
//     org.jfree.chart.plot.DefaultDrawingSupplier var58 = new org.jfree.chart.plot.DefaultDrawingSupplier(var47, var49, var51, var53, var55, var57);
//     org.jfree.chart.plot.DefaultDrawingSupplier var59 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var28, var32, var42, var57);
//     
//     // Checks the contract:  equals-hashcode on var12 and var45
//     assertTrue("Contract failed: equals-hashcode on var12 and var45", var12.equals(var45) ? var12.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var58
//     assertTrue("Contract failed: equals-hashcode on var12 and var58", var12.equals(var58) ? var12.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var12
//     assertTrue("Contract failed: equals-hashcode on var45 and var12", var45.equals(var12) ? var45.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var58
//     assertTrue("Contract failed: equals-hashcode on var45 and var58", var45.equals(var58) ? var45.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var12
//     assertTrue("Contract failed: equals-hashcode on var58 and var12", var58.equals(var12) ? var58.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var45
//     assertTrue("Contract failed: equals-hashcode on var58 and var45", var58.equals(var45) ? var58.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var2 = var1.getValue();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPaint(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    double var8 = var1.getMaximumLabelWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.14d);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.util.List var5 = null;
//     var4.setSubtitles(var5);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setHorizontalAlignment(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var5 = var4.getHeightRange();
//     org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var4);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var13 = var12.getHeightRange();
//     org.jfree.chart.util.Size2D var14 = var8.arrange(var9, var12);
//     org.jfree.chart.block.RectangleConstraint var16 = var12.toFixedWidth((-1.0d));
//     org.jfree.chart.util.Size2D var17 = var0.arrange(var7, var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var14
//     assertTrue("Contract failed: equals-hashcode on var6 and var14", var6.equals(var14) ? var6.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var6
//     assertTrue("Contract failed: equals-hashcode on var14 and var6", var14.equals(var6) ? var14.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var17
//     assertTrue("Contract failed: equals-hashcode on var14 and var17", var14.equals(var17) ? var14.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var14
//     assertTrue("Contract failed: equals-hashcode on var17 and var14", var17.equals(var14) ? var17.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.util.RectangleInsets var5 = var4.getPadding();
    double var7 = var5.trimWidth((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var1.drawOutline(var4, var5);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxis((-1), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=0,b=1]", var1, var2, var3);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var8 = var7.getColorSpace();
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var4, (java.awt.Paint)var7);
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var15 = var14.getHeightRange();
//     org.jfree.chart.util.Size2D var16 = var10.arrange(var11, var14);
//     boolean var17 = var9.equals((java.lang.Object)var14);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.util.Size2D var19 = var9.calculateDimensions(var18);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint var4 = null;
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Stroke var8 = null;
//     java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
//     java.awt.Shape var10 = null;
//     java.awt.Shape[] var11 = new java.awt.Shape[] { var10};
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9, var11);
//     java.awt.Paint var13 = null;
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     java.awt.Paint var15 = null;
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
//     java.awt.Paint var17 = null;
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Stroke var21 = null;
//     java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
//     java.awt.Shape var23 = null;
//     java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
//     org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var16, var18, var20, var22, var24);
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     var27.setPieIndex(100);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     java.awt.Stroke var32 = var31.getBaseSectionOutlineStroke();
//     var27.setBaseSectionOutlineStroke(var32);
//     java.awt.Stroke[] var34 = new java.awt.Stroke[] { var32};
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Paint var37 = null;
//     java.awt.Paint[] var38 = new java.awt.Paint[] { var37};
//     java.awt.Paint var39 = null;
//     java.awt.Paint[] var40 = new java.awt.Paint[] { var39};
//     java.awt.Stroke var41 = null;
//     java.awt.Stroke[] var42 = new java.awt.Stroke[] { var41};
//     java.awt.Stroke var43 = null;
//     java.awt.Stroke[] var44 = new java.awt.Stroke[] { var43};
//     java.awt.Shape var45 = null;
//     java.awt.Shape[] var46 = new java.awt.Shape[] { var45};
//     org.jfree.chart.plot.DefaultDrawingSupplier var47 = new org.jfree.chart.plot.DefaultDrawingSupplier(var36, var38, var40, var42, var44, var46);
//     java.awt.Shape[] var48 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var49 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var14, var34, var44, var48);
//     
//     // Checks the contract:  equals-hashcode on var12 and var25
//     assertTrue("Contract failed: equals-hashcode on var12 and var25", var12.equals(var25) ? var12.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var47
//     assertTrue("Contract failed: equals-hashcode on var12 and var47", var12.equals(var47) ? var12.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var12
//     assertTrue("Contract failed: equals-hashcode on var25 and var12", var25.equals(var12) ? var25.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var47
//     assertTrue("Contract failed: equals-hashcode on var25 and var47", var25.equals(var47) ? var25.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var12
//     assertTrue("Contract failed: equals-hashcode on var47 and var12", var47.equals(var12) ? var47.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var25
//     assertTrue("Contract failed: equals-hashcode on var47 and var25", var47.equals(var25) ? var47.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeType(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var25, (org.jfree.chart.block.Arrangement)var30);
//     org.jfree.chart.util.VerticalAlignment var32 = var31.getVerticalAlignment();
//     var14.setVerticalAlignment(var32);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 1.0f, 10.0f, var4, 0.025d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=0,g=0,b=1]", "", "hi!", "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "");

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    java.lang.String var4 = var2.toString();
    float[] var5 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var2.getColorComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var4.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    var4.removeLegend();
    java.lang.Object var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTextAntiAlias(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var1.drawOutline(var5, var6);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setForegroundAlpha((-1.0f));
//     var1.setCircular(true, true);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setForegroundAlpha((-1.0f));
//     var8.setCircular(true, true);
//     java.awt.Paint var14 = var8.getLabelShadowPaint();
//     var1.setShadowPaint(var14);
//     java.awt.Paint var17 = null;
//     var1.setSectionOutlinePaint((java.lang.Comparable)1.0d, var17);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     org.jfree.chart.plot.PlotState var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     var1.draw(var19, var20, var21, var22, var23);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
    float[] var8 = new float[] { 10.0f, 100.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var9 = var2.getComponents(var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setTickLabelsVisible(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRange(10.0d, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     java.awt.Paint var16 = var1.getSectionOutlinePaint((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     org.jfree.chart.plot.PlotState var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var1.draw(var17, var18, var19, var20, var21);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var5 = var4.getHeightRange();
//     org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var4);
//     java.lang.Object var7 = var6.clone();
//     java.lang.Object var8 = var6.clone();
//     
//     // Checks the contract:  equals-hashcode on var7 and var8
//     assertTrue("Contract failed: equals-hashcode on var7 and var8", var7.equals(var8) ? var7.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var7
//     assertTrue("Contract failed: equals-hashcode on var8 and var7", var8.equals(var7) ? var8.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.lang.String var1 = var0.getID();
//     var0.setPadding(1.0d, 0.0d, 0.0d, 10.0d);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var11 = var10.getValue();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getLabelOffset();
//     java.awt.Stroke var13 = var10.getOutlineStroke();
//     java.lang.Object var14 = var0.draw(var7, var8, (java.lang.Object)var10);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var5 = var4.getHeightRange();
//     org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var4);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.lang.Object var10 = var0.draw(var7, var8, (java.lang.Object)"");
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    var4.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.AxisLocation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation(var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.util.RectangleInsets var5 = var4.getPadding();
    org.jfree.chart.ChartRenderingInfo var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var9 = var4.createBufferedImage((-1), (-1), var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var5 = var4.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var15.setShadowXOffset(100.0d);
    var15.setNoDataMessage("hi!");
    java.awt.Stroke var21 = var15.getLabelOutlineStroke();
    var13.setDomainZeroBaselineStroke(var21);
    java.awt.Stroke var23 = var13.getRangeGridlineStroke();
    var8.setRangeGridlineStroke(var23);
    org.jfree.chart.plot.Marker var26 = null;
    org.jfree.chart.util.Layer var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var28 = var8.removeRangeMarker((-1), var26, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setForegroundAlpha((-1.0f));
    var1.setCircular(true, true);
    org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.event.ChartChangeEventType var8 = var7.getType();
    java.lang.String var9 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var9.equals("ChartChangeEventType.GENERAL"));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    var1.setBackgroundAlpha(0.0f);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.AttributedString var12 = var10.getAttributedLabel(0);
    java.lang.Object var13 = null;
    boolean var14 = var10.equals(var13);
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var10);
    java.lang.Object var16 = var10.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    java.awt.Paint var16 = var1.getSectionOutlinePaint((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
    java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var20 = var19.getColorSpace();
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var19);
    var1.setBaseSectionOutlinePaint((java.awt.Paint)var19);
    java.lang.String var23 = var19.toString();
    java.awt.Color var26 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var27 = var26.getColorSpace();
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
    java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
    java.awt.Font var32 = var30.getNoDataMessageFont();
    java.awt.Color var35 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var36 = var35.getColorSpace();
    java.awt.Color var37 = var35.darker();
    org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("", var32, (java.awt.Paint)var35);
    float[] var42 = new float[] { 10.0f, 0.0f, (-1.0f)};
    float[] var43 = var35.getColorComponents(var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var44 = var19.getComponents(var27, var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var23.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setTickLabelsVisible(true);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var6 = var5.getRangeType();
    var1.setRangeType(var6);
    java.awt.Shape var8 = var1.getRightArrow();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRange(4.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockFrame var2 = var1.getFrame();
//     var0.setFrame(var2);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("Category Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var14.removeChangeListener(var15);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    org.jfree.chart.axis.ValueAxis var22 = null;
    int var23 = var21.getDomainAxisIndex(var22);
    var21.setRangeCrosshairValue(10.0d);
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    java.awt.geom.Point2D var28 = null;
    var21.zoomDomainAxes(0.0d, var27, var28);
    org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
    var14.setSources(var30);
    org.jfree.chart.util.HorizontalAlignment var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setHorizontalAlignment(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("ChartChangeEventType.GENERAL", var1, (-1.0f), 100.0f, var4);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var19 = var18.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var20 = null;
    var18.setMarkerBand(var20);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var18, var22);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var23.getDomainMarkers(1, var25);
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var23.addRangeMarker((org.jfree.chart.plot.Marker)var28);
    org.jfree.chart.axis.AxisLocation var30 = var23.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation((-1), var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ChartRenderingInfo var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var10 = var4.createBufferedImage(0, (-1), 4.0d, 1.0d, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     int var6 = var4.getDomainAxisIndex(var5);
//     var4.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomDomainAxes(0.0d, var10, var11);
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var15 = var14.getValue();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getLabelOffset();
//     java.awt.Stroke var17 = var14.getOutlineStroke();
//     java.awt.Paint var18 = var14.getLabelPaint();
//     var14.setLabel("");
//     org.jfree.chart.util.Layer var21 = null;
//     boolean var22 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var14, var21);
// 
//   }

//  public void test100() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Pie Plot", var1);
//
//  }
//
  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    java.awt.Font var4 = var2.getNoDataMessageFont();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var8 = var7.getColorSpace();
    org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var4, (java.awt.Paint)var7);
    org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var15 = var14.getHeightRange();
    org.jfree.chart.util.Size2D var16 = var10.arrange(var11, var14);
    boolean var17 = var9.equals((java.lang.Object)var14);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setLineAlignment(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    double var4 = var1.getLabelLinkMargin();
    double var5 = var1.getShadowXOffset();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setPieIndex(100);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
    var7.setBaseSectionOutlineStroke(var12);
    org.jfree.chart.util.RectangleInsets var14 = var7.getLabelPadding();
    java.awt.Color var17 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var18 = var17.getColorSpace();
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var17);
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(var14, (java.awt.Paint)var17);
    var1.setInsets(var14);
    java.awt.geom.Rectangle2D var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var23 = var14.createInsetRectangle(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     var8.setDomainAxis(1, var13, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var8.setRenderer(var16, false);
//     var8.setAnchorValue((-1.0d));
//     org.jfree.chart.plot.Marker var22 = null;
//     org.jfree.chart.util.Layer var23 = null;
//     var8.addRangeMarker(100, var22, var23);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var4.removeLegend();
//     org.jfree.chart.event.TitleChangeEvent var6 = null;
//     var4.titleChanged(var6);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var10 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!");
    var5.addLibrary((org.jfree.chart.ui.Library)var10);
    org.jfree.chart.ui.Library[] var12 = var5.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = var0.getTimeline();
    org.jfree.chart.axis.DateTickMarkPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickMarkPosition(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    org.jfree.chart.plot.AbstractPieLabelDistributor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    var14.setPadding(0.025d, (-1.0d), 1.0d, 100.0d);
    org.jfree.chart.util.RectangleAnchor var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setLegendItemGraphicAnchor(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    var1.setBackgroundAlpha(0.0f);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.AttributedString var12 = var10.getAttributedLabel(0);
    java.lang.Object var13 = null;
    boolean var14 = var10.equals(var13);
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var10);
    org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
    boolean var18 = var1.equals((java.lang.Object)var17);
    org.jfree.chart.util.RectangleAnchor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setLabelAnchor(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
//     java.lang.String var15 = var8.getPlotType();
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     java.util.List var17 = var8.getCategoriesForAxis(var16);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     var8.handleClick(1, 10, var20);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.plot.CategoryMarker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 1);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    var8.clearRangeAxes();
    org.jfree.chart.axis.CategoryAnchor var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setDomainGridlinePosition(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setForegroundAlpha((-1.0f));
//     var2.setCircular(true, true);
//     java.awt.Paint var8 = var2.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     var16.setDomainZeroBaselineStroke(var24);
//     java.awt.Paint var26 = var16.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var29 = var28.getValue();
//     org.jfree.chart.util.RectangleInsets var30 = var28.getLabelOffset();
//     java.awt.Stroke var31 = var28.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(0.0d, var8, var11, var26, var31, 0.0f);
//     java.lang.Object var34 = var33.clone();
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     var37.setForegroundAlpha((-1.0f));
//     var37.setCircular(true, true);
//     java.awt.Paint var43 = var37.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot(var44);
//     java.awt.Stroke var46 = var45.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     java.awt.Stroke var54 = var53.getBaseSectionOutlineStroke();
//     var53.setShadowXOffset(100.0d);
//     var53.setNoDataMessage("hi!");
//     java.awt.Stroke var59 = var53.getLabelOutlineStroke();
//     var51.setDomainZeroBaselineStroke(var59);
//     java.awt.Paint var61 = var51.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var64 = var63.getValue();
//     org.jfree.chart.util.RectangleInsets var65 = var63.getLabelOffset();
//     java.awt.Stroke var66 = var63.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(0.0d, var43, var46, var61, var66, 0.0f);
//     var33.setOutlinePaint(var61);
//     
//     // Checks the contract:  equals-hashcode on var2 and var37
//     assertTrue("Contract failed: equals-hashcode on var2 and var37", var2.equals(var37) ? var2.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var45
//     assertTrue("Contract failed: equals-hashcode on var10 and var45", var10.equals(var45) ? var10.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var53
//     assertTrue("Contract failed: equals-hashcode on var18 and var53", var18.equals(var53) ? var18.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var2
//     assertTrue("Contract failed: equals-hashcode on var37 and var2", var37.equals(var2) ? var37.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var10
//     assertTrue("Contract failed: equals-hashcode on var45 and var10", var45.equals(var10) ? var45.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var18
//     assertTrue("Contract failed: equals-hashcode on var53 and var18", var53.equals(var18) ? var53.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var51
//     assertTrue("Contract failed: equals-hashcode on var16 and var51", var16.equals(var51) ? var16.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var16
//     assertTrue("Contract failed: equals-hashcode on var51 and var16", var51.equals(var16) ? var51.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var63
//     assertTrue("Contract failed: equals-hashcode on var28 and var63", var28.equals(var63) ? var28.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var68
//     assertTrue("Contract failed: equals-hashcode on var33 and var68", var33.equals(var68) ? var33.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var28
//     assertTrue("Contract failed: equals-hashcode on var63 and var28", var63.equals(var28) ? var63.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var33
//     assertTrue("Contract failed: equals-hashcode on var68 and var33", var68.equals(var33) ? var68.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(100, var6);
//     var4.mapDatasetToRangeAxis(1, (-16777216));
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleAnchor var14 = null;
//     java.awt.geom.Point2D var15 = org.jfree.chart.util.RectangleAnchor.coordinates(var13, var14);
//     org.jfree.chart.plot.PlotState var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     var4.draw(var11, var12, var15, var16, var17);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var2 = var1.getValue();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
    double var4 = var3.getRight();
    java.lang.String var5 = var3.toString();
    java.lang.String var6 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var5.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var6.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    var2.setPieIndex(100);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    var2.handleClick(100, 1, var7);
    org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
    java.awt.Font var13 = var11.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    var14.removeLegend();
    var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var14);
    org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(short)1, var14, 100, (-16777216));
    org.jfree.chart.event.ChartChangeListener var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.removeChangeListener(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     var0.setDataset(var1);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleAnchor var6 = null;
//     java.awt.geom.Point2D var7 = org.jfree.chart.util.RectangleAnchor.coordinates(var5, var6);
//     org.jfree.chart.plot.PlotState var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var0.draw(var3, var4, var7, var8, var9);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setForegroundAlpha((-1.0f));
    var1.setCircular(true, true);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    var8.setForegroundAlpha((-1.0f));
    var8.setCircular(true, true);
    java.awt.Paint var14 = var8.getLabelShadowPaint();
    var1.setShadowPaint(var14);
    java.awt.Paint var17 = null;
    var1.setSectionOutlinePaint((java.lang.Comparable)1.0d, var17);
    java.awt.Paint var20 = var1.getSectionPaint((java.lang.Comparable)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setPieIndex(100);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var2.setBaseSectionOutlineStroke(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var2.getLabelPadding();
//     var0.setTickLabelInsets(var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.AxisState var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var20.setShadowXOffset(100.0d);
//     var20.setNoDataMessage("hi!");
//     java.awt.Stroke var26 = var20.getLabelOutlineStroke();
//     var18.setDomainZeroBaselineStroke(var26);
//     java.awt.Paint var28 = var18.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var30 = var18.getRangeAxisEdge(1);
//     java.util.List var31 = var0.refreshTicks(var11, var12, var13, var30);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Category Plot", var1, 100.0f, 0.0f, var4);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge(1);
    org.jfree.chart.annotations.XYAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    java.awt.Font var8 = var6.getNoDataMessageFont();
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var12 = var11.getColorSpace();
    java.awt.Color var13 = var11.darker();
    org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("", var8, (java.awt.Paint)var11);
    float[] var18 = new float[] { 10.0f, 0.0f, (-1.0f)};
    float[] var19 = var11.getColorComponents(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var20 = var2.getComponents(var19);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.chart.util.VerticalAlignment var17 = var14.getVerticalAlignment();
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     var24.setShadowXOffset(100.0d);
//     var24.setNoDataMessage("hi!");
//     java.awt.Stroke var30 = var24.getLabelOutlineStroke();
//     var22.setDomainZeroBaselineStroke(var30);
//     java.awt.Paint var32 = var22.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var34 = var22.getRangeAxisEdge(1);
//     var14.setPosition(var34);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var8 = var7.getColorSpace();
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var4, (java.awt.Paint)var7);
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var15 = var14.getHeightRange();
//     org.jfree.chart.util.Size2D var16 = var10.arrange(var11, var14);
//     boolean var17 = var9.equals((java.lang.Object)var14);
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var21 = var20.getColorSpace();
//     java.awt.Color var22 = var20.darker();
//     boolean var23 = var9.equals((java.lang.Object)var22);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setForegroundAlpha((-1.0f));
//     var26.setCircular(true, true);
//     java.awt.Paint var32 = var26.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     java.awt.Stroke var43 = var42.getBaseSectionOutlineStroke();
//     var42.setShadowXOffset(100.0d);
//     var42.setNoDataMessage("hi!");
//     java.awt.Stroke var48 = var42.getLabelOutlineStroke();
//     var40.setDomainZeroBaselineStroke(var48);
//     java.awt.Paint var50 = var40.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var53 = var52.getValue();
//     org.jfree.chart.util.RectangleInsets var54 = var52.getLabelOffset();
//     java.awt.Stroke var55 = var52.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d, var32, var35, var50, var55, 0.0f);
//     java.lang.Object var58 = var57.clone();
//     boolean var59 = var9.equals((java.lang.Object)var57);
//     
//     // Checks the contract:  equals-hashcode on var2 and var34
//     assertTrue("Contract failed: equals-hashcode on var2 and var34", var2.equals(var34) ? var2.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var2
//     assertTrue("Contract failed: equals-hashcode on var34 and var2", var34.equals(var2) ? var34.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.AxisState var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     var10.setShadowXOffset(100.0d);
//     var10.setNoDataMessage("hi!");
//     java.awt.Stroke var16 = var10.getLabelOutlineStroke();
//     var8.setDomainZeroBaselineStroke(var16);
//     java.awt.Paint var18 = var8.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var20 = var8.getRangeAxisEdge(1);
//     java.util.List var21 = var0.refreshTicks(var1, var2, var3, var20);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockFrame var1 = var0.getFrame();
//     boolean var3 = var0.equals((java.lang.Object)0.025d);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     java.awt.Paint var11 = var10.getRangeTickBandPaint();
//     org.jfree.chart.axis.AxisSpace var12 = var10.getFixedDomainAxisSpace();
//     java.lang.Object var13 = var0.draw(var4, var5, (java.lang.Object)var10);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var16 = var15.getValue();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getLabelOffset();
//     java.awt.Stroke var18 = var15.getOutlineStroke();
//     boolean var19 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var15);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=0,g=0,b=1]", var1);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.Title var6 = var4.getSubtitle(0);
    var6.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    java.awt.Font var4 = var2.getNoDataMessageFont();
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var8 = var7.getColorSpace();
    java.awt.Color var9 = var7.darker();
    org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("", var4, (java.awt.Paint)var7);
    float[] var14 = new float[] { 10.0f, 0.0f, (-1.0f)};
    float[] var15 = var7.getColorComponents(var14);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
    java.awt.Font var20 = var18.getNoDataMessageFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var24 = var23.getColorSpace();
    java.awt.Color var25 = var23.darker();
    org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("", var20, (java.awt.Paint)var23);
    float[] var30 = new float[] { 10.0f, 0.0f, (-1.0f)};
    float[] var31 = var23.getColorComponents(var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var32 = var7.getRGBComponents(var30);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge(1);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     java.awt.Font var21 = var19.getNoDataMessageFont();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var25 = var24.getColorSpace();
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var21, (java.awt.Paint)var24);
//     var4.setRangeCrosshairPaint((java.awt.Paint)var24);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
//     var34.setShadowXOffset(100.0d);
//     var34.setNoDataMessage("hi!");
//     java.awt.Stroke var40 = var34.getLabelOutlineStroke();
//     var32.setDomainZeroBaselineStroke(var40);
//     java.awt.Paint var42 = var32.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var44 = var32.getRangeAxisEdge(1);
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     java.awt.Stroke var48 = var47.getBaseSectionOutlineStroke();
//     java.awt.Font var49 = var47.getNoDataMessageFont();
//     java.awt.Color var52 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var53 = var52.getColorSpace();
//     org.jfree.chart.text.TextBlock var54 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var49, (java.awt.Paint)var52);
//     var32.setRangeCrosshairPaint((java.awt.Paint)var52);
//     java.awt.color.ColorSpace var56 = var52.getColorSpace();
//     float[] var60 = new float[] { 100.0f, (-1.0f), 10.0f};
//     float[] var61 = var24.getColorComponents(var56, var60);
//     
//     // Checks the contract:  equals-hashcode on var4 and var32
//     assertTrue("Contract failed: equals-hashcode on var4 and var32", var4.equals(var32) ? var4.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var4
//     assertTrue("Contract failed: equals-hashcode on var32 and var4", var32.equals(var4) ? var32.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var47
//     assertTrue("Contract failed: equals-hashcode on var19 and var47", var19.equals(var47) ? var19.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var19
//     assertTrue("Contract failed: equals-hashcode on var47 and var19", var47.equals(var19) ? var47.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     java.text.AttributedString var5 = var3.getAttributedLabel(10);
//     var1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
//     org.jfree.data.general.PieDataset var7 = null;
//     java.text.AttributedString var9 = var3.generateAttributedSectionLabel(var7, (java.lang.Comparable)' ');
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge(1);
    java.awt.geom.Point2D var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setQuadrantOrigin(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setPieIndex(100);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var2.setBaseSectionOutlineStroke(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var2.getLabelPadding();
//     var0.setTickLabelInsets(var9);
//     org.jfree.chart.axis.DateTickUnit var11 = null;
//     java.util.Date var12 = var0.calculateHighestVisibleTickValue(var11);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var2 = var1.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var3 = null;
//     var1.setMarkerBand(var3);
//     java.lang.String var5 = var1.getLabelToolTip();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
//     var16.setShadowXOffset(100.0d);
//     var16.setNoDataMessage("hi!");
//     java.awt.Stroke var22 = var16.getLabelOutlineStroke();
//     var14.setDomainZeroBaselineStroke(var22);
//     java.awt.Paint var24 = var14.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var26 = var14.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.axis.AxisState var28 = var1.draw(var6, 100.0d, var8, var9, var26, var27);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartChangeEventType.GENERAL", var1);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    float[] var4 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = var2.getRGBComponents(var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    org.jfree.chart.util.RectangleInsets var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setAxisOffset(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setPieIndex(100);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var2.setBaseSectionOutlineStroke(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var2.getLabelPadding();
//     var0.setTickLabelInsets(var9);
//     var0.setUpperBound(3.0d);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.AxisState var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     boolean var21 = var20.isDomainCrosshairLockedOnData();
//     org.jfree.chart.util.RectangleEdge var23 = var20.getDomainAxisEdge((-16777216));
//     java.util.List var24 = var0.refreshTicks(var13, var14, var15, var23);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.plot.Marker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var11 = var8.removeRangeMarker(var9, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
//     boolean var8 = var7.isDomainCrosshairLockedOnData();
//     org.jfree.chart.util.RectangleEdge var10 = var7.getDomainAxisEdge((-16777216));
//     double var11 = var0.valueToJava2D(1.0E-5d, var2, var10);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     java.awt.Paint var16 = var1.getSectionOutlinePaint((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var20 = var19.getColorSpace();
//     org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var19);
//     var1.setBaseSectionOutlinePaint((java.awt.Paint)var19);
//     java.lang.String var23 = var19.toString();
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var19};
//     java.awt.Paint var25 = null;
//     java.awt.Paint[] var26 = new java.awt.Paint[] { var25};
//     java.awt.Paint var27 = null;
//     java.awt.Paint[] var28 = new java.awt.Paint[] { var27};
//     java.awt.Paint var29 = null;
//     java.awt.Paint[] var30 = new java.awt.Paint[] { var29};
//     java.awt.Stroke var31 = null;
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     java.awt.Stroke var33 = null;
//     java.awt.Stroke[] var34 = new java.awt.Stroke[] { var33};
//     java.awt.Shape var35 = null;
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var26, var28, var30, var32, var34, var36);
//     java.awt.Paint var38 = null;
//     java.awt.Paint[] var39 = new java.awt.Paint[] { var38};
//     java.awt.Paint var40 = null;
//     java.awt.Paint[] var41 = new java.awt.Paint[] { var40};
//     java.awt.Paint var42 = null;
//     java.awt.Paint[] var43 = new java.awt.Paint[] { var42};
//     java.awt.Stroke var44 = null;
//     java.awt.Stroke[] var45 = new java.awt.Stroke[] { var44};
//     java.awt.Stroke var46 = null;
//     java.awt.Stroke[] var47 = new java.awt.Stroke[] { var46};
//     java.awt.Shape var48 = null;
//     java.awt.Shape[] var49 = new java.awt.Shape[] { var48};
//     org.jfree.chart.plot.DefaultDrawingSupplier var50 = new org.jfree.chart.plot.DefaultDrawingSupplier(var39, var41, var43, var45, var47, var49);
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     var53.setForegroundAlpha((-1.0f));
//     var53.setCircular(true, true);
//     java.awt.Paint var59 = var53.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot var61 = new org.jfree.chart.plot.PiePlot(var60);
//     java.awt.Stroke var62 = var61.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var63, var64, var65, var66);
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.PiePlot var69 = new org.jfree.chart.plot.PiePlot(var68);
//     java.awt.Stroke var70 = var69.getBaseSectionOutlineStroke();
//     var69.setShadowXOffset(100.0d);
//     var69.setNoDataMessage("hi!");
//     java.awt.Stroke var75 = var69.getLabelOutlineStroke();
//     var67.setDomainZeroBaselineStroke(var75);
//     java.awt.Paint var77 = var67.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var80 = var79.getValue();
//     org.jfree.chart.util.RectangleInsets var81 = var79.getLabelOffset();
//     java.awt.Stroke var82 = var79.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var84 = new org.jfree.chart.plot.ValueMarker(0.0d, var59, var62, var77, var82, 0.0f);
//     java.awt.Stroke var85 = var84.getStroke();
//     java.awt.Stroke[] var86 = new java.awt.Stroke[] { var85};
//     java.awt.Shape[] var87 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var88 = new org.jfree.chart.plot.DefaultDrawingSupplier(var24, var26, var47, var86, var87);
//     
//     // Checks the contract:  equals-hashcode on var37 and var50
//     assertTrue("Contract failed: equals-hashcode on var37 and var50", var37.equals(var50) ? var37.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var37
//     assertTrue("Contract failed: equals-hashcode on var50 and var37", var50.equals(var37) ? var50.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var3 = var2.getFirstTextFragment();
//     java.awt.Font var4 = var3.getFont();
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var13 = var12.getColorSpace();
//     java.awt.Color var14 = var12.darker();
//     int var15 = var14.getRGB();
//     var9.setDomainCrosshairPaint((java.awt.Paint)var14);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.G2TextMeasurer var20 = new org.jfree.chart.text.G2TextMeasurer(var19);
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("ChartChangeEventType.GENERAL", var4, (java.awt.Paint)var14, 100.0f, 10, (org.jfree.chart.text.TextMeasurer)var20);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
//     var7.setShadowXOffset(100.0d);
//     var7.setNoDataMessage("hi!");
//     java.awt.Stroke var13 = var7.getLabelOutlineStroke();
//     var5.setDomainZeroBaselineStroke(var13);
//     java.awt.Stroke var15 = var5.getRangeGridlineStroke();
//     var0.setRadiusGridlineStroke(var15);
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var21 = var20.getColorSpace();
//     java.awt.Color var22 = var20.darker();
//     java.awt.Color var23 = java.awt.Color.getColor("", var22);
//     var0.setRadiusGridlinePaint((java.awt.Paint)var22);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.chart.axis.AxisSpace var32 = var31.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     java.awt.geom.Point2D var37 = org.jfree.chart.util.RectangleAnchor.coordinates(var35, var36);
//     var31.zoomDomainAxes(100.0d, var34, var37, false);
//     var0.zoomRangeAxes(0.14d, var26, var37, false);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    var8.clearRangeAxes();
    java.awt.Paint var13 = var8.getOutlinePaint();
    org.jfree.chart.util.SortOrder var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setRowRenderingOrder(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.data.general.DatasetChangeEvent var2 = null;
    var1.datasetChanged(var2);
    java.lang.String var4 = var1.getPlotType();
    var1.setExplodePercent((java.lang.Comparable)0.0f, 0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Pie Plot"+ "'", var4.equals("Pie Plot"));

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.GENERAL", var1, 10.0f, (-1.0f), 10.0d, 0.0f, (-1.0f));
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     boolean var11 = var10.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     java.awt.Stroke var15 = var14.getBaseSectionOutlineStroke();
//     java.awt.Font var16 = var14.getNoDataMessageFont();
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var20 = var19.getColorSpace();
//     java.awt.Color var21 = var19.darker();
//     org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("", var16, (java.awt.Paint)var19);
//     var10.setDomainCrosshairPaint((java.awt.Paint)var19);
//     org.jfree.chart.axis.AxisSpace var24 = var10.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleAnchor var29 = null;
//     java.awt.geom.Point2D var30 = org.jfree.chart.util.RectangleAnchor.coordinates(var28, var29);
//     var10.zoomDomainAxes(0.025d, (-1.0d), var27, var30);
//     var0.zoomDomainAxes(0.0d, 0.0d, var5, var30);
//     var0.zoom(1.0d);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getGPL();

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    org.jfree.chart.util.RectangleEdge var15 = var8.getRangeAxisEdge();
    org.jfree.chart.annotations.CategoryAnnotation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addAnnotation(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setTickLabelsVisible(true);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var6 = var5.getRangeType();
//     var1.setRangeType(var6);
//     var1.setTickMarkInsideLength(100.0f);
//     java.text.NumberFormat var10 = var1.getNumberFormatOverride();
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.data.category.CategoryDataset var15 = null;
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var19 = var18.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var20 = null;
//     var18.setMarkerBand(var20);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var18, var22);
//     org.jfree.chart.util.Layer var25 = null;
//     java.util.Collection var26 = var23.getDomainMarkers(1, var25);
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var23.addRangeMarker((org.jfree.chart.plot.Marker)var28);
//     org.jfree.chart.util.RectangleEdge var30 = var23.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.axis.AxisState var32 = var1.draw(var11, 1.0E-8d, var13, var14, var30, var31);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.Point var4 = var0.translateValueThetaRadiusToJava2D(1.0E-8d, 1.0E-5d, var3);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var4.removeLegend();
//     java.awt.RenderingHints var6 = null;
//     var4.setRenderingHints(var6);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var5 = var4.getHeightRange();
    org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var4);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    var4.clearRangeAxes();
    org.jfree.chart.LegendItemCollection var16 = var4.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var18 = var16.get((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0E-8d, 0.0d, 10, (java.lang.Comparable)(-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.14d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     var0.addCornerTextItem("Pie Plot");
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
//     var7.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var9 = var7.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     boolean var18 = var17.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     java.awt.Font var23 = var21.getNoDataMessageFont();
//     java.awt.Color var26 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var27 = var26.getColorSpace();
//     java.awt.Color var28 = var26.darker();
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("", var23, (java.awt.Paint)var26);
//     var17.setDomainCrosshairPaint((java.awt.Paint)var26);
//     org.jfree.chart.axis.AxisSpace var31 = var17.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     java.awt.geom.Point2D var37 = org.jfree.chart.util.RectangleAnchor.coordinates(var35, var36);
//     var17.zoomDomainAxes(0.025d, (-1.0d), var34, var37);
//     var7.zoomDomainAxes(0.0d, 0.0d, var12, var37);
//     var0.zoomDomainAxes(4.0d, var6, var37, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var21);
//     java.awt.Stroke var23 = var13.getRangeGridlineStroke();
//     var8.setRangeGridlineStroke(var23);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var29 = var28.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var30 = null;
//     var28.setMarkerBand(var30);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var32);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     var40.setShadowXOffset(100.0d);
//     var40.setNoDataMessage("hi!");
//     java.awt.Stroke var46 = var40.getLabelOutlineStroke();
//     var38.setDomainZeroBaselineStroke(var46);
//     java.awt.Stroke var48 = var38.getRangeGridlineStroke();
//     var33.setRangeGridlineStroke(var48);
//     var8.setRangeCrosshairStroke(var48);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var40
//     assertTrue("Contract failed: equals-hashcode on var15 and var40", var15.equals(var40) ? var15.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var15
//     assertTrue("Contract failed: equals-hashcode on var40 and var15", var40.equals(var15) ? var40.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleAnchor var9 = null;
//     java.awt.geom.Point2D var10 = org.jfree.chart.util.RectangleAnchor.coordinates(var8, var9);
//     var4.zoomDomainAxes(100.0d, var7, var10, false);
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var15 = var14.getValue();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var17.setShadowXOffset(100.0d);
//     var17.setNoDataMessage("hi!");
//     java.awt.Stroke var23 = var17.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
//     java.awt.Paint var32 = var17.getSectionOutlinePaint((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
//     java.awt.Color var35 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var36 = var35.getColorSpace();
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var35);
//     var17.setBaseSectionOutlinePaint((java.awt.Paint)var35);
//     var14.setLabelPaint((java.awt.Paint)var35);
//     boolean var40 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var14);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    var1.setBaseSectionOutlineStroke(var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getLabelPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)true, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.awt.Paint var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    java.awt.Shape var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemShape(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (short)0};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 10};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var21);
//     java.awt.Stroke var23 = var13.getRangeGridlineStroke();
//     var8.setRangeGridlineStroke(var23);
//     var8.mapDatasetToRangeAxis(0, 1);
//     org.jfree.chart.util.RectangleEdge var29 = var8.getDomainAxisEdge((-1));
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var33 = var32.getValue();
//     org.jfree.chart.util.RectangleInsets var34 = var32.getLabelOffset();
//     java.awt.Stroke var35 = var32.getOutlineStroke();
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var8.removeRangeMarker((-16777215), (org.jfree.chart.plot.Marker)var32, var36);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     java.awt.Font var3 = var2.getFont();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.text.TextAnchor var7 = null;
//     var2.draw(var4, 0.5f, (-1.0f), var7, 0.5f, 0.0f, 3.0d);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(100, var6);
//     var4.setRangeGridlinesVisible(false);
//     org.jfree.data.xy.XYDataset var10 = null;
//     int var11 = var4.indexOf(var10);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     var14.setForegroundAlpha((-1.0f));
//     var14.setCircular(true, true);
//     java.awt.Paint var20 = var14.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
//     var30.setShadowXOffset(100.0d);
//     var30.setNoDataMessage("hi!");
//     java.awt.Stroke var36 = var30.getLabelOutlineStroke();
//     var28.setDomainZeroBaselineStroke(var36);
//     java.awt.Paint var38 = var28.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var41 = var40.getValue();
//     org.jfree.chart.util.RectangleInsets var42 = var40.getLabelOffset();
//     java.awt.Stroke var43 = var40.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(0.0d, var20, var23, var38, var43, 0.0f);
//     java.awt.Stroke var46 = var45.getStroke();
//     boolean var47 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var45);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setForegroundAlpha((-1.0f));
    var1.setCircular(true, true);
    java.awt.Paint var7 = var1.getOutlinePaint();
    org.jfree.chart.util.RectangleInsets var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelPadding(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var15.setShadowXOffset(100.0d);
    var15.setNoDataMessage("hi!");
    java.awt.Stroke var21 = var15.getLabelOutlineStroke();
    var13.setDomainZeroBaselineStroke(var21);
    java.awt.Stroke var23 = var13.getRangeGridlineStroke();
    var8.setRangeGridlineStroke(var23);
    org.jfree.chart.axis.CategoryAnchor var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setDomainGridlinePosition(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    var4.setRangeCrosshairValue(10.0d);
    boolean var9 = var4.isDomainCrosshairVisible();
    int var10 = var4.getWeight();
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var14 = var13.getValue();
    org.jfree.chart.util.RectangleInsets var15 = var13.getLabelOffset();
    java.awt.Stroke var16 = var13.getOutlineStroke();
    java.awt.Paint var17 = var13.getLabelPaint();
    java.awt.Paint var18 = var13.getPaint();
    org.jfree.chart.util.Layer var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(10, (org.jfree.chart.plot.Marker)var13, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    boolean var7 = var4.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    double var4 = var1.getLabelLinkMargin();
    double var5 = var1.getShadowXOffset();
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    int var9 = var8.getRed();
    var1.setShadowPaint((java.awt.Paint)var8);
    org.jfree.chart.event.MarkerChangeEvent var11 = null;
    var1.markerChanged(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var6 = var5.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var7 = null;
//     var5.setMarkerBand(var7);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var5, var9);
//     org.jfree.chart.util.Layer var12 = null;
//     java.util.Collection var13 = var10.getDomainMarkers(1, var12);
//     org.jfree.chart.axis.ValueAxis var15 = var10.getRangeAxis(0);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var15, var16);
//     
//     // Checks the contract:  equals-hashcode on var10 and var17
//     assertTrue("Contract failed: equals-hashcode on var10 and var17", var10.equals(var17) ? var10.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var10
//     assertTrue("Contract failed: equals-hashcode on var17 and var10", var17.equals(var10) ? var17.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    java.lang.String var15 = var8.getPlotType();
    org.jfree.chart.axis.CategoryAxis var16 = null;
    java.util.List var17 = var8.getCategoriesForAxis(var16);
    var8.setRangeCrosshairVisible(false);
    org.jfree.chart.plot.CategoryMarker var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Category Plot"+ "'", var15.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setPieIndex(100);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
//     var1.setBaseSectionOutlineStroke(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var1.getLabelPadding();
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var12 = var11.getColorSpace();
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var8, (java.awt.Paint)var11);
//     int var15 = var11.getGreen();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     java.awt.Font var20 = var18.getNoDataMessageFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var24 = var23.getColorSpace();
//     java.awt.Color var25 = var23.darker();
//     org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("", var20, (java.awt.Paint)var23);
//     float[] var30 = new float[] { 10.0f, 0.0f, (-1.0f)};
//     float[] var31 = var23.getColorComponents(var30);
//     float[] var32 = var11.getRGBColorComponents(var30);
//     
//     // Checks the contract:  equals-hashcode on var5 and var18
//     assertTrue("Contract failed: equals-hashcode on var5 and var18", var5.equals(var18) ? var5.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var5
//     assertTrue("Contract failed: equals-hashcode on var18 and var5", var18.equals(var5) ? var18.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    int var15 = var4.getDatasetCount();
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
    var17.setPieIndex(100);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
    java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
    var17.setBaseSectionOutlineStroke(var22);
    org.jfree.chart.util.RectangleInsets var24 = var17.getLabelPadding();
    java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var28 = var27.getColorSpace();
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var24, (java.awt.Paint)var27);
    var4.setDomainZeroBaselinePaint((java.awt.Paint)var27);
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
    java.awt.Stroke var40 = var39.getBaseSectionOutlineStroke();
    var39.setShadowXOffset(100.0d);
    var39.setNoDataMessage("hi!");
    java.awt.Stroke var45 = var39.getLabelOutlineStroke();
    var37.setDomainZeroBaselineStroke(var45);
    java.awt.Paint var47 = var37.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var48 = null;
    org.jfree.chart.axis.CategoryAxis var49 = null;
    org.jfree.chart.axis.NumberAxis3D var51 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var52 = var51.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var53 = null;
    var51.setMarkerBand(var53);
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var48, var49, (org.jfree.chart.axis.ValueAxis)var51, var55);
    org.jfree.chart.util.Layer var58 = null;
    java.util.Collection var59 = var56.getDomainMarkers(1, var58);
    org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var56.addRangeMarker((org.jfree.chart.plot.Marker)var61);
    org.jfree.chart.axis.AxisLocation var63 = var56.getRangeAxisLocation();
    var37.setDomainAxisLocation(var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation((-1), var63);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var21);
//     java.awt.Stroke var23 = var13.getRangeGridlineStroke();
//     var8.setRangeGridlineStroke(var23);
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     java.util.List var26 = var8.getCategoriesForAxis(var25);
//     var8.clearRangeMarkers(10);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
//     var30.setShadowXOffset(100.0d);
//     var30.setNoDataMessage("hi!");
//     java.awt.Stroke var36 = var30.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var38, var39, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30, (org.jfree.chart.block.Arrangement)var37, (org.jfree.chart.block.Arrangement)var42);
//     org.jfree.chart.block.BlockContainer var44 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var37);
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
//     var46.setShadowXOffset(100.0d);
//     var46.setNoDataMessage("hi!");
//     java.awt.Stroke var52 = var46.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var53 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var54 = null;
//     org.jfree.chart.util.VerticalAlignment var55 = null;
//     org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement(var54, var55, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46, (org.jfree.chart.block.Arrangement)var53, (org.jfree.chart.block.Arrangement)var58);
//     org.jfree.chart.title.LegendTitle var60 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8, (org.jfree.chart.block.Arrangement)var37, (org.jfree.chart.block.Arrangement)var58);
//     
//     // Checks the contract:  equals-hashcode on var15 and var30
//     assertTrue("Contract failed: equals-hashcode on var15 and var30", var15.equals(var30) ? var15.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var46
//     assertTrue("Contract failed: equals-hashcode on var15 and var46", var15.equals(var46) ? var15.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var15
//     assertTrue("Contract failed: equals-hashcode on var30 and var15", var30.equals(var15) ? var30.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var46
//     assertTrue("Contract failed: equals-hashcode on var30 and var46", var30.equals(var46) ? var30.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var15
//     assertTrue("Contract failed: equals-hashcode on var46 and var15", var46.equals(var15) ? var46.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var30
//     assertTrue("Contract failed: equals-hashcode on var46 and var30", var46.equals(var30) ? var46.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var53
//     assertTrue("Contract failed: equals-hashcode on var37 and var53", var37.equals(var53) ? var37.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var58
//     assertTrue("Contract failed: equals-hashcode on var42 and var58", var42.equals(var58) ? var42.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var37
//     assertTrue("Contract failed: equals-hashcode on var53 and var37", var53.equals(var37) ? var53.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var42
//     assertTrue("Contract failed: equals-hashcode on var58 and var42", var58.equals(var42) ? var58.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    org.jfree.chart.event.RendererChangeEvent var15 = null;
    var8.rendererChanged(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", var3, "", "Pie Plot", "");
    var7.addOptionalLibrary("hi!");

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = var0.getTimeline();
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    double var5 = var4.getLength();
    var0.setRange(var4, true, true);
    org.jfree.chart.axis.DateTickUnit var9 = var0.getTickUnit();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var11 = var10.getTimeline();
    org.jfree.chart.axis.TickUnitSource var12 = var10.getStandardTickUnits();
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var14 = var13.getTimeline();
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
    double var18 = var17.getLength();
    var13.setRange(var17, true, true);
    org.jfree.chart.axis.DateTickUnit var22 = var13.getTickUnit();
    java.util.Date var23 = var10.calculateLowestVisibleTickValue(var22);
    org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var25 = var24.getTimeline();
    org.jfree.chart.axis.TickUnitSource var26 = var24.getStandardTickUnits();
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var28 = var27.getTimeline();
    org.jfree.data.Range var29 = null;
    org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 0.0d);
    double var32 = var31.getLength();
    var27.setRange(var31, true, true);
    org.jfree.chart.axis.DateTickUnit var36 = var27.getTickUnit();
    java.util.Date var37 = var24.calculateLowestVisibleTickValue(var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var23, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainCrosshairLockedOnData();
//     org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge((-16777216));
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setForegroundAlpha((-1.0f));
//     var10.setCircular(true, true);
//     java.awt.Paint var16 = var10.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     var26.setShadowXOffset(100.0d);
//     var26.setNoDataMessage("hi!");
//     java.awt.Stroke var32 = var26.getLabelOutlineStroke();
//     var24.setDomainZeroBaselineStroke(var32);
//     java.awt.Paint var34 = var24.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var37 = var36.getValue();
//     org.jfree.chart.util.RectangleInsets var38 = var36.getLabelOffset();
//     java.awt.Stroke var39 = var36.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(0.0d, var16, var19, var34, var39, 0.0f);
//     java.lang.Object var42 = var41.clone();
//     org.jfree.chart.util.Layer var43 = null;
//     boolean var44 = var4.removeRangeMarker((org.jfree.chart.plot.Marker)var41, var43);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Stroke var1 = var0.getSeparatorStroke();
    boolean var2 = var0.getSeparatorsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockFrame var1 = var0.getFrame();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var0.arrange(var2);
//     java.lang.Object var4 = var3.clone();
//     java.lang.Object var5 = var3.clone();
//     
//     // Checks the contract:  equals-hashcode on var4 and var5
//     assertTrue("Contract failed: equals-hashcode on var4 and var5", var4.equals(var5) ? var4.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var4
//     assertTrue("Contract failed: equals-hashcode on var5 and var4", var5.equals(var4) ? var5.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.chart.util.VerticalAlignment var17 = var14.getVerticalAlignment();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     var19.setForegroundAlpha((-1.0f));
//     var19.setCircular(true, true);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setForegroundAlpha((-1.0f));
//     var26.setCircular(true, true);
//     java.awt.Paint var32 = var26.getLabelShadowPaint();
//     var19.setShadowPaint(var32);
//     boolean var34 = var17.equals((java.lang.Object)var32);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     java.awt.Stroke var37 = var36.getBaseSectionOutlineStroke();
//     var36.setShadowXOffset(100.0d);
//     var36.setNoDataMessage("hi!");
//     java.awt.Stroke var42 = var36.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var43 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement(var44, var45, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36, (org.jfree.chart.block.Arrangement)var43, (org.jfree.chart.block.Arrangement)var48);
//     org.jfree.chart.block.BlockContainer var50 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var43);
//     boolean var51 = var17.equals((java.lang.Object)var50);
//     
//     // Checks the contract:  equals-hashcode on var1 and var36
//     assertTrue("Contract failed: equals-hashcode on var1 and var36", var1.equals(var36) ? var1.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var1
//     assertTrue("Contract failed: equals-hashcode on var36 and var1", var36.equals(var1) ? var36.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var43
//     assertTrue("Contract failed: equals-hashcode on var8 and var43", var8.equals(var43) ? var8.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var48
//     assertTrue("Contract failed: equals-hashcode on var13 and var48", var13.equals(var48) ? var13.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var8
//     assertTrue("Contract failed: equals-hashcode on var43 and var8", var43.equals(var8) ? var43.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var13
//     assertTrue("Contract failed: equals-hashcode on var48 and var13", var48.equals(var13) ? var48.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     var14.setPadding(0.025d, (-1.0d), 1.0d, 100.0d);
//     var14.setID("Pie Plot");
//     org.jfree.chart.util.RectangleInsets var22 = var14.getItemLabelPadding();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     var24.setShadowXOffset(100.0d);
//     var24.setNoDataMessage("hi!");
//     java.awt.Stroke var30 = var24.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement(var32, var33, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var36);
//     org.jfree.chart.event.TitleChangeListener var38 = null;
//     var37.removeChangeListener(var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     int var46 = var44.getDomainAxisIndex(var45);
//     var44.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     java.awt.geom.Point2D var51 = null;
//     var44.zoomDomainAxes(0.0d, var50, var51);
//     org.jfree.chart.LegendItemSource[] var53 = new org.jfree.chart.LegendItemSource[] { var44};
//     var37.setSources(var53);
//     org.jfree.chart.LegendItemSource[] var55 = var37.getSources();
//     var14.setSources(var55);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var36
//     assertTrue("Contract failed: equals-hashcode on var13 and var36", var13.equals(var36) ? var13.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var13
//     assertTrue("Contract failed: equals-hashcode on var36 and var13", var36.equals(var13) ? var36.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     var0.setLimit(0.0d);
//     org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var5 = var4.getValue();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getLabelOffset();
//     java.awt.Stroke var7 = var4.getOutlineStroke();
//     java.awt.Paint var8 = var4.getLabelPaint();
//     var0.setAggregatedItemsPaint(var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setForegroundAlpha((-1.0f));
//     var11.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var11);
//     org.jfree.chart.event.ChartChangeEventType var18 = null;
//     var17.setType(var18);
//     java.lang.String var20 = var17.toString();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     java.awt.Font var24 = var22.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getPadding();
//     var17.setChart(var25);
//     var25.setBorderVisible(true);
//     java.awt.Stroke var30 = var25.getBorderStroke();
//     var25.setAntiAlias(true);
//     var0.setPieChart(var25);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     var35.setPieIndex(100);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
//     java.awt.Stroke var40 = var39.getBaseSectionOutlineStroke();
//     var35.setBaseSectionOutlineStroke(var40);
//     org.jfree.chart.util.RectangleInsets var42 = var35.getLabelPadding();
//     java.awt.Color var45 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var46 = var45.getColorSpace();
//     org.jfree.chart.block.BlockBorder var47 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(var42, (java.awt.Paint)var45);
//     var25.setPadding(var42);
//     
//     // Checks the contract:  equals-hashcode on var22 and var39
//     assertTrue("Contract failed: equals-hashcode on var22 and var39", var22.equals(var39) ? var22.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var22
//     assertTrue("Contract failed: equals-hashcode on var39 and var22", var39.equals(var22) ? var39.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     var24.setShadowXOffset(100.0d);
//     var24.setNoDataMessage("hi!");
//     java.awt.Stroke var30 = var24.getLabelOutlineStroke();
//     var22.setDomainZeroBaselineStroke(var30);
//     java.awt.Paint var32 = var22.getDomainGridlinePaint();
//     java.awt.Paint var33 = var22.getDomainZeroBaselinePaint();
//     var22.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D("");
//     var37.setTickLabelsVisible(true);
//     var37.setLowerBound(1.0d);
//     org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var37};
//     var22.setDomainAxes(var42);
//     var4.setDomainAxes(var42);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var4
//     assertTrue("Contract failed: equals-hashcode on var22 and var4", var22.equals(var4) ? var22.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getLegendItemGraphicPadding();
//     java.awt.Font var17 = var14.getItemFont();
//     java.awt.Paint var18 = var14.getItemPaint();
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     var25.setShadowXOffset(100.0d);
//     var25.setNoDataMessage("hi!");
//     java.awt.Stroke var31 = var25.getLabelOutlineStroke();
//     var23.setDomainZeroBaselineStroke(var31);
//     java.awt.Paint var33 = var23.getDomainGridlinePaint();
//     java.awt.Paint var34 = var23.getDomainZeroBaselinePaint();
//     java.awt.Paint var35 = var23.getRangeTickBandPaint();
//     org.jfree.chart.util.RectangleInsets var36 = var23.getInsets();
//     var14.setLegendItemGraphicPadding(var36);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.general.DatasetChangeEvent var1 = null;
    var0.datasetChanged(var1);
    org.jfree.chart.util.RectangleInsets var3 = var0.getInsets();
    double var5 = var3.calculateLeftOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 8.0d);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setForegroundAlpha((-1.0f));
//     var17.setCircular(true, true);
//     java.awt.Paint var23 = var17.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     var33.setShadowXOffset(100.0d);
//     var33.setNoDataMessage("hi!");
//     java.awt.Stroke var39 = var33.getLabelOutlineStroke();
//     var31.setDomainZeroBaselineStroke(var39);
//     java.awt.Paint var41 = var31.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var44 = var43.getValue();
//     org.jfree.chart.util.RectangleInsets var45 = var43.getLabelOffset();
//     java.awt.Stroke var46 = var43.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(0.0d, var23, var26, var41, var46, 0.0f);
//     boolean var49 = var4.equals((java.lang.Object)var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var31
//     assertTrue("Contract failed: equals-hashcode on var4 and var31", var4.equals(var31) ? var4.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var4
//     assertTrue("Contract failed: equals-hashcode on var31 and var4", var31.equals(var4) ? var31.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var33
//     assertTrue("Contract failed: equals-hashcode on var6 and var33", var6.equals(var33) ? var6.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var6
//     assertTrue("Contract failed: equals-hashcode on var33 and var6", var33.equals(var6) ? var33.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
//     var7.setTickLabelsVisible(true);
//     int var10 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var7);
//     int var11 = var4.getDomainAxisCount();
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     var16.setDomainZeroBaselineStroke(var24);
//     java.awt.Paint var26 = var16.getDomainGridlinePaint();
//     java.awt.Paint var27 = var16.getDomainZeroBaselinePaint();
//     org.jfree.chart.plot.SeriesRenderingOrder var28 = var16.getSeriesRenderingOrder();
//     var4.setSeriesRenderingOrder(var28);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     var4.setDomainGridlinesVisible(false);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var20.setShadowXOffset(100.0d);
//     var20.setNoDataMessage("hi!");
//     java.awt.Stroke var26 = var20.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement(var28, var29, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20, (org.jfree.chart.block.Arrangement)var27, (org.jfree.chart.block.Arrangement)var32);
//     org.jfree.chart.event.TitleChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     int var42 = var40.getDomainAxisIndex(var41);
//     var40.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     java.awt.geom.Point2D var47 = null;
//     var40.zoomDomainAxes(0.0d, var46, var47);
//     org.jfree.chart.LegendItemSource[] var49 = new org.jfree.chart.LegendItemSource[] { var40};
//     var33.setSources(var49);
//     org.jfree.chart.LegendItemSource[] var51 = var33.getSources();
//     org.jfree.chart.LegendItemSource[] var52 = var33.getSources();
//     java.lang.Object var53 = var33.clone();
//     java.awt.geom.Rectangle2D var54 = var33.getBounds();
//     org.jfree.chart.plot.PolarPlot var55 = new org.jfree.chart.plot.PolarPlot();
//     var55.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var57 = var55.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.data.xy.XYDataset var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var61, var62, var63, var64);
//     boolean var66 = var65.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.PiePlot var69 = new org.jfree.chart.plot.PiePlot(var68);
//     java.awt.Stroke var70 = var69.getBaseSectionOutlineStroke();
//     java.awt.Font var71 = var69.getNoDataMessageFont();
//     java.awt.Color var74 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var75 = var74.getColorSpace();
//     java.awt.Color var76 = var74.darker();
//     org.jfree.chart.text.TextFragment var77 = new org.jfree.chart.text.TextFragment("", var71, (java.awt.Paint)var74);
//     var65.setDomainCrosshairPaint((java.awt.Paint)var74);
//     org.jfree.chart.axis.AxisSpace var79 = var65.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var82 = null;
//     java.awt.geom.Rectangle2D var83 = null;
//     org.jfree.chart.util.RectangleAnchor var84 = null;
//     java.awt.geom.Point2D var85 = org.jfree.chart.util.RectangleAnchor.coordinates(var83, var84);
//     var65.zoomDomainAxes(0.025d, (-1.0d), var82, var85);
//     var55.zoomDomainAxes(0.0d, 0.0d, var60, var85);
//     org.jfree.chart.plot.PlotState var88 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var89 = null;
//     var4.draw(var18, var54, var85, var88, var89);
//     
//     // Checks the contract:  equals-hashcode on var6 and var20
//     assertTrue("Contract failed: equals-hashcode on var6 and var20", var6.equals(var20) ? var6.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var6
//     assertTrue("Contract failed: equals-hashcode on var20 and var6", var20.equals(var6) ? var20.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainCrosshairLockedOnData();
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     var4.setParent((org.jfree.chart.plot.Plot)var6);
//     
//     // Checks the contract:  equals-hashcode on var4 and var6
//     assertTrue("Contract failed: equals-hashcode on var4 and var6", var4.equals(var6) ? var4.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var4
//     assertTrue("Contract failed: equals-hashcode on var6 and var4", var6.equals(var4) ? var6.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var8.datasetChanged(var12);
    var8.configureDomainAxes();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
    java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
    var21.setShadowXOffset(100.0d);
    var21.setNoDataMessage("hi!");
    java.awt.Stroke var27 = var21.getLabelOutlineStroke();
    var19.setDomainZeroBaselineStroke(var27);
    java.awt.Paint var29 = var19.getDomainGridlinePaint();
    java.awt.Paint var30 = var19.getDomainZeroBaselinePaint();
    java.awt.Paint var31 = var19.getRangeTickBandPaint();
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var36 = var35.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var37 = null;
    var35.setMarkerBand(var37);
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var35, var39);
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis var43 = null;
    org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var46 = var45.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var47 = null;
    var45.setMarkerBand(var47);
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var42, var43, (org.jfree.chart.axis.ValueAxis)var45, var49);
    org.jfree.chart.util.Layer var52 = null;
    java.util.Collection var53 = var50.getDomainMarkers(1, var52);
    org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var50.addRangeMarker((org.jfree.chart.plot.Marker)var55);
    org.jfree.chart.axis.AxisLocation var57 = var50.getRangeAxisLocation();
    var40.setRangeAxisLocation(0, var57);
    var19.setDomainAxisLocation(var57);
    var8.setDomainAxisLocation(var57);
    org.jfree.chart.annotations.CategoryAnnotation var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addAnnotation(var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

//  public void test209() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Polar Plot", var1);
//
//  }
//
  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var21.getDomainAxisIndex(var22);
//     var21.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var21.zoomDomainAxes(0.0d, var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
//     var14.setSources(var30);
//     org.jfree.chart.LegendItemSource[] var32 = var14.getSources();
//     org.jfree.chart.LegendItemSource[] var33 = var14.getSources();
//     java.lang.Object var34 = var14.clone();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     java.awt.Stroke var37 = var36.getBaseSectionOutlineStroke();
//     java.awt.Font var38 = var36.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var36);
//     org.jfree.chart.util.RectangleInsets var40 = var39.getPadding();
//     java.awt.Paint var41 = var39.getBorderPaint();
//     var14.addChangeListener((org.jfree.chart.event.TitleChangeListener)var39);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var43, var44, var45, var46);
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot(var48);
//     java.awt.Stroke var50 = var49.getBaseSectionOutlineStroke();
//     var49.setShadowXOffset(100.0d);
//     var49.setNoDataMessage("hi!");
//     java.awt.Stroke var55 = var49.getLabelOutlineStroke();
//     var47.setDomainZeroBaselineStroke(var55);
//     java.awt.Paint var57 = var47.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var59 = var47.getRangeAxisEdge(1);
//     boolean var60 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var59);
//     var14.setLegendItemGraphicEdge(var59);
//     
//     // Checks the contract:  equals-hashcode on var1 and var49
//     assertTrue("Contract failed: equals-hashcode on var1 and var49", var1.equals(var49) ? var1.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var1
//     assertTrue("Contract failed: equals-hashcode on var49 and var1", var49.equals(var1) ? var49.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=0,g=0,b=1]", "java.awt.Color[r=0,g=0,b=1]", var3);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 1);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.util.RectangleEdge var15 = var8.getRangeAxisEdge();
//     org.jfree.chart.plot.DrawingSupplier var16 = null;
//     var8.setDrawingSupplier(var16);
//     org.jfree.chart.event.PlotChangeEvent var18 = null;
//     var8.notifyListeners(var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     var26.setShadowXOffset(100.0d);
//     var26.setNoDataMessage("hi!");
//     java.awt.Stroke var32 = var26.getLabelOutlineStroke();
//     var24.setDomainZeroBaselineStroke(var32);
//     java.awt.Paint var34 = var24.getDomainGridlinePaint();
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var39 = var38.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var40 = null;
//     var38.setMarkerBand(var40);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var35, var36, (org.jfree.chart.axis.ValueAxis)var38, var42);
//     org.jfree.chart.util.Layer var45 = null;
//     java.util.Collection var46 = var43.getDomainMarkers(1, var45);
//     org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var43.addRangeMarker((org.jfree.chart.plot.Marker)var48);
//     org.jfree.chart.axis.AxisLocation var50 = var43.getRangeAxisLocation();
//     var24.setDomainAxisLocation(var50);
//     var8.setRangeAxisLocation(var50);
//     
//     // Checks the contract:  equals-hashcode on var13 and var48
//     assertTrue("Contract failed: equals-hashcode on var13 and var48", var13.equals(var48) ? var13.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var13
//     assertTrue("Contract failed: equals-hashcode on var48 and var13", var48.equals(var13) ? var48.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var4.removeLegend();
//     java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
//     var4.setBorderPaint((java.awt.Paint)var8);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     var12.setShadowXOffset(100.0d);
//     var12.setNoDataMessage("hi!");
//     java.awt.Stroke var18 = var12.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var20 = null;
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var24);
//     org.jfree.chart.event.TitleChangeListener var26 = null;
//     var25.removeChangeListener(var26);
//     org.jfree.chart.util.VerticalAlignment var28 = var25.getVerticalAlignment();
//     java.awt.Font var29 = var25.getItemFont();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var29);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     java.awt.Font var35 = var33.getNoDataMessageFont();
//     java.awt.Color var38 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var39 = var38.getColorSpace();
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var35, (java.awt.Paint)var38);
//     org.jfree.chart.block.BlockContainer var41 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var46 = var45.getHeightRange();
//     org.jfree.chart.util.Size2D var47 = var41.arrange(var42, var45);
//     boolean var48 = var40.equals((java.lang.Object)var45);
//     java.awt.Color var51 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var52 = var51.getColorSpace();
//     java.awt.Color var53 = var51.darker();
//     boolean var54 = var40.equals((java.lang.Object)var53);
//     var30.setBackgroundPaint((java.awt.Paint)var53);
//     java.awt.Font var56 = var30.getFont();
//     var4.setTitle(var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var10 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!");
    var5.addLibrary((org.jfree.chart.ui.Library)var10);
    java.lang.String var12 = var10.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var16 = var15.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var17 = null;
//     var15.setMarkerBand(var17);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var19);
//     org.jfree.chart.util.Layer var22 = null;
//     java.util.Collection var23 = var20.getDomainMarkers(1, var22);
//     org.jfree.data.general.DatasetChangeEvent var24 = null;
//     var20.datasetChanged(var24);
//     var20.configureDomainAxes();
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     var33.setShadowXOffset(100.0d);
//     var33.setNoDataMessage("hi!");
//     java.awt.Stroke var39 = var33.getLabelOutlineStroke();
//     var31.setDomainZeroBaselineStroke(var39);
//     java.awt.Paint var41 = var31.getDomainGridlinePaint();
//     java.awt.Paint var42 = var31.getDomainZeroBaselinePaint();
//     java.awt.Paint var43 = var31.getRangeTickBandPaint();
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.NumberAxis3D var47 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var48 = var47.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var49 = null;
//     var47.setMarkerBand(var49);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot(var44, var45, (org.jfree.chart.axis.ValueAxis)var47, var51);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var58 = var57.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var59 = null;
//     var57.setMarkerBand(var59);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var54, var55, (org.jfree.chart.axis.ValueAxis)var57, var61);
//     org.jfree.chart.util.Layer var64 = null;
//     java.util.Collection var65 = var62.getDomainMarkers(1, var64);
//     org.jfree.chart.plot.ValueMarker var67 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var62.addRangeMarker((org.jfree.chart.plot.Marker)var67);
//     org.jfree.chart.axis.AxisLocation var69 = var62.getRangeAxisLocation();
//     var52.setRangeAxisLocation(0, var69);
//     var31.setDomainAxisLocation(var69);
//     var20.setDomainAxisLocation(var69);
//     var8.setRangeAxisLocation(var69);
//     
//     // Checks the contract:  equals-hashcode on var8 and var52
//     assertTrue("Contract failed: equals-hashcode on var8 and var52", var8.equals(var52) ? var8.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var8
//     assertTrue("Contract failed: equals-hashcode on var52 and var8", var52.equals(var8) ? var52.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
//     var7.setShadowXOffset(100.0d);
//     var7.setNoDataMessage("hi!");
//     java.awt.Stroke var13 = var7.getLabelOutlineStroke();
//     var5.setDomainZeroBaselineStroke(var13);
//     java.awt.Stroke var15 = var5.getRangeGridlineStroke();
//     var0.setRadiusGridlineStroke(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     boolean var22 = var21.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     java.awt.Font var27 = var25.getNoDataMessageFont();
//     java.awt.Color var30 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var31 = var30.getColorSpace();
//     java.awt.Color var32 = var30.darker();
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var27, (java.awt.Paint)var30);
//     var21.setDomainCrosshairPaint((java.awt.Paint)var30);
//     java.awt.Stroke var35 = var21.getDomainZeroBaselineStroke();
//     var21.setWeight((-1));
//     java.awt.Color var40 = java.awt.Color.getColor("hi!", 1);
//     var21.setDomainCrosshairPaint((java.awt.Paint)var40);
//     var0.setRadiusGridlinePaint((java.awt.Paint)var40);
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot(var44);
//     var45.setPieIndex(100);
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot(var48);
//     java.awt.Stroke var50 = var49.getBaseSectionOutlineStroke();
//     var45.setBaseSectionOutlineStroke(var50);
//     org.jfree.chart.util.RectangleInsets var52 = var45.getLabelPadding();
//     var43.setTickLabelInsets(var52);
//     org.jfree.data.Range var54 = null;
//     org.jfree.data.Range var56 = org.jfree.data.Range.expandToInclude(var54, 0.0d);
//     double var57 = var56.getLength();
//     org.jfree.data.Range var58 = null;
//     org.jfree.data.Range var60 = org.jfree.data.Range.expandToInclude(var58, 0.0d);
//     org.jfree.data.Range var61 = org.jfree.data.Range.combine(var56, var60);
//     var43.setRange(var61, true, true);
//     org.jfree.data.Range var65 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var43);
//     
//     // Checks the contract:  equals-hashcode on var25 and var49
//     assertTrue("Contract failed: equals-hashcode on var25 and var49", var25.equals(var49) ? var25.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var25
//     assertTrue("Contract failed: equals-hashcode on var49 and var25", var49.equals(var25) ? var49.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(short)100, 0.025d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainCrosshairLockedOnData();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     var6.setLabelAngle(0.0d);
//     var6.centerRange(0.025d);
//     int var11 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     org.jfree.chart.axis.AxisSpace var19 = var18.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.util.RectangleAnchor var23 = null;
//     java.awt.geom.Point2D var24 = org.jfree.chart.util.RectangleAnchor.coordinates(var22, var23);
//     var18.zoomDomainAxes(100.0d, var21, var24, false);
//     var4.zoomRangeAxes(0.025d, var13, var24, false);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     var8.clearRangeAxes();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15, (org.jfree.chart.block.Arrangement)var22, (org.jfree.chart.block.Arrangement)var27);
//     org.jfree.chart.event.TitleChangeListener var29 = null;
//     var28.removeChangeListener(var29);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     int var37 = var35.getDomainAxisIndex(var36);
//     var35.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     java.awt.geom.Point2D var42 = null;
//     var35.zoomDomainAxes(0.0d, var41, var42);
//     org.jfree.chart.LegendItemSource[] var44 = new org.jfree.chart.LegendItemSource[] { var35};
//     var28.setSources(var44);
//     org.jfree.chart.LegendItemSource[] var46 = var28.getSources();
//     org.jfree.chart.LegendItemSource[] var47 = var28.getSources();
//     java.lang.Object var48 = var28.clone();
//     java.awt.geom.Rectangle2D var49 = var28.getBounds();
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot var56 = new org.jfree.chart.plot.PiePlot(var55);
//     java.awt.Stroke var57 = var56.getBaseSectionOutlineStroke();
//     var56.setShadowXOffset(100.0d);
//     var56.setNoDataMessage("hi!");
//     java.awt.Stroke var62 = var56.getLabelOutlineStroke();
//     var54.setDomainZeroBaselineStroke(var62);
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     org.jfree.data.xy.XYDataset var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var66, var67, var68, var69);
//     boolean var71 = var70.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var73 = null;
//     org.jfree.chart.plot.PiePlot var74 = new org.jfree.chart.plot.PiePlot(var73);
//     java.awt.Stroke var75 = var74.getBaseSectionOutlineStroke();
//     java.awt.Font var76 = var74.getNoDataMessageFont();
//     java.awt.Color var79 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var80 = var79.getColorSpace();
//     java.awt.Color var81 = var79.darker();
//     org.jfree.chart.text.TextFragment var82 = new org.jfree.chart.text.TextFragment("", var76, (java.awt.Paint)var79);
//     var70.setDomainCrosshairPaint((java.awt.Paint)var79);
//     org.jfree.chart.axis.AxisSpace var84 = var70.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var87 = null;
//     java.awt.geom.Rectangle2D var88 = null;
//     org.jfree.chart.util.RectangleAnchor var89 = null;
//     java.awt.geom.Point2D var90 = org.jfree.chart.util.RectangleAnchor.coordinates(var88, var89);
//     var70.zoomDomainAxes(0.025d, (-1.0d), var87, var90);
//     var54.zoomDomainAxes(4.0d, var65, var90);
//     org.jfree.chart.plot.PlotState var93 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var94 = null;
//     var8.draw(var13, var49, var90, var93, var94);
//     
//     // Checks the contract:  equals-hashcode on var15 and var56
//     assertTrue("Contract failed: equals-hashcode on var15 and var56", var15.equals(var56) ? var15.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var15
//     assertTrue("Contract failed: equals-hashcode on var56 and var15", var56.equals(var15) ? var56.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
    java.awt.Font var3 = var2.getFont();
    java.lang.String var4 = var2.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "hi!"+ "'", var4.equals("hi!"));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    var6.setForegroundAlpha((-1.0f));
    var6.setCircular(true, true);
    org.jfree.chart.event.PlotChangeEvent var12 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var6);
    var6.setBackgroundImageAlignment((-1));
    java.awt.Stroke var15 = var6.getBaseSectionOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setTextAntiAlias((java.lang.Object)var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockFrame var1 = var0.getFrame();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.util.Size2D var3 = var0.arrange(var2);
    var3.setWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("Pie Plot", var1, var2, var3);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    var4.clearRangeMarkers(0);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    boolean var23 = var22.isDomainCrosshairLockedOnData();
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
    java.awt.Font var28 = var26.getNoDataMessageFont();
    java.awt.Color var31 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.Color var33 = var31.darker();
    org.jfree.chart.text.TextFragment var34 = new org.jfree.chart.text.TextFragment("", var28, (java.awt.Paint)var31);
    var22.setDomainCrosshairPaint((java.awt.Paint)var31);
    java.awt.Stroke var36 = var22.getDomainZeroBaselineStroke();
    var22.setWeight((-1));
    java.awt.Color var41 = java.awt.Color.getColor("hi!", 1);
    var22.setDomainCrosshairPaint((java.awt.Paint)var41);
    var4.setOutlinePaint((java.awt.Paint)var41);
    org.jfree.data.general.PieDataset var45 = null;
    org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
    java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
    java.awt.Font var48 = var46.getNoDataMessageFont();
    java.awt.Color var51 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var52 = var51.getColorSpace();
    java.awt.Color var53 = var51.darker();
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var48, (java.awt.Paint)var51);
    float[] var58 = new float[] { 10.0f, 0.0f, (-1.0f)};
    float[] var59 = var51.getColorComponents(var58);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var60 = var41.getRGBComponents(var58);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setForegroundAlpha((-1.0f));
//     var1.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.ChartChangeEventType var8 = null;
//     var7.setType(var8);
//     java.lang.String var10 = var7.toString();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
//     var7.setChart(var15);
//     var15.setBorderVisible(true);
//     java.awt.Stroke var20 = var15.getBorderStroke();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var29, (org.jfree.chart.block.Arrangement)var34);
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var35.removeChangeListener(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     int var44 = var42.getDomainAxisIndex(var43);
//     var42.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     java.awt.geom.Point2D var49 = null;
//     var42.zoomDomainAxes(0.0d, var48, var49);
//     org.jfree.chart.LegendItemSource[] var51 = new org.jfree.chart.LegendItemSource[] { var42};
//     var35.setSources(var51);
//     org.jfree.chart.LegendItemSource[] var53 = var35.getSources();
//     org.jfree.chart.LegendItemSource[] var54 = var35.getSources();
//     java.lang.Object var55 = var35.clone();
//     var15.addSubtitle((org.jfree.chart.title.Title)var35);
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot(var57);
//     java.awt.Stroke var59 = var58.getBaseSectionOutlineStroke();
//     var58.setShadowXOffset(100.0d);
//     var58.setNoDataMessage("hi!");
//     java.awt.Stroke var64 = var58.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var65 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var66 = null;
//     org.jfree.chart.util.VerticalAlignment var67 = null;
//     org.jfree.chart.block.ColumnArrangement var70 = new org.jfree.chart.block.ColumnArrangement(var66, var67, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var71 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var58, (org.jfree.chart.block.Arrangement)var65, (org.jfree.chart.block.Arrangement)var70);
//     org.jfree.chart.event.TitleChangeListener var72 = null;
//     var71.removeChangeListener(var72);
//     org.jfree.data.xy.XYDataset var74 = null;
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var77 = null;
//     org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot(var74, var75, var76, var77);
//     org.jfree.chart.axis.ValueAxis var79 = null;
//     int var80 = var78.getDomainAxisIndex(var79);
//     var78.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var84 = null;
//     java.awt.geom.Point2D var85 = null;
//     var78.zoomDomainAxes(0.0d, var84, var85);
//     org.jfree.chart.LegendItemSource[] var87 = new org.jfree.chart.LegendItemSource[] { var78};
//     var71.setSources(var87);
//     org.jfree.chart.LegendItemSource[] var89 = var71.getSources();
//     org.jfree.chart.LegendItemSource[] var90 = var71.getSources();
//     java.lang.Object var91 = var71.clone();
//     org.jfree.chart.LegendItemSource[] var92 = var71.getSources();
//     var15.removeSubtitle((org.jfree.chart.title.Title)var71);
//     
//     // Checks the contract:  equals-hashcode on var22 and var58
//     assertTrue("Contract failed: equals-hashcode on var22 and var58", var22.equals(var58) ? var22.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var22
//     assertTrue("Contract failed: equals-hashcode on var58 and var22", var58.equals(var22) ? var58.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var65
//     assertTrue("Contract failed: equals-hashcode on var29 and var65", var29.equals(var65) ? var29.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var70
//     assertTrue("Contract failed: equals-hashcode on var34 and var70", var34.equals(var70) ? var34.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var29
//     assertTrue("Contract failed: equals-hashcode on var65 and var29", var65.equals(var29) ? var65.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var34
//     assertTrue("Contract failed: equals-hashcode on var70 and var34", var70.equals(var34) ? var70.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var78
//     assertTrue("Contract failed: equals-hashcode on var42 and var78", var42.equals(var78) ? var42.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var42
//     assertTrue("Contract failed: equals-hashcode on var78 and var42", var78.equals(var42) ? var78.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var15.setShadowXOffset(100.0d);
    var15.setNoDataMessage("hi!");
    java.awt.Stroke var21 = var15.getLabelOutlineStroke();
    var13.setDomainZeroBaselineStroke(var21);
    java.awt.Stroke var23 = var13.getRangeGridlineStroke();
    var8.setRangeGridlineStroke(var23);
    int var25 = var8.getDomainAxisCount();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    var8.setRenderer(1, var27, false);
    org.jfree.chart.plot.CategoryMarker var30 = null;
    org.jfree.chart.util.Layer var31 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(var30, var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
    org.jfree.chart.util.RectangleInsets var16 = var14.getLegendItemGraphicPadding();
    java.awt.Font var17 = var14.getItemFont();
    org.jfree.chart.block.BlockFrame var18 = var14.getFrame();
    org.jfree.chart.util.HorizontalAlignment var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setHorizontalAlignment(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var1, 8.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
//     java.awt.Font var6 = var4.getNoDataMessageFont();
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var10 = var9.getColorSpace();
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var6, (java.awt.Paint)var9);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var14 = var13.getValue();
//     org.jfree.chart.util.RectangleInsets var15 = var13.getLabelOffset();
//     java.awt.Stroke var16 = var13.getOutlineStroke();
//     java.awt.Paint var17 = var13.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var20 = null;
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var17, 0.0f, 1, var20);
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var25 = var24.getColorSpace();
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var24);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.text.G2TextMeasurer var29 = new org.jfree.chart.text.G2TextMeasurer(var28);
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var6, (java.awt.Paint)var24, 10.0f, (org.jfree.chart.text.TextMeasurer)var29);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    var8.setDomainAxis(1, var13, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    var8.setRenderer(var16, false);
    var8.setAnchorValue((-1.0d));
    org.jfree.data.xy.XYDataset var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
    org.jfree.chart.axis.AxisSpace var27 = var26.getFixedDomainAxisSpace();
    org.jfree.chart.axis.AxisLocation var29 = var26.getRangeAxisLocation(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setDomainAxisLocation((-16777216), var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setForegroundAlpha((-1.0f));
//     var1.setCircular(true, true);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setForegroundAlpha((-1.0f));
//     var8.setCircular(true, true);
//     java.awt.Paint var14 = var8.getLabelShadowPaint();
//     var1.setShadowPaint(var14);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     var20.setDomainZeroBaselineStroke(var28);
//     java.awt.Paint var30 = var20.getDomainGridlinePaint();
//     java.awt.Paint var31 = var20.getDomainZeroBaselinePaint();
//     var1.setOutlinePaint(var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
//     java.awt.Stroke var40 = var39.getBaseSectionOutlineStroke();
//     var39.setShadowXOffset(100.0d);
//     var39.setNoDataMessage("hi!");
//     java.awt.Stroke var45 = var39.getLabelOutlineStroke();
//     var37.setDomainZeroBaselineStroke(var45);
//     java.awt.Paint var47 = var37.getDomainGridlinePaint();
//     java.awt.Paint var48 = var37.getDomainZeroBaselinePaint();
//     var37.clearRangeMarkers(0);
//     java.awt.Stroke var51 = var37.getRangeGridlineStroke();
//     var1.setLabelLinkStroke(var51);
//     
//     // Checks the contract:  equals-hashcode on var22 and var39
//     assertTrue("Contract failed: equals-hashcode on var22 and var39", var22.equals(var39) ? var22.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var22
//     assertTrue("Contract failed: equals-hashcode on var39 and var22", var39.equals(var22) ? var39.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var37
//     assertTrue("Contract failed: equals-hashcode on var20 and var37", var20.equals(var37) ? var20.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var20
//     assertTrue("Contract failed: equals-hashcode on var37 and var20", var37.equals(var20) ? var37.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("Range[0.0,0.0]", var1, var2, var3);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    var8.clearDomainMarkers(0);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var13 = var12.getTimeline();
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 0.0d);
    double var17 = var16.getLength();
    var12.setRange(var16, true, true);
    var8.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis)var12);
    java.util.TimeZone var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setTimeZone(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     var4.clearRangeAxes();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     boolean var21 = var20.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     java.awt.Font var26 = var24.getNoDataMessageFont();
//     java.awt.Color var29 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var30 = var29.getColorSpace();
//     java.awt.Color var31 = var29.darker();
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var26, (java.awt.Paint)var29);
//     var20.setDomainCrosshairPaint((java.awt.Paint)var29);
//     org.jfree.chart.axis.AxisSpace var34 = var20.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PolarPlot var35 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     java.awt.Stroke var43 = var42.getBaseSectionOutlineStroke();
//     var42.setShadowXOffset(100.0d);
//     var42.setNoDataMessage("hi!");
//     java.awt.Stroke var48 = var42.getLabelOutlineStroke();
//     var40.setDomainZeroBaselineStroke(var48);
//     java.awt.Stroke var50 = var40.getRangeGridlineStroke();
//     var35.setRadiusGridlineStroke(var50);
//     var20.setRangeCrosshairStroke(var50);
//     var4.setRangeGridlineStroke(var50);
//     
//     // Checks the contract:  equals-hashcode on var4 and var40
//     assertTrue("Contract failed: equals-hashcode on var4 and var40", var4.equals(var40) ? var4.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var4
//     assertTrue("Contract failed: equals-hashcode on var40 and var4", var40.equals(var4) ? var40.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var14.removeChangeListener(var15);
    org.jfree.chart.util.VerticalAlignment var17 = var14.getVerticalAlignment();
    java.awt.Font var18 = var14.getItemFont();
    java.awt.Graphics2D var19 = null;
    org.jfree.data.Range var20 = null;
    org.jfree.chart.block.RectangleConstraint var22 = new org.jfree.chart.block.RectangleConstraint(var20, 1.0d);
    org.jfree.chart.util.Size2D var23 = var14.arrange(var19, var22);
    org.jfree.data.Range var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var25 = var22.toRangeHeight(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(100, 1, var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getInsets();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    java.awt.Font var12 = var10.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var13.removeLegend();
    var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var19 = var18.getColorSpace();
    java.lang.String var20 = var18.toString();
    var1.setOutlinePaint((java.awt.Paint)var18);
    var1.setStartAngle(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var20.equals("java.awt.Color[r=0,g=0,b=1]"));

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var21);
//     java.awt.Stroke var23 = var13.getRangeGridlineStroke();
//     var8.setRangeGridlineStroke(var23);
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     java.util.List var26 = var8.getCategoriesForAxis(var25);
//     var8.clearRangeMarkers(10);
//     var8.setAnchorValue(0.025d, false);
//     var8.setRangeCrosshairVisible(false);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var8.handleClick((-1), 255, var36);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(100, 1, var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getInsets();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    java.awt.Font var12 = var10.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var13.removeLegend();
    var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    var13.setAntiAlias(true);
    java.lang.Object var18 = var13.getTextAntiAlias();
    float var19 = var13.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartChangeListener var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addChangeListener(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.5f);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    java.awt.Font var4 = var2.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
    java.awt.Image var7 = null;
    var5.setBackgroundImage(var7);
    var0.setPieChart(var5);
    org.jfree.chart.ChartRenderingInfo var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var15 = var5.createBufferedImage(0, 0, 5.0d, 100.0d, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var5 = var4.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var6 = null;
    var4.setMarkerBand(var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var4, var8);
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    var4.setRange(var12, false, false);
    var4.setPositiveArrowVisible(true);
    var4.setLabelToolTip("");
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
    var21.setTickLabelsVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var21, var24);
    boolean var26 = var21.isVerticalTickLabels();
    double var27 = var21.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    var4.clearRangeMarkers(0);
    java.awt.Stroke var18 = var4.getRangeGridlineStroke();
    var4.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.axis.AxisLocation var23 = var4.getDomainAxisLocation(15);
    org.jfree.chart.plot.PlotOrientation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var23, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setForegroundAlpha((-1.0f));
//     var1.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.ChartChangeEventType var8 = null;
//     var7.setType(var8);
//     java.lang.String var10 = var7.toString();
//     org.jfree.chart.JFreeChart var11 = var7.getChart();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setForegroundAlpha((-1.0f));
//     var13.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var19 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.event.ChartChangeEventType var20 = var19.getType();
//     org.jfree.chart.event.ChartChangeEventType var21 = var19.getType();
//     var7.setType(var21);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"hi!", 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    var1.setBaseSectionOutlineStroke(var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getLabelPadding();
    double var9 = var1.getShadowYOffset();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var14 = var13.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var15 = null;
    var13.setMarkerBand(var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var13, var17);
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 0.0d);
    var13.setRange(var21, false, false);
    java.text.NumberFormat var25 = null;
    var13.setNumberFormatOverride(var25);
    boolean var27 = var1.equals((java.lang.Object)var13);
    java.lang.String var28 = var13.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    double var7 = var1.getShadowXOffset();
    var1.setPieIndex(1);
    boolean var10 = var1.getIgnoreZeroValues();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.AttributedString var14 = var12.getAttributedLabel(0);
    java.lang.Object var15 = null;
    boolean var16 = var12.equals(var15);
    java.text.AttributedString var18 = null;
    var12.setAttributedLabel(1, var18);
    var1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
    java.awt.Font var24 = var22.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
    org.jfree.chart.title.Title var27 = var25.getSubtitle(0);
    org.jfree.chart.event.ChartProgressEvent var30 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var25, 10, (-16777215));
    var1.setSectionOutlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    java.lang.String var1 = var0.getGPL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
    java.awt.Font var4 = var2.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
    java.awt.Image var7 = null;
    var5.setBackgroundImage(var7);
    var0.setPieChart(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var10 = var5.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setPieIndex(100);
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var1.handleClick(100, 1, var6);
//     org.jfree.chart.util.RectangleInsets var8 = var1.getInsets();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     java.awt.Font var12 = var10.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     var13.removeLegend();
//     var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var19 = var18.getColorSpace();
//     java.lang.String var20 = var18.toString();
//     var1.setOutlinePaint((java.awt.Paint)var18);
//     org.jfree.chart.block.BlockContainer var22 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var27 = var26.getHeightRange();
//     org.jfree.chart.util.Size2D var28 = var22.arrange(var23, var26);
//     org.jfree.chart.block.Arrangement var29 = var22.getArrangement();
//     org.jfree.chart.block.BlockContainer var30 = new org.jfree.chart.block.BlockContainer();
//     java.lang.String var31 = var30.getID();
//     var30.setPadding(1.0d, 0.0d, 0.0d, 10.0d);
//     org.jfree.chart.block.Arrangement var37 = var30.getArrangement();
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, var29, var37);
//     
//     // Checks the contract:  equals-hashcode on var29 and var37
//     assertTrue("Contract failed: equals-hashcode on var29 and var37", var29.equals(var37) ? var29.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var29
//     assertTrue("Contract failed: equals-hashcode on var37 and var29", var37.equals(var29) ? var37.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 0.0f, 0.5f, var4);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("0,0,-2,-2,-2,2,-2,2", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    java.awt.Stroke var4 = var3.getBaseSectionOutlineStroke();
    java.awt.Font var5 = var3.getNoDataMessageFont();
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var9 = var8.getColorSpace();
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var5, (java.awt.Paint)var8);
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var5, var11, 2.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     int var15 = var4.getDatasetCount();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setPieIndex(100);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     var17.setBaseSectionOutlineStroke(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var17.getLabelPadding();
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var28 = var27.getColorSpace();
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
//     org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var24, (java.awt.Paint)var27);
//     var4.setDomainZeroBaselinePaint((java.awt.Paint)var27);
//     var4.mapDatasetToRangeAxis(0, 1);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     java.awt.Stroke var38 = var37.getBaseSectionOutlineStroke();
//     var37.setShadowXOffset(100.0d);
//     var37.setNoDataMessage("hi!");
//     java.awt.Stroke var43 = var37.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var45 = null;
//     org.jfree.chart.util.VerticalAlignment var46 = null;
//     org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement(var45, var46, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var49);
//     org.jfree.chart.event.TitleChangeListener var51 = null;
//     var50.removeChangeListener(var51);
//     org.jfree.data.xy.XYDataset var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var53, var54, var55, var56);
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     int var59 = var57.getDomainAxisIndex(var58);
//     var57.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     java.awt.geom.Point2D var64 = null;
//     var57.zoomDomainAxes(0.0d, var63, var64);
//     org.jfree.chart.LegendItemSource[] var66 = new org.jfree.chart.LegendItemSource[] { var57};
//     var50.setSources(var66);
//     org.jfree.chart.LegendItemSource[] var68 = var50.getSources();
//     org.jfree.chart.LegendItemSource[] var69 = var50.getSources();
//     java.lang.Object var70 = var50.clone();
//     java.awt.geom.Rectangle2D var71 = var50.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     var4.drawAnnotations(var35, var71, var72);
//     
//     // Checks the contract:  equals-hashcode on var6 and var37
//     assertTrue("Contract failed: equals-hashcode on var6 and var37", var6.equals(var37) ? var6.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var6
//     assertTrue("Contract failed: equals-hashcode on var37 and var6", var37.equals(var6) ? var37.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var2 = var1.getValue();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     java.awt.Font var8 = var6.getNoDataMessageFont();
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var12 = var11.getColorSpace();
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var8, (java.awt.Paint)var11);
//     org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var16 = var15.getValue();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getLabelOffset();
//     java.awt.Stroke var18 = var15.getOutlineStroke();
//     java.awt.Paint var19 = var15.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var22 = null;
//     org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var8, var19, 0.0f, 1, var22);
//     var1.setLabelFont(var8);
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var27 = var26.getValue();
//     org.jfree.chart.util.RectangleInsets var28 = var26.getLabelOffset();
//     var1.setLabelOffset(var28);
//     
//     // Checks the contract:  equals-hashcode on var15 and var26
//     assertTrue("Contract failed: equals-hashcode on var15 and var26", var15.equals(var26) ? var15.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var15
//     assertTrue("Contract failed: equals-hashcode on var26 and var15", var26.equals(var15) ? var26.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(100, var6);
//     var4.setRangeGridlinesVisible(false);
//     org.jfree.data.xy.XYDataset var10 = null;
//     int var11 = var4.indexOf(var10);
//     org.jfree.data.category.CategoryDataset var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var16 = var15.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var17 = null;
//     var15.setMarkerBand(var17);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var19);
//     org.jfree.chart.util.Layer var22 = null;
//     java.util.Collection var23 = var20.getDomainMarkers(1, var22);
//     org.jfree.chart.axis.ValueAxis var25 = var20.getRangeAxis(0);
//     int var26 = var4.getRangeAxisIndex(var25);
//     java.awt.Stroke var27 = var4.getDomainZeroBaselineStroke();
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var32 = var31.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var33 = null;
//     var31.setMarkerBand(var33);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var28, var29, (org.jfree.chart.axis.ValueAxis)var31, var35);
//     org.jfree.chart.util.Layer var38 = null;
//     java.util.Collection var39 = var36.getDomainMarkers(1, var38);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var36.addRangeMarker((org.jfree.chart.plot.Marker)var41);
//     java.awt.Stroke var43 = var41.getOutlineStroke();
//     org.jfree.chart.util.Layer var44 = null;
//     boolean var45 = var4.removeDomainMarker((org.jfree.chart.plot.Marker)var41, var44);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var8 = var7.getColorSpace();
//     java.awt.Color var9 = var7.darker();
//     org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("", var4, (java.awt.Paint)var7);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.text.TextAnchor var14 = null;
//     var10.draw(var11, 1.0f, (-1.0f), var14, 0.0f, 100.0f, 5.0d);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     var8.setDomainAxis(1, var13, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var8.setRenderer(var16, false);
//     var8.setAnchorValue((-1.0d));
//     org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
//     var21.setLimit(0.0d);
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var26 = var25.getValue();
//     org.jfree.chart.util.RectangleInsets var27 = var25.getLabelOffset();
//     java.awt.Stroke var28 = var25.getOutlineStroke();
//     java.awt.Paint var29 = var25.getLabelPaint();
//     var21.setAggregatedItemsPaint(var29);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     var32.setForegroundAlpha((-1.0f));
//     var32.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var38 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var32);
//     org.jfree.chart.event.ChartChangeEventType var39 = null;
//     var38.setType(var39);
//     java.lang.String var41 = var38.toString();
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     java.awt.Stroke var44 = var43.getBaseSectionOutlineStroke();
//     java.awt.Font var45 = var43.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var43);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getPadding();
//     var38.setChart(var46);
//     var46.setBorderVisible(true);
//     java.awt.Stroke var51 = var46.getBorderStroke();
//     var46.setAntiAlias(true);
//     var21.setPieChart(var46);
//     boolean var55 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)(-1.0d), (java.lang.Object)var21);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot var57 = new org.jfree.chart.plot.PiePlot(var56);
//     java.awt.Stroke var58 = var57.getBaseSectionOutlineStroke();
//     java.awt.Font var59 = var57.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var60 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var57);
//     org.jfree.chart.util.RectangleInsets var61 = var60.getPadding();
//     java.awt.Image var62 = null;
//     var60.setBackgroundImage(var62);
//     var21.setPieChart(var60);
//     
//     // Checks the contract:  equals-hashcode on var43 and var57
//     assertTrue("Contract failed: equals-hashcode on var43 and var57", var43.equals(var57) ? var43.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var43
//     assertTrue("Contract failed: equals-hashcode on var57 and var43", var57.equals(var43) ? var57.hashCode() == var43.hashCode() : true);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var8 = var7.getColorSpace();
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var4, (java.awt.Paint)var7);
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var15 = var14.getHeightRange();
//     org.jfree.chart.util.Size2D var16 = var10.arrange(var11, var14);
//     boolean var17 = var9.equals((java.lang.Object)var14);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.text.TextBlockAnchor var21 = null;
//     var9.draw(var18, (-1.0f), 2.0f, var21, 10.0f, 0.5f, 0.0d);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("Pie Plot");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     var1.draw(var2, 0.0f, 100.0f, var5, 0.0f, 1.0f, 0.0d);
// 
//   }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var3 = var2.getColorSpace();
//     java.lang.String var4 = var2.toString();
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var2};
//     java.awt.Paint var6 = null;
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     java.awt.Paint var8 = null;
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var8};
//     java.awt.Paint var10 = null;
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var10};
//     java.awt.Stroke var12 = null;
//     java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
//     java.awt.Stroke var14 = null;
//     java.awt.Stroke[] var15 = new java.awt.Stroke[] { var14};
//     java.awt.Shape var16 = null;
//     java.awt.Shape[] var17 = new java.awt.Shape[] { var16};
//     org.jfree.chart.plot.DefaultDrawingSupplier var18 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var9, var11, var13, var15, var17);
//     java.awt.Paint var19 = null;
//     java.awt.Paint[] var20 = new java.awt.Paint[] { var19};
//     java.awt.Paint var21 = null;
//     java.awt.Paint[] var22 = new java.awt.Paint[] { var21};
//     java.awt.Paint var23 = null;
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var23};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Shape var29 = null;
//     java.awt.Shape[] var30 = new java.awt.Shape[] { var29};
//     org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier(var20, var22, var24, var26, var28, var30);
//     java.awt.Paint var32 = null;
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
//     java.awt.Paint var34 = null;
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     java.awt.Paint var36 = null;
//     java.awt.Paint[] var37 = new java.awt.Paint[] { var36};
//     java.awt.Stroke var38 = null;
//     java.awt.Stroke[] var39 = new java.awt.Stroke[] { var38};
//     java.awt.Stroke var40 = null;
//     java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
//     java.awt.Shape var42 = null;
//     java.awt.Shape[] var43 = new java.awt.Shape[] { var42};
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var33, var35, var37, var39, var41, var43);
//     java.awt.Shape[] var45 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier(var5, var11, var28, var41, var45);
//     
//     // Checks the contract:  equals-hashcode on var18 and var31
//     assertTrue("Contract failed: equals-hashcode on var18 and var31", var18.equals(var31) ? var18.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var44
//     assertTrue("Contract failed: equals-hashcode on var18 and var44", var18.equals(var44) ? var18.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var18
//     assertTrue("Contract failed: equals-hashcode on var31 and var18", var31.equals(var18) ? var31.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var44
//     assertTrue("Contract failed: equals-hashcode on var31 and var44", var31.equals(var44) ? var31.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var18
//     assertTrue("Contract failed: equals-hashcode on var44 and var18", var44.equals(var18) ? var44.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var31
//     assertTrue("Contract failed: equals-hashcode on var44 and var31", var44.equals(var31) ? var44.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     var2.setShadowXOffset(100.0d);
//     var2.setNoDataMessage("hi!");
//     java.awt.Stroke var8 = var2.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, (org.jfree.chart.block.Arrangement)var9, (org.jfree.chart.block.Arrangement)var14);
//     org.jfree.chart.util.VerticalAlignment var16 = var15.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getLegendItemGraphicPadding();
//     java.awt.Font var18 = var15.getItemFont();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     java.awt.Font var22 = var20.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.util.RectangleInsets var24 = var23.getPadding();
//     java.awt.Paint var25 = var23.getBorderPaint();
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.text.G2TextMeasurer var28 = new org.jfree.chart.text.G2TextMeasurer(var27);
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var18, var25, 0.0f, (org.jfree.chart.text.TextMeasurer)var28);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var21.getDomainAxisIndex(var22);
//     var21.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var21.zoomDomainAxes(0.0d, var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
//     var14.setSources(var30);
//     org.jfree.chart.LegendItemSource[] var32 = var14.getSources();
//     org.jfree.chart.LegendItemSource[] var33 = var14.getSources();
//     java.lang.Object var34 = var14.clone();
//     java.awt.geom.Rectangle2D var35 = var14.getBounds();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setForegroundAlpha((-1.0f));
//     var38.setCircular(true, true);
//     java.awt.Paint var44 = var38.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     org.jfree.data.general.PieDataset var53 = null;
//     org.jfree.chart.plot.PiePlot var54 = new org.jfree.chart.plot.PiePlot(var53);
//     java.awt.Stroke var55 = var54.getBaseSectionOutlineStroke();
//     var54.setShadowXOffset(100.0d);
//     var54.setNoDataMessage("hi!");
//     java.awt.Stroke var60 = var54.getLabelOutlineStroke();
//     var52.setDomainZeroBaselineStroke(var60);
//     java.awt.Paint var62 = var52.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var65 = var64.getValue();
//     org.jfree.chart.util.RectangleInsets var66 = var64.getLabelOffset();
//     java.awt.Stroke var67 = var64.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(0.0d, var44, var47, var62, var67, 0.0f);
//     java.lang.Object var70 = var69.clone();
//     org.jfree.chart.util.RectangleAnchor var71 = var69.getLabelAnchor();
//     java.awt.geom.Point2D var72 = org.jfree.chart.util.RectangleAnchor.coordinates(var35, var71);
//     
//     // Checks the contract:  equals-hashcode on var1 and var54
//     assertTrue("Contract failed: equals-hashcode on var1 and var54", var1.equals(var54) ? var1.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var1
//     assertTrue("Contract failed: equals-hashcode on var54 and var1", var54.equals(var1) ? var54.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(100, 1, var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getInsets();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    java.awt.Font var12 = var10.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var13.removeLegend();
    var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    org.jfree.chart.ChartRenderingInfo var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var21 = var13.createBufferedImage((-16777216), 0, 0.0d, 0.0d, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var8 = var7.getColorSpace();
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var4, (java.awt.Paint)var7);
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var15 = var14.getHeightRange();
//     org.jfree.chart.util.Size2D var16 = var10.arrange(var11, var14);
//     boolean var17 = var9.equals((java.lang.Object)var14);
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var21 = var20.getColorSpace();
//     java.awt.Color var22 = var20.darker();
//     boolean var23 = var9.equals((java.lang.Object)var22);
//     org.jfree.chart.text.TextLine var24 = var9.getLastLine();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.text.TextAnchor var28 = null;
//     var24.draw(var25, 0.0f, (-1.0f), var28, 2.0f, 0.5f, 5.0d);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    var4.clearRangeMarkers(0);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    boolean var23 = var22.isDomainCrosshairLockedOnData();
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
    java.awt.Font var28 = var26.getNoDataMessageFont();
    java.awt.Color var31 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var32 = var31.getColorSpace();
    java.awt.Color var33 = var31.darker();
    org.jfree.chart.text.TextFragment var34 = new org.jfree.chart.text.TextFragment("", var28, (java.awt.Paint)var31);
    var22.setDomainCrosshairPaint((java.awt.Paint)var31);
    java.awt.Stroke var36 = var22.getDomainZeroBaselineStroke();
    var22.setWeight((-1));
    java.awt.Color var41 = java.awt.Color.getColor("hi!", 1);
    var22.setDomainCrosshairPaint((java.awt.Paint)var41);
    var4.setOutlinePaint((java.awt.Paint)var41);
    float[] var44 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var45 = var41.getRGBComponents(var44);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setTickLabelsVisible(true);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var6 = var5.getRangeType();
    var1.setRangeType(var6);
    var1.setTickMarkInsideLength(100.0f);
    java.text.NumberFormat var10 = var1.getNumberFormatOverride();
    java.text.NumberFormat var11 = null;
    var1.setNumberFormatOverride(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var1);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge(1);
    org.jfree.chart.util.RectangleEdge var17 = org.jfree.chart.util.RectangleEdge.opposite(var16);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    java.awt.Font var21 = var19.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
    java.util.List var23 = var22.getSubtitles();
    boolean var24 = var16.equals((java.lang.Object)var22);
    org.jfree.chart.ChartRenderingInfo var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var30 = var22.createBufferedImage((-16777215), 100, (-1.0d), 10.0d, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var21.getDomainAxisIndex(var22);
//     var21.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var21.zoomDomainAxes(0.0d, var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
//     var14.setSources(var30);
//     org.jfree.chart.LegendItemSource[] var32 = var14.getSources();
//     org.jfree.chart.LegendItemSource[] var33 = var14.getSources();
//     java.lang.Object var34 = var14.clone();
//     java.awt.geom.Rectangle2D var35 = var14.getBounds();
//     org.jfree.chart.entity.ChartEntity var37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var35, "ChartChangeEventType.GENERAL");
//     org.jfree.data.category.CategoryDataset var38 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var42 = var41.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var43 = null;
//     var41.setMarkerBand(var43);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var41, var45);
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     java.awt.Stroke var54 = var53.getBaseSectionOutlineStroke();
//     var53.setShadowXOffset(100.0d);
//     var53.setNoDataMessage("hi!");
//     java.awt.Stroke var59 = var53.getLabelOutlineStroke();
//     var51.setDomainZeroBaselineStroke(var59);
//     java.awt.Stroke var61 = var51.getRangeGridlineStroke();
//     var46.setRangeGridlineStroke(var61);
//     var46.mapDatasetToRangeAxis(0, 1);
//     org.jfree.chart.util.RectangleEdge var67 = var46.getDomainAxisEdge((-1));
//     double var68 = org.jfree.chart.util.RectangleEdge.coordinate(var35, var67);
//     
//     // Checks the contract:  equals-hashcode on var1 and var53
//     assertTrue("Contract failed: equals-hashcode on var1 and var53", var1.equals(var53) ? var1.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var1
//     assertTrue("Contract failed: equals-hashcode on var53 and var1", var53.equals(var1) ? var53.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = null;
    int var6 = var4.getDomainAxisIndex(var5);
    org.jfree.chart.axis.AxisLocation var8 = var4.getDomainAxisLocation((-16777216));
    java.awt.Stroke var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainZeroBaselineStroke(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     java.awt.Image var3 = null;
//     org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", var3, "", "Pie Plot", "");
//     org.jfree.chart.ui.Licences var8 = org.jfree.chart.ui.Licences.getInstance();
//     boolean var9 = var7.equals((java.lang.Object)var8);
//     java.lang.String var10 = var8.getGPL();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
//     java.awt.Paint var17 = var15.getBorderPaint();
//     org.jfree.chart.ui.BasicProjectInfo var23 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "hi!", "hi!");
//     org.jfree.chart.ui.BasicProjectInfo var28 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!");
//     var23.addLibrary((org.jfree.chart.ui.Library)var28);
//     java.lang.String var30 = var23.getLicenceName();
//     org.jfree.chart.ui.BasicProjectInfo var35 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!");
//     var23.addLibrary((org.jfree.chart.ui.Library)var35);
//     org.jfree.chart.JFreeChart var37 = null;
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
//     var39.setForegroundAlpha((-1.0f));
//     var39.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var45 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var39);
//     org.jfree.chart.event.ChartChangeEventType var46 = var45.getType();
//     boolean var48 = var46.equals((java.lang.Object)(short)1);
//     org.jfree.chart.event.ChartChangeEvent var49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var35, var37, var46);
//     org.jfree.chart.event.ChartChangeEvent var50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var15, var46);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     java.awt.Stroke var54 = var53.getBaseSectionOutlineStroke();
//     var53.setShadowXOffset(100.0d);
//     var53.setNoDataMessage("hi!");
//     java.awt.Stroke var59 = var53.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var61 = null;
//     org.jfree.chart.util.VerticalAlignment var62 = null;
//     org.jfree.chart.block.ColumnArrangement var65 = new org.jfree.chart.block.ColumnArrangement(var61, var62, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53, (org.jfree.chart.block.Arrangement)var60, (org.jfree.chart.block.Arrangement)var65);
//     org.jfree.chart.event.TitleChangeListener var67 = null;
//     var66.removeChangeListener(var67);
//     org.jfree.data.xy.XYDataset var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var69, var70, var71, var72);
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     int var75 = var73.getDomainAxisIndex(var74);
//     var73.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     java.awt.geom.Point2D var80 = null;
//     var73.zoomDomainAxes(0.0d, var79, var80);
//     org.jfree.chart.LegendItemSource[] var82 = new org.jfree.chart.LegendItemSource[] { var73};
//     var66.setSources(var82);
//     org.jfree.chart.LegendItemSource[] var84 = var66.getSources();
//     org.jfree.chart.LegendItemSource[] var85 = var66.getSources();
//     java.lang.Object var86 = var66.clone();
//     java.awt.geom.Rectangle2D var87 = var66.getBounds();
//     var15.draw(var51, var87);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.util.Rotation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isDomainCrosshairLockedOnData();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
    java.awt.Font var10 = var8.getNoDataMessageFont();
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var14 = var13.getColorSpace();
    java.awt.Color var15 = var13.darker();
    org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var10, (java.awt.Paint)var13);
    var4.setDomainCrosshairPaint((java.awt.Paint)var13);
    java.awt.Stroke var18 = var4.getDomainZeroBaselineStroke();
    var4.setWeight((-1));
    java.awt.Color var23 = java.awt.Color.getColor("hi!", 1);
    var4.setDomainCrosshairPaint((java.awt.Paint)var23);
    boolean var25 = var4.isOutlineVisible();
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRenderer((-16777215), var27, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     boolean var2 = var0.equals((java.lang.Object)"Category Plot");
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
//     var5.setShadowXOffset(100.0d);
//     var5.setNoDataMessage("hi!");
//     java.awt.Stroke var11 = var5.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5, (org.jfree.chart.block.Arrangement)var12, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.event.TitleChangeListener var19 = null;
//     var18.removeChangeListener(var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     int var27 = var25.getDomainAxisIndex(var26);
//     var25.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     java.awt.geom.Point2D var32 = null;
//     var25.zoomDomainAxes(0.0d, var31, var32);
//     org.jfree.chart.LegendItemSource[] var34 = new org.jfree.chart.LegendItemSource[] { var25};
//     var18.setSources(var34);
//     org.jfree.chart.LegendItemSource[] var36 = var18.getSources();
//     org.jfree.chart.LegendItemSource[] var37 = var18.getSources();
//     java.lang.Object var38 = var18.clone();
//     java.awt.geom.Rectangle2D var39 = var18.getBounds();
//     org.jfree.chart.entity.ChartEntity var41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var39, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleAnchor var43 = null;
//     java.awt.geom.Point2D var44 = org.jfree.chart.util.RectangleAnchor.coordinates(var42, var43);
//     org.jfree.chart.plot.PlotState var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var0.draw(var3, var39, var44, var45, var46);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("ChartEntity: tooltip = hi!", var1, var2);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     float var3 = var2.getBaselineOffset();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.text.TextAnchor var7 = null;
//     var2.draw(var4, 10.0f, 0.0f, var7, 100.0f, 0.0f, 0.2d);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setTickLabelsVisible(true);
    java.awt.Stroke var4 = var1.getTickMarkStroke();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("");
    var6.setTickLabelsVisible(true);
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var11 = var10.getRangeType();
    var6.setRangeType(var11);
    java.awt.Shape var13 = var6.getRightArrow();
    var1.setRightArrow(var13);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var13, "");
    java.lang.Object var17 = var16.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    double var4 = var1.getLabelLinkMargin();
    org.jfree.data.general.DatasetGroup var5 = var1.getDatasetGroup();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setForegroundAlpha((-1.0f));
    var7.setCircular(true, true);
    org.jfree.chart.event.PlotChangeEvent var13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var7);
    var1.notifyListeners(var13);
    org.jfree.chart.util.Rotation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     var1.draw(var3, 100.0f, 0.0f, var6, 0.8f, 0.8f, 1.0E-8d);
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var21.getDomainAxisIndex(var22);
//     var21.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var21.zoomDomainAxes(0.0d, var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
//     var14.setSources(var30);
//     org.jfree.chart.LegendItemSource[] var32 = var14.getSources();
//     java.lang.Object var33 = var14.clone();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     var36.setForegroundAlpha((-1.0f));
//     var36.setCircular(true, true);
//     java.awt.Paint var42 = var36.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot(var43);
//     java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.PiePlot var52 = new org.jfree.chart.plot.PiePlot(var51);
//     java.awt.Stroke var53 = var52.getBaseSectionOutlineStroke();
//     var52.setShadowXOffset(100.0d);
//     var52.setNoDataMessage("hi!");
//     java.awt.Stroke var58 = var52.getLabelOutlineStroke();
//     var50.setDomainZeroBaselineStroke(var58);
//     java.awt.Paint var60 = var50.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var63 = var62.getValue();
//     org.jfree.chart.util.RectangleInsets var64 = var62.getLabelOffset();
//     java.awt.Stroke var65 = var62.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var67 = new org.jfree.chart.plot.ValueMarker(0.0d, var42, var45, var60, var65, 0.0f);
//     java.lang.Object var68 = var67.clone();
//     org.jfree.chart.util.RectangleAnchor var69 = var67.getLabelAnchor();
//     var14.setLegendItemGraphicLocation(var69);
//     
//     // Checks the contract:  equals-hashcode on var1 and var52
//     assertTrue("Contract failed: equals-hashcode on var1 and var52", var1.equals(var52) ? var1.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var1
//     assertTrue("Contract failed: equals-hashcode on var52 and var1", var52.equals(var1) ? var52.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     java.awt.Paint var16 = var1.getSectionOutlinePaint((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var20 = var19.getColorSpace();
//     org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var19);
//     var1.setBaseSectionOutlinePaint((java.awt.Paint)var19);
//     java.lang.String var23 = var19.toString();
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     boolean var29 = var28.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     java.awt.Font var34 = var32.getNoDataMessageFont();
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var38 = var37.getColorSpace();
//     java.awt.Color var39 = var37.darker();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var34, (java.awt.Paint)var37);
//     var28.setDomainCrosshairPaint((java.awt.Paint)var37);
//     java.awt.color.ColorSpace var42 = var37.getColorSpace();
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot(var44);
//     java.awt.Stroke var46 = var45.getBaseSectionOutlineStroke();
//     java.awt.Font var47 = var45.getNoDataMessageFont();
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var51 = var50.getColorSpace();
//     java.awt.Color var52 = var50.darker();
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var47, (java.awt.Paint)var50);
//     float[] var57 = new float[] { 10.0f, 0.0f, (-1.0f)};
//     float[] var58 = var50.getColorComponents(var57);
//     float[] var59 = var19.getColorComponents(var42, var57);
//     
//     // Checks the contract:  equals-hashcode on var32 and var45
//     assertTrue("Contract failed: equals-hashcode on var32 and var45", var32.equals(var45) ? var32.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var32
//     assertTrue("Contract failed: equals-hashcode on var45 and var32", var45.equals(var32) ? var45.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isDomainCrosshairLockedOnData();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
    java.awt.Font var10 = var8.getNoDataMessageFont();
    java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var14 = var13.getColorSpace();
    java.awt.Color var15 = var13.darker();
    org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var10, (java.awt.Paint)var13);
    var4.setDomainCrosshairPaint((java.awt.Paint)var13);
    org.jfree.chart.axis.AxisSpace var18 = var4.getFixedRangeAxisSpace();
    org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
    var26.setShadowXOffset(100.0d);
    var26.setNoDataMessage("hi!");
    java.awt.Stroke var32 = var26.getLabelOutlineStroke();
    var24.setDomainZeroBaselineStroke(var32);
    java.awt.Stroke var34 = var24.getRangeGridlineStroke();
    var19.setRadiusGridlineStroke(var34);
    var4.setRangeCrosshairStroke(var34);
    org.jfree.data.xy.XYDataset var38 = null;
    var4.setDataset(255, var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     var20.setDomainZeroBaselineStroke(var28);
//     java.awt.Paint var30 = var20.getDomainGridlinePaint();
//     var20.clearRangeAxes();
//     var20.clearDomainMarkers();
//     org.jfree.chart.plot.DatasetRenderingOrder var33 = var20.getDatasetRenderingOrder();
//     org.jfree.chart.plot.ValueMarker var35 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var36 = var35.getValue();
//     org.jfree.chart.util.RectangleInsets var37 = var35.getLabelOffset();
//     java.awt.Stroke var38 = var35.getOutlineStroke();
//     var20.addRangeMarker((org.jfree.chart.plot.Marker)var35);
//     boolean var40 = var8.equals((java.lang.Object)var35);
//     
//     // Checks the contract:  equals-hashcode on var13 and var35
//     assertTrue("Contract failed: equals-hashcode on var13 and var35", var13.equals(var35) ? var13.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var13
//     assertTrue("Contract failed: equals-hashcode on var35 and var13", var35.equals(var13) ? var35.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", var1);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
//     var7.setShadowXOffset(100.0d);
//     var7.setNoDataMessage("hi!");
//     java.awt.Stroke var13 = var7.getLabelOutlineStroke();
//     var5.setDomainZeroBaselineStroke(var13);
//     java.awt.Stroke var15 = var5.getRangeGridlineStroke();
//     var0.setRadiusGridlineStroke(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     boolean var22 = var21.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     java.awt.Font var27 = var25.getNoDataMessageFont();
//     java.awt.Color var30 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var31 = var30.getColorSpace();
//     java.awt.Color var32 = var30.darker();
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var27, (java.awt.Paint)var30);
//     var21.setDomainCrosshairPaint((java.awt.Paint)var30);
//     java.awt.Stroke var35 = var21.getDomainZeroBaselineStroke();
//     var21.setWeight((-1));
//     java.awt.Color var40 = java.awt.Color.getColor("hi!", 1);
//     var21.setDomainCrosshairPaint((java.awt.Paint)var40);
//     var0.setRadiusGridlinePaint((java.awt.Paint)var40);
//     java.lang.String var43 = var0.getPlotType();
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleAnchor var47 = null;
//     java.awt.geom.Point2D var48 = org.jfree.chart.util.RectangleAnchor.coordinates(var46, var47);
//     var0.zoomRangeAxes(0.0d, var45, var48);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     java.awt.Stroke var4 = var3.getBaseSectionOutlineStroke();
//     var3.setShadowXOffset(100.0d);
//     var3.setNoDataMessage("hi!");
//     java.awt.Stroke var9 = var3.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
//     org.jfree.chart.event.TitleChangeListener var17 = null;
//     var16.removeChangeListener(var17);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     int var25 = var23.getDomainAxisIndex(var24);
//     var23.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     java.awt.geom.Point2D var30 = null;
//     var23.zoomDomainAxes(0.0d, var29, var30);
//     org.jfree.chart.LegendItemSource[] var32 = new org.jfree.chart.LegendItemSource[] { var23};
//     var16.setSources(var32);
//     org.jfree.chart.LegendItemSource[] var34 = var16.getSources();
//     org.jfree.chart.LegendItemSource[] var35 = var16.getSources();
//     java.lang.Object var36 = var16.clone();
//     java.awt.geom.Rectangle2D var37 = var16.getBounds();
//     org.jfree.chart.entity.ChartEntity var39 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var37, "ChartChangeEventType.GENERAL");
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
//     var46.setShadowXOffset(100.0d);
//     var46.setNoDataMessage("hi!");
//     java.awt.Stroke var52 = var46.getLabelOutlineStroke();
//     var44.setDomainZeroBaselineStroke(var52);
//     org.jfree.chart.plot.PlotRenderingInfo var55 = null;
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var56, var57, var58, var59);
//     boolean var61 = var60.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var63 = null;
//     org.jfree.chart.plot.PiePlot var64 = new org.jfree.chart.plot.PiePlot(var63);
//     java.awt.Stroke var65 = var64.getBaseSectionOutlineStroke();
//     java.awt.Font var66 = var64.getNoDataMessageFont();
//     java.awt.Color var69 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var70 = var69.getColorSpace();
//     java.awt.Color var71 = var69.darker();
//     org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("", var66, (java.awt.Paint)var69);
//     var60.setDomainCrosshairPaint((java.awt.Paint)var69);
//     org.jfree.chart.axis.AxisSpace var74 = var60.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     java.awt.geom.Rectangle2D var78 = null;
//     org.jfree.chart.util.RectangleAnchor var79 = null;
//     java.awt.geom.Point2D var80 = org.jfree.chart.util.RectangleAnchor.coordinates(var78, var79);
//     var60.zoomDomainAxes(0.025d, (-1.0d), var77, var80);
//     var44.zoomDomainAxes(4.0d, var55, var80);
//     org.jfree.chart.plot.PlotState var83 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var84 = null;
//     var0.draw(var1, var37, var80, var83, var84);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     var2.setShadowXOffset(100.0d);
//     var2.setNoDataMessage("hi!");
//     java.awt.Stroke var8 = var2.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, (org.jfree.chart.block.Arrangement)var9, (org.jfree.chart.block.Arrangement)var14);
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var15.removeChangeListener(var16);
//     org.jfree.chart.util.VerticalAlignment var18 = var15.getVerticalAlignment();
//     java.awt.Font var19 = var15.getItemFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     var23.setShadowXOffset(100.0d);
//     var23.setNoDataMessage("hi!");
//     java.awt.Stroke var29 = var23.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var35);
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var36.removeChangeListener(var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     int var45 = var43.getDomainAxisIndex(var44);
//     var43.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var43.zoomDomainAxes(0.0d, var49, var50);
//     org.jfree.chart.LegendItemSource[] var52 = new org.jfree.chart.LegendItemSource[] { var43};
//     var36.setSources(var52);
//     org.jfree.chart.LegendItemSource[] var54 = var36.getSources();
//     org.jfree.chart.LegendItemSource[] var55 = var36.getSources();
//     java.lang.Object var56 = var36.clone();
//     java.awt.geom.Rectangle2D var57 = var36.getBounds();
//     var20.draw(var21, var57);
//     
//     // Checks the contract:  equals-hashcode on var2 and var23
//     assertTrue("Contract failed: equals-hashcode on var2 and var23", var2.equals(var23) ? var2.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var2
//     assertTrue("Contract failed: equals-hashcode on var23 and var2", var23.equals(var2) ? var23.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var30
//     assertTrue("Contract failed: equals-hashcode on var9 and var30", var9.equals(var30) ? var9.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var35
//     assertTrue("Contract failed: equals-hashcode on var14 and var35", var14.equals(var35) ? var14.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var9
//     assertTrue("Contract failed: equals-hashcode on var30 and var9", var30.equals(var9) ? var30.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var14
//     assertTrue("Contract failed: equals-hashcode on var35 and var14", var35.equals(var14) ? var35.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = var0.getTimeline();
//     org.jfree.chart.axis.TickUnitSource var2 = var0.getStandardTickUnits();
//     java.util.TimeZone var3 = var0.getTimeZone();
//     org.jfree.chart.axis.TickUnitSource var4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var3);
//     
//     // Checks the contract:  equals-hashcode on var2 and var4
//     assertTrue("Contract failed: equals-hashcode on var2 and var4", var2.equals(var4) ? var2.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var2
//     assertTrue("Contract failed: equals-hashcode on var4 and var2", var4.equals(var2) ? var4.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getLegendItemGraphicPadding();
//     java.lang.Object var17 = var14.clone();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var19.setShadowXOffset(100.0d);
//     var19.setNoDataMessage("hi!");
//     java.awt.Stroke var25 = var19.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19, (org.jfree.chart.block.Arrangement)var26, (org.jfree.chart.block.Arrangement)var31);
//     org.jfree.chart.event.TitleChangeListener var33 = null;
//     var32.removeChangeListener(var33);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     int var41 = var39.getDomainAxisIndex(var40);
//     var39.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var39.zoomDomainAxes(0.0d, var45, var46);
//     org.jfree.chart.LegendItemSource[] var48 = new org.jfree.chart.LegendItemSource[] { var39};
//     var32.setSources(var48);
//     var14.setSources(var48);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var31
//     assertTrue("Contract failed: equals-hashcode on var13 and var31", var13.equals(var31) ? var13.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var13
//     assertTrue("Contract failed: equals-hashcode on var31 and var13", var31.equals(var13) ? var31.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setPieIndex(100);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
//     var1.setBaseSectionOutlineStroke(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var1.getLabelPadding();
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var12 = var11.getColorSpace();
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var8, (java.awt.Paint)var11);
//     java.awt.Paint var15 = var14.getPaint();
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var15);
//     
//     // Checks the contract:  equals-hashcode on var13 and var16
//     assertTrue("Contract failed: equals-hashcode on var13 and var16", var13.equals(var16) ? var13.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var13
//     assertTrue("Contract failed: equals-hashcode on var16 and var13", var16.equals(var13) ? var16.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getLegendItemGraphicPadding();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var25, (org.jfree.chart.block.Arrangement)var30);
//     org.jfree.chart.event.TitleChangeListener var32 = null;
//     var31.removeChangeListener(var32);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     int var40 = var38.getDomainAxisIndex(var39);
//     var38.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Point2D var45 = null;
//     var38.zoomDomainAxes(0.0d, var44, var45);
//     org.jfree.chart.LegendItemSource[] var47 = new org.jfree.chart.LegendItemSource[] { var38};
//     var31.setSources(var47);
//     org.jfree.chart.LegendItemSource[] var49 = var31.getSources();
//     org.jfree.chart.LegendItemSource[] var50 = var31.getSources();
//     java.lang.Object var51 = var31.clone();
//     java.awt.geom.Rectangle2D var52 = var31.getBounds();
//     org.jfree.chart.entity.ChartEntity var54 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var52, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var57 = var16.createInsetRectangle(var52, true, true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var4 = var3.getFirstTextFragment();
//     var1.addFragment(var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.util.Size2D var7 = var4.calculateDimensions(var6);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainCrosshairLockedOnData();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     var6.setLabelAngle(0.0d);
//     var6.centerRange(0.025d);
//     int var11 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var14 = var13.getValue();
//     boolean var15 = var4.removeDomainMarker((org.jfree.chart.plot.Marker)var13);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var4.removeLegend();
//     java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
//     var4.setBorderPaint((java.awt.Paint)var8);
//     org.jfree.chart.util.RectangleInsets var10 = var4.getPadding();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
//     java.awt.Paint var17 = var15.getBorderPaint();
//     java.awt.RenderingHints var18 = var15.getRenderingHints();
//     var4.setRenderingHints(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    var1.setBackgroundAlpha(0.0f);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.AttributedString var12 = var10.getAttributedLabel(0);
    java.lang.Object var13 = null;
    boolean var14 = var10.equals(var13);
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var10);
    org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
    boolean var18 = var1.equals((java.lang.Object)var17);
    java.awt.Font var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setLabelFont(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getPadding();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
//     java.awt.Font var9 = var7.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     var10.removeLegend();
//     java.awt.Color var14 = java.awt.Color.getColor("hi!", 1);
//     var10.setBorderPaint((java.awt.Paint)var14);
//     org.jfree.chart.util.RectangleInsets var16 = var10.getPadding();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var25 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement(var26, var27, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var25, (org.jfree.chart.block.Arrangement)var30);
//     org.jfree.chart.event.TitleChangeListener var32 = null;
//     var31.removeChangeListener(var32);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     int var40 = var38.getDomainAxisIndex(var39);
//     var38.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Point2D var45 = null;
//     var38.zoomDomainAxes(0.0d, var44, var45);
//     org.jfree.chart.LegendItemSource[] var47 = new org.jfree.chart.LegendItemSource[] { var38};
//     var31.setSources(var47);
//     org.jfree.chart.LegendItemSource[] var49 = var31.getSources();
//     org.jfree.chart.LegendItemSource[] var50 = var31.getSources();
//     java.lang.Object var51 = var31.clone();
//     java.awt.geom.Rectangle2D var52 = var31.getBounds();
//     org.jfree.chart.entity.ChartEntity var54 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var52, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var57 = var16.createInsetRectangle(var52, false, false);
//     org.jfree.chart.util.LengthAdjustmentType var58 = null;
//     org.jfree.chart.util.LengthAdjustmentType var59 = null;
//     java.awt.geom.Rectangle2D var60 = var5.createAdjustedRectangle(var57, var58, var59);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var15.setShadowXOffset(100.0d);
    var15.setNoDataMessage("hi!");
    java.awt.Stroke var21 = var15.getLabelOutlineStroke();
    var13.setDomainZeroBaselineStroke(var21);
    java.awt.Stroke var23 = var13.getRangeGridlineStroke();
    var8.setRangeGridlineStroke(var23);
    org.jfree.chart.axis.CategoryAxis var25 = null;
    java.util.List var26 = var8.getCategoriesForAxis(var25);
    var8.clearRangeMarkers(10);
    var8.setAnchorValue(0.025d, false);
    var8.setRangeCrosshairVisible(false);
    org.jfree.chart.plot.CategoryMarker var35 = null;
    org.jfree.chart.util.Layer var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(100, var35, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = var0.getTimeline();
    java.util.Date var2 = var0.getMaximumDate();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setPieIndex(100);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
    java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
    var5.setBaseSectionOutlineStroke(var10);
    org.jfree.chart.util.RectangleInsets var12 = var5.getLabelPadding();
    var3.setTickLabelInsets(var12);
    float var14 = var3.getTickMarkOutsideLength();
    java.util.Date var15 = var3.getMaximumDate();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    var18.setPieIndex(100);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
    var18.setBaseSectionOutlineStroke(var23);
    org.jfree.chart.util.RectangleInsets var25 = var18.getLabelPadding();
    var16.setTickLabelInsets(var25);
    float var27 = var16.getTickMarkOutsideLength();
    java.util.Date var28 = var16.getMaximumDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var15, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var1 = var0.getTickLabelPaint();
    java.util.TimeZone var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTimeZone(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    org.jfree.chart.util.RectangleEdge var15 = var8.getRangeAxisEdge();
    var8.clearRangeMarkers();
    java.lang.Object var17 = var8.clone();
    org.jfree.chart.annotations.CategoryAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var19 = var8.removeAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var3 = var1.getLegendItems();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var6 = var5.getValue();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     java.awt.Font var12 = var10.getNoDataMessageFont();
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var16 = var15.getColorSpace();
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var12, (java.awt.Paint)var15);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var20 = var19.getValue();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getLabelOffset();
//     java.awt.Stroke var22 = var19.getOutlineStroke();
//     java.awt.Paint var23 = var19.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var26 = null;
//     org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, var23, 0.0f, 1, var26);
//     var5.setLabelFont(var12);
//     var1.setAngleLabelFont(var12);
//     org.jfree.chart.text.TextLine var30 = new org.jfree.chart.text.TextLine("Pie Plot", var12);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.text.TextAnchor var34 = null;
//     var30.draw(var31, 0.5f, 2.0f, var34, 2.0f, 100.0f, (-1.0d));
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (-16777216));
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
//     var7.setShadowXOffset(100.0d);
//     var7.setNoDataMessage("hi!");
//     java.awt.Stroke var13 = var7.getLabelOutlineStroke();
//     var5.setDomainZeroBaselineStroke(var13);
//     java.awt.Stroke var15 = var5.getRangeGridlineStroke();
//     var0.setRadiusGridlineStroke(var15);
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var21 = var20.getColorSpace();
//     java.awt.Color var22 = var20.darker();
//     java.awt.Color var23 = java.awt.Color.getColor("", var22);
//     var0.setRadiusGridlinePaint((java.awt.Paint)var22);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     var26.setShadowXOffset(100.0d);
//     var26.setNoDataMessage("hi!");
//     java.awt.Stroke var32 = var26.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var34, var35, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var38);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     java.awt.Stroke var42 = var41.getBaseSectionOutlineStroke();
//     var41.setShadowXOffset(100.0d);
//     var41.setNoDataMessage("hi!");
//     java.awt.Stroke var47 = var41.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var49 = null;
//     org.jfree.chart.util.VerticalAlignment var50 = null;
//     org.jfree.chart.block.ColumnArrangement var53 = new org.jfree.chart.block.ColumnArrangement(var49, var50, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41, (org.jfree.chart.block.Arrangement)var48, (org.jfree.chart.block.Arrangement)var53);
//     org.jfree.chart.block.BlockContainer var55 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var48);
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var48);
//     
//     // Checks the contract:  equals-hashcode on var7 and var26
//     assertTrue("Contract failed: equals-hashcode on var7 and var26", var7.equals(var26) ? var7.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var41
//     assertTrue("Contract failed: equals-hashcode on var7 and var41", var7.equals(var41) ? var7.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var7
//     assertTrue("Contract failed: equals-hashcode on var26 and var7", var26.equals(var7) ? var26.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var41
//     assertTrue("Contract failed: equals-hashcode on var26 and var41", var26.equals(var41) ? var26.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var7
//     assertTrue("Contract failed: equals-hashcode on var41 and var7", var41.equals(var7) ? var41.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var26
//     assertTrue("Contract failed: equals-hashcode on var41 and var26", var41.equals(var26) ? var41.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var48
//     assertTrue("Contract failed: equals-hashcode on var33 and var48", var33.equals(var48) ? var33.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var53
//     assertTrue("Contract failed: equals-hashcode on var38 and var53", var38.equals(var53) ? var38.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var33
//     assertTrue("Contract failed: equals-hashcode on var48 and var33", var48.equals(var33) ? var48.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var38
//     assertTrue("Contract failed: equals-hashcode on var53 and var38", var53.equals(var38) ? var53.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    var4.clearRangeAxes();
    var4.clearDomainMarkers();
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var20 = var19.getValue();
    org.jfree.chart.util.RectangleInsets var21 = var19.getLabelOffset();
    java.awt.Stroke var22 = var19.getOutlineStroke();
    java.awt.Paint var23 = var19.getLabelPaint();
    org.jfree.chart.util.Layer var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(0, (org.jfree.chart.plot.Marker)var19, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
//     var3.setRange(var11, false, false);
//     var3.setPositiveArrowVisible(true);
//     var3.setLabelToolTip("");
//     org.jfree.data.Range var19 = null;
//     org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 0.0d);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     var23.setForegroundAlpha((-1.0f));
//     var23.setCircular(true, true);
//     java.awt.Paint var29 = var23.getOutlinePaint();
//     boolean var30 = var21.equals((java.lang.Object)var29);
//     var3.setRange(var21);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     var33.setForegroundAlpha((-1.0f));
//     var33.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var39 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var33);
//     org.jfree.chart.event.ChartChangeEventType var40 = null;
//     var39.setType(var40);
//     java.lang.String var42 = var39.toString();
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot(var43);
//     java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
//     java.awt.Font var46 = var44.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var44);
//     org.jfree.chart.util.RectangleInsets var48 = var47.getPadding();
//     var39.setChart(var47);
//     var47.setBorderVisible(true);
//     java.awt.Stroke var52 = var47.getBorderStroke();
//     var47.setAntiAlias(true);
//     var47.setBackgroundImageAlignment(10);
//     boolean var57 = var21.equals((java.lang.Object)10);
//     
//     // Checks the contract:  equals-hashcode on var23 and var33
//     assertTrue("Contract failed: equals-hashcode on var23 and var33", var23.equals(var33) ? var23.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var23
//     assertTrue("Contract failed: equals-hashcode on var33 and var23", var33.equals(var23) ? var33.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ChartChangeEventType.GENERAL", var1, 0.0f, 0.0f, var4, 10.0d, 0.8f, (-1.0f));
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var2 = var1.getValue();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
    boolean var5 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)"Polar Plot");
    double var6 = var3.getTop();
    double var7 = var3.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.lang.String var1 = var0.getLabel();
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var2, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.PolarItemRenderer var1 = var0.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     var2.setShadowXOffset(100.0d);
//     var2.setNoDataMessage("hi!");
//     java.awt.Stroke var8 = var2.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, (org.jfree.chart.block.Arrangement)var9, (org.jfree.chart.block.Arrangement)var14);
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var15.removeChangeListener(var16);
//     org.jfree.chart.util.VerticalAlignment var18 = var15.getVerticalAlignment();
//     java.awt.Font var19 = var15.getItemFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     java.awt.Font var25 = var23.getNoDataMessageFont();
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var29 = var28.getColorSpace();
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var25, (java.awt.Paint)var28);
//     org.jfree.chart.block.BlockContainer var31 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var36 = var35.getHeightRange();
//     org.jfree.chart.util.Size2D var37 = var31.arrange(var32, var35);
//     boolean var38 = var30.equals((java.lang.Object)var35);
//     java.awt.Color var41 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var42 = var41.getColorSpace();
//     java.awt.Color var43 = var41.darker();
//     boolean var44 = var30.equals((java.lang.Object)var43);
//     var20.setBackgroundPaint((java.awt.Paint)var43);
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     java.awt.Stroke var48 = var47.getBaseSectionOutlineStroke();
//     var47.setShadowXOffset(100.0d);
//     var47.setNoDataMessage("hi!");
//     double var53 = var47.getShadowXOffset();
//     var47.setPieIndex(1);
//     boolean var56 = var47.getIgnoreZeroValues();
//     org.jfree.data.general.PieDataset var57 = null;
//     org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot(var57);
//     org.jfree.data.general.PieDataset var59 = null;
//     org.jfree.chart.plot.PiePlot var60 = new org.jfree.chart.plot.PiePlot(var59);
//     java.awt.Stroke var61 = var60.getBaseSectionOutlineStroke();
//     var60.setShadowXOffset(100.0d);
//     var60.setNoDataMessage("hi!");
//     java.awt.Stroke var66 = var60.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var67 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var68 = null;
//     org.jfree.chart.util.VerticalAlignment var69 = null;
//     org.jfree.chart.block.ColumnArrangement var72 = new org.jfree.chart.block.ColumnArrangement(var68, var69, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60, (org.jfree.chart.block.Arrangement)var67, (org.jfree.chart.block.Arrangement)var72);
//     java.awt.Paint var75 = var60.getSectionOutlinePaint((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
//     java.awt.Color var78 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var79 = var78.getColorSpace();
//     org.jfree.chart.block.BlockBorder var80 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var78);
//     var60.setBaseSectionOutlinePaint((java.awt.Paint)var78);
//     java.lang.String var82 = var78.toString();
//     var58.setLabelOutlinePaint((java.awt.Paint)var78);
//     var47.setLabelBackgroundPaint((java.awt.Paint)var78);
//     var20.setPaint((java.awt.Paint)var78);
//     
//     // Checks the contract:  equals-hashcode on var9 and var67
//     assertTrue("Contract failed: equals-hashcode on var9 and var67", var9.equals(var67) ? var9.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var72
//     assertTrue("Contract failed: equals-hashcode on var14 and var72", var14.equals(var72) ? var14.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var9
//     assertTrue("Contract failed: equals-hashcode on var67 and var9", var67.equals(var9) ? var67.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var14
//     assertTrue("Contract failed: equals-hashcode on var72 and var14", var72.equals(var14) ? var72.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge(1);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     java.awt.Font var21 = var19.getNoDataMessageFont();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var25 = var24.getColorSpace();
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var21, (java.awt.Paint)var24);
//     var4.setRangeCrosshairPaint((java.awt.Paint)var24);
//     var4.setDomainCrosshairValue(4.0d, false);
//     java.awt.Paint var31 = var4.getDomainTickBandPaint();
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var36 = var35.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var37 = null;
//     var35.setMarkerBand(var37);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var35, var39);
//     org.jfree.chart.util.Layer var42 = null;
//     java.util.Collection var43 = var40.getDomainMarkers(1, var42);
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     var40.setDomainAxis(1, var45, false);
//     var40.setAnchorValue((-1.0d), true);
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.PiePlot var52 = new org.jfree.chart.plot.PiePlot(var51);
//     java.awt.Stroke var53 = var52.getBaseSectionOutlineStroke();
//     var52.setShadowXOffset(100.0d);
//     var52.setNoDataMessage("hi!");
//     java.awt.Stroke var58 = var52.getLabelOutlineStroke();
//     var40.setDomainGridlineStroke(var58);
//     var4.setRangeCrosshairStroke(var58);
//     
//     // Checks the contract:  equals-hashcode on var6 and var52
//     assertTrue("Contract failed: equals-hashcode on var6 and var52", var6.equals(var52) ? var6.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var6
//     assertTrue("Contract failed: equals-hashcode on var52 and var6", var52.equals(var6) ? var52.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(100, 1, var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getInsets();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    java.awt.Font var12 = var10.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var13.removeLegend();
    var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    var13.setAntiAlias(true);
    java.lang.Object var18 = var13.getTextAntiAlias();
    org.jfree.chart.event.ChartChangeListener var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addChangeListener(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    boolean var1 = var0.isAxisLineVisible();
    var0.setAxisLineVisible(true);
    java.awt.Shape var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setUpArrow(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers((-1), var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     var16.setDomainZeroBaselineStroke(var24);
//     java.awt.Paint var26 = var16.getDomainGridlinePaint();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var31 = var30.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var32 = null;
//     var30.setMarkerBand(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var30, var34);
//     org.jfree.chart.util.Layer var37 = null;
//     java.util.Collection var38 = var35.getDomainMarkers(1, var37);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var35.addRangeMarker((org.jfree.chart.plot.Marker)var40);
//     org.jfree.chart.axis.AxisLocation var42 = var35.getRangeAxisLocation();
//     var16.setDomainAxisLocation(var42);
//     var8.setDomainAxisLocation(var42, true);
//     java.awt.Paint var46 = var8.getRangeGridlinePaint();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot(var48);
//     java.awt.Stroke var50 = var49.getBaseSectionOutlineStroke();
//     var49.setShadowXOffset(100.0d);
//     var49.setNoDataMessage("hi!");
//     java.awt.Stroke var55 = var49.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49, (org.jfree.chart.block.Arrangement)var56, (org.jfree.chart.block.Arrangement)var61);
//     org.jfree.chart.event.TitleChangeListener var63 = null;
//     var62.removeChangeListener(var63);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var65, var66, var67, var68);
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     int var71 = var69.getDomainAxisIndex(var70);
//     var69.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     java.awt.geom.Point2D var76 = null;
//     var69.zoomDomainAxes(0.0d, var75, var76);
//     org.jfree.chart.LegendItemSource[] var78 = new org.jfree.chart.LegendItemSource[] { var69};
//     var62.setSources(var78);
//     org.jfree.chart.LegendItemSource[] var80 = var62.getSources();
//     org.jfree.chart.LegendItemSource[] var81 = var62.getSources();
//     java.lang.Object var82 = var62.clone();
//     java.awt.geom.Rectangle2D var83 = var62.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     boolean var86 = var8.render(var47, var83, 0, var85);
//     
//     // Checks the contract:  equals-hashcode on var18 and var49
//     assertTrue("Contract failed: equals-hashcode on var18 and var49", var18.equals(var49) ? var18.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var18
//     assertTrue("Contract failed: equals-hashcode on var49 and var18", var49.equals(var18) ? var49.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(100, var6);
    var4.setRangeGridlinesVisible(false);
    org.jfree.data.xy.XYDataset var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDataset((-1), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
    var7.setShadowXOffset(100.0d);
    var7.setNoDataMessage("hi!");
    java.awt.Stroke var13 = var7.getLabelOutlineStroke();
    var5.setDomainZeroBaselineStroke(var13);
    java.awt.Stroke var15 = var5.getRangeGridlineStroke();
    var0.setRadiusGridlineStroke(var15);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    boolean var22 = var21.isDomainCrosshairLockedOnData();
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
    java.awt.Font var27 = var25.getNoDataMessageFont();
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var31 = var30.getColorSpace();
    java.awt.Color var32 = var30.darker();
    org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var27, (java.awt.Paint)var30);
    var21.setDomainCrosshairPaint((java.awt.Paint)var30);
    java.awt.Stroke var35 = var21.getDomainZeroBaselineStroke();
    var21.setWeight((-1));
    java.awt.Color var40 = java.awt.Color.getColor("hi!", 1);
    var21.setDomainCrosshairPaint((java.awt.Paint)var40);
    var0.setRadiusGridlinePaint((java.awt.Paint)var40);
    java.lang.Object var43 = var0.clone();
    var0.setRadiusGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var4 = var3.getFirstTextFragment();
//     var1.addFragment(var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.text.TextAnchor var9 = null;
//     var4.draw(var6, 2.0f, 1.0f, var9, 2.0f, 0.0f, 0.0d);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     var0.setInnerSeparatorExtension(0.0d);
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     int var9 = var7.getDomainAxisIndex(var8);
//     var7.setRangeCrosshairValue(10.0d);
//     boolean var12 = var7.isDomainCrosshairVisible();
//     int var13 = var7.getWeight();
//     boolean var14 = var0.equals((java.lang.Object)var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
//     java.awt.Font var18 = var16.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.title.Title var21 = var19.getSubtitle(0);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     var25.setShadowXOffset(100.0d);
//     var25.setNoDataMessage("hi!");
//     java.awt.Stroke var31 = var25.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var37);
//     org.jfree.chart.event.TitleChangeListener var39 = null;
//     var38.removeChangeListener(var39);
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     int var47 = var45.getDomainAxisIndex(var46);
//     var45.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     java.awt.geom.Point2D var52 = null;
//     var45.zoomDomainAxes(0.0d, var51, var52);
//     org.jfree.chart.LegendItemSource[] var54 = new org.jfree.chart.LegendItemSource[] { var45};
//     var38.setSources(var54);
//     org.jfree.chart.LegendItemSource[] var56 = var38.getSources();
//     org.jfree.chart.LegendItemSource[] var57 = var38.getSources();
//     java.lang.Object var58 = var38.clone();
//     java.awt.geom.Rectangle2D var59 = var38.getBounds();
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot var61 = new org.jfree.chart.plot.PiePlot(var60);
//     var61.setForegroundAlpha((-1.0f));
//     var61.setCircular(true, true);
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot(var67);
//     var68.setForegroundAlpha((-1.0f));
//     var68.setCircular(true, true);
//     java.awt.Paint var74 = var68.getLabelShadowPaint();
//     var61.setShadowPaint(var74);
//     java.awt.Paint var77 = null;
//     var61.setSectionOutlinePaint((java.lang.Comparable)1.0d, var77);
//     org.jfree.chart.urls.PieURLGenerator var79 = null;
//     var61.setURLGenerator(var79);
//     org.jfree.chart.plot.PlotRenderingInfo var82 = null;
//     org.jfree.chart.plot.PiePlotState var83 = var0.initialise(var23, var59, var61, (java.lang.Integer)255, var82);
//     
//     // Checks the contract:  equals-hashcode on var7 and var45
//     assertTrue("Contract failed: equals-hashcode on var7 and var45", var7.equals(var45) ? var7.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var7
//     assertTrue("Contract failed: equals-hashcode on var45 and var7", var45.equals(var7) ? var45.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = var0.getTimeline();
    org.jfree.chart.axis.TickUnitSource var2 = var0.getStandardTickUnits();
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setTickLabelsVisible(true);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var6 = var5.getRangeType();
//     var1.setRangeType(var6);
//     java.awt.Shape var8 = var1.getRightArrow();
//     org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var8);
//     var9.setToolTipText("hi!");
//     java.lang.String var12 = var9.toString();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var13 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var14 = null;
//     java.lang.String var15 = var9.getImageMapAreaTag(var13, var14);
// 
//   }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     var4.clearRangeAxes();
//     var4.clearDomainMarkers();
//     org.jfree.chart.plot.DatasetRenderingOrder var17 = var4.getDatasetRenderingOrder();
//     var4.configureDomainAxes();
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var4.getRangeMarkers(255, var20);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     org.jfree.chart.axis.AxisSpace var29 = var28.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleAnchor var33 = null;
//     java.awt.geom.Point2D var34 = org.jfree.chart.util.RectangleAnchor.coordinates(var32, var33);
//     var28.zoomDomainAxes(100.0d, var31, var34, false);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleAnchor var40 = null;
//     java.awt.geom.Point2D var41 = org.jfree.chart.util.RectangleAnchor.coordinates(var39, var40);
//     var28.zoomRangeAxes(0.14d, var38, var41);
//     var4.zoomDomainAxes(8.0d, var23, var41);
//     
//     // Checks the contract:  equals-hashcode on var4 and var28
//     assertTrue("Contract failed: equals-hashcode on var4 and var28", var4.equals(var28) ? var4.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var4
//     assertTrue("Contract failed: equals-hashcode on var28 and var4", var28.equals(var4) ? var28.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getLegendItemGraphicPadding();
//     java.awt.Font var17 = var14.getItemFont();
//     org.jfree.chart.block.BlockFrame var18 = var14.getFrame();
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     var21.setForegroundAlpha((-1.0f));
//     var21.setCircular(true, true);
//     java.awt.Paint var27 = var21.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
//     java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     java.awt.Stroke var38 = var37.getBaseSectionOutlineStroke();
//     var37.setShadowXOffset(100.0d);
//     var37.setNoDataMessage("hi!");
//     java.awt.Stroke var43 = var37.getLabelOutlineStroke();
//     var35.setDomainZeroBaselineStroke(var43);
//     java.awt.Paint var45 = var35.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var48 = var47.getValue();
//     org.jfree.chart.util.RectangleInsets var49 = var47.getLabelOffset();
//     java.awt.Stroke var50 = var47.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(0.0d, var27, var30, var45, var50, 0.0f);
//     java.lang.Object var53 = var52.clone();
//     org.jfree.chart.util.RectangleAnchor var54 = var52.getLabelAnchor();
//     var14.setLegendItemGraphicLocation(var54);
//     
//     // Checks the contract:  equals-hashcode on var1 and var37
//     assertTrue("Contract failed: equals-hashcode on var1 and var37", var1.equals(var37) ? var1.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var1
//     assertTrue("Contract failed: equals-hashcode on var37 and var1", var37.equals(var1) ? var37.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.chart.util.VerticalAlignment var17 = var14.getVerticalAlignment();
//     var14.setWidth(0.05d);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     var21.setShadowXOffset(100.0d);
//     var21.setNoDataMessage("hi!");
//     java.awt.Stroke var27 = var21.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var28, (org.jfree.chart.block.Arrangement)var33);
//     org.jfree.chart.event.TitleChangeListener var35 = null;
//     var34.removeChangeListener(var35);
//     org.jfree.chart.util.VerticalAlignment var37 = var34.getVerticalAlignment();
//     java.awt.Font var38 = var34.getItemFont();
//     var14.setItemFont(var38);
//     
//     // Checks the contract:  equals-hashcode on var1 and var21
//     assertTrue("Contract failed: equals-hashcode on var1 and var21", var1.equals(var21) ? var1.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var1
//     assertTrue("Contract failed: equals-hashcode on var21 and var1", var21.equals(var1) ? var21.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var33
//     assertTrue("Contract failed: equals-hashcode on var13 and var33", var13.equals(var33) ? var13.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var13
//     assertTrue("Contract failed: equals-hashcode on var33 and var13", var33.equals(var13) ? var33.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "java.awt.Color[r=0,g=0,b=1]", "hi!", "Pie 3D Plot");

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
    var1.setBaseSectionOutlineStroke(var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getLabelPadding();
    double var9 = var1.getShadowYOffset();
    java.awt.Paint var10 = var1.getLabelLinkPaint();
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
    var12.setShadowXOffset(100.0d);
    var12.setNoDataMessage("hi!");
    java.awt.Stroke var18 = var12.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var12, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var24);
    org.jfree.chart.event.TitleChangeListener var26 = null;
    var25.removeChangeListener(var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.chart.axis.ValueAxis var33 = null;
    int var34 = var32.getDomainAxisIndex(var33);
    var32.setRangeCrosshairValue(10.0d);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    java.awt.geom.Point2D var39 = null;
    var32.zoomDomainAxes(0.0d, var38, var39);
    org.jfree.chart.LegendItemSource[] var41 = new org.jfree.chart.LegendItemSource[] { var32};
    var25.setSources(var41);
    org.jfree.chart.LegendItemSource[] var43 = var25.getSources();
    org.jfree.chart.LegendItemSource[] var44 = var25.getSources();
    java.lang.Object var45 = var25.clone();
    org.jfree.chart.util.RectangleInsets var46 = var25.getLegendItemGraphicPadding();
    org.jfree.chart.plot.ValueMarker var48 = new org.jfree.chart.plot.ValueMarker(0.0d);
    double var49 = var48.getValue();
    org.jfree.chart.util.RectangleInsets var50 = var48.getLabelOffset();
    java.awt.Stroke var51 = var48.getOutlineStroke();
    java.awt.Paint var52 = var48.getLabelPaint();
    var25.setBackgroundPaint(var52);
    var1.setShadowPaint(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var21.getDomainAxisIndex(var22);
//     var21.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var21.zoomDomainAxes(0.0d, var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
//     var14.setSources(var30);
//     var14.setNotify(false);
//     java.lang.String var34 = var14.getID();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     java.awt.Stroke var37 = var36.getBaseSectionOutlineStroke();
//     var36.setShadowXOffset(100.0d);
//     var36.setNoDataMessage("hi!");
//     java.awt.Stroke var42 = var36.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var43 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement(var44, var45, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36, (org.jfree.chart.block.Arrangement)var43, (org.jfree.chart.block.Arrangement)var48);
//     org.jfree.chart.event.TitleChangeListener var50 = null;
//     var49.removeChangeListener(var50);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var52, var53, var54, var55);
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     int var58 = var56.getDomainAxisIndex(var57);
//     var56.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     java.awt.geom.Point2D var63 = null;
//     var56.zoomDomainAxes(0.0d, var62, var63);
//     org.jfree.chart.LegendItemSource[] var65 = new org.jfree.chart.LegendItemSource[] { var56};
//     var49.setSources(var65);
//     org.jfree.chart.LegendItemSource[] var67 = var49.getSources();
//     var14.setSources(var67);
//     
//     // Checks the contract:  equals-hashcode on var1 and var36
//     assertTrue("Contract failed: equals-hashcode on var1 and var36", var1.equals(var36) ? var1.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var1
//     assertTrue("Contract failed: equals-hashcode on var36 and var1", var36.equals(var1) ? var36.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var43
//     assertTrue("Contract failed: equals-hashcode on var8 and var43", var8.equals(var43) ? var8.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var48
//     assertTrue("Contract failed: equals-hashcode on var13 and var48", var13.equals(var48) ? var13.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var8
//     assertTrue("Contract failed: equals-hashcode on var43 and var8", var43.equals(var8) ? var43.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var13
//     assertTrue("Contract failed: equals-hashcode on var48 and var13", var48.equals(var13) ? var48.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var56
//     assertTrue("Contract failed: equals-hashcode on var21 and var56", var21.equals(var56) ? var21.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var21
//     assertTrue("Contract failed: equals-hashcode on var56 and var21", var56.equals(var21) ? var56.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.025d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    var8.clearRangeAxes();
    var8.clearDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     int var15 = var4.getDatasetCount();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setPieIndex(100);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     var17.setBaseSectionOutlineStroke(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var17.getLabelPadding();
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var28 = var27.getColorSpace();
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
//     org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var24, (java.awt.Paint)var27);
//     var4.setDomainZeroBaselinePaint((java.awt.Paint)var27);
//     var4.mapDatasetToRangeAxis(0, 1);
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setPieIndex(100);
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     java.awt.Stroke var43 = var42.getBaseSectionOutlineStroke();
//     var38.setBaseSectionOutlineStroke(var43);
//     org.jfree.chart.util.RectangleInsets var45 = var38.getLabelPadding();
//     var36.setTickLabelInsets(var45);
//     org.jfree.data.Range var47 = null;
//     org.jfree.data.Range var49 = org.jfree.data.Range.expandToInclude(var47, 0.0d);
//     double var50 = var49.getLength();
//     org.jfree.data.Range var51 = null;
//     org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 0.0d);
//     org.jfree.data.Range var54 = org.jfree.data.Range.combine(var49, var53);
//     var36.setRange(var54, true, true);
//     var4.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis)var36, true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var38
//     assertTrue("Contract failed: equals-hashcode on var17 and var38", var17.equals(var38) ? var17.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var42
//     assertTrue("Contract failed: equals-hashcode on var21 and var42", var21.equals(var42) ? var21.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var17
//     assertTrue("Contract failed: equals-hashcode on var38 and var17", var38.equals(var17) ? var38.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var21
//     assertTrue("Contract failed: equals-hashcode on var42 and var21", var42.equals(var21) ? var42.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setPieIndex(100);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var2.handleClick(100, 1, var7);
//     org.jfree.chart.util.RectangleInsets var9 = var2.getInsets();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
//     java.awt.Font var13 = var11.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     var14.removeLegend();
//     var2.addChangeListener((org.jfree.chart.event.PlotChangeListener)var14);
//     org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(short)1, var14, 100, (-16777216));
//     org.jfree.chart.JFreeChart var20 = var19.getChart();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     var22.setPieIndex(100);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     var22.handleClick(100, 1, var27);
//     org.jfree.chart.util.RectangleInsets var29 = var22.getInsets();
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     java.awt.Stroke var32 = var31.getBaseSectionOutlineStroke();
//     java.awt.Font var33 = var31.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
//     var34.removeLegend();
//     var22.addChangeListener((org.jfree.chart.event.PlotChangeListener)var34);
//     var34.setAntiAlias(true);
//     java.lang.Object var39 = var34.getTextAntiAlias();
//     float var40 = var34.getBackgroundImageAlpha();
//     var19.setChart(var34);
//     
//     // Checks the contract:  equals-hashcode on var2 and var22
//     assertTrue("Contract failed: equals-hashcode on var2 and var22", var2.equals(var22) ? var2.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var31
//     assertTrue("Contract failed: equals-hashcode on var11 and var31", var11.equals(var31) ? var11.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var2
//     assertTrue("Contract failed: equals-hashcode on var22 and var2", var22.equals(var2) ? var22.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var11
//     assertTrue("Contract failed: equals-hashcode on var31 and var11", var31.equals(var11) ? var31.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var34
//     assertTrue("Contract failed: equals-hashcode on var14 and var34", var14.equals(var34) ? var14.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var34
//     assertTrue("Contract failed: equals-hashcode on var20 and var34", var20.equals(var34) ? var20.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var14
//     assertTrue("Contract failed: equals-hashcode on var34 and var14", var34.equals(var14) ? var34.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var20
//     assertTrue("Contract failed: equals-hashcode on var34 and var20", var34.equals(var20) ? var34.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     var4.setRenderer(var16);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     var24.setShadowXOffset(100.0d);
//     var24.setNoDataMessage("hi!");
//     java.awt.Stroke var30 = var24.getLabelOutlineStroke();
//     var22.setDomainZeroBaselineStroke(var30);
//     java.awt.Paint var32 = var22.getDomainGridlinePaint();
//     var22.clearRangeAxes();
//     org.jfree.chart.plot.PolarPlot var34 = new org.jfree.chart.plot.PolarPlot();
//     var34.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var36 = var34.getLegendItems();
//     var22.setFixedLegendItems(var36);
//     var4.setFixedLegendItems(var36);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var4
//     assertTrue("Contract failed: equals-hashcode on var22 and var4", var22.equals(var4) ? var22.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var24
//     assertTrue("Contract failed: equals-hashcode on var6 and var24", var6.equals(var24) ? var6.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var6
//     assertTrue("Contract failed: equals-hashcode on var24 and var6", var24.equals(var6) ? var24.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setPieIndex(100);
//     double var4 = var1.getLabelLinkMargin();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Stroke var8 = var7.getBaseSectionOutlineStroke();
//     var7.setShadowXOffset(100.0d);
//     var7.setNoDataMessage("hi!");
//     java.awt.Stroke var13 = var7.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var14, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.event.TitleChangeListener var21 = null;
//     var20.removeChangeListener(var21);
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     int var29 = var27.getDomainAxisIndex(var28);
//     var27.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var27.zoomDomainAxes(0.0d, var33, var34);
//     org.jfree.chart.LegendItemSource[] var36 = new org.jfree.chart.LegendItemSource[] { var27};
//     var20.setSources(var36);
//     org.jfree.chart.LegendItemSource[] var38 = var20.getSources();
//     org.jfree.chart.LegendItemSource[] var39 = var20.getSources();
//     java.lang.Object var40 = var20.clone();
//     java.awt.geom.Rectangle2D var41 = var20.getBounds();
//     var1.drawOutline(var5, var41);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setPieIndex(100);
//     double var4 = var1.getLabelLinkMargin();
//     org.jfree.data.general.DatasetGroup var5 = var1.getDatasetGroup();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.block.LineBorder var7 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var8 = var7.getPaint();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
//     java.awt.Font var13 = var11.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
//     var14.removeLegend();
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
//     var14.setBorderPaint((java.awt.Paint)var18);
//     org.jfree.chart.util.RectangleInsets var20 = var14.getPadding();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var29, (org.jfree.chart.block.Arrangement)var34);
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var35.removeChangeListener(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     int var44 = var42.getDomainAxisIndex(var43);
//     var42.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     java.awt.geom.Point2D var49 = null;
//     var42.zoomDomainAxes(0.0d, var48, var49);
//     org.jfree.chart.LegendItemSource[] var51 = new org.jfree.chart.LegendItemSource[] { var42};
//     var35.setSources(var51);
//     org.jfree.chart.LegendItemSource[] var53 = var35.getSources();
//     org.jfree.chart.LegendItemSource[] var54 = var35.getSources();
//     java.lang.Object var55 = var35.clone();
//     java.awt.geom.Rectangle2D var56 = var35.getBounds();
//     org.jfree.chart.entity.ChartEntity var58 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var56, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var61 = var20.createInsetRectangle(var56, false, false);
//     var7.draw(var9, var61);
//     var1.drawOutline(var6, var61);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     java.awt.Paint var16 = var4.getRangeTickBandPaint();
//     org.jfree.chart.util.RectangleInsets var17 = var4.getInsets();
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var22 = var21.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var23 = null;
//     var21.setMarkerBand(var23);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var25);
//     org.jfree.chart.util.Layer var28 = null;
//     java.util.Collection var29 = var26.getDomainMarkers(1, var28);
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var26.addRangeMarker((org.jfree.chart.plot.Marker)var31);
//     java.lang.String var33 = var26.getPlotType();
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     java.util.List var35 = var26.getCategoriesForAxis(var34);
//     var26.setRangeCrosshairVisible(false);
//     var26.clearAnnotations();
//     org.jfree.chart.util.Layer var39 = null;
//     java.util.Collection var40 = var26.getRangeMarkers(var39);
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
//     org.jfree.chart.axis.AxisSpace var46 = var45.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotOrientation var47 = var45.getOrientation();
//     var26.setOrientation(var47);
//     var4.setOrientation(var47);
//     
//     // Checks the contract:  equals-hashcode on var4 and var45
//     assertTrue("Contract failed: equals-hashcode on var4 and var45", var4.equals(var45) ? var4.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var4
//     assertTrue("Contract failed: equals-hashcode on var45 and var4", var45.equals(var4) ? var45.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.util.List var5 = var4.getSubtitles();
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var10 = var9.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var11 = null;
//     var9.setMarkerBand(var11);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var13);
//     org.jfree.chart.util.Layer var16 = null;
//     java.util.Collection var17 = var14.getDomainMarkers(1, var16);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var14.addRangeMarker((org.jfree.chart.plot.Marker)var19);
//     java.lang.String var21 = var14.getPlotType();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     java.util.List var23 = var14.getCategoriesForAxis(var22);
//     var4.setSubtitles(var23);
//     org.jfree.chart.title.LegendTitle var26 = var4.getLegend(1);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     java.awt.Stroke var29 = var28.getBaseSectionOutlineStroke();
//     java.awt.Font var30 = var28.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     org.jfree.chart.util.RectangleInsets var32 = var31.getPadding();
//     var4.setPadding(var32);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var21);
//     java.awt.Stroke var23 = var13.getRangeGridlineStroke();
//     var8.setRangeGridlineStroke(var23);
//     int var25 = var8.getDomainAxisCount();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var8.setRenderer(1, var27, false);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var34 = var33.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var35 = null;
//     var33.setMarkerBand(var35);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var30, var31, (org.jfree.chart.axis.ValueAxis)var33, var37);
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var38.getDomainMarkers(1, var40);
//     org.jfree.chart.axis.CategoryAnchor var42 = var38.getDomainGridlinePosition();
//     var8.setDomainGridlinePosition(var42);
//     
//     // Checks the contract:  equals-hashcode on var8 and var38
//     assertTrue("Contract failed: equals-hashcode on var8 and var38", var8.equals(var38) ? var8.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var8
//     assertTrue("Contract failed: equals-hashcode on var38 and var8", var38.equals(var8) ? var38.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
//     java.awt.Font var10 = var8.getNoDataMessageFont();
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var14 = var13.getColorSpace();
//     java.awt.Color var15 = var13.darker();
//     org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var10, (java.awt.Paint)var13);
//     var4.setDomainCrosshairPaint((java.awt.Paint)var13);
//     java.awt.Stroke var18 = var4.getDomainZeroBaselineStroke();
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     var25.setShadowXOffset(100.0d);
//     var25.setNoDataMessage("hi!");
//     java.awt.Stroke var31 = var25.getLabelOutlineStroke();
//     var23.setDomainZeroBaselineStroke(var31);
//     java.awt.Paint var33 = var23.getDomainGridlinePaint();
//     var23.clearRangeAxes();
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     boolean var41 = var40.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot(var43);
//     java.awt.Stroke var45 = var44.getBaseSectionOutlineStroke();
//     java.awt.Font var46 = var44.getNoDataMessageFont();
//     java.awt.Color var49 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var50 = var49.getColorSpace();
//     java.awt.Color var51 = var49.darker();
//     org.jfree.chart.text.TextFragment var52 = new org.jfree.chart.text.TextFragment("", var46, (java.awt.Paint)var49);
//     var40.setDomainCrosshairPaint((java.awt.Paint)var49);
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     var40.setFixedDomainAxisSpace(var54, false);
//     org.jfree.chart.axis.AxisLocation var58 = var40.getRangeAxisLocation((-16777215));
//     var23.setDomainAxisLocation(100, var58, false);
//     var4.setDomainAxisLocation(var58);
//     
//     // Checks the contract:  equals-hashcode on var8 and var44
//     assertTrue("Contract failed: equals-hashcode on var8 and var44", var8.equals(var44) ? var8.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var8
//     assertTrue("Contract failed: equals-hashcode on var44 and var8", var44.equals(var8) ? var44.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var21);
//     java.awt.Stroke var23 = var13.getRangeGridlineStroke();
//     var8.setRangeGridlineStroke(var23);
//     int var25 = var8.getDomainAxisCount();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var8.setRenderer(1, var27, false);
//     org.jfree.chart.plot.DrawingSupplier var30 = var8.getDrawingSupplier();
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     java.awt.Paint var37 = var36.getRangeTickBandPaint();
//     org.jfree.data.xy.XYDataset var38 = null;
//     int var39 = var36.indexOf(var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
//     var46.setShadowXOffset(100.0d);
//     var46.setNoDataMessage("hi!");
//     java.awt.Stroke var52 = var46.getLabelOutlineStroke();
//     var44.setDomainZeroBaselineStroke(var52);
//     java.awt.Paint var54 = var44.getDomainGridlinePaint();
//     java.awt.Paint var55 = var44.getDomainZeroBaselinePaint();
//     var44.clearRangeMarkers(0);
//     java.awt.Stroke var58 = var44.getRangeGridlineStroke();
//     var44.setDomainCrosshairValue((-1.0d), false);
//     org.jfree.chart.axis.AxisLocation var63 = var44.getDomainAxisLocation(15);
//     var36.setRangeAxisLocation(var63);
//     var8.setDomainAxisLocation(0, var63);
//     
//     // Checks the contract:  equals-hashcode on var15 and var46
//     assertTrue("Contract failed: equals-hashcode on var15 and var46", var15.equals(var46) ? var15.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var15
//     assertTrue("Contract failed: equals-hashcode on var46 and var15", var46.equals(var15) ? var46.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.util.RectangleEdge var15 = var8.getRangeAxisEdge();
//     var8.clearRangeMarkers();
//     java.lang.Object var17 = var8.clone();
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var20 = var19.getValue();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     java.awt.Font var26 = var24.getNoDataMessageFont();
//     java.awt.Color var29 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var30 = var29.getColorSpace();
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var26, (java.awt.Paint)var29);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var34 = var33.getValue();
//     org.jfree.chart.util.RectangleInsets var35 = var33.getLabelOffset();
//     java.awt.Stroke var36 = var33.getOutlineStroke();
//     java.awt.Paint var37 = var33.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var40 = null;
//     org.jfree.chart.text.TextBlock var41 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, var37, 0.0f, 1, var40);
//     var19.setLabelFont(var26);
//     var19.setLabel("ChartEntity: tooltip = hi!");
//     boolean var45 = var8.removeDomainMarker((org.jfree.chart.plot.Marker)var19);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    java.lang.String var15 = var8.getPlotType();
    org.jfree.chart.axis.CategoryAxis var16 = null;
    java.util.List var17 = var8.getCategoriesForAxis(var16);
    var8.setDomainGridlinesVisible(true);
    org.jfree.chart.plot.CategoryMarker var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Category Plot"+ "'", var15.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     var2.setShadowXOffset(100.0d);
//     var2.setNoDataMessage("hi!");
//     java.awt.Stroke var8 = var2.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, (org.jfree.chart.block.Arrangement)var9, (org.jfree.chart.block.Arrangement)var14);
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var15.removeChangeListener(var16);
//     org.jfree.chart.util.VerticalAlignment var18 = var15.getVerticalAlignment();
//     java.awt.Font var19 = var15.getItemFont();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("", var19);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     java.awt.Font var25 = var23.getNoDataMessageFont();
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var29 = var28.getColorSpace();
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var25, (java.awt.Paint)var28);
//     org.jfree.chart.block.BlockContainer var31 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var36 = var35.getHeightRange();
//     org.jfree.chart.util.Size2D var37 = var31.arrange(var32, var35);
//     boolean var38 = var30.equals((java.lang.Object)var35);
//     java.awt.Color var41 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var42 = var41.getColorSpace();
//     java.awt.Color var43 = var41.darker();
//     boolean var44 = var30.equals((java.lang.Object)var43);
//     var20.setBackgroundPaint((java.awt.Paint)var43);
//     java.awt.Font var46 = var20.getFont();
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot(var48);
//     java.awt.Stroke var50 = var49.getBaseSectionOutlineStroke();
//     var49.setShadowXOffset(100.0d);
//     var49.setNoDataMessage("hi!");
//     java.awt.Stroke var55 = var49.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49, (org.jfree.chart.block.Arrangement)var56, (org.jfree.chart.block.Arrangement)var61);
//     org.jfree.chart.event.TitleChangeListener var63 = null;
//     var62.removeChangeListener(var63);
//     org.jfree.chart.util.VerticalAlignment var65 = var62.getVerticalAlignment();
//     java.awt.Font var66 = var62.getItemFont();
//     org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle("", var66);
//     org.jfree.chart.util.HorizontalAlignment var68 = var67.getHorizontalAlignment();
//     var20.setTextAlignment(var68);
//     
//     // Checks the contract:  equals-hashcode on var2 and var49
//     assertTrue("Contract failed: equals-hashcode on var2 and var49", var2.equals(var49) ? var2.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var2
//     assertTrue("Contract failed: equals-hashcode on var49 and var2", var49.equals(var2) ? var49.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var56
//     assertTrue("Contract failed: equals-hashcode on var9 and var56", var9.equals(var56) ? var9.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var61
//     assertTrue("Contract failed: equals-hashcode on var14 and var61", var14.equals(var61) ? var14.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var9
//     assertTrue("Contract failed: equals-hashcode on var56 and var9", var56.equals(var9) ? var56.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var14
//     assertTrue("Contract failed: equals-hashcode on var61 and var14", var61.equals(var14) ? var61.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("java.awt.Color[r=0,g=0,b=1]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers((-1), var10);
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    java.awt.Stroke var14 = var13.getBaseSectionOutlineStroke();
    var13.setShadowXOffset(100.0d);
    var13.setNoDataMessage("hi!");
    double var19 = var13.getShadowXOffset();
    var13.setBackgroundAlpha((-1.0f));
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
    var24.setPieIndex(100);
    double var27 = var24.getLabelLinkMargin();
    double var28 = var24.getShadowXOffset();
    java.awt.Color var31 = java.awt.Color.getColor("hi!", 1);
    int var32 = var31.getRed();
    var24.setShadowPaint((java.awt.Paint)var31);
    var13.setSectionOutlinePaint((java.lang.Comparable)3.0d, (java.awt.Paint)var31);
    var8.setRangeGridlinePaint((java.awt.Paint)var31);
    org.jfree.chart.annotations.CategoryAnnotation var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addAnnotation(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    var4.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
    var19.setTickLabelsVisible(true);
    var19.setLowerBound(1.0d);
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var19};
    var4.setDomainAxes(var24);
    org.jfree.chart.plot.DatasetRenderingOrder var26 = var4.getDatasetRenderingOrder();
    var4.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var21.getDomainAxisIndex(var22);
//     var21.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var21.zoomDomainAxes(0.0d, var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
//     var14.setSources(var30);
//     org.jfree.chart.LegendItemSource[] var32 = var14.getSources();
//     org.jfree.chart.LegendItemSource[] var33 = var14.getSources();
//     java.lang.Object var34 = var14.clone();
//     java.awt.geom.Rectangle2D var35 = var14.getBounds();
//     org.jfree.chart.entity.ChartEntity var37 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var35, "ChartChangeEventType.GENERAL");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var38 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var39 = null;
//     java.lang.String var40 = var37.getImageMapAreaTag(var38, var39);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
    org.jfree.chart.util.RectangleInsets var16 = var14.getLegendItemGraphicPadding();
    java.awt.Font var17 = var14.getItemFont();
    org.jfree.chart.util.RectangleEdge var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setPosition(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(-16777216));
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.chart.util.VerticalAlignment var17 = var14.getVerticalAlignment();
//     var14.setWidth(0.05d);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     var22.setPieIndex(100);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     var22.setBaseSectionOutlineStroke(var27);
//     org.jfree.chart.util.RectangleInsets var29 = var22.getLabelPadding();
//     var20.setTickLabelInsets(var29);
//     var14.setItemLabelPadding(var29);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     var33.setShadowXOffset(100.0d);
//     var33.setNoDataMessage("hi!");
//     java.awt.Stroke var39 = var33.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var40 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var41 = null;
//     org.jfree.chart.util.VerticalAlignment var42 = null;
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var45);
//     org.jfree.chart.event.TitleChangeListener var47 = null;
//     var46.removeChangeListener(var47);
//     org.jfree.data.xy.XYDataset var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var52 = null;
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot(var49, var50, var51, var52);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     int var55 = var53.getDomainAxisIndex(var54);
//     var53.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     java.awt.geom.Point2D var60 = null;
//     var53.zoomDomainAxes(0.0d, var59, var60);
//     org.jfree.chart.LegendItemSource[] var62 = new org.jfree.chart.LegendItemSource[] { var53};
//     var46.setSources(var62);
//     org.jfree.chart.LegendItemSource[] var64 = var46.getSources();
//     org.jfree.chart.LegendItemSource[] var65 = var46.getSources();
//     java.lang.Object var66 = var46.clone();
//     java.awt.geom.Rectangle2D var67 = var46.getBounds();
//     org.jfree.chart.entity.ChartEntity var69 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var67, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var72 = var29.createInsetRectangle(var67, true, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var40
//     assertTrue("Contract failed: equals-hashcode on var8 and var40", var8.equals(var40) ? var8.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var45
//     assertTrue("Contract failed: equals-hashcode on var13 and var45", var13.equals(var45) ? var13.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var8
//     assertTrue("Contract failed: equals-hashcode on var40 and var8", var40.equals(var8) ? var40.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var13
//     assertTrue("Contract failed: equals-hashcode on var45 and var13", var45.equals(var13) ? var45.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    var2.setPieIndex(100);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var2.setBaseSectionOutlineStroke(var7);
    org.jfree.chart.util.RectangleInsets var9 = var2.getLabelPadding();
    var0.setTickLabelInsets(var9);
    float var11 = var0.getTickMarkOutsideLength();
    java.util.Date var12 = var0.getMaximumDate();
    org.jfree.chart.axis.DateTickMarkPosition var13 = var0.getTickMarkPosition();
    var0.setTickMarkInsideLength(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
//     java.lang.String var15 = var8.getPlotType();
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     java.util.List var17 = var8.getCategoriesForAxis(var16);
//     var8.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var21 = var20.getTickLabelPaint();
//     int var22 = var8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var20);
//     org.jfree.chart.util.RectangleInsets var23 = var8.getAxisOffset();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var28 = var27.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var29 = null;
//     var27.setMarkerBand(var29);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var27, var31);
//     org.jfree.chart.util.Layer var34 = null;
//     java.util.Collection var35 = var32.getDomainMarkers(1, var34);
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     var32.setDomainAxis(1, var37, false);
//     var32.setAnchorValue((-1.0d), true);
//     boolean var43 = var32.isRangeCrosshairLockedOnData();
//     var32.setDomainGridlinesVisible(true);
//     java.util.List var46 = var32.getAnnotations();
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     java.awt.Paint var52 = var51.getRangeTickBandPaint();
//     java.awt.Image var53 = var51.getBackgroundImage();
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis var55 = null;
//     org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var58 = var57.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var59 = null;
//     var57.setMarkerBand(var59);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var54, var55, (org.jfree.chart.axis.ValueAxis)var57, var61);
//     org.jfree.chart.util.Layer var64 = null;
//     java.util.Collection var65 = var62.getDomainMarkers(1, var64);
//     org.jfree.chart.plot.ValueMarker var67 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var62.addRangeMarker((org.jfree.chart.plot.Marker)var67);
//     java.awt.Stroke var69 = var67.getOutlineStroke();
//     var51.setDomainZeroBaselineStroke(var69);
//     var32.setRangeGridlineStroke(var69);
//     var8.setRangeCrosshairStroke(var69);
//     
//     // Checks the contract:  equals-hashcode on var13 and var67
//     assertTrue("Contract failed: equals-hashcode on var13 and var67", var13.equals(var67) ? var13.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var13
//     assertTrue("Contract failed: equals-hashcode on var67 and var13", var67.equals(var13) ? var67.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    var0.clear();

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(100, 1, var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getInsets();
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
    java.awt.Font var12 = var10.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var13.removeLegend();
    var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var13);
    java.awt.Color var18 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var19 = var18.getColorSpace();
    java.lang.String var20 = var18.toString();
    var1.setOutlinePaint((java.awt.Paint)var18);
    float[] var22 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var23 = var18.getComponents(var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var20.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     var19.setShadowXOffset(100.0d);
//     var19.setNoDataMessage("hi!");
//     java.awt.Stroke var25 = var19.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19, (org.jfree.chart.block.Arrangement)var26, (org.jfree.chart.block.Arrangement)var31);
//     org.jfree.chart.event.TitleChangeListener var33 = null;
//     var32.removeChangeListener(var33);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     int var41 = var39.getDomainAxisIndex(var40);
//     var39.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var39.zoomDomainAxes(0.0d, var45, var46);
//     org.jfree.chart.LegendItemSource[] var48 = new org.jfree.chart.LegendItemSource[] { var39};
//     var32.setSources(var48);
//     org.jfree.chart.LegendItemSource[] var50 = var32.getSources();
//     org.jfree.chart.LegendItemSource[] var51 = var32.getSources();
//     java.lang.Object var52 = var32.clone();
//     java.awt.geom.Rectangle2D var53 = var32.getBounds();
//     org.jfree.chart.entity.ChartEntity var55 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var53, "ChartChangeEventType.GENERAL");
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var56, var57, var58, var59);
//     org.jfree.chart.axis.AxisSpace var61 = var60.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.NumberAxis3D var63 = new org.jfree.chart.axis.NumberAxis3D("");
//     var63.setTickLabelsVisible(true);
//     int var66 = var60.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var63);
//     java.lang.Object var67 = var14.draw(var17, var53, (java.lang.Object)var60);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
//     java.awt.Image var7 = null;
//     var5.setBackgroundImage(var7);
//     var0.setPieChart(var5);
//     org.jfree.chart.JFreeChart var10 = var0.getPieChart();
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     boolean var16 = var15.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     java.awt.Font var21 = var19.getNoDataMessageFont();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var25 = var24.getColorSpace();
//     java.awt.Color var26 = var24.darker();
//     org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("", var21, (java.awt.Paint)var24);
//     var15.setDomainCrosshairPaint((java.awt.Paint)var24);
//     java.awt.color.ColorSpace var29 = var24.getColorSpace();
//     java.awt.Color var30 = var24.brighter();
//     var0.setAggregatedItemsPaint((java.awt.Paint)var30);
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.AxisLocation var7 = var4.getRangeAxisLocation(100);
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var10 = var9.getValue();
//     org.jfree.chart.util.RectangleInsets var11 = var9.getLabelOffset();
//     java.awt.Stroke var12 = var9.getOutlineStroke();
//     java.awt.Font var13 = var9.getLabelFont();
//     org.jfree.chart.util.Layer var14 = null;
//     boolean var15 = var4.removeDomainMarker((org.jfree.chart.plot.Marker)var9, var14);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getLegendItemGraphicPadding();
//     java.lang.Object var17 = var14.clone();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var20.setShadowXOffset(100.0d);
//     var20.setNoDataMessage("hi!");
//     java.awt.Stroke var26 = var20.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement(var28, var29, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20, (org.jfree.chart.block.Arrangement)var27, (org.jfree.chart.block.Arrangement)var32);
//     org.jfree.chart.event.TitleChangeListener var34 = null;
//     var33.removeChangeListener(var34);
//     org.jfree.chart.util.VerticalAlignment var36 = var33.getVerticalAlignment();
//     java.awt.Font var37 = var33.getItemFont();
//     org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("", var37);
//     org.jfree.chart.util.HorizontalAlignment var39 = var38.getHorizontalAlignment();
//     var14.setHorizontalAlignment(var39);
//     
//     // Checks the contract:  equals-hashcode on var1 and var20
//     assertTrue("Contract failed: equals-hashcode on var1 and var20", var1.equals(var20) ? var1.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var1
//     assertTrue("Contract failed: equals-hashcode on var20 and var1", var20.equals(var1) ? var20.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var27
//     assertTrue("Contract failed: equals-hashcode on var8 and var27", var8.equals(var27) ? var8.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var32
//     assertTrue("Contract failed: equals-hashcode on var13 and var32", var13.equals(var32) ? var13.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var8
//     assertTrue("Contract failed: equals-hashcode on var27 and var8", var27.equals(var8) ? var27.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var13
//     assertTrue("Contract failed: equals-hashcode on var32 and var13", var32.equals(var13) ? var32.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    java.lang.String var15 = var8.getPlotType();
    org.jfree.chart.axis.CategoryAxis var16 = null;
    java.util.List var17 = var8.getCategoriesForAxis(var16);
    var8.setRangeCrosshairVisible(false);
    var8.clearAnnotations();
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var8.getRangeMarkers(var21);
    org.jfree.chart.util.SortOrder var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setColumnRenderingOrder(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Category Plot"+ "'", var15.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateDimensions(var3);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setTickLabelsVisible(true);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var6 = var5.getRangeType();
    var1.setRangeType(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    var2.setPieIndex(100);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var2.setBaseSectionOutlineStroke(var7);
    org.jfree.chart.util.RectangleInsets var9 = var2.getLabelPadding();
    var0.setTickLabelInsets(var9);
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
    double var14 = var13.getLength();
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
    org.jfree.data.Range var18 = org.jfree.data.Range.combine(var13, var17);
    var0.setRange(var18, true, true);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var23 = var22.getTimeline();
    java.util.Date var24 = var22.getMaximumDate();
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var26 = var25.getTimeline();
    java.util.Date var27 = var25.getMaximumDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var24, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setForegroundAlpha((-1.0f));
//     var1.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.ChartChangeEventType var8 = null;
//     var7.setType(var8);
//     java.lang.String var10 = var7.toString();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
//     var7.setChart(var15);
//     var15.setBorderVisible(true);
//     java.awt.Stroke var20 = var15.getBorderStroke();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var29, (org.jfree.chart.block.Arrangement)var34);
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var35.removeChangeListener(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     int var44 = var42.getDomainAxisIndex(var43);
//     var42.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     java.awt.geom.Point2D var49 = null;
//     var42.zoomDomainAxes(0.0d, var48, var49);
//     org.jfree.chart.LegendItemSource[] var51 = new org.jfree.chart.LegendItemSource[] { var42};
//     var35.setSources(var51);
//     org.jfree.chart.LegendItemSource[] var53 = var35.getSources();
//     org.jfree.chart.LegendItemSource[] var54 = var35.getSources();
//     java.lang.Object var55 = var35.clone();
//     var15.addSubtitle((org.jfree.chart.title.Title)var35);
//     org.jfree.chart.util.RectangleInsets var57 = var35.getPadding();
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var58, var59, var60, var61);
//     org.jfree.data.general.PieDataset var63 = null;
//     org.jfree.chart.plot.PiePlot var64 = new org.jfree.chart.plot.PiePlot(var63);
//     java.awt.Stroke var65 = var64.getBaseSectionOutlineStroke();
//     var64.setShadowXOffset(100.0d);
//     var64.setNoDataMessage("hi!");
//     java.awt.Stroke var70 = var64.getLabelOutlineStroke();
//     var62.setDomainZeroBaselineStroke(var70);
//     java.awt.Paint var72 = var62.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var74 = var62.getRangeAxisEdge(1);
//     var35.setLegendItemGraphicEdge(var74);
//     
//     // Checks the contract:  equals-hashcode on var22 and var64
//     assertTrue("Contract failed: equals-hashcode on var22 and var64", var22.equals(var64) ? var22.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var22
//     assertTrue("Contract failed: equals-hashcode on var64 and var22", var64.equals(var22) ? var64.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.0d, 4.0d, 0.14d, 4.00000001d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers((-1), var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     var16.setDomainZeroBaselineStroke(var24);
//     java.awt.Paint var26 = var16.getDomainGridlinePaint();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var31 = var30.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var32 = null;
//     var30.setMarkerBand(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var30, var34);
//     org.jfree.chart.util.Layer var37 = null;
//     java.util.Collection var38 = var35.getDomainMarkers(1, var37);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var35.addRangeMarker((org.jfree.chart.plot.Marker)var40);
//     org.jfree.chart.axis.AxisLocation var42 = var35.getRangeAxisLocation();
//     var16.setDomainAxisLocation(var42);
//     var8.setDomainAxisLocation(var42, true);
//     org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.RectangleConstraint var50 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var51 = var50.getHeightRange();
//     boolean var52 = var47.equals((java.lang.Object)var50);
//     org.jfree.chart.block.BlockContainer var53 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var54 = null;
//     org.jfree.chart.block.RectangleConstraint var57 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var58 = var57.getHeightRange();
//     org.jfree.chart.util.Size2D var59 = var53.arrange(var54, var57);
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot var61 = new org.jfree.chart.plot.PiePlot(var60);
//     var61.setForegroundAlpha((-1.0f));
//     var61.setCircular(true, true);
//     java.awt.Paint var67 = var61.getLabelShadowPaint();
//     var47.add((org.jfree.chart.block.Block)var53, (java.lang.Object)var67);
//     org.jfree.chart.block.BlockContainer var69 = new org.jfree.chart.block.BlockContainer();
//     var69.setPadding(0.0d, 3.0d, (-1.0d), 0.025d);
//     org.jfree.chart.axis.DateAxis var75 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var76 = var75.getTimeline();
//     boolean var77 = var69.equals((java.lang.Object)var75);
//     org.jfree.data.xy.XYDataset var78 = null;
//     org.jfree.chart.axis.ValueAxis var79 = null;
//     org.jfree.chart.axis.ValueAxis var80 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var81 = null;
//     org.jfree.chart.plot.XYPlot var82 = new org.jfree.chart.plot.XYPlot(var78, var79, var80, var81);
//     org.jfree.data.general.PieDataset var83 = null;
//     org.jfree.chart.plot.PiePlot var84 = new org.jfree.chart.plot.PiePlot(var83);
//     java.awt.Stroke var85 = var84.getBaseSectionOutlineStroke();
//     var84.setShadowXOffset(100.0d);
//     var84.setNoDataMessage("hi!");
//     java.awt.Stroke var90 = var84.getLabelOutlineStroke();
//     var82.setDomainZeroBaselineStroke(var90);
//     var47.add((org.jfree.chart.block.Block)var69, (java.lang.Object)var90);
//     org.jfree.chart.title.LegendTitle var93 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var8, (org.jfree.chart.block.Arrangement)var46, (org.jfree.chart.block.Arrangement)var47);
//     
//     // Checks the contract:  equals-hashcode on var18 and var84
//     assertTrue("Contract failed: equals-hashcode on var18 and var84", var18.equals(var84) ? var18.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var18
//     assertTrue("Contract failed: equals-hashcode on var84 and var18", var84.equals(var18) ? var84.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.Range var9 = null;
//     org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
//     var3.setRange(var11, false, false);
//     var3.setPositiveArrowVisible(true);
//     var3.setLabelToolTip("");
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.AttributedString var22 = var20.getAttributedLabel(0);
//     java.text.NumberFormat var23 = var20.getNumberFormat();
//     var3.setNumberFormatOverride(var23);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var26 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.AttributedString var28 = var26.getAttributedLabel(0);
//     java.text.NumberFormat var29 = var26.getNumberFormat();
//     var3.setNumberFormatOverride(var29);
//     
//     // Checks the contract:  equals-hashcode on var20 and var26
//     assertTrue("Contract failed: equals-hashcode on var20 and var26", var20.equals(var26) ? var20.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var20
//     assertTrue("Contract failed: equals-hashcode on var26 and var20", var26.equals(var20) ? var26.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     var4.clearRangeAxes();
//     var4.clearDomainMarkers();
//     org.jfree.chart.plot.DatasetRenderingOrder var17 = var4.getDatasetRenderingOrder();
//     var4.configureDomainAxes();
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Stroke var26 = var25.getBaseSectionOutlineStroke();
//     var25.setShadowXOffset(100.0d);
//     var25.setNoDataMessage("hi!");
//     java.awt.Stroke var31 = var25.getLabelOutlineStroke();
//     var23.setDomainZeroBaselineStroke(var31);
//     java.awt.Paint var33 = var23.getDomainGridlinePaint();
//     java.awt.Paint var34 = var23.getDomainZeroBaselinePaint();
//     var23.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D("");
//     var38.setTickLabelsVisible(true);
//     var38.setLowerBound(1.0d);
//     org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var38};
//     var23.setDomainAxes(var43);
//     var4.setRangeAxes(var43);
//     
//     // Checks the contract:  equals-hashcode on var6 and var25
//     assertTrue("Contract failed: equals-hashcode on var6 and var25", var6.equals(var25) ? var6.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var6
//     assertTrue("Contract failed: equals-hashcode on var25 and var6", var25.equals(var6) ? var25.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.axis.CategoryAxis var13 = null;
//     var8.setDomainAxis(1, var13, false);
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     var20.setDomainZeroBaselineStroke(var28);
//     java.awt.Paint var30 = var20.getDomainGridlinePaint();
//     java.awt.Paint var31 = var20.getDomainZeroBaselinePaint();
//     java.awt.Paint var32 = var20.getRangeTickBandPaint();
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis var34 = null;
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var37 = var36.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var38 = null;
//     var36.setMarkerBand(var38);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var33, var34, (org.jfree.chart.axis.ValueAxis)var36, var40);
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     org.jfree.chart.axis.NumberAxis3D var46 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var47 = var46.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var48 = null;
//     var46.setMarkerBand(var48);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var43, var44, (org.jfree.chart.axis.ValueAxis)var46, var50);
//     org.jfree.chart.util.Layer var53 = null;
//     java.util.Collection var54 = var51.getDomainMarkers(1, var53);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var51.addRangeMarker((org.jfree.chart.plot.Marker)var56);
//     org.jfree.chart.axis.AxisLocation var58 = var51.getRangeAxisLocation();
//     var41.setRangeAxisLocation(0, var58);
//     var20.setDomainAxisLocation(var58);
//     var8.setRangeAxisLocation(var58, false);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var14.removeChangeListener(var15);
    org.jfree.chart.util.VerticalAlignment var17 = var14.getVerticalAlignment();
    org.jfree.chart.util.HorizontalAlignment var18 = var14.getHorizontalAlignment();
    double var19 = var14.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
//     java.awt.Font var6 = var4.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     var7.removeLegend();
//     java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
//     var7.setBorderPaint((java.awt.Paint)var11);
//     org.jfree.chart.util.RectangleInsets var13 = var7.getPadding();
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15, (org.jfree.chart.block.Arrangement)var22, (org.jfree.chart.block.Arrangement)var27);
//     org.jfree.chart.event.TitleChangeListener var29 = null;
//     var28.removeChangeListener(var29);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     int var37 = var35.getDomainAxisIndex(var36);
//     var35.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     java.awt.geom.Point2D var42 = null;
//     var35.zoomDomainAxes(0.0d, var41, var42);
//     org.jfree.chart.LegendItemSource[] var44 = new org.jfree.chart.LegendItemSource[] { var35};
//     var28.setSources(var44);
//     org.jfree.chart.LegendItemSource[] var46 = var28.getSources();
//     org.jfree.chart.LegendItemSource[] var47 = var28.getSources();
//     java.lang.Object var48 = var28.clone();
//     java.awt.geom.Rectangle2D var49 = var28.getBounds();
//     org.jfree.chart.entity.ChartEntity var51 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var49, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var54 = var13.createInsetRectangle(var49, false, false);
//     var0.draw(var2, var54);
//     java.awt.Graphics2D var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     var0.draw(var56, var57);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.lang.String var1 = var0.getID();
    var0.setPadding(1.0d, 0.0d, 0.0d, 10.0d);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var13 = var12.getHeightRange();
    org.jfree.chart.util.Size2D var14 = var8.arrange(var9, var12);
    org.jfree.chart.block.RectangleConstraint var16 = var12.toFixedWidth((-1.0d));
    org.jfree.chart.block.LengthConstraintType var17 = var16.getWidthConstraintType();
    org.jfree.chart.util.Size2D var18 = var0.arrange(var7, var16);
    double var19 = var18.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    var2.setRenderer(var3);
    org.jfree.data.general.WaferMapDataset var5 = var2.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var10 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!");
    var5.addLibrary((org.jfree.chart.ui.Library)var10);
    java.lang.String var12 = var10.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "hi!"+ "'", var12.equals("hi!"));

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Pie Plot", var1, 100.0f, 0.8f, var4, 5.0d, 0.8f, 2.0f);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
//     var19.setTickLabelsVisible(true);
//     var19.setLowerBound(1.0d);
//     org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var19};
//     var4.setDomainAxes(var24);
//     org.jfree.chart.plot.DatasetRenderingOrder var26 = var4.getDatasetRenderingOrder();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
//     var34.setShadowXOffset(100.0d);
//     var34.setNoDataMessage("hi!");
//     java.awt.Stroke var40 = var34.getLabelOutlineStroke();
//     var32.setDomainZeroBaselineStroke(var40);
//     java.awt.Paint var42 = var32.getDomainGridlinePaint();
//     var32.clearRangeAxes();
//     var32.clearDomainMarkers();
//     org.jfree.chart.axis.AxisLocation var45 = var32.getRangeAxisLocation();
//     var4.setRangeAxisLocation(100, var45);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setPieIndex(100);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var2.setBaseSectionOutlineStroke(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var2.getLabelPadding();
//     var0.setTickLabelInsets(var9);
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     double var14 = var13.getLength();
//     org.jfree.data.Range var15 = null;
//     org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
//     org.jfree.data.Range var18 = org.jfree.data.Range.combine(var13, var17);
//     var0.setRange(var18, true, true);
//     boolean var22 = var0.isVisible();
//     var0.setVerticalTickLabels(false);
//     org.jfree.chart.block.LineBorder var26 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var27 = var26.getPaint();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
//     java.awt.Font var32 = var30.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
//     var33.removeLegend();
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", 1);
//     var33.setBorderPaint((java.awt.Paint)var37);
//     org.jfree.chart.util.RectangleInsets var39 = var33.getPadding();
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     java.awt.Stroke var42 = var41.getBaseSectionOutlineStroke();
//     var41.setShadowXOffset(100.0d);
//     var41.setNoDataMessage("hi!");
//     java.awt.Stroke var47 = var41.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var49 = null;
//     org.jfree.chart.util.VerticalAlignment var50 = null;
//     org.jfree.chart.block.ColumnArrangement var53 = new org.jfree.chart.block.ColumnArrangement(var49, var50, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41, (org.jfree.chart.block.Arrangement)var48, (org.jfree.chart.block.Arrangement)var53);
//     org.jfree.chart.event.TitleChangeListener var55 = null;
//     var54.removeChangeListener(var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     int var63 = var61.getDomainAxisIndex(var62);
//     var61.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     java.awt.geom.Point2D var68 = null;
//     var61.zoomDomainAxes(0.0d, var67, var68);
//     org.jfree.chart.LegendItemSource[] var70 = new org.jfree.chart.LegendItemSource[] { var61};
//     var54.setSources(var70);
//     org.jfree.chart.LegendItemSource[] var72 = var54.getSources();
//     org.jfree.chart.LegendItemSource[] var73 = var54.getSources();
//     java.lang.Object var74 = var54.clone();
//     java.awt.geom.Rectangle2D var75 = var54.getBounds();
//     org.jfree.chart.entity.ChartEntity var77 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var75, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var80 = var39.createInsetRectangle(var75, false, false);
//     var26.draw(var28, var80);
//     org.jfree.data.xy.XYDataset var82 = null;
//     org.jfree.chart.axis.ValueAxis var83 = null;
//     org.jfree.chart.axis.ValueAxis var84 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var85 = null;
//     org.jfree.chart.plot.XYPlot var86 = new org.jfree.chart.plot.XYPlot(var82, var83, var84, var85);
//     org.jfree.data.general.PieDataset var87 = null;
//     org.jfree.chart.plot.PiePlot var88 = new org.jfree.chart.plot.PiePlot(var87);
//     java.awt.Stroke var89 = var88.getBaseSectionOutlineStroke();
//     var88.setShadowXOffset(100.0d);
//     var88.setNoDataMessage("hi!");
//     java.awt.Stroke var94 = var88.getLabelOutlineStroke();
//     var86.setDomainZeroBaselineStroke(var94);
//     java.awt.Paint var96 = var86.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var98 = var86.getRangeAxisEdge(1);
//     double var99 = var0.java2DToValue(0.0d, var80, var98);
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var88
//     assertTrue("Contract failed: equals-hashcode on var41 and var88", var41.equals(var88) ? var41.hashCode() == var88.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var88 and var41
//     assertTrue("Contract failed: equals-hashcode on var88 and var41", var88.equals(var41) ? var88.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    double var4 = var1.getLabelLinkMargin();
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockFrame var1 = var0.getFrame();
    boolean var3 = var0.equals((java.lang.Object)0.025d);
    var0.clear();
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer();
    var5.setPadding(0.0d, 3.0d, (-1.0d), 0.025d);
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var12 = var11.getTimeline();
    boolean var13 = var5.equals((java.lang.Object)var11);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    var15.setPieIndex(100);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var15.setBaseSectionOutlineStroke(var20);
    org.jfree.chart.util.RectangleInsets var22 = var15.getLabelPadding();
    double var23 = var15.getShadowYOffset();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var28 = var27.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var29 = null;
    var27.setMarkerBand(var29);
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var24, var25, (org.jfree.chart.axis.ValueAxis)var27, var31);
    org.jfree.data.Range var33 = null;
    org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, 0.0d);
    var27.setRange(var35, false, false);
    java.text.NumberFormat var39 = null;
    var27.setNumberFormatOverride(var39);
    boolean var41 = var15.equals((java.lang.Object)var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var5, (java.lang.Object)var27);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.LengthAdjustmentType var2 = var1.getLabelOffsetType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var5 = var4.getHeightRange();
//     org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var4);
//     org.jfree.data.Range var7 = var4.getWidthRange();
//     org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var13 = var12.getHeightRange();
//     org.jfree.chart.util.Size2D var14 = var8.arrange(var9, var12);
//     java.lang.Object var15 = var14.clone();
//     var14.setHeight(0.0d);
//     org.jfree.chart.util.Size2D var18 = var4.calculateConstrainedSize(var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var14
//     assertTrue("Contract failed: equals-hashcode on var6 and var14", var6.equals(var14) ? var6.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var18
//     assertTrue("Contract failed: equals-hashcode on var6 and var18", var6.equals(var18) ? var6.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var6
//     assertTrue("Contract failed: equals-hashcode on var14 and var6", var14.equals(var6) ? var14.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var18
//     assertTrue("Contract failed: equals-hashcode on var14 and var18", var14.equals(var18) ? var14.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var6
//     assertTrue("Contract failed: equals-hashcode on var18 and var6", var18.equals(var6) ? var18.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var14
//     assertTrue("Contract failed: equals-hashcode on var18 and var14", var18.equals(var14) ? var18.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    var8.setDomainAxis(1, var13, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    var8.setRenderer(var16, false);
    org.jfree.chart.util.RectangleEdge var19 = var8.getDomainAxisEdge();
    org.jfree.data.category.CategoryDataset var20 = var8.getDataset();
    org.jfree.chart.util.Layer var22 = null;
    java.util.Collection var23 = var8.getRangeMarkers((-16777216), var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     var8.clearRangeAxes();
//     var8.setDrawSharedDomainAxis(false);
//     boolean var15 = var8.getDrawSharedDomainAxis();
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var18 = var17.getValue();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     java.awt.Font var24 = var22.getNoDataMessageFont();
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var28 = var27.getColorSpace();
//     org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var24, (java.awt.Paint)var27);
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var32 = var31.getValue();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getLabelOffset();
//     java.awt.Stroke var34 = var31.getOutlineStroke();
//     java.awt.Paint var35 = var31.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var38 = null;
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("", var24, var35, 0.0f, 1, var38);
//     var17.setLabelFont(var24);
//     boolean var41 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var17);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var8.getRangeAxis(0);
//     var8.zoom(4.0d);
//     org.jfree.chart.util.Layer var17 = null;
//     java.util.Collection var18 = var8.getDomainMarkers(15, var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     java.awt.Stroke var22 = var21.getBaseSectionOutlineStroke();
//     java.awt.Font var23 = var21.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var21);
//     var24.removeLegend();
//     java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
//     var24.setBorderPaint((java.awt.Paint)var28);
//     org.jfree.chart.util.RectangleInsets var30 = var24.getPadding();
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     var32.setShadowXOffset(100.0d);
//     var32.setNoDataMessage("hi!");
//     java.awt.Stroke var38 = var32.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var39 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var40 = null;
//     org.jfree.chart.util.VerticalAlignment var41 = null;
//     org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var32, (org.jfree.chart.block.Arrangement)var39, (org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.event.TitleChangeListener var46 = null;
//     var45.removeChangeListener(var46);
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     int var54 = var52.getDomainAxisIndex(var53);
//     var52.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var58 = null;
//     java.awt.geom.Point2D var59 = null;
//     var52.zoomDomainAxes(0.0d, var58, var59);
//     org.jfree.chart.LegendItemSource[] var61 = new org.jfree.chart.LegendItemSource[] { var52};
//     var45.setSources(var61);
//     org.jfree.chart.LegendItemSource[] var63 = var45.getSources();
//     org.jfree.chart.LegendItemSource[] var64 = var45.getSources();
//     java.lang.Object var65 = var45.clone();
//     java.awt.geom.Rectangle2D var66 = var45.getBounds();
//     org.jfree.chart.entity.ChartEntity var68 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var66, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var71 = var30.createInsetRectangle(var66, false, false);
//     var8.drawBackground(var19, var71);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    java.awt.Stroke var7 = var1.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var9 = null;
    org.jfree.chart.util.VerticalAlignment var10 = null;
    org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var14.removeChangeListener(var15);
    org.jfree.chart.util.VerticalAlignment var17 = var14.getVerticalAlignment();
    var14.setWidth(0.05d);
    org.jfree.chart.util.RectangleInsets var20 = var14.getItemLabelPadding();
    org.jfree.chart.util.VerticalAlignment var21 = var14.getVerticalAlignment();
    java.lang.Object var22 = var14.clone();
    org.jfree.chart.util.RectangleEdge var23 = var14.getLegendItemGraphicEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "hi!", "hi!");
    java.lang.String var6 = var5.getInfo();
    var5.setInfo("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D("");
    var7.setTickLabelsVisible(true);
    int var10 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var7);
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainZoomable();
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRenderer((-16777215), var14, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    var6.setLabelAngle(0.0d);
    var6.centerRange(0.025d);
    int var11 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
    var18.setShadowXOffset(100.0d);
    var18.setNoDataMessage("hi!");
    java.awt.Stroke var24 = var18.getLabelOutlineStroke();
    var16.setDomainZeroBaselineStroke(var24);
    java.awt.Paint var26 = var16.getDomainGridlinePaint();
    java.awt.Paint var27 = var16.getDomainZeroBaselinePaint();
    var16.setDomainGridlinesVisible(false);
    org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D("");
    var31.setTickLabelsVisible(true);
    var31.setLowerBound(1.0d);
    org.jfree.chart.axis.ValueAxis[] var36 = new org.jfree.chart.axis.ValueAxis[] { var31};
    var16.setDomainAxes(var36);
    org.jfree.chart.plot.DatasetRenderingOrder var38 = var16.getDatasetRenderingOrder();
    var4.setDatasetRenderingOrder(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    var0.setInnerSeparatorExtension(0.0d);
    var0.setOuterSeparatorExtension(0.2d);
    org.jfree.chart.labels.PieToolTipGenerator var5 = var0.getToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    java.util.List var5 = var4.getSubtitles();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var10 = var9.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var11 = null;
    var9.setMarkerBand(var11);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var13);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var14.getDomainMarkers(1, var16);
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var14.addRangeMarker((org.jfree.chart.plot.Marker)var19);
    java.lang.String var21 = var14.getPlotType();
    org.jfree.chart.axis.CategoryAxis var22 = null;
    java.util.List var23 = var14.getCategoriesForAxis(var22);
    var4.setSubtitles(var23);
    org.jfree.chart.event.ChartProgressListener var25 = null;
    var4.addProgressListener(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Category Plot"+ "'", var21.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainCrosshairLockedOnData();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     java.awt.Stroke var15 = var14.getBaseSectionOutlineStroke();
//     var14.setShadowXOffset(100.0d);
//     var14.setNoDataMessage("hi!");
//     java.awt.Stroke var20 = var14.getLabelOutlineStroke();
//     var12.setDomainZeroBaselineStroke(var20);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
//     boolean var29 = var28.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     java.awt.Font var34 = var32.getNoDataMessageFont();
//     java.awt.Color var37 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var38 = var37.getColorSpace();
//     java.awt.Color var39 = var37.darker();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var34, (java.awt.Paint)var37);
//     var28.setDomainCrosshairPaint((java.awt.Paint)var37);
//     org.jfree.chart.axis.AxisSpace var42 = var28.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleAnchor var47 = null;
//     java.awt.geom.Point2D var48 = org.jfree.chart.util.RectangleAnchor.coordinates(var46, var47);
//     var28.zoomDomainAxes(0.025d, (-1.0d), var45, var48);
//     var12.zoomDomainAxes(4.0d, var23, var48);
//     var4.zoomDomainAxes(0.0d, var7, var48, false);
//     
//     // Checks the contract:  equals-hashcode on var4 and var12
//     assertTrue("Contract failed: equals-hashcode on var4 and var12", var4.equals(var12) ? var4.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var4
//     assertTrue("Contract failed: equals-hashcode on var12 and var4", var12.equals(var4) ? var12.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.AttributedString var3 = var1.getAttributedLabel(0);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     boolean var9 = var8.isDomainCrosshairLockedOnData();
//     org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge((-16777216));
//     boolean var12 = var1.equals((java.lang.Object)var8);
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var15 = var14.getValue();
//     org.jfree.chart.util.RectangleInsets var16 = var14.getLabelOffset();
//     double var17 = var16.getRight();
//     java.lang.String var18 = var16.toString();
//     double var20 = var16.calculateTopInset(0.0d);
//     var8.setAxisOffset(var16);
//     org.jfree.chart.plot.Marker var22 = null;
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var8.removeDomainMarker(var22, var23);
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var16 = var4.getRangeAxisEdge(1);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
//     java.awt.Font var21 = var19.getNoDataMessageFont();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var25 = var24.getColorSpace();
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var21, (java.awt.Paint)var24);
//     var4.setRangeCrosshairPaint((java.awt.Paint)var24);
//     var4.setDomainCrosshairValue(4.0d, false);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     java.awt.Font var35 = var33.getNoDataMessageFont();
//     java.awt.Color var38 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var39 = var38.getColorSpace();
//     java.awt.Color var40 = var38.darker();
//     org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("", var35, (java.awt.Paint)var38);
//     java.awt.Font var42 = var41.getFont();
//     var4.setNoDataMessageFont(var42);
//     
//     // Checks the contract:  equals-hashcode on var19 and var33
//     assertTrue("Contract failed: equals-hashcode on var19 and var33", var19.equals(var33) ? var19.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var19
//     assertTrue("Contract failed: equals-hashcode on var33 and var19", var33.equals(var19) ? var33.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.data.general.DatasetChangeEvent var12 = null;
//     var8.datasetChanged(var12);
//     org.jfree.data.general.DatasetGroup var14 = var8.getDatasetGroup();
//     org.jfree.chart.plot.Marker var15 = null;
//     org.jfree.chart.util.Layer var16 = null;
//     boolean var17 = var8.removeDomainMarker(var15, var16);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.util.VerticalAlignment var15 = var14.getVerticalAlignment();
//     var14.setPadding(0.0d, 100.0d, 0.0d, 100.0d);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var29, (org.jfree.chart.block.Arrangement)var34);
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var35.removeChangeListener(var36);
//     org.jfree.chart.util.VerticalAlignment var38 = var35.getVerticalAlignment();
//     var35.setWidth(0.05d);
//     org.jfree.chart.util.RectangleInsets var41 = var35.getItemLabelPadding();
//     var14.setItemLabelPadding(var41);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var29
//     assertTrue("Contract failed: equals-hashcode on var8 and var29", var8.equals(var29) ? var8.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var34
//     assertTrue("Contract failed: equals-hashcode on var13 and var34", var13.equals(var34) ? var13.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var8
//     assertTrue("Contract failed: equals-hashcode on var29 and var8", var29.equals(var8) ? var29.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var13
//     assertTrue("Contract failed: equals-hashcode on var34 and var13", var34.equals(var13) ? var34.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     float var4 = var1.getForegroundAlpha();
//     org.jfree.chart.labels.PieToolTipGenerator var5 = var1.getToolTipGenerator();
//     java.awt.Stroke var6 = var1.getLabelLinkStroke();
//     double var7 = var1.getMinimumArcAngleToDraw();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Stroke var12 = var11.getBaseSectionOutlineStroke();
//     var11.setShadowXOffset(100.0d);
//     var11.setNoDataMessage("hi!");
//     java.awt.Stroke var17 = var11.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var19 = null;
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11, (org.jfree.chart.block.Arrangement)var18, (org.jfree.chart.block.Arrangement)var23);
//     java.awt.Paint var26 = var11.getSectionOutlinePaint((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=1]");
//     java.awt.Color var29 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var30 = var29.getColorSpace();
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var29);
//     var11.setBaseSectionOutlinePaint((java.awt.Paint)var29);
//     java.lang.String var33 = var29.toString();
//     var9.setLabelOutlinePaint((java.awt.Paint)var29);
//     var1.setLabelPaint((java.awt.Paint)var29);
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setPieIndex(100);
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     java.awt.Stroke var43 = var42.getBaseSectionOutlineStroke();
//     var38.setBaseSectionOutlineStroke(var43);
//     org.jfree.chart.util.RectangleInsets var45 = var38.getLabelPadding();
//     java.awt.Color var48 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var49 = var48.getColorSpace();
//     org.jfree.chart.block.BlockBorder var50 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var48);
//     org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder(var45, (java.awt.Paint)var48);
//     int var52 = var48.getGreen();
//     var1.setSectionOutlinePaint((java.lang.Comparable)"Pie Plot", (java.awt.Paint)var48);
//     
//     // Checks the contract:  equals-hashcode on var31 and var50
//     assertTrue("Contract failed: equals-hashcode on var31 and var50", var31.equals(var50) ? var31.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var31
//     assertTrue("Contract failed: equals-hashcode on var50 and var31", var50.equals(var31) ? var50.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
    var4.clearRangeMarkers(0);
    java.awt.Stroke var18 = var4.getRangeGridlineStroke();
    var4.setDomainCrosshairValue((-1.0d), false);
    org.jfree.chart.LegendItemCollection var22 = var4.getLegendItems();
    org.jfree.data.xy.XYDataset var24 = var4.getDataset((-16777216));
    org.jfree.chart.axis.AxisSpace var25 = null;
    var4.setFixedRangeAxisSpace(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint var4 = null;
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Stroke var8 = null;
//     java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
//     java.awt.Shape var10 = null;
//     java.awt.Shape[] var11 = new java.awt.Shape[] { var10};
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9, var11);
//     java.awt.Paint var13 = null;
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     java.awt.Paint var15 = null;
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var15};
//     java.awt.Paint var17 = null;
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Stroke var21 = null;
//     java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
//     java.awt.Shape var23 = null;
//     java.awt.Shape[] var24 = new java.awt.Shape[] { var23};
//     org.jfree.chart.plot.DefaultDrawingSupplier var25 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var16, var18, var20, var22, var24);
//     java.awt.Paint var26 = null;
//     java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
//     java.awt.Paint var28 = null;
//     java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
//     java.awt.Paint var30 = null;
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var30};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     java.awt.Shape var36 = null;
//     java.awt.Shape[] var37 = new java.awt.Shape[] { var36};
//     org.jfree.chart.plot.DefaultDrawingSupplier var38 = new org.jfree.chart.plot.DefaultDrawingSupplier(var27, var29, var31, var33, var35, var37);
//     java.awt.Stroke[] var39 = null;
//     java.awt.Shape[] var40 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var41 = new org.jfree.chart.plot.DefaultDrawingSupplier(var3, var16, var33, var39, var40);
//     
//     // Checks the contract:  equals-hashcode on var12 and var25
//     assertTrue("Contract failed: equals-hashcode on var12 and var25", var12.equals(var25) ? var12.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var38
//     assertTrue("Contract failed: equals-hashcode on var12 and var38", var12.equals(var38) ? var12.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var12
//     assertTrue("Contract failed: equals-hashcode on var25 and var12", var25.equals(var12) ? var25.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var38
//     assertTrue("Contract failed: equals-hashcode on var25 and var38", var25.equals(var38) ? var25.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var12
//     assertTrue("Contract failed: equals-hashcode on var38 and var12", var38.equals(var12) ? var38.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var25
//     assertTrue("Contract failed: equals-hashcode on var38 and var25", var38.equals(var25) ? var38.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var11 = var10.getValue();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getLabelOffset();
//     java.awt.Stroke var13 = var10.getOutlineStroke();
//     java.awt.Paint var14 = var10.getLabelPaint();
//     org.jfree.chart.util.Layer var15 = null;
//     boolean var16 = var8.removeDomainMarker((org.jfree.chart.plot.Marker)var10, var15);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setUpperMargin(0.2d);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     java.awt.Font var8 = var6.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var9.removeLegend();
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     var9.setBorderPaint((java.awt.Paint)var13);
//     org.jfree.chart.util.RectangleInsets var15 = var9.getPadding();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var17.setShadowXOffset(100.0d);
//     var17.setNoDataMessage("hi!");
//     java.awt.Stroke var23 = var17.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var30.removeChangeListener(var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     int var39 = var37.getDomainAxisIndex(var38);
//     var37.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Point2D var44 = null;
//     var37.zoomDomainAxes(0.0d, var43, var44);
//     org.jfree.chart.LegendItemSource[] var46 = new org.jfree.chart.LegendItemSource[] { var37};
//     var30.setSources(var46);
//     org.jfree.chart.LegendItemSource[] var48 = var30.getSources();
//     org.jfree.chart.LegendItemSource[] var49 = var30.getSources();
//     java.lang.Object var50 = var30.clone();
//     java.awt.geom.Rectangle2D var51 = var30.getBounds();
//     org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var51, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var56 = var15.createInsetRectangle(var51, false, false);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.PiePlot var63 = new org.jfree.chart.plot.PiePlot(var62);
//     java.awt.Stroke var64 = var63.getBaseSectionOutlineStroke();
//     var63.setShadowXOffset(100.0d);
//     var63.setNoDataMessage("hi!");
//     java.awt.Stroke var69 = var63.getLabelOutlineStroke();
//     var61.setDomainZeroBaselineStroke(var69);
//     java.awt.Paint var71 = var61.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var73 = var61.getRangeAxisEdge(1);
//     boolean var74 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var73);
//     double var75 = var0.getCategoryEnd(255, 15, var56, var73);
//     
//     // Checks the contract:  equals-hashcode on var17 and var63
//     assertTrue("Contract failed: equals-hashcode on var17 and var63", var17.equals(var63) ? var17.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var17
//     assertTrue("Contract failed: equals-hashcode on var63 and var17", var63.equals(var17) ? var63.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     var1.setShadowXOffset(100.0d);
//     var1.setNoDataMessage("hi!");
//     java.awt.Stroke var7 = var1.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.ColumnArrangement var13 = new org.jfree.chart.block.ColumnArrangement(var9, var10, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var8, (org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.event.TitleChangeListener var15 = null;
//     var14.removeChangeListener(var15);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var21.getDomainAxisIndex(var22);
//     var21.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var21.zoomDomainAxes(0.0d, var27, var28);
//     org.jfree.chart.LegendItemSource[] var30 = new org.jfree.chart.LegendItemSource[] { var21};
//     var14.setSources(var30);
//     org.jfree.chart.LegendItemSource[] var32 = var14.getSources();
//     org.jfree.chart.LegendItemSource[] var33 = var14.getSources();
//     java.lang.Object var34 = var14.clone();
//     org.jfree.chart.util.RectangleInsets var35 = var14.getLegendItemGraphicPadding();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     java.awt.Stroke var39 = var38.getBaseSectionOutlineStroke();
//     var38.setShadowXOffset(100.0d);
//     var38.setNoDataMessage("hi!");
//     java.awt.Stroke var44 = var38.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var46 = null;
//     org.jfree.chart.util.VerticalAlignment var47 = null;
//     org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38, (org.jfree.chart.block.Arrangement)var45, (org.jfree.chart.block.Arrangement)var50);
//     org.jfree.chart.event.TitleChangeListener var52 = null;
//     var51.removeChangeListener(var52);
//     org.jfree.chart.util.VerticalAlignment var54 = var51.getVerticalAlignment();
//     java.awt.Font var55 = var51.getItemFont();
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("", var55);
//     org.jfree.chart.util.HorizontalAlignment var57 = var56.getHorizontalAlignment();
//     var14.setHorizontalAlignment(var57);
//     
//     // Checks the contract:  equals-hashcode on var1 and var38
//     assertTrue("Contract failed: equals-hashcode on var1 and var38", var1.equals(var38) ? var1.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var1
//     assertTrue("Contract failed: equals-hashcode on var38 and var1", var38.equals(var1) ? var38.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var45
//     assertTrue("Contract failed: equals-hashcode on var8 and var45", var8.equals(var45) ? var8.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var50
//     assertTrue("Contract failed: equals-hashcode on var13 and var50", var13.equals(var50) ? var13.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var8
//     assertTrue("Contract failed: equals-hashcode on var45 and var8", var45.equals(var8) ? var45.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var13
//     assertTrue("Contract failed: equals-hashcode on var50 and var13", var50.equals(var13) ? var50.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var8 = var7.getColorSpace();
    java.awt.Color var9 = var7.darker();
    int var10 = var9.getRGB();
    var4.setDomainCrosshairPaint((java.awt.Paint)var9);
    var4.setDomainCrosshairValue(0.14d);
    org.jfree.chart.LegendItemCollection var14 = null;
    var4.setFixedLegendItems(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-16777216));

  }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
//     var15.setShadowXOffset(100.0d);
//     var15.setNoDataMessage("hi!");
//     java.awt.Stroke var21 = var15.getLabelOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var21);
//     java.awt.Stroke var23 = var13.getRangeGridlineStroke();
//     var8.setRangeGridlineStroke(var23);
//     var8.mapDatasetToRangeAxis(0, 1);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     java.awt.Stroke var36 = var35.getBaseSectionOutlineStroke();
//     var35.setShadowXOffset(100.0d);
//     var35.setNoDataMessage("hi!");
//     java.awt.Stroke var41 = var35.getLabelOutlineStroke();
//     var33.setDomainZeroBaselineStroke(var41);
//     java.awt.Paint var43 = var33.getDomainGridlinePaint();
//     java.awt.Paint var44 = var33.getDomainZeroBaselinePaint();
//     java.awt.Paint var45 = var33.getRangeTickBandPaint();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.NumberAxis3D var49 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var50 = var49.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var51 = null;
//     var49.setMarkerBand(var51);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var46, var47, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.data.category.CategoryDataset var56 = null;
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var60 = var59.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var61 = null;
//     var59.setMarkerBand(var61);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var56, var57, (org.jfree.chart.axis.ValueAxis)var59, var63);
//     org.jfree.chart.util.Layer var66 = null;
//     java.util.Collection var67 = var64.getDomainMarkers(1, var66);
//     org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var64.addRangeMarker((org.jfree.chart.plot.Marker)var69);
//     org.jfree.chart.axis.AxisLocation var71 = var64.getRangeAxisLocation();
//     var54.setRangeAxisLocation(0, var71);
//     var33.setDomainAxisLocation(var71);
//     var8.setDomainAxisLocation(1, var71);
//     
//     // Checks the contract:  equals-hashcode on var15 and var35
//     assertTrue("Contract failed: equals-hashcode on var15 and var35", var15.equals(var35) ? var15.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var15
//     assertTrue("Contract failed: equals-hashcode on var35 and var15", var35.equals(var15) ? var35.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.Paint var5 = var4.getRangeTickBandPaint();
//     org.jfree.data.xy.XYDataset var6 = null;
//     int var7 = var4.indexOf(var6);
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     var10.setShadowXOffset(100.0d);
//     var10.setNoDataMessage("hi!");
//     var10.setBackgroundAlpha(0.0f);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.AttributedString var21 = var19.getAttributedLabel(0);
//     java.lang.Object var22 = null;
//     boolean var23 = var19.equals(var22);
//     var10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var19);
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     boolean var27 = var10.equals((java.lang.Object)var26);
//     var26.setLabel("ChartChangeEventType.GENERAL");
//     org.jfree.chart.util.Layer var30 = null;
//     var4.addRangeMarker(1, (org.jfree.chart.plot.Marker)var26, var30);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     var34.setForegroundAlpha((-1.0f));
//     var34.setCircular(true, true);
//     java.awt.Paint var40 = var34.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     java.awt.Stroke var43 = var42.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.PiePlot var50 = new org.jfree.chart.plot.PiePlot(var49);
//     java.awt.Stroke var51 = var50.getBaseSectionOutlineStroke();
//     var50.setShadowXOffset(100.0d);
//     var50.setNoDataMessage("hi!");
//     java.awt.Stroke var56 = var50.getLabelOutlineStroke();
//     var48.setDomainZeroBaselineStroke(var56);
//     java.awt.Paint var58 = var48.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var61 = var60.getValue();
//     org.jfree.chart.util.RectangleInsets var62 = var60.getLabelOffset();
//     java.awt.Stroke var63 = var60.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(0.0d, var40, var43, var58, var63, 0.0f);
//     java.lang.Object var66 = var65.clone();
//     org.jfree.chart.util.RectangleAnchor var67 = var65.getLabelAnchor();
//     java.lang.String var68 = var67.toString();
//     var26.setLabelAnchor(var67);
//     
//     // Checks the contract:  equals-hashcode on var4 and var48
//     assertTrue("Contract failed: equals-hashcode on var4 and var48", var4.equals(var48) ? var4.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var4
//     assertTrue("Contract failed: equals-hashcode on var48 and var4", var48.equals(var4) ? var48.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setForegroundAlpha((-1.0f));
    var1.setCircular(true, true);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    var8.setForegroundAlpha((-1.0f));
    var8.setCircular(true, true);
    java.awt.Paint var14 = var8.getLabelShadowPaint();
    var1.setShadowPaint(var14);
    java.awt.Paint var16 = var1.getLabelPaint();
    var1.setLabelLinksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setMaximumCategoryLabelWidthRatio((-1.0f));
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     java.awt.Font var8 = var6.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var9.removeLegend();
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     var9.setBorderPaint((java.awt.Paint)var13);
//     org.jfree.chart.util.RectangleInsets var15 = var9.getPadding();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var17.setShadowXOffset(100.0d);
//     var17.setNoDataMessage("hi!");
//     java.awt.Stroke var23 = var17.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var30.removeChangeListener(var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     int var39 = var37.getDomainAxisIndex(var38);
//     var37.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Point2D var44 = null;
//     var37.zoomDomainAxes(0.0d, var43, var44);
//     org.jfree.chart.LegendItemSource[] var46 = new org.jfree.chart.LegendItemSource[] { var37};
//     var30.setSources(var46);
//     org.jfree.chart.LegendItemSource[] var48 = var30.getSources();
//     org.jfree.chart.LegendItemSource[] var49 = var30.getSources();
//     java.lang.Object var50 = var30.clone();
//     java.awt.geom.Rectangle2D var51 = var30.getBounds();
//     org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var51, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var56 = var15.createInsetRectangle(var51, false, false);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.data.general.PieDataset var62 = null;
//     org.jfree.chart.plot.PiePlot var63 = new org.jfree.chart.plot.PiePlot(var62);
//     java.awt.Stroke var64 = var63.getBaseSectionOutlineStroke();
//     var63.setShadowXOffset(100.0d);
//     var63.setNoDataMessage("hi!");
//     java.awt.Stroke var69 = var63.getLabelOutlineStroke();
//     var61.setDomainZeroBaselineStroke(var69);
//     java.awt.Paint var71 = var61.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var73 = var61.getRangeAxisEdge(1);
//     double var74 = var0.getCategoryMiddle(255, (-16777216), var56, var73);
//     
//     // Checks the contract:  equals-hashcode on var17 and var63
//     assertTrue("Contract failed: equals-hashcode on var17 and var63", var17.equals(var63) ? var17.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var17
//     assertTrue("Contract failed: equals-hashcode on var63 and var17", var63.equals(var17) ? var63.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     java.awt.Stroke var5 = var4.getBaseSectionOutlineStroke();
//     java.awt.Font var6 = var4.getNoDataMessageFont();
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var10 = var9.getColorSpace();
//     java.awt.Color var11 = var9.darker();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var6, (java.awt.Paint)var9);
//     var1.removeFragment(var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextAnchor var15 = null;
//     float var16 = var12.calculateBaselineOffset(var14, var15);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    var4.clearRangeAxes();
    var4.clearDomainMarkers();
    org.jfree.chart.plot.DatasetRenderingOrder var17 = var4.getDatasetRenderingOrder();
    var4.configureDomainAxes();
    java.awt.Paint var19 = var4.getDomainCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     var4.clearRangeMarkers(0);
//     java.awt.Stroke var18 = var4.getRangeGridlineStroke();
//     var4.setDomainCrosshairValue((-1.0d), false);
//     org.jfree.chart.LegendItemCollection var22 = var4.getLegendItems();
//     org.jfree.data.xy.XYDataset var24 = var4.getDataset((-16777216));
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     java.awt.Paint var31 = var30.getRangeTickBandPaint();
//     org.jfree.data.xy.XYDataset var32 = null;
//     int var33 = var30.indexOf(var32);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     var40.setShadowXOffset(100.0d);
//     var40.setNoDataMessage("hi!");
//     java.awt.Stroke var46 = var40.getLabelOutlineStroke();
//     var38.setDomainZeroBaselineStroke(var46);
//     java.awt.Paint var48 = var38.getDomainGridlinePaint();
//     java.awt.Paint var49 = var38.getDomainZeroBaselinePaint();
//     var38.clearRangeMarkers(0);
//     java.awt.Stroke var52 = var38.getRangeGridlineStroke();
//     var38.setDomainCrosshairValue((-1.0d), false);
//     org.jfree.chart.axis.AxisLocation var57 = var38.getDomainAxisLocation(15);
//     var30.setRangeAxisLocation(var57);
//     var4.setRangeAxisLocation(255, var57);
//     
//     // Checks the contract:  equals-hashcode on var38 and var4
//     assertTrue("Contract failed: equals-hashcode on var38 and var4", var38.equals(var4) ? var38.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var38 and var4.", var38.equals(var4) == var4.equals(var38));
//     
//     // Checks the contract:  equals-hashcode on var6 and var40
//     assertTrue("Contract failed: equals-hashcode on var6 and var40", var6.equals(var40) ? var6.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var6
//     assertTrue("Contract failed: equals-hashcode on var40 and var6", var40.equals(var6) ? var40.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(100, var6);
    var4.setRangeGridlinesVisible(false);
    org.jfree.data.xy.XYDataset var10 = null;
    int var11 = var4.indexOf(var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var16 = var15.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var17 = null;
    var15.setMarkerBand(var17);
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var12, var13, (org.jfree.chart.axis.ValueAxis)var15, var19);
    org.jfree.chart.util.Layer var22 = null;
    java.util.Collection var23 = var20.getDomainMarkers(1, var22);
    org.jfree.chart.axis.ValueAxis var25 = var20.getRangeAxis(0);
    int var26 = var4.getRangeAxisIndex(var25);
    org.jfree.chart.axis.AxisSpace var27 = var4.getFixedDomainAxisSpace();
    java.awt.geom.Point2D var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setQuadrantOrigin(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    var0.clearCornerTextItems();
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomDomainAxes(3.0d, 3.0d, var4, var5);
    java.lang.String var7 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Polar Plot"+ "'", var7.equals("Polar Plot"));

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("WMAP_Plot", var1);
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     var1.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var3 = var1.getLegendItems();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var6 = var5.getValue();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     java.awt.Stroke var11 = var10.getBaseSectionOutlineStroke();
//     java.awt.Font var12 = var10.getNoDataMessageFont();
//     java.awt.Color var15 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var16 = var15.getColorSpace();
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var12, (java.awt.Paint)var15);
//     org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var20 = var19.getValue();
//     org.jfree.chart.util.RectangleInsets var21 = var19.getLabelOffset();
//     java.awt.Stroke var22 = var19.getOutlineStroke();
//     java.awt.Paint var23 = var19.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var26 = null;
//     org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, var23, 0.0f, 1, var26);
//     var5.setLabelFont(var12);
//     var1.setAngleLabelFont(var12);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("Polar Plot", var12);
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var33 = var32.getValue();
//     org.jfree.chart.util.RectangleInsets var34 = var32.getLabelOffset();
//     boolean var36 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var34, (java.lang.Object)"Polar Plot");
//     double var37 = var34.getTop();
//     boolean var38 = var30.equals((java.lang.Object)var37);
//     
//     // Checks the contract:  equals-hashcode on var19 and var32
//     assertTrue("Contract failed: equals-hashcode on var19 and var32", var19.equals(var32) ? var19.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var19
//     assertTrue("Contract failed: equals-hashcode on var32 and var19", var32.equals(var19) ? var32.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
    org.jfree.chart.axis.AxisLocation var7 = var4.getRangeAxisLocation(100);
    org.jfree.data.general.DatasetChangeEvent var8 = null;
    var4.datasetChanged(var8);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var15 = var14.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var16 = null;
    var14.setMarkerBand(var16);
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var11, var12, (org.jfree.chart.axis.ValueAxis)var14, var18);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getDomainMarkers(1, var21);
    org.jfree.chart.axis.ValueAxis var24 = var19.getRangeAxis(0);
    java.awt.Paint var25 = var24.getAxisLinePaint();
    var24.setTickMarkOutsideLength((-1.0f));
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
    java.awt.Stroke var31 = var30.getBaseSectionOutlineStroke();
    var30.setShadowXOffset(100.0d);
    var30.setNoDataMessage("hi!");
    java.awt.Stroke var36 = var30.getLabelOutlineStroke();
    org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.util.HorizontalAlignment var38 = null;
    org.jfree.chart.util.VerticalAlignment var39 = null;
    org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var38, var39, 100.0d, (-1.0d));
    org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30, (org.jfree.chart.block.Arrangement)var37, (org.jfree.chart.block.Arrangement)var42);
    org.jfree.chart.event.TitleChangeListener var44 = null;
    var43.removeChangeListener(var44);
    org.jfree.chart.util.VerticalAlignment var46 = var43.getVerticalAlignment();
    java.awt.Font var47 = var43.getItemFont();
    org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle("", var47);
    org.jfree.data.general.PieDataset var50 = null;
    org.jfree.chart.plot.PiePlot var51 = new org.jfree.chart.plot.PiePlot(var50);
    java.awt.Stroke var52 = var51.getBaseSectionOutlineStroke();
    java.awt.Font var53 = var51.getNoDataMessageFont();
    java.awt.Color var56 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var57 = var56.getColorSpace();
    org.jfree.chart.text.TextBlock var58 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var53, (java.awt.Paint)var56);
    org.jfree.chart.block.BlockContainer var59 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var60 = null;
    org.jfree.chart.block.RectangleConstraint var63 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var64 = var63.getHeightRange();
    org.jfree.chart.util.Size2D var65 = var59.arrange(var60, var63);
    boolean var66 = var58.equals((java.lang.Object)var63);
    java.awt.Color var69 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var70 = var69.getColorSpace();
    java.awt.Color var71 = var69.darker();
    boolean var72 = var58.equals((java.lang.Object)var71);
    var48.setBackgroundPaint((java.awt.Paint)var71);
    java.awt.Font var74 = var48.getFont();
    var24.setTickLabelFont(var74);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxis((-1), var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    double var4 = var1.getLabelLinkMargin();
    org.jfree.data.general.DatasetGroup var5 = var1.getDatasetGroup();
    boolean var6 = var1.getIgnoreZeroValues();
    org.jfree.chart.urls.PieURLGenerator var7 = var1.getLegendLabelURLGenerator();
    var1.setIgnoreNullValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getLowerMargin();
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRightArrow(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.util.RectangleEdge var15 = var8.getRangeAxisEdge();
//     var8.clearRangeMarkers();
//     java.awt.Color var20 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var21 = var20.getColorSpace();
//     java.awt.Color var22 = var20.darker();
//     java.awt.Color var23 = java.awt.Color.getColor("", var22);
//     var8.setRangeCrosshairPaint((java.awt.Paint)var23);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var29 = var28.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var30 = null;
//     var28.setMarkerBand(var30);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var25, var26, (org.jfree.chart.axis.ValueAxis)var28, var32);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     java.awt.Stroke var41 = var40.getBaseSectionOutlineStroke();
//     var40.setShadowXOffset(100.0d);
//     var40.setNoDataMessage("hi!");
//     java.awt.Stroke var46 = var40.getLabelOutlineStroke();
//     var38.setDomainZeroBaselineStroke(var46);
//     java.awt.Stroke var48 = var38.getRangeGridlineStroke();
//     var33.setRangeGridlineStroke(var48);
//     org.jfree.chart.axis.CategoryAxis var50 = var33.getDomainAxis();
//     var33.setRangeCrosshairLockedOnData(true);
//     org.jfree.data.category.CategoryDataset var53 = null;
//     org.jfree.chart.axis.CategoryAxis var54 = null;
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var57 = var56.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var58 = null;
//     var56.setMarkerBand(var58);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var53, var54, (org.jfree.chart.axis.ValueAxis)var56, var60);
//     org.jfree.chart.util.Layer var63 = null;
//     java.util.Collection var64 = var61.getDomainMarkers(1, var63);
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var61.addRangeMarker((org.jfree.chart.plot.Marker)var66);
//     java.lang.String var68 = var61.getPlotType();
//     org.jfree.chart.axis.CategoryAxis var69 = null;
//     java.util.List var70 = var61.getCategoriesForAxis(var69);
//     var61.setRangeCrosshairVisible(false);
//     var61.clearAnnotations();
//     org.jfree.chart.util.Layer var74 = null;
//     java.util.Collection var75 = var61.getRangeMarkers(var74);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var76 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var77 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var76};
//     var61.setRenderers(var77);
//     var33.setRenderers(var77);
//     var8.setRenderers(var77);
//     
//     // Checks the contract:  equals-hashcode on var13 and var66
//     assertTrue("Contract failed: equals-hashcode on var13 and var66", var13.equals(var66) ? var13.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var13
//     assertTrue("Contract failed: equals-hashcode on var66 and var13", var66.equals(var13) ? var66.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setForegroundAlpha((-1.0f));
//     var1.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.ChartChangeEventType var8 = null;
//     var7.setType(var8);
//     java.lang.String var10 = var7.toString();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
//     var7.setChart(var15);
//     var15.setBorderVisible(true);
//     java.awt.Stroke var20 = var15.getBorderStroke();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var29, (org.jfree.chart.block.Arrangement)var34);
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var35.removeChangeListener(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     int var44 = var42.getDomainAxisIndex(var43);
//     var42.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     java.awt.geom.Point2D var49 = null;
//     var42.zoomDomainAxes(0.0d, var48, var49);
//     org.jfree.chart.LegendItemSource[] var51 = new org.jfree.chart.LegendItemSource[] { var42};
//     var35.setSources(var51);
//     org.jfree.chart.LegendItemSource[] var53 = var35.getSources();
//     org.jfree.chart.LegendItemSource[] var54 = var35.getSources();
//     java.lang.Object var55 = var35.clone();
//     var15.addSubtitle((org.jfree.chart.title.Title)var35);
//     org.jfree.chart.util.RectangleInsets var57 = var35.getPadding();
//     java.awt.Graphics2D var58 = null;
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.data.category.CategoryDataset var60 = null;
//     org.jfree.chart.axis.CategoryAxis var61 = null;
//     org.jfree.chart.axis.NumberAxis3D var63 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var64 = var63.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var65 = null;
//     var63.setMarkerBand(var65);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var67 = null;
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot(var60, var61, (org.jfree.chart.axis.ValueAxis)var63, var67);
//     org.jfree.data.Range var69 = null;
//     org.jfree.data.Range var71 = org.jfree.data.Range.expandToInclude(var69, 0.0d);
//     var63.setRange(var71, false, false);
//     java.lang.Object var75 = var35.draw(var58, var59, (java.lang.Object)var63);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers(1, var10);
//     org.jfree.chart.axis.ValueAxis var13 = var8.getRangeAxis(0);
//     boolean var14 = var13.isAxisLineVisible();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     java.awt.Font var19 = var17.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     var20.removeLegend();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     var20.setBorderPaint((java.awt.Paint)var24);
//     org.jfree.chart.util.RectangleInsets var26 = var20.getPadding();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     java.awt.Stroke var29 = var28.getBaseSectionOutlineStroke();
//     var28.setShadowXOffset(100.0d);
//     var28.setNoDataMessage("hi!");
//     java.awt.Stroke var34 = var28.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.ColumnArrangement var40 = new org.jfree.chart.block.ColumnArrangement(var36, var37, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28, (org.jfree.chart.block.Arrangement)var35, (org.jfree.chart.block.Arrangement)var40);
//     org.jfree.chart.event.TitleChangeListener var42 = null;
//     var41.removeChangeListener(var42);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     int var50 = var48.getDomainAxisIndex(var49);
//     var48.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     java.awt.geom.Point2D var55 = null;
//     var48.zoomDomainAxes(0.0d, var54, var55);
//     org.jfree.chart.LegendItemSource[] var57 = new org.jfree.chart.LegendItemSource[] { var48};
//     var41.setSources(var57);
//     org.jfree.chart.LegendItemSource[] var59 = var41.getSources();
//     org.jfree.chart.LegendItemSource[] var60 = var41.getSources();
//     java.lang.Object var61 = var41.clone();
//     java.awt.geom.Rectangle2D var62 = var41.getBounds();
//     org.jfree.chart.entity.ChartEntity var64 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var62, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var67 = var26.createInsetRectangle(var62, false, false);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     int var74 = var72.getDomainAxisIndex(var73);
//     var72.setRangeCrosshairValue(10.0d);
//     boolean var77 = var72.isDomainCrosshairVisible();
//     int var78 = var72.getWeight();
//     org.jfree.chart.util.RectangleEdge var80 = var72.getDomainAxisEdge(1);
//     double var81 = var13.lengthToJava2D(8.0d, var62, var80);
//     
//     // Checks the contract:  equals-hashcode on var48 and var72
//     assertTrue("Contract failed: equals-hashcode on var48 and var72", var48.equals(var72) ? var48.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var48
//     assertTrue("Contract failed: equals-hashcode on var72 and var48", var72.equals(var48) ? var72.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
//     var1.setTickLabelsVisible(true);
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var6 = var5.getRangeType();
//     var1.setRangeType(var6);
//     java.awt.Shape var8 = var1.getDownArrow();
//     org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var8, "java.awt.Color[r=0,g=0,b=1]", "Pie Plot");
//     org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity(var8, "Range[0.0,0.0]");
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.entity.PieSectionEntity var20 = new org.jfree.chart.entity.PieSectionEntity(var8, var14, (-16777216), 100, (java.lang.Comparable)0.025d, "", "ChartEntity: tooltip = hi!");
//     org.jfree.data.general.PieDataset var21 = var20.getDataset();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var22 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var23 = null;
//     java.lang.String var24 = var20.getImageMapAreaTag(var22, var23);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("0,0,-2,-2,2,-2,2,-2", var1);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockFrame var1 = var0.getFrame();
    boolean var3 = var0.equals((java.lang.Object)0.025d);
    var0.clear();
    java.lang.Object var5 = var0.clone();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var10 = var9.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var11 = null;
    var9.setMarkerBand(var11);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var6, var7, (org.jfree.chart.axis.ValueAxis)var9, var13);
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
    var9.setRange(var17, false, false);
    var9.setPositiveArrowVisible(true);
    var9.setLabelToolTip("");
    org.jfree.data.Range var25 = null;
    org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 0.0d);
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
    var29.setForegroundAlpha((-1.0f));
    var29.setCircular(true, true);
    java.awt.Paint var35 = var29.getOutlinePaint();
    boolean var36 = var27.equals((java.lang.Object)var35);
    var9.setRange(var27);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var42 = var41.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var43 = null;
    var41.setMarkerBand(var43);
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot(var38, var39, (org.jfree.chart.axis.ValueAxis)var41, var45);
    org.jfree.data.Range var47 = null;
    org.jfree.data.Range var49 = org.jfree.data.Range.expandToInclude(var47, 0.0d);
    var41.setRange(var49, false, false);
    org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(var27, var49);
    boolean var54 = var0.equals((java.lang.Object)var27);
    boolean var55 = var0.isEmpty();
    org.jfree.chart.util.RectangleInsets var56 = var0.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    double var7 = var1.getShadowXOffset();
    var1.setBackgroundAlpha((-1.0f));
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setPieIndex(100);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    var13.handleClick(100, 1, var18);
    org.jfree.chart.util.RectangleInsets var20 = var13.getInsets();
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
    java.awt.Font var24 = var22.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
    var25.removeLegend();
    var13.addChangeListener((org.jfree.chart.event.PlotChangeListener)var25);
    java.awt.Color var30 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var31 = var30.getColorSpace();
    java.lang.String var32 = var30.toString();
    var13.setOutlinePaint((java.awt.Paint)var30);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    org.jfree.chart.plot.PiePlotState var36 = var1.initialise(var10, var11, var13, (java.lang.Integer)1, var35);
    org.jfree.chart.plot.Plot var37 = var1.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var32.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setForegroundAlpha((-1.0f));
    var1.setCircular(true, true);
    var1.setNoDataMessage("");
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D("");
    var10.setUpperBound(1.0d);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
    java.awt.Stroke var20 = var19.getBaseSectionOutlineStroke();
    var19.setShadowXOffset(100.0d);
    var19.setNoDataMessage("hi!");
    java.awt.Stroke var25 = var19.getLabelOutlineStroke();
    var17.setDomainZeroBaselineStroke(var25);
    java.awt.Stroke var27 = var17.getRangeGridlineStroke();
    var10.setAxisLineStroke(var27);
    var1.setLabelOutlineStroke(var27);
    var1.setMaximumLabelWidth(8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 15);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 0.0d);
//     double var4 = var3.getLength();
//     double var5 = var3.getCentralValue();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     java.awt.Stroke var9 = var8.getBaseSectionOutlineStroke();
//     java.awt.Font var10 = var8.getNoDataMessageFont();
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var14 = var13.getColorSpace();
//     org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var10, (java.awt.Paint)var13);
//     org.jfree.chart.block.BlockContainer var16 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var21 = var20.getHeightRange();
//     org.jfree.chart.util.Size2D var22 = var16.arrange(var17, var20);
//     boolean var23 = var15.equals((java.lang.Object)var20);
//     double var24 = var20.getWidth();
//     org.jfree.chart.block.LengthConstraintType var25 = var20.getWidthConstraintType();
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var30 = org.jfree.data.Range.expandToInclude(var28, 0.0d);
//     double var31 = var30.getLength();
//     org.jfree.data.Range var32 = null;
//     org.jfree.data.Range var34 = org.jfree.data.Range.expandToInclude(var32, 0.0d);
//     org.jfree.data.Range var35 = org.jfree.data.Range.combine(var30, var34);
//     double var37 = var35.constrain(10.0d);
//     java.lang.Object var38 = null;
//     boolean var39 = var35.equals(var38);
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(0.0d, var35);
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     java.awt.Stroke var44 = var43.getBaseSectionOutlineStroke();
//     java.awt.Font var45 = var43.getNoDataMessageFont();
//     java.awt.Color var48 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var49 = var48.getColorSpace();
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var45, (java.awt.Paint)var48);
//     org.jfree.chart.block.BlockContainer var51 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var52 = null;
//     org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var56 = var55.getHeightRange();
//     org.jfree.chart.util.Size2D var57 = var51.arrange(var52, var55);
//     boolean var58 = var50.equals((java.lang.Object)var55);
//     double var59 = var55.getWidth();
//     org.jfree.chart.block.LengthConstraintType var60 = var55.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var61 = new org.jfree.chart.block.RectangleConstraint(0.05d, var3, var25, 1.0E-5d, var35, var60);
//     
//     // Checks the contract:  equals-hashcode on var8 and var43
//     assertTrue("Contract failed: equals-hashcode on var8 and var43", var8.equals(var43) ? var8.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var8
//     assertTrue("Contract failed: equals-hashcode on var43 and var8", var43.equals(var8) ? var43.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var51
//     assertTrue("Contract failed: equals-hashcode on var16 and var51", var16.equals(var51) ? var16.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var16
//     assertTrue("Contract failed: equals-hashcode on var51 and var16", var51.equals(var16) ? var51.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var57
//     assertTrue("Contract failed: equals-hashcode on var22 and var57", var22.equals(var57) ? var22.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var22
//     assertTrue("Contract failed: equals-hashcode on var57 and var22", var57.equals(var22) ? var57.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.block.Arrangement var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Pie 3D Plot", var1, var2);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.util.List var5 = var4.getSubtitles();
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     var4.handleClick(1, 100, var8);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var4.removeLegend();
//     org.jfree.chart.title.TextTitle var6 = var4.getTitle();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     java.awt.Stroke var10 = var9.getBaseSectionOutlineStroke();
//     var9.setShadowXOffset(100.0d);
//     var9.setNoDataMessage("hi!");
//     java.awt.Stroke var15 = var9.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.ColumnArrangement var21 = new org.jfree.chart.block.ColumnArrangement(var17, var18, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
//     org.jfree.chart.event.TitleChangeListener var23 = null;
//     var22.removeChangeListener(var23);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     int var31 = var29.getDomainAxisIndex(var30);
//     var29.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     java.awt.geom.Point2D var36 = null;
//     var29.zoomDomainAxes(0.0d, var35, var36);
//     org.jfree.chart.LegendItemSource[] var38 = new org.jfree.chart.LegendItemSource[] { var29};
//     var22.setSources(var38);
//     org.jfree.chart.LegendItemSource[] var40 = var22.getSources();
//     org.jfree.chart.LegendItemSource[] var41 = var22.getSources();
//     java.lang.Object var42 = var22.clone();
//     java.awt.geom.Rectangle2D var43 = var22.getBounds();
//     org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var43, "ChartChangeEventType.GENERAL");
//     org.jfree.data.xy.XYDataset var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
//     org.jfree.chart.axis.AxisSpace var51 = var50.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.util.RectangleAnchor var55 = null;
//     java.awt.geom.Point2D var56 = org.jfree.chart.util.RectangleAnchor.coordinates(var54, var55);
//     var50.zoomDomainAxes(100.0d, var53, var56, false);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleAnchor var62 = null;
//     java.awt.geom.Point2D var63 = org.jfree.chart.util.RectangleAnchor.coordinates(var61, var62);
//     var50.zoomRangeAxes(0.14d, var60, var63);
//     org.jfree.chart.ChartRenderingInfo var65 = null;
//     var4.draw(var7, var43, var63, var65);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setMaximumCategoryLabelWidthRatio((-1.0f));
    int var3 = var0.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setPieIndex(100);
    double var4 = var1.getLabelLinkMargin();
    var1.setSimpleLabels(false);
    double var7 = var1.getShadowYOffset();
    var1.setStartAngle((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 4.0d);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.data.general.WaferMapDataset var1 = null;
    var0.setDataset(var1);
    java.lang.Object var3 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Font var3 = var1.getNoDataMessageFont();
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    var4.removeLegend();
    java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
    var4.setBorderPaint((java.awt.Paint)var8);
    org.jfree.chart.util.RectangleInsets var10 = var4.getPadding();
    org.jfree.chart.title.TextTitle var11 = var4.getTitle();
    org.jfree.chart.ChartRenderingInfo var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var17 = var4.createBufferedImage((-16777216), 10, 4.0d, 1.0E-5d, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Font var2 = var0.getTickLabelFont(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = var0.getTimeline();
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     double var5 = var4.getLength();
//     var0.setRange(var4, true, true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     var15.removeLegend();
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
//     var15.setBorderPaint((java.awt.Paint)var19);
//     org.jfree.chart.util.RectangleInsets var21 = var15.getPadding();
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     var23.setShadowXOffset(100.0d);
//     var23.setNoDataMessage("hi!");
//     java.awt.Stroke var29 = var23.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var35);
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var36.removeChangeListener(var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     int var45 = var43.getDomainAxisIndex(var44);
//     var43.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var43.zoomDomainAxes(0.0d, var49, var50);
//     org.jfree.chart.LegendItemSource[] var52 = new org.jfree.chart.LegendItemSource[] { var43};
//     var36.setSources(var52);
//     org.jfree.chart.LegendItemSource[] var54 = var36.getSources();
//     org.jfree.chart.LegendItemSource[] var55 = var36.getSources();
//     java.lang.Object var56 = var36.clone();
//     java.awt.geom.Rectangle2D var57 = var36.getBounds();
//     org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var57, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var62 = var21.createInsetRectangle(var57, false, false);
//     org.jfree.data.category.CategoryDataset var63 = null;
//     org.jfree.chart.axis.CategoryAxis var64 = null;
//     org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var67 = var66.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var68 = null;
//     var66.setMarkerBand(var68);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var70 = null;
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var63, var64, (org.jfree.chart.axis.ValueAxis)var66, var70);
//     org.jfree.chart.util.Layer var73 = null;
//     java.util.Collection var74 = var71.getDomainMarkers(1, var73);
//     org.jfree.chart.axis.CategoryAxis var76 = null;
//     var71.setDomainAxis(1, var76, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var79 = null;
//     var71.setRenderer(var79, false);
//     org.jfree.chart.util.RectangleEdge var82 = var71.getDomainAxisEdge();
//     java.util.List var83 = var0.refreshTicks(var9, var10, var57, var82);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var8.datasetChanged(var12);
    org.jfree.chart.axis.AxisLocation var14 = var8.getDomainAxisLocation();
    org.jfree.chart.axis.CategoryAxis var16 = null;
    var8.setDomainAxis(15, var16, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     var0.setExplodePercent((java.lang.Comparable)10, 0.05d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     java.awt.Font var8 = var6.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var9.removeLegend();
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     var9.setBorderPaint((java.awt.Paint)var13);
//     org.jfree.chart.util.RectangleInsets var15 = var9.getPadding();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var17.setShadowXOffset(100.0d);
//     var17.setNoDataMessage("hi!");
//     java.awt.Stroke var23 = var17.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var30.removeChangeListener(var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     int var39 = var37.getDomainAxisIndex(var38);
//     var37.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Point2D var44 = null;
//     var37.zoomDomainAxes(0.0d, var43, var44);
//     org.jfree.chart.LegendItemSource[] var46 = new org.jfree.chart.LegendItemSource[] { var37};
//     var30.setSources(var46);
//     org.jfree.chart.LegendItemSource[] var48 = var30.getSources();
//     org.jfree.chart.LegendItemSource[] var49 = var30.getSources();
//     java.lang.Object var50 = var30.clone();
//     java.awt.geom.Rectangle2D var51 = var30.getBounds();
//     org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var51, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var56 = var15.createInsetRectangle(var51, false, false);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.chart.axis.AxisSpace var62 = var61.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     java.awt.geom.Rectangle2D var65 = null;
//     org.jfree.chart.util.RectangleAnchor var66 = null;
//     java.awt.geom.Point2D var67 = org.jfree.chart.util.RectangleAnchor.coordinates(var65, var66);
//     var61.zoomDomainAxes(100.0d, var64, var67, false);
//     org.jfree.chart.plot.PlotState var70 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     var0.draw(var4, var56, var67, var70, var71);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var19 = var18.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var20 = null;
    var18.setMarkerBand(var20);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var15, var16, (org.jfree.chart.axis.ValueAxis)var18, var22);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var23.getDomainMarkers(1, var25);
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var23.addRangeMarker((org.jfree.chart.plot.Marker)var28);
    org.jfree.chart.axis.AxisLocation var30 = var23.getRangeAxisLocation();
    var4.setDomainAxisLocation(var30);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.axis.CategoryAxis var34 = null;
    org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var37 = var36.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var38 = null;
    var36.setMarkerBand(var38);
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var33, var34, (org.jfree.chart.axis.ValueAxis)var36, var40);
    org.jfree.data.Range var42 = null;
    org.jfree.data.Range var44 = org.jfree.data.Range.expandToInclude(var42, 0.0d);
    var36.setRange(var44, false, false);
    var36.setPositiveArrowVisible(true);
    var36.setLabelToolTip("");
    org.jfree.chart.axis.NumberAxis3D var53 = new org.jfree.chart.axis.NumberAxis3D("");
    var53.setTickLabelsVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var32, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.axis.ValueAxis)var53, var56);
    org.jfree.data.Range var58 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint var4 = null;
//     java.awt.Paint[] var5 = new java.awt.Paint[] { var4};
//     java.awt.Stroke var6 = null;
//     java.awt.Stroke[] var7 = new java.awt.Stroke[] { var6};
//     java.awt.Stroke var8 = null;
//     java.awt.Stroke[] var9 = new java.awt.Stroke[] { var8};
//     java.awt.Shape var10 = null;
//     java.awt.Shape[] var11 = new java.awt.Shape[] { var10};
//     org.jfree.chart.plot.DefaultDrawingSupplier var12 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var5, var7, var9, var11);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     var15.setPieIndex(100);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     var15.handleClick(100, 1, var20);
//     org.jfree.chart.util.RectangleInsets var22 = var15.getInsets();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Stroke var25 = var24.getBaseSectionOutlineStroke();
//     java.awt.Font var26 = var24.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     var27.removeLegend();
//     var15.addChangeListener((org.jfree.chart.event.PlotChangeListener)var27);
//     org.jfree.chart.event.ChartProgressEvent var32 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(short)1, var27, 100, (-16777216));
//     org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var27);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     java.awt.Stroke var36 = var35.getBaseSectionOutlineStroke();
//     java.awt.Font var37 = var35.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var35);
//     org.jfree.chart.util.RectangleInsets var39 = var38.getPadding();
//     java.awt.Image var40 = null;
//     var38.setBackgroundImage(var40);
//     java.util.List var42 = var38.getSubtitles();
//     int var43 = var38.getBackgroundImageAlignment();
//     var33.setChart(var38);
//     
//     // Checks the contract:  equals-hashcode on var24 and var35
//     assertTrue("Contract failed: equals-hashcode on var24 and var35", var24.equals(var35) ? var24.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var24
//     assertTrue("Contract failed: equals-hashcode on var35 and var24", var35.equals(var24) ? var35.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = var0.getTimeline();
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 0.0d);
//     double var5 = var4.getLength();
//     var0.setRange(var4, true, true);
//     org.jfree.chart.axis.DateTickUnit var9 = var0.getTickUnit();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     var15.removeLegend();
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
//     var15.setBorderPaint((java.awt.Paint)var19);
//     org.jfree.chart.util.RectangleInsets var21 = var15.getPadding();
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     var23.setShadowXOffset(100.0d);
//     var23.setNoDataMessage("hi!");
//     java.awt.Stroke var29 = var23.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var35);
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var36.removeChangeListener(var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     int var45 = var43.getDomainAxisIndex(var44);
//     var43.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var43.zoomDomainAxes(0.0d, var49, var50);
//     org.jfree.chart.LegendItemSource[] var52 = new org.jfree.chart.LegendItemSource[] { var43};
//     var36.setSources(var52);
//     org.jfree.chart.LegendItemSource[] var54 = var36.getSources();
//     org.jfree.chart.LegendItemSource[] var55 = var36.getSources();
//     java.lang.Object var56 = var36.clone();
//     java.awt.geom.Rectangle2D var57 = var36.getBounds();
//     org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var57, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var62 = var21.createInsetRectangle(var57, false, false);
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var63, var64, var65, var66);
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.PiePlot var69 = new org.jfree.chart.plot.PiePlot(var68);
//     java.awt.Stroke var70 = var69.getBaseSectionOutlineStroke();
//     var69.setShadowXOffset(100.0d);
//     var69.setNoDataMessage("hi!");
//     java.awt.Stroke var75 = var69.getLabelOutlineStroke();
//     var67.setDomainZeroBaselineStroke(var75);
//     java.awt.Paint var77 = var67.getDomainGridlinePaint();
//     org.jfree.chart.util.RectangleEdge var79 = var67.getRangeAxisEdge(1);
//     boolean var80 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var79);
//     double var81 = var0.java2DToValue(3.0d, var57, var79);
//     
//     // Checks the contract:  equals-hashcode on var23 and var69
//     assertTrue("Contract failed: equals-hashcode on var23 and var69", var23.equals(var69) ? var23.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var23
//     assertTrue("Contract failed: equals-hashcode on var69 and var23", var69.equals(var23) ? var69.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleAnchor var9 = null;
    java.awt.geom.Point2D var10 = org.jfree.chart.util.RectangleAnchor.coordinates(var8, var9);
    var4.zoomDomainAxes(100.0d, var7, var10, false);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleAnchor var16 = null;
    java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
    var4.zoomRangeAxes(0.14d, var14, var17);
    java.awt.Paint var19 = var4.getRangeCrosshairPaint();
    org.jfree.chart.axis.ValueAxis var20 = var4.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var4 = var3.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var5 = null;
//     var3.setMarkerBand(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getDomainMarkers((-1), var10);
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Stroke var19 = var18.getBaseSectionOutlineStroke();
//     var18.setShadowXOffset(100.0d);
//     var18.setNoDataMessage("hi!");
//     java.awt.Stroke var24 = var18.getLabelOutlineStroke();
//     var16.setDomainZeroBaselineStroke(var24);
//     java.awt.Paint var26 = var16.getDomainGridlinePaint();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var31 = var30.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var32 = null;
//     var30.setMarkerBand(var32);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var30, var34);
//     org.jfree.chart.util.Layer var37 = null;
//     java.util.Collection var38 = var35.getDomainMarkers(1, var37);
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var35.addRangeMarker((org.jfree.chart.plot.Marker)var40);
//     org.jfree.chart.axis.AxisLocation var42 = var35.getRangeAxisLocation();
//     var16.setDomainAxisLocation(var42);
//     var8.setDomainAxisLocation(var42, true);
//     java.awt.Paint var46 = var8.getRangeGridlinePaint();
//     java.awt.Graphics2D var47 = null;
//     org.jfree.data.general.PieDataset var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot(var48);
//     java.awt.Stroke var50 = var49.getBaseSectionOutlineStroke();
//     var49.setShadowXOffset(100.0d);
//     var49.setNoDataMessage("hi!");
//     java.awt.Stroke var55 = var49.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var49, (org.jfree.chart.block.Arrangement)var56, (org.jfree.chart.block.Arrangement)var61);
//     org.jfree.chart.event.TitleChangeListener var63 = null;
//     var62.removeChangeListener(var63);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var65, var66, var67, var68);
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     int var71 = var69.getDomainAxisIndex(var70);
//     var69.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     java.awt.geom.Point2D var76 = null;
//     var69.zoomDomainAxes(0.0d, var75, var76);
//     org.jfree.chart.LegendItemSource[] var78 = new org.jfree.chart.LegendItemSource[] { var69};
//     var62.setSources(var78);
//     org.jfree.chart.LegendItemSource[] var80 = var62.getSources();
//     org.jfree.chart.LegendItemSource[] var81 = var62.getSources();
//     java.lang.Object var82 = var62.clone();
//     java.awt.geom.Rectangle2D var83 = var62.getBounds();
//     org.jfree.chart.entity.ChartEntity var85 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var83, "ChartChangeEventType.GENERAL");
//     var8.drawBackground(var47, var83);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     var4.clearRangeAxes();
//     var4.clearDomainMarkers();
//     org.jfree.chart.axis.AxisLocation var17 = var4.getRangeAxisLocation();
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     int var19 = var4.getRangeAxisIndex(var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     java.awt.Stroke var27 = var26.getBaseSectionOutlineStroke();
//     var26.setShadowXOffset(100.0d);
//     var26.setNoDataMessage("hi!");
//     java.awt.Stroke var32 = var26.getLabelOutlineStroke();
//     var24.setDomainZeroBaselineStroke(var32);
//     java.awt.Paint var34 = var24.getDomainGridlinePaint();
//     java.awt.Paint var35 = var24.getDomainZeroBaselinePaint();
//     var24.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D("");
//     var39.setTickLabelsVisible(true);
//     var39.setLowerBound(1.0d);
//     org.jfree.chart.axis.ValueAxis[] var44 = new org.jfree.chart.axis.ValueAxis[] { var39};
//     var24.setDomainAxes(var44);
//     var4.setDomainAxes(var44);
//     
//     // Checks the contract:  equals-hashcode on var6 and var26
//     assertTrue("Contract failed: equals-hashcode on var6 and var26", var6.equals(var26) ? var6.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var6
//     assertTrue("Contract failed: equals-hashcode on var26 and var6", var26.equals(var6) ? var26.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "hi!", var3, "hi!", "java.awt.Color[r=0,g=0,b=1]", "hi!");
    var7.setLicenceText("");
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var14 = var13.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var15 = null;
    var13.setMarkerBand(var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var10, var11, (org.jfree.chart.axis.ValueAxis)var13, var17);
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var18.getDomainMarkers(1, var20);
    org.jfree.chart.axis.CategoryAxis var23 = null;
    var18.setDomainAxis(1, var23, false);
    var18.setAnchorValue((-1.0d), true);
    boolean var29 = var18.isRangeCrosshairLockedOnData();
    var18.setDomainGridlinesVisible(true);
    java.util.List var32 = var18.getAnnotations();
    var7.setContributors(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.lang.String var1 = var0.getID();
//     var0.setPadding(1.0d, 0.0d, 0.0d, 10.0d);
//     org.jfree.chart.block.Arrangement var7 = var0.getArrangement();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     java.awt.Paint var14 = var13.getRangeTickBandPaint();
//     java.awt.Image var15 = var13.getBackgroundImage();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var20 = var19.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var21 = null;
//     var19.setMarkerBand(var21);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var16, var17, (org.jfree.chart.axis.ValueAxis)var19, var23);
//     org.jfree.chart.util.Layer var26 = null;
//     java.util.Collection var27 = var24.getDomainMarkers(1, var26);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var24.addRangeMarker((org.jfree.chart.plot.Marker)var29);
//     java.awt.Stroke var31 = var29.getOutlineStroke();
//     var13.setDomainZeroBaselineStroke(var31);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.plot.RingPlot var34 = new org.jfree.chart.plot.RingPlot();
//     var34.setInnerSeparatorExtension(0.0d);
//     var34.setInnerSeparatorExtension(100.0d);
//     java.awt.Graphics2D var39 = null;
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     java.awt.Stroke var42 = var41.getBaseSectionOutlineStroke();
//     var41.setShadowXOffset(100.0d);
//     var41.setNoDataMessage("hi!");
//     java.awt.Stroke var47 = var41.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var48 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var49 = null;
//     org.jfree.chart.util.VerticalAlignment var50 = null;
//     org.jfree.chart.block.ColumnArrangement var53 = new org.jfree.chart.block.ColumnArrangement(var49, var50, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41, (org.jfree.chart.block.Arrangement)var48, (org.jfree.chart.block.Arrangement)var53);
//     org.jfree.chart.event.TitleChangeListener var55 = null;
//     var54.removeChangeListener(var55);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     int var63 = var61.getDomainAxisIndex(var62);
//     var61.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     java.awt.geom.Point2D var68 = null;
//     var61.zoomDomainAxes(0.0d, var67, var68);
//     org.jfree.chart.LegendItemSource[] var70 = new org.jfree.chart.LegendItemSource[] { var61};
//     var54.setSources(var70);
//     org.jfree.chart.LegendItemSource[] var72 = var54.getSources();
//     org.jfree.chart.LegendItemSource[] var73 = var54.getSources();
//     java.lang.Object var74 = var54.clone();
//     java.awt.geom.Rectangle2D var75 = var54.getBounds();
//     org.jfree.chart.entity.ChartEntity var77 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var75, "ChartChangeEventType.GENERAL");
//     org.jfree.data.general.PieDataset var78 = null;
//     org.jfree.chart.plot.PiePlot var79 = new org.jfree.chart.plot.PiePlot(var78);
//     java.awt.Stroke var80 = var79.getBaseSectionOutlineStroke();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var81 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
//     java.text.AttributedString var83 = var81.getAttributedLabel(10);
//     var79.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var81);
//     java.lang.Integer var85 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var86 = null;
//     org.jfree.chart.plot.PiePlotState var87 = var34.initialise(var39, var75, var79, var85, var86);
//     org.jfree.chart.block.BlockContainer var88 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockFrame var89 = var88.getFrame();
//     java.util.List var90 = var88.getBlocks();
//     var13.drawRangeTickBands(var33, var75, var90);
//     java.lang.Object var92 = null;
//     java.lang.Object var93 = var0.draw(var8, var75, var92);
// 
//   }

//  public void test460() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
//
//
//    java.lang.Class var0 = null;
//    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//
//  }
//
  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers((-1), var10);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var18 = var17.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var19 = null;
    var17.setMarkerBand(var19);
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var17, var21);
    org.jfree.data.Range var23 = null;
    org.jfree.data.Range var25 = org.jfree.data.Range.expandToInclude(var23, 0.0d);
    var17.setRange(var25, false, false);
    var17.setPositiveArrowVisible(true);
    var17.setLabelToolTip("");
    org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("");
    var34.setTickLabelsVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var34, var37);
    boolean var39 = var34.isVerticalTickLabels();
    var34.setRangeAboutValue(8.0d, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var34, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var5 = var4.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var6 = null;
    var4.setMarkerBand(var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var4, var8);
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    var4.setRange(var12, false, false);
    var4.setPositiveArrowVisible(true);
    var4.setLabelToolTip("");
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
    var21.setTickLabelsVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var21, var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var27 = var25.getQuadrantPaint(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, var1);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.AttributedString var3 = var1.getAttributedLabel(0);
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     boolean var9 = var8.isDomainCrosshairLockedOnData();
//     org.jfree.chart.util.RectangleEdge var11 = var8.getDomainAxisEdge((-16777216));
//     boolean var12 = var1.equals((java.lang.Object)var8);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.NumberAxis3D var17 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var18 = var17.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var19 = null;
//     var17.setMarkerBand(var19);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var14, var15, (org.jfree.chart.axis.ValueAxis)var17, var21);
//     org.jfree.data.Range var23 = null;
//     org.jfree.data.Range var25 = org.jfree.data.Range.expandToInclude(var23, 0.0d);
//     var17.setRange(var25, false, false);
//     var17.setPositiveArrowVisible(true);
//     var17.setLabelToolTip("");
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D("");
//     var34.setTickLabelsVisible(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var34, var37);
//     org.jfree.chart.plot.Plot var39 = var17.getPlot();
//     org.jfree.data.Range var40 = var17.getRange();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = null;
//     org.jfree.chart.axis.NumberAxis3D var44 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var45 = var44.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var46 = null;
//     var44.setMarkerBand(var46);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var41, var42, (org.jfree.chart.axis.ValueAxis)var44, var48);
//     org.jfree.data.Range var50 = null;
//     org.jfree.data.Range var52 = org.jfree.data.Range.expandToInclude(var50, 0.0d);
//     var44.setRange(var52, false, false);
//     var44.setPositiveArrowVisible(true);
//     var44.setLabelToolTip("");
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var61 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.AttributedString var63 = var61.getAttributedLabel(0);
//     java.text.NumberFormat var64 = var61.getNumberFormat();
//     var44.setNumberFormatOverride(var64);
//     var17.setNumberFormatOverride(var64);
//     boolean var67 = var1.equals((java.lang.Object)var17);
//     
//     // Checks the contract:  equals-hashcode on var1 and var61
//     assertTrue("Contract failed: equals-hashcode on var1 and var61", var1.equals(var61) ? var1.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var1
//     assertTrue("Contract failed: equals-hashcode on var61 and var1", var61.equals(var1) ? var61.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setForegroundAlpha((-1.0f));
//     var1.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.ChartChangeEventType var8 = null;
//     var7.setType(var8);
//     java.lang.String var10 = var7.toString();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getPadding();
//     var7.setChart(var15);
//     var15.setBorderVisible(true);
//     java.awt.Stroke var20 = var15.getBorderStroke();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     var22.setShadowXOffset(100.0d);
//     var22.setNoDataMessage("hi!");
//     java.awt.Stroke var28 = var22.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var22, (org.jfree.chart.block.Arrangement)var29, (org.jfree.chart.block.Arrangement)var34);
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var35.removeChangeListener(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     int var44 = var42.getDomainAxisIndex(var43);
//     var42.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     java.awt.geom.Point2D var49 = null;
//     var42.zoomDomainAxes(0.0d, var48, var49);
//     org.jfree.chart.LegendItemSource[] var51 = new org.jfree.chart.LegendItemSource[] { var42};
//     var35.setSources(var51);
//     org.jfree.chart.LegendItemSource[] var53 = var35.getSources();
//     org.jfree.chart.LegendItemSource[] var54 = var35.getSources();
//     java.lang.Object var55 = var35.clone();
//     var15.addSubtitle((org.jfree.chart.title.Title)var35);
//     boolean var57 = var15.getAntiAlias();
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.PiePlot var59 = new org.jfree.chart.plot.PiePlot(var58);
//     java.awt.Stroke var60 = var59.getBaseSectionOutlineStroke();
//     var59.setShadowXOffset(100.0d);
//     var59.setNoDataMessage("hi!");
//     java.awt.Stroke var65 = var59.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var66 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var67 = null;
//     org.jfree.chart.util.VerticalAlignment var68 = null;
//     org.jfree.chart.block.ColumnArrangement var71 = new org.jfree.chart.block.ColumnArrangement(var67, var68, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59, (org.jfree.chart.block.Arrangement)var66, (org.jfree.chart.block.Arrangement)var71);
//     org.jfree.chart.event.TitleChangeListener var73 = null;
//     var72.removeChangeListener(var73);
//     org.jfree.data.xy.XYDataset var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var78 = null;
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot(var75, var76, var77, var78);
//     org.jfree.chart.axis.ValueAxis var80 = null;
//     int var81 = var79.getDomainAxisIndex(var80);
//     var79.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     java.awt.geom.Point2D var86 = null;
//     var79.zoomDomainAxes(0.0d, var85, var86);
//     org.jfree.chart.LegendItemSource[] var88 = new org.jfree.chart.LegendItemSource[] { var79};
//     var72.setSources(var88);
//     org.jfree.chart.LegendItemSource[] var90 = var72.getSources();
//     org.jfree.chart.LegendItemSource[] var91 = var72.getSources();
//     var15.addSubtitle((org.jfree.chart.title.Title)var72);
//     
//     // Checks the contract:  equals-hashcode on var22 and var59
//     assertTrue("Contract failed: equals-hashcode on var22 and var59", var22.equals(var59) ? var22.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var22
//     assertTrue("Contract failed: equals-hashcode on var59 and var22", var59.equals(var22) ? var59.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var66
//     assertTrue("Contract failed: equals-hashcode on var29 and var66", var29.equals(var66) ? var29.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var71
//     assertTrue("Contract failed: equals-hashcode on var34 and var71", var34.equals(var71) ? var34.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var29
//     assertTrue("Contract failed: equals-hashcode on var66 and var29", var66.equals(var29) ? var66.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var34
//     assertTrue("Contract failed: equals-hashcode on var71 and var34", var71.equals(var34) ? var71.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var79
//     assertTrue("Contract failed: equals-hashcode on var42 and var79", var42.equals(var79) ? var42.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var42
//     assertTrue("Contract failed: equals-hashcode on var79 and var42", var79.equals(var42) ? var79.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    double var2 = var1.getPieCenterY();
    int var3 = var1.getPassesRequired();
    var1.setPieHRadius(0.025d);
    var1.setTotal((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.util.Layer var19 = null;
//     java.util.Collection var20 = var4.getDomainMarkers(100, var19);
//     org.jfree.chart.plot.Marker var21 = null;
//     org.jfree.chart.util.Layer var22 = null;
//     boolean var23 = var4.removeDomainMarker(var21, var22);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     var0.setLimit(0.0d);
//     org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var5 = var4.getValue();
//     org.jfree.chart.util.RectangleInsets var6 = var4.getLabelOffset();
//     java.awt.Stroke var7 = var4.getOutlineStroke();
//     java.awt.Paint var8 = var4.getLabelPaint();
//     var0.setAggregatedItemsPaint(var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setForegroundAlpha((-1.0f));
//     var11.setCircular(true, true);
//     org.jfree.chart.event.PlotChangeEvent var17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var11);
//     org.jfree.chart.event.ChartChangeEventType var18 = null;
//     var17.setType(var18);
//     java.lang.String var20 = var17.toString();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Stroke var23 = var22.getBaseSectionOutlineStroke();
//     java.awt.Font var24 = var22.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var22);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getPadding();
//     var17.setChart(var25);
//     var25.setBorderVisible(true);
//     java.awt.Stroke var30 = var25.getBorderStroke();
//     var25.setAntiAlias(true);
//     var0.setPieChart(var25);
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var38 = var37.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var39 = null;
//     var37.setMarkerBand(var39);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var34, var35, (org.jfree.chart.axis.ValueAxis)var37, var41);
//     org.jfree.chart.util.Layer var44 = null;
//     java.util.Collection var45 = var42.getDomainMarkers(1, var44);
//     var42.clearRangeAxes();
//     java.awt.Paint var47 = var42.getOutlinePaint();
//     var25.setBackgroundPaint(var47);
//     org.jfree.chart.plot.PolarPlot var49 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.general.DatasetChangeEvent var50 = null;
//     var49.datasetChanged(var50);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.NumberAxis3D var55 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var56 = var55.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var57 = null;
//     var55.setMarkerBand(var57);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var52, var53, (org.jfree.chart.axis.ValueAxis)var55, var59);
//     org.jfree.chart.util.Layer var62 = null;
//     java.util.Collection var63 = var60.getDomainMarkers(1, var62);
//     org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     var60.addRangeMarker((org.jfree.chart.plot.Marker)var65);
//     java.awt.Stroke var67 = var65.getOutlineStroke();
//     var49.setRadiusGridlineStroke(var67);
//     var25.setBorderStroke(var67);
//     
//     // Checks the contract:  equals-hashcode on var4 and var65
//     assertTrue("Contract failed: equals-hashcode on var4 and var65", var4.equals(var65) ? var4.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var4
//     assertTrue("Contract failed: equals-hashcode on var65 and var4", var65.equals(var4) ? var65.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var15.setShadowXOffset(100.0d);
    var15.setNoDataMessage("hi!");
    java.awt.Stroke var21 = var15.getLabelOutlineStroke();
    var13.setDomainZeroBaselineStroke(var21);
    java.awt.Stroke var23 = var13.getRangeGridlineStroke();
    var8.setRangeGridlineStroke(var23);
    org.jfree.chart.event.RendererChangeEvent var25 = null;
    var8.rendererChanged(var25);
    var8.setRangeCrosshairLockedOnData(false);
    java.awt.Paint var29 = var8.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    boolean var2 = var0.equals((java.lang.Object)1L);
    var0.clear();
    boolean var5 = var0.containsKey((java.lang.Comparable)8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 0.0d);
    var3.setRange(var11, false, false);
    var3.setPositiveArrowVisible(true);
    java.awt.Stroke var17 = var3.getTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setMaximumCategoryLabelWidthRatio((-1.0f));
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     java.awt.Font var8 = var6.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var9.removeLegend();
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     var9.setBorderPaint((java.awt.Paint)var13);
//     org.jfree.chart.util.RectangleInsets var15 = var9.getPadding();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     var17.setShadowXOffset(100.0d);
//     var17.setNoDataMessage("hi!");
//     java.awt.Stroke var23 = var17.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var30.removeChangeListener(var31);
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var33, var34, var35, var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     int var39 = var37.getDomainAxisIndex(var38);
//     var37.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Point2D var44 = null;
//     var37.zoomDomainAxes(0.0d, var43, var44);
//     org.jfree.chart.LegendItemSource[] var46 = new org.jfree.chart.LegendItemSource[] { var37};
//     var30.setSources(var46);
//     org.jfree.chart.LegendItemSource[] var48 = var30.getSources();
//     org.jfree.chart.LegendItemSource[] var49 = var30.getSources();
//     java.lang.Object var50 = var30.clone();
//     java.awt.geom.Rectangle2D var51 = var30.getBounds();
//     org.jfree.chart.entity.ChartEntity var53 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var51, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var56 = var15.createInsetRectangle(var51, false, false);
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.NumberAxis3D var60 = new org.jfree.chart.axis.NumberAxis3D("");
//     org.jfree.data.RangeType var61 = var60.getRangeType();
//     org.jfree.chart.axis.MarkerAxisBand var62 = null;
//     var60.setMarkerBand(var62);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var64 = null;
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot(var57, var58, (org.jfree.chart.axis.ValueAxis)var60, var64);
//     org.jfree.data.xy.XYDataset var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var66, var67, var68, var69);
//     org.jfree.data.general.PieDataset var71 = null;
//     org.jfree.chart.plot.PiePlot var72 = new org.jfree.chart.plot.PiePlot(var71);
//     java.awt.Stroke var73 = var72.getBaseSectionOutlineStroke();
//     var72.setShadowXOffset(100.0d);
//     var72.setNoDataMessage("hi!");
//     java.awt.Stroke var78 = var72.getLabelOutlineStroke();
//     var70.setDomainZeroBaselineStroke(var78);
//     java.awt.Stroke var80 = var70.getRangeGridlineStroke();
//     var65.setRangeGridlineStroke(var80);
//     var65.mapDatasetToRangeAxis(0, 1);
//     org.jfree.chart.util.RectangleEdge var86 = var65.getDomainAxisEdge((-1));
//     boolean var87 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var86);
//     double var88 = var0.getCategoryMiddle(100, 0, var51, var86);
//     
//     // Checks the contract:  equals-hashcode on var17 and var72
//     assertTrue("Contract failed: equals-hashcode on var17 and var72", var17.equals(var72) ? var17.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var17
//     assertTrue("Contract failed: equals-hashcode on var72 and var17", var72.equals(var17) ? var72.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    org.jfree.chart.util.RectangleEdge var15 = var8.getRangeAxisEdge();
    var8.clearRangeMarkers();
    var8.setDomainGridlinesVisible(false);
    var8.clearDomainMarkers(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "java.awt.Color[r=0,g=0,b=1]", "");
    java.lang.String var5 = var4.getName();
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var16 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!");
    var11.addLibrary((org.jfree.chart.ui.Library)var16);
    java.lang.String var18 = var11.getLicenceName();
    var4.addOptionalLibrary((org.jfree.chart.ui.Library)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "hi!"+ "'", var18.equals("hi!"));

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setPieIndex(100);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var2.setBaseSectionOutlineStroke(var7);
//     org.jfree.chart.util.RectangleInsets var9 = var2.getLabelPadding();
//     var0.setTickLabelInsets(var9);
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 0.0d);
//     double var14 = var13.getLength();
//     org.jfree.data.Range var15 = null;
//     org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 0.0d);
//     org.jfree.data.Range var18 = org.jfree.data.Range.combine(var13, var17);
//     var0.setRange(var18, true, true);
//     double var22 = var0.getLabelAngle();
//     var0.zoomRange(0.14d, 2.0d);
//     java.text.DateFormat var26 = null;
//     var0.setDateFormatOverride(var26);
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     var30.setPieIndex(100);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Stroke var35 = var34.getBaseSectionOutlineStroke();
//     var30.setBaseSectionOutlineStroke(var35);
//     org.jfree.chart.util.RectangleInsets var37 = var30.getLabelPadding();
//     var28.setTickLabelInsets(var37);
//     org.jfree.data.Range var39 = null;
//     org.jfree.data.Range var41 = org.jfree.data.Range.expandToInclude(var39, 0.0d);
//     double var42 = var41.getLength();
//     org.jfree.data.Range var43 = null;
//     org.jfree.data.Range var45 = org.jfree.data.Range.expandToInclude(var43, 0.0d);
//     org.jfree.data.Range var46 = org.jfree.data.Range.combine(var41, var45);
//     var28.setRange(var46, true, true);
//     double var50 = var28.getLabelAngle();
//     var28.setRange(0.0d, 1.0d);
//     java.util.Date var54 = var28.getMinimumDate();
//     var0.setMaximumDate(var54);
//     
//     // Checks the contract:  equals-hashcode on var2 and var30
//     assertTrue("Contract failed: equals-hashcode on var2 and var30", var2.equals(var30) ? var2.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var2
//     assertTrue("Contract failed: equals-hashcode on var30 and var2", var30.equals(var2) ? var30.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setPieIndex(100);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     java.awt.Stroke var6 = var5.getBaseSectionOutlineStroke();
//     var1.setBaseSectionOutlineStroke(var6);
//     org.jfree.chart.util.RectangleInsets var8 = var1.getLabelPadding();
//     double var9 = var1.getShadowYOffset();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
//     java.lang.String var12 = var11.getID();
//     var11.setPadding(1.0d, 0.0d, 0.0d, 10.0d);
//     org.jfree.chart.block.Arrangement var18 = var11.getArrangement();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     java.awt.Stroke var21 = var20.getBaseSectionOutlineStroke();
//     var20.setShadowXOffset(100.0d);
//     var20.setNoDataMessage("hi!");
//     double var26 = var20.getShadowXOffset();
//     var20.setPieIndex(1);
//     boolean var29 = var20.getIgnoreZeroValues();
//     boolean var30 = var11.equals((java.lang.Object)var20);
//     java.awt.geom.Rectangle2D var31 = var11.getBounds();
//     org.jfree.chart.plot.PolarPlot var32 = new org.jfree.chart.plot.PolarPlot();
//     var32.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var34 = var32.getLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     boolean var43 = var42.isDomainCrosshairLockedOnData();
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     java.awt.Stroke var47 = var46.getBaseSectionOutlineStroke();
//     java.awt.Font var48 = var46.getNoDataMessageFont();
//     java.awt.Color var51 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var52 = var51.getColorSpace();
//     java.awt.Color var53 = var51.darker();
//     org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("", var48, (java.awt.Paint)var51);
//     var42.setDomainCrosshairPaint((java.awt.Paint)var51);
//     org.jfree.chart.axis.AxisSpace var56 = var42.getFixedRangeAxisSpace();
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     java.awt.geom.Rectangle2D var60 = null;
//     org.jfree.chart.util.RectangleAnchor var61 = null;
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.RectangleAnchor.coordinates(var60, var61);
//     var42.zoomDomainAxes(0.025d, (-1.0d), var59, var62);
//     var32.zoomDomainAxes(0.0d, 0.0d, var37, var62);
//     org.jfree.chart.plot.PlotState var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     var1.draw(var10, var31, var62, var65, var66);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]", "", "", var3, "", "Pie Plot", "");
    var7.setLicenceText("Range[0.0,0.0]");
    var7.setInfo("Range[0.0,0.0]");

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     var4.clearRangeAxes();
//     org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot();
//     var16.clearCornerTextItems();
//     org.jfree.chart.LegendItemCollection var18 = var16.getLegendItems();
//     var4.setFixedLegendItems(var18);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = var4.getRenderer(255);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setForegroundAlpha((-1.0f));
//     var25.setCircular(true, true);
//     java.awt.Paint var31 = var25.getLabelShadowPaint();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Stroke var34 = var33.getBaseSectionOutlineStroke();
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     java.awt.Stroke var42 = var41.getBaseSectionOutlineStroke();
//     var41.setShadowXOffset(100.0d);
//     var41.setNoDataMessage("hi!");
//     java.awt.Stroke var47 = var41.getLabelOutlineStroke();
//     var39.setDomainZeroBaselineStroke(var47);
//     java.awt.Paint var49 = var39.getDomainGridlinePaint();
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var52 = var51.getValue();
//     org.jfree.chart.util.RectangleInsets var53 = var51.getLabelOffset();
//     java.awt.Stroke var54 = var51.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d, var31, var34, var49, var54, 0.0f);
//     org.jfree.chart.util.Layer var57 = null;
//     boolean var58 = var4.removeRangeMarker((-16777216), (org.jfree.chart.plot.Marker)var56, var57);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    var8.clearRangeAxes();
    java.awt.Paint var13 = var8.getOutlinePaint();
    org.jfree.data.category.CategoryDataset var14 = null;
    var8.setDataset(var14);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var8.getRangeMarkers(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.AxisSpace var6 = var5.getFixedDomainAxisSpace();
    org.jfree.chart.plot.PlotOrientation var7 = var5.getOrientation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var8 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    var8.setDomainAxis(1, var13, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    var8.setRenderer(var16, false);
    org.jfree.chart.util.RectangleEdge var19 = var8.getDomainAxisEdge();
    java.awt.Stroke var20 = var8.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    var4.clearRangeAxes();
    org.jfree.chart.plot.PolarPlot var16 = new org.jfree.chart.plot.PolarPlot();
    var16.clearCornerTextItems();
    org.jfree.chart.LegendItemCollection var18 = var16.getLegendItems();
    var4.setFixedLegendItems(var18);
    int var20 = var4.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getPadding();
//     java.awt.Image var6 = null;
//     var4.setBackgroundImage(var6);
//     java.util.List var8 = var4.getSubtitles();
//     int var9 = var4.getBackgroundImageAlignment();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Stroke var13 = var12.getBaseSectionOutlineStroke();
//     java.awt.Font var14 = var12.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     var15.removeLegend();
//     java.awt.Color var19 = java.awt.Color.getColor("hi!", 1);
//     var15.setBorderPaint((java.awt.Paint)var19);
//     org.jfree.chart.util.RectangleInsets var21 = var15.getPadding();
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Stroke var24 = var23.getBaseSectionOutlineStroke();
//     var23.setShadowXOffset(100.0d);
//     var23.setNoDataMessage("hi!");
//     java.awt.Stroke var29 = var23.getLabelOutlineStroke();
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var31 = null;
//     org.jfree.chart.util.VerticalAlignment var32 = null;
//     org.jfree.chart.block.ColumnArrangement var35 = new org.jfree.chart.block.ColumnArrangement(var31, var32, 100.0d, (-1.0d));
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var35);
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var36.removeChangeListener(var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     int var45 = var43.getDomainAxisIndex(var44);
//     var43.setRangeCrosshairValue(10.0d);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var43.zoomDomainAxes(0.0d, var49, var50);
//     org.jfree.chart.LegendItemSource[] var52 = new org.jfree.chart.LegendItemSource[] { var43};
//     var36.setSources(var52);
//     org.jfree.chart.LegendItemSource[] var54 = var36.getSources();
//     org.jfree.chart.LegendItemSource[] var55 = var36.getSources();
//     java.lang.Object var56 = var36.clone();
//     java.awt.geom.Rectangle2D var57 = var36.getBounds();
//     org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var57, "ChartChangeEventType.GENERAL");
//     java.awt.geom.Rectangle2D var62 = var21.createInsetRectangle(var57, false, false);
//     var4.draw(var10, var57);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Stroke var3 = var2.getBaseSectionOutlineStroke();
//     java.awt.Font var4 = var2.getNoDataMessageFont();
//     java.awt.Color var7 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var8 = var7.getColorSpace();
//     java.awt.Color var9 = var7.darker();
//     org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("", var4, (java.awt.Paint)var7);
//     java.awt.Font var11 = var10.getFont();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.text.TextAnchor var13 = null;
//     float var14 = var10.calculateBaselineOffset(var12, var13);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
//     var6.setShadowXOffset(100.0d);
//     var6.setNoDataMessage("hi!");
//     java.awt.Stroke var12 = var6.getLabelOutlineStroke();
//     var4.setDomainZeroBaselineStroke(var12);
//     java.awt.Paint var14 = var4.getDomainGridlinePaint();
//     java.awt.Paint var15 = var4.getDomainZeroBaselinePaint();
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D("");
//     var19.setTickLabelsVisible(true);
//     var19.setLowerBound(1.0d);
//     org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var19};
//     var4.setDomainAxes(var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     java.awt.Stroke var33 = var32.getBaseSectionOutlineStroke();
//     var32.setShadowXOffset(100.0d);
//     var32.setNoDataMessage("hi!");
//     java.awt.Stroke var38 = var32.getLabelOutlineStroke();
//     var30.setDomainZeroBaselineStroke(var38);
//     java.awt.Paint var40 = var30.getDomainGridlinePaint();
//     java.awt.Paint var41 = var30.getDomainZeroBaselinePaint();
//     org.jfree.chart.plot.SeriesRenderingOrder var42 = var30.getSeriesRenderingOrder();
//     var4.setSeriesRenderingOrder(var42);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    java.awt.Stroke var16 = var15.getBaseSectionOutlineStroke();
    var15.setShadowXOffset(100.0d);
    var15.setNoDataMessage("hi!");
    java.awt.Stroke var21 = var15.getLabelOutlineStroke();
    var13.setDomainZeroBaselineStroke(var21);
    java.awt.Stroke var23 = var13.getRangeGridlineStroke();
    var8.setRangeGridlineStroke(var23);
    org.jfree.chart.axis.CategoryAxis var25 = null;
    java.util.List var26 = var8.getCategoriesForAxis(var25);
    var8.clearRangeMarkers(10);
    var8.setAnchorValue(0.025d, false);
    var8.configureDomainAxes();
    java.awt.Paint var33 = var8.getRangeGridlinePaint();
    int var34 = var8.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 15);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Stroke var7 = var6.getBaseSectionOutlineStroke();
    var6.setShadowXOffset(100.0d);
    var6.setNoDataMessage("hi!");
    java.awt.Stroke var12 = var6.getLabelOutlineStroke();
    var4.setDomainZeroBaselineStroke(var12);
    java.awt.Paint var14 = var4.getDomainGridlinePaint();
    var4.clearRangeAxes();
    org.jfree.chart.LegendItemCollection var16 = var4.getLegendItems();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var22 = var21.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var23 = null;
    var21.setMarkerBand(var23);
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var18, var19, (org.jfree.chart.axis.ValueAxis)var21, var25);
    org.jfree.chart.util.Layer var28 = null;
    java.util.Collection var29 = var26.getDomainMarkers((-1), var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    org.jfree.data.general.PieDataset var35 = null;
    org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
    java.awt.Stroke var37 = var36.getBaseSectionOutlineStroke();
    var36.setShadowXOffset(100.0d);
    var36.setNoDataMessage("hi!");
    java.awt.Stroke var42 = var36.getLabelOutlineStroke();
    var34.setDomainZeroBaselineStroke(var42);
    java.awt.Paint var44 = var34.getDomainGridlinePaint();
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis var46 = null;
    org.jfree.chart.axis.NumberAxis3D var48 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var49 = var48.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var50 = null;
    var48.setMarkerBand(var50);
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var45, var46, (org.jfree.chart.axis.ValueAxis)var48, var52);
    org.jfree.chart.util.Layer var55 = null;
    java.util.Collection var56 = var53.getDomainMarkers(1, var55);
    org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var53.addRangeMarker((org.jfree.chart.plot.Marker)var58);
    org.jfree.chart.axis.AxisLocation var60 = var53.getRangeAxisLocation();
    var34.setDomainAxisLocation(var60);
    var26.setDomainAxisLocation(var60, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation((-16777215), var60);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisSpace var5 = var4.getFixedDomainAxisSpace();
    org.jfree.chart.plot.PlotOrientation var6 = var4.getOrientation();
    int var7 = var4.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setForegroundAlpha((-1.0f));
    var1.setCircular(true, true);
    java.awt.Paint var7 = var1.getOutlinePaint();
    java.awt.Paint var8 = var1.getBaseSectionPaint();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var10);
    var1.setPieIndex((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     java.awt.Stroke var4 = var3.getBaseSectionOutlineStroke();
//     java.awt.Font var5 = var3.getNoDataMessageFont();
//     java.awt.Color var8 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var9 = var8.getColorSpace();
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var5, (java.awt.Paint)var8);
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     double var13 = var12.getValue();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getLabelOffset();
//     java.awt.Stroke var15 = var12.getOutlineStroke();
//     java.awt.Paint var16 = var12.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var19 = null;
//     org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, var16, 0.0f, 1, var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.TextBlockAnchor var24 = null;
//     var20.draw(var21, 0.0f, (-1.0f), var24);
//     org.jfree.chart.ui.BasicProjectInfo var31 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "hi!", "hi!");
//     org.jfree.chart.ui.BasicProjectInfo var36 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!");
//     var31.addLibrary((org.jfree.chart.ui.Library)var36);
//     java.lang.String var38 = var31.getLicenceName();
//     boolean var39 = var20.equals((java.lang.Object)var31);
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     java.awt.Stroke var43 = var42.getBaseSectionOutlineStroke();
//     java.awt.Font var44 = var42.getNoDataMessageFont();
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var48 = var47.getColorSpace();
//     org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=1]", var44, (java.awt.Paint)var47);
//     org.jfree.chart.block.BlockContainer var50 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.block.RectangleConstraint var54 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.data.Range var55 = var54.getHeightRange();
//     org.jfree.chart.util.Size2D var56 = var50.arrange(var51, var54);
//     boolean var57 = var49.equals((java.lang.Object)var54);
//     org.jfree.chart.util.HorizontalAlignment var58 = var49.getLineAlignment();
//     var20.setLineAlignment(var58);
//     
//     // Checks the contract:  equals-hashcode on var3 and var42
//     assertTrue("Contract failed: equals-hashcode on var3 and var42", var3.equals(var42) ? var3.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var3
//     assertTrue("Contract failed: equals-hashcode on var42 and var3", var42.equals(var3) ? var42.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     double[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "Range[0.0,0.0]", var2);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    var1.setTickLabelsVisible(true);
    org.jfree.data.Range var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var4, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var4 = var3.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var5 = null;
    var3.setMarkerBand(var5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getDomainMarkers(1, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    var8.addRangeMarker((org.jfree.chart.plot.Marker)var13);
    java.lang.String var15 = var8.getPlotType();
    org.jfree.chart.axis.CategoryAxis var16 = null;
    java.util.List var17 = var8.getCategoriesForAxis(var16);
    var8.setRangeCrosshairVisible(false);
    var8.clearAnnotations();
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var8.getRangeMarkers(var21);
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.chart.axis.AxisSpace var28 = var27.getFixedDomainAxisSpace();
    org.jfree.chart.plot.PlotOrientation var29 = var27.getOrientation();
    var8.setOrientation(var29);
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
    var33.setPieIndex(100);
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
    java.awt.Stroke var38 = var37.getBaseSectionOutlineStroke();
    var33.setBaseSectionOutlineStroke(var38);
    org.jfree.chart.util.RectangleInsets var40 = var33.getLabelPadding();
    var31.setTickLabelInsets(var40);
    org.jfree.data.Range var42 = null;
    org.jfree.data.Range var44 = org.jfree.data.Range.expandToInclude(var42, 0.0d);
    double var45 = var44.getLength();
    org.jfree.data.Range var46 = null;
    org.jfree.data.Range var48 = org.jfree.data.Range.expandToInclude(var46, 0.0d);
    org.jfree.data.Range var49 = org.jfree.data.Range.combine(var44, var48);
    var31.setRange(var49, true, true);
    double var53 = var31.getLabelAngle();
    var31.zoomRange(0.14d, 2.0d);
    boolean var57 = var29.equals((java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Category Plot"+ "'", var15.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("");
    org.jfree.data.RangeType var2 = var1.getRangeType();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    java.lang.String var5 = var1.getLabelToolTip();
    var1.configure();
    org.jfree.data.Range var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var7, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.data.Range var5 = var4.getHeightRange();
    org.jfree.chart.util.Size2D var6 = var0.arrange(var1, var4);
    java.lang.Object var7 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Font var3 = var1.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     var4.removeLegend();
//     org.jfree.chart.title.LegendTitle var6 = var4.getLegend();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setPieIndex(100);
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     var8.handleClick(100, 1, var13);
//     org.jfree.chart.util.RectangleInsets var15 = var8.getInsets();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Stroke var18 = var17.getBaseSectionOutlineStroke();
//     java.awt.Font var19 = var17.getNoDataMessageFont();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     var20.removeLegend();
//     var8.addChangeListener((org.jfree.chart.event.PlotChangeListener)var20);
//     var20.setAntiAlias(true);
//     java.lang.Object var25 = var20.getTextAntiAlias();
//     float var26 = var20.getBackgroundImageAlpha();
//     java.awt.RenderingHints var27 = var20.getRenderingHints();
//     var4.setRenderingHints(var27);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var20
//     assertTrue("Contract failed: equals-hashcode on var4 and var20", var4.equals(var20) ? var4.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var4
//     assertTrue("Contract failed: equals-hashcode on var20 and var4", var20.equals(var4) ? var20.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setForegroundAlpha((-1.0f));
    var1.setCircular(true, true);
    org.jfree.chart.event.PlotChangeEvent var7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var1);
    var1.setBackgroundImageAlignment((-1));
    java.awt.Stroke var10 = var1.getBaseSectionOutlineStroke();
    java.awt.Paint var11 = var1.getBaseSectionPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setShadowXOffset(100.0d);
    var1.setNoDataMessage("hi!");
    var1.setBackgroundAlpha(0.0f);
    boolean var9 = var1.getSectionOutlinesVisible();
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
    java.awt.Stroke var17 = var16.getBaseSectionOutlineStroke();
    var16.setShadowXOffset(100.0d);
    var16.setNoDataMessage("hi!");
    java.awt.Stroke var22 = var16.getLabelOutlineStroke();
    var14.setDomainZeroBaselineStroke(var22);
    java.awt.Paint var24 = var14.getDomainGridlinePaint();
    java.awt.Paint var25 = var14.getDomainZeroBaselinePaint();
    java.awt.Paint var26 = var14.getRangeTickBandPaint();
    org.jfree.chart.util.RectangleInsets var27 = var14.getInsets();
    var1.setSimpleLabelOffset(var27);
    var1.setInteriorGap(0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

//  public void test500() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Range[0.0,0.0]", var1);
//
//  }
//
//}
