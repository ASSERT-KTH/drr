
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(126284888);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    var4.clear();
    var4.setDomainDescription("");
    var4.removeAgedItems(true);
    java.lang.Class var13 = null;
    org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var13);
    var14.removeAgedItems(false);
    java.util.Collection var17 = var14.getTimePeriods();
    java.lang.Class var21 = null;
    org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var21);
    boolean var23 = var22.isEmpty();
    java.lang.String var24 = var22.getDescription();
    java.util.Collection var25 = var14.getTimePeriodsUniqueToOtherSeries(var22);
    var22.setDescription("");
    org.jfree.data.general.SeriesChangeListener var28 = null;
    var22.removeChangeListener(var28);
    java.lang.String var30 = var22.getDomainDescription();
    java.util.Collection var31 = var4.getTimePeriodsUniqueToOtherSeries(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "hi!"+ "'", var30.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1420099199999L);
//     int var9 = var5.getMonth();
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
//     long var11 = var5.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419062400000L);
// 
//   }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1.0d, "14-December-2014", "ERROR : Relative To String", var9);
//     var10.setDomainDescription("14-December-2014");
//     org.jfree.data.general.SeriesChangeListener var13 = null;
//     var10.removeChangeListener(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("20-December-2014");
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.jfree.data.general.SeriesException var4 = new org.jfree.data.general.SeriesException("20-December-2014");
    var1.addSuppressed((java.lang.Throwable)var4);
    java.lang.Throwable[] var6 = var1.getSuppressed();
    java.lang.String var7 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "org.jfree.data.general.SeriesException: 20-December-2014"+ "'", var7.equals("org.jfree.data.general.SeriesException: 20-December-2014"));

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     var4.setDescription("20-December-2014");
//     var4.setDescription("ERROR : Relative To String");
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     java.util.Date var11 = var10.getEnd();
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(var11);
//     java.lang.String var15 = var14.toString();
//     long var16 = var14.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var14.next();
//     java.lang.Object var18 = null;
//     boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var14, var18);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(3, var14);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)1419140800211L);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.removeChangeListener(var4);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
    var10.removeAgedItems(false);
    java.util.Collection var13 = var10.getTimePeriods();
    java.lang.Class var17 = null;
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
    boolean var19 = var18.isEmpty();
    java.lang.String var20 = var18.getDescription();
    java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
    org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
    var22.setMaximumItemAge(0L);
    var22.setRangeDescription("2015");
    java.lang.Class var27 = var22.getTimePeriodClass();
    java.util.Collection var28 = var22.getTimePeriods();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     long var13 = var11.getSerialIndex();
//     long var14 = var11.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11);
//     long var16 = var11.getSerialIndex();
//     long var17 = var11.getFirstMillisecond();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     java.util.Date var19 = var18.getEnd();
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(var19);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(var19);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year(var19);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var22, "org.jfree.data.general.SeriesException: December 2014", "", var25);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var28);
//     var29.fireSeriesChanged();
//     var29.fireSeriesChanged();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (-1.0d));
//     int var35 = var32.getYear();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var37 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var32, (org.jfree.data.time.RegularTimePeriod)var36);
//     org.jfree.data.time.Year var38 = var36.getYear();
//     java.lang.String var39 = var38.toString();
//     long var40 = var38.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var41 = var38.previous();
//     boolean var42 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var26, (java.lang.Object)var38);
//     int var43 = var26.getItemCount();
//     int var44 = var11.compareTo((java.lang.Object)var26);
//     boolean var45 = var26.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "2014"+ "'", var39.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == true);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Monday"+ "'", var1.equals("Monday"));

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var2.removeChangeListener(var7);
//     java.util.List var9 = var2.getItems();
//     org.jfree.data.general.SeriesChangeEvent var10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var12 = var2.getDataItem((-572));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var10);
//     var11.fireSeriesChanged();
//     var11.fireSeriesChanged();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     int var17 = var14.getYear();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var19 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var18);
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var18);
//     java.lang.String var21 = var6.getRangeDescription();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     long var23 = var22.getSerialIndex();
//     int var24 = var22.getYear();
//     int var25 = var22.getDayOfMonth();
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.general.SeriesChangeListener var27 = null;
//     var6.addChangeListener(var27);
//     var6.setRangeDescription("org.jfree.data.general.SeriesChangeEvent[source=0]");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Value"+ "'", var21.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 20);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond();
//     long var2 = var1.getMiddleMillisecond();
//     java.util.Date var3 = var1.getStart();
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.RegularTimePeriod var5 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var3, var4);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var3);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getLastMillisecond(var7);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     java.beans.PropertyChangeListener var9 = null;
//     var6.removePropertyChangeListener(var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var6.addChangeListener(var11);
//     var6.removeAgedItems(true);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     java.util.Date var16 = var15.getEnd();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(var16);
//     long var18 = var17.getFirstMillisecond();
//     int var19 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.RegularTimePeriod var23 = var21.previous();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var6.getDataItem(var23);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     long var29 = var28.getSerialIndex();
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var31 = var27.createCopy((org.jfree.data.time.RegularTimePeriod)var28, (org.jfree.data.time.RegularTimePeriod)var30);
//     org.jfree.data.general.SeriesChangeListener var32 = null;
//     var31.addChangeListener(var32);
//     org.jfree.data.general.SeriesChangeListener var34 = null;
//     var31.removeChangeListener(var34);
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var37);
//     var38.fireSeriesChanged();
//     var38.fireSeriesChanged();
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var41, (-1.0d));
//     int var44 = var41.getYear();
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var46 = var38.createCopy((org.jfree.data.time.RegularTimePeriod)var41, (org.jfree.data.time.RegularTimePeriod)var45);
//     org.jfree.data.time.Year var47 = var45.getYear();
//     long var48 = var47.getSerialIndex();
//     long var49 = var47.getSerialIndex();
//     long var50 = var47.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var47);
//     long var52 = var47.getSerialIndex();
//     boolean var53 = var31.equals((java.lang.Object)var47);
//     org.jfree.data.time.TimeSeries var54 = var6.addAndOrUpdate(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]", var1);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }
// 
// 
//     org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     java.util.Date var3 = var2.getEnd();
//     boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)var2);
//     org.jfree.data.time.RegularTimePeriod var5 = var2.next();
//     java.util.Calendar var6 = null;
//     long var7 = var2.getMiddleMillisecond(var6);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     java.lang.String var8 = var2.getDescription();
//     var2.clear();
//     java.util.List var10 = var2.getItems();
//     var2.setMaximumItemAge(1419140711323L);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var14);
//     var15.fireSeriesChanged();
//     var15.fireSeriesChanged();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (-1.0d));
//     int var21 = var18.getYear();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var23 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var18, (org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.Year var24 = var22.getYear();
//     org.jfree.data.time.RegularTimePeriod var25 = var22.next();
//     java.lang.Number var26 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var22);
//     java.beans.PropertyChangeListener var27 = null;
//     var2.addPropertyChangeListener(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var6);
//     boolean var8 = var7.isEmpty();
//     var7.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var13 = var12.toString();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var17);
//     var18.fireSeriesChanged();
//     var18.fireSeriesChanged();
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     int var24 = var21.getYear();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var26 = var18.createCopy((org.jfree.data.time.RegularTimePeriod)var21, (org.jfree.data.time.RegularTimePeriod)var25);
//     org.jfree.data.time.RegularTimePeriod var27 = var25.next();
//     org.jfree.data.time.TimeSeriesDataItem var29 = var7.addOrUpdate(var27, 100.0d);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var29, var30);
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond();
//     long var33 = var32.getMiddleMillisecond();
//     long var34 = var32.getFirstMillisecond();
//     var31.delete((org.jfree.data.time.RegularTimePeriod)var32);
//     java.util.Calendar var36 = null;
//     long var37 = var32.getFirstMillisecond(var36);
//     org.jfree.data.time.RegularTimePeriod var38 = var32.previous();
//     int var39 = var0.compareTo((java.lang.Object)var32);
//     java.util.Calendar var40 = null;
//     long var41 = var0.getFirstMillisecond(var40);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2014);
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(2014);
//     int var4 = var1.compare((org.jfree.data.time.SerialDate)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var7 = var6.toSerial();
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var6);
//     int var9 = var6.getYYYY();
//     int var10 = var6.getMonth();
//     java.lang.String var11 = var6.toString();
//     boolean var12 = var3.isAfter((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var16 = var15.getTime();
//     boolean var17 = var14.equals((java.lang.Object)var16);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     long var22 = var19.getFirstMillisecond();
//     long var23 = var19.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(byte)0);
//     java.lang.String var26 = var19.toString();
//     java.lang.String var27 = var19.toString();
//     org.jfree.data.time.SerialDate var28 = var19.getSerialDate();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var28);
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var32 = var31.getTime();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addDays(2014, var33);
//     boolean var35 = var14.isInRange(var29, var34);
//     org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var39 = var38.getTime();
//     boolean var40 = var37.equals((java.lang.Object)var39);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var44 = var43.getTime();
//     boolean var45 = var42.equals((java.lang.Object)var44);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, (-1.0d));
//     long var50 = var47.getFirstMillisecond();
//     long var51 = var47.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, (java.lang.Number)(byte)0);
//     java.lang.String var54 = var47.toString();
//     java.lang.String var55 = var47.toString();
//     org.jfree.data.time.SerialDate var56 = var47.getSerialDate();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var56);
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var60 = var59.getTime();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var60);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addDays(2014, var61);
//     boolean var63 = var42.isInRange(var57, var62);
//     org.jfree.data.time.SerialDate var64 = var37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var42);
//     boolean var65 = var14.isBefore((org.jfree.data.time.SerialDate)var42);
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(2014);
//     var67.setDescription("Time");
//     var67.setDescription("hi!");
//     boolean var72 = var42.isAfter(var67);
//     org.jfree.data.time.Day var74 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var74, (-1.0d));
//     long var77 = var74.getFirstMillisecond();
//     long var78 = var74.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var74, (java.lang.Number)(byte)0);
//     java.lang.String var81 = var74.toString();
//     java.lang.String var82 = var74.toString();
//     org.jfree.data.time.SerialDate var83 = var74.getSerialDate();
//     org.jfree.data.time.SerialDate var84 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var83);
//     boolean var85 = var42.isOnOrAfter(var84);
//     org.jfree.data.time.Day var86 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var88 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var86, (-1.0d));
//     int var89 = var86.getYear();
//     org.jfree.data.time.SerialDate var90 = var86.getSerialDate();
//     org.jfree.data.time.SerialDate var91 = var84.getEndOfCurrentMonth(var90);
//     org.jfree.data.time.SerialDate var92 = var3.getEndOfCurrentMonth(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "30-January-1900"+ "'", var11.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-December-2014"+ "'", var27.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "20-December-2014"+ "'", var54.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "20-December-2014"+ "'", var55.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var81 + "' != '" + "20-December-2014"+ "'", var81.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var82 + "' != '" + "20-December-2014"+ "'", var82.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     java.util.Date var3 = var2.getTime();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var5);
//     var6.fireSeriesChanged();
//     var6.setMaximumItemCount(0);
//     var6.setMaximumItemCount(2147483647);
//     var6.clear();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     int var15 = var13.compareTo((java.lang.Object)'4');
//     org.jfree.data.time.RegularTimePeriod var16 = var13.next();
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(1419140717124L);
//     org.jfree.data.time.TimeSeries var19 = var6.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     java.lang.String var21 = var20.toString();
//     java.util.Date var22 = var20.getStart();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(var22);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     java.lang.Object var28 = var27.clone();
//     java.lang.Number var29 = var27.getValue();
//     org.jfree.data.time.RegularTimePeriod var30 = var27.getPeriod();
//     boolean var31 = var24.equals((java.lang.Object)var30);
//     long var32 = var24.getFirstMillisecond();
//     long var33 = var24.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var34 = var24.previous();
//     java.util.Calendar var35 = null;
//     long var36 = var24.getMiddleMillisecond(var35);
//     int var37 = var18.compareTo((java.lang.Object)var36);
//     boolean var38 = var2.equals((java.lang.Object)var37);
//     org.jfree.data.time.RegularTimePeriod var39 = var2.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "December 2014"+ "'", var21.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + (-1.0d)+ "'", var29.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     java.beans.PropertyChangeListener var9 = null;
//     var6.removePropertyChangeListener(var9);
//     var6.clear();
//     boolean var12 = var6.getNotify();
//     var6.setMaximumItemAge(1419140704567L);
//     boolean var15 = var6.isEmpty();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.String var17 = var16.toString();
//     java.util.Date var18 = var16.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(var18);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     java.lang.Object var24 = var23.clone();
//     java.lang.Number var25 = var23.getValue();
//     org.jfree.data.time.RegularTimePeriod var26 = var23.getPeriod();
//     boolean var27 = var20.equals((java.lang.Object)var26);
//     long var28 = var20.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var29 = var20.next();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var33);
//     var34.clear();
//     var34.setDomainDescription("");
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var40 = null;
//     long var41 = var39.getMiddleMillisecond(var40);
//     int var42 = var34.getIndex((org.jfree.data.time.RegularTimePeriod)var39);
//     java.lang.Class var44 = null;
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var44);
//     var45.fireSeriesChanged();
//     var45.fireSeriesChanged();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, (-1.0d));
//     int var51 = var48.getYear();
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var53 = var45.createCopy((org.jfree.data.time.RegularTimePeriod)var48, (org.jfree.data.time.RegularTimePeriod)var52);
//     org.jfree.data.time.Year var54 = var52.getYear();
//     java.lang.String var55 = var54.toString();
//     java.lang.Class var59 = null;
//     org.jfree.data.time.TimeSeries var60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var59);
//     boolean var61 = var60.isEmpty();
//     var60.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var65 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var66 = var65.toString();
//     org.jfree.data.time.TimeSeriesDataItem var68 = var60.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var65, 1.0d);
//     boolean var69 = var54.equals((java.lang.Object)var65);
//     long var70 = var54.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var71 = var54.next();
//     var34.delete((org.jfree.data.time.RegularTimePeriod)var54);
//     java.util.Collection var73 = var34.getTimePeriods();
//     org.jfree.data.time.FixedMillisecond var75 = new org.jfree.data.time.FixedMillisecond((-1L));
//     long var76 = var75.getMiddleMillisecond();
//     java.lang.Number var77 = var34.getValue((org.jfree.data.time.RegularTimePeriod)var75);
//     java.util.Calendar var78 = null;
//     long var79 = var75.getMiddleMillisecond(var78);
//     org.jfree.data.time.RegularTimePeriod var80 = var75.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var81 = var6.createCopy(var29, (org.jfree.data.time.RegularTimePeriod)var75);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "December 2014"+ "'", var17.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + (-1.0d)+ "'", var25.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "2014"+ "'", var55.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var66 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var66.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == (-1L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getSerialIndex();
//     org.jfree.data.time.SerialDate var2 = var0.getSerialDate();
//     java.lang.String var3 = var0.toString();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, (-1.0d));
//     long var7 = var4.getFirstMillisecond();
//     long var8 = var4.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)(byte)0);
//     java.lang.String var11 = var4.toString();
//     java.lang.String var12 = var4.toString();
//     java.lang.String var13 = var4.toString();
//     boolean var14 = var0.equals((java.lang.Object)var4);
//     int var15 = var0.getDayOfMonth();
//     long var16 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "20-December-2014"+ "'", var3.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 41993L);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     java.beans.PropertyChangeListener var9 = null;
//     var6.removePropertyChangeListener(var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     int var13 = var11.compareTo((java.lang.Object)'4');
//     boolean var14 = var6.equals((java.lang.Object)'4');
//     java.lang.String var15 = var6.getRangeDescription();
//     org.jfree.data.time.TimeSeries var18 = var6.createCopy(10, 2147483647);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(var21);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (-1.0d));
//     java.lang.Object var27 = var26.clone();
//     java.lang.Number var28 = var26.getValue();
//     org.jfree.data.time.RegularTimePeriod var29 = var26.getPeriod();
//     boolean var30 = var23.equals((java.lang.Object)var29);
//     long var31 = var23.getFirstMillisecond();
//     long var32 = var23.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var33 = var23.previous();
//     java.util.Calendar var34 = null;
//     long var35 = var23.getMiddleMillisecond(var34);
//     org.jfree.data.time.TimeSeriesDataItem var37 = var18.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)1419140707881L);
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var39);
//     var40.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var42 = null;
//     var40.removeChangeListener(var42);
//     var40.removeAgedItems(true);
//     long var46 = var40.getMaximumItemAge();
//     org.jfree.data.time.TimeSeries var47 = var18.addAndOrUpdate(var40);
//     boolean var48 = var47.getNotify();
//     java.beans.PropertyChangeListener var49 = null;
//     var47.addPropertyChangeListener(var49);
//     var47.setMaximumItemAge(1419140725477L);
//     var47.removeAgedItems(1419140732580L, false);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     long var5 = var4.getSerialIndex();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var7 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var4, (org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var7.addChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var7.removeChangeListener(var10);
//     var7.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     java.lang.Object var17 = var16.clone();
//     java.lang.Number var18 = var16.getValue();
//     org.jfree.data.time.RegularTimePeriod var19 = var16.getPeriod();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     java.lang.String var21 = var20.toString();
//     java.util.Date var22 = var20.getStart();
//     org.jfree.data.time.TimeSeries var23 = var7.createCopy(var19, (org.jfree.data.time.RegularTimePeriod)var20);
//     java.util.Date var24 = var20.getEnd();
//     java.util.TimeZone var25 = null;
//     org.jfree.data.time.RegularTimePeriod var26 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var24, var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day(var24);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var27, var28);
//     java.util.Date var30 = var27.getStart();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var30);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + (-1.0d)+ "'", var18.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "December 2014"+ "'", var21.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var10.removeChangeListener(var12);
//     int var14 = var6.compareTo((java.lang.Object)var10);
//     int var15 = var10.getItemCount();
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "Time", "December 2014", var19);
//     int var21 = var20.getMaximumItemCount();
//     java.util.Collection var22 = var10.getTimePeriodsUniqueToOtherSeries(var20);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var24);
//     var25.fireSeriesChanged();
//     var25.setMaximumItemCount(0);
//     var25.setMaximumItemAge(1L);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var32);
//     var33.fireSeriesChanged();
//     var33.setMaximumItemCount(0);
//     var33.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month();
//     java.lang.Number var40 = var33.getValue((org.jfree.data.time.RegularTimePeriod)var39);
//     var25.delete((org.jfree.data.time.RegularTimePeriod)var39);
//     long var42 = var39.getFirstMillisecond();
//     org.jfree.data.time.Year var43 = var39.getYear();
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (-1.0d));
//     long var47 = var44.getFirstMillisecond();
//     long var48 = var44.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (java.lang.Number)(byte)0);
//     java.lang.Number var51 = var50.getValue();
//     java.lang.Object var52 = var50.clone();
//     int var53 = var43.compareTo((java.lang.Object)var50);
//     java.lang.Number var54 = var50.getValue();
//     var20.add(var50);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-44999));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-11372));

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy(0, 0);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     int var15 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.RegularTimePeriod var16 = var11.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(2014, var20);
//     boolean var22 = var1.isInRange(var16, var21);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getSerialIndex();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var29 = var25.createCopy((org.jfree.data.time.RegularTimePeriod)var26, (org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var29.addChangeListener(var30);
//     org.jfree.data.general.SeriesChangeListener var32 = null;
//     var29.removeChangeListener(var32);
//     var29.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var36, (-1.0d));
//     java.lang.Object var39 = var38.clone();
//     java.lang.Number var40 = var38.getValue();
//     org.jfree.data.time.RegularTimePeriod var41 = var38.getPeriod();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     java.lang.String var43 = var42.toString();
//     java.util.Date var44 = var42.getStart();
//     org.jfree.data.time.TimeSeries var45 = var29.createCopy(var41, (org.jfree.data.time.RegularTimePeriod)var42);
//     var29.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var50 = var49.toString();
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)10L);
//     long var53 = var49.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var49);
//     int var55 = var29.getIndex((org.jfree.data.time.RegularTimePeriod)var49);
//     boolean var56 = var1.equals((java.lang.Object)var29);
//     var29.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]");
//     java.lang.Class var60 = null;
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var60);
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day();
//     long var63 = var62.getSerialIndex();
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var65 = var61.createCopy((org.jfree.data.time.RegularTimePeriod)var62, (org.jfree.data.time.RegularTimePeriod)var64);
//     long var66 = var62.getSerialIndex();
//     org.jfree.data.time.Month var67 = new org.jfree.data.time.Month();
//     java.util.Date var68 = var67.getEnd();
//     org.jfree.data.time.FixedMillisecond var69 = new org.jfree.data.time.FixedMillisecond(var68);
//     org.jfree.data.time.RegularTimePeriod var70 = var69.next();
//     java.util.Calendar var71 = null;
//     long var72 = var69.getFirstMillisecond(var71);
//     org.jfree.data.time.TimeSeries var73 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var62, (org.jfree.data.time.RegularTimePeriod)var69);
//     java.lang.Comparable var74 = var29.getKey();
//     java.util.List var75 = var29.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + (-1.0d)+ "'", var40.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "December 2014"+ "'", var43.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var50.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var74 + "' != '" + 100.0d+ "'", var74.equals(100.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     int var8 = var0.getYear();
//     int var9 = var0.getMonth();
//     int var10 = var0.getMonth();
//     long var11 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 41993L);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var27 = var26.toString();
//     int var28 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     java.util.Date var29 = var26.getTime();
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var33);
//     boolean var35 = var34.isEmpty();
//     var34.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var40 = var39.toString();
//     org.jfree.data.time.TimeSeriesDataItem var42 = var34.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var39, 1.0d);
//     java.util.Calendar var43 = null;
//     long var44 = var39.getMiddleMillisecond(var43);
//     boolean var46 = var39.equals((java.lang.Object)1L);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     boolean var48 = var39.equals((java.lang.Object)var47);
//     org.jfree.data.time.RegularTimePeriod var49 = var47.next();
//     int var50 = var26.compareTo((java.lang.Object)var47);
//     java.lang.Class var54 = null;
//     org.jfree.data.time.TimeSeries var55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var54);
//     var55.removeAgedItems(false);
//     var55.setMaximumItemAge(1417420800000L);
//     int var60 = var26.compareTo((java.lang.Object)var55);
//     java.util.Date var61 = var26.getTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var27.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var40.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
    java.lang.Object var3 = var2.clone();
    java.lang.Number var4 = var2.getValue();
    java.lang.Number var5 = var2.getValue();
    java.lang.Object var6 = var2.clone();
    var2.setValue((java.lang.Number)1388563200000L);
    org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond(1419140725374L);
    int var11 = var2.compareTo((java.lang.Object)1419140725374L);
    java.lang.Number var12 = var2.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1.0d)+ "'", var4.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0d)+ "'", var5.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 1388563200000L+ "'", var12.equals(1388563200000L));

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    java.util.Date var2 = var1.getEnd();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("30-January-1900", var1);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)1419140706412L);
//     int var11 = var8.getMonth();
//     java.lang.String var12 = var8.toString();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)10.0f);
//     org.jfree.data.time.SerialDate var15 = var8.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = var8.getSerialDate();
//     org.jfree.data.time.RegularTimePeriod var17 = var8.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getMiddleMillisecond(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419140801971L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419140801971L);
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var10);
//     var11.fireSeriesChanged();
//     var11.fireSeriesChanged();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     int var17 = var14.getYear();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var19 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var18);
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var18);
//     var6.clear();
//     java.lang.String var22 = var6.getDomainDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "Time"+ "'", var22.equals("Time"));
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.Class var5 = var2.getTimePeriodClass();
    java.lang.String var6 = var2.getDescription();
    java.lang.Class var10 = null;
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var10);
    var11.clear();
    java.util.Collection var13 = var2.getTimePeriodsUniqueToOtherSeries(var11);
    int var14 = var11.getMaximumItemCount();
    java.util.Collection var15 = var11.getTimePeriods();
    java.beans.PropertyChangeListener var16 = null;
    var11.addPropertyChangeListener(var16);
    var11.clear();
    java.lang.String var19 = var11.getDomainDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var6.equals("SerialDate.weekInMonthToString(): invalid code."));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "hi!"+ "'", var19.equals("hi!"));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    var4.clear();
    var4.setDomainDescription("");
    var4.setRangeDescription("hi!");
    var4.setDomainDescription("January 2014");
    int var12 = var4.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.Class var5 = var2.getTimePeriodClass();
    java.lang.String var6 = var2.getDescription();
    java.util.Collection var7 = var2.getTimePeriods();
    boolean var8 = var2.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var6.equals("SerialDate.weekInMonthToString(): invalid code."));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     var2.clear();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.previous();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     java.util.Date var16 = var15.getEnd();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var2.addOrUpdate(var18, 10.0d);
//     var2.clear();
//     var2.setDescription("Sat Dec 20 21:45:07 PST 2014");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var25 = var2.getTimePeriod((-44999));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }
// 
// 
//     org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("2014");
//     java.lang.Object var2 = null;
//     boolean var3 = var1.equals(var2);
//     long var4 = var1.getSerialIndex();
//     long var5 = var1.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1420099199999L);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }
// 
// 
//     org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("ERROR : Relative To String");
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     java.lang.String var3 = var2.toString();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var5);
//     var6.fireSeriesChanged();
//     var6.fireSeriesChanged();
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (-1.0d));
//     int var12 = var9.getYear();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var14 = var6.createCopy((org.jfree.data.time.RegularTimePeriod)var9, (org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.Year var15 = var13.getYear();
//     java.lang.String var16 = var15.toString();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var20);
//     boolean var22 = var21.isEmpty();
//     var21.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var27 = var26.toString();
//     org.jfree.data.time.TimeSeriesDataItem var29 = var21.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, 1.0d);
//     boolean var30 = var15.equals((java.lang.Object)var26);
//     int var31 = var2.compareTo((java.lang.Object)var15);
//     org.jfree.data.general.SeriesException var33 = new org.jfree.data.general.SeriesException("20-December-2014");
//     java.lang.Throwable[] var34 = var33.getSuppressed();
//     org.jfree.data.general.SeriesException var36 = new org.jfree.data.general.SeriesException("20-December-2014");
//     var33.addSuppressed((java.lang.Throwable)var36);
//     org.jfree.data.general.SeriesException var39 = new org.jfree.data.general.SeriesException("20-December-2014");
//     java.lang.Throwable[] var40 = var39.getSuppressed();
//     org.jfree.data.general.SeriesException var42 = new org.jfree.data.general.SeriesException("20-December-2014");
//     var39.addSuppressed((java.lang.Throwable)var42);
//     java.lang.String var44 = var39.toString();
//     var36.addSuppressed((java.lang.Throwable)var39);
//     org.jfree.data.general.SeriesException var47 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10.0]");
//     var36.addSuppressed((java.lang.Throwable)var47);
//     java.lang.Throwable[] var49 = var47.getSuppressed();
//     boolean var50 = var15.equals((java.lang.Object)var47);
//     java.lang.Throwable[] var51 = var47.getSuppressed();
//     var1.addSuppressed((java.lang.Throwable)var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "December 2014"+ "'", var3.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "2014"+ "'", var16.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var27.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "org.jfree.data.general.SeriesException: 20-December-2014"+ "'", var44.equals("org.jfree.data.general.SeriesException: 20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     long var2 = var0.getSerialIndex();
//     java.lang.String var3 = var0.toString();
//     int var4 = var0.getYearValue();
//     long var5 = var0.getSerialIndex();
//     java.util.Date var6 = var0.getStart();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "December 2014"+ "'", var3.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.SerialDate var4 = var0.getSerialDate();
//     int var5 = var0.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var6);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var9 = var8.previous();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.previous();
//     java.lang.Number var11 = null;
//     org.jfree.data.time.TimeSeriesDataItem var12 = var7.addOrUpdate(var10, var11);
//     var7.setDescription("org.jfree.data.general.SeriesChangeEvent[source=Wed Dec 31 16:00:00 PST 1969]");
//     boolean var15 = var7.getNotify();
//     boolean var16 = var7.getNotify();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: Last", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 10.0d);
//     long var4 = var0.getSerialIndex();
//     java.lang.String var5 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "December 2014"+ "'", var5.equals("December 2014"));
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1420099199999L);
//     var2.setDomainDescription("2014");
//     java.util.List var11 = var2.getItems();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var13);
//     var14.fireSeriesChanged();
//     var14.setMaximumItemCount(0);
//     var14.setMaximumItemAge(1L);
//     java.util.List var20 = var14.getItems();
//     var14.clear();
//     org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var14);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var24);
//     var25.fireSeriesChanged();
//     var25.fireSeriesChanged();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, (-1.0d));
//     int var31 = var28.getYear();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var33 = var25.createCopy((org.jfree.data.time.RegularTimePeriod)var28, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var34 = var32.getYear();
//     java.lang.String var35 = var34.toString();
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var39);
//     var40.removeAgedItems(false);
//     java.util.Collection var43 = var40.getTimePeriods();
//     java.lang.Class var47 = null;
//     org.jfree.data.time.TimeSeries var48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var47);
//     boolean var49 = var48.isEmpty();
//     java.lang.String var50 = var48.getDescription();
//     java.util.Collection var51 = var40.getTimePeriodsUniqueToOtherSeries(var48);
//     boolean var52 = var34.equals((java.lang.Object)var51);
//     boolean var53 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var34);
//     int var54 = var34.getYear();
//     long var55 = var34.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "2014"+ "'", var35.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1388563200000L);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Monday", var1);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var1);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var4, "org.jfree.data.general.SeriesException: December 2014", "", var7);
//     int var9 = var4.getYear();
//     java.lang.String var10 = var4.toString();
//     org.jfree.data.time.RegularTimePeriod var11 = var4.previous();
//     java.lang.Object var12 = null;
//     int var13 = var4.compareTo(var12);
//     int var14 = var4.getYear();
//     int var15 = var4.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2014"+ "'", var10.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test50"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     long var3 = var2.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getFirstMillisecond(var4);
//     java.util.Calendar var6 = null;
//     var2.peg(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1420099199999L);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test51"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     java.lang.Number var9 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var8);
//     long var10 = var8.getSerialIndex();
//     org.jfree.data.general.SeriesException var12 = new org.jfree.data.general.SeriesException("20-December-2014");
//     java.lang.Throwable[] var13 = var12.getSuppressed();
//     org.jfree.data.general.SeriesException var15 = new org.jfree.data.general.SeriesException("20-December-2014");
//     var12.addSuppressed((java.lang.Throwable)var15);
//     java.lang.Throwable[] var17 = var15.getSuppressed();
//     boolean var18 = var8.equals((java.lang.Object)var17);
//     org.jfree.data.time.RegularTimePeriod var19 = var8.previous();
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var23);
//     long var25 = var24.getMaximumItemAge();
//     boolean var26 = var8.equals((java.lang.Object)var24);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var29 = var28.toSerial();
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var28);
//     int var31 = var28.getYYYY();
//     int var32 = var28.getMonth();
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var36 = var35.getTime();
//     boolean var37 = var34.equals((java.lang.Object)var36);
//     org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var40 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var41 = var40.getTime();
//     boolean var42 = var39.equals((java.lang.Object)var41);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (-1.0d));
//     long var47 = var44.getFirstMillisecond();
//     long var48 = var44.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (java.lang.Number)(byte)0);
//     java.lang.String var51 = var44.toString();
//     java.lang.String var52 = var44.toString();
//     org.jfree.data.time.SerialDate var53 = var44.getSerialDate();
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var53);
//     org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var57 = var56.getTime();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var57);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.addDays(2014, var58);
//     boolean var60 = var39.isInRange(var54, var59);
//     org.jfree.data.time.SerialDate var61 = var34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var39);
//     java.util.Date var62 = var39.toDate();
//     int var63 = var39.getMonth();
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var39);
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(6, 6, 2015);
//     boolean var70 = var28.isInRange((org.jfree.data.time.SerialDate)var39, var68, 0);
//     boolean var71 = var8.equals((java.lang.Object)var70);
//     java.util.Calendar var72 = null;
//     var8.peg(var72);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test52"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (-1.0d));
//     int var6 = var3.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var3.previous();
//     int var8 = var1.compareTo((java.lang.Object)var3);
//     java.util.Date var9 = var1.getTime();
//     java.util.Calendar var10 = null;
//     long var11 = var1.getLastMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var1.getMiddleMillisecond(var12);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var16 = var15.toString();
//     long var17 = var15.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.previous();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var20);
//     var21.fireSeriesChanged();
//     var21.fireSeriesChanged();
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (-1.0d));
//     int var27 = var24.getYear();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var29 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var24, (org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.time.Year var30 = var28.getYear();
//     java.lang.String var31 = var30.toString();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var35);
//     var36.removeAgedItems(false);
//     java.util.Collection var39 = var36.getTimePeriods();
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var43);
//     boolean var45 = var44.isEmpty();
//     java.lang.String var46 = var44.getDescription();
//     java.util.Collection var47 = var36.getTimePeriodsUniqueToOtherSeries(var44);
//     boolean var48 = var30.equals((java.lang.Object)var47);
//     java.util.Collection var49 = org.jfree.chart.util.ObjectUtilities.deepClone(var47);
//     boolean var50 = var15.equals((java.lang.Object)var49);
//     int var51 = var1.compareTo((java.lang.Object)var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var2.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var16.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "2014"+ "'", var31.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test53"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var31 = var30.toSerial();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     int var34 = var32.compareTo((java.lang.Object)'4');
//     java.util.Date var35 = var32.getStart();
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var38 = var37.toString();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)10L);
//     int var41 = var32.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     java.lang.String var43 = var42.toString();
//     java.util.Date var44 = var42.getStart();
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(var44);
//     int var46 = var32.compareTo((java.lang.Object)var45);
//     org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var50 = var49.getTime();
//     boolean var51 = var48.equals((java.lang.Object)var50);
//     org.jfree.data.time.Day var53 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var53, (-1.0d));
//     long var56 = var53.getFirstMillisecond();
//     long var57 = var53.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var53, (java.lang.Number)(byte)0);
//     java.lang.String var60 = var53.toString();
//     java.lang.String var61 = var53.toString();
//     org.jfree.data.time.SerialDate var62 = var53.getSerialDate();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var62);
//     org.jfree.data.time.FixedMillisecond var65 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var66 = var65.getTime();
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(var66);
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.addDays(2014, var67);
//     boolean var69 = var48.isInRange(var63, var68);
//     boolean var71 = var30.isInRange(var45, var63, 1);
//     org.jfree.data.time.Day var72 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var72, (-1.0d));
//     int var75 = var72.getYear();
//     org.jfree.data.time.SerialDate var76 = var72.getSerialDate();
//     boolean var77 = var30.isOnOrAfter(var76);
//     boolean var78 = var1.isAfter(var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var79 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var76);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var38.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "December 2014"+ "'", var43.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var60 + "' != '" + "20-December-2014"+ "'", var60.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-December-2014"+ "'", var61.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == false);
// 
//   }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test54"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var2);
//     java.lang.String var6 = var5.getDescription();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "", "org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]", var9);
//     java.util.List var11 = var10.getItems();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test55"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     var3.fireSeriesChanged();
//     var3.fireSeriesChanged();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var11 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Year var12 = var10.getYear();
//     long var13 = var12.getSerialIndex();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     long var17 = var14.getFirstMillisecond();
//     long var18 = var14.getLastMillisecond();
//     int var19 = var14.getDayOfMonth();
//     org.jfree.data.general.SeriesChangeEvent var20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var14);
//     java.lang.String var21 = var20.toString();
//     int var22 = var12.compareTo((java.lang.Object)var20);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(10, var12);
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]"+ "'", var21.equals("org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test56"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     java.lang.String var8 = var2.getDescription();
//     boolean var9 = var2.isEmpty();
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test57"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("30-April-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test58"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     var2.clear();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.previous();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
//     java.lang.String var15 = var2.getDescription();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var17);
//     var18.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.Class var21 = var18.getTimePeriodClass();
//     java.util.Collection var22 = var18.getTimePeriods();
//     long var23 = var18.getMaximumItemAge();
//     var18.setDescription("Nearest");
//     java.util.Collection var26 = var2.getTimePeriodsUniqueToOtherSeries(var18);
//     var18.setNotify(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var29 = var18.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test59"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test60"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2014);
    int var2 = var1.getYYYY();
    int var3 = var1.getDayOfWeek();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1905);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test61"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     int var13 = var11.getYear();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.next();
//     long var15 = var11.getFirstMillisecond();
//     long var16 = var11.getFirstMillisecond();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     long var21 = var20.getSerialIndex();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var23 = var19.createCopy((org.jfree.data.time.RegularTimePeriod)var20, (org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.general.SeriesChangeListener var24 = null;
//     var23.removeChangeListener(var24);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var27);
//     var28.fireSeriesChanged();
//     var28.fireSeriesChanged();
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, (-1.0d));
//     int var34 = var31.getYear();
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var36 = var28.createCopy((org.jfree.data.time.RegularTimePeriod)var31, (org.jfree.data.time.RegularTimePeriod)var35);
//     var23.delete((org.jfree.data.time.RegularTimePeriod)var35);
//     java.lang.String var38 = var23.getRangeDescription();
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     long var40 = var39.getSerialIndex();
//     int var41 = var39.getYear();
//     int var42 = var39.getDayOfMonth();
//     var23.delete((org.jfree.data.time.RegularTimePeriod)var39);
//     int var44 = var11.compareTo((java.lang.Object)var23);
//     java.lang.Class var46 = null;
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var46);
//     var47.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.Class var50 = var47.getTimePeriodClass();
//     java.lang.String var51 = var47.getDescription();
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var55);
//     var56.clear();
//     java.util.Collection var58 = var47.getTimePeriodsUniqueToOtherSeries(var56);
//     int var59 = var56.getMaximumItemCount();
//     java.util.Collection var60 = var56.getTimePeriods();
//     java.util.Collection var61 = var23.getTimePeriodsUniqueToOtherSeries(var56);
//     java.lang.Object var62 = null;
//     boolean var63 = var56.equals(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "Value"+ "'", var38.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var51.equals("SerialDate.weekInMonthToString(): invalid code."));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test62"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2015);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test63"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419140707939L);
    java.util.Calendar var2 = null;
    long var3 = var1.getFirstMillisecond(var2);
    java.util.Date var4 = var1.getTime();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1419140707939L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test64"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.time.TimePeriodFormatException: Last");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test65"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test66"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     int var7 = var0.getMonth();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.fireSeriesChanged();
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     int var16 = var13.getYear();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Year var19 = var17.getYear();
//     long var20 = var19.getSerialIndex();
//     long var21 = var19.getSerialIndex();
//     long var22 = var19.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var19);
//     java.lang.String var24 = var19.toString();
//     int var25 = var0.compareTo((java.lang.Object)var24);
//     long var26 = var0.getSerialIndex();
//     long var27 = var0.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var28 = var0.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "2014"+ "'", var24.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419105599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test67"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var11);
//     var12.removeAgedItems(false);
//     java.util.Collection var15 = var12.getTimePeriods();
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var19);
//     boolean var21 = var20.isEmpty();
//     java.lang.String var22 = var20.getDescription();
//     java.util.Collection var23 = var12.getTimePeriodsUniqueToOtherSeries(var20);
//     org.jfree.data.general.SeriesChangeEvent var25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     java.util.Date var27 = var26.getEnd();
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)var26);
//     int var29 = var26.getMonth();
//     long var30 = var26.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, 0.0d);
//     org.jfree.data.time.Year var33 = var26.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var35 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, 1.0d);
//     org.jfree.data.time.Year var36 = var26.getYear();
//     long var37 = var36.getFirstMillisecond();
//     java.lang.Class var41 = null;
//     org.jfree.data.time.TimeSeries var42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var41);
//     var42.removeAgedItems(false);
//     java.util.Collection var45 = var42.getTimePeriods();
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var49);
//     boolean var51 = var50.isEmpty();
//     java.lang.String var52 = var50.getDescription();
//     java.util.Collection var53 = var42.getTimePeriodsUniqueToOtherSeries(var50);
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var55);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     long var58 = var57.getSerialIndex();
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var60 = var56.createCopy((org.jfree.data.time.RegularTimePeriod)var57, (org.jfree.data.time.RegularTimePeriod)var59);
//     int var61 = var56.getItemCount();
//     boolean var62 = var56.isEmpty();
//     java.lang.String var63 = var56.getRangeDescription();
//     java.lang.Class var65 = null;
//     org.jfree.data.time.TimeSeries var66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var65);
//     org.jfree.data.time.Day var67 = new org.jfree.data.time.Day();
//     long var68 = var67.getSerialIndex();
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var70 = var66.createCopy((org.jfree.data.time.RegularTimePeriod)var67, (org.jfree.data.time.RegularTimePeriod)var69);
//     int var71 = var66.getItemCount();
//     boolean var72 = var66.isEmpty();
//     java.lang.String var73 = var66.getRangeDescription();
//     java.util.Collection var74 = var56.getTimePeriodsUniqueToOtherSeries(var66);
//     var66.fireSeriesChanged();
//     java.util.Collection var76 = var42.getTimePeriodsUniqueToOtherSeries(var66);
//     java.util.Collection var77 = org.jfree.chart.util.ObjectUtilities.deepClone(var76);
//     boolean var78 = var36.equals((java.lang.Object)var76);
//     java.util.Collection var79 = org.jfree.chart.util.ObjectUtilities.deepClone(var76);
//     java.lang.Object var80 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "Value"+ "'", var63.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var73 + "' != '" + "Value"+ "'", var73.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
// 
//   }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test68"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     java.lang.String var3 = var1.toString();
//     java.util.Calendar var4 = null;
//     long var5 = var1.getLastMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var1.getMiddleMillisecond(var6);
//     java.lang.Object var8 = null;
//     boolean var9 = var1.equals(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var3.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test69"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     boolean var23 = var22.getNotify();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var22.setMaximumItemCount((-10635));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test70"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var2);
//     var5.setDescription("December 2014");
//     java.lang.String var8 = var5.getDescription();
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "December 2014"+ "'", var8.equals("December 2014"));
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test71"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     java.lang.Object var29 = null;
//     boolean var30 = var6.equals(var29);
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month();
//     java.lang.String var32 = var31.toString();
//     java.util.Date var33 = var31.getStart();
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(var33);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(var33);
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var33);
//     org.jfree.data.time.SerialDate var37 = var6.getEndOfCurrentMonth(var36);
//     int var38 = var6.getMonth();
//     int var39 = var6.getMonth();
//     int var40 = var6.getMonth();
//     java.util.Date var41 = var6.toDate();
//     java.lang.String var42 = var6.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "December 2014"+ "'", var32.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "30-January-1900"+ "'", var42.equals("30-January-1900"));
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test72"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var3);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10L);
//     long var11 = var7.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var7);
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var3, (java.lang.Object)var12);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(var3);
//     java.lang.String var15 = var14.toString();
//     java.lang.String var16 = var14.toString();
//     org.jfree.data.general.SeriesException var18 = new org.jfree.data.general.SeriesException("20-December-2014");
//     java.lang.Throwable[] var19 = var18.getSuppressed();
//     org.jfree.data.general.SeriesException var21 = new org.jfree.data.general.SeriesException("20-December-2014");
//     var18.addSuppressed((java.lang.Throwable)var21);
//     org.jfree.data.general.SeriesException var24 = new org.jfree.data.general.SeriesException("20-December-2014");
//     java.lang.Throwable[] var25 = var24.getSuppressed();
//     org.jfree.data.general.SeriesException var27 = new org.jfree.data.general.SeriesException("20-December-2014");
//     var24.addSuppressed((java.lang.Throwable)var27);
//     java.lang.String var29 = var24.toString();
//     var21.addSuppressed((java.lang.Throwable)var24);
//     org.jfree.data.general.SeriesException var32 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=10.0]");
//     var21.addSuppressed((java.lang.Throwable)var32);
//     java.lang.Throwable[] var34 = var32.getSuppressed();
//     int var35 = var14.compareTo((java.lang.Object)var32);
//     java.util.Calendar var36 = null;
//     long var37 = var14.getFirstMillisecond(var36);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test73"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     int var13 = var11.getYear();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.previous();
//     org.jfree.data.general.SeriesChangeEvent var15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var11);
//     long var16 = var11.getLastMillisecond();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var21 = var20.getTime();
//     boolean var22 = var19.equals((java.lang.Object)var21);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var26 = var25.getTime();
//     boolean var27 = var24.equals((java.lang.Object)var26);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, (-1.0d));
//     long var32 = var29.getFirstMillisecond();
//     long var33 = var29.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, (java.lang.Number)(byte)0);
//     java.lang.String var36 = var29.toString();
//     java.lang.String var37 = var29.toString();
//     org.jfree.data.time.SerialDate var38 = var29.getSerialDate();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var38);
//     org.jfree.data.time.FixedMillisecond var41 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var42 = var41.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.addDays(2014, var43);
//     boolean var45 = var24.isInRange(var39, var44);
//     org.jfree.data.time.SerialDate var46 = var19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var24);
//     java.lang.String var47 = var19.toString();
//     int var48 = var19.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var51 = var50.toSerial();
//     org.jfree.data.time.Day var52 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var50);
//     int var53 = var50.getYYYY();
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (-1.0d));
//     long var58 = var55.getFirstMillisecond();
//     long var59 = var55.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (java.lang.Number)(byte)0);
//     java.lang.String var62 = var55.toString();
//     java.lang.String var63 = var55.toString();
//     org.jfree.data.time.SerialDate var64 = var55.getSerialDate();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var64);
//     org.jfree.data.time.Day var66 = new org.jfree.data.time.Day();
//     long var67 = var66.getSerialIndex();
//     org.jfree.data.time.SerialDate var68 = var66.getSerialDate();
//     boolean var70 = var50.isInRange(var65, var68, 100);
//     org.jfree.data.time.FixedMillisecond var72 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var73 = var72.getTime();
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var73);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.addDays(2014, var74);
//     org.jfree.data.time.SerialDate var76 = var65.getEndOfCurrentMonth(var74);
//     var65.setDescription("20-December-2014");
//     boolean var79 = var19.isAfter(var65);
//     var19.setDescription("org.jfree.data.general.SeriesException: October");
//     java.lang.String var82 = var19.toString();
//     org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.addMonths(2015, (org.jfree.data.time.SerialDate)var19);
//     int var84 = var11.compareTo((java.lang.Object)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "20-December-2014"+ "'", var36.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "20-December-2014"+ "'", var37.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "30-January-1900"+ "'", var47.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "20-December-2014"+ "'", var62.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "20-December-2014"+ "'", var63.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var82 + "' != '" + "30-January-1900"+ "'", var82.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test74"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var1 = var0.getYear();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(0L);
    boolean var4 = var0.equals((java.lang.Object)var3);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "org.jfree.data.general.SeriesChangeEvent[source=14-December-2014]", "", var7);
    var8.setNotify(true);
    java.beans.PropertyChangeListener var11 = null;
    var8.removePropertyChangeListener(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test75"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-11), 2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test76"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)10L);
//     long var5 = var1.getSerialIndex();
//     java.util.Calendar var6 = null;
//     long var7 = var1.getMiddleMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var1.getMiddleMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var1.previous();
//     java.util.Calendar var11 = null;
//     var1.peg(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var2.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test77"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.setDomainDescription("20-December-2014");
//     var6.removeAgedItems(true);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     java.util.Date var28 = var27.getEnd();
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(var28);
//     org.jfree.data.time.RegularTimePeriod var30 = var29.next();
//     long var31 = var29.getFirstMillisecond();
//     int var32 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var29);
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var34);
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     long var37 = var36.getSerialIndex();
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var39 = var35.createCopy((org.jfree.data.time.RegularTimePeriod)var36, (org.jfree.data.time.RegularTimePeriod)var38);
//     int var40 = var38.getDayOfMonth();
//     long var41 = var38.getFirstMillisecond();
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var38);
//     boolean var44 = var6.equals((java.lang.Object)1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test78"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(1419140714346L);
    long var3 = var2.getFirstMillisecond();
    boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1419140743166L, (java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1419140714346L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test79"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     var2.clear();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var12);
//     var13.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var13.removeChangeListener(var15);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var20);
//     var21.removeAgedItems(false);
//     java.util.Collection var24 = var21.getTimePeriods();
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var28);
//     boolean var30 = var29.isEmpty();
//     java.lang.String var31 = var29.getDescription();
//     java.util.Collection var32 = var21.getTimePeriodsUniqueToOtherSeries(var29);
//     org.jfree.data.time.TimeSeries var33 = var13.addAndOrUpdate(var21);
//     var33.setMaximumItemAge(0L);
//     var33.removeAgedItems(false);
//     java.lang.Object var38 = null;
//     boolean var39 = var33.equals(var38);
//     org.jfree.data.time.TimeSeries var40 = var2.addAndOrUpdate(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(12, 13, (-11));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test81"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (-1.0d));
//     long var4 = var1.getFirstMillisecond();
//     long var5 = var1.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var11 = var10.getTime();
//     boolean var12 = var9.equals((java.lang.Object)var11);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     long var17 = var14.getFirstMillisecond();
//     long var18 = var14.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)(byte)0);
//     java.lang.String var21 = var14.toString();
//     java.lang.String var22 = var14.toString();
//     org.jfree.data.time.SerialDate var23 = var14.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var27 = var26.getTime();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addDays(2014, var28);
//     boolean var30 = var9.isInRange(var24, var29);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var33 = var32.toSerial();
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month();
//     int var36 = var34.compareTo((java.lang.Object)'4');
//     java.util.Date var37 = var34.getStart();
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var40 = var39.toString();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)10L);
//     int var43 = var34.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var44 = new org.jfree.data.time.Month();
//     java.lang.String var45 = var44.toString();
//     java.util.Date var46 = var44.getStart();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var46);
//     int var48 = var34.compareTo((java.lang.Object)var47);
//     org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var52 = var51.getTime();
//     boolean var53 = var50.equals((java.lang.Object)var52);
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (-1.0d));
//     long var58 = var55.getFirstMillisecond();
//     long var59 = var55.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (java.lang.Number)(byte)0);
//     java.lang.String var62 = var55.toString();
//     java.lang.String var63 = var55.toString();
//     org.jfree.data.time.SerialDate var64 = var55.getSerialDate();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var64);
//     org.jfree.data.time.FixedMillisecond var67 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var68 = var67.getTime();
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.createInstance(var68);
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.addDays(2014, var69);
//     boolean var71 = var50.isInRange(var65, var70);
//     boolean var73 = var32.isInRange(var47, var65, 1);
//     boolean var74 = var9.isBefore((org.jfree.data.time.SerialDate)var32);
//     int var75 = var7.compareTo((java.lang.Object)var9);
//     org.jfree.data.time.SpreadsheetDate var77 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var78 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var79 = var78.getTime();
//     boolean var80 = var77.equals((java.lang.Object)var79);
//     boolean var81 = var9.isBefore((org.jfree.data.time.SerialDate)var77);
//     int var82 = var77.getDayOfWeek();
//     var77.setDescription("Oct");
//     int var85 = var77.getDayOfMonth();
//     int var86 = var77.getMonth();
//     org.jfree.data.time.SerialDate var87 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate)var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var40.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "December 2014"+ "'", var45.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "20-December-2014"+ "'", var62.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "20-December-2014"+ "'", var63.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test82"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var7);
//     boolean var9 = var8.isEmpty();
//     var8.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var14 = var13.toString();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, 1.0d);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var13.previous();
//     java.util.Date var21 = var13.getTime();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day(var21);
//     java.lang.String var23 = var22.toString();
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var27 = var26.toSerial();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month();
//     int var30 = var28.compareTo((java.lang.Object)'4');
//     java.util.Date var31 = var28.getStart();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var34 = var33.toString();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)10L);
//     int var37 = var28.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     java.lang.String var39 = var38.toString();
//     java.util.Date var40 = var38.getStart();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     int var42 = var28.compareTo((java.lang.Object)var41);
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var46 = var45.getTime();
//     boolean var47 = var44.equals((java.lang.Object)var46);
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (-1.0d));
//     long var52 = var49.getFirstMillisecond();
//     long var53 = var49.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)(byte)0);
//     java.lang.String var56 = var49.toString();
//     java.lang.String var57 = var49.toString();
//     org.jfree.data.time.SerialDate var58 = var49.getSerialDate();
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var58);
//     org.jfree.data.time.FixedMillisecond var61 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var62 = var61.getTime();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addDays(2014, var63);
//     boolean var65 = var44.isInRange(var59, var64);
//     boolean var67 = var26.isInRange(var41, var59, 1);
//     java.lang.String var68 = var26.getDescription();
//     org.jfree.data.time.Month var69 = new org.jfree.data.time.Month();
//     int var71 = var69.compareTo((java.lang.Object)'4');
//     java.util.Date var72 = var69.getStart();
//     boolean var73 = var26.equals((java.lang.Object)var72);
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.addYears(30, (org.jfree.data.time.SerialDate)var26);
//     int var75 = var22.compareTo((java.lang.Object)var26);
//     int var76 = var22.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var14.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "31-December-1969"+ "'", var23.equals("31-December-1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var34.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "December 2014"+ "'", var39.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "20-December-2014"+ "'", var56.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "20-December-2014"+ "'", var57.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1969);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test83"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     long var5 = var4.getMaximumItemAge();
//     java.util.List var6 = var4.getItems();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var10 = var7.getFirstMillisecond();
//     long var11 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)0);
//     java.lang.String var14 = var7.toString();
//     java.lang.String var15 = var7.toString();
//     org.jfree.data.time.SerialDate var16 = var7.getSerialDate();
//     long var17 = var7.getSerialIndex();
//     int var18 = var7.getMonth();
//     java.lang.String var19 = var7.toString();
//     java.lang.Number var20 = var4.getValue((org.jfree.data.time.RegularTimePeriod)var7);
//     var4.clear();
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var23);
//     var24.fireSeriesChanged();
//     var24.fireSeriesChanged();
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, (-1.0d));
//     int var30 = var27.getYear();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var32 = var24.createCopy((org.jfree.data.time.RegularTimePeriod)var27, (org.jfree.data.time.RegularTimePeriod)var31);
//     var32.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=false]");
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (-1.0d));
//     int var38 = var35.getYear();
//     long var39 = var35.getLastMillisecond();
//     int var40 = var35.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, 1.0d);
//     var32.setKey((java.lang.Comparable)var35);
//     int var44 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var35);
//     long var45 = var35.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 41993L);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test84"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    var4.removeAgedItems(false);
    java.lang.Class var7 = var4.getTimePeriodClass();
    var4.setDomainDescription("Time");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var10 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test85"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getFirstMillisecond();
//     java.util.Calendar var5 = null;
//     var2.peg(var5);
//     long var7 = var2.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(short)0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1420099199999L);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test86"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     boolean var10 = var7.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var25 = var24.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(2014, var26);
//     boolean var28 = var7.isInRange(var22, var27);
//     org.jfree.data.time.SerialDate var29 = var2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var7);
//     java.util.Date var30 = var7.toDate();
//     int var31 = var7.getMonth();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var7);
//     org.jfree.data.time.RegularTimePeriod var33 = var32.next();
//     int var34 = var32.getMonth();
//     org.jfree.data.time.SerialDate var35 = var32.getSerialDate();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addMonths(4, var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test87"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getSerialIndex();
//     org.jfree.data.time.SerialDate var2 = var0.getSerialDate();
//     java.lang.Object var3 = null;
//     boolean var4 = var0.equals(var3);
//     int var5 = var0.getYear();
//     java.lang.String var6 = var0.toString();
//     int var7 = var0.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "20-December-2014"+ "'", var6.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 20);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test88"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy(0, 0);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var10.addChangeListener(var11);
//     var10.setMaximumItemAge(1419140750537L);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var16);
//     var17.fireSeriesChanged();
//     java.lang.Class var22 = null;
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var22);
//     boolean var24 = var23.isEmpty();
//     var23.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var29 = var28.toString();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var23.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var28, 1.0d);
//     var17.delete((org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, 10.0d);
//     org.jfree.data.time.TimeSeriesDataItem var35 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var29.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test89"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     java.lang.Object var3 = var2.clone();
//     java.lang.Number var4 = var2.getValue();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     long var8 = var5.getFirstMillisecond();
//     long var9 = var5.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)(byte)0);
//     java.lang.String var12 = var5.toString();
//     java.lang.String var13 = var5.toString();
//     org.jfree.data.time.SerialDate var14 = var5.getSerialDate();
//     long var15 = var5.getSerialIndex();
//     int var16 = var5.getMonth();
//     java.lang.String var17 = var5.toString();
//     boolean var18 = var2.equals((java.lang.Object)var17);
//     java.lang.Object var19 = var2.clone();
//     java.lang.Object var20 = var2.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + (-1.0d)+ "'", var4.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "20-December-2014"+ "'", var12.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "20-December-2014"+ "'", var17.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test90"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     org.jfree.data.time.RegularTimePeriod var8 = var6.getPeriod();
//     var6.setValue((java.lang.Number)1419140710770L);
//     org.jfree.data.time.RegularTimePeriod var11 = var6.getPeriod();
//     java.lang.Number var12 = var6.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + 1419140710770L+ "'", var12.equals(1419140710770L));
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test91"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.previous();
//     java.lang.String var5 = var0.toString();
//     java.lang.String var6 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var7 = var0.next();
//     java.util.Calendar var8 = null;
//     long var9 = var0.getLastMillisecond(var8);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test93"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     long var16 = var13.getFirstMillisecond();
//     long var17 = var13.getLastMillisecond();
//     int var18 = var13.getDayOfMonth();
//     org.jfree.data.general.SeriesChangeEvent var19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var13);
//     java.lang.String var20 = var19.toString();
//     int var21 = var11.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11);
//     org.jfree.data.time.RegularTimePeriod var23 = var11.next();
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var27);
//     var28.removeAgedItems(false);
//     java.util.Collection var31 = var28.getTimePeriods();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var35);
//     boolean var37 = var36.isEmpty();
//     java.lang.String var38 = var36.getDescription();
//     java.util.Collection var39 = var28.getTimePeriodsUniqueToOtherSeries(var36);
//     int var40 = var11.compareTo((java.lang.Object)var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]"+ "'", var20.equals("org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test94"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     long var13 = var11.getSerialIndex();
//     long var14 = var11.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var15 = var11.next();
//     java.util.Calendar var16 = null;
//     long var17 = var11.getLastMillisecond(var16);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test95"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     var6.setValue((java.lang.Number)41993L);
//     java.lang.Number var9 = var6.getValue();
//     var6.setValue((java.lang.Number)1969);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + 41993L+ "'", var9.equals(41993L));
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test96"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     long var5 = var4.getSerialIndex();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var7 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var4, (org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.general.SeriesChangeListener var8 = null;
//     var7.addChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var7.removeChangeListener(var10);
//     var7.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     java.lang.Object var17 = var16.clone();
//     java.lang.Number var18 = var16.getValue();
//     org.jfree.data.time.RegularTimePeriod var19 = var16.getPeriod();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     java.lang.String var21 = var20.toString();
//     java.util.Date var22 = var20.getStart();
//     org.jfree.data.time.TimeSeries var23 = var7.createCopy(var19, (org.jfree.data.time.RegularTimePeriod)var20);
//     java.util.Date var24 = var20.getEnd();
//     java.util.TimeZone var25 = null;
//     org.jfree.data.time.RegularTimePeriod var26 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var24, var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day(var24);
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(var24);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + (-1.0d)+ "'", var18.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "December 2014"+ "'", var21.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test97"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    java.util.Date var2 = var1.getEnd();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
    org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
    java.util.TimeZone var5 = null;
    org.jfree.data.time.RegularTimePeriod var6 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var2, var5);
    org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var2);
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var2);
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var2);
    java.util.TimeZone var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var11 = new org.jfree.data.time.Day(var2, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test98"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     java.lang.String var3 = var2.getDomainDescription();
//     var2.clear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var6);
//     var7.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.Class var10 = var7.getTimePeriodClass();
//     java.lang.String var11 = var7.getDescription();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var15);
//     var16.clear();
//     java.util.Collection var18 = var7.getTimePeriodsUniqueToOtherSeries(var16);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var20);
//     var21.fireSeriesChanged();
//     var21.setMaximumItemCount(0);
//     var21.setMaximumItemAge(1L);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var28);
//     var29.fireSeriesChanged();
//     var29.setMaximumItemCount(0);
//     var29.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month();
//     java.lang.Number var36 = var29.getValue((org.jfree.data.time.RegularTimePeriod)var35);
//     var21.delete((org.jfree.data.time.RegularTimePeriod)var35);
//     var21.fireSeriesChanged();
//     java.lang.Class var39 = var21.getTimePeriodClass();
//     java.lang.Class var40 = var21.getTimePeriodClass();
//     org.jfree.data.time.TimeSeries var41 = var7.addAndOrUpdate(var21);
//     org.jfree.data.time.TimeSeries var42 = var2.addAndOrUpdate(var21);
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     java.util.Date var44 = var43.getEnd();
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond(var44);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(var44);
//     long var47 = var46.getFirstMillisecond();
//     long var48 = var46.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var49 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var50 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var46, var49);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Time"+ "'", var3.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var11.equals("SerialDate.weekInMonthToString(): invalid code."));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1420099199999L);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test99"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     long var7 = var0.getSerialIndex();
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     java.lang.String var9 = var8.toString();
//     java.util.Date var10 = var8.getStart();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     boolean var13 = var0.equals((java.lang.Object)var10);
//     org.jfree.data.time.RegularTimePeriod var14 = var0.next();
//     java.lang.String var15 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "December 2014"+ "'", var9.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test100"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.getMonth();
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var7 = var6.getTime();
//     boolean var8 = var5.equals((java.lang.Object)var7);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (-1.0d));
//     long var13 = var10.getFirstMillisecond();
//     long var14 = var10.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(byte)0);
//     java.lang.String var17 = var10.toString();
//     java.lang.String var18 = var10.toString();
//     org.jfree.data.time.SerialDate var19 = var10.getSerialDate();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var19);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var23 = var22.getTime();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addDays(2014, var24);
//     boolean var26 = var5.isInRange(var20, var25);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var29 = var28.toSerial();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month();
//     int var32 = var30.compareTo((java.lang.Object)'4');
//     java.util.Date var33 = var30.getStart();
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var36 = var35.toString();
//     org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)10L);
//     int var39 = var30.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var40 = new org.jfree.data.time.Month();
//     java.lang.String var41 = var40.toString();
//     java.util.Date var42 = var40.getStart();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     int var44 = var30.compareTo((java.lang.Object)var43);
//     org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var48 = var47.getTime();
//     boolean var49 = var46.equals((java.lang.Object)var48);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var51, (-1.0d));
//     long var54 = var51.getFirstMillisecond();
//     long var55 = var51.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var51, (java.lang.Number)(byte)0);
//     java.lang.String var58 = var51.toString();
//     java.lang.String var59 = var51.toString();
//     org.jfree.data.time.SerialDate var60 = var51.getSerialDate();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var60);
//     org.jfree.data.time.FixedMillisecond var63 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var64 = var63.getTime();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.createInstance(var64);
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addDays(2014, var65);
//     boolean var67 = var46.isInRange(var61, var66);
//     boolean var69 = var28.isInRange(var43, var61, 1);
//     boolean var70 = var5.isBefore((org.jfree.data.time.SerialDate)var28);
//     org.jfree.data.time.SerialDate var71 = org.jfree.data.time.SerialDate.addYears(31, (org.jfree.data.time.SerialDate)var5);
//     boolean var72 = var1.isOnOrBefore(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "20-December-2014"+ "'", var17.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var36.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "December 2014"+ "'", var41.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "20-December-2014"+ "'", var58.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + "20-December-2014"+ "'", var59.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == true);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test101"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
    int var2 = var1.toSerial();
    org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
    int var4 = var1.getYYYY();
    java.util.Date var5 = var1.toDate();
    org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var5);
    java.lang.String var7 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "30-January-1900"+ "'", var7.equals("30-January-1900"));

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test102"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     java.lang.String var29 = var1.toString();
//     int var30 = var1.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var33 = var32.toSerial();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var32);
//     int var35 = var32.getYYYY();
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (-1.0d));
//     long var40 = var37.getFirstMillisecond();
//     long var41 = var37.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)(byte)0);
//     java.lang.String var44 = var37.toString();
//     java.lang.String var45 = var37.toString();
//     org.jfree.data.time.SerialDate var46 = var37.getSerialDate();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var46);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     long var49 = var48.getSerialIndex();
//     org.jfree.data.time.SerialDate var50 = var48.getSerialDate();
//     boolean var52 = var32.isInRange(var47, var50, 100);
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var55 = var54.getTime();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addDays(2014, var56);
//     org.jfree.data.time.SerialDate var58 = var47.getEndOfCurrentMonth(var56);
//     var47.setDescription("20-December-2014");
//     boolean var61 = var1.isAfter(var47);
//     org.jfree.data.time.TimeSeries var62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1);
//     org.jfree.data.time.FixedMillisecond var63 = new org.jfree.data.time.FixedMillisecond();
//     long var64 = var63.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var67 = var66.getTime();
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.addDays(2014, var68);
//     boolean var70 = var63.equals((java.lang.Object)var69);
//     java.lang.String var71 = var69.toString();
//     boolean var72 = var1.isBefore(var69);
//     int var73 = var1.getDayOfMonth();
//     int var74 = var1.getYYYY();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "30-January-1900"+ "'", var29.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "20-December-2014"+ "'", var44.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "20-December-2014"+ "'", var45.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419140802829L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var71 + "' != '" + "25-June-2020"+ "'", var71.equals("25-June-2020"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1900);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test103"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(2014, var20);
//     boolean var22 = var1.isInRange(var16, var21);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getSerialIndex();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var29 = var25.createCopy((org.jfree.data.time.RegularTimePeriod)var26, (org.jfree.data.time.RegularTimePeriod)var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var29.addChangeListener(var30);
//     org.jfree.data.general.SeriesChangeListener var32 = null;
//     var29.removeChangeListener(var32);
//     var29.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var36, (-1.0d));
//     java.lang.Object var39 = var38.clone();
//     java.lang.Number var40 = var38.getValue();
//     org.jfree.data.time.RegularTimePeriod var41 = var38.getPeriod();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     java.lang.String var43 = var42.toString();
//     java.util.Date var44 = var42.getStart();
//     org.jfree.data.time.TimeSeries var45 = var29.createCopy(var41, (org.jfree.data.time.RegularTimePeriod)var42);
//     var29.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var50 = var49.toString();
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)10L);
//     long var53 = var49.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var54 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var49);
//     int var55 = var29.getIndex((org.jfree.data.time.RegularTimePeriod)var49);
//     boolean var56 = var1.equals((java.lang.Object)var29);
//     var29.setDomainDescription("org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var61 = var29.createCopy((-460), 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + (-1.0d)+ "'", var40.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "December 2014"+ "'", var43.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var50.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test104"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     long var4 = var2.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var5 = var2.previous();
//     long var6 = var2.getFirstMillisecond();
//     long var7 = var2.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1420099199999L);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test105"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     java.lang.String var8 = var2.getDescription();
//     var2.clear();
//     java.util.List var10 = var2.getItems();
//     java.beans.PropertyChangeListener var11 = null;
//     var2.removePropertyChangeListener(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test106"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     long var7 = var0.getSerialIndex();
//     long var8 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419062400000L);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test107"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     org.jfree.data.time.RegularTimePeriod var12 = var9.next();
//     org.jfree.data.time.Year var13 = var9.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test108"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419140710770L);
    long var2 = var1.getLastMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1419140710770L);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test109"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.getMonth();
//     java.lang.String var3 = var1.getDescription();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     java.util.Date var5 = var4.getEnd();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var10 = var9.getTime();
//     boolean var11 = var8.equals((java.lang.Object)var10);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var15 = var14.getTime();
//     boolean var16 = var13.equals((java.lang.Object)var15);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (-1.0d));
//     long var21 = var18.getFirstMillisecond();
//     long var22 = var18.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)(byte)0);
//     java.lang.String var25 = var18.toString();
//     java.lang.String var26 = var18.toString();
//     org.jfree.data.time.SerialDate var27 = var18.getSerialDate();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var27);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addDays(2014, var32);
//     boolean var34 = var13.isInRange(var28, var33);
//     org.jfree.data.time.SerialDate var35 = var8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var13);
//     java.util.Date var36 = var13.toDate();
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond();
//     long var39 = var38.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var41 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var42 = var41.getTime();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.addDays(2014, var43);
//     boolean var45 = var38.equals((java.lang.Object)var44);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.addDays((-452), var44);
//     boolean var47 = var13.isAfter(var46);
//     boolean var48 = var1.isInRange(var6, var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "20-December-2014"+ "'", var25.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419140802946L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test110"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     int var8 = var0.getYear();
//     int var9 = var0.getMonth();
//     int var10 = var0.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var11 = var0.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var0.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test111"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test112"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.removeChangeListener(var4);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
    var10.removeAgedItems(false);
    java.util.Collection var13 = var10.getTimePeriods();
    java.lang.Class var17 = null;
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
    boolean var19 = var18.isEmpty();
    java.lang.String var20 = var18.getDescription();
    java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
    org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
    var22.setMaximumItemAge(0L);
    var22.setRangeDescription("2015");
    var22.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test113"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     var4.clear();
//     var4.setDomainDescription("");
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var10 = null;
//     long var11 = var9.getMiddleMillisecond(var10);
//     int var12 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var14);
//     var15.fireSeriesChanged();
//     var15.fireSeriesChanged();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (-1.0d));
//     int var21 = var18.getYear();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var23 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var18, (org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.Year var24 = var22.getYear();
//     java.lang.String var25 = var24.toString();
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var29);
//     boolean var31 = var30.isEmpty();
//     var30.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var36 = var35.toString();
//     org.jfree.data.time.TimeSeriesDataItem var38 = var30.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var35, 1.0d);
//     boolean var39 = var24.equals((java.lang.Object)var35);
//     long var40 = var24.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var41 = var24.next();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     java.lang.Class var44 = null;
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var44);
//     var45.fireSeriesChanged();
//     var45.fireSeriesChanged();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, (-1.0d));
//     int var51 = var48.getYear();
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var53 = var45.createCopy((org.jfree.data.time.RegularTimePeriod)var48, (org.jfree.data.time.RegularTimePeriod)var52);
//     org.jfree.data.time.Year var54 = var52.getYear();
//     long var55 = var54.getSerialIndex();
//     long var56 = var54.getSerialIndex();
//     long var57 = var54.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var54);
//     int var59 = var24.compareTo((java.lang.Object)var58);
//     java.util.Calendar var60 = null;
//     long var61 = var24.getMiddleMillisecond(var60);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test114"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var2);
//     java.util.TimeZone var8 = null;
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var2, var8);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test115"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     java.lang.String var2 = var1.toString();
//     java.util.Date var3 = var1.getStart();
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.RegularTimePeriod var5 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var3, var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "December 2014"+ "'", var2.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test116"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     java.lang.Object var8 = var7.clone();
//     java.lang.Number var9 = var7.getValue();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.getPeriod();
//     boolean var11 = var4.equals((java.lang.Object)var10);
//     long var12 = var4.getFirstMillisecond();
//     long var13 = var4.getFirstMillisecond();
//     long var14 = var4.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (-1.0d)+ "'", var9.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test117"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    java.util.Date var4 = var1.getEnd();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test118"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     long var13 = var11.getSerialIndex();
//     long var14 = var11.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11);
//     long var16 = var11.getSerialIndex();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var21 = var20.getTime();
//     boolean var22 = var19.equals((java.lang.Object)var21);
//     int var23 = var19.toSerial();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate)var19);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day(var24);
//     boolean var26 = var11.equals((java.lang.Object)var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test119"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.lang.String var2 = var0.toString();
//     long var3 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var4 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "December 2014"+ "'", var2.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test120"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("31-December-1969", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test121"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     java.lang.Number var9 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.addChangeListener(var10);
//     java.beans.PropertyChangeListener var12 = null;
//     var2.addPropertyChangeListener(var12);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     int var16 = var14.compareTo((java.lang.Object)'4');
//     java.util.Date var17 = var14.getStart();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var20 = var19.toString();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)10L);
//     int var23 = var14.compareTo((java.lang.Object)10L);
//     java.util.Date var24 = var14.getStart();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.RegularTimePeriod var26 = var14.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var20.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test122"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)(-1), var1);
//     java.util.Collection var3 = var2.getTimePeriods();
//     java.lang.Comparable var4 = var2.getKey();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var7 = var6.toString();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)10L);
//     long var10 = var6.getSerialIndex();
//     java.util.Calendar var11 = null;
//     long var12 = var6.getMiddleMillisecond(var11);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var14);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     long var17 = var16.getSerialIndex();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var19 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.general.SeriesChangeListener var20 = null;
//     var19.addChangeListener(var20);
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var19.removeChangeListener(var22);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var25);
//     var26.fireSeriesChanged();
//     var26.setMaximumItemCount(0);
//     var26.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     java.lang.Number var33 = var26.getValue((org.jfree.data.time.RegularTimePeriod)var32);
//     java.lang.String var34 = var32.toString();
//     org.jfree.data.time.TimeSeriesDataItem var35 = var19.getDataItem((org.jfree.data.time.RegularTimePeriod)var32);
//     long var36 = var32.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var37 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var32);
//     java.lang.String var38 = var32.toString();
//     java.util.Calendar var39 = null;
//     var32.peg(var39);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test123"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     java.util.Date var4 = var3.getEnd();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     boolean var6 = var0.equals((java.lang.Object)var4);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test124"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.removeChangeListener(var4);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
//     var10.removeAgedItems(false);
//     java.util.Collection var13 = var10.getTimePeriods();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
//     boolean var19 = var18.isEmpty();
//     java.lang.String var20 = var18.getDescription();
//     java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
//     org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getSerialIndex();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var29 = var25.createCopy((org.jfree.data.time.RegularTimePeriod)var26, (org.jfree.data.time.RegularTimePeriod)var28);
//     int var30 = var25.getItemCount();
//     var25.removeAgedItems(false);
//     var25.clear();
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var35 = var34.previous();
//     org.jfree.data.time.RegularTimePeriod var36 = var34.previous();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var25.getDataItem((org.jfree.data.time.RegularTimePeriod)var34);
//     org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var40 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var41 = var40.getTime();
//     boolean var42 = var39.equals((java.lang.Object)var41);
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var46 = var45.getTime();
//     boolean var47 = var44.equals((java.lang.Object)var46);
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (-1.0d));
//     long var52 = var49.getFirstMillisecond();
//     long var53 = var49.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)(byte)0);
//     java.lang.String var56 = var49.toString();
//     java.lang.String var57 = var49.toString();
//     org.jfree.data.time.SerialDate var58 = var49.getSerialDate();
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var58);
//     org.jfree.data.time.FixedMillisecond var61 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var62 = var61.getTime();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addDays(2014, var63);
//     boolean var65 = var44.isInRange(var59, var64);
//     org.jfree.data.time.SerialDate var66 = var39.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var44);
//     java.util.Date var67 = var44.toDate();
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day(var67);
//     org.jfree.data.time.Day var70 = new org.jfree.data.time.Day(var67);
//     org.jfree.data.time.TimeSeriesDataItem var72 = var25.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var70, (java.lang.Number)12);
//     org.jfree.data.time.RegularTimePeriod var73 = var70.previous();
//     long var74 = var70.getSerialIndex();
//     org.jfree.data.time.Month var75 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var76 = var75.previous();
//     org.jfree.data.time.RegularTimePeriod var77 = var75.previous();
//     int var78 = var70.compareTo((java.lang.Object)var75);
//     int var79 = var75.getYearValue();
//     var10.setKey((java.lang.Comparable)var75);
//     org.jfree.data.time.RegularTimePeriod var81 = var75.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "20-December-2014"+ "'", var56.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "20-December-2014"+ "'", var57.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 31L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test125"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     java.lang.Object var8 = var7.clone();
//     java.lang.Number var9 = var7.getValue();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.getPeriod();
//     boolean var11 = var4.equals((java.lang.Object)var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var4.previous();
//     long var13 = var4.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
//     java.util.Date var16 = var4.getTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (-1.0d)+ "'", var9.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test126"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     var1.setDescription("Following");
//     java.util.Date var31 = var1.toDate();
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var35 = var34.getTime();
//     boolean var36 = var33.equals((java.lang.Object)var35);
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(var35);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var40 = var39.toString();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)10L);
//     long var43 = var39.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var44 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var39);
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var35, (java.lang.Object)var44);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day(var35);
//     org.jfree.data.time.SerialDate var47 = var46.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var52 = var51.getTime();
//     boolean var53 = var50.equals((java.lang.Object)var52);
//     org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var57 = var56.getTime();
//     boolean var58 = var55.equals((java.lang.Object)var57);
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var60, (-1.0d));
//     long var63 = var60.getFirstMillisecond();
//     long var64 = var60.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var60, (java.lang.Number)(byte)0);
//     java.lang.String var67 = var60.toString();
//     java.lang.String var68 = var60.toString();
//     org.jfree.data.time.SerialDate var69 = var60.getSerialDate();
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var69);
//     org.jfree.data.time.FixedMillisecond var72 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var73 = var72.getTime();
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var73);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.addDays(2014, var74);
//     boolean var76 = var55.isInRange(var70, var75);
//     org.jfree.data.time.SerialDate var77 = var50.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var55);
//     java.util.Date var78 = var55.toDate();
//     int var79 = var55.getMonth();
//     int var80 = var55.getYYYY();
//     org.jfree.data.time.SerialDate var81 = org.jfree.data.time.SerialDate.addMonths(12, (org.jfree.data.time.SerialDate)var55);
//     boolean var83 = var1.isInRange(var47, (org.jfree.data.time.SerialDate)var55, (-11014));
//     int var84 = var1.getDayOfWeek();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var40.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var67 + "' != '" + "20-December-2014"+ "'", var67.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var68 + "' != '" + "20-December-2014"+ "'", var68.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 3);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test127"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     java.beans.PropertyChangeListener var9 = null;
//     var6.removePropertyChangeListener(var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     int var13 = var11.compareTo((java.lang.Object)'4');
//     boolean var14 = var6.equals((java.lang.Object)'4');
//     java.lang.String var15 = var6.getRangeDescription();
//     org.jfree.data.time.TimeSeries var18 = var6.createCopy(10, 2147483647);
//     var6.setMaximumItemAge(1419140712057L);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     java.lang.String var22 = var21.toString();
//     long var23 = var21.getSerialIndex();
//     long var24 = var21.getLastMillisecond();
//     java.util.Date var25 = var21.getEnd();
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day(var25);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     java.lang.String var28 = var27.toString();
//     java.util.Date var29 = var27.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(var29);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (-1.0d));
//     java.lang.Object var35 = var34.clone();
//     java.lang.Number var36 = var34.getValue();
//     org.jfree.data.time.RegularTimePeriod var37 = var34.getPeriod();
//     boolean var38 = var31.equals((java.lang.Object)var37);
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, (java.lang.Number)1388563200000L);
//     long var41 = var31.getSerialIndex();
//     java.util.Calendar var42 = null;
//     long var43 = var31.getFirstMillisecond(var42);
//     java.util.Date var44 = var31.getStart();
//     boolean var45 = var26.equals((java.lang.Object)var44);
//     java.lang.Number var46 = var6.getValue((org.jfree.data.time.RegularTimePeriod)var26);
//     var6.removeAgedItems(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var50 = var6.getDataItem(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "Value"+ "'", var15.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "December 2014"+ "'", var22.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "December 2014"+ "'", var28.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + (-1.0d)+ "'", var36.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test128"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
    java.lang.Object var3 = var2.clone();
    java.lang.Object var4 = var2.clone();
    java.lang.Number var5 = null;
    var2.setValue(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test129"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var1);
//     java.lang.String var5 = var4.toString();
//     org.jfree.data.time.RegularTimePeriod var6 = var4.next();
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var10 = var9.getTime();
//     boolean var11 = var8.equals((java.lang.Object)var10);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var15 = var14.getTime();
//     boolean var16 = var13.equals((java.lang.Object)var15);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (-1.0d));
//     long var21 = var18.getFirstMillisecond();
//     long var22 = var18.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)(byte)0);
//     java.lang.String var25 = var18.toString();
//     java.lang.String var26 = var18.toString();
//     org.jfree.data.time.SerialDate var27 = var18.getSerialDate();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var27);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addDays(2014, var32);
//     boolean var34 = var13.isInRange(var28, var33);
//     org.jfree.data.time.SerialDate var35 = var8.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var13);
//     java.lang.Object var36 = null;
//     boolean var37 = var13.equals(var36);
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     java.lang.String var39 = var38.toString();
//     java.util.Date var40 = var38.getStart();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(var40);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.SerialDate var44 = var13.getEndOfCurrentMonth(var43);
//     boolean var45 = var4.equals((java.lang.Object)var44);
//     java.lang.String var46 = var4.toString();
//     org.jfree.data.time.RegularTimePeriod var47 = var4.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "2014"+ "'", var5.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "20-December-2014"+ "'", var25.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "20-December-2014"+ "'", var26.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "December 2014"+ "'", var39.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "2014"+ "'", var46.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test130"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     int var5 = var3.compareTo((java.lang.Object)'4');
//     java.util.Date var6 = var3.getStart();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var9 = var8.toString();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)10L);
//     int var12 = var3.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     java.lang.String var14 = var13.toString();
//     java.util.Date var15 = var13.getStart();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     int var17 = var3.compareTo((java.lang.Object)var16);
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var21 = var20.getTime();
//     boolean var22 = var19.equals((java.lang.Object)var21);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (-1.0d));
//     long var27 = var24.getFirstMillisecond();
//     long var28 = var24.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)(byte)0);
//     java.lang.String var31 = var24.toString();
//     java.lang.String var32 = var24.toString();
//     org.jfree.data.time.SerialDate var33 = var24.getSerialDate();
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var33);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var37 = var36.getTime();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var37);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addDays(2014, var38);
//     boolean var40 = var19.isInRange(var34, var39);
//     boolean var42 = var1.isInRange(var16, var34, 1);
//     java.lang.String var43 = var1.getDescription();
//     int var44 = var1.getMonth();
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var47 = var46.toString();
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, (-1.0d));
//     int var51 = var48.getYear();
//     org.jfree.data.time.RegularTimePeriod var52 = var48.previous();
//     int var53 = var46.compareTo((java.lang.Object)var48);
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month();
//     boolean var55 = var48.equals((java.lang.Object)var54);
//     java.lang.Class var57 = null;
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var57);
//     var58.fireSeriesChanged();
//     var58.fireSeriesChanged();
//     org.jfree.data.time.Day var61 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var61, (-1.0d));
//     int var64 = var61.getYear();
//     org.jfree.data.time.Month var65 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var66 = var58.createCopy((org.jfree.data.time.RegularTimePeriod)var61, (org.jfree.data.time.RegularTimePeriod)var65);
//     java.util.Date var67 = var61.getEnd();
//     boolean var68 = var48.equals((java.lang.Object)var61);
//     boolean var69 = var1.equals((java.lang.Object)var61);
//     java.lang.Object var70 = null;
//     boolean var71 = var1.equals(var70);
//     int var72 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var76 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var77 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var78 = var77.getTime();
//     boolean var79 = var76.equals((java.lang.Object)var78);
//     int var80 = var76.toSerial();
//     org.jfree.data.time.SerialDate var81 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate)var76);
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.addMonths(0, var81);
//     boolean var83 = var1.isOnOrAfter(var82);
//     java.util.Date var84 = var1.toDate();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var9.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "December 2014"+ "'", var14.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "20-December-2014"+ "'", var31.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "20-December-2014"+ "'", var32.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var47.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test131"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (-1.0d));
//     long var4 = var1.getFirstMillisecond();
//     long var5 = var1.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var11 = var10.getTime();
//     boolean var12 = var9.equals((java.lang.Object)var11);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     long var17 = var14.getFirstMillisecond();
//     long var18 = var14.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)(byte)0);
//     java.lang.String var21 = var14.toString();
//     java.lang.String var22 = var14.toString();
//     org.jfree.data.time.SerialDate var23 = var14.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var27 = var26.getTime();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addDays(2014, var28);
//     boolean var30 = var9.isInRange(var24, var29);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var33 = var32.toSerial();
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month();
//     int var36 = var34.compareTo((java.lang.Object)'4');
//     java.util.Date var37 = var34.getStart();
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var40 = var39.toString();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)10L);
//     int var43 = var34.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var44 = new org.jfree.data.time.Month();
//     java.lang.String var45 = var44.toString();
//     java.util.Date var46 = var44.getStart();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var46);
//     int var48 = var34.compareTo((java.lang.Object)var47);
//     org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var52 = var51.getTime();
//     boolean var53 = var50.equals((java.lang.Object)var52);
//     org.jfree.data.time.Day var55 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (-1.0d));
//     long var58 = var55.getFirstMillisecond();
//     long var59 = var55.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, (java.lang.Number)(byte)0);
//     java.lang.String var62 = var55.toString();
//     java.lang.String var63 = var55.toString();
//     org.jfree.data.time.SerialDate var64 = var55.getSerialDate();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var64);
//     org.jfree.data.time.FixedMillisecond var67 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var68 = var67.getTime();
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.createInstance(var68);
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.addDays(2014, var69);
//     boolean var71 = var50.isInRange(var65, var70);
//     boolean var73 = var32.isInRange(var47, var65, 1);
//     boolean var74 = var9.isBefore((org.jfree.data.time.SerialDate)var32);
//     int var75 = var7.compareTo((java.lang.Object)var9);
//     org.jfree.data.time.SpreadsheetDate var77 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var78 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var79 = var78.getTime();
//     boolean var80 = var77.equals((java.lang.Object)var79);
//     boolean var81 = var9.isBefore((org.jfree.data.time.SerialDate)var77);
//     int var82 = var77.getDayOfWeek();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.addMonths((-452), (org.jfree.data.time.SerialDate)var77);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var40.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "December 2014"+ "'", var45.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "20-December-2014"+ "'", var62.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "20-December-2014"+ "'", var63.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 3);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test132"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.SerialDate var4 = var0.getSerialDate();
//     int var5 = var0.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var6);
//     java.lang.String var8 = var7.getRangeDescription();
//     java.util.Collection var9 = var7.getTimePeriods();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "Value"+ "'", var8.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test133"); }


    org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("2015");
    java.lang.Class var2 = null;
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1, var2);
    org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
    org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, (-1.0d));
    java.lang.Object var7 = var6.clone();
    java.lang.Number var8 = var6.getValue();
    java.lang.Number var9 = var6.getValue();
    java.lang.Object var10 = var6.clone();
    java.lang.Object var11 = var6.clone();
    org.jfree.data.time.RegularTimePeriod var12 = var6.getPeriod();
    int var13 = var1.compareTo((java.lang.Object)var6);
    org.jfree.data.time.RegularTimePeriod var14 = var6.getPeriod();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1.0d)+ "'", var9.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test134"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getMiddleMillisecond();
//     long var2 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419140803401L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419140803401L);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test135"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     var4.clear();
//     var4.setDomainDescription("");
//     var4.clear();
//     int var9 = var4.getMaximumItemCount();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     int var12 = var10.compareTo((java.lang.Object)'4');
//     java.util.Date var13 = var10.getStart();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var16 = var15.toString();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10L);
//     int var19 = var10.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.TimeSeriesDataItem var21 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)1L);
//     java.lang.Object var22 = null;
//     int var23 = var10.compareTo(var22);
//     int var24 = var10.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var16.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
// 
//   }

}
