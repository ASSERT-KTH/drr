
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-1), 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    org.jfree.data.time.RegularTimePeriod var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var4.getIndex(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var3 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)"hi!");
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=10.0]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 2014, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, var1);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(0, (java.lang.Number)(short)100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getSerialIndex();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(-1.0f));
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(100, 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, 2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("hi!");

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
    org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(var6, (java.lang.Number)1420099199999L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1420099199999L);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (-1.0d));
//     int var12 = var9.getYear();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)1419140703686L);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var2, var3);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.TimeSeries var3 = null;
//     java.util.Collection var4 = var2.getTimePeriodsUniqueToOtherSeries(var3);
// 
//   }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=10.0]", var1);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("December 2014", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.time.RegularTimePeriod var4 = null;
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
    org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var8 = var2.createCopy(var4, (org.jfree.data.time.RegularTimePeriod)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var10 = var9.previous();
//     var6.add(var10, (java.lang.Number)(short)1);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("20-December-2014", var1);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     java.lang.String var8 = var0.toString();
//     java.util.Calendar var9 = null;
//     var0.peg(var9);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(2014, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    var4.setDescription("20-December-2014");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setMaximumItemCount((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var10 = var2.createCopy(31, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var9 = var6.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("20-December-2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond();
//     long var6 = var5.getMiddleMillisecond();
//     long var7 = var5.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var5, 100.0d, true);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    var2.setMaximumItemCount(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("20-December-2014", var1);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     java.lang.String var8 = var7.toString();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     java.lang.String var2 = var1.toString();
//     java.util.Date var3 = var1.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-1), var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "December 2014"+ "'", var2.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var10.removeChangeListener(var12);
//     int var14 = var6.compareTo((java.lang.Object)var10);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     java.lang.String var16 = var15.toString();
//     java.util.Date var17 = var15.getStart();
//     long var18 = var15.getLastMillisecond();
//     java.lang.Number var19 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.update((org.jfree.data.time.RegularTimePeriod)var15, var19);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "December 2014"+ "'", var16.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1420099199999L);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(1, var1);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.delete(10, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (-1.0d));
//     int var6 = var3.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var3.previous();
//     int var8 = var1.compareTo((java.lang.Object)var3);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     java.util.Calendar var11 = null;
//     long var12 = var3.getFirstMillisecond(var11);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Last"+ "'", var1.equals("Last"));

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Comparable var9 = var6.getKey();
//     var6.setRangeDescription("hi!");
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.Number var19 = var18.getValue();
//     var6.add(var18, false);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var10.removeChangeListener(var12);
//     int var14 = var6.compareTo((java.lang.Object)var10);
//     java.lang.String var15 = var10.getDomainDescription();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var18 = var17.toString();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)10L);
//     var10.add(var20);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(1, 2014, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "Time", "December 2014", var3);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     var4.add(var6, 100.0d, false);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var7 = var6.getLastMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)0.0f);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
    java.util.Date var3 = var2.getTime();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.addDays(2014, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(31, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var14 = var4.getValue(20);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     java.lang.Number var8 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update(100, var8);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0d), "Time", "December 2014", var3);
    org.jfree.data.time.TimeSeriesDataItem var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.update(2014, (java.lang.Number)1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Time", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond();
//     long var2 = var1.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var5 = var4.getTime();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addDays(2014, var6);
//     boolean var8 = var1.equals((java.lang.Object)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(100, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419140704314L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     java.util.Calendar var11 = null;
//     long var12 = var9.getFirstMillisecond(var11);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (-1.0d));
//     long var4 = var1.getFirstMillisecond();
//     long var5 = var1.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(byte)0);
//     java.lang.String var8 = var1.toString();
//     java.lang.String var9 = var1.toString();
//     org.jfree.data.time.SerialDate var10 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var13 = var10.getFollowingDayOfWeek(31);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update(0, (java.lang.Number)(-1.0f));
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.Comparable var11 = var2.getKey();
//     var2.removeAgedItems(10L, true);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Time");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Wed Dec 31 16:00:00 PST 1969", var1);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var10.removeChangeListener(var12);
//     int var14 = var6.compareTo((java.lang.Object)var10);
//     java.lang.String var15 = var10.getDomainDescription();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (-1.0d));
//     long var19 = var16.getFirstMillisecond();
//     long var20 = var16.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(byte)0);
//     java.lang.String var23 = var16.toString();
//     int var24 = var16.getYear();
//     org.jfree.data.time.RegularTimePeriod var25 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var26 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var16, var25);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "Time"+ "'", var15.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "20-December-2014"+ "'", var23.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2014);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getSerialIndex();
//     org.jfree.data.time.SerialDate var2 = var0.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var4 = var2.getFollowingDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(2014, var20);
//     boolean var22 = var1.isInRange(var16, var21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var24 = var21.getNearestDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond();
//     long var14 = var13.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var17 = var16.getTime();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addDays(2014, var18);
//     boolean var20 = var13.equals((java.lang.Object)var19);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(-1L));
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Sunday"+ "'", var1.equals("Sunday"));

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 0, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var10.removeChangeListener(var12);
//     int var14 = var6.compareTo((java.lang.Object)var10);
//     java.lang.String var15 = var10.getDomainDescription();
//     var10.fireSeriesChanged();
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var19 = null;
//     long var20 = var18.getLastMillisecond(var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.update((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)31);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "Time"+ "'", var15.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0L);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Object var8 = var6.clone();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var10);
//     var11.fireSeriesChanged();
//     var11.setMaximumItemCount(0);
//     var11.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     java.lang.Number var18 = var11.getValue((org.jfree.data.time.RegularTimePeriod)var17);
//     int var19 = var6.compareTo((java.lang.Object)var17);
//     org.jfree.data.time.RegularTimePeriod var20 = var17.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.RegularTimePeriod var11 = var9.next();
//     java.util.Calendar var12 = null;
//     long var13 = var9.getFirstMillisecond(var12);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1420099199999L);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     java.util.Date var10 = var9.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     var2.delete(var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var16 = var2.createCopy(100, 31);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     var10.removeAgedItems(0L, true);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    java.util.Date var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("December 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

//  public void test111() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("2014", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     boolean var5 = var4.isEmpty();
//     org.jfree.data.time.TimeSeries var6 = null;
//     java.util.Collection var7 = var4.getTimePeriodsUniqueToOtherSeries(var6);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.SerialDate var29 = null;
//     int var30 = var6.compare(var29);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    var2.setMaximumItemCount(0);
    var2.setMaximumItemAge(1L);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
    var10.fireSeriesChanged();
    var10.setMaximumItemCount(0);
    var10.setMaximumItemAge(1L);
    org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
    java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
    var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var19 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.removeAgedItems(1419062400000L, true);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.setMaximumItemCount(0);
//     var10.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (-1.0d));
//     long var23 = var20.getFirstMillisecond();
//     long var24 = var20.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(byte)0);
//     java.lang.Number var27 = var26.getValue();
//     var2.add(var26);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.util.Calendar var12 = null;
//     long var13 = var11.getFirstMillisecond(var12);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var8 = var2.getTimePeriod(10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getSerialIndex();
//     org.jfree.data.time.SerialDate var2 = var0.getSerialDate();
//     java.lang.Object var3 = null;
//     boolean var4 = var0.equals(var3);
//     java.util.Calendar var5 = null;
//     var0.peg(var5);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(2014);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getFollowingDayOfWeek(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Sunday");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
    int var2 = var1.toSerial();
    org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
    int var4 = var1.getYYYY();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var1.compareTo((java.lang.Object)(short)1);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1900);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     java.lang.String var8 = var0.toString();
//     org.jfree.data.time.SerialDate var9 = var0.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var11 = var9.getNearestDayOfWeek(12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(1, 10, 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getSerialIndex();
//     int var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(31, 3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test135() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("SerialDate.weekInMonthToString(): invalid code.", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(1, (-1), 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "October"+ "'", var1.equals("October"));

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1900, (-459), 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var10);
//     var11.fireSeriesChanged();
//     var11.fireSeriesChanged();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     int var17 = var14.getYear();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var19 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var18);
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var18);
//     int var21 = var6.getMaximumItemCount();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, (-1.0d));
//     long var25 = var22.getFirstMillisecond();
//     long var26 = var22.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)(byte)0);
//     java.lang.String var29 = var22.toString();
//     int var30 = var22.getYear();
//     var6.add((org.jfree.data.time.RegularTimePeriod)var22, (-1.0d));
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "Last", "hi!", var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var10.addChangeListener(var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.delete(100, 1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(100, 2014, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December 2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("October");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     long var3 = var0.getMiddleMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(2014, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (-1.0d));
//     long var4 = var1.getFirstMillisecond();
//     long var5 = var1.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(byte)0);
//     java.lang.String var8 = var1.toString();
//     java.lang.String var9 = var1.toString();
//     org.jfree.data.time.SerialDate var10 = var1.getSerialDate();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var21 = var20.getTime();
//     boolean var22 = var19.equals((java.lang.Object)var21);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (-1.0d));
//     long var27 = var24.getFirstMillisecond();
//     long var28 = var24.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)(byte)0);
//     java.lang.String var31 = var24.toString();
//     java.lang.String var32 = var24.toString();
//     org.jfree.data.time.SerialDate var33 = var24.getSerialDate();
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var33);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var37 = var36.getTime();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var37);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addDays(2014, var38);
//     boolean var40 = var19.isInRange(var34, var39);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var43 = var42.toSerial();
//     org.jfree.data.time.Month var44 = new org.jfree.data.time.Month();
//     int var46 = var44.compareTo((java.lang.Object)'4');
//     java.util.Date var47 = var44.getStart();
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var50 = var49.toString();
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)10L);
//     int var53 = var44.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month();
//     java.lang.String var55 = var54.toString();
//     java.util.Date var56 = var54.getStart();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     int var58 = var44.compareTo((java.lang.Object)var57);
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var61 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var62 = var61.getTime();
//     boolean var63 = var60.equals((java.lang.Object)var62);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var67 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var65, (-1.0d));
//     long var68 = var65.getFirstMillisecond();
//     long var69 = var65.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var65, (java.lang.Number)(byte)0);
//     java.lang.String var72 = var65.toString();
//     java.lang.String var73 = var65.toString();
//     org.jfree.data.time.SerialDate var74 = var65.getSerialDate();
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var74);
//     org.jfree.data.time.FixedMillisecond var77 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var78 = var77.getTime();
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.createInstance(var78);
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.addDays(2014, var79);
//     boolean var81 = var60.isInRange(var75, var80);
//     boolean var83 = var42.isInRange(var57, var75, 1);
//     boolean var84 = var19.isBefore((org.jfree.data.time.SerialDate)var42);
//     int var85 = var17.compareTo((java.lang.Object)var19);
//     org.jfree.data.time.SerialDate var86 = var10.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var19);
//     org.jfree.data.general.SeriesChangeEvent var87 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "20-December-2014"+ "'", var31.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "20-December-2014"+ "'", var32.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var50.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "December 2014"+ "'", var55.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + "20-December-2014"+ "'", var72.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var73 + "' != '" + "20-December-2014"+ "'", var73.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    boolean var5 = var4.isEmpty();
    java.lang.String var6 = var4.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var4.getTimePeriod((-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = var5.getFollowingDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     long var5 = var4.getMaximumItemAge();
//     java.beans.PropertyChangeListener var6 = null;
//     var4.removePropertyChangeListener(var6);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var12 = var11.getTime();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addDays(2014, var13);
//     boolean var15 = var8.equals((java.lang.Object)var14);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var8, 0.0d, false);
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     var4.removeAgedItems(false);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     java.util.Date var8 = var7.getEnd();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
//     org.jfree.data.time.RegularTimePeriod var10 = var9.next();
//     var4.add(var10, 10.0d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, (-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.Number var18 = var17.getValue();
//     java.lang.Object var19 = var17.clone();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var21);
//     var22.fireSeriesChanged();
//     var22.setMaximumItemCount(0);
//     var22.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month();
//     java.lang.Number var29 = var22.getValue((org.jfree.data.time.RegularTimePeriod)var28);
//     int var30 = var17.compareTo((java.lang.Object)var28);
//     var10.add(var17, false);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     boolean var8 = var2.isEmpty();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var10 = var2.getTimePeriod((-1));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var3 = var2.toSerial();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     int var6 = var4.compareTo((java.lang.Object)'4');
//     java.util.Date var7 = var4.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)10L);
//     int var13 = var4.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     java.lang.String var15 = var14.toString();
//     java.util.Date var16 = var14.getStart();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     int var18 = var4.compareTo((java.lang.Object)var17);
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var22 = var21.getTime();
//     boolean var23 = var20.equals((java.lang.Object)var22);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     long var28 = var25.getFirstMillisecond();
//     long var29 = var25.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(byte)0);
//     java.lang.String var32 = var25.toString();
//     java.lang.String var33 = var25.toString();
//     org.jfree.data.time.SerialDate var34 = var25.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var34);
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var38 = var37.getTime();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addDays(2014, var39);
//     boolean var41 = var20.isInRange(var35, var40);
//     boolean var43 = var2.isInRange(var17, var35, 1);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (-1.0d));
//     int var47 = var44.getYear();
//     org.jfree.data.time.SerialDate var48 = var44.getSerialDate();
//     boolean var49 = var2.isOnOrAfter(var48);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, var48);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "December 2014"+ "'", var15.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "20-December-2014"+ "'", var32.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "20-December-2014"+ "'", var33.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     int var13 = var11.getYear();
//     java.util.Calendar var14 = null;
//     long var15 = var11.getLastMillisecond(var14);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     java.lang.String var8 = var0.toString();
//     java.util.Calendar var9 = null;
//     long var10 = var0.getLastMillisecond(var9);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var1);
//     java.lang.String var5 = var4.toString();
//     java.util.Calendar var6 = null;
//     long var7 = var4.getLastMillisecond(var6);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     java.util.Date var2 = var1.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.RegularTimePeriod var5 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var2, var4);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var2, var6);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var10);
//     var11.fireSeriesChanged();
//     var11.fireSeriesChanged();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     int var17 = var14.getYear();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var19 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var18);
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var18);
//     org.jfree.data.time.RegularTimePeriod var21 = var18.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.SerialDate var4 = var0.getSerialDate();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getLastMillisecond(var5);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var16);
//     boolean var18 = var17.isEmpty();
//     var17.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var23 = var22.toString();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 1.0d);
//     boolean var26 = var11.equals((java.lang.Object)var22);
//     long var27 = var11.getLastMillisecond();
//     java.util.Calendar var28 = null;
//     long var29 = var11.getLastMillisecond(var28);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("2014", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     long var8 = var5.getFirstMillisecond();
//     long var9 = var5.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)(byte)0);
//     java.lang.Number var12 = var11.getValue();
//     var4.add(var11, false);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    var2.setMaximumItemCount(0);
    var2.setMaximumItemAge(1L);
    org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
    java.lang.Number var9 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var8);
    boolean var10 = var2.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var13 = var2.createCopy(2014, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var10 = var7.getFirstMillisecond();
//     long var11 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)0);
//     java.lang.String var14 = var7.toString();
//     java.lang.String var15 = var7.toString();
//     org.jfree.data.time.SerialDate var16 = var7.getSerialDate();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var16);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var20 = var19.getTime();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays(2014, var21);
//     boolean var23 = var2.isInRange(var17, var22);
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var26 = var25.toSerial();
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     int var29 = var27.compareTo((java.lang.Object)'4');
//     java.util.Date var30 = var27.getStart();
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var33 = var32.toString();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)10L);
//     int var36 = var27.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month();
//     java.lang.String var38 = var37.toString();
//     java.util.Date var39 = var37.getStart();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     int var41 = var27.compareTo((java.lang.Object)var40);
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var45 = var44.getTime();
//     boolean var46 = var43.equals((java.lang.Object)var45);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, (-1.0d));
//     long var51 = var48.getFirstMillisecond();
//     long var52 = var48.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, (java.lang.Number)(byte)0);
//     java.lang.String var55 = var48.toString();
//     java.lang.String var56 = var48.toString();
//     org.jfree.data.time.SerialDate var57 = var48.getSerialDate();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var57);
//     org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var61 = var60.getTime();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var61);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addDays(2014, var62);
//     boolean var64 = var43.isInRange(var58, var63);
//     boolean var66 = var25.isInRange(var40, var58, 1);
//     boolean var67 = var2.isBefore((org.jfree.data.time.SerialDate)var25);
//     org.jfree.data.time.SpreadsheetDate var69 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var70 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var71 = var70.getTime();
//     boolean var72 = var69.equals((java.lang.Object)var71);
//     org.jfree.data.time.Day var74 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var74, (-1.0d));
//     long var77 = var74.getFirstMillisecond();
//     long var78 = var74.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var74, (java.lang.Number)(byte)0);
//     java.lang.String var81 = var74.toString();
//     java.lang.String var82 = var74.toString();
//     org.jfree.data.time.SerialDate var83 = var74.getSerialDate();
//     org.jfree.data.time.SerialDate var84 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var83);
//     org.jfree.data.time.FixedMillisecond var86 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var87 = var86.getTime();
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.createInstance(var87);
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.addDays(2014, var88);
//     boolean var90 = var69.isInRange(var84, var89);
//     boolean var91 = var25.isAfter((org.jfree.data.time.SerialDate)var69);
//     int var92 = var69.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var93 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(31, (org.jfree.data.time.SerialDate)var69);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var33.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "December 2014"+ "'", var38.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "20-December-2014"+ "'", var55.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var56 + "' != '" + "20-December-2014"+ "'", var56.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var81 + "' != '" + "20-December-2014"+ "'", var81.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var82 + "' != '" + "20-December-2014"+ "'", var82.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 1);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     long var14 = var11.getFirstMillisecond();
//     java.util.Calendar var15 = null;
//     long var16 = var11.getLastMillisecond(var15);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var10);
//     var11.fireSeriesChanged();
//     var11.fireSeriesChanged();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     int var17 = var14.getYear();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var19 = var11.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var18);
//     var6.delete((org.jfree.data.time.RegularTimePeriod)var18);
//     int var21 = var6.getMaximumItemCount();
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var23);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     long var26 = var25.getSerialIndex();
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var28 = var24.createCopy((org.jfree.data.time.RegularTimePeriod)var25, (org.jfree.data.time.RegularTimePeriod)var27);
//     org.jfree.data.general.SeriesChangeListener var29 = null;
//     var28.addChangeListener(var29);
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var28.removeChangeListener(var31);
//     var28.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (-1.0d));
//     java.lang.Object var38 = var37.clone();
//     java.lang.Number var39 = var37.getValue();
//     org.jfree.data.time.RegularTimePeriod var40 = var37.getPeriod();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month();
//     java.lang.String var42 = var41.toString();
//     java.util.Date var43 = var41.getStart();
//     org.jfree.data.time.TimeSeries var44 = var28.createCopy(var40, (org.jfree.data.time.RegularTimePeriod)var41);
//     var6.add(var40, (java.lang.Number)28, true);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var3 = var2.toSerial();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     int var6 = var4.compareTo((java.lang.Object)'4');
//     java.util.Date var7 = var4.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)10L);
//     int var13 = var4.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     java.lang.String var15 = var14.toString();
//     java.util.Date var16 = var14.getStart();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     int var18 = var4.compareTo((java.lang.Object)var17);
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var22 = var21.getTime();
//     boolean var23 = var20.equals((java.lang.Object)var22);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     long var28 = var25.getFirstMillisecond();
//     long var29 = var25.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(byte)0);
//     java.lang.String var32 = var25.toString();
//     java.lang.String var33 = var25.toString();
//     org.jfree.data.time.SerialDate var34 = var25.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var34);
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var38 = var37.getTime();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addDays(2014, var39);
//     boolean var41 = var20.isInRange(var35, var40);
//     boolean var43 = var2.isInRange(var17, var35, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2147483647, var35);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "December 2014"+ "'", var15.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "20-December-2014"+ "'", var32.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "20-December-2014"+ "'", var33.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     java.util.TimeZone var3 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2, var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-452));

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(2014, var20);
//     boolean var22 = var1.isInRange(var16, var21);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var25 = var24.toSerial();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     int var28 = var26.compareTo((java.lang.Object)'4');
//     java.util.Date var29 = var26.getStart();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var32 = var31.toString();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, (java.lang.Number)10L);
//     int var35 = var26.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     java.lang.String var37 = var36.toString();
//     java.util.Date var38 = var36.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     int var40 = var26.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var44 = var43.getTime();
//     boolean var45 = var42.equals((java.lang.Object)var44);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, (-1.0d));
//     long var50 = var47.getFirstMillisecond();
//     long var51 = var47.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, (java.lang.Number)(byte)0);
//     java.lang.String var54 = var47.toString();
//     java.lang.String var55 = var47.toString();
//     org.jfree.data.time.SerialDate var56 = var47.getSerialDate();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var56);
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var60 = var59.getTime();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var60);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addDays(2014, var61);
//     boolean var63 = var42.isInRange(var57, var62);
//     boolean var65 = var24.isInRange(var39, var57, 1);
//     boolean var66 = var1.isBefore((org.jfree.data.time.SerialDate)var24);
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var69 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var70 = var69.getTime();
//     boolean var71 = var68.equals((java.lang.Object)var70);
//     org.jfree.data.time.Day var73 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var73, (-1.0d));
//     long var76 = var73.getFirstMillisecond();
//     long var77 = var73.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var79 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var73, (java.lang.Number)(byte)0);
//     java.lang.String var80 = var73.toString();
//     java.lang.String var81 = var73.toString();
//     org.jfree.data.time.SerialDate var82 = var73.getSerialDate();
//     org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var82);
//     org.jfree.data.time.FixedMillisecond var85 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var86 = var85.getTime();
//     org.jfree.data.time.SerialDate var87 = org.jfree.data.time.SerialDate.createInstance(var86);
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.addDays(2014, var87);
//     boolean var89 = var68.isInRange(var83, var88);
//     boolean var90 = var24.isAfter((org.jfree.data.time.SerialDate)var68);
//     int var91 = var68.getYYYY();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var32.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "December 2014"+ "'", var37.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "20-December-2014"+ "'", var54.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "20-December-2014"+ "'", var55.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var80 + "' != '" + "20-December-2014"+ "'", var80.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var81 + "' != '" + "20-December-2014"+ "'", var81.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == 1900);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var7 = var6.toSerial();
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var6);
//     int var9 = var6.getYYYY();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     long var23 = var22.getSerialIndex();
//     org.jfree.data.time.SerialDate var24 = var22.getSerialDate();
//     boolean var26 = var6.isInRange(var21, var24, 100);
//     boolean var27 = var4.equals((java.lang.Object)var6);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     boolean var32 = var29.equals((java.lang.Object)var31);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var36 = var35.getTime();
//     boolean var37 = var34.equals((java.lang.Object)var36);
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (-1.0d));
//     long var42 = var39.getFirstMillisecond();
//     long var43 = var39.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)(byte)0);
//     java.lang.String var46 = var39.toString();
//     java.lang.String var47 = var39.toString();
//     org.jfree.data.time.SerialDate var48 = var39.getSerialDate();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var48);
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var52 = var51.getTime();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addDays(2014, var53);
//     boolean var55 = var34.isInRange(var49, var54);
//     org.jfree.data.time.SerialDate var56 = var29.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var34);
//     org.jfree.data.time.SerialDate var57 = null;
//     boolean var59 = var6.isInRange((org.jfree.data.time.SerialDate)var29, var57, 2014);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var7 = var6.toSerial();
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var6);
//     int var9 = var6.getYYYY();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     long var23 = var22.getSerialIndex();
//     org.jfree.data.time.SerialDate var24 = var22.getSerialDate();
//     boolean var26 = var6.isInRange(var21, var24, 100);
//     boolean var27 = var4.equals((java.lang.Object)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var29 = var6.getNearestDayOfWeek(2147483647);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(28, 12, 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     java.lang.String var8 = var0.toString();
//     org.jfree.data.time.SerialDate var9 = var0.getSerialDate();
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (-1.0d));
//     long var13 = var10.getFirstMillisecond();
//     long var14 = var10.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var20 = var19.getTime();
//     boolean var21 = var18.equals((java.lang.Object)var20);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (-1.0d));
//     long var26 = var23.getFirstMillisecond();
//     long var27 = var23.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)(byte)0);
//     java.lang.String var30 = var23.toString();
//     java.lang.String var31 = var23.toString();
//     org.jfree.data.time.SerialDate var32 = var23.getSerialDate();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var32);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var36 = var35.getTime();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addDays(2014, var37);
//     boolean var39 = var18.isInRange(var33, var38);
//     org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var42 = var41.toSerial();
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     int var45 = var43.compareTo((java.lang.Object)'4');
//     java.util.Date var46 = var43.getStart();
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var49 = var48.toString();
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, (java.lang.Number)10L);
//     int var52 = var43.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var53 = new org.jfree.data.time.Month();
//     java.lang.String var54 = var53.toString();
//     java.util.Date var55 = var53.getStart();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     int var57 = var43.compareTo((java.lang.Object)var56);
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var61 = var60.getTime();
//     boolean var62 = var59.equals((java.lang.Object)var61);
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var66 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var64, (-1.0d));
//     long var67 = var64.getFirstMillisecond();
//     long var68 = var64.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var70 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var64, (java.lang.Number)(byte)0);
//     java.lang.String var71 = var64.toString();
//     java.lang.String var72 = var64.toString();
//     org.jfree.data.time.SerialDate var73 = var64.getSerialDate();
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var73);
//     org.jfree.data.time.FixedMillisecond var76 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var77 = var76.getTime();
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var77);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.addDays(2014, var78);
//     boolean var80 = var59.isInRange(var74, var79);
//     boolean var82 = var41.isInRange(var56, var74, 1);
//     boolean var83 = var18.isBefore((org.jfree.data.time.SerialDate)var41);
//     int var84 = var16.compareTo((java.lang.Object)var18);
//     org.jfree.data.time.SerialDate var85 = var9.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var87 = var9.getNearestDayOfWeek((-459));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "20-December-2014"+ "'", var30.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "20-December-2014"+ "'", var31.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var49.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "December 2014"+ "'", var54.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var71 + "' != '" + "20-December-2014"+ "'", var71.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + "20-December-2014"+ "'", var72.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var11 = var2.getValue(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    long var5 = var4.getMaximumItemAge();
    java.util.List var6 = var4.getItems();
    org.jfree.data.time.RegularTimePeriod var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var8 = var4.getDataItem(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var11 = var10.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1420099199999L);
//     var2.setDomainDescription("2014");
//     long var11 = var2.getMaximumItemAge();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var13 = var2.getValue(10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9223372036854775807L);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (-1.0d));
//     int var12 = var9.getYear();
//     int var13 = var9.getYear();
//     var6.add((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-452), true);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-41962));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     long var5 = var4.getMaximumItemAge();
//     java.beans.PropertyChangeListener var6 = null;
//     var4.removePropertyChangeListener(var6);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var11);
//     boolean var13 = var12.isEmpty();
//     var12.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var18 = var17.toString();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, 1.0d);
//     java.util.Calendar var21 = null;
//     long var22 = var17.getMiddleMillisecond(var21);
//     boolean var24 = var17.equals((java.lang.Object)1L);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     boolean var26 = var17.equals((java.lang.Object)var25);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var25, 0.0d, true);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     long var3 = var1.getFirstMillisecond(var2);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     java.lang.Object var8 = var7.clone();
//     java.lang.Number var9 = var7.getValue();
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (-1.0d));
//     long var13 = var10.getFirstMillisecond();
//     long var14 = var10.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(byte)0);
//     java.lang.String var17 = var10.toString();
//     java.lang.String var18 = var10.toString();
//     org.jfree.data.time.SerialDate var19 = var10.getSerialDate();
//     long var20 = var10.getSerialIndex();
//     int var21 = var10.getMonth();
//     java.lang.String var22 = var10.toString();
//     boolean var23 = var7.equals((java.lang.Object)var22);
//     var2.add(var7, false);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Wed Dec 31 16:00:00 PST 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var10 = var7.getFirstMillisecond();
//     long var11 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)0);
//     java.lang.String var14 = var7.toString();
//     java.lang.String var15 = var7.toString();
//     org.jfree.data.time.SerialDate var16 = var7.getSerialDate();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var16);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var20 = var19.getTime();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays(2014, var21);
//     boolean var23 = var2.isInRange(var17, var22);
//     int var24 = var2.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addMonths((-452), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SerialDate.weekInMonthToString(): invalid code.", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("December 2014", var1);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Comparable var9 = var6.getKey();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var11 = var6.getTimePeriod(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + 100.0d+ "'", var9.equals(100.0d));
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var6);
//     var7.fireSeriesChanged();
//     var7.setMaximumItemCount(0);
//     var7.setMaximumItemAge(1L);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var14);
//     var15.fireSeriesChanged();
//     var15.setMaximumItemCount(0);
//     var15.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     java.lang.Number var22 = var15.getValue((org.jfree.data.time.RegularTimePeriod)var21);
//     var7.delete((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month();
//     java.util.Date var25 = var24.getEnd();
//     long var26 = var24.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var28 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)(-1.0d));
//     var4.add((org.jfree.data.time.RegularTimePeriod)var24, 10.0d);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1420099199999L);
//     var2.setDomainDescription("2014");
//     java.lang.Object var11 = var2.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     int var2 = var0.compareTo((java.lang.Object)'4');
//     java.util.Date var3 = var0.getStart();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getMiddleMillisecond(var4);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     var3.fireSeriesChanged();
//     var3.fireSeriesChanged();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var11 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Year var12 = var10.getYear();
//     java.lang.String var13 = var12.toString();
//     int var14 = var12.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(100, var12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "2014"+ "'", var13.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     long var23 = var22.getMaximumItemAge();
//     org.jfree.data.time.RegularTimePeriod var24 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var26 = var22.addOrUpdate(var24, 10.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 9223372036854775807L);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var5 = var4.toString();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     org.jfree.data.time.RegularTimePeriod var10 = var6.previous();
//     int var11 = var4.compareTo((java.lang.Object)var6);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     boolean var13 = var6.equals((java.lang.Object)var12);
//     boolean var14 = var2.equals((java.lang.Object)var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var15 = new org.jfree.data.time.Month((-41962), var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var5.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     java.lang.String var8 = var0.toString();
//     int var10 = var0.compareTo((java.lang.Object)true);
//     java.util.Calendar var11 = null;
//     long var12 = var0.getFirstMillisecond(var11);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var10.removeChangeListener(var12);
//     int var14 = var6.compareTo((java.lang.Object)var10);
//     var10.setDomainDescription("Wed Dec 31 16:00:00 PST 1969");
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var18);
//     var19.fireSeriesChanged();
//     var19.setMaximumItemCount(0);
//     var19.setDomainDescription("2014");
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"Wed Dec 31 16:00:00 PST 1969", (java.lang.Object)"2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var1 = var0.getTime();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419140708273L);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     java.util.Date var3 = var2.getEnd();
//     boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)var2);
//     java.util.Calendar var5 = null;
//     long var6 = var2.getLastMillisecond(var5);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     boolean var10 = var7.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var25 = var24.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(2014, var26);
//     boolean var28 = var7.isInRange(var22, var27);
//     org.jfree.data.time.SerialDate var29 = var2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var7);
//     java.util.Date var30 = var7.toDate();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var32 = var31.getTime();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     boolean var34 = var7.isOnOrBefore(var33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1900, (org.jfree.data.time.SerialDate)var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Following"+ "'", var1.equals("Following"));

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-41962), 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(10L);
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(-41956), false);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Date var2 = var1.getStart();
    java.util.TimeZone var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var4 = var1.getYYYY();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.SerialDate var7 = var5.getSerialDate();
//     int var8 = var1.compare(var7);
//     org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var12 = var11.getTime();
//     boolean var13 = var10.equals((java.lang.Object)var12);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, (-1.0d));
//     long var18 = var15.getFirstMillisecond();
//     long var19 = var15.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(byte)0);
//     java.lang.String var22 = var15.toString();
//     java.lang.String var23 = var15.toString();
//     org.jfree.data.time.SerialDate var24 = var15.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var24);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var28 = var27.getTime();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addDays(2014, var29);
//     boolean var31 = var10.isInRange(var25, var30);
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var35 = var34.getTime();
//     boolean var36 = var33.equals((java.lang.Object)var35);
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var40 = var39.getTime();
//     boolean var41 = var38.equals((java.lang.Object)var40);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var43, (-1.0d));
//     long var46 = var43.getFirstMillisecond();
//     long var47 = var43.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var43, (java.lang.Number)(byte)0);
//     java.lang.String var50 = var43.toString();
//     java.lang.String var51 = var43.toString();
//     org.jfree.data.time.SerialDate var52 = var43.getSerialDate();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var52);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var56 = var55.getTime();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addDays(2014, var57);
//     boolean var59 = var38.isInRange(var53, var58);
//     org.jfree.data.time.SerialDate var60 = var33.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var38);
//     boolean var61 = var10.isBefore((org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.SerialDate var62 = null;
//     boolean var63 = var1.isInRange((org.jfree.data.time.SerialDate)var10, var62);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-41956));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     boolean var9 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)(byte)(-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-41962));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-10635));

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setDomainDescription("2014");
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, (-1.0d));
//     long var11 = var8.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)(byte)1, true);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=false]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)(-1), var1);
    var2.setMaximumItemCount(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var2.createCopy(1900, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-452));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Oct"+ "'", var2.equals("Oct"));

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.setMaximumItemCount(0);
//     var10.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     long var22 = var19.getFirstMillisecond();
//     long var23 = var19.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(byte)0);
//     java.lang.Number var26 = var25.getValue();
//     java.lang.Object var27 = var25.clone();
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var29);
//     var30.fireSeriesChanged();
//     var30.setMaximumItemCount(0);
//     var30.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     java.lang.Number var37 = var30.getValue((org.jfree.data.time.RegularTimePeriod)var36);
//     int var38 = var25.compareTo((java.lang.Object)var36);
//     int var39 = var16.compareTo((java.lang.Object)var38);
//     java.lang.Class var42 = null;
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var16, "20-December-2014", "2014", var42);
//     java.util.Calendar var44 = null;
//     long var45 = var16.getFirstMillisecond(var44);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(2014, 12, (-41956));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.removeChangeListener(var4);
//     var2.removeAgedItems(true);
//     long var8 = var2.getMaximumItemAge();
//     var2.removeAgedItems(1419140704381L, false);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     long var8 = var0.getFirstMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var0.getFirstMillisecond(var9);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getSerialIndex();
//     java.lang.Class var3 = null;
//     java.io.InputStream var4 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var3);
//     boolean var5 = var0.equals((java.lang.Object)"");
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    java.util.Date var1 = var0.getEnd();
    org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
    java.util.Date var3 = var2.getTime();
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("October");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
    java.util.Date var1 = var0.getTime();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
    boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var2.getFollowingDayOfWeek(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Value");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var1 = var0.getYear();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(0L);
    boolean var4 = var0.equals((java.lang.Object)var3);
    java.util.Calendar var5 = null;
    long var6 = var3.getFirstMillisecond(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     java.util.Date var3 = var2.getEnd();
//     boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)var2);
//     java.util.Calendar var5 = null;
//     long var6 = var2.getFirstMillisecond(var5);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.setMaximumItemCount(0);
//     var10.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.util.Date var20 = var19.getEnd();
//     long var21 = var19.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1.0d));
//     java.util.List var24 = var2.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var25 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var24);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Tuesday"+ "'", var1.equals("Tuesday"));

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
//     org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var6 = var5.getTime();
//     boolean var7 = var4.equals((java.lang.Object)var6);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var11 = var10.getTime();
//     boolean var12 = var9.equals((java.lang.Object)var11);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (-1.0d));
//     long var17 = var14.getFirstMillisecond();
//     long var18 = var14.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)(byte)0);
//     java.lang.String var21 = var14.toString();
//     java.lang.String var22 = var14.toString();
//     org.jfree.data.time.SerialDate var23 = var14.getSerialDate();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var27 = var26.getTime();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addDays(2014, var28);
//     boolean var30 = var9.isInRange(var24, var29);
//     org.jfree.data.time.SerialDate var31 = var4.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var9);
//     java.lang.String var32 = var4.toString();
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var35 = var34.toSerial();
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var34);
//     int var37 = var34.getYYYY();
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (-1.0d));
//     long var42 = var39.getFirstMillisecond();
//     long var43 = var39.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)(byte)0);
//     java.lang.String var46 = var39.toString();
//     java.lang.String var47 = var39.toString();
//     org.jfree.data.time.SerialDate var48 = var39.getSerialDate();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var48);
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     long var51 = var50.getSerialIndex();
//     org.jfree.data.time.SerialDate var52 = var50.getSerialDate();
//     boolean var54 = var34.isInRange(var49, var52, 100);
//     org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var57 = var56.getTime();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var57);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.addDays(2014, var58);
//     org.jfree.data.time.SerialDate var60 = var49.getEndOfCurrentMonth(var58);
//     org.jfree.data.time.FixedMillisecond var62 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var63 = var62.getTime();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(var63);
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.addDays(2014, var64);
//     boolean var66 = var4.isInRange(var60, var65);
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate)var4);
//     boolean var68 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "20-December-2014"+ "'", var22.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "30-January-1900"+ "'", var32.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "20-December-2014"+ "'", var46.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "20-December-2014"+ "'", var47.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     java.util.Calendar var13 = null;
//     var11.peg(var13);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var3 = var2.toSerial();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     int var6 = var4.compareTo((java.lang.Object)'4');
//     java.util.Date var7 = var4.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)10L);
//     int var13 = var4.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     java.lang.String var15 = var14.toString();
//     java.util.Date var16 = var14.getStart();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     int var18 = var4.compareTo((java.lang.Object)var17);
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var22 = var21.getTime();
//     boolean var23 = var20.equals((java.lang.Object)var22);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     long var28 = var25.getFirstMillisecond();
//     long var29 = var25.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(byte)0);
//     java.lang.String var32 = var25.toString();
//     java.lang.String var33 = var25.toString();
//     org.jfree.data.time.SerialDate var34 = var25.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var34);
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var38 = var37.getTime();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addDays(2014, var39);
//     boolean var41 = var20.isInRange(var35, var40);
//     boolean var43 = var2.isInRange(var17, var35, 1);
//     java.lang.String var44 = var2.getDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "December 2014"+ "'", var15.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "20-December-2014"+ "'", var32.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "20-December-2014"+ "'", var33.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     var3.fireSeriesChanged();
//     var3.fireSeriesChanged();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var11 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Year var12 = var10.getYear();
//     java.lang.String var13 = var12.toString();
//     long var14 = var12.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var15 = var12.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var16 = new org.jfree.data.time.Month((-10635), var12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "2014"+ "'", var13.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addDays(2014, var9);
//     boolean var11 = var4.equals((java.lang.Object)var10);
//     int var12 = var0.compareTo((java.lang.Object)var10);
//     java.util.Date var13 = var0.getEnd();
//     int var14 = var0.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419140709176L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.util.Calendar var12 = null;
//     long var13 = var11.getLastMillisecond(var12);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("October", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var1 = var0.getYear();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(0L);
    boolean var4 = var0.equals((java.lang.Object)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.SerialDate var4 = var0.getSerialDate();
//     int var5 = var0.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var8 = var7.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.removeChangeListener(var4);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
    var10.removeAgedItems(false);
    java.util.Collection var13 = var10.getTimePeriods();
    java.lang.Class var17 = null;
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
    boolean var19 = var18.isEmpty();
    java.lang.String var20 = var18.getDescription();
    java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
    org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var24 = var22.getValue(1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     int var2 = var0.compareTo((java.lang.Object)'4');
//     java.util.Date var3 = var0.getStart();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var6 = var5.toString();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)10L);
//     int var9 = var0.compareTo((java.lang.Object)10L);
//     long var10 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var6.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1417420800000L);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-452), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("org.jfree.data.general.SeriesChangeEvent[source=false]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     int var4 = var0.getYear();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getLastMillisecond(var5);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     java.util.Date var29 = var6.toDate();
//     java.util.TimeZone var30 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var29, var30);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    boolean var5 = var4.isEmpty();
    var4.setMaximumItemAge(1419140703900L);
    org.jfree.data.general.SeriesChangeListener var8 = null;
    var4.addChangeListener(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var10 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-10635), 20, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(2014, var20);
//     boolean var22 = var1.isInRange(var16, var21);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var25 = var24.toSerial();
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     int var28 = var26.compareTo((java.lang.Object)'4');
//     java.util.Date var29 = var26.getStart();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var32 = var31.toString();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, (java.lang.Number)10L);
//     int var35 = var26.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     java.lang.String var37 = var36.toString();
//     java.util.Date var38 = var36.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     int var40 = var26.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var43 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var44 = var43.getTime();
//     boolean var45 = var42.equals((java.lang.Object)var44);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, (-1.0d));
//     long var50 = var47.getFirstMillisecond();
//     long var51 = var47.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, (java.lang.Number)(byte)0);
//     java.lang.String var54 = var47.toString();
//     java.lang.String var55 = var47.toString();
//     org.jfree.data.time.SerialDate var56 = var47.getSerialDate();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var56);
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var60 = var59.getTime();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var60);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addDays(2014, var61);
//     boolean var63 = var42.isInRange(var57, var62);
//     boolean var65 = var24.isInRange(var39, var57, 1);
//     boolean var66 = var1.isBefore((org.jfree.data.time.SerialDate)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var68 = var1.getNearestDayOfWeek(28);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var32.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "December 2014"+ "'", var37.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "20-December-2014"+ "'", var54.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var55 + "' != '" + "20-December-2014"+ "'", var55.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.removeChangeListener(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var2.getTimePeriod(12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1420099199999L);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var15 = var4.createCopy(2147483647, 20);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     var2.clear();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.previous();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
//     java.lang.String var15 = var2.getDescription();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.util.Date var17 = var16.getEnd();
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(var17);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var17);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(var17);
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.time.RegularTimePeriod var22 = var20.next();
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var22, "Last", "", var25);
//     boolean var27 = var2.equals((java.lang.Object)var22);
//     var2.setDescription("2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "2014"+ "'", var21.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100, 0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    int var2 = var0.compareTo((java.lang.Object)'4');
    java.util.Date var3 = var0.getStart();
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var3);
    java.util.TimeZone var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var3, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     int var8 = var0.getYear();
//     int var9 = var0.getYear();
//     java.util.Calendar var10 = null;
//     long var11 = var0.getLastMillisecond(var10);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var3 = var2.toSerial();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var2);
//     int var5 = var2.getYYYY();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     long var7 = var6.getSerialIndex();
//     org.jfree.data.time.SerialDate var8 = var6.getSerialDate();
//     int var9 = var2.compare(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (-1.0d));
//     long var13 = var10.getFirstMillisecond();
//     long var14 = var10.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(byte)0);
//     java.lang.String var17 = var10.toString();
//     java.lang.String var18 = var10.toString();
//     org.jfree.data.time.SerialDate var19 = var10.getSerialDate();
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (-1.0d));
//     long var23 = var20.getFirstMillisecond();
//     long var24 = var20.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var30 = var29.getTime();
//     boolean var31 = var28.equals((java.lang.Object)var30);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, (-1.0d));
//     long var36 = var33.getFirstMillisecond();
//     long var37 = var33.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)(byte)0);
//     java.lang.String var40 = var33.toString();
//     java.lang.String var41 = var33.toString();
//     org.jfree.data.time.SerialDate var42 = var33.getSerialDate();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var42);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var46 = var45.getTime();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var46);
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addDays(2014, var47);
//     boolean var49 = var28.isInRange(var43, var48);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var52 = var51.toSerial();
//     org.jfree.data.time.Month var53 = new org.jfree.data.time.Month();
//     int var55 = var53.compareTo((java.lang.Object)'4');
//     java.util.Date var56 = var53.getStart();
//     org.jfree.data.time.FixedMillisecond var58 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var59 = var58.toString();
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var58, (java.lang.Number)10L);
//     int var62 = var53.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var63 = new org.jfree.data.time.Month();
//     java.lang.String var64 = var63.toString();
//     java.util.Date var65 = var63.getStart();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var65);
//     int var67 = var53.compareTo((java.lang.Object)var66);
//     org.jfree.data.time.SpreadsheetDate var69 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var70 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var71 = var70.getTime();
//     boolean var72 = var69.equals((java.lang.Object)var71);
//     org.jfree.data.time.Day var74 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var76 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var74, (-1.0d));
//     long var77 = var74.getFirstMillisecond();
//     long var78 = var74.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var80 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var74, (java.lang.Number)(byte)0);
//     java.lang.String var81 = var74.toString();
//     java.lang.String var82 = var74.toString();
//     org.jfree.data.time.SerialDate var83 = var74.getSerialDate();
//     org.jfree.data.time.SerialDate var84 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var83);
//     org.jfree.data.time.FixedMillisecond var86 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var87 = var86.getTime();
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.createInstance(var87);
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.addDays(2014, var88);
//     boolean var90 = var69.isInRange(var84, var89);
//     boolean var92 = var51.isInRange(var66, var84, 1);
//     boolean var93 = var28.isBefore((org.jfree.data.time.SerialDate)var51);
//     int var94 = var26.compareTo((java.lang.Object)var28);
//     org.jfree.data.time.SerialDate var95 = var19.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var28);
//     int var96 = var2.compare((org.jfree.data.time.SerialDate)var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var97 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), (org.jfree.data.time.SerialDate)var28);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-41962));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "20-December-2014"+ "'", var17.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "20-December-2014"+ "'", var40.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var59.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var64 + "' != '" + "December 2014"+ "'", var64.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var81 + "' != '" + "20-December-2014"+ "'", var81.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var82 + "' != '" + "20-December-2014"+ "'", var82.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == 0);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     java.lang.String var8 = var0.toString();
//     org.jfree.data.time.SerialDate var9 = var0.getSerialDate();
//     long var10 = var0.getFirstMillisecond();
//     java.lang.String var11 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "20-December-2014"+ "'", var7.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "20-December-2014"+ "'", var11.equals("20-December-2014"));
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.previous();
//     java.lang.String var5 = var0.toString();
//     java.util.Calendar var6 = null;
//     var0.peg(var6);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     long var3 = var0.getLastMillisecond();
//     int var5 = var0.compareTo((java.lang.Object)"hi!");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
// 
//   }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     java.lang.Number var9 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var8);
//     java.lang.String var10 = var8.toString();
//     java.util.Calendar var11 = null;
//     long var12 = var8.getFirstMillisecond(var11);
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=false]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-41956));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     java.lang.String var8 = var2.getDescription();
//     var2.clear();
//     java.util.List var10 = var2.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var11 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var10);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Wed Dec 31 16:00:00 PST 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var10 = var9.getTime();
//     boolean var11 = var8.equals((java.lang.Object)var10);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     long var16 = var13.getFirstMillisecond();
//     long var17 = var13.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(byte)0);
//     java.lang.String var20 = var13.toString();
//     java.lang.String var21 = var13.toString();
//     org.jfree.data.time.SerialDate var22 = var13.getSerialDate();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var22);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var26 = var25.getTime();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addDays(2014, var27);
//     boolean var29 = var8.isInRange(var23, var28);
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var32 = var31.toSerial();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     int var35 = var33.compareTo((java.lang.Object)'4');
//     java.util.Date var36 = var33.getStart();
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var39 = var38.toString();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, (java.lang.Number)10L);
//     int var42 = var33.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     java.lang.String var44 = var43.toString();
//     java.util.Date var45 = var43.getStart();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     int var47 = var33.compareTo((java.lang.Object)var46);
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var51 = var50.getTime();
//     boolean var52 = var49.equals((java.lang.Object)var51);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, (-1.0d));
//     long var57 = var54.getFirstMillisecond();
//     long var58 = var54.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, (java.lang.Number)(byte)0);
//     java.lang.String var61 = var54.toString();
//     java.lang.String var62 = var54.toString();
//     org.jfree.data.time.SerialDate var63 = var54.getSerialDate();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var63);
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var67 = var66.getTime();
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.addDays(2014, var68);
//     boolean var70 = var49.isInRange(var64, var69);
//     boolean var72 = var31.isInRange(var46, var64, 1);
//     boolean var73 = var8.isBefore((org.jfree.data.time.SerialDate)var31);
//     int var74 = var6.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.SpreadsheetDate var76 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var77 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var78 = var77.getTime();
//     boolean var79 = var76.equals((java.lang.Object)var78);
//     boolean var80 = var8.isBefore((org.jfree.data.time.SerialDate)var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var82 = var8.getPreviousDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var39.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "December 2014"+ "'", var44.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-December-2014"+ "'", var61.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "20-December-2014"+ "'", var62.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(20, (-10635), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.removeChangeListener(var4);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
    var10.removeAgedItems(false);
    java.util.Collection var13 = var10.getTimePeriods();
    java.lang.Class var17 = null;
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
    boolean var19 = var18.isEmpty();
    java.lang.String var20 = var18.getDescription();
    java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
    org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var24 = var2.getValue(20);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("30-January-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     int var5 = var2.compareTo((java.lang.Object)"December 2014");
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     int var10 = var6.getYear();
//     boolean var11 = var2.equals((java.lang.Object)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var12 = new org.jfree.data.time.Month((-452), var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.setMaximumItemCount(0);
//     var10.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.fireSeriesChanged();
//     java.lang.Class var20 = var2.getTimePeriodClass();
//     var2.setNotify(true);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var24);
//     var25.fireSeriesChanged();
//     var25.fireSeriesChanged();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, (-1.0d));
//     int var31 = var28.getYear();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var33 = var25.createCopy((org.jfree.data.time.RegularTimePeriod)var28, (org.jfree.data.time.RegularTimePeriod)var32);
//     org.jfree.data.time.Year var34 = var32.getYear();
//     long var35 = var34.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var36 = var34.previous();
//     long var37 = var34.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)2014L);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     java.util.Calendar var8 = null;
//     long var9 = var0.getFirstMillisecond(var8);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("20-December-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     java.lang.String var8 = var2.getDescription();
//     var2.clear();
//     java.util.List var10 = var2.getItems();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var11, 1.0d, false);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.Class var5 = var2.getTimePeriodClass();
    java.util.Collection var6 = var2.getTimePeriods();
    long var7 = var2.getMaximumItemAge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var2.getTimePeriod(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 9223372036854775807L);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(2014, var5);
//     boolean var7 = var0.equals((java.lang.Object)var6);
//     java.lang.Class var8 = null;
//     java.lang.ClassLoader var9 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var8);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var9);
//     int var11 = var0.compareTo((java.lang.Object)var9);
//     org.jfree.chart.util.ObjectUtilities.setClassLoader(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419140710571L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     java.util.Date var3 = var0.getEnd();
//     java.util.TimeZone var4 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var3, var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.previous();
//     java.util.Calendar var15 = null;
//     long var16 = var11.getFirstMillisecond(var15);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
//     long var4 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419140710770L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419140710770L);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.SerialDate var4 = var0.getSerialDate();
//     int var5 = var0.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var7.delete(2147483647, 20);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.setMaximumItemCount(0);
//     var10.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.util.Date var20 = var19.getEnd();
//     long var21 = var19.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1.0d));
//     java.util.List var24 = var2.getItems();
//     java.beans.PropertyChangeListener var25 = null;
//     var2.removePropertyChangeListener(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.SerialDate var4 = var0.getSerialDate();
//     int var5 = var0.getYear();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, var6);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, (-1.0d));
//     java.lang.Object var11 = var10.clone();
//     org.jfree.data.time.RegularTimePeriod var12 = var10.getPeriod();
//     var7.add(var10, false);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=10.0]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Comparable var9 = var6.getKey();
//     var6.setRangeDescription("hi!");
//     java.lang.String var12 = var6.getRangeDescription();
//     var6.removeAgedItems(1419140703900L, false);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.Class var5 = var2.getTimePeriodClass();
//     java.util.Collection var6 = var2.getTimePeriods();
//     long var7 = var2.getMaximumItemAge();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)10L);
//     long var13 = var9.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var9);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var9, 0.0d);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "Last", "hi!", var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var10.addChangeListener(var11);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var14);
//     var15.fireSeriesChanged();
//     var15.fireSeriesChanged();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (-1.0d));
//     int var21 = var18.getYear();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var23 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var18, (org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.Year var24 = var22.getYear();
//     long var25 = var24.getSerialIndex();
//     long var26 = var24.getSerialIndex();
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var24);
//     long var29 = var24.getSerialIndex();
//     var10.add((org.jfree.data.time.RegularTimePeriod)var24, 10.0d);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var4 = var1.getYYYY();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     long var18 = var17.getSerialIndex();
//     org.jfree.data.time.SerialDate var19 = var17.getSerialDate();
//     boolean var21 = var1.isInRange(var16, var19, 100);
//     java.lang.String var22 = var1.getDescription();
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var26 = var25.getTime();
//     boolean var27 = var24.equals((java.lang.Object)var26);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     boolean var32 = var29.equals((java.lang.Object)var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (-1.0d));
//     long var37 = var34.getFirstMillisecond();
//     long var38 = var34.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)(byte)0);
//     java.lang.String var41 = var34.toString();
//     java.lang.String var42 = var34.toString();
//     org.jfree.data.time.SerialDate var43 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var43);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var47 = var46.getTime();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addDays(2014, var48);
//     boolean var50 = var29.isInRange(var44, var49);
//     org.jfree.data.time.SerialDate var51 = var24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var29);
//     java.lang.String var52 = var24.toString();
//     org.jfree.data.time.SpreadsheetDate var54 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var55 = var54.toSerial();
//     org.jfree.data.time.Day var56 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var54);
//     int var57 = var54.getYYYY();
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var59, (-1.0d));
//     long var62 = var59.getFirstMillisecond();
//     long var63 = var59.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var59, (java.lang.Number)(byte)0);
//     java.lang.String var66 = var59.toString();
//     java.lang.String var67 = var59.toString();
//     org.jfree.data.time.SerialDate var68 = var59.getSerialDate();
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var68);
//     org.jfree.data.time.Day var70 = new org.jfree.data.time.Day();
//     long var71 = var70.getSerialIndex();
//     org.jfree.data.time.SerialDate var72 = var70.getSerialDate();
//     boolean var74 = var54.isInRange(var69, var72, 100);
//     org.jfree.data.time.FixedMillisecond var76 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var77 = var76.getTime();
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var77);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.addDays(2014, var78);
//     org.jfree.data.time.SerialDate var80 = var69.getEndOfCurrentMonth(var78);
//     org.jfree.data.time.FixedMillisecond var82 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var83 = var82.getTime();
//     org.jfree.data.time.SerialDate var84 = org.jfree.data.time.SerialDate.createInstance(var83);
//     org.jfree.data.time.SerialDate var85 = org.jfree.data.time.SerialDate.addDays(2014, var84);
//     boolean var86 = var24.isInRange(var80, var85);
//     boolean var87 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var89 = var24.getPreviousDayOfWeek(30);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "20-December-2014"+ "'", var42.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "30-January-1900"+ "'", var52.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var66 + "' != '" + "20-December-2014"+ "'", var66.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var67 + "' != '" + "20-December-2014"+ "'", var67.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == true);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("20-December-2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.removeChangeListener(var4);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
    var10.removeAgedItems(false);
    java.util.Collection var13 = var10.getTimePeriods();
    java.lang.Class var17 = null;
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
    boolean var19 = var18.isEmpty();
    java.lang.String var20 = var18.getDescription();
    java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
    org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var24 = var22.getTimePeriod((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     java.lang.Comparable var9 = var6.getKey();
//     var6.setRangeDescription("hi!");
//     java.lang.String var12 = var6.getRangeDescription();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var14);
//     var15.fireSeriesChanged();
//     var15.fireSeriesChanged();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (-1.0d));
//     int var21 = var18.getYear();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var23 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var18, (org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.Year var24 = var22.getYear();
//     long var25 = var24.getSerialIndex();
//     long var26 = var24.getSerialIndex();
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var28 = var24.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.update((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + 100.0d+ "'", var9.equals(100.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "hi!"+ "'", var12.equals("hi!"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=10.0]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (-1.0d));
//     int var6 = var3.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var3.previous();
//     int var8 = var1.compareTo((java.lang.Object)var3);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     long var24 = var21.getFirstMillisecond();
//     long var25 = var21.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     boolean var32 = var29.equals((java.lang.Object)var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (-1.0d));
//     long var37 = var34.getFirstMillisecond();
//     long var38 = var34.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)(byte)0);
//     java.lang.String var41 = var34.toString();
//     java.lang.String var42 = var34.toString();
//     org.jfree.data.time.SerialDate var43 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var43);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var47 = var46.getTime();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addDays(2014, var48);
//     boolean var50 = var29.isInRange(var44, var49);
//     org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var53 = var52.toSerial();
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month();
//     int var56 = var54.compareTo((java.lang.Object)'4');
//     java.util.Date var57 = var54.getStart();
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var60 = var59.toString();
//     org.jfree.data.time.TimeSeriesDataItem var62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var59, (java.lang.Number)10L);
//     int var63 = var54.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var64 = new org.jfree.data.time.Month();
//     java.lang.String var65 = var64.toString();
//     java.util.Date var66 = var64.getStart();
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(var66);
//     int var68 = var54.compareTo((java.lang.Object)var67);
//     org.jfree.data.time.SpreadsheetDate var70 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var71 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var72 = var71.getTime();
//     boolean var73 = var70.equals((java.lang.Object)var72);
//     org.jfree.data.time.Day var75 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var77 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var75, (-1.0d));
//     long var78 = var75.getFirstMillisecond();
//     long var79 = var75.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var81 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var75, (java.lang.Number)(byte)0);
//     java.lang.String var82 = var75.toString();
//     java.lang.String var83 = var75.toString();
//     org.jfree.data.time.SerialDate var84 = var75.getSerialDate();
//     org.jfree.data.time.SerialDate var85 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var84);
//     org.jfree.data.time.FixedMillisecond var87 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var88 = var87.getTime();
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.createInstance(var88);
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.addDays(2014, var89);
//     boolean var91 = var70.isInRange(var85, var90);
//     boolean var93 = var52.isInRange(var67, var85, 1);
//     boolean var94 = var29.isBefore((org.jfree.data.time.SerialDate)var52);
//     int var95 = var27.compareTo((java.lang.Object)var29);
//     org.jfree.data.time.SerialDate var96 = var20.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var29);
//     org.jfree.data.general.SeriesChangeEvent var97 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var20);
//     boolean var98 = var3.equals((java.lang.Object)var20);
//     org.jfree.data.time.Day var99 = new org.jfree.data.time.Day(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var2.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "20-December-2014"+ "'", var42.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var60 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var60.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var65 + "' != '" + "December 2014"+ "'", var65.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var82 + "' != '" + "20-December-2014"+ "'", var82.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var83 + "' != '" + "20-December-2014"+ "'", var83.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == false);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var8 = var2.getDataItem(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var2);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var2, var6);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     long var3 = var2.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var6 = var5.getTime();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(2014, var7);
//     boolean var9 = var2.equals((java.lang.Object)var8);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addDays((-452), var8);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-41956), var10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419140711545L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getLastMillisecond(var4);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     java.lang.String var8 = var2.getDescription();
//     boolean var9 = var2.isEmpty();
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (-1.0d));
//     java.lang.Object var13 = var12.clone();
//     java.lang.Number var14 = var12.getValue();
//     var2.add(var12, false);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.delete(0, 2014);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-452));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(28, 28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     long var3 = var0.getLastMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "First"+ "'", var1.equals("First"));

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     var3.fireSeriesChanged();
//     var3.fireSeriesChanged();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var11 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Year var12 = var10.getYear();
//     long var13 = var12.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var14 = var12.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(1900, var12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("14-December-2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var4 = null;
//     var2.removeChangeListener(var4);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
//     var10.removeAgedItems(false);
//     java.util.Collection var13 = var10.getTimePeriods();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
//     boolean var19 = var18.isEmpty();
//     java.lang.String var20 = var18.getDescription();
//     java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
//     org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
//     var22.setMaximumItemAge(0L);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     java.lang.String var26 = var25.toString();
//     java.util.Date var27 = var25.getStart();
//     java.lang.String var28 = var25.toString();
//     var22.add((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d), false);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    var4.clear();
    var4.setDomainDescription("");
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var10 = null;
    long var11 = var9.getMiddleMillisecond(var10);
    int var12 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var9);
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((-41956));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-459), (-41956));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(10L);
//     org.jfree.data.time.RegularTimePeriod var2 = var1.next();
//     java.lang.String var3 = var1.toString();
//     java.util.Calendar var4 = null;
//     var1.peg(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var3.equals("Wed Dec 31 16:00:00 PST 1969"));
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     boolean var10 = var7.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var25 = var24.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(2014, var26);
//     boolean var28 = var7.isInRange(var22, var27);
//     org.jfree.data.time.SerialDate var29 = var2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var7);
//     java.lang.String var30 = var2.toString();
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var33 = var32.toSerial();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var32);
//     int var35 = var32.getYYYY();
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (-1.0d));
//     long var40 = var37.getFirstMillisecond();
//     long var41 = var37.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)(byte)0);
//     java.lang.String var44 = var37.toString();
//     java.lang.String var45 = var37.toString();
//     org.jfree.data.time.SerialDate var46 = var37.getSerialDate();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var46);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     long var49 = var48.getSerialIndex();
//     org.jfree.data.time.SerialDate var50 = var48.getSerialDate();
//     boolean var52 = var32.isInRange(var47, var50, 100);
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var55 = var54.getTime();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addDays(2014, var56);
//     org.jfree.data.time.SerialDate var58 = var47.getEndOfCurrentMonth(var56);
//     org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var61 = var60.getTime();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var61);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addDays(2014, var62);
//     boolean var64 = var2.isInRange(var58, var63);
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate)var2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var67 = var2.getNearestDayOfWeek((-459));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "30-January-1900"+ "'", var30.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "20-December-2014"+ "'", var44.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "20-December-2014"+ "'", var45.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(28, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-41962), 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (-1.0d));
//     long var4 = var1.getFirstMillisecond();
//     long var5 = var1.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(byte)0);
//     java.lang.String var8 = var1.toString();
//     java.lang.String var9 = var1.toString();
//     org.jfree.data.time.SerialDate var10 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var10);
//     org.jfree.data.general.SeriesChangeEvent var12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var14 = var11.getPreviousDayOfWeek(100);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Date var1 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var1);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var1);
//     java.util.Calendar var5 = null;
//     var4.peg(var5);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Last", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "Last", "hi!", var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.delete(2014, (-459));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.Comparable var11 = var2.getKey();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var12 = var2.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + 100.0d+ "'", var11.equals(100.0d));
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    var4.setDescription("20-December-2014");
    boolean var7 = var4.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(3, 2014, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(31);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     java.lang.Object var6 = var2.clone();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getSerialIndex();
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var13 = var9.createCopy((org.jfree.data.time.RegularTimePeriod)var10, (org.jfree.data.time.RegularTimePeriod)var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var13.addChangeListener(var14);
//     java.beans.PropertyChangeListener var16 = null;
//     var13.removePropertyChangeListener(var16);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     int var20 = var18.compareTo((java.lang.Object)'4');
//     boolean var21 = var13.equals((java.lang.Object)'4');
//     java.util.Collection var22 = var2.getTimePeriodsUniqueToOtherSeries(var13);
//     java.lang.Object var23 = var2.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
    var4.setDescription("20-December-2014");
    org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
    java.util.Date var8 = var7.getEnd();
    org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var8);
    org.jfree.data.time.RegularTimePeriod var10 = var9.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(var10, (java.lang.Number)9223372036854775807L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     var3.fireSeriesChanged();
//     var3.fireSeriesChanged();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var11 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Year var12 = var10.getYear();
//     java.lang.String var13 = var12.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(0, var12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "2014"+ "'", var13.equals("2014"));
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: Wed Dec 31 16:00:00 PST 1969");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1900);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     int var13 = var11.getYear();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.previous();
//     java.util.Calendar var15 = null;
//     var11.peg(var15);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-41956));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(28, (-10635));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var10 = var7.getFirstMillisecond();
//     long var11 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)0);
//     java.lang.String var14 = var7.toString();
//     java.lang.String var15 = var7.toString();
//     org.jfree.data.time.SerialDate var16 = var7.getSerialDate();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var16);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var20 = var19.getTime();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays(2014, var21);
//     boolean var23 = var2.isInRange(var17, var22);
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var27 = var26.getTime();
//     boolean var28 = var25.equals((java.lang.Object)var27);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var32 = var31.getTime();
//     boolean var33 = var30.equals((java.lang.Object)var32);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (-1.0d));
//     long var38 = var35.getFirstMillisecond();
//     long var39 = var35.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)(byte)0);
//     java.lang.String var42 = var35.toString();
//     java.lang.String var43 = var35.toString();
//     org.jfree.data.time.SerialDate var44 = var35.getSerialDate();
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var44);
//     org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var48 = var47.getTime();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(var48);
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.addDays(2014, var49);
//     boolean var51 = var30.isInRange(var45, var50);
//     org.jfree.data.time.SerialDate var52 = var25.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var30);
//     boolean var53 = var2.isBefore((org.jfree.data.time.SerialDate)var30);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addYears((-1), (org.jfree.data.time.SerialDate)var30);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "20-December-2014"+ "'", var42.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "20-December-2014"+ "'", var43.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=20-December-2014]", var1);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     long var3 = var0.getLastMillisecond();
//     int var4 = var0.getYearValue();
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getLastMillisecond(var6);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     boolean var10 = var7.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var25 = var24.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(2014, var26);
//     boolean var28 = var7.isInRange(var22, var27);
//     org.jfree.data.time.SerialDate var29 = var2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var7);
//     java.lang.String var30 = var2.toString();
//     int var31 = var2.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var34 = var33.toSerial();
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var33);
//     int var36 = var33.getYYYY();
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, (-1.0d));
//     long var41 = var38.getFirstMillisecond();
//     long var42 = var38.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, (java.lang.Number)(byte)0);
//     java.lang.String var45 = var38.toString();
//     java.lang.String var46 = var38.toString();
//     org.jfree.data.time.SerialDate var47 = var38.getSerialDate();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var47);
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     long var50 = var49.getSerialIndex();
//     org.jfree.data.time.SerialDate var51 = var49.getSerialDate();
//     boolean var53 = var33.isInRange(var48, var51, 100);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var56 = var55.getTime();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addDays(2014, var57);
//     org.jfree.data.time.SerialDate var59 = var48.getEndOfCurrentMonth(var57);
//     var48.setDescription("20-December-2014");
//     boolean var62 = var2.isAfter(var48);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(31, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "30-January-1900"+ "'", var30.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "20-December-2014"+ "'", var45.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "20-December-2014"+ "'", var46.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("First");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Number var7 = var6.getValue();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var10.removeChangeListener(var12);
//     int var14 = var6.compareTo((java.lang.Object)var10);
//     java.lang.String var15 = var10.getDomainDescription();
//     var10.fireSeriesChanged();
//     java.beans.PropertyChangeListener var17 = null;
//     var10.removePropertyChangeListener(var17);
//     boolean var19 = var10.isEmpty();
//     org.jfree.data.time.RegularTimePeriod var20 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var10.delete(var20);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (byte)0+ "'", var7.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "Time"+ "'", var15.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
// 
//   }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Sunday");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     boolean var8 = var2.isEmpty();
//     java.lang.String var9 = var2.getRangeDescription();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var11);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     long var14 = var13.getSerialIndex();
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var16 = var12.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var15);
//     int var17 = var12.getItemCount();
//     boolean var18 = var12.isEmpty();
//     java.lang.String var19 = var12.getRangeDescription();
//     java.util.Collection var20 = var2.getTimePeriodsUniqueToOtherSeries(var12);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(10L);
//     var12.add((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)(byte)0, true);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("30-January-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.removeChangeListener(var7);
//     var6.fireSeriesChanged();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(2014, var20);
//     boolean var22 = var1.isInRange(var16, var21);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var26 = var25.getTime();
//     boolean var27 = var24.equals((java.lang.Object)var26);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     boolean var32 = var29.equals((java.lang.Object)var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (-1.0d));
//     long var37 = var34.getFirstMillisecond();
//     long var38 = var34.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)(byte)0);
//     java.lang.String var41 = var34.toString();
//     java.lang.String var42 = var34.toString();
//     org.jfree.data.time.SerialDate var43 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var43);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var47 = var46.getTime();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addDays(2014, var48);
//     boolean var50 = var29.isInRange(var44, var49);
//     org.jfree.data.time.SerialDate var51 = var24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var29);
//     boolean var52 = var1.isBefore((org.jfree.data.time.SerialDate)var29);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var53 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "20-December-2014"+ "'", var42.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var27 = var26.toString();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)10L);
//     long var30 = var26.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var26);
//     int var32 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.update((-452), (java.lang.Number)1419140712057L);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var27.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-1));
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var27 = var26.toString();
//     int var28 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     org.jfree.data.time.RegularTimePeriod var29 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.add(var29, (java.lang.Number)(byte)100, true);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var27.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.setMaximumItemCount(0);
//     var10.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.util.Date var20 = var19.getEnd();
//     long var21 = var19.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1.0d));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((-452), (java.lang.Number)1419140711323L);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ERROR : Relative To String", var1);
// 
//   }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var12);
//     var13.fireSeriesChanged();
//     var13.setMaximumItemCount(0);
//     var13.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.Number var20 = var13.getValue((org.jfree.data.time.RegularTimePeriod)var19);
//     java.lang.String var21 = var19.toString();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var6.getDataItem((org.jfree.data.time.RegularTimePeriod)var19);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var24 = var23.getYear();
//     org.jfree.data.time.RegularTimePeriod var25 = var24.next();
//     var6.add(var25, 10.0d, false);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419140704567L);
    long var2 = var1.getMiddleMillisecond();
    long var3 = var1.getLastMillisecond();
    int var5 = var1.compareTo((java.lang.Object)"2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1419140704567L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1419140704567L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     java.lang.String var2 = var1.toString();
//     java.util.Date var3 = var1.getStart();
//     long var4 = var1.getLastMillisecond();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addDays(2014, var10);
//     boolean var12 = var5.equals((java.lang.Object)var11);
//     int var13 = var1.compareTo((java.lang.Object)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), var11);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "December 2014"+ "'", var2.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419140713731L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     var4.removeAgedItems(false);
//     java.util.Collection var7 = var4.getTimePeriods();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var11);
//     boolean var13 = var12.isEmpty();
//     java.lang.String var14 = var12.getDescription();
//     java.util.Collection var15 = var4.getTimePeriodsUniqueToOtherSeries(var12);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var17 = var16.getYear();
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     int var20 = var17.compareTo((java.lang.Object)"December 2014");
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     int var24 = var21.getYear();
//     int var25 = var21.getYear();
//     boolean var26 = var17.equals((java.lang.Object)var25);
//     var12.add((org.jfree.data.time.RegularTimePeriod)var17, 1.0d, false);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesChangeEvent[source=10.0]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     long var13 = var11.getSerialIndex();
//     long var14 = var11.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var15.addChangeListener(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     int var13 = var11.getYear();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.previous();
//     long var15 = var11.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1420099199999L);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var16);
//     boolean var18 = var17.isEmpty();
//     var17.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var23 = var22.toString();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 1.0d);
//     boolean var26 = var11.equals((java.lang.Object)var22);
//     org.jfree.data.time.RegularTimePeriod var27 = var11.previous();
//     java.util.Calendar var28 = null;
//     long var29 = var11.getLastMillisecond(var28);
// 
//   }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     boolean var10 = var7.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var25 = var24.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(2014, var26);
//     boolean var28 = var7.isInRange(var22, var27);
//     org.jfree.data.time.SerialDate var29 = var2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var7);
//     java.lang.Object var30 = null;
//     boolean var31 = var7.equals(var30);
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     java.lang.String var33 = var32.toString();
//     java.util.Date var34 = var32.getStart();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(var34);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var34);
//     org.jfree.data.time.SerialDate var38 = var7.getEndOfCurrentMonth(var37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addYears((-452), var37);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "December 2014"+ "'", var33.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var8 = var7.toSerial();
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var7);
//     int var10 = var7.getYYYY();
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     long var24 = var23.getSerialIndex();
//     org.jfree.data.time.SerialDate var25 = var23.getSerialDate();
//     boolean var27 = var7.isInRange(var22, var25, 100);
//     boolean var28 = var5.equals((java.lang.Object)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(20, (org.jfree.data.time.SerialDate)var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     var4.setDescription("20-December-2014");
//     boolean var7 = var4.isEmpty();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var11);
//     var12.removeAgedItems(false);
//     java.util.Collection var15 = var12.getTimePeriods();
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var19);
//     boolean var21 = var20.isEmpty();
//     java.lang.String var22 = var20.getDescription();
//     java.util.Collection var23 = var12.getTimePeriodsUniqueToOtherSeries(var20);
//     org.jfree.data.general.SeriesChangeEvent var25 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month();
//     java.util.Date var27 = var26.getEnd();
//     boolean var28 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)var26);
//     int var29 = var26.getMonth();
//     long var30 = var26.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, 0.0d);
//     boolean var33 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)0.0d);
//     long var34 = var4.getMaximumItemAge();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setMaximumItemCount((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 9223372036854775807L);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-41956));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(20, (-41956));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays((-10635), var1);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     java.util.Date var7 = var3.getEnd();
//     java.util.TimeZone var8 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var7, var8);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var27 = var26.toString();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)10L);
//     long var30 = var26.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var31 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var26);
//     int var32 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var36);
//     boolean var38 = var37.isEmpty();
//     var37.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var43 = var42.toString();
//     org.jfree.data.time.TimeSeriesDataItem var45 = var37.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var42, 1.0d);
//     java.util.Calendar var46 = null;
//     long var47 = var42.getMiddleMillisecond(var46);
//     boolean var49 = var42.equals((java.lang.Object)1L);
//     org.jfree.data.time.RegularTimePeriod var50 = var42.previous();
//     org.jfree.data.time.RegularTimePeriod var51 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var52 = var6.createCopy((org.jfree.data.time.RegularTimePeriod)var42, var51);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var27.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var43.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    var2.fireSeriesChanged();
    java.beans.PropertyChangeListener var5 = null;
    var2.removePropertyChangeListener(var5);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     java.beans.PropertyChangeListener var9 = null;
//     var6.removePropertyChangeListener(var9);
//     java.lang.String var11 = var6.getDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var12 = var6.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy(0, 0);
//     var10.removeAgedItems(1419140709190L, false);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getMiddleMillisecond(var13);
//     boolean var16 = var9.equals((java.lang.Object)1L);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     boolean var18 = var9.equals((java.lang.Object)var17);
//     java.util.Date var19 = var9.getEnd();
//     java.util.TimeZone var20 = null;
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var19, var20);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var2);
//     var3.fireSeriesChanged();
//     var3.fireSeriesChanged();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     int var9 = var6.getYear();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var11 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Year var12 = var10.getYear();
//     java.lang.String var13 = var12.toString();
//     int var14 = var12.getYear();
//     long var15 = var12.getLastMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var16 = new org.jfree.data.time.Month((-452), var12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "2014"+ "'", var13.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1420099199999L);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     long var14 = var11.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var15 = var11.next();
//     java.util.Calendar var16 = null;
//     long var17 = var11.getFirstMillisecond(var16);
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(3, 28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     java.util.Calendar var13 = null;
//     long var14 = var11.getLastMillisecond(var13);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var4 = var1.getYYYY();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     long var18 = var17.getSerialIndex();
//     org.jfree.data.time.SerialDate var19 = var17.getSerialDate();
//     boolean var21 = var1.isInRange(var16, var19, 100);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     org.jfree.data.time.SerialDate var27 = var16.getEndOfCurrentMonth(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var29 = var27.getPreviousDayOfWeek(12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.Comparable var11 = var2.getKey();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var13 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 10.0d);
//     var2.add(var15);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"December 2014", var1);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
    java.util.Date var1 = var0.getTime();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
    java.util.TimeZone var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     var2.clear();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.previous();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     java.util.Date var16 = var15.getEnd();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(var16);
//     org.jfree.data.time.RegularTimePeriod var18 = var17.next();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var2.addOrUpdate(var18, 10.0d);
//     java.util.Date var21 = var18.getEnd();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getMiddleMillisecond();
//     long var2 = var0.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     var0.peg(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419140715050L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419140715050L);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     long var5 = var4.getMaximumItemAge();
//     java.util.List var6 = var4.getItems();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var10 = var7.getFirstMillisecond();
//     long var11 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)0);
//     java.lang.String var14 = var7.toString();
//     java.lang.String var15 = var7.toString();
//     org.jfree.data.time.SerialDate var16 = var7.getSerialDate();
//     long var17 = var7.getSerialIndex();
//     int var18 = var7.getMonth();
//     java.lang.String var19 = var7.toString();
//     java.lang.Number var20 = var4.getValue((org.jfree.data.time.RegularTimePeriod)var7);
//     org.jfree.data.time.RegularTimePeriod var21 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.add(var21, 0.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)10.0f);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     java.util.Date var3 = var2.getEnd();
//     boolean var4 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)var2);
//     int var5 = var2.getMonth();
//     java.util.Calendar var6 = null;
//     var2.peg(var6);
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, 3);
//     long var3 = var2.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-62049081600000L));
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var3 = var2.toSerial();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var2);
//     int var5 = var2.getYYYY();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var10 = var7.getFirstMillisecond();
//     long var11 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)0);
//     java.lang.String var14 = var7.toString();
//     java.lang.String var15 = var7.toString();
//     org.jfree.data.time.SerialDate var16 = var7.getSerialDate();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var16);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     long var19 = var18.getSerialIndex();
//     org.jfree.data.time.SerialDate var20 = var18.getSerialDate();
//     boolean var22 = var2.isInRange(var17, var20, 100);
//     java.lang.String var23 = var2.getDescription();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.addMonths(31, (org.jfree.data.time.SerialDate)var2);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     int var28 = var25.getYear();
//     org.jfree.data.time.RegularTimePeriod var29 = var25.previous();
//     java.lang.String var30 = var25.toString();
//     java.lang.String var31 = var25.toString();
//     java.util.Date var32 = var25.getEnd();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var33 = var2.compareTo((java.lang.Object)var25);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "20-December-2014"+ "'", var15.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "20-December-2014"+ "'", var30.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "20-December-2014"+ "'", var31.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (-1.0d));
//     long var9 = var6.getFirstMillisecond();
//     long var10 = var6.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)0);
//     java.lang.String var13 = var6.toString();
//     java.lang.String var14 = var6.toString();
//     org.jfree.data.time.SerialDate var15 = var6.getSerialDate();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(2014, var20);
//     boolean var22 = var1.isInRange(var16, var21);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var26 = var25.getTime();
//     boolean var27 = var24.equals((java.lang.Object)var26);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     boolean var32 = var29.equals((java.lang.Object)var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (-1.0d));
//     long var37 = var34.getFirstMillisecond();
//     long var38 = var34.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)(byte)0);
//     java.lang.String var41 = var34.toString();
//     java.lang.String var42 = var34.toString();
//     org.jfree.data.time.SerialDate var43 = var34.getSerialDate();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var43);
//     org.jfree.data.time.FixedMillisecond var46 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var47 = var46.getTime();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addDays(2014, var48);
//     boolean var50 = var29.isInRange(var44, var49);
//     org.jfree.data.time.SerialDate var51 = var24.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var29);
//     boolean var52 = var1.isBefore((org.jfree.data.time.SerialDate)var29);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, (-1.0d));
//     long var57 = var54.getFirstMillisecond();
//     long var58 = var54.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, (java.lang.Number)(byte)0);
//     java.lang.String var61 = var54.toString();
//     java.lang.String var62 = var54.toString();
//     org.jfree.data.time.SerialDate var63 = var54.getSerialDate();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var63);
//     boolean var65 = var1.isOn(var64);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var67 = var64.getFollowingDayOfWeek(2014);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + "20-December-2014"+ "'", var13.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "20-December-2014"+ "'", var14.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "20-December-2014"+ "'", var41.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "20-December-2014"+ "'", var42.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-December-2014"+ "'", var61.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "20-December-2014"+ "'", var62.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     int var2 = var0.compareTo((java.lang.Object)'4');
//     java.util.Date var3 = var0.getStart();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var6 = var5.toString();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)10L);
//     int var9 = var0.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     java.lang.String var11 = var10.toString();
//     java.util.Date var12 = var10.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     int var14 = var0.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var0.previous();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem(var15, (-1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var6.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "December 2014"+ "'", var11.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2, var3);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Sunday", var1);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-41962), 0, (-10635));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     java.util.Date var29 = var6.toDate();
//     int var30 = var6.getMonth();
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var6);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var36 = var35.getTime();
//     boolean var37 = var34.equals((java.lang.Object)var36);
//     org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var40 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var41 = var40.getTime();
//     boolean var42 = var39.equals((java.lang.Object)var41);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (-1.0d));
//     long var47 = var44.getFirstMillisecond();
//     long var48 = var44.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var44, (java.lang.Number)(byte)0);
//     java.lang.String var51 = var44.toString();
//     java.lang.String var52 = var44.toString();
//     org.jfree.data.time.SerialDate var53 = var44.getSerialDate();
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var53);
//     org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var57 = var56.getTime();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var57);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.addDays(2014, var58);
//     boolean var60 = var39.isInRange(var54, var59);
//     org.jfree.data.time.SerialDate var61 = var34.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var39);
//     java.lang.String var62 = var34.toString();
//     org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var65 = var64.toSerial();
//     org.jfree.data.time.Day var66 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var64);
//     int var67 = var64.getYYYY();
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var71 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var69, (-1.0d));
//     long var72 = var69.getFirstMillisecond();
//     long var73 = var69.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var69, (java.lang.Number)(byte)0);
//     java.lang.String var76 = var69.toString();
//     java.lang.String var77 = var69.toString();
//     org.jfree.data.time.SerialDate var78 = var69.getSerialDate();
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var78);
//     org.jfree.data.time.Day var80 = new org.jfree.data.time.Day();
//     long var81 = var80.getSerialIndex();
//     org.jfree.data.time.SerialDate var82 = var80.getSerialDate();
//     boolean var84 = var64.isInRange(var79, var82, 100);
//     org.jfree.data.time.FixedMillisecond var86 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var87 = var86.getTime();
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.createInstance(var87);
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.addDays(2014, var88);
//     org.jfree.data.time.SerialDate var90 = var79.getEndOfCurrentMonth(var88);
//     org.jfree.data.time.FixedMillisecond var92 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var93 = var92.getTime();
//     org.jfree.data.time.SerialDate var94 = org.jfree.data.time.SerialDate.createInstance(var93);
//     org.jfree.data.time.SerialDate var95 = org.jfree.data.time.SerialDate.addDays(2014, var94);
//     boolean var96 = var34.isInRange(var90, var95);
//     org.jfree.data.time.SerialDate var97 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate)var34);
//     boolean var98 = var6.isOnOrAfter(var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "20-December-2014"+ "'", var51.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "20-December-2014"+ "'", var52.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "30-January-1900"+ "'", var62.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var76 + "' != '" + "20-December-2014"+ "'", var76.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var77 + "' != '" + "20-December-2014"+ "'", var77.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == false);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     long var3 = var0.getLastMillisecond();
//     int var4 = var0.getYearValue();
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     int var6 = var5.getMaximumItemCount();
//     org.jfree.data.time.TimeSeriesDataItem var7 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var5.add(var7, true);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 2147483647);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var9 = var2.getValue(1);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var2 = var1.toString();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)10L);
//     org.jfree.data.time.RegularTimePeriod var5 = var4.getPeriod();
//     java.util.Calendar var6 = null;
//     long var7 = var5.getMiddleMillisecond(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var2.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
    int var2 = var1.getMonth();
    java.lang.String var3 = var1.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = var1.getPreviousDayOfWeek((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Value", var1);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     boolean var10 = var7.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var25 = var24.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(2014, var26);
//     boolean var28 = var7.isInRange(var22, var27);
//     org.jfree.data.time.SerialDate var29 = var2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var7);
//     java.lang.Object var30 = null;
//     boolean var31 = var7.equals(var30);
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     java.lang.String var33 = var32.toString();
//     java.util.Date var34 = var32.getStart();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(var34);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var34);
//     org.jfree.data.time.SerialDate var38 = var7.getEndOfCurrentMonth(var37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addDays((-41956), (org.jfree.data.time.SerialDate)var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "December 2014"+ "'", var33.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     java.lang.String var2 = var1.toString();
//     java.util.Date var3 = var1.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-41956), var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "December 2014"+ "'", var2.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     java.util.Date var29 = var6.toDate();
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var31 = var30.getTime();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     boolean var33 = var6.isOnOrBefore(var32);
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var37 = var36.getTime();
//     boolean var38 = var35.equals((java.lang.Object)var37);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var41 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var42 = var41.getTime();
//     boolean var43 = var40.equals((java.lang.Object)var42);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, (-1.0d));
//     long var48 = var45.getFirstMillisecond();
//     long var49 = var45.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, (java.lang.Number)(byte)0);
//     java.lang.String var52 = var45.toString();
//     java.lang.String var53 = var45.toString();
//     org.jfree.data.time.SerialDate var54 = var45.getSerialDate();
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var54);
//     org.jfree.data.time.FixedMillisecond var57 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var58 = var57.getTime();
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.createInstance(var58);
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.addDays(2014, var59);
//     boolean var61 = var40.isInRange(var55, var60);
//     org.jfree.data.time.SerialDate var62 = var35.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var40);
//     java.util.Date var63 = var40.toDate();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(var63);
//     boolean var65 = var6.isBefore(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "20-December-2014"+ "'", var52.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "20-December-2014"+ "'", var53.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.String var7 = var0.toString();
//     int var8 = var0.getYear();
//     int var9 = var0.getMonth();
//     int var10 = var0.getDayOfMonth();
//     java.util.Calendar var11 = null;
//     long var12 = var0.getFirstMillisecond(var11);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     java.util.Date var10 = var9.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     java.lang.String var14 = var13.toString();
//     org.jfree.data.time.RegularTimePeriod var15 = var13.next();
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var19 = var18.getTime();
//     boolean var20 = var17.equals((java.lang.Object)var19);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     boolean var25 = var22.equals((java.lang.Object)var24);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, (-1.0d));
//     long var30 = var27.getFirstMillisecond();
//     long var31 = var27.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, (java.lang.Number)(byte)0);
//     java.lang.String var34 = var27.toString();
//     java.lang.String var35 = var27.toString();
//     org.jfree.data.time.SerialDate var36 = var27.getSerialDate();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var36);
//     org.jfree.data.time.FixedMillisecond var39 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var40 = var39.getTime();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addDays(2014, var41);
//     boolean var43 = var22.isInRange(var37, var42);
//     org.jfree.data.time.SerialDate var44 = var17.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var22);
//     java.lang.Object var45 = null;
//     boolean var46 = var22.equals(var45);
//     org.jfree.data.time.Month var47 = new org.jfree.data.time.Month();
//     java.lang.String var48 = var47.toString();
//     java.util.Date var49 = var47.getStart();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.FixedMillisecond var51 = new org.jfree.data.time.FixedMillisecond(var49);
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.SerialDate var53 = var22.getEndOfCurrentMonth(var52);
//     boolean var54 = var13.equals((java.lang.Object)var53);
//     org.jfree.data.time.RegularTimePeriod var55 = var13.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var6.update((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)1418759999999L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "2014"+ "'", var14.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "20-December-2014"+ "'", var34.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "20-December-2014"+ "'", var35.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + "December 2014"+ "'", var48.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2147483647, (-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (-1.0d));
//     long var4 = var1.getFirstMillisecond();
//     long var5 = var1.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(byte)0);
//     java.lang.String var8 = var1.toString();
//     java.lang.String var9 = var1.toString();
//     org.jfree.data.time.SerialDate var10 = var1.getSerialDate();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var10);
//     org.jfree.data.general.SeriesChangeEvent var12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var14 = var11.getNearestDayOfWeek(28);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "20-December-2014"+ "'", var8.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     var2.clear();
//     org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var13 = var12.toSerial();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var12);
//     int var15 = var12.getYYYY();
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, (-1.0d));
//     long var20 = var17.getFirstMillisecond();
//     long var21 = var17.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)(byte)0);
//     java.lang.String var24 = var17.toString();
//     java.lang.String var25 = var17.toString();
//     org.jfree.data.time.SerialDate var26 = var17.getSerialDate();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     long var29 = var28.getSerialIndex();
//     org.jfree.data.time.SerialDate var30 = var28.getSerialDate();
//     boolean var32 = var12.isInRange(var27, var30, 100);
//     var2.setKey((java.lang.Comparable)var30);
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month();
//     java.util.Date var35 = var34.getEnd();
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(var35);
//     org.jfree.data.time.RegularTimePeriod var37 = var36.next();
//     var2.add(var37, 100.0d);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var10 = var9.getTime();
//     boolean var11 = var8.equals((java.lang.Object)var10);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     long var16 = var13.getFirstMillisecond();
//     long var17 = var13.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(byte)0);
//     java.lang.String var20 = var13.toString();
//     java.lang.String var21 = var13.toString();
//     org.jfree.data.time.SerialDate var22 = var13.getSerialDate();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var22);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var26 = var25.getTime();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addDays(2014, var27);
//     boolean var29 = var8.isInRange(var23, var28);
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var32 = var31.toSerial();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     int var35 = var33.compareTo((java.lang.Object)'4');
//     java.util.Date var36 = var33.getStart();
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var39 = var38.toString();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, (java.lang.Number)10L);
//     int var42 = var33.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     java.lang.String var44 = var43.toString();
//     java.util.Date var45 = var43.getStart();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     int var47 = var33.compareTo((java.lang.Object)var46);
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var50 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var51 = var50.getTime();
//     boolean var52 = var49.equals((java.lang.Object)var51);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, (-1.0d));
//     long var57 = var54.getFirstMillisecond();
//     long var58 = var54.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var54, (java.lang.Number)(byte)0);
//     java.lang.String var61 = var54.toString();
//     java.lang.String var62 = var54.toString();
//     org.jfree.data.time.SerialDate var63 = var54.getSerialDate();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var63);
//     org.jfree.data.time.FixedMillisecond var66 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var67 = var66.getTime();
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.addDays(2014, var68);
//     boolean var70 = var49.isInRange(var64, var69);
//     boolean var72 = var31.isInRange(var46, var64, 1);
//     boolean var73 = var8.isBefore((org.jfree.data.time.SerialDate)var31);
//     int var74 = var6.compareTo((java.lang.Object)var8);
//     org.jfree.data.time.SpreadsheetDate var76 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var77 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var78 = var77.getTime();
//     boolean var79 = var76.equals((java.lang.Object)var78);
//     boolean var80 = var8.isBefore((org.jfree.data.time.SerialDate)var76);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var82 = var8.getNearestDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var39.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "December 2014"+ "'", var44.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "20-December-2014"+ "'", var61.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var62 + "' != '" + "20-December-2014"+ "'", var62.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.setMaximumItemCount(0);
//     var2.setMaximumItemAge(1L);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     var10.fireSeriesChanged();
//     var10.setMaximumItemCount(0);
//     var10.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     java.lang.Number var17 = var10.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.util.Date var20 = var19.getEnd();
//     long var21 = var19.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(-1.0d));
//     java.util.List var24 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(1419140707939L);
//     java.util.Calendar var27 = null;
//     long var28 = var26.getFirstMillisecond(var27);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Date var31 = var30.getStart();
//     org.jfree.data.time.RegularTimePeriod var32 = var30.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var33 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var26, (org.jfree.data.time.RegularTimePeriod)var30);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419140707939L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var27 = var26.toString();
//     int var28 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var30 = var29.previous();
//     var6.add(var30, 10.0d);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var4 = var3.toString();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var9 = var5.previous();
//     int var10 = var3.compareTo((java.lang.Object)var5);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     boolean var12 = var5.equals((java.lang.Object)var11);
//     boolean var13 = var1.equals((java.lang.Object)var12);
//     java.util.Calendar var14 = null;
//     long var15 = var1.getLastMillisecond(var14);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("20-December-2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     java.lang.String var2 = var1.toString();
//     java.util.Date var3 = var1.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var3);
//     var6.setDescription("December 2014");
//     java.lang.String var9 = var6.getDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(2147483647, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var2 + "' != '" + "December 2014"+ "'", var2.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "December 2014"+ "'", var9.equals("December 2014"));
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     java.lang.Object var3 = var2.clone();
//     java.lang.Number var4 = var2.getValue();
//     java.lang.Number var5 = var2.getValue();
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getPeriod();
//     java.util.Calendar var7 = null;
//     long var8 = var6.getMiddleMillisecond(var7);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    var2.setMaximumItemCount(0);
    var2.setMaximumItemAge(1L);
    java.util.List var8 = var2.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var8);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var6.removeChangeListener(var9);
//     var6.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     java.lang.String var20 = var19.toString();
//     java.util.Date var21 = var19.getStart();
//     org.jfree.data.time.TimeSeries var22 = var6.createCopy(var18, (org.jfree.data.time.RegularTimePeriod)var19);
//     var6.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var27 = var26.toString();
//     int var28 = var6.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var30);
//     var31.fireSeriesChanged();
//     var31.fireSeriesChanged();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (-1.0d));
//     int var37 = var34.getYear();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var39 = var31.createCopy((org.jfree.data.time.RegularTimePeriod)var34, (org.jfree.data.time.RegularTimePeriod)var38);
//     org.jfree.data.time.Year var40 = var38.getYear();
//     long var41 = var40.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var42 = var6.getDataItem((org.jfree.data.time.RegularTimePeriod)var40);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var44 = var6.getValue(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "December 2014"+ "'", var20.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var27.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var11.getSerialIndex();
//     long var13 = var11.getSerialIndex();
//     long var14 = var11.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11);
//     long var16 = var11.getSerialIndex();
//     java.util.Calendar var17 = null;
//     long var18 = var11.getLastMillisecond(var17);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Last", var1);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getMiddleMillisecond(var13);
//     boolean var16 = var9.equals((java.lang.Object)1L);
//     long var17 = var9.getMiddleMillisecond();
//     java.util.Calendar var18 = null;
//     var9.peg(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 0L);
// 
//   }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     int var4 = var1.getYYYY();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     long var6 = var5.getSerialIndex();
//     org.jfree.data.time.SerialDate var7 = var5.getSerialDate();
//     int var8 = var1.compare(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (-1.0d));
//     long var12 = var9.getFirstMillisecond();
//     long var13 = var9.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(byte)0);
//     java.lang.String var16 = var9.toString();
//     java.lang.String var17 = var9.toString();
//     org.jfree.data.time.SerialDate var18 = var9.getSerialDate();
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (-1.0d));
//     long var22 = var19.getFirstMillisecond();
//     long var23 = var19.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)(byte)0);
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var29 = var28.getTime();
//     boolean var30 = var27.equals((java.lang.Object)var29);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (-1.0d));
//     long var35 = var32.getFirstMillisecond();
//     long var36 = var32.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)(byte)0);
//     java.lang.String var39 = var32.toString();
//     java.lang.String var40 = var32.toString();
//     org.jfree.data.time.SerialDate var41 = var32.getSerialDate();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var41);
//     org.jfree.data.time.FixedMillisecond var44 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var45 = var44.getTime();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.addDays(2014, var46);
//     boolean var48 = var27.isInRange(var42, var47);
//     org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var51 = var50.toSerial();
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     int var54 = var52.compareTo((java.lang.Object)'4');
//     java.util.Date var55 = var52.getStart();
//     org.jfree.data.time.FixedMillisecond var57 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var58 = var57.toString();
//     org.jfree.data.time.TimeSeriesDataItem var60 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var57, (java.lang.Number)10L);
//     int var61 = var52.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var62 = new org.jfree.data.time.Month();
//     java.lang.String var63 = var62.toString();
//     java.util.Date var64 = var62.getStart();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.createInstance(var64);
//     int var66 = var52.compareTo((java.lang.Object)var65);
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var69 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var70 = var69.getTime();
//     boolean var71 = var68.equals((java.lang.Object)var70);
//     org.jfree.data.time.Day var73 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var75 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var73, (-1.0d));
//     long var76 = var73.getFirstMillisecond();
//     long var77 = var73.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var79 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var73, (java.lang.Number)(byte)0);
//     java.lang.String var80 = var73.toString();
//     java.lang.String var81 = var73.toString();
//     org.jfree.data.time.SerialDate var82 = var73.getSerialDate();
//     org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var82);
//     org.jfree.data.time.FixedMillisecond var85 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var86 = var85.getTime();
//     org.jfree.data.time.SerialDate var87 = org.jfree.data.time.SerialDate.createInstance(var86);
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.addDays(2014, var87);
//     boolean var89 = var68.isInRange(var83, var88);
//     boolean var91 = var50.isInRange(var65, var83, 1);
//     boolean var92 = var27.isBefore((org.jfree.data.time.SerialDate)var50);
//     int var93 = var25.compareTo((java.lang.Object)var27);
//     org.jfree.data.time.SerialDate var94 = var18.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var27);
//     int var95 = var1.compare((org.jfree.data.time.SerialDate)var27);
//     java.lang.String var96 = var1.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var98 = var1.getFollowingDayOfWeek((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-41962));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "20-December-2014"+ "'", var16.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "20-December-2014"+ "'", var17.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "20-December-2014"+ "'", var39.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "20-December-2014"+ "'", var40.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var58.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var63 + "' != '" + "December 2014"+ "'", var63.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var80 + "' != '" + "20-December-2014"+ "'", var80.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var81 + "' != '" + "20-December-2014"+ "'", var81.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var96 + "' != '" + "30-January-1900"+ "'", var96.equals("30-January-1900"));
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-10635), (-452));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var7);
//     boolean var9 = var8.isEmpty();
//     var8.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var14 = var13.toString();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, 1.0d);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 10.0d);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var21);
//     var22.fireSeriesChanged();
//     var22.fireSeriesChanged();
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     int var28 = var25.getYear();
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var30 = var22.createCopy((org.jfree.data.time.RegularTimePeriod)var25, (org.jfree.data.time.RegularTimePeriod)var29);
//     org.jfree.data.time.Year var31 = var29.getYear();
//     long var32 = var31.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var33 = var31.previous();
//     int var34 = var19.compareTo((java.lang.Object)var33);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (-1.0d));
//     long var38 = var35.getFirstMillisecond();
//     long var39 = var35.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var35, (java.lang.Number)(byte)0);
//     java.lang.Number var42 = var41.getValue();
//     java.lang.Object var43 = var41.clone();
//     java.lang.Class var45 = null;
//     org.jfree.data.time.TimeSeries var46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var45);
//     var46.fireSeriesChanged();
//     var46.setMaximumItemCount(0);
//     var46.setMaximumItemAge(1L);
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     java.lang.Number var53 = var46.getValue((org.jfree.data.time.RegularTimePeriod)var52);
//     int var54 = var41.compareTo((java.lang.Object)var52);
//     boolean var55 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var14.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + (byte)0+ "'", var42.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("14-December-2014", var1);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var8 = var7.getTime();
//     boolean var9 = var6.equals((java.lang.Object)var8);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var14 = var11.getFirstMillisecond();
//     long var15 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     java.lang.String var18 = var11.toString();
//     java.lang.String var19 = var11.toString();
//     org.jfree.data.time.SerialDate var20 = var11.getSerialDate();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var20);
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var24 = var23.getTime();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addDays(2014, var25);
//     boolean var27 = var6.isInRange(var21, var26);
//     org.jfree.data.time.SerialDate var28 = var1.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var6);
//     java.lang.String var29 = var1.toString();
//     int var30 = var1.getDayOfWeek();
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var33 = var32.toSerial();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var32);
//     int var35 = var32.getYYYY();
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (-1.0d));
//     long var40 = var37.getFirstMillisecond();
//     long var41 = var37.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)(byte)0);
//     java.lang.String var44 = var37.toString();
//     java.lang.String var45 = var37.toString();
//     org.jfree.data.time.SerialDate var46 = var37.getSerialDate();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var46);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     long var49 = var48.getSerialIndex();
//     org.jfree.data.time.SerialDate var50 = var48.getSerialDate();
//     boolean var52 = var32.isInRange(var47, var50, 100);
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var55 = var54.getTime();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addDays(2014, var56);
//     org.jfree.data.time.SerialDate var58 = var47.getEndOfCurrentMonth(var56);
//     var47.setDescription("20-December-2014");
//     boolean var61 = var1.isAfter(var47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var63 = var1.getPreviousDayOfWeek((-41956));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "20-December-2014"+ "'", var18.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "30-January-1900"+ "'", var29.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "20-December-2014"+ "'", var44.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "20-December-2014"+ "'", var45.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.previous();
//     java.util.Calendar var15 = null;
//     long var16 = var11.getLastMillisecond(var15);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var7);
//     boolean var9 = var8.isEmpty();
//     var8.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var14 = var13.toString();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, 1.0d);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var20 = var13.previous();
//     java.util.Date var21 = var13.getTime();
//     java.util.TimeZone var22 = null;
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var21, var22);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var3 = var2.toSerial();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     int var6 = var4.compareTo((java.lang.Object)'4');
//     java.util.Date var7 = var4.getStart();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)10L);
//     int var13 = var4.compareTo((java.lang.Object)10L);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     java.lang.String var15 = var14.toString();
//     java.util.Date var16 = var14.getStart();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     int var18 = var4.compareTo((java.lang.Object)var17);
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var22 = var21.getTime();
//     boolean var23 = var20.equals((java.lang.Object)var22);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (-1.0d));
//     long var28 = var25.getFirstMillisecond();
//     long var29 = var25.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(byte)0);
//     java.lang.String var32 = var25.toString();
//     java.lang.String var33 = var25.toString();
//     org.jfree.data.time.SerialDate var34 = var25.getSerialDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var34);
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var38 = var37.getTime();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addDays(2014, var39);
//     boolean var41 = var20.isInRange(var35, var40);
//     boolean var43 = var2.isInRange(var17, var35, 1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var10.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "December 2014"+ "'", var15.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "20-December-2014"+ "'", var32.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "20-December-2014"+ "'", var33.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == false);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var3 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var4 = var0.previous();
//     java.lang.String var5 = var0.toString();
//     java.lang.String var6 = var0.toString();
//     java.util.Date var7 = var0.getEnd();
//     java.util.TimeZone var8 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var7, var8);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "20-December-2014"+ "'", var5.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "20-December-2014"+ "'", var6.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Following");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var5 = var4.getTime();
//     boolean var6 = var3.equals((java.lang.Object)var5);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var10 = var9.getTime();
//     boolean var11 = var8.equals((java.lang.Object)var10);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
//     long var16 = var13.getFirstMillisecond();
//     long var17 = var13.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(byte)0);
//     java.lang.String var20 = var13.toString();
//     java.lang.String var21 = var13.toString();
//     org.jfree.data.time.SerialDate var22 = var13.getSerialDate();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var22);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var26 = var25.getTime();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(var26);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addDays(2014, var27);
//     boolean var29 = var8.isInRange(var23, var28);
//     org.jfree.data.time.SerialDate var30 = var3.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var8);
//     java.lang.String var31 = var3.toString();
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var34 = var33.toSerial();
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var33);
//     int var36 = var33.getYYYY();
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, (-1.0d));
//     long var41 = var38.getFirstMillisecond();
//     long var42 = var38.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var38, (java.lang.Number)(byte)0);
//     java.lang.String var45 = var38.toString();
//     java.lang.String var46 = var38.toString();
//     org.jfree.data.time.SerialDate var47 = var38.getSerialDate();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var47);
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     long var50 = var49.getSerialIndex();
//     org.jfree.data.time.SerialDate var51 = var49.getSerialDate();
//     boolean var53 = var33.isInRange(var48, var51, 100);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var56 = var55.getTime();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.addDays(2014, var57);
//     org.jfree.data.time.SerialDate var59 = var48.getEndOfCurrentMonth(var57);
//     org.jfree.data.time.FixedMillisecond var61 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var62 = var61.getTime();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addDays(2014, var63);
//     boolean var65 = var3.isInRange(var59, var64);
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate)var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate)var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "20-December-2014"+ "'", var21.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "30-January-1900"+ "'", var31.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "20-December-2014"+ "'", var45.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "20-December-2014"+ "'", var46.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-459), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     java.lang.Object var8 = var7.clone();
//     java.lang.Number var9 = var7.getValue();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.getPeriod();
//     boolean var11 = var4.equals((java.lang.Object)var10);
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)1388563200000L);
//     long var14 = var4.getSerialIndex();
//     java.util.Calendar var15 = null;
//     long var16 = var4.getLastMillisecond(var15);
//     long var17 = var4.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "December 2014"+ "'", var1.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (-1.0d)+ "'", var9.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1417420800000L);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.Class var5 = var2.getTimePeriodClass();
    org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
    java.util.Date var7 = var6.getEnd();
    int var8 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var6);
    int var9 = var2.getItemCount();
    boolean var10 = var2.getNotify();
    boolean var11 = var2.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-452));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var3 = var2.getTime();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3, var5);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     var2.removeAgedItems(false);
//     var2.clear();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.RegularTimePeriod var12 = var11.previous();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var18 = var17.getTime();
//     boolean var19 = var16.equals((java.lang.Object)var18);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var23 = var22.getTime();
//     boolean var24 = var21.equals((java.lang.Object)var23);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (-1.0d));
//     long var29 = var26.getFirstMillisecond();
//     long var30 = var26.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)(byte)0);
//     java.lang.String var33 = var26.toString();
//     java.lang.String var34 = var26.toString();
//     org.jfree.data.time.SerialDate var35 = var26.getSerialDate();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var35);
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var39 = var38.getTime();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.addDays(2014, var40);
//     boolean var42 = var21.isInRange(var36, var41);
//     org.jfree.data.time.SerialDate var43 = var16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var21);
//     java.util.Date var44 = var21.toDate();
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(var44);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day(var44);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day(var44);
//     org.jfree.data.time.TimeSeriesDataItem var49 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var47, (java.lang.Number)12);
//     java.util.Calendar var50 = null;
//     var47.peg(var50);
// 
//   }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (-1.0d));
//     long var5 = var2.getFirstMillisecond();
//     long var6 = var2.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(byte)0);
//     java.lang.String var9 = var2.toString();
//     java.lang.String var10 = var2.toString();
//     org.jfree.data.time.SerialDate var11 = var2.getSerialDate();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var11);
//     org.jfree.data.general.SeriesChangeEvent var13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var12);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-452), var12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "20-December-2014"+ "'", var9.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "20-December-2014"+ "'", var10.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var3);
//     var4.removeAgedItems(false);
//     java.util.Collection var7 = var4.getTimePeriods();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var9);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     long var12 = var11.getSerialIndex();
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var14 = var10.createCopy((org.jfree.data.time.RegularTimePeriod)var11, (org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var14.addChangeListener(var15);
//     org.jfree.data.general.SeriesChangeListener var17 = null;
//     var14.removeChangeListener(var17);
//     var14.setDomainDescription("14-December-2014");
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (-1.0d));
//     java.lang.Object var24 = var23.clone();
//     java.lang.Number var25 = var23.getValue();
//     org.jfree.data.time.RegularTimePeriod var26 = var23.getPeriod();
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     java.lang.String var28 = var27.toString();
//     java.util.Date var29 = var27.getStart();
//     org.jfree.data.time.TimeSeries var30 = var14.createCopy(var26, (org.jfree.data.time.RegularTimePeriod)var27);
//     var14.setDomainDescription("20-December-2014");
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var35 = var34.toString();
//     org.jfree.data.time.TimeSeriesDataItem var37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)10L);
//     long var38 = var34.getSerialIndex();
//     org.jfree.data.general.SeriesChangeEvent var39 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var34);
//     int var40 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var34);
//     java.util.Calendar var41 = null;
//     long var42 = var34.getFirstMillisecond(var41);
//     org.jfree.data.time.TimeSeriesDataItem var44 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var34, 10.0d);
//     java.util.Calendar var45 = null;
//     long var46 = var34.getLastMillisecond(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + (-1.0d)+ "'", var25.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + "December 2014"+ "'", var28.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var35.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0L);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var2 = var0.compareTo((java.lang.Object)'a');
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getFirstMillisecond();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     java.util.Date var6 = var5.getEnd();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(var6);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var6);
//     boolean var9 = var0.equals((java.lang.Object)var6);
//     java.util.Calendar var10 = null;
//     long var11 = var0.getFirstMillisecond(var10);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     long var3 = var0.getFirstMillisecond();
//     long var4 = var0.getLastMillisecond();
//     int var5 = var0.getDayOfMonth();
//     java.util.Calendar var6 = null;
//     long var7 = var0.getMiddleMillisecond(var6);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     int var4 = var0.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeries var6 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var3, (org.jfree.data.time.RegularTimePeriod)var5);
//     int var7 = var2.getItemCount();
//     java.lang.String var8 = var2.getDescription();
//     java.beans.PropertyChangeListener var9 = null;
//     var2.addPropertyChangeListener(var9);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var14);
//     boolean var16 = var15.isEmpty();
//     var15.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var21 = var20.toString();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.util.Calendar var24 = null;
//     long var25 = var20.getMiddleMillisecond(var24);
//     boolean var27 = var20.equals((java.lang.Object)1L);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     boolean var29 = var20.equals((java.lang.Object)var28);
//     org.jfree.data.time.RegularTimePeriod var30 = var28.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update(var30, (java.lang.Number)2147483647);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Wed Dec 31 16:00:00 PST 1969"+ "'", var21.equals("Wed Dec 31 16:00:00 PST 1969"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.setDescription("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.Class var5 = var2.getTimePeriodClass();
    java.util.Collection var6 = var2.getTimePeriods();
    org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
    int var9 = var7.compareTo((java.lang.Object)'a');
    org.jfree.data.time.RegularTimePeriod var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var11 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var7, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var4 = null;
    var2.removeChangeListener(var4);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var9);
    var10.removeAgedItems(false);
    java.util.Collection var13 = var10.getTimePeriods();
    java.lang.Class var17 = null;
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var17);
    boolean var19 = var18.isEmpty();
    java.lang.String var20 = var18.getDescription();
    java.util.Collection var21 = var10.getTimePeriodsUniqueToOtherSeries(var18);
    org.jfree.data.time.TimeSeries var22 = var2.addAndOrUpdate(var10);
    var22.setMaximumItemAge(0L);
    var22.removeAgedItems(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var28 = var22.getValue((-41962));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var4 = var3.getTime();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(31);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var9 = var8.getTime();
//     boolean var10 = var7.equals((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     long var15 = var12.getFirstMillisecond();
//     long var16 = var12.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(byte)0);
//     java.lang.String var19 = var12.toString();
//     java.lang.String var20 = var12.toString();
//     org.jfree.data.time.SerialDate var21 = var12.getSerialDate();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var21);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var25 = var24.getTime();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(2014, var26);
//     boolean var28 = var7.isInRange(var22, var27);
//     org.jfree.data.time.SerialDate var29 = var2.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var7);
//     java.lang.String var30 = var2.toString();
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(31);
//     int var33 = var32.toSerial();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var32);
//     int var35 = var32.getYYYY();
//     org.jfree.data.time.Day var37 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (-1.0d));
//     long var40 = var37.getFirstMillisecond();
//     long var41 = var37.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)(byte)0);
//     java.lang.String var44 = var37.toString();
//     java.lang.String var45 = var37.toString();
//     org.jfree.data.time.SerialDate var46 = var37.getSerialDate();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var46);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     long var49 = var48.getSerialIndex();
//     org.jfree.data.time.SerialDate var50 = var48.getSerialDate();
//     boolean var52 = var32.isInRange(var47, var50, 100);
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var55 = var54.getTime();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addDays(2014, var56);
//     org.jfree.data.time.SerialDate var58 = var47.getEndOfCurrentMonth(var56);
//     org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Date var61 = var60.getTime();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var61);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addDays(2014, var62);
//     boolean var64 = var2.isInRange(var58, var63);
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate)var2);
//     int var66 = var2.toSerial();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "20-December-2014"+ "'", var19.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "20-December-2014"+ "'", var20.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "30-January-1900"+ "'", var30.equals("30-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var44 + "' != '" + "20-December-2014"+ "'", var44.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + "20-December-2014"+ "'", var45.equals("20-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 41993L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 31);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getSerialIndex();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (-1.0d));
//     java.lang.Object var3 = var2.clone();
//     java.lang.Number var4 = var2.getValue();
//     java.lang.Number var5 = var2.getValue();
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getPeriod();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var10 = var7.getFirstMillisecond();
//     long var11 = var7.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)(byte)0);
//     java.lang.Number var14 = var13.getValue();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var16);
//     var17.fireSeriesChanged();
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var17.removeChangeListener(var19);
//     int var21 = var13.compareTo((java.lang.Object)var17);
//     int var22 = var2.compareTo((java.lang.Object)var13);
//     java.lang.Object var23 = var13.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + (-1.0d)+ "'", var4.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (-1.0d)+ "'", var5.equals((-1.0d)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419062400000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148799999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (byte)0+ "'", var14.equals((byte)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     int var13 = var11.getYear();
//     long var14 = var11.getLastMillisecond();
//     java.util.Calendar var15 = null;
//     var11.peg(var15);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100L, "hi!", "hi!", var16);
//     boolean var18 = var17.isEmpty();
//     var17.setMaximumItemAge(1419140703900L);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var23 = var22.toString();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var22, 1.0d);
//     boolean var26 = var11.equals((java.lang.Object)var22);
//     long var27 = var11.getSerialIndex();
//     java.util.Calendar var28 = null;
//     var11.peg(var28);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d, var1);
//     var2.fireSeriesChanged();
//     var2.fireSeriesChanged();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (-1.0d));
//     int var8 = var5.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var5, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Year var11 = var9.getYear();
//     java.lang.String var12 = var11.toString();
//     long var13 = var11.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var14 = var11.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var11);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)false);
    java.lang.Object var3 = var2.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + false+ "'", var3.equals(false));

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     int var2 = var0.compareTo((java.lang.Object)'4');
//     java.util.Date var3 = var0.getStart();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.lang.String var6 = var5.toString();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)10L);
//     int var9 = var0.compareTo((java.lang.Object)10L);
//     java.util.Date var10 = var0.getStart();
//     java.util.Calendar var11 = null;
//     long var12 = var0.getLastMillisecond(var11);
// 
//   }

}
