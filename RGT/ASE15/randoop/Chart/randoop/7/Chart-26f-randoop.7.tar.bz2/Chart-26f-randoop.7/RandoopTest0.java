
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     java.awt.Color var0 = null;
//     java.lang.String var1 = org.jfree.chart.util.PaintUtilities.colorToString(var0);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    java.awt.Paint var3 = null;
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryMarker var6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0d, var1, var2, var3, var4, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { "hi!"};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.block.LabelBlock var3 = new org.jfree.chart.block.LabelBlock("", var1, var2);
//     
//     // Checks the contract:  var3.equals(var3)
//     assertTrue("Contract failed: var3.equals(var3)", var3.equals(var3));
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, var1);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.awt.Shape var5 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Shape var16 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var17 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var18 = var17.clone();
    java.awt.Paint var19 = var17.getBasePaint();
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var16, var19);
    java.awt.Stroke var21 = null;
    java.awt.Shape var23 = null;
    java.awt.Stroke var24 = null;
    java.awt.Color var28 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "ThreadContext", "", "hi!", false, var5, false, (java.awt.Paint)var10, false, var19, var21, false, var23, var24, (java.awt.Paint)var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    float[] var3 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = java.awt.Color.RGBtoHSB(100, 10, 0, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    org.jfree.chart.util.GradientPaintTransformer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setFillPaintTransformer(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setPadding(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)1.0d, var1, var2, var3, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(1, var1);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.lang.Boolean var2 = var0.getSeriesShapesVisible(100);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var9 = var8.getLabel();
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.data.category.CategoryDataset var11 = null;
//     var0.drawItem(var3, var4, var5, var6, (org.jfree.chart.axis.CategoryAxis)var8, var10, var11, 0, 1, 4);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var2 = var1.getCategoryLabelPositionOffset();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.axis.AxisState var9 = var1.draw(var3, 0.0d, var5, var6, var7, var8);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 100.0d, 0.0d, var3);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 100.0d, 10.0f, 0.0f);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    boolean var3 = var0.getBaseSeriesVisible();
    org.jfree.chart.labels.ItemLabelPosition var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseNegativeItemLabelPosition(var4, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var2 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var4 = var3.clone();
    java.awt.Paint var5 = var3.getBasePaint();
    boolean var6 = var3.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
    java.awt.Font var11 = null;
    var3.setSeriesItemLabelFont(0, var11, true);
    java.awt.Font var14 = var3.getBaseItemLabelFont();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelFont((-1), var14, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     java.lang.Number[] var0 = null;
//     java.lang.Number[][] var1 = new java.lang.Number[][] { var0};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    java.awt.Shape var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = var2.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.renderer.WaferMapRenderer var5 = null;
    org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var4, var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var6.setBackgroundPaint(var9);
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.WaterfallBarRenderer var12 = new org.jfree.chart.renderer.category.WaterfallBarRenderer(var1, var3, var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var2.handleClick(0, 4, var5);
//     org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", var1, 0.0f, 100.0f, var4, 1.0d, 0.0f, 0.0f);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 0.0d, 10.0d, var3);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     var2.setDataset(var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     org.jfree.chart.plot.PlotState var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var2.draw(var6, var7, var8, var9, var10);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.LegendItemEntity var1 = new org.jfree.chart.entity.LegendItemEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.data.category.CategoryDataset var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var3, var4, var5, var6, var7, 100, (-1), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.urls.PieURLGenerator var1 = var0.getURLGenerator();
//     double var2 = var0.getMaximumExplodePercent();
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getBasePaint();
//     boolean var3 = var0.getBaseSeriesVisible();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var6 = var5.clone();
//     java.awt.Paint var7 = var5.getBasePaint();
//     boolean var8 = var5.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var11 = var5.getURLGenerator(100, 4);
//     java.awt.Font var13 = null;
//     var5.setSeriesItemLabelFont(0, var13, true);
//     java.awt.Font var16 = var5.getBaseItemLabelFont();
//     var0.setSeriesItemLabelFont(10, var16, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.Marker var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    double var1 = var0.getUpperClip();
    org.jfree.chart.labels.CategoryToolTipGenerator var4 = var0.getToolTipGenerator(4, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var3 = var0.isItemLabelVisible(1, 0);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = null;
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var11 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var4, var5, var6, var7, (org.jfree.chart.axis.CategoryAxis)var9, var10, (org.jfree.data.category.CategoryDataset)var11, 10, 4, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Font var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    java.awt.Paint var3 = var1.getBasePaint();
    boolean var4 = var1.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var7 = var1.getURLGenerator(100, 4);
    java.awt.Font var9 = null;
    var1.setSeriesItemLabelFont(0, var9, true);
    java.awt.Font var12 = var1.getBaseItemLabelFont();
    java.awt.Color var16 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var16);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setLineAlignment(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(1900, 10, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.AxisLocation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation(0, var9, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var4 = var3.darker();
    float[] var5 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var4.getRGBComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Stroke var4 = var2.getOutlineStroke();
//     java.lang.String var5 = var2.getPlotType();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     org.jfree.chart.plot.PlotState var9 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var2.draw(var6, var7, var8, var9, var10);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var4.rendererChanged(var11);
    org.jfree.chart.plot.Marker var13 = null;
    org.jfree.chart.util.Layer var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var14, (java.lang.Comparable)'a');
//     var7.setDataset(4, (org.jfree.data.category.CategoryDataset)var14);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("WMAP_Plot", var1);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var9 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var11 = var10.clone();
    java.awt.Paint var12 = var10.getBasePaint();
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var9, var12);
    var3.setSeriesOutlinePaint(0, var12, true);
    var0.setBackgroundPaint(var12);
    java.lang.Comparable var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var18 = var0.getSectionPaint(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    java.util.List var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var8, (java.lang.Comparable)true, (java.lang.Comparable)100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 2.0d, 1.0f, 0.0f);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    boolean var3 = var0.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getURLGenerator(100, 4);
    var0.setBase(100.0d);
    org.jfree.chart.plot.DrawingSupplier var9 = var0.getDrawingSupplier();
    boolean var10 = var0.getAutoPopulateSeriesOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("WMAP_Plot", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.plot.CategoryMarker var14 = null;
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
    java.awt.Color var6 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var7 = var6.darker();
    boolean var8 = var2.equals((java.lang.Object)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var10 = var2.get(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var12.getRangeMarkers(0, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.data.Range var17 = var12.getDataRange(var16);
    org.jfree.chart.axis.AxisSpace var18 = null;
    var12.setFixedDomainAxisSpace(var18);
    java.util.List var20 = var12.getAnnotations();
    java.lang.Comparable var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var20, (java.lang.Comparable)"hi!", var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setSeriesItemLabelsVisible(4, true);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var11, var12, var13);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    java.awt.geom.Point2D var18 = null;
    var14.zoomDomainAxes((-1.0d), 0.2d, var17, var18);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var22 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var20, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, var24, var25, var26);
    org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var29 = var28.getLabelOutlinePaint();
    var27.setRangeCrosshairPaint(var29);
    int var31 = var27.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var32 = new org.jfree.chart.axis.AxisSpace();
    var27.setFixedRangeAxisSpace(var32);
    org.jfree.chart.axis.AxisSpace var34 = new org.jfree.chart.axis.AxisSpace();
    var27.setFixedRangeAxisSpace(var34);
    org.jfree.chart.axis.CategoryAxis var37 = var27.getDomainAxisForDataset(0);
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var39 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var41 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var39, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var39, var43, var44, var45);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var4, var5, var6, var14, var37, var38, (org.jfree.data.category.CategoryDataset)var39, 1900, 100, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    java.awt.Stroke var3 = var0.getLabelOutlineStroke();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var7 = null;
    var6.setLabelOutlinePaint(var7);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var4, var5, var6, (java.lang.Integer)0, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.util.RectangleInsets var3 = var1.getTickLabelInsets();
    double var5 = var3.calculateTopOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var4 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var3);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var11 = var8.isOnOrBefore((org.jfree.data.time.SerialDate)var10);
    boolean var12 = var6.isOnOrAfter((org.jfree.data.time.SerialDate)var10);
    boolean var13 = var3.isBefore((org.jfree.data.time.SerialDate)var10);
    var3.setDescription("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 0.0f, 0.0f, 100.0d, 0.0f, 1.0f);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = null;
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.block.RectangleConstraint var3 = null;
//     org.jfree.chart.util.Size2D var4 = var0.arrange(var1, var2, var3);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var13 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var13, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var17, var18, var19);
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var22 = var21.getLabelOutlinePaint();
//     var20.setRangeCrosshairPaint(var22);
//     int var24 = var20.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var25 = new org.jfree.chart.axis.AxisSpace();
//     var20.setFixedRangeAxisSpace(var25);
//     org.jfree.chart.axis.AxisSpace var27 = new org.jfree.chart.axis.AxisSpace();
//     var20.setFixedRangeAxisSpace(var27);
//     var4.setFixedRangeAxisSpace(var27);
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var31 = var30.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var32 = var30.getLegendItems();
//     java.awt.Color var36 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var37 = var36.darker();
//     boolean var38 = var32.equals((java.lang.Object)var36);
//     java.lang.Object var39 = null;
//     boolean var40 = var32.equals(var39);
//     var4.setFixedLegendItems(var32);
//     
//     // Checks the contract:  equals-hashcode on var21 and var30
//     assertTrue("Contract failed: equals-hashcode on var21 and var30", var21.equals(var30) ? var21.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var21
//     assertTrue("Contract failed: equals-hashcode on var30 and var21", var30.equals(var21) ? var30.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var3 = var0.isItemLabelVisible(1, 0);
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     java.awt.Stroke var9 = var8.getBorderStroke();
//     var0.setSeriesStroke(100, var9, true);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var13 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var14 = var13.clone();
//     java.awt.Paint var15 = var13.getBasePaint();
//     boolean var16 = var13.getBaseSeriesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var19 = var18.getCategoryLabelPositionOffset();
//     java.awt.Paint var20 = var18.getAxisLinePaint();
//     java.awt.Stroke var21 = var18.getTickMarkStroke();
//     var13.setBaseStroke(var21, true);
//     var0.setSeriesStroke(4, var21);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var13 and var0.", var13.equals(var0) == var0.equals(var13));
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = var2.getWidthRange();
    org.jfree.chart.block.LengthConstraintType var4 = var2.getHeightConstraintType();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    boolean var8 = var5.getBaseSeriesVisible();
    boolean var9 = var4.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var2 = var0.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var3 = var0.getLabelLinksVisible();
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendLabelGenerator(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    org.jfree.chart.axis.CategoryAxis var17 = var7.getDomainAxisForDataset(0);
    org.jfree.chart.axis.CategoryAnchor var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDomainGridlinePosition(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.util.TableOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataExtractOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.axis.CategoryAxis var17 = var7.getDomainAxisForDataset(0);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var18, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var18, var22, var23, var24);
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var27 = var26.getLabelOutlinePaint();
//     var25.setRangeCrosshairPaint(var27);
//     int var29 = var25.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var30 = new org.jfree.chart.axis.AxisSpace();
//     var25.setFixedRangeAxisSpace(var30);
//     org.jfree.chart.axis.AxisSpace var32 = new org.jfree.chart.axis.AxisSpace();
//     var25.setFixedRangeAxisSpace(var32);
//     org.jfree.chart.util.SortOrder var34 = var25.getRowRenderingOrder();
//     var7.setColumnRenderingOrder(var34);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var25
//     assertTrue("Contract failed: equals-hashcode on var7 and var25", var7.equals(var25) ? var7.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var7
//     assertTrue("Contract failed: equals-hashcode on var25 and var7", var25.equals(var7) ? var25.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var7 = var6.getLabelOutlinePaint();
    var4.setBackgroundPaint(var7);
    var0.setLabelShadowPaint(var7);
    int var10 = var0.getPieIndex();
    java.lang.Comparable var11 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var13 = var12.clone();
    java.awt.Paint var14 = var12.getBasePaint();
    boolean var15 = var12.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var18 = var12.getURLGenerator(100, 4);
    java.awt.Font var20 = null;
    var12.setSeriesItemLabelFont(0, var20, true);
    java.awt.Paint var23 = var12.getBasePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSectionPaint(var11, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
    java.awt.Color var6 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var7 = var6.darker();
    boolean var8 = var2.equals((java.lang.Object)var6);
    java.lang.Object var9 = null;
    boolean var10 = var2.equals(var9);
    int var11 = var2.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(var0, var1);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    var3.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var7 = var3.getPadding();
    org.jfree.chart.event.ChartChangeListener var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addChangeListener(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
//     java.awt.Paint var10 = var4.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var12 = var4.getRangeAxisLocation(1);
//     java.lang.Object var13 = null;
//     boolean var14 = var12.equals(var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var19.getRangeMarkers(0, var21);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.data.Range var24 = var19.getDataRange(var23);
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     var19.setFixedDomainAxisSpace(var25);
//     boolean var27 = var19.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotOrientation var28 = var19.getOrientation();
//     org.jfree.chart.util.RectangleEdge var29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var12, var28);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var0.setSeriesToolTipGenerator(0, var3, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = var0.getItemLabelGenerator((-1), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Stroke var4 = var2.getOutlineStroke();
//     org.jfree.chart.LegendItemCollection var5 = var2.getLegendItems();
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    boolean var3 = var0.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getURLGenerator(100, 4);
    boolean var7 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("WMAP_Plot", "black", var3);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     var17.zoomDomainAxes((-1.0d), 0.2d, var20, var21);
//     java.awt.Paint var23 = var17.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var25 = var17.getRangeAxisLocation(1);
//     java.lang.Object var26 = null;
//     boolean var27 = var25.equals(var26);
//     var4.setDomainAxisLocation(var25);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var33.getRangeMarkers(0, var35);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.data.Range var38 = var33.getDataRange(var37);
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var33.setFixedDomainAxisSpace(var39);
//     java.awt.Paint var41 = null;
//     var33.setRangeTickBandPaint(var41);
//     java.awt.geom.Point2D var43 = var33.getQuadrantOrigin();
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     java.awt.geom.Point2D var52 = null;
//     var48.zoomDomainAxes((-1.0d), 0.2d, var51, var52);
//     java.awt.Paint var54 = var48.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var56 = var48.getRangeAxisLocation(1);
//     java.lang.Object var57 = null;
//     boolean var58 = var56.equals(var57);
//     var33.setRangeAxisLocation(var56);
//     var4.setDomainAxisLocation(var56, true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var48
//     assertTrue("Contract failed: equals-hashcode on var17 and var48", var17.equals(var48) ? var17.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var17
//     assertTrue("Contract failed: equals-hashcode on var48 and var17", var48.equals(var17) ? var48.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    java.lang.Number var10 = var0.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var13 = var0.getQ3Value(10, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getMaxOutlier(4, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var2 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var3 = var2.getChartArea();
//     var1.setLegendItemShape((java.awt.Shape)var3);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, (java.awt.Shape)var3, 0.0d, 0.0f, 0.0f);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Stroke var4 = var3.getBorderStroke();
//     var3.setAntiAlias(false);
//     org.jfree.chart.event.TitleChangeEvent var7 = null;
//     var3.titleChanged(var7);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.data.Range var9 = var4.getDataRange(var8);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var4.setFixedDomainAxisSpace(var10);
//     java.awt.Paint var12 = null;
//     var4.setRangeTickBandPaint(var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = var4.getRendererForDataset(var14);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     org.jfree.chart.util.Layer var23 = null;
//     java.util.Collection var24 = var21.getRangeMarkers(0, var23);
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.data.Range var26 = var21.getDataRange(var25);
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var21.setFixedDomainAxisSpace(var27);
//     java.awt.Paint var29 = null;
//     var21.setRangeTickBandPaint(var29);
//     java.awt.geom.Point2D var31 = var21.getQuadrantOrigin();
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     java.awt.geom.Point2D var40 = null;
//     var36.zoomDomainAxes((-1.0d), 0.2d, var39, var40);
//     java.awt.Paint var42 = var36.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var44 = var36.getRangeAxisLocation(1);
//     java.lang.Object var45 = null;
//     boolean var46 = var44.equals(var45);
//     var21.setRangeAxisLocation(var44);
//     org.jfree.chart.axis.AxisLocation var49 = var21.getDomainAxisLocation((-1));
//     var4.setDomainAxisLocation(4, var49, true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var4
//     assertTrue("Contract failed: equals-hashcode on var36 and var4", var36.equals(var4) ? var36.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var36 and var4.", var36.equals(var4) == var4.equals(var36));
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setSeriesShapesVisible(1, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var6 = var0.equals((java.lang.Object)var5);
    boolean var7 = var0.getBaseShapesFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10, 100, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    double var3 = var2.getWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isRangeCrosshairVisible();
//     java.awt.Stroke var6 = var4.getRangeZeroBaselineStroke();
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     org.jfree.chart.util.Layer var13 = null;
//     java.util.Collection var14 = var11.getRangeMarkers(0, var13);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var11.zoomDomainAxes(2.0d, 1.0d, var17, var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var24.zoomDomainAxes((-1.0d), 0.2d, var27, var28);
//     java.awt.Paint var30 = var24.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var32 = var24.getRangeAxisLocation(1);
//     java.lang.Object var33 = null;
//     boolean var34 = var32.equals(var33);
//     var11.setDomainAxisLocation(var32);
//     var4.setDomainAxisLocation(var32, true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.data.general.WaferMapDataset var11 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var12 = null;
//     org.jfree.chart.plot.WaferMapPlot var13 = new org.jfree.chart.plot.WaferMapPlot(var11, var12);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
//     java.awt.Image var15 = null;
//     var14.setBackgroundImage(var15);
//     org.jfree.chart.title.TextTitle var17 = null;
//     var14.setTitle(var17);
//     var14.setAntiAlias(false);
//     float var21 = var14.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var22 = var14.getLegend();
//     var3.addLegend(var22);
//     
//     // Checks the contract:  equals-hashcode on var2 and var13
//     assertTrue("Contract failed: equals-hashcode on var2 and var13", var2.equals(var13) ? var2.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var2
//     assertTrue("Contract failed: equals-hashcode on var13 and var2", var13.equals(var2) ? var13.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.plot.AbstractPieLabelDistributor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("WMAP_Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var2 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var3 = var2.getChartArea();
//     var1.setLegendItemShape((java.awt.Shape)var3);
//     var0.setChartArea(var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    java.lang.Number var10 = var0.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var13 = var0.getValue(100, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorUp(10.0d);
    double var3 = var0.getCursor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-10.0d));

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    double var2 = var0.getMaximumBarWidth();
    java.lang.Boolean var4 = var0.getSeriesVisibleInLegend(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var26 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var28 = var27.clone();
//     java.awt.Paint var29 = var27.getBasePaint();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var26, var29);
//     var20.setSeriesOutlinePaint(0, var29, true);
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var29, 0.0f, var34);
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var37 = null;
//     var36.setLabelOutlinePaint(var37);
//     java.awt.Stroke var39 = var36.getLabelOutlineStroke();
//     java.awt.Paint var40 = var36.getLabelPaint();
//     org.jfree.chart.text.TextLine var41 = new org.jfree.chart.text.TextLine("", var14, var40);
//     org.jfree.chart.text.TextFragment var42 = var41.getFirstTextFragment();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var47 = var46.clone();
//     java.awt.Paint var48 = var46.getBasePaint();
//     boolean var49 = var46.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var52 = var46.getURLGenerator(100, 4);
//     java.awt.Font var54 = null;
//     var46.setSeriesItemLabelFont(0, var54, true);
//     java.awt.Font var57 = var46.getBaseItemLabelFont();
//     java.awt.Color var61 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("", var57, (java.awt.Paint)var61);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var69 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var70 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var71 = var70.clone();
//     java.awt.Paint var72 = var70.getBasePaint();
//     org.jfree.chart.LegendItem var73 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var69, var72);
//     var63.setSeriesOutlinePaint(0, var72, true);
//     org.jfree.chart.text.TextMeasurer var77 = null;
//     org.jfree.chart.text.TextBlock var78 = org.jfree.chart.text.TextUtilities.createTextBlock("", var57, var72, 0.0f, var77);
//     org.jfree.chart.plot.PiePlot var79 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var80 = null;
//     var79.setLabelOutlinePaint(var80);
//     java.awt.Stroke var82 = var79.getLabelOutlineStroke();
//     java.awt.Paint var83 = var79.getLabelPaint();
//     org.jfree.chart.text.TextLine var84 = new org.jfree.chart.text.TextLine("", var57, var83);
//     org.jfree.chart.text.TextFragment var85 = var84.getFirstTextFragment();
//     float var86 = var85.getBaselineOffset();
//     var41.addFragment(var85);
//     
//     // Checks the contract:  equals-hashcode on var30 and var73
//     assertTrue("Contract failed: equals-hashcode on var30 and var73", var30.equals(var73) ? var30.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var30
//     assertTrue("Contract failed: equals-hashcode on var73 and var30", var73.equals(var30) ? var73.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var79
//     assertTrue("Contract failed: equals-hashcode on var36 and var79", var36.equals(var79) ? var36.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var36
//     assertTrue("Contract failed: equals-hashcode on var79 and var36", var79.equals(var36) ? var79.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var2 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var8 = var7.getLabelInsets();
//     double var10 = var8.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     java.awt.geom.Rectangle2D var15 = var8.createInsetRectangle(var12, true, false);
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.getCategoryJava2DCoordinate(var3, 13, 13, var15, var16);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.axis.CategoryLabelPositions var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setCategoryLabelPositions(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
//     org.jfree.chart.ChartRenderingInfo var3 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var4 = var3.getChartArea();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, var9, var10, var11);
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var14 = var13.getLabelOutlinePaint();
//     var12.setRangeCrosshairPaint(var14);
//     int var16 = var12.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var17 = new org.jfree.chart.axis.AxisSpace();
//     var12.setFixedRangeAxisSpace(var17);
//     org.jfree.chart.axis.AxisSpace var19 = new org.jfree.chart.axis.AxisSpace();
//     var12.setFixedRangeAxisSpace(var19);
//     java.lang.String var21 = var12.getPlotType();
//     boolean var22 = var12.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var26 = var25.getLabel();
//     org.jfree.data.KeyedObject var27 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var25);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("");
//     var29.setUpperMargin(0.0d);
//     var29.setInverted(true);
//     boolean var34 = var29.isVerticalTickLabels();
//     double var35 = var29.getFixedAutoRange();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var36 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     var0.drawHorizontalItem(var1, var2, var4, var12, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.data.category.CategoryDataset)var36, 1900, (-1));
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.axis.CategoryAxis var17 = var7.getDomainAxisForDataset(0);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = var7.getRendererForDataset((org.jfree.data.category.CategoryDataset)var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var1 = var0.clone();
    double var2 = var0.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelOutlinePaint();
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var7 = var6.getLabelOutlinePaint();
//     var4.setBackgroundPaint(var7);
//     var0.setLabelShadowPaint(var7);
//     boolean var10 = var0.getIgnoreZeroValues();
//     double var11 = var0.getMaximumExplodePercent();
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getQ3Value(0, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setText("black");

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = null;
    var0.setSeriesItemLabelGenerator(1900, var2);
    boolean var4 = var0.getAutoPopulateSeriesStroke();
    boolean var5 = var0.getAutoPopulateSeriesFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var7 = var6.getLabelOutlinePaint();
    var4.setBackgroundPaint(var7);
    var0.setLabelShadowPaint(var7);
    int var10 = var0.getPieIndex();
    double var11 = var0.getMinimumArcAngleToDraw();
    org.jfree.chart.urls.PieURLGenerator var12 = var0.getLegendLabelURLGenerator();
    var0.setMaximumLabelWidth((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.data.statistics.BoxAndWhiskerItem var8 = null;
//     var0.add(var8, (java.lang.Comparable)(-1), (java.lang.Comparable)10);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = null;
    var2.setLabelOutlinePaint(var3);
    java.awt.Stroke var5 = var2.getLabelOutlineStroke();
    var1.setOutlineStroke(var5);
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAggregatedItemsPaint(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition((-1));
//     var3.setNegativeItemLabelPositionFallback(var6);
//     var0.setBasePositiveItemLabelPosition(var6);
//     
//     // Checks the contract:  equals-hashcode on var2 and var6
//     assertTrue("Contract failed: equals-hashcode on var2 and var6", var2.equals(var6) ? var2.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var2
//     assertTrue("Contract failed: equals-hashcode on var6 and var2", var6.equals(var2) ? var6.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("XY Plot", var1);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getMargin();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.Image var6 = null;
    var5.setBackgroundImage(var6);
    org.jfree.chart.title.TextTitle var8 = null;
    var5.setTitle(var8);
    var5.setAntiAlias(false);
    float var12 = var5.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var13 = var5.getLegend();
    var13.setHeight(0.0d);
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var17 = var16.getLabelOutlinePaint();
    org.jfree.chart.LegendItemCollection var18 = var16.getLegendItems();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var23 = var22.darker();
    boolean var24 = var18.equals((java.lang.Object)var22);
    java.lang.Object var25 = null;
    boolean var26 = var18.equals(var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var13, (java.lang.Object)var18);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getBasePaint();
//     boolean var3 = var0.getBaseSeriesVisible();
//     double var4 = var0.getBase();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var6.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var9 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition((-1));
//     var6.setBasePositiveItemLabelPosition(var11, true);
//     var0.setSeriesNegativeItemLabelPosition(1900, var11, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var9 and var0.", var9.equals(var0) == var0.equals(var9));
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 0.0f, 10.0f, var4, 0.5f, 0.0f, 1.0d);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = null;
//     var0.setLabelOutlinePaint(var1);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var9 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var11 = var10.clone();
//     java.awt.Paint var12 = var10.getBasePaint();
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var9, var12);
//     var3.setSeriesOutlinePaint(0, var12, true);
//     var0.setBackgroundPaint(var12);
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var18 = null;
//     var17.setLabelOutlinePaint(var18);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var26 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var28 = var27.clone();
//     java.awt.Paint var29 = var27.getBasePaint();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var26, var29);
//     var20.setSeriesOutlinePaint(0, var29, true);
//     var17.setBackgroundPaint(var29);
//     var0.setBackgroundPaint(var29);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);
    org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isRangeCrosshairVisible();
//     java.awt.Stroke var6 = var4.getRangeZeroBaselineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var4.handleClick(4, 1900, var9);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var3 = var2.clone();
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, var8);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var10, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var14, var15, var16);
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var19 = var18.getLabelOutlinePaint();
//     var17.setRangeCrosshairPaint(var19);
//     var9.setDomainTickBandPaint(var19);
//     var2.setSeriesItemLabelPaint(10, var19, true);
//     org.jfree.chart.text.TextMeasurer var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("XY Plot", var1, var19, (-1.0f), var25);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     var3.setTitle("ThreadContext");
//     java.awt.Color var9 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var10 = var9.darker();
//     var3.setBorderPaint((java.awt.Paint)var10);
//     java.lang.String var12 = org.jfree.chart.util.PaintUtilities.colorToString(var10);
//     java.awt.color.ColorSpace var13 = null;
//     float[] var17 = new float[] { 1.0f, (-1.0f), 1.0f};
//     float[] var18 = var10.getComponents(var13, var17);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var6.getRangeMarkers(0, var8);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var6.getRangeMarkers(var10);
    var0.setObject((java.lang.Comparable)(short)(-1), (java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(3);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     boolean var11 = var7.isRangeCrosshairVisible();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var12, var16, var17, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomDomainAxes((-1.0d), 0.2d, var22, var23);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var32 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var34 = var33.clone();
//     java.awt.Paint var35 = var33.getBasePaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
//     var26.setSeriesOutlinePaint(0, var35, true);
//     var19.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
//     org.jfree.chart.axis.CategoryAnchor var40 = var19.getDomainGridlinePosition();
//     var7.setDomainGridlinePosition(var40);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var1 = var0.getURLGenerator();
    java.awt.Color var6 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var0.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInteriorGap(1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     float var8 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.event.PlotChangeEvent var9 = null;
//     var3.plotChanged(var9);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    java.awt.Paint var3 = var1.getBasePaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var10 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var11 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var12 = var11.clone();
    java.awt.Paint var13 = var11.getBasePaint();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var10, var13);
    var4.setSeriesOutlinePaint(0, var13, true);
    java.awt.Stroke var18 = var4.lookupSeriesOutlineStroke(10);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var19 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var20 = var19.clone();
    java.awt.Paint var21 = var19.getBasePaint();
    boolean var22 = var19.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var25 = var19.getURLGenerator(100, 4);
    java.awt.Paint var28 = var19.getItemOutlinePaint(10, (-1));
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isRangeCrosshairVisible();
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var37 = var36.getTickMarkStroke();
    var33.setDomainCrosshairStroke(var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(3.0d, var3, var18, var28, var37, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

//  public void test167() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var2);
//
//  }
//
  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.2d, 3.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var6 = var5.getMargin();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = null;
//     org.jfree.chart.util.Size2D var9 = var4.arrange(var5, var7, var8);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(3, 100, 0, 1, var4);
//     java.util.Date var6 = null;
//     java.util.Date var7 = var5.addToDate(var6);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.2d, 3.0d);
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, var8);
//     org.jfree.chart.util.Size2D var10 = var4.arrange(var5, var6, var9);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var2 = var0.getValue(13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getMargin();
//     org.jfree.chart.block.BlockContainer var2 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BlockFrame var3 = var2.getFrame();
//     var0.setFrame(var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraintType.RANGE");

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "hi!", "hi!", "");
    org.jfree.chart.ui.Library[] var5 = var4.getLibraries();
    java.lang.String var6 = var4.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "hi!"+ "'", var6.equals("hi!"));

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var11.setTitle("ThreadContext");
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var11.setBorderPaint((java.awt.Paint)var18);
    var7.setRangeGridlinePaint((java.awt.Paint)var18);
    int var21 = var18.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.statistics.BoxAndWhiskerItem var3 = var0.getItem(3, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     var11.setHeight(0.0d);
//     org.jfree.chart.util.RectangleAnchor var14 = var11.getLegendItemGraphicLocation();
//     org.jfree.data.general.WaferMapDataset var15 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var16 = null;
//     org.jfree.chart.plot.WaferMapPlot var17 = new org.jfree.chart.plot.WaferMapPlot(var15, var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     java.awt.Image var19 = null;
//     var18.setBackgroundImage(var19);
//     org.jfree.chart.title.TextTitle var21 = null;
//     var18.setTitle(var21);
//     var18.setAntiAlias(false);
//     float var25 = var18.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var26 = var18.getLegend();
//     java.awt.Paint var27 = var26.getBackgroundPaint();
//     var11.setItemPaint(var27);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     var11.setHeight(0.0d);
//     org.jfree.chart.util.RectangleAnchor var14 = var11.getLegendItemGraphicLocation();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelInsets();
//     double var19 = var17.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     java.awt.geom.Rectangle2D var24 = var17.createInsetRectangle(var21, true, false);
//     var11.setPadding(var17);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var29 = var28.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var36 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var37 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var38 = var37.clone();
//     java.awt.Paint var39 = var37.getBasePaint();
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var36, var39);
//     var30.setSeriesOutlinePaint(0, var39, true);
//     boolean var43 = var28.equals((java.lang.Object)var39);
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var46 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var47 = var46.getChartArea();
//     var45.setLegendItemShape((java.awt.Shape)var47);
//     var28.setSeriesShape(4, (java.awt.Shape)var47);
//     java.awt.geom.Rectangle2D var50 = var17.createOutsetRectangle(var47);
//     
//     // Checks the contract:  equals-hashcode on var20 and var46
//     assertTrue("Contract failed: equals-hashcode on var20 and var46", var20.equals(var46) ? var20.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var20
//     assertTrue("Contract failed: equals-hashcode on var46 and var20", var46.equals(var20) ? var46.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "April"+ "'", var1.equals("April"));

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    int var10 = var4.getDomainAxisCount();
    int var11 = var4.getDomainAxisCount();
    boolean var12 = var4.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.data.Range var9 = var4.getDataRange(var8);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var4.setFixedDomainAxisSpace(var10);
//     org.jfree.chart.axis.ValueAxis var13 = var4.getDomainAxis(4);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var4.handleClick(0, 0, var16);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
    java.awt.Paint var3 = var2.getWallPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var10 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var11 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var12 = var11.clone();
    java.awt.Paint var13 = var11.getBasePaint();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var10, var13);
    var4.setSeriesOutlinePaint(0, var13, true);
    boolean var17 = var2.equals((java.lang.Object)var13);
    org.jfree.data.category.CategoryDataset var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var19 = var2.findRangeBounds(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Paint var3 = var1.getBasePaint();
//     boolean var4 = var1.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var1.getURLGenerator(100, 4);
//     java.awt.Font var9 = null;
//     var1.setSeriesItemLabelFont(0, var9, true);
//     java.awt.Font var12 = var1.getBaseItemLabelFont();
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var16 = var15.getWallPaint();
//     org.jfree.chart.text.TextMeasurer var19 = null;
//     org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("April", var12, var16, 1.0f, 1900, var19);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isRangeCrosshairVisible();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, var12, var13, var14);
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var17 = var16.getLabelOutlinePaint();
//     var15.setRangeCrosshairPaint(var17);
//     int var19 = var15.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
//     var15.setFixedRangeAxisSpace(var20);
//     org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
//     var15.setFixedRangeAxisSpace(var22);
//     java.lang.String var24 = var15.getPlotType();
//     java.awt.Paint var25 = var15.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var28 = var27.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var30 = null;
//     var29.setLabelOutlinePaint(var30);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var38 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var39 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var40 = var39.clone();
//     java.awt.Paint var41 = var39.getBasePaint();
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var38, var41);
//     var32.setSeriesOutlinePaint(0, var41, true);
//     var29.setBackgroundPaint(var41);
//     java.awt.Stroke var46 = null;
//     org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var25, var28, var41, var46, 0.0f);
//     var4.setRangeGridlinePaint(var25);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var50 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var52 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var50, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var50, var54, var55, var56);
//     org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var59 = var58.getLabelOutlinePaint();
//     var57.setRangeCrosshairPaint(var59);
//     org.jfree.data.xy.XYDataset var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var61, var62, var63, var64);
//     org.jfree.chart.util.Layer var67 = null;
//     java.util.Collection var68 = var65.getRangeMarkers(0, var67);
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     java.awt.geom.Point2D var72 = null;
//     var65.zoomDomainAxes(2.0d, 1.0d, var71, var72);
//     org.jfree.data.xy.XYDataset var74 = null;
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var77 = null;
//     org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot(var74, var75, var76, var77);
//     org.jfree.chart.plot.PlotRenderingInfo var81 = null;
//     java.awt.geom.Point2D var82 = null;
//     var78.zoomDomainAxes((-1.0d), 0.2d, var81, var82);
//     java.awt.Paint var84 = var78.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var86 = var78.getRangeAxisLocation(1);
//     java.lang.Object var87 = null;
//     boolean var88 = var86.equals(var87);
//     var65.setDomainAxisLocation(var86);
//     var57.setDomainAxisLocation(var86);
//     var4.setDomainAxisLocation(var86);
//     
//     // Checks the contract:  equals-hashcode on var4 and var65
//     assertTrue("Contract failed: equals-hashcode on var4 and var65", var4.equals(var65) ? var4.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var4
//     assertTrue("Contract failed: equals-hashcode on var65 and var4", var65.equals(var4) ? var65.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var50
//     assertTrue("Contract failed: equals-hashcode on var8 and var50", var8.equals(var50) ? var8.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var8
//     assertTrue("Contract failed: equals-hashcode on var50 and var8", var50.equals(var8) ? var50.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var58
//     assertTrue("Contract failed: equals-hashcode on var16 and var58", var16.equals(var58) ? var16.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var16
//     assertTrue("Contract failed: equals-hashcode on var58 and var16", var58.equals(var16) ? var58.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var4.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition((-1));
//     var4.setBasePositiveItemLabelPosition(var9, true);
//     org.jfree.chart.text.TextAnchor var12 = var9.getTextAnchor();
//     java.awt.geom.Rectangle2D var13 = org.jfree.chart.text.TextUtilities.drawAlignedString("ThreadContext", var1, 0.5f, 1.0f, var12);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var15.getRangeMarkers(0, var17);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    java.awt.geom.Point2D var22 = null;
    var15.zoomDomainAxes(2.0d, 1.0d, var21, var22);
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.chart.plot.PlotRenderingInfo var31 = null;
    java.awt.geom.Point2D var32 = null;
    var28.zoomDomainAxes((-1.0d), 0.2d, var31, var32);
    java.awt.Paint var34 = var28.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var36 = var28.getRangeAxisLocation(1);
    java.lang.Object var37 = null;
    boolean var38 = var36.equals(var37);
    var15.setDomainAxisLocation(var36);
    var7.setDomainAxisLocation(var36);
    org.jfree.chart.plot.CategoryMarker var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.data.general.DatasetGroup var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setGroup(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var3 = null;
//     var2.setLabelOutlinePaint(var3);
//     java.awt.Stroke var5 = var2.getLabelOutlineStroke();
//     var1.setOutlineStroke(var5);
//     java.awt.Paint var7 = var1.getAggregatedItemsPaint();
//     org.jfree.chart.JFreeChart var8 = var1.getPieChart();
//     org.jfree.chart.event.TitleChangeEvent var9 = null;
//     var8.titleChanged(var9);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var6 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var8 = var7.clone();
    java.awt.Paint var9 = var7.getBasePaint();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var6, var9);
    var0.setSeriesOutlinePaint(0, var9, true);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var16 = var15.getCategoryLabelPositionOffset();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    var0.setSeriesItemLabelPaint(0, var17, true);
    var0.setSeriesShapesFilled(0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("April", var1);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var9 = var8.getNumberFormatOverride();
//     org.jfree.data.Range var12 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var13 = new org.jfree.data.time.DateRange(var12);
//     var8.setRangeWithMargins((org.jfree.data.Range)var13);
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelInsets();
//     double var19 = var17.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     java.awt.geom.Rectangle2D var24 = var17.createInsetRectangle(var21, true, false);
//     var8.setDownArrow((java.awt.Shape)var24);
//     var5.setSeriesShape(13, (java.awt.Shape)var24, false);
//     java.awt.Point var28 = var0.translateValueThetaRadiusToJava2D(1.0E-5d, (-1.0d), var24);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("black");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var2 = var0.getSectionPaint((java.lang.Comparable)10.0d);
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    java.util.List var1 = var0.getKeys();
    java.lang.Object var2 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var4 = var3.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var5 = var3.getLegendItems();
//     var2.addAll(var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    java.lang.Object var0 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = null;
    var2.setLabelOutlinePaint(var3);
    java.awt.Stroke var5 = var2.getLabelOutlineStroke();
    java.awt.Paint var6 = var2.getLabelPaint();
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var2);
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getBasePaint();
//     boolean var3 = var0.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getURLGenerator(100, 4);
//     var0.setBase(100.0d);
//     org.jfree.chart.plot.DrawingSupplier var9 = var0.getDrawingSupplier();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var11 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var13 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var11, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var15, var16, var17);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     java.awt.geom.Point2D var22 = null;
//     var18.zoomDomainAxes((-1.0d), 0.2d, var21, var22);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var31 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var33 = var32.clone();
//     java.awt.Paint var34 = var32.getBasePaint();
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var31, var34);
//     var25.setSeriesOutlinePaint(0, var34, true);
//     var18.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     var40.setUpperMargin(0.0d);
//     var40.setInverted(true);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var47 = var46.getNumberFormatOverride();
//     org.jfree.data.Range var50 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var51 = new org.jfree.data.time.DateRange(var50);
//     var46.setRangeWithMargins((org.jfree.data.Range)var51);
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var55 = var54.getLabelInsets();
//     double var57 = var55.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var58 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var59 = var58.getChartArea();
//     java.awt.geom.Rectangle2D var62 = var55.createInsetRectangle(var59, true, false);
//     var46.setDownArrow((java.awt.Shape)var62);
//     var0.drawRangeGridline(var10, var18, (org.jfree.chart.axis.ValueAxis)var40, var62, 0.0d);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var5 = var4.getLabelInsets();
    double var7 = var5.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var8 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var9 = var8.getChartArea();
    java.awt.geom.Rectangle2D var12 = var5.createInsetRectangle(var9, true, false);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var13 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var13, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var17, var18, var19);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    java.awt.geom.Point2D var24 = null;
    var20.zoomDomainAxes((-1.0d), 0.2d, var23, var24);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var33 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var35 = var34.clone();
    java.awt.Paint var36 = var34.getBasePaint();
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var33, var36);
    var27.setSeriesOutlinePaint(0, var36, true);
    var20.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
    org.jfree.chart.axis.CategoryAnchor var41 = var20.getDomainGridlinePosition();
    org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var44 = var43.getCategoryLabelPositionOffset();
    java.awt.Paint var45 = var43.getAxisLinePaint();
    java.awt.Stroke var46 = var43.getTickMarkStroke();
    java.util.EventListener var47 = null;
    boolean var48 = var43.hasListener(var47);
    float var49 = var43.getTickMarkInsideLength();
    org.jfree.data.xy.XYDataset var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.axis.ValueAxis var52 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
    org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
    org.jfree.chart.plot.PlotRenderingInfo var57 = null;
    java.awt.geom.Point2D var58 = null;
    var54.zoomDomainAxes((-1.0d), 0.2d, var57, var58);
    java.awt.Paint var60 = var54.getRangeCrosshairPaint();
    double var61 = var54.getDomainCrosshairValue();
    var54.setRangeZeroBaselineVisible(true);
    java.awt.Stroke var64 = var54.getRangeGridlineStroke();
    java.lang.String var65 = var54.getPlotType();
    org.jfree.data.xy.XYDataset var66 = null;
    org.jfree.chart.axis.ValueAxis var67 = null;
    org.jfree.chart.axis.ValueAxis var68 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var69 = null;
    org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot(var66, var67, var68, var69);
    org.jfree.chart.util.Layer var72 = null;
    java.util.Collection var73 = var70.getRangeMarkers(0, var72);
    org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("");
    var75.setUpperMargin(0.0d);
    var75.setInverted(true);
    boolean var80 = var75.isVerticalTickLabels();
    double var81 = var75.getFixedAutoRange();
    org.jfree.data.Range var82 = var70.getDataRange((org.jfree.chart.axis.ValueAxis)var75);
    org.jfree.data.Range var83 = var54.getDataRange((org.jfree.chart.axis.ValueAxis)var75);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var84 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var85 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var84);
    double var86 = var85.getLimit();
    org.jfree.data.category.CategoryDataset var87 = var85.getDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var12, var20, (org.jfree.chart.axis.CategoryAxis)var43, (org.jfree.chart.axis.ValueAxis)var75, var87, 1900, 13, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "XY Plot"+ "'", var65.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var5 = var4.getLabelOutlinePaint();
    var2.setBackgroundPaint(var5);
    org.jfree.chart.renderer.WaferMapRenderer var7 = null;
    var2.setRenderer(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    org.jfree.chart.axis.ValueAxis var13 = var4.getDomainAxis(4);
    int var14 = var4.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var4 = var3.darker();
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var6 = var5.getURLGenerator();
    java.awt.Color var11 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var5.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var11);
    java.awt.color.ColorSpace var13 = var11.getColorSpace();
    float[] var17 = new float[] { 0.0f, 10.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var18 = var3.getComponents(var13, var17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var2 = var1.getCategoryLabelPositionOffset();
    var1.setVisible(true);
    java.lang.Object var5 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var4.handleClick(1900, 1, var12);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     java.awt.image.BufferedImage var13 = var3.createBufferedImage(3, 4, 10, var11);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.ChartRenderingInfo var3 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var4 = var3.getChartArea();
//     java.awt.Point var5 = var0.translateValueThetaRadiusToJava2D(4.0d, 100.0d, var4);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var5, var6, var7);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     java.awt.geom.Point2D var12 = null;
//     var8.zoomDomainAxes((-1.0d), 0.2d, var11, var12);
//     org.jfree.chart.util.SortOrder var14 = var8.getRowRenderingOrder();
//     java.awt.Paint var15 = var8.getRangeGridlinePaint();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var20, var21, var22);
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var25 = var24.getLabelOutlinePaint();
//     var23.setRangeCrosshairPaint(var25);
//     int var27 = var23.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var28 = new org.jfree.chart.axis.AxisSpace();
//     var23.setFixedRangeAxisSpace(var28);
//     org.jfree.chart.axis.AxisSpace var30 = new org.jfree.chart.axis.AxisSpace();
//     var23.setFixedRangeAxisSpace(var30);
//     var23.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var35 = null;
//     var34.setLabelOutlinePaint(var35);
//     java.awt.Stroke var37 = var34.getLabelOutlineStroke();
//     java.awt.Paint var38 = var34.getLabelPaint();
//     org.jfree.data.general.WaferMapDataset var39 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var40 = null;
//     org.jfree.chart.plot.WaferMapPlot var41 = new org.jfree.chart.plot.WaferMapPlot(var39, var40);
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var41);
//     java.awt.Stroke var43 = var41.getOutlineStroke();
//     var34.setBaseSectionOutlineStroke(var43);
//     var23.setDomainGridlineStroke(var43);
//     java.awt.Color var50 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var51 = java.awt.Color.getColor("black", var50);
//     org.jfree.data.general.WaferMapDataset var52 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var53 = null;
//     org.jfree.chart.plot.WaferMapPlot var54 = new org.jfree.chart.plot.WaferMapPlot(var52, var53);
//     org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var54);
//     java.awt.Stroke var56 = var54.getOutlineStroke();
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker((-10.0d), var15, var43, (java.awt.Paint)var51, var56, 0.5f);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var54
//     assertTrue("Contract failed: equals-hashcode on var41 and var54", var41.equals(var54) ? var41.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var41
//     assertTrue("Contract failed: equals-hashcode on var54 and var41", var54.equals(var41) ? var54.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var55
//     assertTrue("Contract failed: equals-hashcode on var42 and var55", var42.equals(var55) ? var42.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var42
//     assertTrue("Contract failed: equals-hashcode on var55 and var42", var55.equals(var42) ? var55.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.getString("black");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    var7.setDrawSharedDomainAxis(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var0.getMaxRegularValue(0, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     boolean var3 = var0.getItemShapeVisible(0, 10);
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var4, var5);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     var7.setTitle("ThreadContext");
//     java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var14 = var13.darker();
//     var7.setBorderPaint((java.awt.Paint)var14);
//     boolean var16 = var0.equals((java.lang.Object)var7);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var19 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var20 = var19.clone();
//     java.awt.Paint var21 = var19.getBasePaint();
//     boolean var22 = var19.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var25 = var19.getURLGenerator(100, 4);
//     java.awt.Font var27 = null;
//     var19.setSeriesItemLabelFont(0, var27, true);
//     java.awt.Font var30 = var19.getBaseItemLabelFont();
//     java.awt.Color var34 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, (java.awt.Paint)var34);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var42 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var43 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var44 = var43.clone();
//     java.awt.Paint var45 = var43.getBasePaint();
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var42, var45);
//     var36.setSeriesOutlinePaint(0, var45, true);
//     org.jfree.chart.text.TextMeasurer var50 = null;
//     org.jfree.chart.text.TextBlock var51 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, var45, 0.0f, var50);
//     boolean var52 = var7.equals((java.lang.Object)var45);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var36.", var0.equals(var36) == var36.equals(var0));
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, var6, var7, var8);
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var11 = var10.getLabelOutlinePaint();
//     var9.setRangeCrosshairPaint(var11);
//     int var13 = var9.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var9.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.axis.AxisSpace var16 = new org.jfree.chart.axis.AxisSpace();
//     var9.setFixedRangeAxisSpace(var16);
//     java.lang.String var18 = var9.getPlotType();
//     java.awt.Paint var19 = var9.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var22 = var21.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = null;
//     var23.setLabelOutlinePaint(var24);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var32 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var34 = var33.clone();
//     java.awt.Paint var35 = var33.getBasePaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
//     var26.setSeriesOutlinePaint(0, var35, true);
//     var23.setBackgroundPaint(var35);
//     java.awt.Stroke var40 = null;
//     org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var19, var22, var35, var40, 0.0f);
//     org.jfree.data.general.WaferMapDataset var43 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var44 = null;
//     org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
//     java.awt.Image var47 = null;
//     var46.setBackgroundImage(var47);
//     var46.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var50 = var46.getPadding();
//     var42.setLabelOffset(var50);
//     java.lang.Object var52 = var42.clone();
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var54 = null;
//     var53.setLabelOutlinePaint(var54);
//     java.awt.Stroke var56 = var53.getLabelOutlineStroke();
//     java.awt.Paint var57 = var53.getLabelPaint();
//     org.jfree.data.general.WaferMapDataset var58 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var59 = null;
//     org.jfree.chart.plot.WaferMapPlot var60 = new org.jfree.chart.plot.WaferMapPlot(var58, var59);
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var60);
//     java.awt.Stroke var62 = var60.getOutlineStroke();
//     var53.setBaseSectionOutlineStroke(var62);
//     var42.setOutlineStroke(var62);
//     
//     // Checks the contract:  equals-hashcode on var45 and var60
//     assertTrue("Contract failed: equals-hashcode on var45 and var60", var45.equals(var60) ? var45.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var45
//     assertTrue("Contract failed: equals-hashcode on var60 and var45", var60.equals(var45) ? var60.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var61
//     assertTrue("Contract failed: equals-hashcode on var46 and var61", var46.equals(var61) ? var46.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var46
//     assertTrue("Contract failed: equals-hashcode on var61 and var46", var61.equals(var46) ? var61.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var10, var11, var12);
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var15 = var14.getLabelOutlinePaint();
//     var13.setRangeCrosshairPaint(var15);
//     var5.setDomainTickBandPaint(var15);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var21 = var18.isItemLabelVisible(1, 0);
//     org.jfree.data.general.WaferMapDataset var23 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var24 = null;
//     org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
//     java.awt.Stroke var27 = var26.getBorderStroke();
//     var18.setSeriesStroke(100, var27, true);
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d, var15, var27);
//     org.jfree.chart.util.LengthAdjustmentType var31 = var30.getLabelOffsetType();
//     org.jfree.chart.event.MarkerChangeListener var32 = null;
//     var30.addChangeListener(var32);
//     org.jfree.chart.util.RectangleInsets var34 = var30.getLabelOffset();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var35 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var36 = var35.clone();
//     java.awt.Paint var37 = var35.getBasePaint();
//     boolean var38 = var35.getBaseSeriesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var41 = var40.getCategoryLabelPositionOffset();
//     java.awt.Paint var42 = var40.getAxisLinePaint();
//     java.awt.Stroke var43 = var40.getTickMarkStroke();
//     var35.setBaseStroke(var43, true);
//     var30.setOutlineStroke(var43);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var18.", var35.equals(var18) == var18.equals(var35));
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("ThreadContext", "hi!", "hi!", "");
    java.lang.String var5 = var4.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "ThreadContext"+ "'", var5.equals("ThreadContext"));

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var1 = var0.getObjectIcon();
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var3 = var2.getObjectIcon();
//     var0.setMaxIcon(var3);
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var9 = var8.getLabel();
//     org.jfree.data.KeyedObject var10 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var8);
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var13 = var12.getLabelInsets();
//     double var15 = var13.calculateTopInset(100.0d);
//     var8.setTickLabelInsets(var13);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLabelInsets();
//     double var23 = var21.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var24 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var25 = var24.getChartArea();
//     java.awt.geom.Rectangle2D var28 = var21.createInsetRectangle(var25, true, false);
//     java.lang.Object var30 = var17.draw(var18, var25, (java.lang.Object)"WMAP_Plot");
//     org.jfree.chart.entity.AxisLabelEntity var33 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var8, (java.awt.Shape)var25, "XY Plot", "WMAP_Plot");
//     var0.setSeriesShape(1900, (java.awt.Shape)var25);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var0.", var2.equals(var0) == var0.equals(var2));
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var3 = var0.isItemLabelVisible(1, 0);
//     double var4 = var0.getBase();
//     boolean var5 = var0.getAutoPopulateSeriesOutlineStroke();
//     java.awt.Paint var7 = null;
//     var0.setSeriesPaint(4, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var10, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var14, var15, var16);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var25 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var25, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var25, var29, var30, var31);
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var34 = var33.getLabelOutlinePaint();
//     var32.setRangeCrosshairPaint(var34);
//     var24.setDomainTickBandPaint(var34);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var37 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var40 = var37.isItemLabelVisible(1, 0);
//     org.jfree.data.general.WaferMapDataset var42 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var43 = null;
//     org.jfree.chart.plot.WaferMapPlot var44 = new org.jfree.chart.plot.WaferMapPlot(var42, var43);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var44);
//     java.awt.Stroke var46 = var45.getBorderStroke();
//     var37.setSeriesStroke(100, var46, true);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(0.0d, var34, var46);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var54 = var53.getLabelInsets();
//     double var56 = var54.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var57 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var58 = var57.getChartArea();
//     java.awt.geom.Rectangle2D var61 = var54.createInsetRectangle(var58, true, false);
//     java.lang.Object var63 = var50.draw(var51, var58, (java.lang.Object)"WMAP_Plot");
//     var0.drawRangeMarker(var9, var17, var18, (org.jfree.chart.plot.Marker)var49, var58);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var5 = var4.getLabelInsets();
//     double var7 = var5.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var8 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var9 = var8.getChartArea();
//     java.awt.geom.Rectangle2D var12 = var5.createInsetRectangle(var9, true, false);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelInsets();
//     double var19 = var17.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     java.awt.geom.Rectangle2D var24 = var17.createInsetRectangle(var21, true, false);
//     java.lang.Object var26 = var13.draw(var14, var21, (java.lang.Object)"WMAP_Plot");
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Point2D var35 = null;
//     var31.zoomDomainAxes((-1.0d), 0.2d, var34, var35);
//     java.awt.Paint var37 = var31.getRangeCrosshairPaint();
//     double var38 = var31.getDomainCrosshairValue();
//     var31.setRangeZeroBaselineVisible(true);
//     java.awt.Stroke var41 = var31.getRangeGridlineStroke();
//     java.lang.String var42 = var31.getPlotType();
//     org.jfree.chart.util.RectangleEdge var43 = var31.getDomainAxisEdge();
//     org.jfree.chart.ChartRenderingInfo var44 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var45 = var44.getChartArea();
//     java.lang.Object var46 = var44.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = new org.jfree.chart.plot.PlotRenderingInfo(var44);
//     org.jfree.chart.axis.AxisState var48 = var0.draw(var1, 1.0d, var9, var21, var43, var47);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    var3.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var7 = var3.getPadding();
    double var9 = var7.calculateLeftOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var3 = null;
//     var2.setLabelOutlinePaint(var3);
//     java.awt.Stroke var5 = var2.getLabelOutlineStroke();
//     var1.setOutlineStroke(var5);
//     double var7 = var1.getLimit();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var8);
//     double var10 = var9.getLimit();
//     org.jfree.data.category.CategoryDataset var11 = var9.getDataset();
//     org.jfree.chart.util.TableOrder var12 = var9.getDataExtractOrder();
//     var1.setDataExtractOrder(var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = null;
    var2.setLabelOutlinePaint(var3);
    java.awt.Stroke var5 = var2.getLabelOutlineStroke();
    var1.setOutlineStroke(var5);
    double var7 = var1.getLimit();
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAggregatedItemsKey(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     var11.setHeight(0.0d);
//     var11.setMargin(10.0d, 2.0d, 0.2d, (-10.0d));
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var21 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var21, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var21, var25, var26, var27);
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var30 = var29.getLabelOutlinePaint();
//     var28.setRangeCrosshairPaint(var30);
//     int var32 = var28.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var33 = new org.jfree.chart.axis.AxisSpace();
//     var28.setFixedRangeAxisSpace(var33);
//     org.jfree.chart.axis.AxisSpace var35 = new org.jfree.chart.axis.AxisSpace();
//     var28.setFixedRangeAxisSpace(var35);
//     java.lang.String var37 = var28.getPlotType();
//     java.awt.Paint var38 = var28.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var41 = var40.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var43 = null;
//     var42.setLabelOutlinePaint(var43);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var51 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var52 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var53 = var52.clone();
//     java.awt.Paint var54 = var52.getBasePaint();
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var51, var54);
//     var45.setSeriesOutlinePaint(0, var54, true);
//     var42.setBackgroundPaint(var54);
//     java.awt.Stroke var59 = null;
//     org.jfree.chart.plot.IntervalMarker var61 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var38, var41, var54, var59, 0.0f);
//     org.jfree.data.general.WaferMapDataset var62 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var63 = null;
//     org.jfree.chart.plot.WaferMapPlot var64 = new org.jfree.chart.plot.WaferMapPlot(var62, var63);
//     org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var64);
//     java.awt.Image var66 = null;
//     var65.setBackgroundImage(var66);
//     var65.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var69 = var65.getPadding();
//     var61.setLabelOffset(var69);
//     java.lang.Object var71 = var61.clone();
//     org.jfree.chart.util.RectangleInsets var72 = var61.getLabelOffset();
//     org.jfree.chart.util.RectangleAnchor var73 = var61.getLabelAnchor();
//     var11.setLegendItemGraphicLocation(var73);
//     
//     // Checks the contract:  equals-hashcode on var2 and var64
//     assertTrue("Contract failed: equals-hashcode on var2 and var64", var2.equals(var64) ? var2.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var2
//     assertTrue("Contract failed: equals-hashcode on var64 and var2", var64.equals(var2) ? var64.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     var11.setMargin(10.0d, 0.2d, 1.0E-5d, (-1.0d));
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var19 = null;
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
//     org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var20);
//     java.awt.Image var22 = null;
//     var21.setBackgroundImage(var22);
//     org.jfree.chart.title.TextTitle var24 = null;
//     var21.setTitle(var24);
//     var21.setAntiAlias(false);
//     float var28 = var21.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var29 = var21.getLegend();
//     var29.setHeight(0.0d);
//     org.jfree.chart.util.RectangleAnchor var32 = var29.getLegendItemGraphicLocation();
//     var11.setLegendItemGraphicAnchor(var32);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLineAlignment(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     var3.fireChartChanged();
//     var3.removeLegend();
//     var3.setBorderVisible(false);
//     org.jfree.data.general.WaferMapDataset var10 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var11 = null;
//     org.jfree.chart.plot.WaferMapPlot var12 = new org.jfree.chart.plot.WaferMapPlot(var10, var11);
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     var13.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var17 = var13.getPadding();
//     double var19 = var17.trimWidth(0.2d);
//     var3.setPadding(var17);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     double var1 = var0.getUpperClip();
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
//     java.awt.Stroke var6 = var5.getBorderStroke();
//     var0.setBaseOutlineStroke(var6);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var0.getPositiveItemLabelPositionFallback();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var11 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var10);
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var14 = var13.getLabelInsets();
//     double var16 = var14.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var18 = var17.getChartArea();
//     java.awt.geom.Rectangle2D var21 = var14.createInsetRectangle(var18, true, false);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var22 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var22, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, var26, var27, var28);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var30 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var30, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var30, var34, var35, var36);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var38 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var38, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var38, var42, var43, var44);
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var47 = var46.getLabelOutlinePaint();
//     var45.setRangeCrosshairPaint(var47);
//     boolean var49 = var45.isRangeCrosshairVisible();
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
//     var51.setUpperMargin(0.0d);
//     var51.setInverted(true);
//     boolean var56 = var51.isVerticalTickLabels();
//     var51.configure();
//     var45.setRangeAxis((org.jfree.chart.axis.ValueAxis)var51);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var59 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var61 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var59, (java.lang.Comparable)'a');
//     org.jfree.data.Range var63 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var59, true);
//     java.text.DateFormat var66 = null;
//     org.jfree.chart.axis.DateTickUnit var67 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var66);
//     java.lang.String var69 = var67.valueToString(1.0d);
//     java.lang.String var71 = var67.valueToString(1.0d);
//     java.lang.Number var73 = var59.getMinRegularValue((java.lang.Comparable)var71, (java.lang.Comparable)0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.drawItem(var9, var11, var18, var29, var34, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.data.category.CategoryDataset)var59, 0, 4, 4);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 3.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var69 + "' != '" + "12/31/69"+ "'", var69.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var71 + "' != '" + "12/31/69"+ "'", var71.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
// 
//   }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.axis.CategoryAxis[] var14 = null;
//     var7.setDomainAxes(var14);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelInsets();
    double var6 = var4.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var8 = var7.getChartArea();
    java.awt.geom.Rectangle2D var11 = var4.createInsetRectangle(var8, true, false);
    java.lang.Object var13 = var0.draw(var1, var8, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.util.RectangleInsets var14 = var0.getMargin();
    double var16 = var14.calculateBottomInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var4.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition((-1));
//     var4.setBasePositiveItemLabelPosition(var9, true);
//     org.jfree.chart.text.TextAnchor var12 = var9.getTextAnchor();
//     boolean var14 = var12.equals((java.lang.Object)"hi!");
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var16 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var16.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var19 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var21 = var19.getSeriesNegativeItemLabelPosition((-1));
//     var16.setBasePositiveItemLabelPosition(var21, true);
//     org.jfree.chart.text.TextAnchor var24 = var21.getTextAnchor();
//     boolean var26 = var24.equals((java.lang.Object)"hi!");
//     java.lang.Object var27 = null;
//     boolean var28 = var24.equals(var27);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, (-1.0f), var12, 2.0d, var24);
//     
//     // Checks the contract:  equals-hashcode on var9 and var21
//     assertTrue("Contract failed: equals-hashcode on var9 and var21", var9.equals(var21) ? var9.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var9
//     assertTrue("Contract failed: equals-hashcode on var21 and var9", var21.equals(var9) ? var21.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var4 = var3.getLength();
//     double var5 = var3.getLength();
//     org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0E-5d, var3);
//     org.jfree.chart.util.Size2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var6.calculateConstrainedSize(var7);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.renderer.category.LevelRenderer var0 = new org.jfree.chart.renderer.category.LevelRenderer();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var2.setSeriesItemLabelGenerator(1900, var4);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getBasePositiveItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-1), var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    var3.setTitle("ThreadContext");
    java.awt.Color var9 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var10 = var9.darker();
    var3.setBorderPaint((java.awt.Paint)var10);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
    double var18 = var16.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var20 = var19.getChartArea();
    java.awt.geom.Rectangle2D var23 = var16.createInsetRectangle(var20, true, false);
    java.lang.Object var25 = var12.draw(var13, var20, (java.lang.Object)"WMAP_Plot");
    var3.addSubtitle((org.jfree.chart.title.Title)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var27 = var3.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.util.RectangleInsets var3 = var1.getTickLabelInsets();
    double var5 = var3.extendWidth(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 8.05d);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = null;
    var2.setLabelOutlinePaint(var3);
    java.awt.Stroke var5 = var2.getLabelOutlineStroke();
    var1.setOutlineStroke(var5);
    java.awt.Paint var7 = var1.getAggregatedItemsPaint();
    org.jfree.chart.JFreeChart var8 = var1.getPieChart();
    org.jfree.chart.event.ChartChangeListener var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.removeChangeListener(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, var6, var7, var8);
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var11 = var10.getLabelOutlinePaint();
//     var9.setRangeCrosshairPaint(var11);
//     int var13 = var9.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var9.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.axis.AxisSpace var16 = new org.jfree.chart.axis.AxisSpace();
//     var9.setFixedRangeAxisSpace(var16);
//     java.lang.String var18 = var9.getPlotType();
//     java.awt.Paint var19 = var9.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var22 = var21.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = null;
//     var23.setLabelOutlinePaint(var24);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var32 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var34 = var33.clone();
//     java.awt.Paint var35 = var33.getBasePaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
//     var26.setSeriesOutlinePaint(0, var35, true);
//     var23.setBackgroundPaint(var35);
//     java.awt.Stroke var40 = null;
//     org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var19, var22, var35, var40, 0.0f);
//     org.jfree.data.general.WaferMapDataset var43 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var44 = null;
//     org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
//     java.awt.Image var47 = null;
//     var46.setBackgroundImage(var47);
//     var46.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var50 = var46.getPadding();
//     var42.setLabelOffset(var50);
//     java.lang.Object var52 = var42.clone();
//     java.lang.Class var53 = null;
//     java.util.EventListener[] var54 = var42.getListeners(var53);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    java.awt.Stroke var3 = var0.getLabelOutlineStroke();
    java.awt.Paint var4 = var0.getNoDataMessagePaint();
    boolean var5 = var0.getIgnoreNullValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setBottom(0.0d);
    var0.setBottom(2.0d);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
//     double var4 = var2.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var5 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var6 = var5.getChartArea();
//     java.awt.geom.Rectangle2D var9 = var2.createInsetRectangle(var6, true, false);
//     java.lang.String var10 = var2.toString();
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var15 = var14.getLabelInsets();
//     double var17 = var15.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var19 = var18.getChartArea();
//     java.awt.geom.Rectangle2D var22 = var15.createInsetRectangle(var19, true, false);
//     java.lang.Object var24 = var11.draw(var12, var19, (java.lang.Object)"WMAP_Plot");
//     org.jfree.chart.util.LengthAdjustmentType var25 = null;
//     org.jfree.chart.util.LengthAdjustmentType var26 = null;
//     java.awt.geom.Rectangle2D var27 = var2.createAdjustedRectangle(var19, var25, var26);
//     
//     // Checks the contract:  equals-hashcode on var5 and var18
//     assertTrue("Contract failed: equals-hashcode on var5 and var18", var5.equals(var18) ? var5.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var5
//     assertTrue("Contract failed: equals-hashcode on var18 and var5", var18.equals(var5) ? var18.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("black", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)10.0d);
//     boolean var23 = var20.getLabelLinksVisible();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", var14, (org.jfree.chart.plot.Plot)var20, false);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var30, var31, var32);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var41.getRangeMarkers(0, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.data.Range var46 = var41.getDataRange(var45);
//     org.jfree.chart.axis.AxisSpace var47 = null;
//     var41.setFixedDomainAxisSpace(var47);
//     java.awt.Paint var49 = null;
//     var41.setRangeTickBandPaint(var49);
//     java.awt.geom.Point2D var51 = var41.getQuadrantOrigin();
//     var33.zoomRangeAxes(10.0d, 0.0d, var36, var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var33, false);
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
//     org.jfree.chart.util.Layer var61 = null;
//     java.util.Collection var62 = var59.getRangeMarkers(0, var61);
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     java.awt.geom.Point2D var66 = null;
//     var59.zoomDomainAxes(2.0d, 1.0d, var65, var66);
//     org.jfree.data.xy.XYDataset var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot(var68, var69, var70, var71);
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     java.awt.geom.Point2D var76 = null;
//     var72.zoomDomainAxes((-1.0d), 0.2d, var75, var76);
//     java.awt.Paint var78 = var72.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var80 = var72.getRangeAxisLocation(1);
//     java.lang.Object var81 = null;
//     boolean var82 = var80.equals(var81);
//     var59.setDomainAxisLocation(var80);
//     var33.setDomainAxisLocation(var80);
//     
//     // Checks the contract:  equals-hashcode on var41 and var72
//     assertTrue("Contract failed: equals-hashcode on var41 and var72", var41.equals(var72) ? var41.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var41
//     assertTrue("Contract failed: equals-hashcode on var72 and var41", var72.equals(var41) ? var72.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     boolean var11 = var7.isRangeCrosshairVisible();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
//     var13.setUpperMargin(0.0d);
//     var13.setInverted(true);
//     boolean var18 = var13.isVerticalTickLabels();
//     var13.configure();
//     var7.setRangeAxis((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var26 = var25.getLabelInsets();
//     double var28 = var26.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var30 = var29.getChartArea();
//     java.awt.geom.Rectangle2D var33 = var26.createInsetRectangle(var30, true, false);
//     java.lang.Object var35 = var22.draw(var23, var30, (java.lang.Object)"WMAP_Plot");
//     org.jfree.data.general.WaferMapDataset var36 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var37 = null;
//     org.jfree.chart.plot.WaferMapPlot var38 = new org.jfree.chart.plot.WaferMapPlot(var36, var37);
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
//     java.awt.Image var40 = null;
//     var39.setBackgroundImage(var40);
//     org.jfree.chart.title.TextTitle var42 = null;
//     var39.setTitle(var42);
//     var39.setAntiAlias(false);
//     float var46 = var39.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var47 = var39.getLegend();
//     java.awt.Paint var48 = var47.getBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
//     var47.setFrame((org.jfree.chart.block.BlockFrame)var53);
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var55 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var56 = var55.getObjectIcon();
//     boolean var57 = var55.isDrawLines();
//     org.jfree.chart.LegendItemSource[] var58 = new org.jfree.chart.LegendItemSource[] { var55};
//     var47.setSources(var58);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var60 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var62 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var60, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var66 = null;
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var60, var64, var65, var66);
//     org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var69 = var68.getLabelOutlinePaint();
//     var67.setRangeCrosshairPaint(var69);
//     int var71 = var67.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var72 = new org.jfree.chart.axis.AxisSpace();
//     var67.setFixedRangeAxisSpace(var72);
//     org.jfree.chart.axis.AxisSpace var74 = new org.jfree.chart.axis.AxisSpace();
//     var67.setFixedRangeAxisSpace(var74);
//     org.jfree.chart.axis.CategoryAxis var77 = var67.getDomainAxisForDataset(0);
//     org.jfree.chart.util.RectangleEdge var78 = var67.getDomainAxisEdge();
//     var47.setLegendItemGraphicEdge(var78);
//     double var80 = var13.java2DToValue(0.0d, var30, var78);
//     
//     // Checks the contract:  equals-hashcode on var0 and var60
//     assertTrue("Contract failed: equals-hashcode on var0 and var60", var0.equals(var60) ? var0.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var0
//     assertTrue("Contract failed: equals-hashcode on var60 and var0", var60.equals(var0) ? var60.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var68
//     assertTrue("Contract failed: equals-hashcode on var8 and var68", var8.equals(var68) ? var8.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var8
//     assertTrue("Contract failed: equals-hashcode on var68 and var8", var68.equals(var8) ? var68.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var7 = var4.isOnOrBefore((org.jfree.data.time.SerialDate)var6);
    boolean var8 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    int var9 = var0.getIndex((java.lang.Comparable)var8);
    int var10 = var0.getItemCount();
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var17 = var14.isOnOrBefore((org.jfree.data.time.SerialDate)var16);
    boolean var18 = var12.isOnOrAfter((org.jfree.data.time.SerialDate)var16);
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    int var21 = var20.getYYYY();
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var28 = var25.isOnOrBefore((org.jfree.data.time.SerialDate)var27);
    boolean var29 = var23.isOnOrAfter((org.jfree.data.time.SerialDate)var27);
    boolean var30 = var12.isInRange((org.jfree.data.time.SerialDate)var20, (org.jfree.data.time.SerialDate)var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var31 = var0.getValue((java.lang.Comparable)var12);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getMargin();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.setTitle("ThreadContext");
    java.awt.Color var11 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var12 = var11.darker();
    var5.setBorderPaint((java.awt.Paint)var12);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var18 = var17.getLabelInsets();
    double var20 = var18.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var21 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var22 = var21.getChartArea();
    java.awt.geom.Rectangle2D var25 = var18.createInsetRectangle(var22, true, false);
    java.lang.Object var27 = var14.draw(var15, var22, (java.lang.Object)"WMAP_Plot");
    var5.addSubtitle((org.jfree.chart.title.Title)var14);
    var0.add((org.jfree.chart.block.Block)var14);
    var14.setWidth(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var4 = var3.getDataset();
    java.awt.Stroke var5 = var3.getAngleGridlineStroke();
    var0.setBaseOutlineStroke(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var5 = var4.getLabelOutlinePaint();
//     var2.setBackgroundPaint(var5);
//     org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var7 = var4.isOnOrBefore((org.jfree.data.time.SerialDate)var6);
    boolean var8 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    int var9 = var0.getIndex((java.lang.Comparable)var8);
    int var10 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var0.getValue((java.lang.Comparable)4);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    var3.setTitle("ThreadContext");
    java.awt.Color var9 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var10 = var9.darker();
    var3.setBorderPaint((java.awt.Paint)var10);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
    double var18 = var16.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var20 = var19.getChartArea();
    java.awt.geom.Rectangle2D var23 = var16.createInsetRectangle(var20, true, false);
    java.lang.Object var25 = var12.draw(var13, var20, (java.lang.Object)"WMAP_Plot");
    var3.addSubtitle((org.jfree.chart.title.Title)var12);
    var3.fireChartChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = var0.getDataset();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var6 = var5.getLabelInsets();
//     double var8 = var6.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var10 = var9.getChartArea();
//     java.awt.geom.Rectangle2D var13 = var6.createInsetRectangle(var10, true, false);
//     java.awt.geom.Point2D var14 = null;
//     org.jfree.chart.plot.PlotState var15 = new org.jfree.chart.plot.PlotState();
//     java.util.Map var16 = var15.getSharedAxisStates();
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     var0.draw(var3, var13, var14, var15, var17);
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     java.lang.Object var22 = var20.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var24 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, var28, var29, var30);
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var33 = var32.getLabelOutlinePaint();
//     var31.setRangeCrosshairPaint(var33);
//     boolean var35 = var31.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.util.Layer var45 = null;
//     java.util.Collection var46 = var43.getRangeMarkers(0, var45);
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.data.Range var48 = var43.getDataRange(var47);
//     org.jfree.chart.axis.AxisSpace var49 = null;
//     var43.setFixedDomainAxisSpace(var49);
//     java.awt.Paint var51 = null;
//     var43.setRangeTickBandPaint(var51);
//     java.awt.geom.Point2D var53 = var43.getQuadrantOrigin();
//     var31.zoomRangeAxes(1.0E-5d, 1.0E-5d, var38, var53);
//     var0.zoomRangeAxes((-1.0d), var23, var53);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var8 = var5.isOnOrBefore((org.jfree.data.time.SerialDate)var7);
//     boolean var9 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var12 = var11.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     boolean var20 = var14.isOnOrAfter((org.jfree.data.time.SerialDate)var18);
//     boolean var21 = var3.isInRange((org.jfree.data.time.SerialDate)var11, (org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var3);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addYears(1, (org.jfree.data.time.SerialDate)var3);
//     org.jfree.data.time.SerialDate var24 = null;
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var29 = var26.isOnOrBefore((org.jfree.data.time.SerialDate)var28);
//     boolean var30 = var3.isInRange(var24, (org.jfree.data.time.SerialDate)var26);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var7 = var4.isOnOrBefore((org.jfree.data.time.SerialDate)var6);
    boolean var8 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    int var9 = var0.getIndex((java.lang.Comparable)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.plot.Plot var4 = var3.getPlot();
//     java.util.List var5 = null;
//     var3.setSubtitles(var5);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    org.jfree.chart.event.RendererChangeEvent var13 = null;
    var7.rendererChanged(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    double var11 = var4.getDomainCrosshairValue();
    var4.setRangeZeroBaselineVisible(true);
    java.awt.Stroke var14 = var4.getRangeGridlineStroke();
    java.lang.String var15 = var4.getPlotType();
    org.jfree.chart.util.RectangleEdge var16 = var4.getDomainAxisEdge();
    var4.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "XY Plot"+ "'", var15.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = var0.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     java.awt.Color var6 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var7 = var6.darker();
//     boolean var8 = var2.equals((java.lang.Object)var6);
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var10 = var9.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var11 = var9.getLegendItems();
//     java.awt.Color var15 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var16 = var15.darker();
//     boolean var17 = var11.equals((java.lang.Object)var15);
//     java.awt.Shape var22 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var23 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var24 = var23.clone();
//     java.awt.Paint var25 = var23.getBasePaint();
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var22, var25);
//     java.awt.Stroke var27 = var26.getOutlineStroke();
//     var11.add(var26);
//     var2.add(var26);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var7 = var6.clone();
//     java.awt.Paint var8 = var6.getBasePaint();
//     boolean var9 = var6.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var6.getURLGenerator(100, 4);
//     java.awt.Font var14 = null;
//     var6.setSeriesItemLabelFont(0, var14, true);
//     java.awt.Font var17 = var6.getBaseItemLabelFont();
//     java.awt.Color var21 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var29 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var30 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var31 = var30.clone();
//     java.awt.Paint var32 = var30.getBasePaint();
//     org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var29, var32);
//     var23.setSeriesOutlinePaint(0, var32, true);
//     org.jfree.chart.text.TextMeasurer var37 = null;
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var32, 0.0f, var37);
//     org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var40 = null;
//     var39.setLabelOutlinePaint(var40);
//     java.awt.Stroke var42 = var39.getLabelOutlineStroke();
//     java.awt.Paint var43 = var39.getLabelPaint();
//     org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine("", var17, var43);
//     org.jfree.chart.text.TextFragment var45 = var44.getFirstTextFragment();
//     float var46 = var45.getBaselineOffset();
//     java.awt.Paint var47 = var45.getPaint();
//     var2.setWallPaint(var47);
//     java.lang.Object var49 = var2.clone();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var50 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var51 = var50.clone();
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var58 = var55.isOnOrBefore((org.jfree.data.time.SerialDate)var57);
//     boolean var59 = var53.isOnOrAfter((org.jfree.data.time.SerialDate)var57);
//     org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var62 = var61.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var66 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var69 = var66.isOnOrBefore((org.jfree.data.time.SerialDate)var68);
//     boolean var70 = var64.isOnOrAfter((org.jfree.data.time.SerialDate)var68);
//     boolean var71 = var53.isInRange((org.jfree.data.time.SerialDate)var61, (org.jfree.data.time.SerialDate)var68);
//     boolean var72 = var50.equals((java.lang.Object)var61);
//     org.jfree.chart.block.BlockBorder var78 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
//     java.awt.Paint var79 = var78.getPaint();
//     var50.setSeriesOutlinePaint(0, var79);
//     var2.setBasePaint(var79, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var50.", var6.equals(var50) == var50.equals(var6));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var30 and var50.", var30.equals(var50) == var50.equals(var30));
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var1 = var0.getWidthType();
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, var3);
    org.jfree.chart.block.RectangleConstraint var6 = var4.toFixedWidth(12.0d);
    boolean var7 = var1.equals((java.lang.Object)var6);
    java.lang.String var8 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "CategoryLabelWidthType.CATEGORY"+ "'", var8.equals("CategoryLabelWidthType.CATEGORY"));

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    java.awt.Paint var12 = null;
    var4.setRangeTickBandPaint(var12);
    java.awt.geom.Point2D var14 = var4.getQuadrantOrigin();
    java.io.ObjectOutputStream var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = var0.getChartArea();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = var0.getPlotInfo();
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     var7.setRenderer(var8, true);
//     org.jfree.chart.plot.Marker var11 = null;
//     var7.addRangeMarker(var11);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    java.awt.Paint var3 = var1.getBasePaint();
    boolean var4 = var1.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var7 = var1.getURLGenerator(100, 4);
    java.awt.Font var9 = null;
    var1.setSeriesItemLabelFont(0, var9, true);
    java.awt.Font var12 = var1.getBaseItemLabelFont();
    java.awt.Color var16 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var16);
    org.jfree.chart.text.TextLine var18 = var17.getLastLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.data.Range var9 = var4.getDataRange(var8);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var4.setFixedDomainAxisSpace(var10);
//     java.util.List var12 = var4.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var15 = var14.getNumberFormatOverride();
//     org.jfree.data.Range var18 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
//     var14.setRangeWithMargins((org.jfree.data.Range)var19);
//     org.jfree.data.Range var23 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange(var23);
//     var14.setDefaultAutoRange(var23);
//     java.awt.Paint var26 = var14.getTickLabelPaint();
//     boolean var27 = var14.getAutoRangeIncludesZero();
//     java.lang.Object var28 = var14.clone();
//     int var29 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var33 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var34 = var33.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var41 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var42 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var43 = var42.clone();
//     java.awt.Paint var44 = var42.getBasePaint();
//     org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var41, var44);
//     var35.setSeriesOutlinePaint(0, var44, true);
//     boolean var48 = var33.equals((java.lang.Object)var44);
//     org.jfree.chart.plot.PiePlot var50 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var51 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var52 = var51.getChartArea();
//     var50.setLegendItemShape((java.awt.Shape)var52);
//     var33.setSeriesShape(4, (java.awt.Shape)var52);
//     var4.drawBackground(var30, var52);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    var2.setBaseShapesVisible(false);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.05d, 0.5f, 10.0f);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(3, 100, 0, 1, var4);
//     org.jfree.data.Range var8 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var9 = new org.jfree.data.time.DateRange(var8);
//     java.util.Date var10 = var9.getLowerDate();
//     java.util.TimeZone var11 = null;
//     java.util.Date var12 = var5.addToDate(var10, var11);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     double var1 = var0.getItemMargin();
//     org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
//     var0.setItemMargin(1.0d);
//     double var7 = var0.getItemMargin();
//     var0.setBaseSeriesVisible(true);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var11);
//     org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var14 = var13.getDataset();
//     java.awt.Stroke var15 = var13.getAngleGridlineStroke();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var19 = var18.getLabelInsets();
//     double var21 = var19.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var22 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var23 = var22.getChartArea();
//     java.awt.geom.Rectangle2D var26 = var19.createInsetRectangle(var23, true, false);
//     java.awt.geom.Point2D var27 = null;
//     org.jfree.chart.plot.PlotState var28 = new org.jfree.chart.plot.PlotState();
//     java.util.Map var29 = var28.getSharedAxisStates();
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var13.draw(var16, var26, var27, var28, var30);
//     org.jfree.chart.plot.CategoryPlot var32 = null;
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var35 = var34.getTickMarkStroke();
//     java.lang.Object var36 = var34.clone();
//     var34.setMaximumCategoryLabelWidthRatio(0.5f);
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("");
//     var40.setUpperMargin(0.0d);
//     var40.setInverted(true);
//     boolean var45 = var40.isVerticalTickLabels();
//     var40.configure();
//     boolean var47 = var40.isTickLabelsVisible();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var48 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var50 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var48, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, var52, var53, var54);
//     java.lang.Number var58 = var48.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var62 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var65 = var62.isOnOrBefore((org.jfree.data.time.SerialDate)var64);
//     boolean var66 = var60.isOnOrAfter((org.jfree.data.time.SerialDate)var64);
//     org.jfree.data.time.SpreadsheetDate var70 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var72 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var74 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var75 = var72.isOnOrBefore((org.jfree.data.time.SerialDate)var74);
//     boolean var76 = var70.isOnOrAfter((org.jfree.data.time.SerialDate)var74);
//     org.jfree.data.time.SpreadsheetDate var78 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var79 = var78.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var81 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var83 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var85 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var86 = var83.isOnOrBefore((org.jfree.data.time.SerialDate)var85);
//     boolean var87 = var81.isOnOrAfter((org.jfree.data.time.SerialDate)var85);
//     boolean var88 = var70.isInRange((org.jfree.data.time.SerialDate)var78, (org.jfree.data.time.SerialDate)var85);
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var70);
//     org.jfree.data.time.SerialDate var90 = org.jfree.data.time.SerialDate.addYears(1, (org.jfree.data.time.SerialDate)var70);
//     java.lang.Number var91 = var48.getValue((java.lang.Comparable)var60, (java.lang.Comparable)var90);
//     var0.drawHorizontalItem(var10, var12, var26, var32, (org.jfree.chart.axis.CategoryAxis)var34, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.data.category.CategoryDataset)var48, 0, 0);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var5.getRangeMarkers(0, var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.data.Range var10 = var5.getDataRange(var9);
    org.jfree.chart.axis.AxisSpace var11 = null;
    var5.setFixedDomainAxisSpace(var11);
    boolean var13 = var5.isRangeCrosshairVisible();
    org.jfree.chart.plot.PlotOrientation var14 = var5.getOrientation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = null;
    var2.setLabelOutlinePaint(var3);
    java.awt.Stroke var5 = var2.getLabelOutlineStroke();
    var1.setOutlineStroke(var5);
    java.awt.Paint var7 = var1.getAggregatedItemsPaint();
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAggregatedItemsKey(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     boolean var4 = var3.getUseOutlinePaint();
//     boolean var6 = var3.isSeriesVisibleInLegend(1);
//     var3.setSeriesShapesFilled(0, false);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var12 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var13 = var12.getChartArea();
//     var11.setLegendItemShape((java.awt.Shape)var13);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var15 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var19, var20, var21);
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = var23.getLabelOutlinePaint();
//     var22.setRangeCrosshairPaint(var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var30.getRangeMarkers(0, var32);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var30.zoomDomainAxes(2.0d, 1.0d, var36, var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     java.awt.geom.Point2D var47 = null;
//     var43.zoomDomainAxes((-1.0d), 0.2d, var46, var47);
//     java.awt.Paint var49 = var43.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var51 = var43.getRangeAxisLocation(1);
//     java.lang.Object var52 = null;
//     boolean var53 = var51.equals(var52);
//     var30.setDomainAxisLocation(var51);
//     var22.setDomainAxisLocation(var51);
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var58 = var3.initialise(var10, var13, var22, 10, var57);
//     var0.draw(var2, var13);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     var0.setFillBox(false);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var7 = var6.getLabelInsets();
//     double var9 = var7.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var11 = var10.getChartArea();
//     java.awt.geom.Rectangle2D var14 = var7.createInsetRectangle(var11, true, false);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var15 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var19, var20, var21);
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = var23.getLabelOutlinePaint();
//     var22.setRangeCrosshairPaint(var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var30.getRangeMarkers(0, var32);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var30.zoomDomainAxes(2.0d, 1.0d, var36, var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     java.awt.geom.Point2D var47 = null;
//     var43.zoomDomainAxes((-1.0d), 0.2d, var46, var47);
//     java.awt.Paint var49 = var43.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var51 = var43.getRangeAxisLocation(1);
//     java.lang.Object var52 = null;
//     boolean var53 = var51.equals(var52);
//     var30.setDomainAxisLocation(var51);
//     var22.setDomainAxisLocation(var51);
//     org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var58 = var57.getTickMarkStroke();
//     java.lang.Object var59 = var57.clone();
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     org.jfree.chart.util.Layer var66 = null;
//     java.util.Collection var67 = var64.getRangeMarkers(0, var66);
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.data.Range var69 = var64.getDataRange(var68);
//     org.jfree.chart.axis.AxisSpace var70 = null;
//     var64.setFixedDomainAxisSpace(var70);
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var74 = var73.getNumberFormatOverride();
//     org.jfree.data.Range var77 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var78 = new org.jfree.data.time.DateRange(var77);
//     var73.setRangeWithMargins((org.jfree.data.Range)var78);
//     org.jfree.data.Range var82 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var83 = new org.jfree.data.time.DateRange(var82);
//     var73.setDefaultAutoRange(var82);
//     int var85 = var64.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var73);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var86 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var87 = var86.clone();
//     java.awt.Paint var88 = var86.getBasePaint();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var89 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.plot.MultiplePiePlot var90 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var89);
//     org.jfree.data.Range var91 = var86.findRangeBounds((org.jfree.data.category.CategoryDataset)var89);
//     var0.drawItem(var3, var4, var14, var22, (org.jfree.chart.axis.CategoryAxis)var57, (org.jfree.chart.axis.ValueAxis)var73, (org.jfree.data.category.CategoryDataset)var89, 100, 13, 10);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
//     org.jfree.data.Range var3 = var2.getWidthRange();
//     org.jfree.chart.block.LengthConstraintType var4 = var2.getHeightConstraintType();
//     double var5 = var2.getWidth();
//     org.jfree.chart.util.Size2D var6 = null;
//     org.jfree.chart.util.Size2D var7 = var2.calculateConstrainedSize(var6);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = var0.getChartArea();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     boolean var4 = var3.getUseOutlinePaint();
//     boolean var6 = var3.isSeriesVisibleInLegend(1);
//     var3.setSeriesShapesFilled(0, false);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var12 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var13 = var12.getChartArea();
//     var11.setLegendItemShape((java.awt.Shape)var13);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var15 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var19, var20, var21);
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = var23.getLabelOutlinePaint();
//     var22.setRangeCrosshairPaint(var24);
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
//     org.jfree.chart.util.Layer var32 = null;
//     java.util.Collection var33 = var30.getRangeMarkers(0, var32);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var30.zoomDomainAxes(2.0d, 1.0d, var36, var37);
//     org.jfree.data.xy.XYDataset var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     java.awt.geom.Point2D var47 = null;
//     var43.zoomDomainAxes((-1.0d), 0.2d, var46, var47);
//     java.awt.Paint var49 = var43.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var51 = var43.getRangeAxisLocation(1);
//     java.lang.Object var52 = null;
//     boolean var53 = var51.equals(var52);
//     var30.setDomainAxisLocation(var51);
//     var22.setDomainAxisLocation(var51);
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var58 = var3.initialise(var10, var13, var22, 10, var57);
//     var0.setChartArea(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(1);
    int var3 = var1.indexOf((java.lang.Object)(short)0);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var6 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
    java.awt.Paint var7 = var6.getWallPaint();
    double var8 = var6.getMinimumBarLength();
    boolean var9 = var1.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    var0.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    var0.removeColumn((java.lang.Comparable)0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var8 = var0.getRowKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var5.getRangeMarkers(0, var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.data.Range var10 = var5.getDataRange(var9);
    var5.clearAnnotations();
    boolean var12 = var0.equals((java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var14 = var5.getDomainAxisForDataset(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.plot.Plot var4 = var3.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var6 = var3.getSubtitle(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.axis.CategoryAxis var17 = var7.getDomainAxisForDataset(0);
//     org.jfree.chart.util.RectangleEdge var18 = var7.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var22 = var21.getLabel();
//     org.jfree.data.KeyedObject var23 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var21);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var26 = var25.getLabelInsets();
//     double var28 = var26.calculateTopInset(100.0d);
//     var21.setTickLabelInsets(var26);
//     int var30 = var7.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var21);
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var33 = var32.getTickMarkStroke();
//     java.lang.Object var34 = var32.clone();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var35 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var37 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var35, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var35, var39, var40, var41);
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var44 = var43.getLabelOutlinePaint();
//     var42.setRangeCrosshairPaint(var44);
//     var32.setLabelPaint(var44);
//     var21.setAxisLinePaint(var44);
//     
//     // Checks the contract:  equals-hashcode on var0 and var35
//     assertTrue("Contract failed: equals-hashcode on var0 and var35", var0.equals(var35) ? var0.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var0
//     assertTrue("Contract failed: equals-hashcode on var35 and var0", var35.equals(var0) ? var35.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var43
//     assertTrue("Contract failed: equals-hashcode on var8 and var43", var8.equals(var43) ? var8.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var8
//     assertTrue("Contract failed: equals-hashcode on var43 and var8", var43.equals(var8) ? var43.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
//     var0.setRenderAsPercentages(false);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var4 = null;
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var7 = var6.getLabelInsets();
//     double var9 = var7.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var11 = var10.getChartArea();
//     java.awt.geom.Rectangle2D var14 = var7.createInsetRectangle(var11, true, false);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var15 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var19, var20, var21);
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var22.zoomDomainAxes((-1.0d), 0.2d, var25, var26);
//     org.jfree.chart.util.SortOrder var28 = var22.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var31 = var30.getLabel();
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var33 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var35 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var33, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, var37, var38, var39);
//     var0.drawItem(var3, var4, var11, var22, (org.jfree.chart.axis.CategoryAxis)var30, var32, (org.jfree.data.category.CategoryDataset)var33, (-1), 1900, (-1));
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = var0.getChartArea();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var5 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var6 = var5.getChartArea();
//     var4.setLegendItemShape((java.awt.Shape)var6);
//     var3.setDataArea(var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     java.util.Date var4 = null;
//     org.jfree.chart.axis.SegmentedTimeline.Segment var5 = var3.getSegment(var4);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = null;
    var2.setLabelOutlinePaint(var3);
    java.awt.Stroke var5 = var2.getLabelOutlineStroke();
    var1.setOutlineStroke(var5);
    java.awt.Paint var7 = var1.getAggregatedItemsPaint();
    org.jfree.chart.JFreeChart var8 = var1.getPieChart();
    org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var14 = var8.createBufferedImage(2, 0, 100.0d, Double.NaN, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     boolean var1 = var0.getUseOutlinePaint();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     boolean var4 = var3.getUseOutlinePaint();
//     var3.setSeriesShapesVisible(1, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var9 = var3.equals((java.lang.Object)var8);
//     boolean var12 = var8.getItemShapeVisible(3, (-1));
//     boolean var13 = var2.equals((java.lang.Object)(-1));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var3.", var0.equals(var3) == var3.equals(var0));
// 
//   }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setSeriesItemLabelsVisible(4, true);
    var0.setBaseSeriesVisibleInLegend(false, false);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "Category Plot", "black");
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)'a');
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var4, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var11 = var3.generateURL((org.jfree.data.category.CategoryDataset)var4, 3, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "January"+ "'", var2.equals("January"));

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var14);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var20, var21, var22);
//     java.lang.Number var26 = var16.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
//     var7.setDataset((org.jfree.data.category.CategoryDataset)var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var16
//     assertTrue("Contract failed: equals-hashcode on var0 and var16", var0.equals(var16) ? var0.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var0
//     assertTrue("Contract failed: equals-hashcode on var16 and var0", var16.equals(var0) ? var16.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, var9, var10, var11);
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelOutlinePaint();
    var12.setRangeCrosshairPaint(var14);
    var4.setDomainTickBandPaint(var14);
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var4.axisChanged(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var4 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var3);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    int var7 = var6.getYYYY();
    int var8 = var1.compare((org.jfree.data.time.SerialDate)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var1.getFollowingDayOfWeek(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var26 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var28 = var27.clone();
//     java.awt.Paint var29 = var27.getBasePaint();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var26, var29);
//     var20.setSeriesOutlinePaint(0, var29, true);
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var29, 0.0f, var34);
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var37 = null;
//     var36.setLabelOutlinePaint(var37);
//     java.awt.Stroke var39 = var36.getLabelOutlineStroke();
//     java.awt.Paint var40 = var36.getLabelPaint();
//     org.jfree.chart.text.TextLine var41 = new org.jfree.chart.text.TextLine("", var14, var40);
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
//     boolean var47 = var46.isRangeCrosshairVisible();
//     java.awt.Stroke var48 = var46.getRangeZeroBaselineStroke();
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var55 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var57 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var55, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var55, var59, var60, var61);
//     org.jfree.chart.plot.PiePlot var63 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var64 = var63.getLabelOutlinePaint();
//     var62.setRangeCrosshairPaint(var64);
//     var54.setDomainTickBandPaint(var64);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var67 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var70 = var67.isItemLabelVisible(1, 0);
//     org.jfree.data.general.WaferMapDataset var72 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var73 = null;
//     org.jfree.chart.plot.WaferMapPlot var74 = new org.jfree.chart.plot.WaferMapPlot(var72, var73);
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var74);
//     java.awt.Stroke var76 = var75.getBorderStroke();
//     var67.setSeriesStroke(100, var76, true);
//     org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker(0.0d, var64, var76);
//     org.jfree.chart.util.LengthAdjustmentType var80 = var79.getLabelOffsetType();
//     org.jfree.chart.event.MarkerChangeListener var81 = null;
//     var79.addChangeListener(var81);
//     org.jfree.chart.util.RectangleInsets var83 = var79.getLabelOffset();
//     org.jfree.chart.block.LineBorder var84 = new org.jfree.chart.block.LineBorder(var40, var48, var83);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var67.", var3.equals(var67) == var67.equals(var3));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var67.", var27.equals(var67) == var67.equals(var27));
//     
//     // Checks the contract:  equals-hashcode on var46 and var54
//     assertTrue("Contract failed: equals-hashcode on var46 and var54", var46.equals(var54) ? var46.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var46
//     assertTrue("Contract failed: equals-hashcode on var54 and var46", var54.equals(var46) ? var54.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var2 = var1.getCategoryLabelPositionOffset();
    java.awt.Paint var3 = var1.getAxisLinePaint();
    java.awt.Stroke var4 = var1.getTickMarkStroke();
    java.util.EventListener var5 = null;
    boolean var6 = var1.hasListener(var5);
    var1.setMaximumCategoryLabelLines(13);
    var1.setLowerMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var4.rendererChanged(var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var17.zoomDomainAxes((-1.0d), 0.2d, var20, var21);
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var25 = var17.getRangeAxisLocation(1);
    var4.setDomainAxisLocation(var25);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var34, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var34, var38, var39, var40);
    org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var43 = var42.getLabelOutlinePaint();
    var41.setRangeCrosshairPaint(var43);
    var33.setDomainTickBandPaint(var43);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var49 = var46.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var51 = null;
    org.jfree.chart.renderer.WaferMapRenderer var52 = null;
    org.jfree.chart.plot.WaferMapPlot var53 = new org.jfree.chart.plot.WaferMapPlot(var51, var52);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var53);
    java.awt.Stroke var55 = var54.getBorderStroke();
    var46.setSeriesStroke(100, var55, true);
    org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(0.0d, var43, var55);
    org.jfree.chart.util.LengthAdjustmentType var59 = var58.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeListener var60 = null;
    var58.addChangeListener(var60);
    org.jfree.chart.util.Layer var62 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((-1), (org.jfree.chart.plot.Marker)var58, var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.axis.NumberTickUnit var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setTickUnit(var7, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    java.lang.Number[] var2 = null;
    java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
    java.lang.Number[] var4 = null;
    java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var4 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var3);
//     org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var11 = var8.isOnOrBefore((org.jfree.data.time.SerialDate)var10);
//     boolean var12 = var6.isOnOrAfter((org.jfree.data.time.SerialDate)var10);
//     boolean var13 = var3.isBefore((org.jfree.data.time.SerialDate)var10);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var18 = var15.isOnOrBefore((org.jfree.data.time.SerialDate)var17);
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
//     boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
//     boolean var27 = var17.isBefore((org.jfree.data.time.SerialDate)var24);
//     boolean var28 = var10.isOn((org.jfree.data.time.SerialDate)var17);
//     var10.setDescription("April");
//     org.jfree.data.time.SerialDate var31 = null;
//     boolean var32 = var10.isAfter(var31);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    var0.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    int var6 = var0.getColumnIndex((java.lang.Comparable)(byte)0);
    var0.removeRow(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var11 = var0.getValue((java.lang.Comparable)"hi!", (java.lang.Comparable)1900);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    double var11 = var4.getDomainCrosshairValue();
    int var12 = var4.getDomainAxisCount();
    org.jfree.data.xy.XYDataset var13 = null;
    int var14 = var4.indexOf(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var9 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var9, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var9, var13, var14, var15);
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var18 = var17.getLabelOutlinePaint();
//     var16.setRangeCrosshairPaint(var18);
//     var8.setDomainTickBandPaint(var18);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var24 = var21.isItemLabelVisible(1, 0);
//     org.jfree.data.general.WaferMapDataset var26 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var27 = null;
//     org.jfree.chart.plot.WaferMapPlot var28 = new org.jfree.chart.plot.WaferMapPlot(var26, var27);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
//     java.awt.Stroke var30 = var29.getBorderStroke();
//     var21.setSeriesStroke(100, var30, true);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(0.0d, var18, var30);
//     var2.setWallPaint(var18);
//     java.awt.Shape var39 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var40 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var41 = var40.clone();
//     java.awt.Paint var42 = var40.getBasePaint();
//     org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var39, var42);
//     java.awt.Stroke var44 = var43.getOutlineStroke();
//     int var45 = var43.getDatasetIndex();
//     java.text.AttributedString var46 = var43.getAttributedLabel();
//     boolean var47 = var43.isShapeVisible();
//     java.awt.Shape var48 = var43.getLine();
//     boolean var49 = var2.equals((java.lang.Object)var43);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var40 and var21.", var40.equals(var21) == var21.equals(var40));
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Range[0.0,0.0]", var1);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var3 = var0.getItemShapeVisible(0, 10);
    org.jfree.data.general.WaferMapDataset var4 = null;
    org.jfree.chart.renderer.WaferMapRenderer var5 = null;
    org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var4, var5);
    org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    var7.setTitle("ThreadContext");
    java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var14 = var13.darker();
    var7.setBorderPaint((java.awt.Paint)var14);
    boolean var16 = var0.equals((java.lang.Object)var7);
    var7.setNotify(false);
    org.jfree.chart.event.ChartChangeListener var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addChangeListener(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
//     org.jfree.chart.util.SortOrder var13 = var7.getRowRenderingOrder();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var15 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var19, var20, var21);
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = var23.getLabelOutlinePaint();
//     var22.setRangeCrosshairPaint(var24);
//     int var26 = var22.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var27 = new org.jfree.chart.axis.AxisSpace();
//     var22.setFixedRangeAxisSpace(var27);
//     org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
//     var22.setFixedRangeAxisSpace(var29);
//     java.lang.String var31 = var22.getPlotType();
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     java.awt.geom.Point2D var40 = null;
//     var36.zoomDomainAxes((-1.0d), 0.2d, var39, var40);
//     java.awt.Paint var42 = var36.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var44 = var36.getRangeAxisLocation(1);
//     var22.setDomainAxisLocation(var44, false);
//     var7.setDomainAxisLocation(3, var44, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    boolean var3 = var0.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getURLGenerator(100, 4);
    var0.setMinimumBarLength(0.0d);
    org.jfree.chart.LegendItem var11 = var0.getLegendItem(4, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition((-1));
//     var1.setNegativeItemLabelPositionFallback(var4);
//     java.awt.Font var6 = var1.getBaseItemLabelFont();
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.urls.PieURLGenerator var8 = var7.getURLGenerator();
//     java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     var7.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var13);
//     java.awt.color.ColorSpace var15 = var13.getColorSpace();
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("Category Plot", var6, (java.awt.Paint)var13);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var24 = var23.getNumberFormatOverride();
//     org.jfree.data.Range var27 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var28 = new org.jfree.data.time.DateRange(var27);
//     var23.setRangeWithMargins((org.jfree.data.Range)var28);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var32 = var31.getLabelInsets();
//     double var34 = var32.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var35 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var36 = var35.getChartArea();
//     java.awt.geom.Rectangle2D var39 = var32.createInsetRectangle(var36, true, false);
//     var23.setDownArrow((java.awt.Shape)var39);
//     var20.setSeriesShape(13, (java.awt.Shape)var39, false);
//     var16.draw(var17, var39);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    boolean var3 = var0.getBaseSeriesVisible();
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var6 = var5.getCategoryLabelPositionOffset();
    java.awt.Paint var7 = var5.getAxisLinePaint();
    java.awt.Stroke var8 = var5.getTickMarkStroke();
    var0.setBaseStroke(var8, true);
    boolean var12 = var0.isSeriesItemLabelsVisible(13);
    var0.setBaseItemLabelsVisible(false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("WMAP_Plot", "Range[0.0,0.0]", var3);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = var0.getDataset();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var6 = var5.clone();
//     java.awt.Paint var7 = var5.getBasePaint();
//     boolean var8 = var5.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var11 = var5.getURLGenerator(100, 4);
//     java.awt.Font var13 = null;
//     var5.setSeriesItemLabelFont(0, var13, true);
//     java.awt.Font var16 = var5.getBaseItemLabelFont();
//     java.awt.Color var20 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var20);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var28 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var29 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var30 = var29.clone();
//     java.awt.Paint var31 = var29.getBasePaint();
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var28, var31);
//     var22.setSeriesOutlinePaint(0, var31, true);
//     org.jfree.chart.text.TextMeasurer var36 = null;
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, var31, 0.0f, var36);
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var39 = null;
//     var38.setLabelOutlinePaint(var39);
//     java.awt.Stroke var41 = var38.getLabelOutlineStroke();
//     java.awt.Paint var42 = var38.getLabelPaint();
//     org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("", var16, var42);
//     org.jfree.chart.text.TextFragment var44 = var43.getFirstTextFragment();
//     float var45 = var44.getBaselineOffset();
//     java.awt.Paint var46 = var44.getPaint();
//     var0.setAngleLabelPaint(var46);
//     var0.zoom(1.0d);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    java.lang.Number var5 = var0.getMeanValue((java.lang.Comparable)(short)1, (java.lang.Comparable)2.0d);
    int var6 = var0.getColumnCount();
    java.lang.Comparable var7 = null;
    java.lang.Number var9 = var0.getMaxOutlier(var7, (java.lang.Comparable)"Range[0.0,0.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var0.getMaxRegularValue(3, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var7.setRenderer(var8, true);
    var7.clearDomainMarkers(10);
    org.jfree.chart.axis.CategoryAnchor var13 = var7.getDomainGridlinePosition();
    org.jfree.chart.util.RectangleEdge var15 = var7.getDomainAxisEdge((-1));
    java.lang.String var16 = var15.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "RectangleEdge.TOP"+ "'", var16.equals("RectangleEdge.TOP"));

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setYOffset(10.0d);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, var8, var9, var10);
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var13 = var12.getLabelOutlinePaint();
//     var11.setRangeCrosshairPaint(var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var19.getRangeMarkers(0, var21);
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var19.zoomDomainAxes(2.0d, 1.0d, var25, var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     java.awt.geom.Point2D var36 = null;
//     var32.zoomDomainAxes((-1.0d), 0.2d, var35, var36);
//     java.awt.Paint var38 = var32.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var40 = var32.getRangeAxisLocation(1);
//     java.lang.Object var41 = null;
//     boolean var42 = var40.equals(var41);
//     var19.setDomainAxisLocation(var40);
//     var11.setDomainAxisLocation(var40);
//     org.jfree.data.general.WaferMapDataset var45 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var46 = null;
//     org.jfree.chart.plot.WaferMapPlot var47 = new org.jfree.chart.plot.WaferMapPlot(var45, var46);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var47);
//     var48.setTitle("ThreadContext");
//     java.awt.Color var54 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var55 = var54.darker();
//     var48.setBorderPaint((java.awt.Paint)var55);
//     java.awt.image.ColorModel var57 = null;
//     java.awt.Rectangle var58 = null;
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var61 = var60.getLabelInsets();
//     double var63 = var61.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var64 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var65 = var64.getChartArea();
//     java.awt.geom.Rectangle2D var68 = var61.createInsetRectangle(var65, true, false);
//     java.awt.geom.AffineTransform var69 = null;
//     java.awt.RenderingHints var70 = null;
//     java.awt.PaintContext var71 = var55.createContext(var57, var58, var65, var69, var70);
//     var0.drawOutline(var3, var11, var65);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     var7.setRenderer(var8, true);
//     var7.clearDomainMarkers(10);
//     org.jfree.chart.axis.CategoryAnchor var13 = var7.getDomainGridlinePosition();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var14, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var14, var18, var19, var20);
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var23 = var22.getLabelOutlinePaint();
//     var21.setRangeCrosshairPaint(var23);
//     int var25 = var21.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var26 = new org.jfree.chart.axis.AxisSpace();
//     var21.setFixedRangeAxisSpace(var26);
//     org.jfree.chart.axis.AxisSpace var28 = new org.jfree.chart.axis.AxisSpace();
//     var21.setFixedRangeAxisSpace(var28);
//     var21.setRangeCrosshairValue(4.0d);
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var33 = null;
//     var32.setLabelOutlinePaint(var33);
//     java.awt.Stroke var35 = var32.getLabelOutlineStroke();
//     java.awt.Paint var36 = var32.getLabelPaint();
//     org.jfree.data.general.WaferMapDataset var37 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var38 = null;
//     org.jfree.chart.plot.WaferMapPlot var39 = new org.jfree.chart.plot.WaferMapPlot(var37, var38);
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var39);
//     java.awt.Stroke var41 = var39.getOutlineStroke();
//     var32.setBaseSectionOutlineStroke(var41);
//     var21.setDomainGridlineStroke(var41);
//     var7.setRangeCrosshairStroke(var41);
//     
//     // Checks the contract:  equals-hashcode on var0 and var14
//     assertTrue("Contract failed: equals-hashcode on var0 and var14", var0.equals(var14) ? var0.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var0
//     assertTrue("Contract failed: equals-hashcode on var14 and var0", var14.equals(var0) ? var14.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(2, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "February"+ "'", var2.equals("February"));

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var4.rendererChanged(var11);
    int var13 = var4.getWeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var3 = var2.clone();
//     java.awt.Paint var4 = var2.getBasePaint();
//     boolean var5 = var2.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var2.getURLGenerator(100, 4);
//     java.awt.Font var10 = null;
//     var2.setSeriesItemLabelFont(0, var10, true);
//     java.awt.Font var13 = var2.getBaseItemLabelFont();
//     org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("January", var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var19.getRangeMarkers(0, var21);
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var19.zoomDomainAxes(2.0d, 1.0d, var25, var26);
//     java.awt.Color var31 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
//     var19.setDomainCrosshairPaint((java.awt.Paint)var31);
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("January", var13, (java.awt.Paint)var31, 100.0f, var34);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    org.jfree.chart.util.SortOrder var13 = var7.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var17 = var16.getTickMarkStroke();
    java.lang.Object var18 = var16.clone();
    var16.setMaximumCategoryLabelWidthRatio(0.5f);
    boolean var21 = var16.isAxisLineVisible();
    var7.setDomainAxis(1900, (org.jfree.chart.axis.CategoryAxis)var16);
    java.awt.Stroke var23 = var16.getTickMarkStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    var4.clearAnnotations();
    java.awt.Paint var11 = var4.getDomainCrosshairPaint();
    int var12 = var4.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     double var14 = var12.getTop();
//     org.jfree.data.general.WaferMapDataset var15 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var16 = null;
//     org.jfree.chart.plot.WaferMapPlot var17 = new org.jfree.chart.plot.WaferMapPlot(var15, var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     var18.setTitle("ThreadContext");
//     java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var25 = var24.darker();
//     var18.setBorderPaint((java.awt.Paint)var25);
//     java.awt.image.ColorModel var27 = null;
//     java.awt.Rectangle var28 = null;
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var31 = var30.getLabelInsets();
//     double var33 = var31.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var35 = var34.getChartArea();
//     java.awt.geom.Rectangle2D var38 = var31.createInsetRectangle(var35, true, false);
//     java.awt.geom.AffineTransform var39 = null;
//     java.awt.RenderingHints var40 = null;
//     java.awt.PaintContext var41 = var25.createContext(var27, var28, var35, var39, var40);
//     org.jfree.data.general.WaferMapDataset var42 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var43 = null;
//     org.jfree.chart.plot.WaferMapPlot var44 = new org.jfree.chart.plot.WaferMapPlot(var42, var43);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var44);
//     java.awt.Image var46 = null;
//     var45.setBackgroundImage(var46);
//     org.jfree.chart.title.TextTitle var48 = null;
//     var45.setTitle(var48);
//     var45.setAntiAlias(false);
//     float var52 = var45.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var53 = var45.getLegend();
//     java.awt.Paint var54 = var53.getBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
//     var53.setFrame((org.jfree.chart.block.BlockFrame)var59);
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var61 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var62 = var61.getObjectIcon();
//     boolean var63 = var61.isDrawLines();
//     org.jfree.chart.LegendItemSource[] var64 = new org.jfree.chart.LegendItemSource[] { var61};
//     var53.setSources(var64);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var66 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var68 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var66, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var72 = null;
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var66, var70, var71, var72);
//     org.jfree.chart.plot.PiePlot var74 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var75 = var74.getLabelOutlinePaint();
//     var73.setRangeCrosshairPaint(var75);
//     int var77 = var73.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var78 = new org.jfree.chart.axis.AxisSpace();
//     var73.setFixedRangeAxisSpace(var78);
//     org.jfree.chart.axis.AxisSpace var80 = new org.jfree.chart.axis.AxisSpace();
//     var73.setFixedRangeAxisSpace(var80);
//     org.jfree.chart.axis.CategoryAxis var83 = var73.getDomainAxisForDataset(0);
//     org.jfree.chart.util.RectangleEdge var84 = var73.getDomainAxisEdge();
//     var53.setLegendItemGraphicEdge(var84);
//     boolean var86 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var84);
//     java.awt.geom.Rectangle2D var87 = var12.reserved(var35, var84);
//     
//     // Checks the contract:  equals-hashcode on var0 and var66
//     assertTrue("Contract failed: equals-hashcode on var0 and var66", var0.equals(var66) ? var0.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var0
//     assertTrue("Contract failed: equals-hashcode on var66 and var0", var66.equals(var0) ? var66.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var73
//     assertTrue("Contract failed: equals-hashcode on var7 and var73", var7.equals(var73) ? var7.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var7
//     assertTrue("Contract failed: equals-hashcode on var73 and var7", var73.equals(var7) ? var73.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var74
//     assertTrue("Contract failed: equals-hashcode on var8 and var74", var8.equals(var74) ? var8.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var8
//     assertTrue("Contract failed: equals-hashcode on var74 and var8", var74.equals(var8) ? var74.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var44
//     assertTrue("Contract failed: equals-hashcode on var17 and var44", var17.equals(var44) ? var17.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var17
//     assertTrue("Contract failed: equals-hashcode on var44 and var17", var44.equals(var17) ? var44.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    org.jfree.chart.axis.CategoryAxis var17 = var7.getDomainAxisForDataset(0);
    var17.setUpperMargin(10.0d);
    var17.setTickMarkInsideLength(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.data.Range var9 = var4.getDataRange(var8);
//     org.jfree.chart.axis.AxisSpace var10 = null;
//     var4.setFixedDomainAxisSpace(var10);
//     java.awt.Paint var12 = null;
//     var4.setRangeTickBandPaint(var12);
//     java.awt.geom.Point2D var14 = var4.getQuadrantOrigin();
//     var4.clearDomainMarkers(4);
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var20 = var19.getChartArea();
//     java.lang.Object var21 = var19.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var23 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var25 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var23, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, var27, var28, var29);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.chart.util.Layer var40 = null;
//     java.util.Collection var41 = var38.getRangeMarkers(0, var40);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.data.Range var43 = var38.getDataRange(var42);
//     org.jfree.chart.axis.AxisSpace var44 = null;
//     var38.setFixedDomainAxisSpace(var44);
//     java.awt.Paint var46 = null;
//     var38.setRangeTickBandPaint(var46);
//     java.awt.geom.Point2D var48 = var38.getQuadrantOrigin();
//     var30.zoomRangeAxes(10.0d, 0.0d, var33, var48);
//     var4.zoomDomainAxes(10.0d, 100.0d, var22, var48);
//     
//     // Checks the contract:  equals-hashcode on var4 and var38
//     assertTrue("Contract failed: equals-hashcode on var4 and var38", var4.equals(var38) ? var4.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var4
//     assertTrue("Contract failed: equals-hashcode on var38 and var4", var38.equals(var4) ? var38.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, (-10.0d), (-10.0d), 3, (java.lang.Comparable)4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    double var4 = var2.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var5 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var6 = var5.getChartArea();
    java.awt.geom.Rectangle2D var9 = var2.createInsetRectangle(var6, true, false);
    double var10 = var2.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.0d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Locale var1 = var0.getLocale();
    boolean var3 = var0.containsKey("hi!");
    java.lang.Object var5 = var0.handleGetObject("Default Group");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    boolean var2 = var0.isDomainZoomable();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var8 = var7.clone();
    java.awt.Paint var9 = var7.getBasePaint();
    boolean var10 = var7.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var13 = var7.getURLGenerator(100, 4);
    java.awt.Font var15 = null;
    var7.setSeriesItemLabelFont(0, var15, true);
    java.awt.Font var18 = var7.getBaseItemLabelFont();
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var23 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var30 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var31 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var32 = var31.clone();
    java.awt.Paint var33 = var31.getBasePaint();
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var30, var33);
    var24.setSeriesOutlinePaint(0, var33, true);
    org.jfree.chart.text.TextMeasurer var38 = null;
    org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, var33, 0.0f, var38);
    org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var41 = null;
    var40.setLabelOutlinePaint(var41);
    java.awt.Stroke var43 = var40.getLabelOutlineStroke();
    java.awt.Paint var44 = var40.getLabelPaint();
    org.jfree.chart.text.TextLine var45 = new org.jfree.chart.text.TextLine("", var18, var44);
    org.jfree.chart.text.TextFragment var46 = var45.getFirstTextFragment();
    float var47 = var46.getBaselineOffset();
    java.awt.Font var48 = var46.getFont();
    var3.setBaseItemLabelFont(var48);
    org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var52 = var51.getTickMarkStroke();
    java.lang.Object var53 = var51.clone();
    var51.setMaximumCategoryLabelWidthRatio(0.5f);
    boolean var56 = var3.equals((java.lang.Object)var51);
    org.jfree.chart.block.BlockBorder var61 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
    java.awt.Paint var62 = var61.getPaint();
    var3.setErrorIndicatorPaint(var62);
    var0.setOutlinePaint(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    double var1 = var0.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition((-1));
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var7 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var8 = var7.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var10 = var9.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var12 = var11.getObjectIcon();
    var9.setMaxIcon(var12);
    var7.setObjectIcon(var12);
    boolean var17 = var7.isItemLabelVisible(10, (-1));
    boolean var18 = var6.equals((java.lang.Object)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-1), var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     var3.setNotify(false);
//     org.jfree.chart.ChartRenderingInfo var16 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var17 = var16.getChartArea();
//     java.lang.Object var18 = var16.clone();
//     java.awt.image.BufferedImage var19 = var3.createBufferedImage(2, 1, var16);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setSeriesItemLabelsVisible(4, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var0.setBaseItemLabelGenerator(var4, false);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.lang.String var3 = var2.getToolTipText();
    var0.add((org.jfree.chart.block.Block)var2);
    org.jfree.chart.util.RectangleEdge var5 = var2.getPosition();
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setHorizontalAlignment(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    java.awt.Color var1 = java.awt.Color.getColor("rect");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var3 = var0.isItemLabelVisible(1, 0);
    double var4 = var0.getBase();
    boolean var5 = var0.getBaseCreateEntities();
    java.awt.Stroke var6 = var0.getBaseStroke();
    java.awt.Shape var9 = var0.getItemShape(10, 10);
    java.awt.Paint var11 = var0.getSeriesPaint(10);
    int var12 = var0.getColumnCount();
    int var13 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var7 = var6.getBorderStroke();
    var0.setRadiusGridlineStroke(var7);
    java.awt.Paint var9 = var0.getAngleGridlinePaint();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var0.axisChanged(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, var6, var7, var8);
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var11 = var10.getLabelOutlinePaint();
//     var9.setRangeCrosshairPaint(var11);
//     int var13 = var9.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var9.setFixedRangeAxisSpace(var14);
//     org.jfree.chart.axis.AxisSpace var16 = new org.jfree.chart.axis.AxisSpace();
//     var9.setFixedRangeAxisSpace(var16);
//     java.lang.String var18 = var9.getPlotType();
//     java.awt.Paint var19 = var9.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var22 = var21.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var24 = null;
//     var23.setLabelOutlinePaint(var24);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var32 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var34 = var33.clone();
//     java.awt.Paint var35 = var33.getBasePaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
//     var26.setSeriesOutlinePaint(0, var35, true);
//     var23.setBackgroundPaint(var35);
//     java.awt.Stroke var40 = null;
//     org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var19, var22, var35, var40, 0.0f);
//     org.jfree.data.general.WaferMapDataset var43 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var44 = null;
//     org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
//     java.awt.Image var47 = null;
//     var46.setBackgroundImage(var47);
//     var46.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var50 = var46.getPadding();
//     var42.setLabelOffset(var50);
//     java.lang.Object var52 = var42.clone();
//     org.jfree.chart.util.RectangleInsets var53 = var42.getLabelOffset();
//     double var55 = var53.trimWidth(3.0d);
//     org.jfree.data.general.WaferMapDataset var56 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var57 = null;
//     org.jfree.chart.plot.WaferMapPlot var58 = new org.jfree.chart.plot.WaferMapPlot(var56, var57);
//     org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var58);
//     var59.setTitle("ThreadContext");
//     org.jfree.chart.plot.Plot var62 = var59.getPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var62.handleClick(0, 0, var65);
//     boolean var67 = var53.equals((java.lang.Object)0);
//     
//     // Checks the contract:  equals-hashcode on var45 and var58
//     assertTrue("Contract failed: equals-hashcode on var45 and var58", var45.equals(var58) ? var45.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var45
//     assertTrue("Contract failed: equals-hashcode on var58 and var45", var58.equals(var45) ? var58.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var5 = var4.getLabel();
//     org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var4);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var9 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var10 = var9.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var17 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var19 = var18.clone();
//     java.awt.Paint var20 = var18.getBasePaint();
//     org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var17, var20);
//     var11.setSeriesOutlinePaint(0, var20, true);
//     boolean var24 = var9.equals((java.lang.Object)var20);
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var28 = var27.getChartArea();
//     var26.setLegendItemShape((java.awt.Shape)var28);
//     var9.setSeriesShape(4, (java.awt.Shape)var28);
//     boolean var31 = var6.equals((java.lang.Object)var28);
//     var0.draw(var1, var28);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var7.setRenderer(var8, true);
    org.jfree.chart.plot.CategoryMarker var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var14);
//     java.lang.String var16 = var7.getPlotType();
//     java.awt.Paint var17 = var7.getDomainGridlinePaint();
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var22.zoomDomainAxes((-1.0d), 0.2d, var25, var26);
//     java.awt.Paint var28 = var22.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var30 = var22.getRangeAxisLocation(1);
//     var7.setDomainAxisLocation(var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var35 = var34.getNumberFormatOverride();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var37 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var38 = var37.clone();
//     java.awt.Paint var39 = var37.getBasePaint();
//     boolean var40 = var37.getBaseSeriesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var43 = var42.getCategoryLabelPositionOffset();
//     java.awt.Paint var44 = var42.getAxisLinePaint();
//     java.awt.Stroke var45 = var42.getTickMarkStroke();
//     var37.setBaseStroke(var45, true);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var51 = var50.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var58 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var59 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var60 = var59.clone();
//     java.awt.Paint var61 = var59.getBasePaint();
//     org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var58, var61);
//     var52.setSeriesOutlinePaint(0, var61, true);
//     boolean var65 = var50.equals((java.lang.Object)var61);
//     org.jfree.chart.plot.PiePlot var67 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var68 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var69 = var68.getChartArea();
//     var67.setLegendItemShape((java.awt.Shape)var69);
//     var50.setSeriesShape(4, (java.awt.Shape)var69);
//     var37.setBaseShape((java.awt.Shape)var69, true);
//     org.jfree.data.xy.XYDataset var74 = null;
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var77 = null;
//     org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot(var74, var75, var76, var77);
//     org.jfree.chart.plot.PlotRenderingInfo var81 = null;
//     java.awt.geom.Point2D var82 = null;
//     var78.zoomDomainAxes((-1.0d), 0.2d, var81, var82);
//     java.awt.Paint var84 = var78.getRangeCrosshairPaint();
//     double var85 = var78.getDomainCrosshairValue();
//     var78.setRangeZeroBaselineVisible(true);
//     java.awt.Stroke var88 = var78.getRangeGridlineStroke();
//     java.lang.String var89 = var78.getPlotType();
//     org.jfree.chart.util.RectangleEdge var90 = var78.getDomainAxisEdge();
//     double var91 = var34.lengthToJava2D(1.0E-5d, var69, var90);
//     var7.drawBackground(var32, var69);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
    java.util.List var5 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    java.awt.Stroke var3 = var0.getLabelOutlineStroke();
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var0.setURLGenerator(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    var0.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var5 = null;
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var10 = var7.isOnOrBefore((org.jfree.data.time.SerialDate)var9);
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var17 = var14.isOnOrBefore((org.jfree.data.time.SerialDate)var16);
    boolean var18 = var12.isOnOrAfter((org.jfree.data.time.SerialDate)var16);
    boolean var19 = var9.isBefore((org.jfree.data.time.SerialDate)var16);
    org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var24 = var21.isOnOrBefore((org.jfree.data.time.SerialDate)var23);
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var31 = var28.isOnOrBefore((org.jfree.data.time.SerialDate)var30);
    boolean var32 = var26.isOnOrAfter((org.jfree.data.time.SerialDate)var30);
    boolean var33 = var23.isBefore((org.jfree.data.time.SerialDate)var30);
    boolean var34 = var16.isOn((org.jfree.data.time.SerialDate)var23);
    java.lang.Comparable var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addValue(var5, (java.lang.Comparable)var16, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(4);
    double var4 = var0.getItemLabelAnchorOffset();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var0.getLegendItemURLGenerator();
    java.lang.Object var6 = var0.clone();
    var0.setAutoPopulateSeriesFillPaint(false);
    var0.setSeriesShapesVisible(255, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var7 = var4.getItemShapeVisible(0, 10);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var11.setTitle("ThreadContext");
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var11.setBorderPaint((java.awt.Paint)var18);
    boolean var20 = var4.equals((java.lang.Object)var11);
    var11.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setPieChart(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(var5);
    var1.setRangeWithMargins((org.jfree.data.Range)var6);
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange(var10);
    var1.setDefaultAutoRange(var10);
    java.awt.Paint var13 = var1.getTickLabelPaint();
    boolean var14 = var1.getAutoRangeIncludesZero();
    java.lang.Object var15 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize((-10.0d), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setBackgroundImageAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var1 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var1, var2);
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
//     java.awt.Image var5 = null;
//     var4.setBackgroundImage(var5);
//     org.jfree.chart.title.TextTitle var7 = null;
//     var4.setTitle(var7);
//     var4.setAntiAlias(false);
//     boolean var11 = var4.isBorderVisible();
//     java.awt.Paint var12 = var4.getBackgroundPaint();
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var14 = var13.getLabelOutlinePaint();
//     org.jfree.data.general.WaferMapDataset var15 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var16 = null;
//     org.jfree.chart.plot.WaferMapPlot var17 = new org.jfree.chart.plot.WaferMapPlot(var15, var16);
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var20 = var19.getLabelOutlinePaint();
//     var17.setBackgroundPaint(var20);
//     var13.setLabelShadowPaint(var20);
//     var4.setBorderPaint(var20);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var24 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var26 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var24, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, var28, var29, var30);
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var33 = var32.getLabelOutlinePaint();
//     var31.setRangeCrosshairPaint(var33);
//     int var35 = var31.getDomainAxisCount();
//     org.jfree.data.general.DatasetChangeEvent var36 = null;
//     var31.datasetChanged(var36);
//     java.awt.Stroke var38 = var31.getRangeGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(100.0d, var20, var38);
//     
//     // Checks the contract:  equals-hashcode on var19 and var32
//     assertTrue("Contract failed: equals-hashcode on var19 and var32", var19.equals(var32) ? var19.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var19
//     assertTrue("Contract failed: equals-hashcode on var32 and var19", var32.equals(var19) ? var32.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition((-1));
//     var1.setNegativeItemLabelPositionFallback(var4);
//     java.awt.Font var6 = var1.getBaseItemLabelFont();
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.urls.PieURLGenerator var8 = var7.getURLGenerator();
//     java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     var7.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var13);
//     java.awt.color.ColorSpace var15 = var13.getColorSpace();
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("Category Plot", var6, (java.awt.Paint)var13);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.data.Range var18 = null;
//     org.jfree.data.Range var19 = null;
//     org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(var18, var19);
//     org.jfree.data.Range var21 = var20.getWidthRange();
//     org.jfree.chart.util.Size2D var22 = var16.arrange(var17, var20);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Paint var6 = var3.getItemFillPaint(10, 13);
    boolean var7 = var0.equals((java.lang.Object)13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange(var2);
//     java.util.Date var4 = var3.getLowerDate();
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var4, var5);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperMargin(0.0d);
    var9.setInverted(true);
    boolean var14 = var9.isVerticalTickLabels();
    double var15 = var9.getFixedAutoRange();
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var9);
    java.awt.Paint var17 = null;
    var4.setOutlinePaint(var17);
    var4.mapDatasetToRangeAxis(0, 100);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var22 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var22, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, var26, var27, var28);
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var31 = var30.getLabelOutlinePaint();
    var29.setRangeCrosshairPaint(var31);
    int var33 = var29.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var34 = new org.jfree.chart.axis.AxisSpace();
    var29.setFixedRangeAxisSpace(var34);
    org.jfree.chart.axis.AxisSpace var36 = new org.jfree.chart.axis.AxisSpace();
    var29.setFixedRangeAxisSpace(var36);
    java.lang.String var38 = var29.getPlotType();
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    java.awt.geom.Point2D var47 = null;
    var43.zoomDomainAxes((-1.0d), 0.2d, var46, var47);
    java.awt.Paint var49 = var43.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var51 = var43.getRangeAxisLocation(1);
    var29.setDomainAxisLocation(var51, false);
    var4.setRangeAxisLocation(var51);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var56 = var4.getRangeAxisForDataset((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "Category Plot"+ "'", var38.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)10.0d);
//     boolean var23 = var20.getLabelLinksVisible();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", var14, (org.jfree.chart.plot.Plot)var20, false);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var30, var31, var32);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var41.getRangeMarkers(0, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.data.Range var46 = var41.getDataRange(var45);
//     org.jfree.chart.axis.AxisSpace var47 = null;
//     var41.setFixedDomainAxisSpace(var47);
//     java.awt.Paint var49 = null;
//     var41.setRangeTickBandPaint(var49);
//     java.awt.geom.Point2D var51 = var41.getQuadrantOrigin();
//     var33.zoomRangeAxes(10.0d, 0.0d, var36, var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var33, false);
//     java.awt.RenderingHints var55 = null;
//     var54.setRenderingHints(var55);
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var3 = var2.getObjectIcon();
    var0.setMaxIcon(var3);
    java.awt.Stroke var5 = var0.getBaseStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var2.rendererChanged(var3);
    java.awt.Stroke var5 = null;
    var2.setOutlineStroke(var5);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     var17.zoomDomainAxes((-1.0d), 0.2d, var20, var21);
//     java.awt.Paint var23 = var17.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var25 = var17.getRangeAxisLocation(1);
//     java.lang.Object var26 = null;
//     boolean var27 = var25.equals(var26);
//     var4.setDomainAxisLocation(var25);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var33.getRangeMarkers(0, var35);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.data.Range var38 = var33.getDataRange(var37);
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var33.setFixedDomainAxisSpace(var39);
//     boolean var41 = var33.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotOrientation var42 = var33.getOrientation();
//     org.jfree.chart.util.RectangleEdge var43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var25, var42);
//     
//     // Checks the contract:  equals-hashcode on var17 and var33
//     assertTrue("Contract failed: equals-hashcode on var17 and var33", var17.equals(var33) ? var17.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var17
//     assertTrue("Contract failed: equals-hashcode on var33 and var17", var33.equals(var17) ? var33.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var7 = var4.isOnOrBefore((org.jfree.data.time.SerialDate)var6);
    boolean var8 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    int var9 = var0.getIndex((java.lang.Comparable)var8);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var12 = var0.getKey(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, var6, var7, var8);
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var11 = var10.getLabelOutlinePaint();
    var9.setRangeCrosshairPaint(var11);
    int var13 = var9.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var9.setFixedRangeAxisSpace(var14);
    org.jfree.chart.axis.AxisSpace var16 = new org.jfree.chart.axis.AxisSpace();
    var9.setFixedRangeAxisSpace(var16);
    java.lang.String var18 = var9.getPlotType();
    java.awt.Paint var19 = var9.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var22 = var21.getTickMarkStroke();
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var24 = null;
    var23.setLabelOutlinePaint(var24);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var32 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var34 = var33.clone();
    java.awt.Paint var35 = var33.getBasePaint();
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
    var26.setSeriesOutlinePaint(0, var35, true);
    var23.setBackgroundPaint(var35);
    java.awt.Stroke var40 = null;
    org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var19, var22, var35, var40, 0.0f);
    org.jfree.data.general.WaferMapDataset var43 = null;
    org.jfree.chart.renderer.WaferMapRenderer var44 = null;
    org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
    java.awt.Image var47 = null;
    var46.setBackgroundImage(var47);
    var46.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var50 = var46.getPadding();
    var42.setLabelOffset(var50);
    double var52 = var42.getEndValue();
    org.jfree.chart.util.LengthAdjustmentType var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var42.setLabelOffsetType(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Category Plot"+ "'", var18.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0d);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var9 = var8.getLabelOutlinePaint();
//     var7.setRangeCrosshairPaint(var9);
//     int var11 = var7.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var7.setFixedRangeAxisSpace(var14);
//     java.lang.String var16 = var7.getPlotType();
//     var7.clearDomainMarkers(1900);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.chart.util.Layer var26 = null;
//     java.util.Collection var27 = var24.getRangeMarkers(0, var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Point2D var31 = null;
//     var24.zoomDomainAxes(2.0d, 1.0d, var30, var31);
//     org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var35 = var34.getChartArea();
//     java.lang.Object var36 = var34.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var34);
//     java.awt.geom.Point2D var38 = null;
//     var24.zoomDomainAxes(2.0d, var37, var38);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
//     org.jfree.chart.util.Layer var46 = null;
//     java.util.Collection var47 = var44.getRangeMarkers(0, var46);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.data.Range var49 = var44.getDataRange(var48);
//     org.jfree.chart.axis.AxisSpace var50 = null;
//     var44.setFixedDomainAxisSpace(var50);
//     java.awt.Paint var52 = null;
//     var44.setRangeTickBandPaint(var52);
//     java.awt.geom.Point2D var54 = var44.getQuadrantOrigin();
//     var7.zoomRangeAxes((-10.0d), var37, var54);
//     
//     // Checks the contract:  equals-hashcode on var24 and var44
//     assertTrue("Contract failed: equals-hashcode on var24 and var44", var24.equals(var44) ? var24.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var24
//     assertTrue("Contract failed: equals-hashcode on var44 and var24", var44.equals(var24) ? var44.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     var3.setTitle("ThreadContext");
//     java.awt.Color var9 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var10 = var9.darker();
//     var3.setBorderPaint((java.awt.Paint)var10);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var16 = var15.getLabelInsets();
//     double var18 = var16.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var20 = var19.getChartArea();
//     java.awt.geom.Rectangle2D var23 = var16.createInsetRectangle(var20, true, false);
//     java.lang.Object var25 = var12.draw(var13, var20, (java.lang.Object)"WMAP_Plot");
//     var3.addSubtitle((org.jfree.chart.title.Title)var12);
//     org.jfree.data.general.WaferMapDataset var27 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var28 = null;
//     org.jfree.chart.plot.WaferMapPlot var29 = new org.jfree.chart.plot.WaferMapPlot(var27, var28);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var29);
//     java.awt.Image var31 = null;
//     var30.setBackgroundImage(var31);
//     org.jfree.chart.title.TextTitle var33 = null;
//     var30.setTitle(var33);
//     var30.setAntiAlias(false);
//     float var37 = var30.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var38 = var30.getLegend();
//     var38.setHeight(0.0d);
//     var38.setMargin(10.0d, 2.0d, 0.2d, (-10.0d));
//     org.jfree.chart.util.RectangleEdge var46 = var38.getPosition();
//     var12.setPosition(var46);
//     
//     // Checks the contract:  equals-hashcode on var2 and var29
//     assertTrue("Contract failed: equals-hashcode on var2 and var29", var2.equals(var29) ? var2.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var2
//     assertTrue("Contract failed: equals-hashcode on var29 and var2", var29.equals(var2) ? var29.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var0.getValue(0, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     var3.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var7 = var3.getPadding();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var9 = var8.getToolTipText();
//     var8.setToolTipText("XY Plot");
//     var3.setTitle(var8);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var14 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var15 = var14.clone();
//     java.awt.Paint var16 = var14.getBasePaint();
//     boolean var17 = var14.getBaseSeriesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var20 = var19.getCategoryLabelPositionOffset();
//     java.awt.Paint var21 = var19.getAxisLinePaint();
//     java.awt.Stroke var22 = var19.getTickMarkStroke();
//     var14.setBaseStroke(var22, true);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var28 = var27.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var35 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var36 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var37 = var36.clone();
//     java.awt.Paint var38 = var36.getBasePaint();
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var35, var38);
//     var29.setSeriesOutlinePaint(0, var38, true);
//     boolean var42 = var27.equals((java.lang.Object)var38);
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var45 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var46 = var45.getChartArea();
//     var44.setLegendItemShape((java.awt.Shape)var46);
//     var27.setSeriesShape(4, (java.awt.Shape)var46);
//     var14.setBaseShape((java.awt.Shape)var46, true);
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var51, var52, var53, var54);
//     org.jfree.chart.util.Layer var57 = null;
//     java.util.Collection var58 = var55.getRangeMarkers(0, var57);
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.data.Range var60 = var55.getDataRange(var59);
//     org.jfree.chart.axis.AxisSpace var61 = null;
//     var55.setFixedDomainAxisSpace(var61);
//     java.awt.Paint var63 = null;
//     var55.setRangeTickBandPaint(var63);
//     java.awt.geom.Point2D var65 = var55.getQuadrantOrigin();
//     org.jfree.chart.ChartRenderingInfo var66 = new org.jfree.chart.ChartRenderingInfo();
//     var3.draw(var13, var46, var65, var66);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    boolean var3 = var0.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getURLGenerator(100, 4);
    java.awt.Font var8 = null;
    var0.setSeriesItemLabelFont(0, var8, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
    var0.setSeriesItemLabelGenerator(0, var12);
    org.jfree.chart.labels.CategoryToolTipGenerator var15 = var0.getSeriesToolTipGenerator(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    double var3 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    int var10 = var8.getDatasetIndex();
    java.text.AttributedString var11 = var8.getAttributedLabel();
    boolean var12 = var8.isShapeVisible();
    java.awt.Shape var13 = var8.getLine();
    java.lang.String var14 = var8.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    java.lang.Object var0 = null;
    java.lang.Object var1 = null;
    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.util.Layer var11 = null;
    java.util.Collection var12 = var4.getDomainMarkers(var11);
    org.jfree.data.xy.XYDataset var14 = null;
    var4.setDataset(1900, var14);
    var4.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var7 = var4.isOnOrBefore((org.jfree.data.time.SerialDate)var6);
    boolean var8 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
    int var11 = var10.getYYYY();
    org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var18 = var15.isOnOrBefore((org.jfree.data.time.SerialDate)var17);
    boolean var19 = var13.isOnOrAfter((org.jfree.data.time.SerialDate)var17);
    boolean var20 = var2.isInRange((org.jfree.data.time.SerialDate)var10, (org.jfree.data.time.SerialDate)var17);
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var2);
    java.lang.String var22 = var21.getDescription();
    var21.setDescription("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelWidthType var1 = var0.getWidthType();
//     org.jfree.data.Range var2 = null;
//     org.jfree.data.Range var3 = null;
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, var3);
//     org.jfree.chart.block.RectangleConstraint var6 = var4.toFixedWidth(12.0d);
//     boolean var7 = var1.equals((java.lang.Object)var6);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, var12, var13, var14);
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var17 = var16.getLabelOutlinePaint();
//     var15.setRangeCrosshairPaint(var17);
//     int var19 = var15.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
//     var15.setFixedRangeAxisSpace(var20);
//     org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
//     var15.setFixedRangeAxisSpace(var22);
//     org.jfree.chart.axis.CategoryAxis var25 = var15.getDomainAxisForDataset(0);
//     org.jfree.chart.util.RectangleEdge var26 = var15.getDomainAxisEdge();
//     boolean var27 = var1.equals((java.lang.Object)var15);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var28 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var28, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var28, var32, var33, var34);
//     java.lang.Comparable var37 = null;
//     java.lang.Number var38 = var28.getMinRegularValue((java.lang.Comparable)"Category Plot", var37);
//     var15.setDataset((org.jfree.data.category.CategoryDataset)var28);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    org.jfree.chart.title.TextTitle var6 = null;
    var3.setTitle(var6);
    var3.setAntiAlias(false);
    float var10 = var3.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
    var11.setHeight(0.0d);
    org.jfree.chart.block.BlockContainer var14 = var11.getItemContainer();
    org.jfree.chart.block.BlockFrame var15 = var14.getFrame();
    org.jfree.chart.block.BlockFrame var16 = var14.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    double var2 = var0.getMinimumArcAngleToDraw();
    double var3 = var0.getMinimumArcAngleToDraw();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0E-5d);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var9 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var11 = var10.clone();
    java.awt.Paint var12 = var10.getBasePaint();
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var9, var12);
    var3.setSeriesOutlinePaint(0, var12, true);
    var0.setBackgroundPaint(var12);
    java.lang.Comparable var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setExplodePercent(var17, 3.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Stroke var4 = var3.getBorderStroke();
    var3.setAntiAlias(false);
    var3.setBackgroundImageAlignment(3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.annotations.XYAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var4.removeAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
//     org.jfree.chart.util.SortOrder var13 = var7.getRowRenderingOrder();
//     java.awt.Paint var14 = var7.getRangeGridlinePaint();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var17, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, var21, var22, var23);
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var26 = var25.getLabelOutlinePaint();
//     var24.setRangeCrosshairPaint(var26);
//     int var28 = var24.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
//     var24.setFixedRangeAxisSpace(var29);
//     org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
//     var24.setFixedRangeAxisSpace(var31);
//     java.lang.String var33 = var24.getPlotType();
//     org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var37 = var36.getChartArea();
//     java.lang.Object var38 = var36.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     var24.handleClick(1900, 0, var39);
//     org.jfree.data.xy.XYDataset var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
//     double var46 = var45.getDomainCrosshairValue();
//     int var47 = var45.getSeriesCount();
//     java.awt.geom.Point2D var48 = var45.getQuadrantOrigin();
//     var7.zoomDomainAxes((-1.0d), 10.0d, var39, var48);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, 10.0d);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
//     org.jfree.chart.util.SortOrder var13 = var7.getRowRenderingOrder();
//     java.awt.Paint var14 = var7.getRangeGridlinePaint();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var15 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var16 = var15.clone();
//     java.awt.Paint var17 = var15.getBasePaint();
//     boolean var18 = var15.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var21 = var15.getURLGenerator(100, 4);
//     java.awt.Font var23 = null;
//     var15.setSeriesItemLabelFont(0, var23, true);
//     java.awt.Paint var26 = var15.getBasePaint();
//     var7.setBackgroundPaint(var26);
//     var7.clearRangeMarkers();
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var36 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var38 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var36, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var36, var40, var41, var42);
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var45 = var44.getLabelOutlinePaint();
//     var43.setRangeCrosshairPaint(var45);
//     var35.setDomainTickBandPaint(var45);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var48 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var51 = var48.isItemLabelVisible(1, 0);
//     org.jfree.data.general.WaferMapDataset var53 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var54 = null;
//     org.jfree.chart.plot.WaferMapPlot var55 = new org.jfree.chart.plot.WaferMapPlot(var53, var54);
//     org.jfree.chart.JFreeChart var56 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var55);
//     java.awt.Stroke var57 = var56.getBorderStroke();
//     var48.setSeriesStroke(100, var57, true);
//     org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(0.0d, var45, var57);
//     org.jfree.chart.util.LengthAdjustmentType var61 = var60.getLabelOffsetType();
//     java.awt.Paint var62 = var60.getOutlinePaint();
//     org.jfree.chart.util.Layer var63 = null;
//     var7.addRangeMarker(10, (org.jfree.chart.plot.Marker)var60, var63);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var15 and var48.", var15.equals(var48) == var48.equals(var15));
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var5 = var3.getSegment(100L);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var13 = var10.isOnOrBefore((org.jfree.data.time.SerialDate)var12);
//     boolean var14 = var8.isOnOrAfter((org.jfree.data.time.SerialDate)var12);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var17 = var16.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var24 = var21.isOnOrBefore((org.jfree.data.time.SerialDate)var23);
//     boolean var25 = var19.isOnOrAfter((org.jfree.data.time.SerialDate)var23);
//     boolean var26 = var8.isInRange((org.jfree.data.time.SerialDate)var16, (org.jfree.data.time.SerialDate)var23);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var8);
//     java.util.Date var28 = var8.toDate();
//     boolean var29 = var3.containsDomainValue(var28);
//     java.util.TimeZone var30 = null;
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year(var28, var30);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorUp(10.0d);
    java.util.List var3 = var0.getTicks();
    org.jfree.chart.util.RectangleEdge var5 = null;
    var0.moveCursor(0.0d, var5);
    var0.cursorRight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     double var1 = var0.getMaxRadius();
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("black");

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("ChartEntity: tooltip = XY Plot");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var3 = var1.get(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    var7.setRenderer(var8, true);
    var7.clearDomainMarkers(10);
    org.jfree.chart.axis.CategoryAnchor var13 = var7.getDomainGridlinePosition();
    org.jfree.chart.axis.AxisState var14 = new org.jfree.chart.axis.AxisState();
    var14.cursorUp(10.0d);
    java.util.List var17 = var14.getTicks();
    var14.cursorRight(10.0d);
    var14.cursorLeft(100.0d);
    boolean var22 = var13.equals((java.lang.Object)100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
//     java.awt.Paint var10 = var4.getRangeCrosshairPaint();
//     double var11 = var4.getDomainCrosshairValue();
//     var4.setRangeZeroBaselineVisible(true);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var18 = var17.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var25 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var27 = var26.clone();
//     java.awt.Paint var28 = var26.getBasePaint();
//     org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var25, var28);
//     var19.setSeriesOutlinePaint(0, var28, true);
//     boolean var32 = var17.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var35 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var36 = var35.getChartArea();
//     var34.setLegendItemShape((java.awt.Shape)var36);
//     var17.setSeriesShape(4, (java.awt.Shape)var36);
//     var4.drawBackground(var14, var36);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var6 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var8 = var7.clone();
//     java.awt.Paint var9 = var7.getBasePaint();
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var6, var9);
//     var0.setSeriesOutlinePaint(0, var9, true);
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var16 = var15.getCategoryLabelPositionOffset();
//     java.awt.Paint var17 = var15.getAxisLinePaint();
//     var0.setSeriesItemLabelPaint(0, var17, true);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var21 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var21, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var21, var25, var26, var27);
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var30 = var29.getLabelOutlinePaint();
//     var28.setRangeCrosshairPaint(var30);
//     int var32 = var28.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var33 = new org.jfree.chart.axis.AxisSpace();
//     var28.setFixedRangeAxisSpace(var33);
//     org.jfree.chart.axis.AxisSpace var35 = new org.jfree.chart.axis.AxisSpace();
//     var28.setFixedRangeAxisSpace(var35);
//     org.jfree.chart.axis.CategoryAxis var38 = var28.getDomainAxisForDataset(0);
//     org.jfree.chart.util.RectangleEdge var39 = var28.getDomainAxisEdge();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var46 = var45.getNumberFormatOverride();
//     org.jfree.data.Range var49 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange(var49);
//     var45.setRangeWithMargins((org.jfree.data.Range)var50);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var54 = var53.getLabelInsets();
//     double var56 = var54.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var57 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var58 = var57.getChartArea();
//     java.awt.geom.Rectangle2D var61 = var54.createInsetRectangle(var58, true, false);
//     var45.setDownArrow((java.awt.Shape)var61);
//     var42.setSeriesShape(13, (java.awt.Shape)var61, false);
//     var0.drawOutline(var20, var28, var61);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("black");

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Paint var2 = var0.getBasePaint();
//     boolean var3 = var0.getBaseSeriesVisible();
//     double var4 = var0.getBase();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var9 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var10 = var9.getObjectIcon();
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var11 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var12 = var11.getObjectIcon();
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var13 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var14 = var13.getObjectIcon();
//     var11.setMaxIcon(var14);
//     var9.setObjectIcon(var14);
//     boolean var19 = var9.isItemLabelVisible(10, (-1));
//     boolean var20 = var8.equals((java.lang.Object)10);
//     var0.setSeriesPositiveItemLabelPosition(1900, var8);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var5 = var3.getSegment(100L);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var10, var11, var12);
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var15 = var14.getLabelOutlinePaint();
//     var13.setRangeCrosshairPaint(var15);
//     int var17 = var13.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var18 = new org.jfree.chart.axis.AxisSpace();
//     var13.setFixedRangeAxisSpace(var18);
//     org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
//     var13.setFixedRangeAxisSpace(var20);
//     java.lang.String var22 = var13.getPlotType();
//     boolean var23 = var13.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var26 = var25.getTickMarkStroke();
//     java.lang.Object var27 = var25.clone();
//     java.util.List var28 = var13.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var25);
//     var3.setExceptionSegments(var28);
//     org.jfree.chart.axis.SegmentedTimeline var33 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var35 = var33.getSegment(100L);
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var43 = var40.isOnOrBefore((org.jfree.data.time.SerialDate)var42);
//     boolean var44 = var38.isOnOrAfter((org.jfree.data.time.SerialDate)var42);
//     org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var47 = var46.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var54 = var51.isOnOrBefore((org.jfree.data.time.SerialDate)var53);
//     boolean var55 = var49.isOnOrAfter((org.jfree.data.time.SerialDate)var53);
//     boolean var56 = var38.isInRange((org.jfree.data.time.SerialDate)var46, (org.jfree.data.time.SerialDate)var53);
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var38);
//     java.util.Date var58 = var38.toDate();
//     boolean var59 = var33.containsDomainValue(var58);
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(var58);
//     var3.addBaseTimelineException(var58);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Last"+ "'", var1.equals("Last"));

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var26 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var28 = var27.clone();
//     java.awt.Paint var29 = var27.getBasePaint();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var26, var29);
//     var20.setSeriesOutlinePaint(0, var29, true);
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var29, 0.0f, var34);
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var37 = null;
//     var36.setLabelOutlinePaint(var37);
//     java.awt.Stroke var39 = var36.getLabelOutlineStroke();
//     java.awt.Paint var40 = var36.getLabelPaint();
//     org.jfree.chart.text.TextLine var41 = new org.jfree.chart.text.TextLine("", var14, var40);
//     org.jfree.chart.text.TextFragment var42 = var41.getFirstTextFragment();
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var46.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var49 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var51 = var49.getSeriesNegativeItemLabelPosition((-1));
//     var46.setBasePositiveItemLabelPosition(var51, true);
//     org.jfree.chart.text.TextAnchor var54 = var51.getTextAnchor();
//     boolean var56 = var54.equals((java.lang.Object)"hi!");
//     java.lang.Object var57 = null;
//     boolean var58 = var54.equals(var57);
//     var42.draw(var43, (-1.0f), 0.0f, var54, (-1.0f), 100.0f, 0.0d);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.List var6 = var0.getOutliers(0, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
//     java.awt.Paint var10 = var4.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var12 = var4.getRangeAxisLocation(1);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.data.DefaultKeyedValues2D var15 = new org.jfree.data.DefaultKeyedValues2D();
//     var15.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
//     java.lang.Number var20 = null;
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var28 = var25.isOnOrBefore((org.jfree.data.time.SerialDate)var27);
//     boolean var29 = var23.isOnOrAfter((org.jfree.data.time.SerialDate)var27);
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var32 = var31.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var39 = var36.isOnOrBefore((org.jfree.data.time.SerialDate)var38);
//     boolean var40 = var34.isOnOrAfter((org.jfree.data.time.SerialDate)var38);
//     boolean var41 = var23.isInRange((org.jfree.data.time.SerialDate)var31, (org.jfree.data.time.SerialDate)var38);
//     var15.addValue(var20, (java.lang.Comparable)' ', (java.lang.Comparable)var23);
//     java.util.List var43 = var15.getColumnKeys();
//     java.util.List var44 = var15.getColumnKeys();
//     var4.drawDomainTickBands(var13, var14, var44);
//     org.jfree.chart.plot.Marker var47 = null;
//     org.jfree.chart.util.Layer var48 = null;
//     var4.addRangeMarker(1900, var47, var48);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var4 = var1.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var6 = null;
    org.jfree.chart.renderer.WaferMapRenderer var7 = null;
    org.jfree.chart.plot.WaferMapPlot var8 = new org.jfree.chart.plot.WaferMapPlot(var6, var7);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    java.awt.Stroke var10 = var9.getBorderStroke();
    var1.setSeriesStroke(100, var10, true);
    java.awt.Paint var14 = var1.getSeriesItemLabelPaint(0);
    boolean var15 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var17 = var16.getUseOutlinePaint();
    org.jfree.chart.labels.ItemLabelPosition var19 = var16.getSeriesNegativeItemLabelPosition(1900);
    var1.setBasePositiveItemLabelPosition(var19, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    java.awt.Paint var11 = null;
    var4.setDomainTickBandPaint(var11);
    java.awt.Paint var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeGridlinePaint(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var13 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var13, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var17, var18, var19);
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var22 = var21.getLabelOutlinePaint();
    var20.setRangeCrosshairPaint(var22);
    int var24 = var20.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var25 = new org.jfree.chart.axis.AxisSpace();
    var20.setFixedRangeAxisSpace(var25);
    org.jfree.chart.axis.AxisSpace var27 = new org.jfree.chart.axis.AxisSpace();
    var20.setFixedRangeAxisSpace(var27);
    var4.setFixedRangeAxisSpace(var27);
    double var30 = var27.getBottom();
    java.lang.Object var31 = var27.clone();
    var27.setTop(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
    long var5 = var3.toMillisecond(1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1L);

  }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.xy.XYDataset var1 = var0.getDataset();
//     java.awt.Stroke var2 = var0.getAngleGridlineStroke();
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
//     java.awt.Stroke var7 = var6.getBorderStroke();
//     var0.setRadiusGridlineStroke(var7);
//     java.awt.Paint var9 = var0.getAngleGridlinePaint();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var13 = var12.clone();
//     java.awt.Paint var14 = var12.getBasePaint();
//     boolean var15 = var12.getBaseSeriesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var18 = var17.getCategoryLabelPositionOffset();
//     java.awt.Paint var19 = var17.getAxisLinePaint();
//     java.awt.Stroke var20 = var17.getTickMarkStroke();
//     var12.setBaseStroke(var20, true);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var26 = var25.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var33 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var35 = var34.clone();
//     java.awt.Paint var36 = var34.getBasePaint();
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var33, var36);
//     var27.setSeriesOutlinePaint(0, var36, true);
//     boolean var40 = var25.equals((java.lang.Object)var36);
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var43 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var44 = var43.getChartArea();
//     var42.setLegendItemShape((java.awt.Shape)var44);
//     var25.setSeriesShape(4, (java.awt.Shape)var44);
//     var12.setBaseShape((java.awt.Shape)var44, true);
//     org.jfree.chart.util.RectangleEdge var49 = null;
//     double var50 = org.jfree.chart.util.RectangleEdge.coordinate(var44, var49);
//     java.awt.Point var51 = var0.translateValueThetaRadiusToJava2D((-1.0d), 0.05d, var44);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = var0.getChartArea();
//     java.lang.Object var2 = var0.clone();
//     java.lang.Object var3 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("Last", var1, var2, var3);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var4 = var3.clone();
    java.awt.Paint var5 = var3.getBasePaint();
    boolean var6 = var3.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
    java.awt.Font var11 = null;
    var3.setSeriesItemLabelFont(0, var11, true);
    java.awt.Font var14 = var3.getBaseItemLabelFont();
    java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var26 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var28 = var27.clone();
    java.awt.Paint var29 = var27.getBasePaint();
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var26, var29);
    var20.setSeriesOutlinePaint(0, var29, true);
    org.jfree.chart.text.TextMeasurer var34 = null;
    org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var29, 0.0f, var34);
    org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var37 = null;
    var36.setLabelOutlinePaint(var37);
    java.awt.Stroke var39 = var36.getLabelOutlineStroke();
    java.awt.Paint var40 = var36.getLabelPaint();
    org.jfree.chart.text.TextLine var41 = new org.jfree.chart.text.TextLine("", var14, var40);
    org.jfree.chart.text.TextFragment var42 = var41.getFirstTextFragment();
    float var43 = var42.getBaselineOffset();
    java.awt.Paint var44 = var42.getPaint();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var45 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var46 = var45.clone();
    org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var53 = var50.isOnOrBefore((org.jfree.data.time.SerialDate)var52);
    boolean var54 = var48.isOnOrAfter((org.jfree.data.time.SerialDate)var52);
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    int var57 = var56.getYYYY();
    org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var64 = var61.isOnOrBefore((org.jfree.data.time.SerialDate)var63);
    boolean var65 = var59.isOnOrAfter((org.jfree.data.time.SerialDate)var63);
    boolean var66 = var48.isInRange((org.jfree.data.time.SerialDate)var56, (org.jfree.data.time.SerialDate)var63);
    boolean var67 = var45.equals((java.lang.Object)var56);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var68 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var70 = var68.getSeriesNegativeItemLabelPosition((-1));
    var45.setBasePositiveItemLabelPosition(var70);
    boolean var72 = var42.equals((java.lang.Object)var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.data.Range var2 = new org.jfree.data.Range(Double.NaN, (-10.0d));
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("rect");

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var12 = var4.getRangeAxisLocation(1);
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.data.DefaultKeyedValues2D var15 = new org.jfree.data.DefaultKeyedValues2D();
    var15.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var20 = null;
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var28 = var25.isOnOrBefore((org.jfree.data.time.SerialDate)var27);
    boolean var29 = var23.isOnOrAfter((org.jfree.data.time.SerialDate)var27);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    int var32 = var31.getYYYY();
    org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var39 = var36.isOnOrBefore((org.jfree.data.time.SerialDate)var38);
    boolean var40 = var34.isOnOrAfter((org.jfree.data.time.SerialDate)var38);
    boolean var41 = var23.isInRange((org.jfree.data.time.SerialDate)var31, (org.jfree.data.time.SerialDate)var38);
    var15.addValue(var20, (java.lang.Comparable)' ', (java.lang.Comparable)var23);
    java.util.List var43 = var15.getColumnKeys();
    java.util.List var44 = var15.getColumnKeys();
    var4.drawDomainTickBands(var13, var14, var44);
    org.jfree.data.xy.XYDataset var46 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = var4.getRendererForDataset(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isRangeCrosshairVisible();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, var12, var13, var14);
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var17 = var16.getLabelOutlinePaint();
    var15.setRangeCrosshairPaint(var17);
    int var19 = var15.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
    var15.setFixedRangeAxisSpace(var20);
    org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
    var15.setFixedRangeAxisSpace(var22);
    java.lang.String var24 = var15.getPlotType();
    java.awt.Paint var25 = var15.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var28 = var27.getTickMarkStroke();
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var30 = null;
    var29.setLabelOutlinePaint(var30);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var38 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var39 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var40 = var39.clone();
    java.awt.Paint var41 = var39.getBasePaint();
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var38, var41);
    var32.setSeriesOutlinePaint(0, var41, true);
    var29.setBackgroundPaint(var41);
    java.awt.Stroke var46 = null;
    org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var25, var28, var41, var46, 0.0f);
    var4.setRangeGridlinePaint(var25);
    org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
    var4.setRenderer(4, var51, true);
    var4.setOutlineVisible(true);
    java.awt.Paint var56 = var4.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Category Plot"+ "'", var24.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var20 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var22 = var21.clone();
    java.awt.Paint var23 = var21.getBasePaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var20, var23);
    var14.setSeriesOutlinePaint(0, var23, true);
    var7.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    var7.setRangeCrosshairValue(2.0d, false);
    java.awt.Color var35 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    int var36 = var35.getAlpha();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var37 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var37, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var37, var41, var42, var43);
    org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var46 = var45.getLabelOutlinePaint();
    var44.setRangeCrosshairPaint(var46);
    int var48 = var44.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var49 = new org.jfree.chart.axis.AxisSpace();
    var44.setFixedRangeAxisSpace(var49);
    org.jfree.chart.axis.AxisSpace var51 = new org.jfree.chart.axis.AxisSpace();
    var44.setFixedRangeAxisSpace(var51);
    var44.setRangeCrosshairValue(4.0d);
    org.jfree.chart.plot.PiePlot var55 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var56 = null;
    var55.setLabelOutlinePaint(var56);
    java.awt.Stroke var58 = var55.getLabelOutlineStroke();
    java.awt.Paint var59 = var55.getLabelPaint();
    org.jfree.data.general.WaferMapDataset var60 = null;
    org.jfree.chart.renderer.WaferMapRenderer var61 = null;
    org.jfree.chart.plot.WaferMapPlot var62 = new org.jfree.chart.plot.WaferMapPlot(var60, var61);
    org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var62);
    java.awt.Stroke var64 = var62.getOutlineStroke();
    var55.setBaseSectionOutlineStroke(var64);
    var44.setDomainGridlineStroke(var64);
    org.jfree.chart.plot.CategoryMarker var67 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(short)0, (java.awt.Paint)var35, var64);
    org.jfree.chart.util.Layer var68 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.addDomainMarker(var67, var68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var5 = var2.isOnOrBefore((org.jfree.data.time.SerialDate)var4);
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var12 = var9.isOnOrBefore((org.jfree.data.time.SerialDate)var11);
    boolean var13 = var7.isOnOrAfter((org.jfree.data.time.SerialDate)var11);
    boolean var14 = var4.isBefore((org.jfree.data.time.SerialDate)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(13, (org.jfree.data.time.SerialDate)var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var11.setTitle("ThreadContext");
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var11.setBorderPaint((java.awt.Paint)var18);
    var7.setRangeGridlinePaint((java.awt.Paint)var18);
    float[] var22 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var23 = var18.getComponents(var22);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.category.CategoryDataset var4 = var3.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    var2.setRenderer(var3);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     var11.setHeight(0.0d);
//     org.jfree.chart.util.RectangleAnchor var14 = var11.getLegendItemGraphicLocation();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var17 = var16.getLabelInsets();
//     double var19 = var17.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var21 = var20.getChartArea();
//     java.awt.geom.Rectangle2D var24 = var17.createInsetRectangle(var21, true, false);
//     var11.setPadding(var17);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var28 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var29 = var28.getChartArea();
//     var27.setLegendItemShape((java.awt.Shape)var29);
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var32 = null;
//     var31.setLabelOutlinePaint(var32);
//     java.awt.Stroke var34 = var31.getLabelOutlineStroke();
//     java.awt.Paint var35 = var31.getLabelPaint();
//     org.jfree.data.general.DatasetChangeEvent var36 = null;
//     var31.datasetChanged(var36);
//     java.lang.Object var38 = var11.draw(var26, var29, (java.lang.Object)var36);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    int var10 = var8.getDatasetIndex();
    java.text.AttributedString var11 = var8.getAttributedLabel();
    boolean var12 = var8.isShapeVisible();
    boolean var13 = var8.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition((-1));
//     var1.setNegativeItemLabelPositionFallback(var4);
//     java.awt.Font var6 = var1.getBaseItemLabelFont();
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.urls.PieURLGenerator var8 = var7.getURLGenerator();
//     java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     var7.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var13);
//     java.awt.color.ColorSpace var15 = var13.getColorSpace();
//     org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("Category Plot", var6, (java.awt.Paint)var13);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var17 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition((-1));
//     var17.setNegativeItemLabelPositionFallback(var20);
//     double var22 = var17.getLowerClip();
//     org.jfree.chart.util.GradientPaintTransformer var23 = var17.getGradientPaintTransformer();
//     boolean var24 = var16.equals((java.lang.Object)var17);
//     
//     // Checks the contract:  equals-hashcode on var4 and var20
//     assertTrue("Contract failed: equals-hashcode on var4 and var20", var4.equals(var20) ? var4.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var4
//     assertTrue("Contract failed: equals-hashcode on var20 and var4", var20.equals(var4) ? var20.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    java.awt.Stroke var4 = var2.getSeriesOutlineStroke(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setSeriesShapesVisible(1, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var6 = var0.equals((java.lang.Object)var5);
    boolean var9 = var5.getItemShapeVisible(3, (-1));
    java.awt.Paint var12 = var5.getItemFillPaint(4, 1);
    var5.setSeriesShapesFilled(100, true);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var17 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var18 = var17.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var19 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var20 = var19.getObjectIcon();
    var17.setMaxIcon(var20);
    java.awt.Stroke var22 = var17.getGroupStroke();
    var5.setSeriesOutlineStroke(0, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, true);
//     double var7 = var0.getRangeUpperBound(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.chart.util.Layer var17 = null;
//     java.util.Collection var18 = var15.getRangeMarkers(0, var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.data.Range var20 = var15.getDataRange(var19);
//     org.jfree.chart.axis.AxisSpace var21 = null;
//     var15.setFixedDomainAxisSpace(var21);
//     java.awt.Paint var23 = null;
//     var15.setRangeTickBandPaint(var23);
//     java.awt.geom.Point2D var25 = var15.getQuadrantOrigin();
//     var7.zoomRangeAxes(10.0d, 0.0d, var10, var25);
//     var7.setAnchorValue((-1.0d), true);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     var35.zoomDomainAxes((-1.0d), 0.2d, var38, var39);
//     java.awt.Paint var41 = var35.getRangeCrosshairPaint();
//     org.jfree.chart.event.RendererChangeEvent var42 = null;
//     var35.rendererChanged(var42);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     java.awt.geom.Point2D var52 = null;
//     var48.zoomDomainAxes((-1.0d), 0.2d, var51, var52);
//     java.awt.Paint var54 = var48.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var56 = var48.getRangeAxisLocation(1);
//     var35.setDomainAxisLocation(var56);
//     var7.setDomainAxisLocation(3, var56, false);
//     
//     // Checks the contract:  equals-hashcode on var15 and var48
//     assertTrue("Contract failed: equals-hashcode on var15 and var48", var15.equals(var48) ? var15.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var15
//     assertTrue("Contract failed: equals-hashcode on var48 and var15", var48.equals(var15) ? var48.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D();
    var1.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var6 = null;
    org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var14 = var11.isOnOrBefore((org.jfree.data.time.SerialDate)var13);
    boolean var15 = var9.isOnOrAfter((org.jfree.data.time.SerialDate)var13);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
    int var18 = var17.getYYYY();
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
    boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
    boolean var27 = var9.isInRange((org.jfree.data.time.SerialDate)var17, (org.jfree.data.time.SerialDate)var24);
    var1.addValue(var6, (java.lang.Comparable)' ', (java.lang.Comparable)var9);
    var9.setDescription("black");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), (org.jfree.data.time.SerialDate)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, var6, var7, var8);
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var11 = var10.getLabelOutlinePaint();
    var9.setRangeCrosshairPaint(var11);
    int var13 = var9.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var9.setFixedRangeAxisSpace(var14);
    org.jfree.chart.axis.AxisSpace var16 = new org.jfree.chart.axis.AxisSpace();
    var9.setFixedRangeAxisSpace(var16);
    java.lang.String var18 = var9.getPlotType();
    java.awt.Paint var19 = var9.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var22 = var21.getTickMarkStroke();
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var24 = null;
    var23.setLabelOutlinePaint(var24);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var32 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var34 = var33.clone();
    java.awt.Paint var35 = var33.getBasePaint();
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
    var26.setSeriesOutlinePaint(0, var35, true);
    var23.setBackgroundPaint(var35);
    java.awt.Stroke var40 = null;
    org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var19, var22, var35, var40, 0.0f);
    org.jfree.chart.util.RectangleAnchor var43 = var42.getLabelAnchor();
    org.jfree.chart.util.LengthAdjustmentType var44 = var42.getLabelOffsetType();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var47 = null;
    var45.setSeriesItemLabelGenerator(1900, var47);
    org.jfree.chart.labels.ItemLabelPosition var49 = var45.getBasePositiveItemLabelPosition();
    boolean var50 = var44.equals((java.lang.Object)var45);
    java.lang.String var51 = var44.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "Category Plot"+ "'", var18.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "CONTRACT"+ "'", var51.equals("CONTRACT"));

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    org.jfree.chart.title.TextTitle var6 = null;
    var3.setTitle(var6);
    var3.setAntiAlias(false);
    float var10 = var3.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
    java.awt.Paint var12 = var11.getBackgroundPaint();
    org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
    var11.setFrame((org.jfree.chart.block.BlockFrame)var17);
    org.jfree.chart.block.BlockContainer var19 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BlockFrame var20 = var19.getFrame();
    var11.setFrame(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)10.0d);
//     boolean var23 = var20.getLabelLinksVisible();
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", var14, (org.jfree.chart.plot.Plot)var20, false);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var30, var31, var32);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var41.getRangeMarkers(0, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.data.Range var46 = var41.getDataRange(var45);
//     org.jfree.chart.axis.AxisSpace var47 = null;
//     var41.setFixedDomainAxisSpace(var47);
//     java.awt.Paint var49 = null;
//     var41.setRangeTickBandPaint(var49);
//     java.awt.geom.Point2D var51 = var41.getQuadrantOrigin();
//     var33.zoomRangeAxes(10.0d, 0.0d, var36, var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var33, false);
//     boolean var55 = var33.getDrawSharedDomainAxis();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var56 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var58 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var56, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var56, var60, var61, var62);
//     org.jfree.chart.plot.PiePlot var64 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var65 = var64.getLabelOutlinePaint();
//     var63.setRangeCrosshairPaint(var65);
//     int var67 = var63.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var68 = new org.jfree.chart.axis.AxisSpace();
//     var63.setFixedRangeAxisSpace(var68);
//     org.jfree.chart.axis.AxisSpace var70 = new org.jfree.chart.axis.AxisSpace();
//     var63.setFixedRangeAxisSpace(var70);
//     org.jfree.chart.axis.CategoryAxis var73 = var63.getDomainAxisForDataset(0);
//     var73.setUpperMargin(10.0d);
//     org.jfree.chart.axis.CategoryAxis[] var76 = new org.jfree.chart.axis.CategoryAxis[] { var73};
//     var33.setDomainAxes(var76);
//     
//     // Checks the contract:  equals-hashcode on var20 and var64
//     assertTrue("Contract failed: equals-hashcode on var20 and var64", var20.equals(var64) ? var20.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var20
//     assertTrue("Contract failed: equals-hashcode on var64 and var20", var64.equals(var20) ? var64.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var56
//     assertTrue("Contract failed: equals-hashcode on var26 and var56", var26.equals(var56) ? var26.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var26
//     assertTrue("Contract failed: equals-hashcode on var56 and var26", var56.equals(var26) ? var56.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var4.getRangeMarkers(var8);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var11 = var10.clone();
    java.awt.Paint var12 = var10.getBasePaint();
    boolean var13 = var10.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var16 = var10.getURLGenerator(100, 4);
    java.awt.Font var18 = null;
    var10.setSeriesItemLabelFont(0, var18, true);
    java.awt.Paint var21 = var10.getBasePaint();
    var4.setDomainGridlinePaint(var21);
    int var23 = var4.getWeight();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var26 = var25.getNumberFormatOverride();
    int var27 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
    java.awt.Font var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.setTickLabelFont(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    var0.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    int var6 = var0.getColumnIndex((java.lang.Comparable)(byte)0);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var6 = var5.clone();
//     java.awt.Paint var7 = var5.getBasePaint();
//     boolean var8 = var5.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var11 = var5.getURLGenerator(100, 4);
//     java.awt.Font var13 = null;
//     var5.setSeriesItemLabelFont(0, var13, true);
//     java.awt.Font var16 = var5.getBaseItemLabelFont();
//     java.awt.Color var20 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var20);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var28 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var29 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var30 = var29.clone();
//     java.awt.Paint var31 = var29.getBasePaint();
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var28, var31);
//     var22.setSeriesOutlinePaint(0, var31, true);
//     org.jfree.chart.text.TextMeasurer var36 = null;
//     org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, var31, 0.0f, var36);
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var39 = null;
//     var38.setLabelOutlinePaint(var39);
//     java.awt.Stroke var41 = var38.getLabelOutlineStroke();
//     java.awt.Paint var42 = var38.getLabelPaint();
//     org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("", var16, var42);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var44 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var44, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var44, var48, var49, var50);
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
//     org.jfree.chart.util.Layer var61 = null;
//     java.util.Collection var62 = var59.getRangeMarkers(0, var61);
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.data.Range var64 = var59.getDataRange(var63);
//     org.jfree.chart.axis.AxisSpace var65 = null;
//     var59.setFixedDomainAxisSpace(var65);
//     java.awt.Paint var67 = null;
//     var59.setRangeTickBandPaint(var67);
//     java.awt.geom.Point2D var69 = var59.getQuadrantOrigin();
//     var51.zoomRangeAxes(10.0d, 0.0d, var54, var69);
//     org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart("hi!", var16, (org.jfree.chart.plot.Plot)var51, false);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var73 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.chart.plot.MultiplePiePlot var74 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var73);
//     org.jfree.chart.plot.PiePlot var75 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var76 = null;
//     var75.setLabelOutlinePaint(var76);
//     java.awt.Stroke var78 = var75.getLabelOutlineStroke();
//     var74.setOutlineStroke(var78);
//     java.awt.Paint var80 = var74.getAggregatedItemsPaint();
//     org.jfree.chart.text.TextMeasurer var83 = null;
//     org.jfree.chart.text.TextBlock var84 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var16, var80, 0.0f, 0, var83);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var2 = null;
    var1.setLabelOutlinePaint(var2);
    java.awt.Stroke var4 = var1.getLabelOutlineStroke();
    java.awt.Paint var5 = var1.getLabelPaint();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    double var7 = var1.getLabelGap();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var8 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var9 = var8.clone();
    java.awt.Paint var10 = var8.getBasePaint();
    var1.setLabelPaint(var10);
    var1.setMinimumArcAngleToDraw(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition((-1));
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var8 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var9 = var8.clone();
    java.awt.Paint var10 = var8.getBasePaint();
    boolean var11 = var8.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var14 = var8.getURLGenerator(100, 4);
    java.awt.Font var16 = null;
    var8.setSeriesItemLabelFont(0, var16, true);
    java.awt.Font var19 = var8.getBaseItemLabelFont();
    java.awt.Color var23 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var23);
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var27 = var25.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var28 = var25.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", var19, (org.jfree.chart.plot.Plot)var25, false);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var31, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var31, var35, var36, var37);
    org.jfree.chart.plot.PlotRenderingInfo var41 = null;
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    org.jfree.chart.util.Layer var48 = null;
    java.util.Collection var49 = var46.getRangeMarkers(0, var48);
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.data.Range var51 = var46.getDataRange(var50);
    org.jfree.chart.axis.AxisSpace var52 = null;
    var46.setFixedDomainAxisSpace(var52);
    java.awt.Paint var54 = null;
    var46.setRangeTickBandPaint(var54);
    java.awt.geom.Point2D var56 = var46.getQuadrantOrigin();
    var38.zoomRangeAxes(10.0d, 0.0d, var41, var56);
    org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart("", var19, (org.jfree.chart.plot.Plot)var38, false);
    org.jfree.chart.event.ChartChangeEventType var60 = null;
    org.jfree.chart.event.ChartChangeEvent var61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var59, var60);
    java.lang.Object var62 = var61.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var4.rendererChanged(var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var17.zoomDomainAxes((-1.0d), 0.2d, var20, var21);
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var25 = var17.getRangeAxisLocation(1);
    var4.setDomainAxisLocation(var25);
    java.awt.Paint var27 = var4.getDomainTickBandPaint();
    java.awt.Shape var32 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var34 = var33.clone();
    java.awt.Paint var35 = var33.getBasePaint();
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
    java.awt.Stroke var37 = var36.getOutlineStroke();
    int var38 = var36.getDatasetIndex();
    java.awt.Stroke var39 = var36.getOutlineStroke();
    var4.setRangeZeroBaselineStroke(var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var42 = var4.getRangeAxisForDataset((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    org.jfree.data.Range var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDefaultAutoRange(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.lang.String var4 = org.jfree.chart.util.PaintUtilities.colorToString(var3);
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var6 = var5.getURLGenerator();
    java.awt.Color var11 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var5.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var11);
    java.awt.color.ColorSpace var13 = var11.getColorSpace();
    float[] var15 = new float[] { 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var16 = var3.getColorComponents(var13, var15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "black"+ "'", var4.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow((java.lang.Comparable)(short)10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var4 = var3.clone();
    java.awt.Paint var5 = var3.getBasePaint();
    boolean var6 = var3.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
    java.awt.Font var11 = null;
    var3.setSeriesItemLabelFont(0, var11, true);
    java.awt.Font var14 = var3.getBaseItemLabelFont();
    java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var23 = var20.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", var14, (org.jfree.chart.plot.Plot)var20, false);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var30, var31, var32);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
    org.jfree.chart.util.Layer var43 = null;
    java.util.Collection var44 = var41.getRangeMarkers(0, var43);
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.data.Range var46 = var41.getDataRange(var45);
    org.jfree.chart.axis.AxisSpace var47 = null;
    var41.setFixedDomainAxisSpace(var47);
    java.awt.Paint var49 = null;
    var41.setRangeTickBandPaint(var49);
    java.awt.geom.Point2D var51 = var41.getQuadrantOrigin();
    var33.zoomRangeAxes(10.0d, 0.0d, var36, var51);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var33, false);
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis((org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.chart.util.RectangleInsets var58 = var56.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isRangeCrosshairVisible();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var8 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var8, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, var12, var13, var14);
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var17 = var16.getLabelOutlinePaint();
//     var15.setRangeCrosshairPaint(var17);
//     int var19 = var15.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
//     var15.setFixedRangeAxisSpace(var20);
//     org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
//     var15.setFixedRangeAxisSpace(var22);
//     java.lang.String var24 = var15.getPlotType();
//     java.awt.Paint var25 = var15.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var28 = var27.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var30 = null;
//     var29.setLabelOutlinePaint(var30);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var38 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var39 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var40 = var39.clone();
//     java.awt.Paint var41 = var39.getBasePaint();
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var38, var41);
//     var32.setSeriesOutlinePaint(0, var41, true);
//     var29.setBackgroundPaint(var41);
//     java.awt.Stroke var46 = null;
//     org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var25, var28, var41, var46, 0.0f);
//     var4.setRangeGridlinePaint(var25);
//     java.awt.Shape var54 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var55 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var56 = var55.clone();
//     java.awt.Paint var57 = var55.getBasePaint();
//     org.jfree.chart.LegendItem var58 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var54, var57);
//     java.awt.Stroke var59 = var58.getOutlineStroke();
//     int var60 = var58.getDatasetIndex();
//     java.awt.Stroke var61 = var58.getOutlineStroke();
//     var4.setDomainGridlineStroke(var61);
//     
//     // Checks the contract:  equals-hashcode on var42 and var58
//     assertTrue("Contract failed: equals-hashcode on var42 and var58", var42.equals(var58) ? var42.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var42
//     assertTrue("Contract failed: equals-hashcode on var58 and var42", var58.equals(var42) ? var58.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var3 = var2.getLabel();
    org.jfree.data.KeyedObject var4 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var7 = var6.getLabelInsets();
    double var9 = var7.calculateTopInset(100.0d);
    var2.setTickLabelInsets(var7);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var15 = var14.getLabelInsets();
    double var17 = var15.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var19 = var18.getChartArea();
    java.awt.geom.Rectangle2D var22 = var15.createInsetRectangle(var19, true, false);
    java.lang.Object var24 = var11.draw(var12, var19, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var19, "XY Plot", "WMAP_Plot");
    org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var34 = var31.isOnOrBefore((org.jfree.data.time.SerialDate)var33);
    boolean var35 = var29.isOnOrAfter((org.jfree.data.time.SerialDate)var33);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    int var38 = var37.getYYYY();
    org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var45 = var42.isOnOrBefore((org.jfree.data.time.SerialDate)var44);
    boolean var46 = var40.isOnOrAfter((org.jfree.data.time.SerialDate)var44);
    boolean var47 = var29.isInRange((org.jfree.data.time.SerialDate)var37, (org.jfree.data.time.SerialDate)var44);
    boolean var48 = var2.equals((java.lang.Object)var37);
    int var49 = var2.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.category.DefaultCategoryDataset var1 = new org.jfree.data.category.DefaultCategoryDataset();
    var1.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
    org.jfree.data.Range var6 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var11, var12, var13);
    java.lang.Number var17 = var7.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
    org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var24 = var21.isOnOrBefore((org.jfree.data.time.SerialDate)var23);
    boolean var25 = var19.isOnOrAfter((org.jfree.data.time.SerialDate)var23);
    org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var34 = var31.isOnOrBefore((org.jfree.data.time.SerialDate)var33);
    boolean var35 = var29.isOnOrAfter((org.jfree.data.time.SerialDate)var33);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    int var38 = var37.getYYYY();
    org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var45 = var42.isOnOrBefore((org.jfree.data.time.SerialDate)var44);
    boolean var46 = var40.isOnOrAfter((org.jfree.data.time.SerialDate)var44);
    boolean var47 = var29.isInRange((org.jfree.data.time.SerialDate)var37, (org.jfree.data.time.SerialDate)var44);
    org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var29);
    org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addYears(1, (org.jfree.data.time.SerialDate)var29);
    java.lang.Number var50 = var7.getValue((java.lang.Comparable)var19, (java.lang.Comparable)var49);
    org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(4);
    int var53 = var52.getYYYY();
    org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var58 = var55.isOnOrBefore((org.jfree.data.time.SerialDate)var57);
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var62 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var65 = var62.isOnOrBefore((org.jfree.data.time.SerialDate)var64);
    boolean var66 = var60.isOnOrAfter((org.jfree.data.time.SerialDate)var64);
    boolean var67 = var57.isBefore((org.jfree.data.time.SerialDate)var64);
    org.jfree.data.time.SpreadsheetDate var69 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var71 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var72 = var69.isOnOrBefore((org.jfree.data.time.SerialDate)var71);
    org.jfree.data.time.SpreadsheetDate var74 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var76 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var78 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var79 = var76.isOnOrBefore((org.jfree.data.time.SerialDate)var78);
    boolean var80 = var74.isOnOrAfter((org.jfree.data.time.SerialDate)var78);
    boolean var81 = var71.isBefore((org.jfree.data.time.SerialDate)var78);
    boolean var82 = var64.isOn((org.jfree.data.time.SerialDate)var71);
    int var83 = var52.compare((org.jfree.data.time.SerialDate)var71);
    int var84 = var71.getYYYY();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var85 = var1.getValue((java.lang.Comparable)var49, (java.lang.Comparable)var71);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 1900);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    boolean var2 = var0.isDomainZoomable();
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAngleLabelFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getMargin();
    java.util.List var2 = var0.getBlocks();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    org.jfree.chart.title.TextTitle var6 = null;
    var3.setTitle(var6);
    boolean var8 = var3.isBorderVisible();
    var3.setBorderVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var10, var11, var12);
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var15 = var14.getLabelOutlinePaint();
    var13.setRangeCrosshairPaint(var15);
    var5.setDomainTickBandPaint(var15);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var21 = var18.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var23 = null;
    org.jfree.chart.renderer.WaferMapRenderer var24 = null;
    org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
    java.awt.Stroke var27 = var26.getBorderStroke();
    var18.setSeriesStroke(100, var27, true);
    org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d, var15, var27);
    org.jfree.chart.util.LengthAdjustmentType var31 = var30.getLabelOffsetType();
    java.awt.Paint var32 = var30.getPaint();
    java.lang.Object var33 = var30.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var5 = var4.getURLGenerator();
    java.awt.Color var10 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var4.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var10);
    java.awt.color.ColorSpace var12 = var10.getColorSpace();
    float[] var16 = new float[] { 1.0f, 1.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var17 = var3.getComponents(var12, var16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    java.lang.String var16 = var7.getPlotType();
    java.awt.Paint var17 = var7.getDomainGridlinePaint();
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var22.zoomDomainAxes((-1.0d), 0.2d, var25, var26);
    java.awt.Paint var28 = var22.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var30 = var22.getRangeAxisLocation(1);
    var7.setDomainAxisLocation(var30);
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var34 = var33.getLabel();
    var7.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Category Plot"+ "'", var16.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + ""+ "'", var34.equals(""));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, (-1.0f), 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2097352));

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    float[] var5 = new float[] { 0.0f, (-1.0f), 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var1.getComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("CategoryLabelWidthType.CATEGORY");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    org.jfree.chart.util.RectangleInsets var3 = var1.getTickLabelInsets();
    java.awt.Font var4 = var1.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperMargin(0.0d);
    var1.setInverted(true);
    boolean var6 = var1.isVerticalTickLabels();
    var1.configure();
    var1.setAutoRangeMinimumSize(4.0d, false);
    org.jfree.chart.axis.NumberTickUnit var11 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var8 = var5.isOnOrBefore((org.jfree.data.time.SerialDate)var7);
//     boolean var9 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var12 = var11.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     boolean var20 = var14.isOnOrAfter((org.jfree.data.time.SerialDate)var18);
//     boolean var21 = var3.isInRange((org.jfree.data.time.SerialDate)var11, (org.jfree.data.time.SerialDate)var18);
//     boolean var22 = var0.equals((java.lang.Object)var11);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var23 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition((-1));
//     var0.setBasePositiveItemLabelPosition(var25);
//     org.jfree.chart.labels.ItemLabelAnchor var27 = var25.getItemLabelAnchor();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var28 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var28.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var31 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var33 = var31.getSeriesNegativeItemLabelPosition((-1));
//     var28.setBasePositiveItemLabelPosition(var33, true);
//     org.jfree.chart.text.TextAnchor var36 = var33.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var37 = new org.jfree.chart.labels.ItemLabelPosition(var27, var36);
//     
//     // Checks the contract:  equals-hashcode on var25 and var33
//     assertTrue("Contract failed: equals-hashcode on var25 and var33", var25.equals(var33) ? var25.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var37
//     assertTrue("Contract failed: equals-hashcode on var25 and var37", var25.equals(var37) ? var25.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var25
//     assertTrue("Contract failed: equals-hashcode on var33 and var25", var33.equals(var25) ? var33.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var37
//     assertTrue("Contract failed: equals-hashcode on var33 and var37", var33.equals(var37) ? var33.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var25
//     assertTrue("Contract failed: equals-hashcode on var37 and var25", var37.equals(var25) ? var37.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var33
//     assertTrue("Contract failed: equals-hashcode on var37 and var33", var37.equals(var33) ? var37.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var3 = var2.clone();
    java.awt.Paint var4 = var2.getBasePaint();
    boolean var5 = var2.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var8 = var2.getURLGenerator(100, 4);
    java.awt.Font var10 = null;
    var2.setSeriesItemLabelFont(0, var10, true);
    java.awt.Font var13 = var2.getBaseItemLabelFont();
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var17);
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var21 = var19.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var22 = var19.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart("hi!", var13, (org.jfree.chart.plot.Plot)var19, false);
    boolean var25 = var19.isCircular();
    boolean var26 = var19.isCircular();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var20 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var22 = var21.clone();
//     java.awt.Paint var23 = var21.getBasePaint();
//     org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var20, var23);
//     var14.setSeriesOutlinePaint(0, var23, true);
//     var7.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     var7.setRangeCrosshairValue(2.0d, false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var34 = var33.clone();
//     java.awt.Paint var35 = var33.getBasePaint();
//     boolean var36 = var33.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var39 = var33.getURLGenerator(100, 4);
//     java.awt.Font var41 = null;
//     var33.setSeriesItemLabelFont(0, var41, true);
//     java.awt.Font var44 = var33.getBaseItemLabelFont();
//     java.awt.Color var48 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("", var44, (java.awt.Paint)var48);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var56 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var57 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var58 = var57.clone();
//     java.awt.Paint var59 = var57.getBasePaint();
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var56, var59);
//     var50.setSeriesOutlinePaint(0, var59, true);
//     org.jfree.chart.text.TextMeasurer var64 = null;
//     org.jfree.chart.text.TextBlock var65 = org.jfree.chart.text.TextUtilities.createTextBlock("", var44, var59, 0.0f, var64);
//     var7.setRangeGridlinePaint(var59);
//     
//     // Checks the contract:  equals-hashcode on var24 and var60
//     assertTrue("Contract failed: equals-hashcode on var24 and var60", var24.equals(var60) ? var24.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var24
//     assertTrue("Contract failed: equals-hashcode on var60 and var24", var60.equals(var24) ? var60.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var4 = var3.getLabelInsets();
//     double var6 = var4.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var8 = var7.getChartArea();
//     java.awt.geom.Rectangle2D var11 = var4.createInsetRectangle(var8, true, false);
//     java.lang.Object var13 = var0.draw(var1, var8, (java.lang.Object)"WMAP_Plot");
//     org.jfree.chart.util.RectangleInsets var14 = var0.getMargin();
//     java.lang.String var15 = var0.getURLText();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var18 = null;
//     org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, var18);
//     double var20 = var19.getWidth();
//     org.jfree.chart.util.Size2D var21 = var0.arrange(var16, var19);
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.Image var6 = null;
    var5.setBackgroundImage(var6);
    org.jfree.chart.title.TextTitle var8 = null;
    var5.setTitle(var8);
    var5.setAntiAlias(false);
    boolean var12 = var5.isBorderVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    java.lang.Boolean var4 = var0.getSeriesVisible(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("XY Plot");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
//     boolean var7 = var2.getAutoRangeStickyZero();
//     java.lang.String var8 = var2.getLabelURL();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var11 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var12 = var11.clone();
//     java.awt.Paint var13 = var11.getBasePaint();
//     boolean var14 = var11.getBaseSeriesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var17 = var16.getCategoryLabelPositionOffset();
//     java.awt.Paint var18 = var16.getAxisLinePaint();
//     java.awt.Stroke var19 = var16.getTickMarkStroke();
//     var11.setBaseStroke(var19, true);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var25 = var24.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var32 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var33 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var34 = var33.clone();
//     java.awt.Paint var35 = var33.getBasePaint();
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var32, var35);
//     var26.setSeriesOutlinePaint(0, var35, true);
//     boolean var39 = var24.equals((java.lang.Object)var35);
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var42 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var43 = var42.getChartArea();
//     var41.setLegendItemShape((java.awt.Shape)var43);
//     var24.setSeriesShape(4, (java.awt.Shape)var43);
//     var11.setBaseShape((java.awt.Shape)var43, true);
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = org.jfree.chart.util.RectangleEdge.coordinate(var43, var48);
//     org.jfree.data.general.WaferMapDataset var50 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var51 = null;
//     org.jfree.chart.plot.WaferMapPlot var52 = new org.jfree.chart.plot.WaferMapPlot(var50, var51);
//     org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var52);
//     java.awt.Image var54 = null;
//     var53.setBackgroundImage(var54);
//     org.jfree.chart.title.TextTitle var56 = null;
//     var53.setTitle(var56);
//     var53.setAntiAlias(false);
//     float var60 = var53.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var61 = var53.getLegend();
//     java.awt.Paint var62 = var61.getBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var67 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
//     var61.setFrame((org.jfree.chart.block.BlockFrame)var67);
//     org.jfree.chart.renderer.category.MinMaxCategoryRenderer var69 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
//     javax.swing.Icon var70 = var69.getObjectIcon();
//     boolean var71 = var69.isDrawLines();
//     org.jfree.chart.LegendItemSource[] var72 = new org.jfree.chart.LegendItemSource[] { var69};
//     var61.setSources(var72);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var74 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var76 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var74, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var78 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var79 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var80 = null;
//     org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var74, var78, var79, var80);
//     org.jfree.chart.plot.PiePlot var82 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var83 = var82.getLabelOutlinePaint();
//     var81.setRangeCrosshairPaint(var83);
//     int var85 = var81.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var86 = new org.jfree.chart.axis.AxisSpace();
//     var81.setFixedRangeAxisSpace(var86);
//     org.jfree.chart.axis.AxisSpace var88 = new org.jfree.chart.axis.AxisSpace();
//     var81.setFixedRangeAxisSpace(var88);
//     org.jfree.chart.axis.CategoryAxis var91 = var81.getDomainAxisForDataset(0);
//     org.jfree.chart.util.RectangleEdge var92 = var81.getDomainAxisEdge();
//     var61.setLegendItemGraphicEdge(var92);
//     java.util.List var94 = var2.refreshTicks(var9, var10, var43, var92);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = var0.getObject("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Paint var4 = var0.getSeriesItemLabelPaint(1);
    int var5 = var0.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var3 = var2.getLabel();
//     org.jfree.data.KeyedObject var4 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var2);
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var7 = var6.getLabelInsets();
//     double var9 = var7.calculateTopInset(100.0d);
//     var2.setTickLabelInsets(var7);
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var15 = var14.getLabelInsets();
//     double var17 = var15.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var19 = var18.getChartArea();
//     java.awt.geom.Rectangle2D var22 = var15.createInsetRectangle(var19, true, false);
//     java.lang.Object var24 = var11.draw(var12, var19, (java.lang.Object)"WMAP_Plot");
//     org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var19, "XY Plot", "WMAP_Plot");
//     var2.setTickLabelsVisible(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var33 = var32.clone();
//     java.awt.Paint var34 = var32.getBasePaint();
//     boolean var35 = var32.getBaseSeriesVisible();
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var38 = var37.getCategoryLabelPositionOffset();
//     java.awt.Paint var39 = var37.getAxisLinePaint();
//     java.awt.Stroke var40 = var37.getTickMarkStroke();
//     var32.setBaseStroke(var40, true);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var46 = var45.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var53 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var54 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var55 = var54.clone();
//     java.awt.Paint var56 = var54.getBasePaint();
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var53, var56);
//     var47.setSeriesOutlinePaint(0, var56, true);
//     boolean var60 = var45.equals((java.lang.Object)var56);
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var63 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var64 = var63.getChartArea();
//     var62.setLegendItemShape((java.awt.Shape)var64);
//     var45.setSeriesShape(4, (java.awt.Shape)var64);
//     var32.setBaseShape((java.awt.Shape)var64, true);
//     org.jfree.chart.util.RectangleEdge var69 = null;
//     double var70 = org.jfree.chart.util.RectangleEdge.coordinate(var64, var69);
//     org.jfree.data.general.WaferMapDataset var71 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var72 = null;
//     org.jfree.chart.plot.WaferMapPlot var73 = new org.jfree.chart.plot.WaferMapPlot(var71, var72);
//     org.jfree.chart.JFreeChart var74 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var73);
//     java.awt.Image var75 = null;
//     var74.setBackgroundImage(var75);
//     org.jfree.chart.title.TextTitle var77 = null;
//     var74.setTitle(var77);
//     var74.setAntiAlias(false);
//     float var81 = var74.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var82 = var74.getLegend();
//     org.jfree.chart.util.RectangleEdge var83 = var82.getLegendItemGraphicEdge();
//     double var84 = var2.getCategoryStart(100, 1900, var64, var83);
//     
//     // Checks the contract:  equals-hashcode on var18 and var63
//     assertTrue("Contract failed: equals-hashcode on var18 and var63", var18.equals(var63) ? var18.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var18
//     assertTrue("Contract failed: equals-hashcode on var63 and var18", var63.equals(var18) ? var63.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var1 = var0.getBaseShapesFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var3 = var2.clone();
    java.awt.Paint var4 = var2.getBasePaint();
    boolean var5 = var2.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var8 = var2.getURLGenerator(100, 4);
    java.awt.Font var10 = null;
    var2.setSeriesItemLabelFont(0, var10, true);
    java.awt.Font var13 = var2.getBaseItemLabelFont();
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, (java.awt.Paint)var17);
    boolean var19 = var0.equals((java.lang.Object)var13);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var20 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var23 = var0.generateLabel((org.jfree.data.category.CategoryDataset)var20, (-2097352));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     var11.setHeight(0.0d);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var16 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var16, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var20, var21, var22);
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var25 = var24.getLabelOutlinePaint();
//     var23.setRangeCrosshairPaint(var25);
//     int var27 = var23.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var28 = new org.jfree.chart.axis.AxisSpace();
//     var23.setFixedRangeAxisSpace(var28);
//     org.jfree.chart.axis.AxisSpace var30 = new org.jfree.chart.axis.AxisSpace();
//     var23.setFixedRangeAxisSpace(var30);
//     java.lang.String var32 = var23.getPlotType();
//     java.awt.Paint var33 = var23.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var36 = var35.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var38 = null;
//     var37.setLabelOutlinePaint(var38);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var46 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var47 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var48 = var47.clone();
//     java.awt.Paint var49 = var47.getBasePaint();
//     org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var46, var49);
//     var40.setSeriesOutlinePaint(0, var49, true);
//     var37.setBackgroundPaint(var49);
//     java.awt.Stroke var54 = null;
//     org.jfree.chart.plot.IntervalMarker var56 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var33, var36, var49, var54, 0.0f);
//     org.jfree.data.general.WaferMapDataset var57 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var58 = null;
//     org.jfree.chart.plot.WaferMapPlot var59 = new org.jfree.chart.plot.WaferMapPlot(var57, var58);
//     org.jfree.chart.JFreeChart var60 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var59);
//     java.awt.Image var61 = null;
//     var60.setBackgroundImage(var61);
//     var60.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var64 = var60.getPadding();
//     var56.setLabelOffset(var64);
//     java.lang.Object var66 = var56.clone();
//     org.jfree.chart.util.RectangleInsets var67 = var56.getLabelOffset();
//     org.jfree.chart.util.RectangleAnchor var68 = var56.getLabelAnchor();
//     var11.setLegendItemGraphicAnchor(var68);
//     
//     // Checks the contract:  equals-hashcode on var2 and var59
//     assertTrue("Contract failed: equals-hashcode on var2 and var59", var2.equals(var59) ? var2.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var2
//     assertTrue("Contract failed: equals-hashcode on var59 and var2", var59.equals(var2) ? var59.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ChartEntity: tooltip = XY Plot", var1);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var3 = var0.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    java.awt.Stroke var9 = var8.getBorderStroke();
    var0.setSeriesStroke(100, var9, true);
    java.awt.Font var13 = var0.getSeriesItemLabelFont(4);
    java.awt.Paint var16 = var0.getItemLabelPaint(10, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.renderer.category.LevelRenderer var0 = new org.jfree.chart.renderer.category.LevelRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelInsets();
    double var6 = var4.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var7 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var8 = var7.getChartArea();
    java.awt.geom.Rectangle2D var11 = var4.createInsetRectangle(var8, true, false);
    org.jfree.chart.plot.CategoryPlot var12 = null;
    org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var15 = var14.getChartArea();
    java.lang.Object var16 = var14.clone();
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var18 = var0.initialise(var1, var11, var12, (-2097352), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(0.05d, 6.0d);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var5 = var4.clone();
    java.awt.Paint var6 = var4.getBasePaint();
    boolean var7 = var4.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var10 = var4.getURLGenerator(100, 4);
    java.awt.Font var12 = null;
    var4.setSeriesItemLabelFont(0, var12, true);
    java.awt.Font var15 = var4.getBaseItemLabelFont();
    java.awt.Color var19 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var15, (java.awt.Paint)var19);
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var23 = var21.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var24 = var21.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", var15, (org.jfree.chart.plot.Plot)var21, false);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var27 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var27, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, var31, var32, var33);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
    org.jfree.chart.util.Layer var44 = null;
    java.util.Collection var45 = var42.getRangeMarkers(0, var44);
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.data.Range var47 = var42.getDataRange(var46);
    org.jfree.chart.axis.AxisSpace var48 = null;
    var42.setFixedDomainAxisSpace(var48);
    java.awt.Paint var50 = null;
    var42.setRangeTickBandPaint(var50);
    java.awt.geom.Point2D var52 = var42.getQuadrantOrigin();
    var34.zoomRangeAxes(10.0d, 0.0d, var37, var52);
    org.jfree.chart.JFreeChart var55 = new org.jfree.chart.JFreeChart("", var15, (org.jfree.chart.plot.Plot)var34, false);
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("");
    var34.setRangeAxis((org.jfree.chart.axis.ValueAxis)var57);
    var57.setAutoTickUnitSelection(false);
    var0.setAxis((org.jfree.chart.axis.ValueAxis)var57);
    java.awt.Stroke var62 = var0.getAngleGridlineStroke();
    java.io.ObjectOutputStream var63 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var62, var63);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
//     org.jfree.chart.util.SortOrder var13 = var7.getRowRenderingOrder();
//     java.awt.Paint var14 = var7.getRangeGridlinePaint();
//     org.jfree.chart.plot.DrawingSupplier var15 = var7.getDrawingSupplier();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
//     java.awt.Paint var20 = var19.getWallPaint();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var27 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var28 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var29 = var28.clone();
//     java.awt.Paint var30 = var28.getBasePaint();
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var27, var30);
//     var21.setSeriesOutlinePaint(0, var30, true);
//     boolean var34 = var19.equals((java.lang.Object)var30);
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var37 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var38 = var37.getChartArea();
//     var36.setLegendItemShape((java.awt.Shape)var38);
//     var19.setSeriesShape(4, (java.awt.Shape)var38);
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
//     org.jfree.chart.util.Layer var48 = null;
//     java.util.Collection var49 = var46.getRangeMarkers(0, var48);
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     java.awt.geom.Point2D var53 = null;
//     var46.zoomDomainAxes(2.0d, 1.0d, var52, var53);
//     org.jfree.chart.ChartRenderingInfo var56 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var57 = var56.getChartArea();
//     java.lang.Object var58 = var56.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var59 = new org.jfree.chart.plot.PlotRenderingInfo(var56);
//     java.awt.geom.Point2D var60 = null;
//     var46.zoomDomainAxes(2.0d, var59, var60);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var62 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var59);
//     boolean var63 = var7.render(var16, var38, 1, var59);
//     
//     // Checks the contract:  equals-hashcode on var37 and var56
//     assertTrue("Contract failed: equals-hashcode on var37 and var56", var37.equals(var56) ? var37.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var37
//     assertTrue("Contract failed: equals-hashcode on var56 and var37", var56.equals(var37) ? var56.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var15.getRangeMarkers(0, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.data.Range var20 = var15.getDataRange(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var15.setFixedDomainAxisSpace(var21);
    java.awt.Paint var23 = null;
    var15.setRangeTickBandPaint(var23);
    java.awt.geom.Point2D var25 = var15.getQuadrantOrigin();
    var7.zoomRangeAxes(10.0d, 0.0d, var10, var25);
    java.io.ObjectOutputStream var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var25, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelInsets();
    double var10 = var8.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    java.awt.geom.Rectangle2D var15 = var8.createInsetRectangle(var12, true, false);
    java.lang.Object var17 = var4.draw(var5, var12, (java.lang.Object)"WMAP_Plot");
    java.awt.Paint var18 = null;
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var23.zoomDomainAxes((-1.0d), 0.2d, var26, var27);
    java.awt.Paint var29 = var23.getRangeCrosshairPaint();
    double var30 = var23.getDomainCrosshairValue();
    java.awt.Stroke var31 = var23.getRangeCrosshairStroke();
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
    org.jfree.chart.util.Layer var38 = null;
    java.util.Collection var39 = var36.getRangeMarkers(0, var38);
    org.jfree.chart.util.Layer var40 = null;
    java.util.Collection var41 = var36.getRangeMarkers(var40);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var42 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var43 = var42.clone();
    java.awt.Paint var44 = var42.getBasePaint();
    boolean var45 = var42.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var48 = var42.getURLGenerator(100, 4);
    java.awt.Font var50 = null;
    var42.setSeriesItemLabelFont(0, var50, true);
    java.awt.Paint var53 = var42.getBasePaint();
    var36.setDomainGridlinePaint(var53);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("12/31/69", "Default Group", "April", "", (java.awt.Shape)var12, var18, var31, var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelInsets();
    double var8 = var6.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    java.awt.geom.Rectangle2D var13 = var6.createInsetRectangle(var10, true, false);
    java.awt.geom.Point2D var14 = null;
    org.jfree.chart.plot.PlotState var15 = new org.jfree.chart.plot.PlotState();
    java.util.Map var16 = var15.getSharedAxisStates();
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    var0.draw(var3, var13, var14, var15, var17);
    org.jfree.chart.util.RectangleAnchor var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var13, var19, 4.0d, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.block.Arrangement var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    var0.setName("ThreadContext");
    org.jfree.chart.ui.BasicProjectInfo var3 = new org.jfree.chart.ui.BasicProjectInfo();
    var3.setVersion("hi!");
    java.lang.String var6 = var3.getCopyright();
    var0.addLibrary((org.jfree.chart.ui.Library)var3);
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo();
    var0.addLibrary((org.jfree.chart.ui.Library)var8);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    java.awt.geom.Point2D var18 = null;
    var14.zoomDomainAxes((-1.0d), 0.2d, var17, var18);
    java.awt.Paint var20 = var14.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var22 = var14.getRangeAxisLocation(1);
    java.awt.Graphics2D var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.data.DefaultKeyedValues2D var25 = new org.jfree.data.DefaultKeyedValues2D();
    var25.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var30 = null;
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var38 = var35.isOnOrBefore((org.jfree.data.time.SerialDate)var37);
    boolean var39 = var33.isOnOrAfter((org.jfree.data.time.SerialDate)var37);
    org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(4);
    int var42 = var41.getYYYY();
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var49 = var46.isOnOrBefore((org.jfree.data.time.SerialDate)var48);
    boolean var50 = var44.isOnOrAfter((org.jfree.data.time.SerialDate)var48);
    boolean var51 = var33.isInRange((org.jfree.data.time.SerialDate)var41, (org.jfree.data.time.SerialDate)var48);
    var25.addValue(var30, (java.lang.Comparable)' ', (java.lang.Comparable)var33);
    java.util.List var53 = var25.getColumnKeys();
    java.util.List var54 = var25.getColumnKeys();
    var14.drawDomainTickBands(var23, var24, var54);
    var8.setContributors(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    int var1 = var0.getSegmentsIncluded();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
//     var4.zoom(3.0d);
//     org.jfree.chart.plot.Marker var15 = null;
//     org.jfree.chart.util.Layer var16 = null;
//     var4.addRangeMarker(var15, var16);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var3 = var0.isItemLabelVisible(1, 0);
    double var4 = var0.getBase();
    var0.setBaseSeriesVisible(true);
    java.awt.Stroke var9 = var0.getItemStroke((-1), 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var8 = var5.isOnOrBefore((org.jfree.data.time.SerialDate)var7);
    boolean var9 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
    int var12 = var11.getYYYY();
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
    boolean var20 = var14.isOnOrAfter((org.jfree.data.time.SerialDate)var18);
    boolean var21 = var3.isInRange((org.jfree.data.time.SerialDate)var11, (org.jfree.data.time.SerialDate)var18);
    boolean var22 = var0.equals((java.lang.Object)var11);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
    java.awt.Paint var29 = var28.getPaint();
    var0.setSeriesOutlinePaint(0, var29);
    boolean var31 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.util.Date var0 = null;
//     java.text.DateFormat var3 = null;
//     org.jfree.chart.axis.DateTickUnit var4 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var3);
//     java.lang.String var6 = var4.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var14 = var11.isOnOrBefore((org.jfree.data.time.SerialDate)var13);
//     boolean var15 = var9.isOnOrAfter((org.jfree.data.time.SerialDate)var13);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var18 = var17.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
//     boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
//     boolean var27 = var9.isInRange((org.jfree.data.time.SerialDate)var17, (org.jfree.data.time.SerialDate)var24);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var9);
//     java.util.Date var29 = var9.toDate();
//     java.util.Date var30 = var4.rollDate(var29);
//     org.jfree.data.time.DateRange var31 = new org.jfree.data.time.DateRange(var0, var29);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var4.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition((-1));
//     var4.setBasePositiveItemLabelPosition(var9, true);
//     org.jfree.chart.text.TextAnchor var12 = var9.getTextAnchor();
//     boolean var14 = var12.equals((java.lang.Object)"hi!");
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var16 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     var16.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var19 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var21 = var19.getSeriesNegativeItemLabelPosition((-1));
//     var16.setBasePositiveItemLabelPosition(var21, true);
//     org.jfree.chart.text.TextAnchor var24 = var21.getTextAnchor();
//     boolean var26 = var24.equals((java.lang.Object)"hi!");
//     java.awt.Shape var27 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("April", var1, (-1.0f), 0.0f, var12, 100.0d, var24);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var7 = var6.clone();
    java.awt.Paint var8 = var6.getBasePaint();
    boolean var9 = var6.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var12 = var6.getURLGenerator(100, 4);
    java.awt.Font var14 = null;
    var6.setSeriesItemLabelFont(0, var14, true);
    java.awt.Font var17 = var6.getBaseItemLabelFont();
    java.awt.Color var21 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var29 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var30 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var31 = var30.clone();
    java.awt.Paint var32 = var30.getBasePaint();
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var29, var32);
    var23.setSeriesOutlinePaint(0, var32, true);
    org.jfree.chart.text.TextMeasurer var37 = null;
    org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, var32, 0.0f, var37);
    org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var40 = null;
    var39.setLabelOutlinePaint(var40);
    java.awt.Stroke var42 = var39.getLabelOutlineStroke();
    java.awt.Paint var43 = var39.getLabelPaint();
    org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine("", var17, var43);
    org.jfree.chart.text.TextFragment var45 = var44.getFirstTextFragment();
    float var46 = var45.getBaselineOffset();
    java.awt.Paint var47 = var45.getPaint();
    var2.setWallPaint(var47);
    org.jfree.chart.labels.ItemLabelPosition var49 = var2.getPositiveItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(2.0d, 6.0d, 4.0d, 8.05d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Pie Plot", "Range[0.0,0.0]", var3);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var1 = var0.getChartArea();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var8 = var7.getLabelInsets();
//     double var10 = var8.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     java.awt.geom.Rectangle2D var15 = var8.createInsetRectangle(var12, true, false);
//     java.lang.Object var17 = var4.draw(var5, var12, (java.lang.Object)"WMAP_Plot");
//     var3.setPlotArea(var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(0, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     java.awt.geom.Point2D var11 = null;
//     var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var15 = var14.getChartArea();
//     java.lang.Object var16 = var14.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
//     java.awt.geom.Point2D var18 = null;
//     var4.zoomDomainAxes(2.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var20 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var17);
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var23 = var22.getLabelInsets();
//     double var25 = var23.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var27 = var26.getChartArea();
//     java.awt.geom.Rectangle2D var30 = var23.createInsetRectangle(var27, true, false);
//     var17.setPlotArea(var30);
//     
//     // Checks the contract:  equals-hashcode on var14 and var26
//     assertTrue("Contract failed: equals-hashcode on var14 and var26", var14.equals(var26) ? var14.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var14
//     assertTrue("Contract failed: equals-hashcode on var26 and var14", var26.equals(var14) ? var26.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var3 = var2.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var5 = var4.getObjectIcon();
    var2.setMaxIcon(var5);
    var0.setObjectIcon(var5);
    boolean var10 = var0.isItemLabelVisible(10, (-1));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var12 = null;
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var13 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var14 = var13.getItemMargin();
    org.jfree.chart.LegendItem var17 = var13.getLegendItem(100, 0);
    var13.setItemMargin(1.0d);
    double var20 = var13.getItemMargin();
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var22 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var23 = var22.getChartArea();
    var21.setLegendItemShape((java.awt.Shape)var23);
    var13.setBaseShape((java.awt.Shape)var23);
    org.jfree.chart.entity.LegendItemEntity var26 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var23);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var27 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var27, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, var31, var32, var33);
    org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var36 = var35.getLabelOutlinePaint();
    var34.setRangeCrosshairPaint(var36);
    int var38 = var34.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var39 = new org.jfree.chart.axis.AxisSpace();
    var34.setFixedRangeAxisSpace(var39);
    org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
    var34.setFixedRangeAxisSpace(var41);
    java.lang.String var43 = var34.getPlotType();
    boolean var44 = var34.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var47 = var46.getTickMarkStroke();
    java.lang.Object var48 = var46.clone();
    java.util.List var49 = var34.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var46);
    var34.clearRangeMarkers(2);
    org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var55 = var53.getCategoryLabelToolTip((java.lang.Comparable)(-1.0f));
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var56 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var58 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var56, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var56, var60, var61, var62);
    org.jfree.chart.plot.PiePlot var64 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var65 = var64.getLabelOutlinePaint();
    var63.setRangeCrosshairPaint(var65);
    int var67 = var63.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var68 = new org.jfree.chart.axis.AxisSpace();
    var63.setFixedRangeAxisSpace(var68);
    org.jfree.chart.axis.AxisSpace var70 = new org.jfree.chart.axis.AxisSpace();
    var63.setFixedRangeAxisSpace(var70);
    java.lang.String var72 = var63.getPlotType();
    boolean var73 = var63.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("");
    var75.setUpperMargin(0.0d);
    var75.setInverted(true);
    boolean var80 = var75.isVerticalTickLabels();
    var75.configure();
    var63.setRangeAxis((org.jfree.chart.axis.ValueAxis)var75);
    var75.setAutoRangeMinimumSize(3.0d);
    org.jfree.chart.axis.NumberTickUnit var86 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    var75.setTickUnit(var86);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var88 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var90 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var88, (java.lang.Comparable)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var11, var12, var23, var34, (org.jfree.chart.axis.CategoryAxis)var53, (org.jfree.chart.axis.ValueAxis)var75, (org.jfree.data.category.CategoryDataset)var88, 1900, 0, 31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "Category Plot"+ "'", var43.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + "Category Plot"+ "'", var72.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var7 = var6.getLabelOutlinePaint();
    var4.setBackgroundPaint(var7);
    var0.setLabelShadowPaint(var7);
    java.awt.Font var10 = var0.getLabelFont();
    org.jfree.chart.util.Rotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDirection(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

}
