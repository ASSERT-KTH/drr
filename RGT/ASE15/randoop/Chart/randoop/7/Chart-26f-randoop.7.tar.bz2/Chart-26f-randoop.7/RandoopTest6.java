
import junit.framework.*;

public class RandoopTest6 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test1"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    int var10 = var4.getDomainAxisCount();
    java.lang.String var11 = var4.getPlotType();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    var13.setUpperMargin(0.0d);
    var13.setInverted(true);
    boolean var18 = var13.isVerticalTickLabels();
    var13.configure();
    var13.setAutoRangeMinimumSize(4.0d, false);
    int var23 = var4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
    double var24 = var13.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "XY Plot"+ "'", var11.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test2"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setSeriesItemLabelsVisible(4, true);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, var8, var9, var10);
    java.lang.Number var14 = var4.getMinOutlier((java.lang.Comparable)(byte)1, (java.lang.Comparable)"XY Plot");
    org.jfree.data.Range var15 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var19 = var18.getLabel();
    org.jfree.data.KeyedObject var20 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var18);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelInsets();
    double var25 = var23.calculateTopInset(100.0d);
    var18.setTickLabelInsets(var23);
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var31 = var30.getLabelInsets();
    double var33 = var31.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var35 = var34.getChartArea();
    java.awt.geom.Rectangle2D var38 = var31.createInsetRectangle(var35, true, false);
    java.lang.Object var40 = var27.draw(var28, var35, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.entity.AxisLabelEntity var43 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, (java.awt.Shape)var35, "XY Plot", "WMAP_Plot");
    org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var50 = var47.isOnOrBefore((org.jfree.data.time.SerialDate)var49);
    boolean var51 = var45.isOnOrAfter((org.jfree.data.time.SerialDate)var49);
    org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
    int var54 = var53.getYYYY();
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var61 = var58.isOnOrBefore((org.jfree.data.time.SerialDate)var60);
    boolean var62 = var56.isOnOrAfter((org.jfree.data.time.SerialDate)var60);
    boolean var63 = var45.isInRange((org.jfree.data.time.SerialDate)var53, (org.jfree.data.time.SerialDate)var60);
    boolean var64 = var18.equals((java.lang.Object)var53);
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var67 = var66.getNumberFormatOverride();
    org.jfree.data.Range var70 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var71 = new org.jfree.data.time.DateRange(var70);
    var66.setRangeWithMargins((org.jfree.data.Range)var71);
    double var73 = var66.getLowerMargin();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var74 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var75 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var77 = var75.getSeriesNegativeItemLabelPosition((-1));
    var74.setNegativeItemLabelPositionFallback(var77);
    double var79 = var74.getLowerClip();
    org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var66, (org.jfree.chart.renderer.category.CategoryItemRenderer)var74);
    java.util.List var81 = var4.getColumnKeys();
    java.lang.Comparable var82 = null;
    org.jfree.data.general.PieDataset var83 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var4, var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + ""+ "'", var19.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test3"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setBottom(0.0d);
    double var3 = var0.getLeft();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, var8, var9, var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var11.setRenderer(var12, true);
    var11.clearDomainMarkers(10);
    org.jfree.chart.axis.CategoryAnchor var17 = var11.getDomainGridlinePosition();
    boolean var18 = var0.equals((java.lang.Object)var11);
    var0.setRight(3.0d);
    double var21 = var0.getTop();
    double var22 = var0.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test4"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var8 = var5.isOnOrBefore((org.jfree.data.time.SerialDate)var7);
//     boolean var9 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var12 = var11.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     boolean var20 = var14.isOnOrAfter((org.jfree.data.time.SerialDate)var18);
//     boolean var21 = var3.isInRange((org.jfree.data.time.SerialDate)var11, (org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var3);
//     java.util.Date var23 = var3.toDate();
//     java.text.DateFormat var26 = null;
//     org.jfree.chart.axis.DateTickUnit var27 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var26);
//     java.lang.String var29 = var27.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var37 = var34.isOnOrBefore((org.jfree.data.time.SerialDate)var36);
//     boolean var38 = var32.isOnOrAfter((org.jfree.data.time.SerialDate)var36);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var41 = var40.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var48 = var45.isOnOrBefore((org.jfree.data.time.SerialDate)var47);
//     boolean var49 = var43.isOnOrAfter((org.jfree.data.time.SerialDate)var47);
//     boolean var50 = var32.isInRange((org.jfree.data.time.SerialDate)var40, (org.jfree.data.time.SerialDate)var47);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var32);
//     java.util.Date var52 = var32.toDate();
//     java.util.Date var53 = var27.rollDate(var52);
//     org.jfree.chart.plot.CategoryMarker var54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var53);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month(var53);
//     org.jfree.data.gantt.Task var56 = new org.jfree.data.gantt.Task("", var23, var53);
//     java.lang.Double var57 = var56.getPercentComplete();
//     var56.setPercentComplete(1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "12/31/69"+ "'", var29.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test5"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    double var3 = var2.getAngle();
    org.jfree.chart.axis.CategoryLabelWidthType var4 = var2.getWidthType();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var2);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var12, var16, var17, var18);
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var21 = var20.getLabelOutlinePaint();
    var19.setRangeCrosshairPaint(var21);
    var11.setDomainTickBandPaint(var21);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var24 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var27 = var24.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var29 = null;
    org.jfree.chart.renderer.WaferMapRenderer var30 = null;
    org.jfree.chart.plot.WaferMapPlot var31 = new org.jfree.chart.plot.WaferMapPlot(var29, var30);
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
    java.awt.Stroke var33 = var32.getBorderStroke();
    var24.setSeriesStroke(100, var33, true);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(0.0d, var21, var33);
    org.jfree.chart.util.LengthAdjustmentType var37 = var36.getLabelOffsetType();
    org.jfree.chart.util.LengthAdjustmentType var38 = var36.getLabelOffsetType();
    boolean var39 = var5.equals((java.lang.Object)var36);
    var36.setValue(2.787634800409E12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test6"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.2d, 3.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test7"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setSeriesItemLabelsVisible(4, true);
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 0.05d);
    boolean var7 = var0.equals((java.lang.Object)var4);
    var0.setIncludeBaseInRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test8"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var8 = null;
    var6.setRenderer(28, var8);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test9"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    int var10 = var8.getDatasetIndex();
    java.text.AttributedString var11 = var8.getAttributedLabel();
    boolean var12 = var8.isShapeFilled();
    java.lang.Comparable var13 = var8.getSeriesKey();
    int var14 = var8.getDatasetIndex();
    boolean var15 = var8.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test10"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    var1.setLowerMargin(0.0d);
    var1.setInverted(false);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test11"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var20 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var22 = var21.clone();
    java.awt.Paint var23 = var21.getBasePaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var20, var23);
    var14.setSeriesOutlinePaint(0, var23, true);
    var7.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAnchor var28 = var7.getDomainGridlinePosition();
    var7.clearDomainMarkers();
    boolean var30 = var7.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test12"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var2 = null;
    var1.setLabelOutlinePaint(var2);
    java.awt.Stroke var4 = var1.getLabelOutlineStroke();
    java.awt.Paint var5 = var1.getLabelPaint();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    var1.setLabelLinkMargin(0.05d);
    var1.setOutlineVisible(true);
    java.awt.Paint var11 = var1.getBaseSectionOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test13"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    org.jfree.chart.axis.NumberTickUnit var7 = var6.getTickUnit();
    java.lang.String var9 = var7.valueToString(100.0d);
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var12 = var11.getCategoryLabelPositionOffset();
    var11.setUpperMargin(2.0d);
    var11.setLabelAngle((-1.0d));
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    int var19 = var18.getYYYY();
    org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var24 = var21.isOnOrBefore((org.jfree.data.time.SerialDate)var23);
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var31 = var28.isOnOrBefore((org.jfree.data.time.SerialDate)var30);
    boolean var32 = var26.isOnOrAfter((org.jfree.data.time.SerialDate)var30);
    boolean var33 = var23.isBefore((org.jfree.data.time.SerialDate)var30);
    org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var38 = var35.isOnOrBefore((org.jfree.data.time.SerialDate)var37);
    org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var45 = var42.isOnOrBefore((org.jfree.data.time.SerialDate)var44);
    boolean var46 = var40.isOnOrAfter((org.jfree.data.time.SerialDate)var44);
    boolean var47 = var37.isBefore((org.jfree.data.time.SerialDate)var44);
    boolean var48 = var30.isOn((org.jfree.data.time.SerialDate)var37);
    int var49 = var18.compare((org.jfree.data.time.SerialDate)var37);
    int var50 = var37.getYYYY();
    java.awt.Paint var51 = var11.getTickLabelPaint((java.lang.Comparable)var37);
    int var52 = var37.getDayOfMonth();
    int var53 = var7.compareTo((java.lang.Object)var52);
    var0.removeColumn((java.lang.Comparable)var52);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var57 = null;
    var55.setSeriesItemLabelGenerator(1900, var57);
    boolean var59 = var55.getAutoPopulateSeriesStroke();
    boolean var60 = var55.getBaseShapesFilled();
    org.jfree.chart.urls.CategoryURLGenerator var62 = var55.getSeriesURLGenerator(1901);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var63 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var65 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var63, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var68 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var63, var67, var68, var69);
    org.jfree.chart.plot.PiePlot var71 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var72 = var71.getLabelOutlinePaint();
    var70.setRangeCrosshairPaint(var72);
    int var74 = var70.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var75 = new org.jfree.chart.axis.AxisSpace();
    var70.setFixedRangeAxisSpace(var75);
    org.jfree.chart.axis.AxisSpace var77 = new org.jfree.chart.axis.AxisSpace();
    var70.setFixedRangeAxisSpace(var77);
    var70.setRangeCrosshairValue(4.0d);
    org.jfree.chart.plot.PiePlot var81 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var82 = null;
    var81.setLabelOutlinePaint(var82);
    java.awt.Stroke var84 = var81.getLabelOutlineStroke();
    java.awt.Paint var85 = var81.getLabelPaint();
    org.jfree.data.general.WaferMapDataset var86 = null;
    org.jfree.chart.renderer.WaferMapRenderer var87 = null;
    org.jfree.chart.plot.WaferMapPlot var88 = new org.jfree.chart.plot.WaferMapPlot(var86, var87);
    org.jfree.chart.JFreeChart var89 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var88);
    java.awt.Stroke var90 = var88.getOutlineStroke();
    var81.setBaseSectionOutlineStroke(var90);
    var70.setDomainGridlineStroke(var90);
    var55.setBaseOutlineStroke(var90, false);
    boolean var95 = var0.equals((java.lang.Object)false);
    int var97 = var0.getColumnIndex((java.lang.Comparable)(byte)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "100"+ "'", var9.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == (-1));

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test14"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Stroke var4 = var3.getBorderStroke();
    boolean var5 = var3.isNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var6 = var3.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test15"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var0);
    double var2 = var1.getBarWidth();
    org.jfree.chart.plot.PlotRenderingInfo var3 = var1.getInfo();
    var1.setBarWidth((-10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test16"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
//     double var4 = var2.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var5 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var6 = var5.getChartArea();
//     java.awt.geom.Rectangle2D var9 = var2.createInsetRectangle(var6, true, false);
//     java.lang.String var10 = var2.toString();
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var13 = var11.getSectionPaint((java.lang.Comparable)10.0d);
//     boolean var14 = var11.getLabelLinksVisible();
//     java.awt.Paint var15 = var11.getLabelBackgroundPaint();
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var2, var15);
//     org.jfree.chart.util.RectangleInsets var17 = var16.getInsets();
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var19 = var18.getLabelOutlinePaint();
//     org.jfree.chart.LegendItemCollection var20 = var18.getLegendItems();
//     java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     java.awt.Color var25 = var24.darker();
//     boolean var26 = var20.equals((java.lang.Object)var24);
//     java.awt.Shape var31 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var33 = var32.clone();
//     java.awt.Paint var34 = var32.getBasePaint();
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var31, var34);
//     java.awt.Stroke var36 = var35.getOutlineStroke();
//     var20.add(var35);
//     boolean var38 = var35.isLineVisible();
//     boolean var39 = var16.equals((java.lang.Object)var38);
//     
//     // Checks the contract:  equals-hashcode on var11 and var18
//     assertTrue("Contract failed: equals-hashcode on var11 and var18", var11.equals(var18) ? var11.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var11
//     assertTrue("Contract failed: equals-hashcode on var18 and var11", var18.equals(var11) ? var18.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test17"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    java.lang.String var16 = var7.getPlotType();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    java.awt.geom.Point2D var25 = null;
    var21.zoomDomainAxes((-1.0d), 0.2d, var24, var25);
    java.awt.Paint var27 = var21.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var29 = var21.getRangeAxisLocation(1);
    var7.setDomainAxisLocation(var29, false);
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var35 = var34.getLabelInsets();
    double var37 = var35.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var38 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var39 = var38.getChartArea();
    java.awt.geom.Rectangle2D var42 = var35.createInsetRectangle(var39, true, false);
    var7.drawBackgroundImage(var32, var39);
    boolean var44 = var7.isSubplot();
    var7.configureRangeAxes();
    org.jfree.chart.axis.CategoryAxis var46 = null;
    var7.setDomainAxis(var46);
    org.jfree.chart.axis.ValueAxis var48 = null;
    var7.setRangeAxis(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Category Plot"+ "'", var16.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test18"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorUp(10.0d);
    java.util.List var3 = var0.getTicks();
    org.jfree.chart.util.RectangleEdge var5 = null;
    var0.moveCursor(0.0d, var5);
    var0.setMax(0.05d);
    var0.setMax(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test19"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(var5);
    var1.setRangeWithMargins((org.jfree.data.Range)var6);
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange(var10);
    var1.setDefaultAutoRange(var10);
    java.awt.Paint var13 = var1.getTickLabelPaint();
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var16 = null;
    var15.setLabelOutlinePaint(var16);
    java.awt.Stroke var18 = var15.getLabelOutlineStroke();
    java.awt.Paint var19 = var15.getLabelPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    double var21 = var15.getLabelGap();
    java.awt.Paint var22 = var15.getBaseSectionOutlinePaint();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    java.awt.Paint var24 = null;
    var15.setShadowPaint(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test20"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    org.jfree.chart.util.SortOrder var13 = var7.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var17 = var16.getTickMarkStroke();
    java.lang.Object var18 = var16.clone();
    var16.setMaximumCategoryLabelWidthRatio(0.5f);
    boolean var21 = var16.isAxisLineVisible();
    var7.setDomainAxis(1900, (org.jfree.chart.axis.CategoryAxis)var16);
    org.jfree.data.general.WaferMapDataset var23 = null;
    org.jfree.chart.renderer.WaferMapRenderer var24 = null;
    org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
    var26.setTitle("ThreadContext");
    java.awt.Color var32 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var33 = var32.darker();
    var26.setBorderPaint((java.awt.Paint)var33);
    org.jfree.chart.plot.Plot var35 = var26.getPlot();
    var26.setTitle("ThreadContext");
    var7.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    java.awt.Stroke var39 = var7.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test21"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var2 = null;
    var1.setLabelOutlinePaint(var2);
    java.awt.Stroke var4 = var1.getLabelOutlineStroke();
    java.awt.Paint var5 = var1.getLabelPaint();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    double var7 = var1.getLabelGap();
    java.awt.Paint var8 = var1.getLabelOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test22"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    int var10 = var8.getDatasetIndex();
    java.text.AttributedString var11 = var8.getAttributedLabel();
    boolean var12 = var8.isShapeVisible();
    org.jfree.chart.util.GradientPaintTransformer var13 = var8.getFillPaintTransformer();
    java.awt.Stroke var14 = var8.getLineStroke();
    int var15 = var8.getDatasetIndex();
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var20 = var17.isOnOrBefore((org.jfree.data.time.SerialDate)var19);
    var8.setSeriesKey((java.lang.Comparable)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test23"); }


    java.lang.Number var0 = null;
    org.jfree.data.DefaultKeyedValues2D var8 = new org.jfree.data.DefaultKeyedValues2D();
    var8.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var13 = null;
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var21 = var18.isOnOrBefore((org.jfree.data.time.SerialDate)var20);
    boolean var22 = var16.isOnOrAfter((org.jfree.data.time.SerialDate)var20);
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
    int var25 = var24.getYYYY();
    org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var32 = var29.isOnOrBefore((org.jfree.data.time.SerialDate)var31);
    boolean var33 = var27.isOnOrAfter((org.jfree.data.time.SerialDate)var31);
    boolean var34 = var16.isInRange((org.jfree.data.time.SerialDate)var24, (org.jfree.data.time.SerialDate)var31);
    var8.addValue(var13, (java.lang.Comparable)' ', (java.lang.Comparable)var16);
    java.util.List var36 = var8.getRowKeys();
    org.jfree.data.statistics.BoxAndWhiskerItem var37 = new org.jfree.data.statistics.BoxAndWhiskerItem(var0, (java.lang.Number)1900, (java.lang.Number)(short)100, (java.lang.Number)Double.NaN, (java.lang.Number)10L, (java.lang.Number)2, (java.lang.Number)(short)1, (java.lang.Number)(byte)1, var36);
    java.lang.Number var38 = var37.getQ3();
    java.lang.Number var39 = var37.getQ1();
    org.jfree.data.xy.XYDataset var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
    double var45 = var44.getDomainCrosshairValue();
    int var46 = var44.getSeriesCount();
    java.awt.geom.Point2D var47 = var44.getQuadrantOrigin();
    boolean var48 = var37.equals((java.lang.Object)var44);
    java.lang.Number var49 = var37.getQ3();
    java.lang.Number var50 = var37.getMinRegularValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + Double.NaN+ "'", var38.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + (short)100+ "'", var39.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + Double.NaN+ "'", var49.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + 10L+ "'", var50.equals(10L));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test24"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(true);
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, (java.lang.Comparable[])var3, var4, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var7.getValue((-1), 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test25"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var7 = var6.getBorderStroke();
    var0.setRadiusGridlineStroke(var7);
    org.jfree.chart.axis.ValueAxis var9 = var0.getAxis();
    var0.addCornerTextItem("Last");
    boolean var12 = var0.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test26"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    boolean var3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var2);
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var2, (java.lang.Comparable)"12/31/69", 0.05d, 0);
    org.jfree.chart.plot.PiePlot3D var8 = new org.jfree.chart.plot.PiePlot3D(var7);
    java.lang.String var9 = var8.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "Pie 3D Plot"+ "'", var9.equals("Pie 3D Plot"));

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test27"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var6 = var4.getRangeZeroBaselineStroke();
    var4.setRangeGridlinesVisible(true);
    org.jfree.data.general.WaferMapDataset var9 = null;
    org.jfree.chart.renderer.WaferMapRenderer var10 = null;
    org.jfree.chart.plot.WaferMapPlot var11 = new org.jfree.chart.plot.WaferMapPlot(var9, var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    java.awt.Stroke var13 = var12.getBorderStroke();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var20 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var22 = var21.clone();
    java.awt.Paint var23 = var21.getBasePaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var20, var23);
    var14.setSeriesOutlinePaint(0, var23, true);
    java.awt.Stroke var28 = var14.lookupSeriesOutlineStroke(10);
    var12.setBorderStroke(var28);
    var4.setRangeZeroBaselineStroke(var28);
    var4.setDomainGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test28"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(false);
    var0.setTranslateY(Double.NaN);
    double var5 = var0.getTranslateX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test29"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
    var0.setItemMargin(1.0d);
    double var7 = var0.getItemMargin();
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    var8.setLegendItemShape((java.awt.Shape)var10);
    var0.setBaseShape((java.awt.Shape)var10);
    org.jfree.chart.entity.LegendItemEntity var13 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var10);
    java.lang.Object var14 = var13.clone();
    org.jfree.data.general.Dataset var15 = var13.getDataset();
    java.lang.String var16 = var13.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test30"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ItemLabelAnchor.CENTER");

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test31"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var11.setTitle("ThreadContext");
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var11.setBorderPaint((java.awt.Paint)var18);
    var7.setRangeGridlinePaint((java.awt.Paint)var18);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var25.zoomDomainAxes((-1.0d), 0.2d, var28, var29);
    java.awt.Paint var31 = var25.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var33 = var25.getRangeAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var34 = org.jfree.chart.axis.AxisLocation.getOpposite(var33);
    var7.setDomainAxisLocation(var33, true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var38 = var7.getRenderer(0);
    org.jfree.chart.axis.AxisLocation var39 = var7.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test32"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(var5);
    var1.setRangeWithMargins((org.jfree.data.Range)var6);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelInsets();
    double var12 = var10.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var13 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var14 = var13.getChartArea();
    java.awt.geom.Rectangle2D var17 = var10.createInsetRectangle(var14, true, false);
    var1.setDownArrow((java.awt.Shape)var17);
    java.lang.Object var19 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test33"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
    java.awt.Color var6 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var7 = var6.darker();
    boolean var8 = var2.equals((java.lang.Object)var6);
    java.awt.Shape var13 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var14 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var15 = var14.clone();
    java.awt.Paint var16 = var14.getBasePaint();
    org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var13, var16);
    java.awt.Stroke var18 = var17.getOutlineStroke();
    var2.add(var17);
    boolean var20 = var17.isLineVisible();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var21 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var21, (java.lang.Comparable)'a');
    org.jfree.chart.plot.MultiplePiePlot var24 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var21);
    java.lang.Number var25 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var21);
    var17.setDataset((org.jfree.data.general.Dataset)var21);
    java.lang.Object var27 = var21.clone();
    boolean var28 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var21);
    org.jfree.data.general.PieDataset var30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var21, 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + 0.0d+ "'", var25.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test34"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var3 = new org.jfree.chart.urls.StandardCategoryURLGenerator("", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "Mar");

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test35"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getObjectIcon();
    boolean var2 = var0.isDrawLines();
    java.awt.Shape var5 = var0.getItemShape(1900, 31);
    javax.swing.Icon var6 = var0.getObjectIcon();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test36"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
    java.lang.Boolean var3 = var0.getSeriesVisibleInLegend(4);
    var0.setDrawOutlines(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test37"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    double var3 = var2.getAngle();
    org.jfree.chart.axis.CategoryLabelWidthType var4 = var2.getWidthType();
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var2);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var10, var11, var12);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var13.setRenderer(var14, true);
    var13.clearDomainMarkers(10);
    org.jfree.chart.axis.CategoryAnchor var19 = var13.getDomainGridlinePosition();
    org.jfree.chart.util.RectangleEdge var21 = var13.getDomainAxisEdge((-1));
    org.jfree.chart.axis.CategoryLabelPosition var22 = var1.getLabelPosition(var21);
    org.jfree.chart.text.TextBlockAnchor var23 = var22.getLabelAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test38"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("black");

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test39"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition((-1));
    var0.setBasePositiveItemLabelPosition(var5, true);
    var0.setMinimumBarLength(10.0d);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getPositiveItemLabelPosition(10, 1900);
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var15 = null;
    var14.setLabelOutlinePaint(var15);
    java.awt.Stroke var17 = var14.getLabelOutlineStroke();
    java.awt.Paint var18 = var14.getLabelPaint();
    org.jfree.chart.plot.AbstractPieLabelDistributor var19 = var14.getLabelDistributor();
    boolean var20 = var13.equals((java.lang.Object)var19);
    org.jfree.data.general.WaferMapDataset var21 = null;
    org.jfree.chart.renderer.WaferMapRenderer var22 = null;
    org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot(var21, var22);
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    java.awt.Image var25 = null;
    var24.setBackgroundImage(var25);
    org.jfree.chart.title.TextTitle var27 = null;
    var24.setTitle(var27);
    var24.setAntiAlias(false);
    float var31 = var24.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var32 = var24.getLegend();
    var24.setNotify(false);
    java.util.List var35 = var24.getSubtitles();
    org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var38 = var37.getTickMarkStroke();
    org.jfree.chart.util.RectangleInsets var39 = var37.getTickLabelInsets();
    double var41 = var39.calculateLeftOutset(100.0d);
    var24.setPadding(var39);
    boolean var43 = var13.equals((java.lang.Object)var24);
    org.jfree.data.DefaultKeyedValues var44 = new org.jfree.data.DefaultKeyedValues();
    java.util.List var45 = var44.getKeys();
    java.lang.Object var46 = var44.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var24.setTextAntiAlias((java.lang.Object)var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test40"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition((-1));
    var0.setBasePositiveItemLabelPosition(var5, true);
    var0.setMinimumBarLength(10.0d);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getPositiveItemLabelPosition(10, 1900);
    org.jfree.chart.labels.ItemLabelAnchor var14 = var13.getItemLabelAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test41"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var7 = var6.getBorderStroke();
    var0.setRadiusGridlineStroke(var7);
    java.awt.Paint var9 = var0.getAngleGridlinePaint();
    org.jfree.data.general.DatasetChangeEvent var10 = null;
    var0.datasetChanged(var10);
    java.awt.Shape var16 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var17 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var18 = var17.clone();
    java.awt.Paint var19 = var17.getBasePaint();
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var16, var19);
    java.awt.Stroke var21 = var20.getOutlineStroke();
    int var22 = var20.getDatasetIndex();
    java.awt.Stroke var23 = var20.getOutlineStroke();
    java.awt.Paint var24 = var20.getOutlinePaint();
    var0.setAngleGridlinePaint(var24);
    var0.setAngleGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test42"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var5, var6, var7);
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var10 = var9.getLabelOutlinePaint();
    var8.setRangeCrosshairPaint(var10);
    int var12 = var8.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var13 = new org.jfree.chart.axis.AxisSpace();
    var8.setFixedRangeAxisSpace(var13);
    org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
    var8.setFixedRangeAxisSpace(var15);
    org.jfree.chart.axis.CategoryAxis var18 = var8.getDomainAxisForDataset(0);
    org.jfree.chart.util.RectangleEdge var19 = var8.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var23 = var22.getLabel();
    org.jfree.data.KeyedObject var24 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var22);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var27 = var26.getLabelInsets();
    double var29 = var27.calculateTopInset(100.0d);
    var22.setTickLabelInsets(var27);
    int var31 = var8.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var22);
    org.jfree.data.general.WaferMapDataset var32 = null;
    org.jfree.chart.renderer.WaferMapRenderer var33 = null;
    org.jfree.chart.plot.WaferMapPlot var34 = new org.jfree.chart.plot.WaferMapPlot(var32, var33);
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var34);
    java.awt.Image var36 = null;
    var35.setBackgroundImage(var36);
    var35.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var39 = var35.getPadding();
    var8.setInsets(var39, false);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    org.jfree.chart.util.Layer var48 = null;
    java.util.Collection var49 = var46.getRangeMarkers(0, var48);
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.data.Range var51 = var46.getDataRange(var50);
    var46.clearAnnotations();
    java.awt.Paint var53 = var46.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var55 = null;
    org.jfree.chart.axis.ValueAxis var56 = null;
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
    org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
    org.jfree.chart.plot.PlotRenderingInfo var62 = null;
    java.awt.geom.Point2D var63 = null;
    var59.zoomDomainAxes((-1.0d), 0.2d, var62, var63);
    java.awt.Paint var65 = var59.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var67 = var59.getRangeAxisLocation(1);
    java.lang.Object var68 = null;
    boolean var69 = var67.equals(var68);
    var46.setDomainAxisLocation(0, var67);
    var8.setDomainAxisLocation(var67);
    org.jfree.chart.axis.AxisLocation var72 = var8.getRangeAxisLocation();
    boolean var73 = var0.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + ""+ "'", var23.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test43"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Paint var3 = var1.getBasePaint();
//     boolean var4 = var1.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var1.getURLGenerator(100, 4);
//     java.awt.Font var9 = null;
//     var1.setSeriesItemLabelFont(0, var9, true);
//     java.awt.Font var12 = var1.getBaseItemLabelFont();
//     boolean var13 = var0.equals((java.lang.Object)var1);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("Category Plot");
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.axis.SegmentedTimeline var17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.text.DateFormat var20 = null;
//     org.jfree.chart.axis.DateTickUnit var21 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var20);
//     java.lang.String var23 = var21.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var31 = var28.isOnOrBefore((org.jfree.data.time.SerialDate)var30);
//     boolean var32 = var26.isOnOrAfter((org.jfree.data.time.SerialDate)var30);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var35 = var34.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var42 = var39.isOnOrBefore((org.jfree.data.time.SerialDate)var41);
//     boolean var43 = var37.isOnOrAfter((org.jfree.data.time.SerialDate)var41);
//     boolean var44 = var26.isInRange((org.jfree.data.time.SerialDate)var34, (org.jfree.data.time.SerialDate)var41);
//     org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var26);
//     java.util.Date var46 = var26.toDate();
//     java.util.Date var47 = var21.rollDate(var46);
//     int var48 = var21.getUnit();
//     org.jfree.chart.axis.SegmentedTimeline var52 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var54 = var52.getSegment(100L);
//     org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var62 = var59.isOnOrBefore((org.jfree.data.time.SerialDate)var61);
//     boolean var63 = var57.isOnOrAfter((org.jfree.data.time.SerialDate)var61);
//     org.jfree.data.time.SpreadsheetDate var65 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var66 = var65.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var70 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var72 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var73 = var70.isOnOrBefore((org.jfree.data.time.SerialDate)var72);
//     boolean var74 = var68.isOnOrAfter((org.jfree.data.time.SerialDate)var72);
//     boolean var75 = var57.isInRange((org.jfree.data.time.SerialDate)var65, (org.jfree.data.time.SerialDate)var72);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var57);
//     java.util.Date var77 = var57.toDate();
//     boolean var78 = var52.containsDomainValue(var77);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.createInstance(var77);
//     java.util.Date var80 = var21.addToDate(var77);
//     var17.addBaseTimelineException(var77);
//     var17.addBaseTimelineException((-2208787199569L));
//     long var84 = var17.getSegmentSize();
//     var15.setTimeline((org.jfree.chart.axis.Timeline)var17);
//     var0.setTimeline((org.jfree.chart.axis.Timeline)var17);
//     float var87 = var0.getTickMarkOutsideLength();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var23 + "' != '" + "12/31/69"+ "'", var23.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 900000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 2.0f);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test44"); }


    org.jfree.data.DefaultKeyedValue var2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)(short)10, (java.lang.Number)1900);
    var2.setValue((java.lang.Number)4);
    var2.setValue((java.lang.Number)31);
    java.lang.Object var7 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(2.0d, 10.0d);
    boolean var11 = var2.equals((java.lang.Object)10.0d);
    java.lang.String var12 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "(10, 31)"+ "'", var12.equals("(10, 31)"));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test45"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(2777097600000L, (-668), (-668));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test46"); }


    org.jfree.chart.ChartRenderingInfo var0 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var1 = var0.getChartArea();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.plot.PlotRenderingInfo var3 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var4 = var0.getChartArea();
    java.awt.geom.Rectangle2D var5 = var0.getChartArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test47"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    boolean var8 = var5.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var11 = var5.getURLGenerator(100, 4);
    java.awt.Font var13 = null;
    var5.setSeriesItemLabelFont(0, var13, true);
    java.awt.Font var16 = var5.getBaseItemLabelFont();
    java.awt.Color var20 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var20);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var28 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var29 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var30 = var29.clone();
    java.awt.Paint var31 = var29.getBasePaint();
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var28, var31);
    var22.setSeriesOutlinePaint(0, var31, true);
    org.jfree.chart.text.TextMeasurer var36 = null;
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, var31, 0.0f, var36);
    org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var39 = null;
    var38.setLabelOutlinePaint(var39);
    java.awt.Stroke var41 = var38.getLabelOutlineStroke();
    java.awt.Paint var42 = var38.getLabelPaint();
    org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("", var16, var42);
    org.jfree.chart.text.TextFragment var44 = var43.getFirstTextFragment();
    float var45 = var44.getBaselineOffset();
    java.awt.Font var46 = var44.getFont();
    var1.setBaseItemLabelFont(var46);
    org.jfree.chart.text.TextLine var48 = new org.jfree.chart.text.TextLine("ThreadContext", var46);
    org.jfree.chart.text.TextFragment var49 = var48.getFirstTextFragment();
    org.jfree.chart.text.TextFragment var50 = var48.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test48"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var2 = var0.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var3 = var0.getLabelLinksVisible();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    var8.zoomDomainAxes(2.0d, 1.0d, var14, var15);
    java.awt.Color var20 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var8.setDomainCrosshairPaint((java.awt.Paint)var20);
    int var22 = var20.getRGB();
    var0.setBackgroundPaint((java.awt.Paint)var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-16777216));

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test49"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var2 = var1.clone();
    int var3 = var1.getMaximumCategoryLabelLines();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    boolean var8 = var5.getBaseSeriesVisible();
    org.jfree.chart.util.GradientPaintTransformer var9 = null;
    var5.setGradientPaintTransformer(var9);
    java.awt.Paint var13 = var5.getItemLabelPaint(31, 1900);
    var1.setTickLabelPaint((java.lang.Comparable)"rect", var13);
    java.text.DateFormat var19 = null;
    org.jfree.chart.axis.DateTickUnit var20 = new org.jfree.chart.axis.DateTickUnit(0, (-2097352), (-1), (-2097352), var19);
    java.awt.Paint var21 = var1.getTickLabelPaint((java.lang.Comparable)(-2097352));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test50"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    java.awt.Stroke var3 = var0.getLabelOutlineStroke();
    java.awt.Paint var4 = var0.getLabelPaint();
    org.jfree.data.general.DatasetChangeEvent var5 = null;
    var0.datasetChanged(var5);
    org.jfree.chart.labels.PieToolTipGenerator var7 = var0.getToolTipGenerator();
    org.jfree.data.general.PieDataset var8 = var0.getDataset();
    boolean var9 = var0.isCircular();
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var15 = var12.isOnOrBefore((org.jfree.data.time.SerialDate)var14);
    int var16 = var14.getDayOfMonth();
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addYears(255, (org.jfree.data.time.SerialDate)var14);
    java.awt.Paint var18 = var0.getSectionOutlinePaint((java.lang.Comparable)255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test51"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.util.Layer var11 = null;
    java.util.Collection var12 = var4.getDomainMarkers(var11);
    boolean var13 = var4.isRangeZeroBaselineVisible();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers(0, var21);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.data.Range var24 = var19.getDataRange(var23);
    var19.clearAnnotations();
    java.awt.Paint var26 = var19.getDomainCrosshairPaint();
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    java.awt.geom.Point2D var36 = null;
    var32.zoomDomainAxes((-1.0d), 0.2d, var35, var36);
    java.awt.Paint var38 = var32.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var40 = var32.getRangeAxisLocation(1);
    java.lang.Object var41 = null;
    boolean var42 = var40.equals(var41);
    var19.setDomainAxisLocation(0, var40);
    var4.setRangeAxisLocation(0, var40, true);
    org.jfree.chart.util.RectangleInsets var46 = var4.getAxisOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test52"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(var5);
    var1.setRangeWithMargins((org.jfree.data.Range)var6);
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange(var10);
    var1.setDefaultAutoRange(var10);
    java.awt.Paint var13 = var1.getTickLabelPaint();
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var16 = null;
    var15.setLabelOutlinePaint(var16);
    java.awt.Stroke var18 = var15.getLabelOutlineStroke();
    java.awt.Paint var19 = var15.getLabelPaint();
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var15);
    double var21 = var15.getLabelGap();
    java.awt.Paint var22 = var15.getBaseSectionOutlinePaint();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    org.jfree.chart.LegendItemCollection var24 = var15.getLegendItems();
    java.awt.Paint var25 = var15.getLabelOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test53"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    var1.setAutoTickUnitSelection(true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test54"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    java.awt.Paint var11 = null;
    var4.setDomainTickBandPaint(var11);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var15 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var19, var20, var21);
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var24 = var23.getLabelOutlinePaint();
    var22.setRangeCrosshairPaint(var24);
    int var26 = var22.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var27 = new org.jfree.chart.axis.AxisSpace();
    var22.setFixedRangeAxisSpace(var27);
    org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
    var22.setFixedRangeAxisSpace(var29);
    java.lang.String var31 = var22.getPlotType();
    java.awt.Paint var32 = var22.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var35 = var34.getTickMarkStroke();
    org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var37 = null;
    var36.setLabelOutlinePaint(var37);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var45 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var47 = var46.clone();
    java.awt.Paint var48 = var46.getBasePaint();
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var45, var48);
    var39.setSeriesOutlinePaint(0, var48, true);
    var36.setBackgroundPaint(var48);
    java.awt.Stroke var53 = null;
    org.jfree.chart.plot.IntervalMarker var55 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var32, var35, var48, var53, 0.0f);
    org.jfree.data.general.WaferMapDataset var56 = null;
    org.jfree.chart.renderer.WaferMapRenderer var57 = null;
    org.jfree.chart.plot.WaferMapPlot var58 = new org.jfree.chart.plot.WaferMapPlot(var56, var57);
    org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var58);
    java.awt.Image var60 = null;
    var59.setBackgroundImage(var60);
    var59.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var63 = var59.getPadding();
    var55.setLabelOffset(var63);
    var4.setAxisOffset(var63);
    boolean var66 = var4.isDomainGridlinesVisible();
    int var67 = var4.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "Category Plot"+ "'", var31.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test55"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    java.awt.Paint var1 = var0.getLastBarPaint();
    java.awt.Paint var2 = var0.getLastBarPaint();
    java.lang.Comparable var3 = null;
    java.awt.Shape var8 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var9 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var10 = var9.clone();
    java.awt.Paint var11 = var9.getBasePaint();
    org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var8, var11);
    java.awt.Stroke var13 = var12.getOutlineStroke();
    int var14 = var12.getDatasetIndex();
    java.text.AttributedString var15 = var12.getAttributedLabel();
    boolean var16 = var12.isShapeVisible();
    java.awt.Shape var17 = var12.getLine();
    org.jfree.chart.entity.CategoryLabelEntity var20 = new org.jfree.chart.entity.CategoryLabelEntity(var3, var17, "ChartEntity: tooltip = XY Plot", "Last");
    var0.setBaseShape(var17);
    java.awt.Shape var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-2097352), var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test56"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(true);
    java.lang.Number[][] var4 = null;
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, (java.lang.Comparable[])var3, var4, var6);
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var10 = var9.getCategoryLabelPositionOffset();
    java.awt.Paint var11 = var9.getAxisLinePaint();
    java.awt.Stroke var12 = var9.getTickMarkStroke();
    int var13 = var9.getCategoryLabelPositionOffset();
    org.jfree.data.general.SeriesChangeEvent var14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var13);
    java.lang.Object var15 = var14.getSource();
    var7.seriesChanged(var14);
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var17 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var18 = var17.getItemMargin();
    org.jfree.chart.LegendItem var21 = var17.getLegendItem(100, 0);
    var17.setItemMargin(1.0d);
    double var24 = var17.getItemMargin();
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var27 = var26.getChartArea();
    var25.setLegendItemShape((java.awt.Shape)var27);
    var17.setBaseShape((java.awt.Shape)var27);
    var17.setFillBox(true);
    boolean var32 = var7.equals((java.lang.Object)true);
    java.lang.Comparable[] var34 = new java.lang.Comparable[] { "Default Group"};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setSeriesKeys(var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 4+ "'", var15.equals(4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test57"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = var0.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var7 = var6.getLabelOutlinePaint();
    var4.setBackgroundPaint(var7);
    var0.setLabelShadowPaint(var7);
    var0.setOutlineVisible(false);
    var0.setLabelLinkMargin((-10.0d));
    org.jfree.chart.labels.PieToolTipGenerator var14 = var0.getToolTipGenerator();
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var16 = var15.getURLGenerator();
    java.awt.Color var21 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var15.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var21);
    java.awt.color.ColorSpace var23 = var21.getColorSpace();
    int var24 = var21.getGreen();
    var0.setBaseSectionOutlinePaint((java.awt.Paint)var21);
    org.jfree.data.general.WaferMapDataset var26 = null;
    org.jfree.chart.renderer.WaferMapRenderer var27 = null;
    org.jfree.chart.plot.WaferMapPlot var28 = new org.jfree.chart.plot.WaferMapPlot(var26, var27);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
    java.awt.Image var30 = null;
    var29.setBackgroundImage(var30);
    org.jfree.chart.title.TextTitle var32 = null;
    var29.setTitle(var32);
    var29.setAntiAlias(false);
    float var36 = var29.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var37 = var29.getLegend();
    java.awt.Paint var38 = var37.getBackgroundPaint();
    org.jfree.chart.block.BlockBorder var43 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
    var37.setFrame((org.jfree.chart.block.BlockFrame)var43);
    java.awt.Paint var45 = var43.getPaint();
    var0.setLabelShadowPaint(var45);
    org.jfree.chart.plot.PiePlot var48 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var49 = null;
    var48.setLabelOutlinePaint(var49);
    java.awt.Stroke var51 = var48.getLabelOutlineStroke();
    java.awt.Paint var52 = var48.getLabelPaint();
    org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var48);
    double var54 = var48.getLabelGap();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var55 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var56 = var55.clone();
    java.awt.Paint var57 = var55.getBasePaint();
    var48.setLabelPaint(var57);
    org.jfree.chart.labels.PieSectionLabelGenerator var59 = var48.getLegendLabelGenerator();
    var0.setLegendLabelToolTipGenerator(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test58"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     var0.zoomRange(0.2d, 0.0d);
//     var0.configure();
//     java.text.DateFormat var7 = null;
//     org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var7);
//     java.lang.String var10 = var8.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var18 = var15.isOnOrBefore((org.jfree.data.time.SerialDate)var17);
//     boolean var19 = var13.isOnOrAfter((org.jfree.data.time.SerialDate)var17);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var22 = var21.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var29 = var26.isOnOrBefore((org.jfree.data.time.SerialDate)var28);
//     boolean var30 = var24.isOnOrAfter((org.jfree.data.time.SerialDate)var28);
//     boolean var31 = var13.isInRange((org.jfree.data.time.SerialDate)var21, (org.jfree.data.time.SerialDate)var28);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var13);
//     java.util.Date var33 = var13.toDate();
//     java.util.Date var34 = var8.rollDate(var33);
//     java.text.DateFormat var37 = null;
//     org.jfree.chart.axis.DateTickUnit var38 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var37);
//     java.lang.String var40 = var38.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var48 = var45.isOnOrBefore((org.jfree.data.time.SerialDate)var47);
//     boolean var49 = var43.isOnOrAfter((org.jfree.data.time.SerialDate)var47);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var52 = var51.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var54 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var59 = var56.isOnOrBefore((org.jfree.data.time.SerialDate)var58);
//     boolean var60 = var54.isOnOrAfter((org.jfree.data.time.SerialDate)var58);
//     boolean var61 = var43.isInRange((org.jfree.data.time.SerialDate)var51, (org.jfree.data.time.SerialDate)var58);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var43);
//     java.util.Date var63 = var43.toDate();
//     java.util.Date var64 = var38.rollDate(var63);
//     org.jfree.chart.plot.CategoryMarker var65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var64);
//     java.util.Date var66 = var8.rollDate(var64);
//     var0.setMaximumDate(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "12/31/69"+ "'", var10.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var40 + "' != '" + "12/31/69"+ "'", var40.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test59"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("May 2058", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test60"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    boolean var3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var2);
    org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D(var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = var4.getLegendLabelGenerator();
    float var6 = var4.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test61"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var15.getRangeMarkers(0, var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.data.Range var20 = var15.getDataRange(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var15.setFixedDomainAxisSpace(var21);
    java.awt.Paint var23 = null;
    var15.setRangeTickBandPaint(var23);
    java.awt.geom.Point2D var25 = var15.getQuadrantOrigin();
    var7.zoomRangeAxes(10.0d, 0.0d, var10, var25);
    var7.setAnchorValue((-1.0d), true);
    java.awt.Paint var30 = var7.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var33 = var32.getTickMarkStroke();
    var32.setAxisLineVisible(true);
    var7.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var32);
    java.util.List var37 = var7.getAnnotations();
    org.jfree.data.category.CategoryDataset var39 = var7.getDataset(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test62"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    var3.fireChartChanged();
    var3.removeLegend();
    org.jfree.chart.title.TextTitle var8 = var3.getTitle();
    boolean var9 = var3.isBorderVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test63"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.data.time.TimePeriodFormatException: ");

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test64"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(2.0d, 10.0d);
    var2.setMinimumBarLength(0.2d);
    java.awt.Stroke var6 = var2.getSeriesOutlineStroke((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test65"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    double var5 = var4.getDomainCrosshairValue();
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var8 = null;
    var7.setLabelOutlinePaint(var8);
    java.awt.Stroke var10 = var7.getLabelOutlineStroke();
    java.awt.Paint var11 = var7.getLabelPaint();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var7);
    double var13 = var7.getLabelGap();
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var15 = var14.getURLGenerator();
    java.awt.Color var20 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var14.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var20);
    java.awt.color.ColorSpace var22 = var20.getColorSpace();
    var7.setShadowPaint((java.awt.Paint)var20);
    var4.setRangeGridlinePaint((java.awt.Paint)var20);
    org.jfree.chart.renderer.category.StackedAreaRenderer var26 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
    var26.setRenderAsPercentages(true);
    boolean var29 = var20.equals((java.lang.Object)true);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var34.getRangeMarkers(0, var36);
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    java.awt.geom.Point2D var41 = null;
    var34.zoomDomainAxes(2.0d, 1.0d, var40, var41);
    java.awt.Color var46 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var34.setDomainCrosshairPaint((java.awt.Paint)var46);
    int var48 = var46.getRGB();
    java.awt.color.ColorSpace var49 = var46.getColorSpace();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var50 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    var50.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var53 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var55 = var53.getSeriesNegativeItemLabelPosition((-1));
    var50.setBasePositiveItemLabelPosition(var55, true);
    org.jfree.chart.text.TextAnchor var58 = var55.getTextAnchor();
    boolean var60 = var58.equals((java.lang.Object)"hi!");
    java.awt.Color var64 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.lang.String var65 = org.jfree.chart.util.PaintUtilities.colorToString(var64);
    java.lang.String var66 = var64.toString();
    boolean var67 = var58.equals((java.lang.Object)var64);
    float[] var68 = null;
    float[] var69 = var64.getComponents(var68);
    float[] var70 = var20.getComponents(var49, var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "black"+ "'", var65.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var66.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test66"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    java.awt.Paint var3 = var1.getBasePaint();
    boolean var4 = var1.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var7 = var1.getURLGenerator(100, 4);
    java.awt.Font var9 = null;
    var1.setSeriesItemLabelFont(0, var9, true);
    java.awt.Font var12 = var1.getBaseItemLabelFont();
    boolean var13 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var15 = null;
    var14.setLabelOutlinePaint(var15);
    java.awt.Stroke var17 = var14.getLabelOutlineStroke();
    java.awt.Paint var18 = var14.getLabelPaint();
    var14.setIgnoreZeroValues(true);
    boolean var21 = var0.equals((java.lang.Object)true);
    boolean var23 = var0.isHiddenValue(0L);
    org.jfree.data.gantt.TaskSeriesCollection var24 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var25 = var24.getColumnCount();
    org.jfree.data.time.SimpleTimePeriod var28 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
    java.util.Date var29 = var28.getStart();
    org.jfree.data.gantt.TaskSeries var30 = var24.getSeries((java.lang.Comparable)var29);
    var0.setMinimumDate(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test67"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    var4.clearDomainMarkers();
    org.jfree.data.general.WaferMapDataset var11 = null;
    org.jfree.chart.renderer.WaferMapRenderer var12 = null;
    org.jfree.chart.plot.WaferMapPlot var13 = new org.jfree.chart.plot.WaferMapPlot(var11, var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var13);
    java.awt.Stroke var15 = var14.getBorderStroke();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var22 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var23 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var24 = var23.clone();
    java.awt.Paint var25 = var23.getBasePaint();
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var22, var25);
    var16.setSeriesOutlinePaint(0, var25, true);
    java.awt.Stroke var30 = var16.lookupSeriesOutlineStroke(10);
    var14.setBorderStroke(var30);
    var4.setRangeZeroBaselineStroke(var30);
    var4.setRangeCrosshairVisible(true);
    var4.clearDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test68"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(Double.POSITIVE_INFINITY);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test69"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    org.jfree.chart.util.SortOrder var13 = var7.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var17 = var16.getTickMarkStroke();
    java.lang.Object var18 = var16.clone();
    var16.setMaximumCategoryLabelWidthRatio(0.5f);
    boolean var21 = var16.isAxisLineVisible();
    var7.setDomainAxis(1900, (org.jfree.chart.axis.CategoryAxis)var16);
    org.jfree.data.general.WaferMapDataset var23 = null;
    org.jfree.chart.renderer.WaferMapRenderer var24 = null;
    org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
    var26.setTitle("ThreadContext");
    java.awt.Color var32 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var33 = var32.darker();
    var26.setBorderPaint((java.awt.Paint)var33);
    org.jfree.chart.plot.Plot var35 = var26.getPlot();
    var26.setTitle("ThreadContext");
    var7.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var26);
    org.jfree.chart.util.HorizontalAlignment var39 = null;
    org.jfree.chart.util.VerticalAlignment var40 = null;
    org.jfree.chart.block.FlowArrangement var43 = new org.jfree.chart.block.FlowArrangement(var39, var40, 3.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var44 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var45 = var44.clone();
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
    java.lang.String var47 = var46.getToolTipText();
    var44.add((org.jfree.chart.block.Block)var46);
    org.jfree.chart.util.RectangleEdge var49 = var46.getPosition();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var52 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var53 = var52.clone();
    java.awt.Paint var54 = var52.getBasePaint();
    boolean var55 = var52.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var58 = var52.getURLGenerator(100, 4);
    java.awt.Font var60 = null;
    var52.setSeriesItemLabelFont(0, var60, true);
    java.awt.Font var63 = var52.getBaseItemLabelFont();
    java.awt.Color var67 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var68 = org.jfree.chart.text.TextUtilities.createTextBlock("", var63, (java.awt.Paint)var67);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var69 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var75 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var76 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var77 = var76.clone();
    java.awt.Paint var78 = var76.getBasePaint();
    org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var75, var78);
    var69.setSeriesOutlinePaint(0, var78, true);
    org.jfree.chart.text.TextMeasurer var83 = null;
    org.jfree.chart.text.TextBlock var84 = org.jfree.chart.text.TextUtilities.createTextBlock("", var63, var78, 0.0f, var83);
    var43.add((org.jfree.chart.block.Block)var46, (java.lang.Object)0.0f);
    var46.setID("rect");
    java.lang.String var88 = var46.getText();
    var26.setTitle(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + ""+ "'", var88.equals(""));

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test70"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.title.LegendTitle var4 = var3.getLegend();
    org.jfree.chart.event.ChartProgressListener var5 = null;
    var3.removeProgressListener(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test71"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var11.setTitle("ThreadContext");
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var11.setBorderPaint((java.awt.Paint)var18);
    var7.setRangeGridlinePaint((java.awt.Paint)var18);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var25.zoomDomainAxes((-1.0d), 0.2d, var28, var29);
    java.awt.Paint var31 = var25.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var33 = var25.getRangeAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var34 = org.jfree.chart.axis.AxisLocation.getOpposite(var33);
    var7.setDomainAxisLocation(var33, true);
    java.awt.Paint var37 = var7.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var38 = var7.getAxisOffset();
    boolean var39 = var7.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test72"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelInsets();
    double var8 = var6.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    java.awt.geom.Rectangle2D var13 = var6.createInsetRectangle(var10, true, false);
    java.awt.geom.Point2D var14 = null;
    org.jfree.chart.plot.PlotState var15 = new org.jfree.chart.plot.PlotState();
    java.util.Map var16 = var15.getSharedAxisStates();
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    var0.draw(var3, var13, var14, var15, var17);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var22 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var23 = var22.clone();
    java.awt.Paint var24 = var22.getBasePaint();
    boolean var25 = var22.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var28 = var22.getURLGenerator(100, 4);
    java.awt.Font var30 = null;
    var22.setSeriesItemLabelFont(0, var30, true);
    java.awt.Font var33 = var22.getBaseItemLabelFont();
    java.awt.Color var37 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var33, (java.awt.Paint)var37);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var45 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var47 = var46.clone();
    java.awt.Paint var48 = var46.getBasePaint();
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var45, var48);
    var39.setSeriesOutlinePaint(0, var48, true);
    org.jfree.chart.text.TextMeasurer var53 = null;
    org.jfree.chart.text.TextBlock var54 = org.jfree.chart.text.TextUtilities.createTextBlock("", var33, var48, 0.0f, var53);
    org.jfree.chart.plot.PiePlot var55 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var56 = null;
    var55.setLabelOutlinePaint(var56);
    java.awt.Stroke var58 = var55.getLabelOutlineStroke();
    java.awt.Paint var59 = var55.getLabelPaint();
    org.jfree.chart.text.TextLine var60 = new org.jfree.chart.text.TextLine("", var33, var59);
    var0.setAngleLabelFont(var33);
    org.jfree.data.xy.XYDataset var62 = null;
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
    org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot(var62, var63, var64, var65);
    org.jfree.chart.plot.PlotRenderingInfo var69 = null;
    java.awt.geom.Point2D var70 = null;
    var66.zoomDomainAxes((-1.0d), 0.2d, var69, var70);
    java.awt.Paint var72 = var66.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var73 = null;
    var66.rendererChanged(var73);
    java.awt.Paint var75 = var66.getOutlinePaint();
    org.jfree.data.general.WaferMapDataset var76 = null;
    org.jfree.chart.renderer.WaferMapRenderer var77 = null;
    org.jfree.chart.plot.WaferMapPlot var78 = new org.jfree.chart.plot.WaferMapPlot(var76, var77);
    org.jfree.chart.JFreeChart var79 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var78);
    java.awt.Image var80 = null;
    var79.setBackgroundImage(var80);
    org.jfree.chart.title.TextTitle var82 = null;
    var79.setTitle(var82);
    var79.setAntiAlias(false);
    float var86 = var79.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var87 = var79.getLegend();
    java.awt.Paint var88 = var87.getBackgroundPaint();
    var66.setRangeCrosshairPaint(var88);
    var0.setAngleLabelPaint(var88);
    java.awt.Font var91 = var0.getAngleLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test73"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    double var1 = var0.getUpperClip();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    boolean var3 = var0.getRenderAsPercentages();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test74"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var15 = var14.getNumberFormatOverride();
    org.jfree.data.Range var18 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
    var14.setRangeWithMargins((org.jfree.data.Range)var19);
    org.jfree.data.Range var23 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange(var23);
    var14.setDefaultAutoRange(var23);
    java.awt.Paint var26 = var14.getTickLabelPaint();
    boolean var27 = var14.getAutoRangeIncludesZero();
    java.lang.Object var28 = var14.clone();
    int var29 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
    java.awt.Paint var30 = var4.getOutlinePaint();
    org.jfree.chart.util.RectangleInsets var31 = var4.getAxisOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test75"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Stroke var4 = var3.getBorderStroke();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var11 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var13 = var12.clone();
//     java.awt.Paint var14 = var12.getBasePaint();
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var11, var14);
//     var5.setSeriesOutlinePaint(0, var14, true);
//     java.awt.Stroke var19 = var5.lookupSeriesOutlineStroke(10);
//     var3.setBorderStroke(var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     boolean var26 = var25.isRangeCrosshairVisible();
//     org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var29 = var28.getTickMarkStroke();
//     var25.setDomainCrosshairStroke(var29);
//     var3.setBorderStroke(var29);
//     java.util.List var32 = null;
//     var3.setSubtitles(var32);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test76"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.data.general.WaferMapDataset var14 = null;
    org.jfree.chart.renderer.WaferMapRenderer var15 = null;
    org.jfree.chart.plot.WaferMapPlot var16 = new org.jfree.chart.plot.WaferMapPlot(var14, var15);
    org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
    java.awt.Image var18 = null;
    var17.setBackgroundImage(var18);
    org.jfree.chart.title.TextTitle var20 = null;
    var17.setTitle(var20);
    var17.setAntiAlias(false);
    float var24 = var17.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var25 = var17.getLegend();
    java.awt.Paint var26 = var25.getBackgroundPaint();
    org.jfree.chart.block.FlowArrangement var27 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var28 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var27);
    var25.setWrapper(var28);
    java.util.List var30 = var28.getBlocks();
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle();
    java.lang.String var32 = var31.getToolTipText();
    var31.setToolTipText("XY Plot");
    var31.setURLText("");
    var28.add((org.jfree.chart.block.Block)var31);
    java.awt.Paint var38 = var31.getPaint();
    var7.setBackgroundPaint(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test77"); }
// 
// 
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange();
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-10.0d), (org.jfree.data.Range)var1);
//     org.jfree.chart.util.Size2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test78"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var6 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var8 = var7.clone();
    java.awt.Paint var9 = var7.getBasePaint();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var6, var9);
    var0.setSeriesOutlinePaint(0, var9, true);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var16 = var15.getCategoryLabelPositionOffset();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    var0.setSeriesItemLabelPaint(0, var17, true);
    boolean var20 = var0.getBaseShapesVisible();
    org.jfree.chart.labels.ItemLabelPosition var21 = var0.getBasePositiveItemLabelPosition();
    java.awt.Paint var22 = var0.getBasePaint();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var25 = var24.getNumberFormatOverride();
    org.jfree.data.Range var28 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var29 = new org.jfree.data.time.DateRange(var28);
    var24.setRangeWithMargins((org.jfree.data.Range)var29);
    org.jfree.data.general.WaferMapDataset var35 = null;
    org.jfree.chart.renderer.WaferMapRenderer var36 = null;
    org.jfree.chart.plot.WaferMapPlot var37 = new org.jfree.chart.plot.WaferMapPlot(var35, var36);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var37);
    java.awt.Image var39 = null;
    var38.setBackgroundImage(var39);
    org.jfree.chart.title.TextTitle var41 = null;
    var38.setTitle(var41);
    var38.setAntiAlias(false);
    float var45 = var38.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var46 = var38.getLegend();
    var46.setHeight(0.0d);
    org.jfree.chart.util.RectangleAnchor var49 = var46.getLegendItemGraphicLocation();
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var52 = var51.getLabelInsets();
    double var54 = var52.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var55 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var56 = var55.getChartArea();
    java.awt.geom.Rectangle2D var59 = var52.createInsetRectangle(var56, true, false);
    var46.setPadding(var52);
    java.awt.Font var61 = var46.getItemFont();
    org.jfree.chart.axis.MarkerAxisBand var62 = new org.jfree.chart.axis.MarkerAxisBand(var24, 3.0d, 0.0d, 8.0d, 0.0d, var61);
    boolean var63 = var0.equals((java.lang.Object)var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test79"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
    java.util.Date var4 = var3.getStart();
    java.lang.Number var6 = var0.getMeanValue((java.lang.Comparable)var3, (java.lang.Comparable)"AxisLocation.BOTTOM_OR_RIGHT");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var8 = var0.getRowKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test80"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange(var3);
    double var5 = var3.getCentralValue();
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var3, 0.05d);
    org.jfree.chart.util.RectangleInsets var12 = new org.jfree.chart.util.RectangleInsets(16.05d, 4.0d, 1.0E-5d, Double.NaN);
    boolean var13 = var7.equals((java.lang.Object)1.0E-5d);
    org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(0.25d, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test81"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var3 = var0.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    java.awt.Stroke var9 = var8.getBorderStroke();
    var0.setSeriesStroke(100, var9, true);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var16.zoomDomainAxes((-1.0d), 0.2d, var19, var20);
    java.awt.Paint var22 = var16.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var23 = null;
    var16.rendererChanged(var23);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    java.awt.geom.Point2D var33 = null;
    var29.zoomDomainAxes((-1.0d), 0.2d, var32, var33);
    java.awt.Paint var35 = var29.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var37 = var29.getRangeAxisLocation(1);
    var16.setDomainAxisLocation(var37);
    boolean var39 = var0.hasListener((java.util.EventListener)var16);
    int var40 = var16.getDomainAxisCount();
    boolean var41 = var16.isDomainCrosshairLockedOnData();
    java.awt.Stroke var42 = var16.getDomainCrosshairStroke();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("");
    var45.setUpperMargin(0.0d);
    var45.setInverted(true);
    boolean var50 = var45.isVerticalTickLabels();
    var45.configure();
    var45.setAutoRangeMinimumSize(4.0d, false);
    var16.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test82"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition((-1));
    var1.setNegativeItemLabelPositionFallback(var4);
    java.awt.Font var6 = var1.getBaseItemLabelFont();
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var8 = var7.getURLGenerator();
    java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var7.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var13);
    java.awt.color.ColorSpace var15 = var13.getColorSpace();
    org.jfree.chart.block.LabelBlock var16 = new org.jfree.chart.block.LabelBlock("Category Plot", var6, (java.awt.Paint)var13);
    int var17 = var13.getBlue();
    float[] var18 = null;
    float[] var19 = var13.getComponents(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test83"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var3 = var2.getLabel();
    org.jfree.data.KeyedObject var4 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var7 = var6.getLabelInsets();
    double var9 = var7.calculateTopInset(100.0d);
    var2.setTickLabelInsets(var7);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var15 = var14.getLabelInsets();
    double var17 = var15.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var19 = var18.getChartArea();
    java.awt.geom.Rectangle2D var22 = var15.createInsetRectangle(var19, true, false);
    java.lang.Object var24 = var11.draw(var12, var19, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var19, "XY Plot", "WMAP_Plot");
    org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var34 = var31.isOnOrBefore((org.jfree.data.time.SerialDate)var33);
    boolean var35 = var29.isOnOrAfter((org.jfree.data.time.SerialDate)var33);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    int var38 = var37.getYYYY();
    org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var45 = var42.isOnOrBefore((org.jfree.data.time.SerialDate)var44);
    boolean var46 = var40.isOnOrAfter((org.jfree.data.time.SerialDate)var44);
    boolean var47 = var29.isInRange((org.jfree.data.time.SerialDate)var37, (org.jfree.data.time.SerialDate)var44);
    boolean var48 = var2.equals((java.lang.Object)var37);
    java.lang.Object var49 = var2.clone();
    var2.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test84"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var20 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var22 = var21.clone();
    java.awt.Paint var23 = var21.getBasePaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var20, var23);
    var14.setSeriesOutlinePaint(0, var23, true);
    var7.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var28 = var7.getDomainAxis();
    org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var30 = var29.getDataset();
    java.awt.Stroke var31 = var29.getAngleGridlineStroke();
    org.jfree.data.general.WaferMapDataset var32 = null;
    org.jfree.chart.renderer.WaferMapRenderer var33 = null;
    org.jfree.chart.plot.WaferMapPlot var34 = new org.jfree.chart.plot.WaferMapPlot(var32, var33);
    org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var34);
    java.awt.Stroke var36 = var35.getBorderStroke();
    var29.setRadiusGridlineStroke(var36);
    org.jfree.chart.LegendItemCollection var38 = var29.getLegendItems();
    var7.setFixedLegendItems(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test85"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    org.jfree.chart.axis.CategoryAxis var17 = var7.getDomainAxisForDataset(0);
    org.jfree.chart.util.RectangleEdge var18 = var7.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var22 = var21.getLabel();
    org.jfree.data.KeyedObject var23 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var21);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var26 = var25.getLabelInsets();
    double var28 = var26.calculateTopInset(100.0d);
    var21.setTickLabelInsets(var26);
    int var30 = var7.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis)var21);
    org.jfree.data.general.WaferMapDataset var31 = null;
    org.jfree.chart.renderer.WaferMapRenderer var32 = null;
    org.jfree.chart.plot.WaferMapPlot var33 = new org.jfree.chart.plot.WaferMapPlot(var31, var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    java.awt.Image var35 = null;
    var34.setBackgroundImage(var35);
    var34.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var38 = var34.getPadding();
    var7.setInsets(var38, false);
    org.jfree.chart.util.UnitType var41 = var38.getUnitType();
    org.jfree.chart.text.TextLine var42 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.util.Size2D var44 = var42.calculateDimensions(var43);
    boolean var45 = var41.equals((java.lang.Object)var44);
    org.jfree.chart.util.RectangleInsets var50 = new org.jfree.chart.util.RectangleInsets(var41, 8.05d, 0.0d, 0.0d, 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + ""+ "'", var22.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test86"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
    org.jfree.chart.axis.SegmentedTimeline.Segment var5 = var3.getSegment(100L);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var10, var11, var12);
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var15 = var14.getLabelOutlinePaint();
    var13.setRangeCrosshairPaint(var15);
    int var17 = var13.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var18 = new org.jfree.chart.axis.AxisSpace();
    var13.setFixedRangeAxisSpace(var18);
    org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
    var13.setFixedRangeAxisSpace(var20);
    java.lang.String var22 = var13.getPlotType();
    boolean var23 = var13.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var26 = var25.getTickMarkStroke();
    java.lang.Object var27 = var25.clone();
    java.util.List var28 = var13.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var25);
    var3.setExceptionSegments(var28);
    long var30 = var3.getSegmentSize();
    var3.addException(10L, (-13L));
    boolean var35 = var3.equals((java.lang.Object)"ThreadContext version XY Plot.\nWMAP_Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:XY Plot\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ThreadContext:None\nThreadContext LICENCE TERMS:\nApril");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Category Plot"+ "'", var22.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test87"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     var0.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
//     var0.clear();
//     java.lang.Object var6 = var0.clone();
//     java.text.DateFormat var9 = null;
//     org.jfree.chart.axis.DateTickUnit var10 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var9);
//     java.lang.String var12 = var10.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var20 = var17.isOnOrBefore((org.jfree.data.time.SerialDate)var19);
//     boolean var21 = var15.isOnOrAfter((org.jfree.data.time.SerialDate)var19);
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var24 = var23.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var31 = var28.isOnOrBefore((org.jfree.data.time.SerialDate)var30);
//     boolean var32 = var26.isOnOrAfter((org.jfree.data.time.SerialDate)var30);
//     boolean var33 = var15.isInRange((org.jfree.data.time.SerialDate)var23, (org.jfree.data.time.SerialDate)var30);
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var15);
//     java.util.Date var35 = var15.toDate();
//     java.util.Date var36 = var10.rollDate(var35);
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(var35);
//     java.lang.Comparable var38 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var39 = var0.getValue((java.lang.Comparable)var37, var38);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "12/31/69"+ "'", var12.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test88"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    boolean var3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var2);
    org.jfree.chart.plot.PiePlot3D var4 = new org.jfree.chart.plot.PiePlot3D(var2);
    var4.setCircular(true, false);
    double var8 = var4.getLabelLinkMargin();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var16 = var15.getNumberFormatOverride();
    org.jfree.data.Range var19 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var20 = new org.jfree.data.time.DateRange(var19);
    var15.setRangeWithMargins((org.jfree.data.Range)var20);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var24 = var23.getLabelInsets();
    double var26 = var24.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var28 = var27.getChartArea();
    java.awt.geom.Rectangle2D var31 = var24.createInsetRectangle(var28, true, false);
    var15.setDownArrow((java.awt.Shape)var31);
    var12.setSeriesShape(13, (java.awt.Shape)var31, false);
    org.jfree.chart.plot.RingPlot var35 = new org.jfree.chart.plot.RingPlot();
    org.jfree.chart.labels.PieSectionLabelGenerator var36 = var35.getLegendLabelGenerator();
    var35.setSeparatorsVisible(false);
    var35.setSeparatorsVisible(false);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
    org.jfree.chart.util.Layer var48 = null;
    java.util.Collection var49 = var46.getRangeMarkers(0, var48);
    org.jfree.chart.plot.PlotRenderingInfo var52 = null;
    java.awt.geom.Point2D var53 = null;
    var46.zoomDomainAxes(2.0d, 1.0d, var52, var53);
    org.jfree.chart.ChartRenderingInfo var56 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var57 = var56.getChartArea();
    java.lang.Object var58 = var56.clone();
    org.jfree.chart.plot.PlotRenderingInfo var59 = new org.jfree.chart.plot.PlotRenderingInfo(var56);
    java.awt.geom.Point2D var60 = null;
    var46.zoomDomainAxes(2.0d, var59, var60);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var62 = var4.initialise(var9, var31, (org.jfree.chart.plot.PiePlot)var35, (java.lang.Integer)(-622), var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test89"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    org.jfree.chart.title.TextTitle var6 = null;
    var3.setTitle(var6);
    var3.setAntiAlias(false);
    float var10 = var3.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
    java.awt.Image var12 = null;
    var3.setBackgroundImage(var12);
    org.jfree.chart.plot.Plot var14 = var3.getPlot();
    org.jfree.chart.axis.CategoryLabelPositions var16 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
    org.jfree.chart.axis.CategoryLabelPosition var17 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var18 = var17.getWidthType();
    org.jfree.chart.axis.CategoryLabelPositions var19 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var16, var17);
    org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot();
    boolean var21 = var16.equals((java.lang.Object)var20);
    org.jfree.chart.event.PlotChangeEvent var22 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var20);
    var3.plotChanged(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test90"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     boolean var3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var2);
//     org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var2);
//     boolean var5 = var4.getSeparatorsVisible();
//     java.awt.Paint var6 = var4.getLabelShadowPaint();
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     var11.zoomDomainAxes((-1.0d), 0.2d, var14, var15);
//     java.awt.Paint var17 = var11.getRangeCrosshairPaint();
//     double var18 = var11.getDomainCrosshairValue();
//     var11.setRangeZeroBaselineVisible(true);
//     java.awt.Stroke var21 = var11.getRangeGridlineStroke();
//     java.lang.String var22 = var11.getPlotType();
//     org.jfree.chart.util.RectangleEdge var23 = var11.getDomainAxisEdge();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var27 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var29 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var27, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, var31, var32, var33);
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var36 = var35.getLabelOutlinePaint();
//     var34.setRangeCrosshairPaint(var36);
//     int var38 = var34.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var39 = new org.jfree.chart.axis.AxisSpace();
//     var34.setFixedRangeAxisSpace(var39);
//     org.jfree.chart.axis.AxisSpace var41 = new org.jfree.chart.axis.AxisSpace();
//     var34.setFixedRangeAxisSpace(var41);
//     java.lang.String var43 = var34.getPlotType();
//     java.awt.Paint var44 = var34.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var47 = var46.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var48 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var49 = null;
//     var48.setLabelOutlinePaint(var49);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var57 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var58 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var59 = var58.clone();
//     java.awt.Paint var60 = var58.getBasePaint();
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var57, var60);
//     var51.setSeriesOutlinePaint(0, var60, true);
//     var48.setBackgroundPaint(var60);
//     java.awt.Stroke var65 = null;
//     org.jfree.chart.plot.IntervalMarker var67 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var44, var47, var60, var65, 0.0f);
//     org.jfree.chart.util.RectangleAnchor var68 = var67.getLabelAnchor();
//     org.jfree.chart.util.LengthAdjustmentType var69 = var67.getLabelOffsetType();
//     org.jfree.chart.util.Layer var70 = null;
//     var11.addRangeMarker(31, (org.jfree.chart.plot.Marker)var67, var70);
//     java.awt.Paint var72 = var11.getDomainCrosshairPaint();
//     var4.setSeparatorPaint(var72);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test91"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    java.awt.Paint var2 = var0.getBasePaint();
    boolean var3 = var0.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getURLGenerator(100, 4);
    java.awt.Paint var9 = var0.getItemOutlinePaint(10, (-1));
    java.awt.Paint var11 = var0.getSeriesPaint(1900);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getPositiveItemLabelPositionFallback();
    var0.setBaseSeriesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test92"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     java.awt.Image var4 = null;
//     var3.setBackgroundImage(var4);
//     org.jfree.chart.title.TextTitle var6 = null;
//     var3.setTitle(var6);
//     var3.setAntiAlias(false);
//     float var10 = var3.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
//     var11.setHeight(0.0d);
//     org.jfree.chart.block.BlockContainer var14 = var11.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var15 = var11.getLegendItemGraphicPadding();
//     double var16 = var11.getContentXOffset();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.util.Size2D var18 = var11.arrange(var17);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test93"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorUp(10.0d);
    java.util.List var3 = var0.getTicks();
    java.util.List var4 = var0.getTicks();
    double var5 = var0.getMax();
    java.util.List var6 = var0.getTicks();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test94"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    boolean var10 = var8.isLineVisible();
    boolean var11 = var8.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test95"); }


    org.jfree.chart.renderer.category.LevelRenderer var0 = new org.jfree.chart.renderer.category.LevelRenderer();
    double var1 = var0.getItemMargin();
    var0.setItemMargin(0.0d);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var4 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var5 = var4.clone();
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var12 = var9.isOnOrBefore((org.jfree.data.time.SerialDate)var11);
    boolean var13 = var7.isOnOrAfter((org.jfree.data.time.SerialDate)var11);
    org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
    int var16 = var15.getYYYY();
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var23 = var20.isOnOrBefore((org.jfree.data.time.SerialDate)var22);
    boolean var24 = var18.isOnOrAfter((org.jfree.data.time.SerialDate)var22);
    boolean var25 = var7.isInRange((org.jfree.data.time.SerialDate)var15, (org.jfree.data.time.SerialDate)var22);
    boolean var26 = var4.equals((java.lang.Object)var15);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var29 = var27.getSeriesNegativeItemLabelPosition((-1));
    var4.setBasePositiveItemLabelPosition(var29);
    org.jfree.chart.labels.ItemLabelAnchor var31 = var29.getItemLabelAnchor();
    double var32 = var29.getAngle();
    var0.setBaseNegativeItemLabelPosition(var29, false);
    org.jfree.chart.plot.CategoryPlot var35 = var0.getPlot();
    double var36 = var0.getMaximumItemWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test96"); }
// 
// 
//     java.lang.Comparable var0 = null;
//     java.awt.Shape var5 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var7 = var6.clone();
//     java.awt.Paint var8 = var6.getBasePaint();
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var5, var8);
//     java.awt.Stroke var10 = var9.getOutlineStroke();
//     int var11 = var9.getDatasetIndex();
//     java.text.AttributedString var12 = var9.getAttributedLabel();
//     boolean var13 = var9.isShapeVisible();
//     java.awt.Shape var14 = var9.getLine();
//     org.jfree.chart.entity.CategoryLabelEntity var17 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var14, "ChartEntity: tooltip = XY Plot", "Last");
//     java.lang.String var18 = var17.toString();
//     java.lang.String var19 = var17.getToolTipText();
//     java.lang.Comparable var20 = var17.getKey();
//     java.lang.Object var21 = var17.clone();
//     java.lang.String var22 = var17.toString();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var23 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var24 = null;
//     java.lang.String var25 = var17.getImageMapAreaTag(var23, var24);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test97"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var6 = var4.getRangeZeroBaselineStroke();
    var4.setRangeGridlinesVisible(true);
    org.jfree.data.general.WaferMapDataset var9 = null;
    org.jfree.chart.renderer.WaferMapRenderer var10 = null;
    org.jfree.chart.plot.WaferMapPlot var11 = new org.jfree.chart.plot.WaferMapPlot(var9, var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    java.awt.Stroke var13 = var12.getBorderStroke();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var20 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var22 = var21.clone();
    java.awt.Paint var23 = var21.getBasePaint();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var20, var23);
    var14.setSeriesOutlinePaint(0, var23, true);
    java.awt.Stroke var28 = var14.lookupSeriesOutlineStroke(10);
    var12.setBorderStroke(var28);
    var4.setRangeZeroBaselineStroke(var28);
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var33 = var32.clone();
    java.awt.Paint var34 = var32.getBasePaint();
    boolean var35 = var32.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var38 = var32.getURLGenerator(100, 4);
    java.awt.Font var40 = null;
    var32.setSeriesItemLabelFont(0, var40, true);
    java.awt.Font var43 = var32.getBaseItemLabelFont();
    boolean var44 = var31.equals((java.lang.Object)var32);
    java.text.DateFormat var45 = var31.getDateFormatOverride();
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var48 = var47.getNumberFormatOverride();
    org.jfree.data.Range var51 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var52 = new org.jfree.data.time.DateRange(var51);
    var47.setRangeWithMargins((org.jfree.data.Range)var52);
    org.jfree.data.Range var56 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var57 = new org.jfree.data.time.DateRange(var56);
    var47.setDefaultAutoRange(var56);
    java.awt.Paint var59 = var47.getTickLabelPaint();
    org.jfree.data.Range var62 = new org.jfree.data.Range(0.0d, 0.0d);
    double var63 = var62.getUpperBound();
    double var64 = var62.getUpperBound();
    var47.setDefaultAutoRange(var62);
    var31.setRange(var62);
    org.jfree.chart.util.ObjectList var68 = new org.jfree.chart.util.ObjectList(1);
    int var70 = var68.indexOf((java.lang.Object)(short)0);
    java.lang.Object var71 = var68.clone();
    boolean var72 = var31.equals(var71);
    java.lang.Object var73 = var31.clone();
    java.text.DateFormat var74 = null;
    var31.setDateFormatOverride(var74);
    int var76 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var31);
    var31.centerRange(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == (-1));

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test98"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var5 = null;
//     var4.setLabelOutlinePaint(var5);
//     var4.setSectionOutlinesVisible(false);
//     java.awt.Shape var9 = var4.getLegendItemShape();
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var11 = null;
//     var10.setLabelOutlinePaint(var11);
//     java.awt.Stroke var13 = var10.getLabelOutlineStroke();
//     java.awt.Paint var14 = null;
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("Category Plot", "April", "WMAP_Plot", "black", var9, var13, var14);
//     java.lang.Comparable var16 = var15.getSeriesKey();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var17 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var19 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var17, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, var21, var22, var23);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     var24.setRenderer(var25, true);
//     java.text.DateFormat var30 = null;
//     org.jfree.chart.axis.DateTickUnit var31 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var30);
//     java.lang.String var33 = var31.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var41 = var38.isOnOrBefore((org.jfree.data.time.SerialDate)var40);
//     boolean var42 = var36.isOnOrAfter((org.jfree.data.time.SerialDate)var40);
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var45 = var44.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var52 = var49.isOnOrBefore((org.jfree.data.time.SerialDate)var51);
//     boolean var53 = var47.isOnOrAfter((org.jfree.data.time.SerialDate)var51);
//     boolean var54 = var36.isInRange((org.jfree.data.time.SerialDate)var44, (org.jfree.data.time.SerialDate)var51);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var36);
//     java.util.Date var56 = var36.toDate();
//     java.util.Date var57 = var31.rollDate(var56);
//     org.jfree.chart.plot.CategoryMarker var58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var57);
//     var24.addRangeMarker((org.jfree.chart.plot.Marker)var58);
//     boolean var60 = var15.equals((java.lang.Object)var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "12/31/69"+ "'", var33.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test99"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    boolean var8 = var5.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var11 = var5.getURLGenerator(100, 4);
    java.awt.Font var13 = null;
    var5.setSeriesItemLabelFont(0, var13, true);
    java.awt.Font var16 = var5.getBaseItemLabelFont();
    java.awt.Color var20 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, (java.awt.Paint)var20);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var28 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var29 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var30 = var29.clone();
    java.awt.Paint var31 = var29.getBasePaint();
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var28, var31);
    var22.setSeriesOutlinePaint(0, var31, true);
    org.jfree.chart.text.TextMeasurer var36 = null;
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var16, var31, 0.0f, var36);
    org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var39 = null;
    var38.setLabelOutlinePaint(var39);
    java.awt.Stroke var41 = var38.getLabelOutlineStroke();
    java.awt.Paint var42 = var38.getLabelPaint();
    org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("", var16, var42);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var44 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var46 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var44, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var44, var48, var49, var50);
    org.jfree.chart.plot.PlotRenderingInfo var54 = null;
    org.jfree.data.xy.XYDataset var55 = null;
    org.jfree.chart.axis.ValueAxis var56 = null;
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
    org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
    org.jfree.chart.util.Layer var61 = null;
    java.util.Collection var62 = var59.getRangeMarkers(0, var61);
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.data.Range var64 = var59.getDataRange(var63);
    org.jfree.chart.axis.AxisSpace var65 = null;
    var59.setFixedDomainAxisSpace(var65);
    java.awt.Paint var67 = null;
    var59.setRangeTickBandPaint(var67);
    java.awt.geom.Point2D var69 = var59.getQuadrantOrigin();
    var51.zoomRangeAxes(10.0d, 0.0d, var54, var69);
    org.jfree.chart.JFreeChart var72 = new org.jfree.chart.JFreeChart("hi!", var16, (org.jfree.chart.plot.Plot)var51, false);
    var0.setAngleLabelFont(var16);
    java.awt.Stroke var74 = var0.getRadiusGridlineStroke();
    boolean var75 = var0.isRangeZoomable();
    org.jfree.data.xy.XYDataset var76 = null;
    var0.setDataset(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test100"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    org.jfree.data.general.SeriesChangeEvent var3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
    double var5 = var2.calculateBottomInset(8.0d);
    double var7 = var2.calculateTopInset(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 3.0d);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test101"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Paint var3 = var1.getBasePaint();
//     boolean var4 = var1.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var1.getURLGenerator(100, 4);
//     java.awt.Font var9 = null;
//     var1.setSeriesItemLabelFont(0, var9, true);
//     java.awt.Font var12 = var1.getBaseItemLabelFont();
//     boolean var13 = var0.equals((java.lang.Object)var1);
//     java.text.DateFormat var14 = var0.getDateFormatOverride();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var17 = var16.getNumberFormatOverride();
//     org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange(var20);
//     var16.setRangeWithMargins((org.jfree.data.Range)var21);
//     org.jfree.data.Range var25 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange(var25);
//     var16.setDefaultAutoRange(var25);
//     java.awt.Paint var28 = var16.getTickLabelPaint();
//     org.jfree.data.Range var31 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var32 = var31.getUpperBound();
//     double var33 = var31.getUpperBound();
//     var16.setDefaultAutoRange(var31);
//     var0.setRange(var31);
//     double var36 = var0.getUpperBound();
//     java.text.DateFormat var39 = null;
//     org.jfree.chart.axis.DateTickUnit var40 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var39);
//     java.lang.String var42 = var40.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var50 = var47.isOnOrBefore((org.jfree.data.time.SerialDate)var49);
//     boolean var51 = var45.isOnOrAfter((org.jfree.data.time.SerialDate)var49);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var54 = var53.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var61 = var58.isOnOrBefore((org.jfree.data.time.SerialDate)var60);
//     boolean var62 = var56.isOnOrAfter((org.jfree.data.time.SerialDate)var60);
//     boolean var63 = var45.isInRange((org.jfree.data.time.SerialDate)var53, (org.jfree.data.time.SerialDate)var60);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var45);
//     java.util.Date var65 = var45.toDate();
//     java.util.Date var66 = var40.rollDate(var65);
//     int var67 = var40.getUnit();
//     var0.setTickUnit(var40, false, false);
//     org.jfree.chart.axis.SegmentedTimeline var74 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     boolean var75 = var74.getAdjustForDaylightSaving();
//     org.jfree.chart.text.TextBlock var76 = new org.jfree.chart.text.TextBlock();
//     java.util.List var77 = var76.getLines();
//     var74.setExceptionSegments(var77);
//     var0.setTimeline((org.jfree.chart.axis.Timeline)var74);
//     var74.setStartTime(0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "12/31/69"+ "'", var42.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test102"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     int var1 = var0.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 12);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test103"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var4.rendererChanged(var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var17.zoomDomainAxes((-1.0d), 0.2d, var20, var21);
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var25 = var17.getRangeAxisLocation(1);
    var4.setDomainAxisLocation(var25);
    org.jfree.data.general.WaferMapDataset var27 = null;
    org.jfree.chart.renderer.WaferMapRenderer var28 = null;
    org.jfree.chart.plot.WaferMapPlot var29 = new org.jfree.chart.plot.WaferMapPlot(var27, var28);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var29);
    java.awt.Image var31 = null;
    var30.setBackgroundImage(var31);
    org.jfree.chart.title.TextTitle var33 = null;
    var30.setTitle(var33);
    var30.setAntiAlias(false);
    float var37 = var30.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var38 = var30.getLegend();
    var38.setHeight(0.0d);
    var38.setMargin(10.0d, 2.0d, 0.2d, (-10.0d));
    org.jfree.chart.block.BlockContainer var46 = var38.getItemContainer();
    boolean var47 = var25.equals((java.lang.Object)var46);
    java.lang.String var48 = var46.getID();
    var46.setMargin(1.05d, (-1.0d), 4.0d, (-27.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test104"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    var0.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    var0.removeColumn((java.lang.Comparable)0);
    java.util.List var7 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getRowKey(5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test105"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getSeriesNegativeItemLabelPosition(1900);
    var0.setBaseSeriesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test106"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.lang.String var3 = var2.getLabel();
//     org.jfree.data.KeyedObject var4 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var2);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     boolean var7 = var6.getUseOutlinePaint();
//     boolean var9 = var6.isSeriesVisibleInLegend(1);
//     var6.setSeriesShapesFilled(0, false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var16 = var15.getChartArea();
//     var14.setLegendItemShape((java.awt.Shape)var16);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var18 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var20 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var18, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var18, var22, var23, var24);
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var27 = var26.getLabelOutlinePaint();
//     var25.setRangeCrosshairPaint(var27);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var33.getRangeMarkers(0, var35);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     java.awt.geom.Point2D var40 = null;
//     var33.zoomDomainAxes(2.0d, 1.0d, var39, var40);
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var42, var43, var44, var45);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var46.zoomDomainAxes((-1.0d), 0.2d, var49, var50);
//     java.awt.Paint var52 = var46.getRangeCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var54 = var46.getRangeAxisLocation(1);
//     java.lang.Object var55 = null;
//     boolean var56 = var54.equals(var55);
//     var33.setDomainAxisLocation(var54);
//     var25.setDomainAxisLocation(var54);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var61 = var6.initialise(var13, var16, var25, 10, var60);
//     boolean var62 = var4.equals((java.lang.Object)var61);
//     java.lang.Comparable var63 = var4.getKey();
//     java.lang.Object var64 = var4.clone();
//     
//     // Checks the contract:  equals-hashcode on var5 and var64
//     assertTrue("Contract failed: equals-hashcode on var5 and var64", var5.equals(var64) ? var5.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var5
//     assertTrue("Contract failed: equals-hashcode on var64 and var5", var64.equals(var5) ? var64.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test107"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    var0.setEndPercent(2.0d);
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var4 = var3.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var10 = var9.getLabelOutlinePaint();
    var7.setBackgroundPaint(var10);
    var3.setLabelShadowPaint(var10);
    var3.setOutlineVisible(false);
    var3.setLabelLinkMargin((-10.0d));
    org.jfree.chart.labels.PieToolTipGenerator var17 = var3.getToolTipGenerator();
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var19 = var18.getURLGenerator();
    java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var18.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var24);
    java.awt.color.ColorSpace var26 = var24.getColorSpace();
    int var27 = var24.getGreen();
    var3.setBaseSectionOutlinePaint((java.awt.Paint)var24);
    var0.setCompletePaint((java.awt.Paint)var24);
    java.awt.Stroke var30 = var0.getBaseStroke();
    double var31 = var0.getEndPercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 2.0d);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test108"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.axis.CategoryLabelPositions var4 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    var1.setCategoryLabelPositions(var4);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var12.getRangeMarkers(0, var14);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var12.zoomDomainAxes(2.0d, 1.0d, var18, var19);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var21 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var23 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var21, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var21, var25, var26, var27);
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var30 = var29.getLabelOutlinePaint();
    var28.setRangeCrosshairPaint(var30);
    int var32 = var28.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var33 = new org.jfree.chart.axis.AxisSpace();
    var28.setFixedRangeAxisSpace(var33);
    org.jfree.chart.axis.AxisSpace var35 = new org.jfree.chart.axis.AxisSpace();
    var28.setFixedRangeAxisSpace(var35);
    var12.setFixedRangeAxisSpace(var35);
    var35.setBottom(1.0d);
    var35.setLeft(0.05d);
    org.jfree.chart.ChartRenderingInfo var42 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var43 = var42.getChartArea();
    org.jfree.chart.block.BlockContainer var44 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var45 = var44.clone();
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
    java.lang.String var47 = var46.getToolTipText();
    var44.add((org.jfree.chart.block.Block)var46);
    org.jfree.chart.util.RectangleEdge var49 = var46.getPosition();
    java.awt.geom.Rectangle2D var50 = var35.reserved(var43, var49);
    org.jfree.data.general.WaferMapDataset var51 = null;
    org.jfree.chart.renderer.WaferMapRenderer var52 = null;
    org.jfree.chart.plot.WaferMapPlot var53 = new org.jfree.chart.plot.WaferMapPlot(var51, var52);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var53);
    java.awt.Image var55 = null;
    var54.setBackgroundImage(var55);
    org.jfree.chart.title.TextTitle var57 = null;
    var54.setTitle(var57);
    var54.setAntiAlias(false);
    float var61 = var54.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var62 = var54.getLegend();
    var62.setHeight(0.0d);
    org.jfree.chart.block.BlockContainer var65 = var62.getItemContainer();
    org.jfree.chart.util.RectangleEdge var66 = var62.getPosition();
    org.jfree.chart.util.RectangleEdge var67 = var62.getPosition();
    double var68 = var1.getCategoryMiddle(31, 13, var43, var67);
    boolean var69 = var1.isTickLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test109"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var2 = var1.getNumberFormatOverride();
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(var5);
    var1.setRangeWithMargins((org.jfree.data.Range)var6);
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var11 = new org.jfree.data.time.DateRange(var10);
    var1.setDefaultAutoRange(var10);
    java.awt.Paint var13 = var1.getTickLabelPaint();
    boolean var14 = var1.getAutoRangeIncludesZero();
    java.awt.Shape var15 = var1.getLeftArrow();
    var1.setUpperMargin((-10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test110"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var2 = var1.getCategoryLabelPositionOffset();
//     java.awt.Paint var3 = var1.getAxisLinePaint();
//     org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
//     org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition();
//     double var7 = var6.getAngle();
//     org.jfree.chart.axis.CategoryLabelWidthType var8 = var6.getWidthType();
//     org.jfree.chart.axis.CategoryLabelPositions var9 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var5, var6);
//     var1.setCategoryLabelPositions(var9);
//     org.jfree.chart.axis.SegmentedTimeline var11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.text.DateFormat var14 = null;
//     org.jfree.chart.axis.DateTickUnit var15 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var14);
//     java.lang.String var17 = var15.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
//     boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var29 = var28.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var36 = var33.isOnOrBefore((org.jfree.data.time.SerialDate)var35);
//     boolean var37 = var31.isOnOrAfter((org.jfree.data.time.SerialDate)var35);
//     boolean var38 = var20.isInRange((org.jfree.data.time.SerialDate)var28, (org.jfree.data.time.SerialDate)var35);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var20);
//     java.util.Date var40 = var20.toDate();
//     java.util.Date var41 = var15.rollDate(var40);
//     int var42 = var15.getUnit();
//     org.jfree.chart.axis.SegmentedTimeline var46 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var48 = var46.getSegment(100L);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var56 = var53.isOnOrBefore((org.jfree.data.time.SerialDate)var55);
//     boolean var57 = var51.isOnOrAfter((org.jfree.data.time.SerialDate)var55);
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var60 = var59.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var62 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var66 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var67 = var64.isOnOrBefore((org.jfree.data.time.SerialDate)var66);
//     boolean var68 = var62.isOnOrAfter((org.jfree.data.time.SerialDate)var66);
//     boolean var69 = var51.isInRange((org.jfree.data.time.SerialDate)var59, (org.jfree.data.time.SerialDate)var66);
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var51);
//     java.util.Date var71 = var51.toDate();
//     boolean var72 = var46.containsDomainValue(var71);
//     org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.createInstance(var71);
//     java.util.Date var74 = var15.addToDate(var71);
//     var11.addBaseTimelineException(var71);
//     var11.addBaseTimelineException((-2208787199569L));
//     boolean var78 = var9.equals((java.lang.Object)var11);
//     java.util.Date var80 = var11.getDate(1900L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "12/31/69"+ "'", var17.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test111"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var4 = var3.clone();
    java.awt.Paint var5 = var3.getBasePaint();
    boolean var6 = var3.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
    java.awt.Font var11 = null;
    var3.setSeriesItemLabelFont(0, var11, true);
    java.awt.Font var14 = var3.getBaseItemLabelFont();
    java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var23 = var20.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", var14, (org.jfree.chart.plot.Plot)var20, false);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var30, var31, var32);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
    org.jfree.chart.util.Layer var43 = null;
    java.util.Collection var44 = var41.getRangeMarkers(0, var43);
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.data.Range var46 = var41.getDataRange(var45);
    org.jfree.chart.axis.AxisSpace var47 = null;
    var41.setFixedDomainAxisSpace(var47);
    java.awt.Paint var49 = null;
    var41.setRangeTickBandPaint(var49);
    java.awt.geom.Point2D var51 = var41.getQuadrantOrigin();
    var33.zoomRangeAxes(10.0d, 0.0d, var36, var51);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var33, false);
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis((org.jfree.chart.axis.ValueAxis)var56);
    org.jfree.chart.axis.ValueAxis var59 = var33.getRangeAxis(3);
    java.lang.String var60 = var33.getPlotType();
    org.jfree.chart.annotations.CategoryAnnotation var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addAnnotation(var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + "Category Plot"+ "'", var60.equals("Category Plot"));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test112"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedWidth(12.0d);
    org.jfree.data.Range var5 = var2.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test113"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var3 = var0.getItemShapeVisible(0, 10);
    org.jfree.chart.LegendItem var6 = var0.getLegendItem(0, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test114"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var2 = var1.clone();
//     java.awt.Paint var3 = var1.getBasePaint();
//     boolean var4 = var1.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var1.getURLGenerator(100, 4);
//     java.awt.Font var9 = null;
//     var1.setSeriesItemLabelFont(0, var9, true);
//     java.awt.Font var12 = var1.getBaseItemLabelFont();
//     boolean var13 = var0.equals((java.lang.Object)var1);
//     java.text.DateFormat var14 = var0.getDateFormatOverride();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
//     java.text.NumberFormat var17 = var16.getNumberFormatOverride();
//     org.jfree.data.Range var20 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var21 = new org.jfree.data.time.DateRange(var20);
//     var16.setRangeWithMargins((org.jfree.data.Range)var21);
//     org.jfree.data.Range var25 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange(var25);
//     var16.setDefaultAutoRange(var25);
//     java.awt.Paint var28 = var16.getTickLabelPaint();
//     org.jfree.data.Range var31 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var32 = var31.getUpperBound();
//     double var33 = var31.getUpperBound();
//     var16.setDefaultAutoRange(var31);
//     var0.setRange(var31);
//     double var36 = var0.getUpperBound();
//     java.text.DateFormat var39 = null;
//     org.jfree.chart.axis.DateTickUnit var40 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var39);
//     java.lang.String var42 = var40.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var50 = var47.isOnOrBefore((org.jfree.data.time.SerialDate)var49);
//     boolean var51 = var45.isOnOrAfter((org.jfree.data.time.SerialDate)var49);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var54 = var53.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var61 = var58.isOnOrBefore((org.jfree.data.time.SerialDate)var60);
//     boolean var62 = var56.isOnOrAfter((org.jfree.data.time.SerialDate)var60);
//     boolean var63 = var45.isInRange((org.jfree.data.time.SerialDate)var53, (org.jfree.data.time.SerialDate)var60);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var45);
//     java.util.Date var65 = var45.toDate();
//     java.util.Date var66 = var40.rollDate(var65);
//     int var67 = var40.getUnit();
//     var0.setTickUnit(var40, false, false);
//     org.jfree.chart.axis.SegmentedTimeline var74 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     boolean var75 = var74.getAdjustForDaylightSaving();
//     org.jfree.chart.text.TextBlock var76 = new org.jfree.chart.text.TextBlock();
//     java.util.List var77 = var76.getLines();
//     var74.setExceptionSegments(var77);
//     var0.setTimeline((org.jfree.chart.axis.Timeline)var74);
//     java.util.Date var81 = var74.getDate(2058L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var42 + "' != '" + "12/31/69"+ "'", var42.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test115"); }
// 
// 
//     java.text.DateFormat var3 = null;
//     org.jfree.chart.axis.DateTickUnit var4 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var3);
//     java.lang.String var6 = var4.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var14 = var11.isOnOrBefore((org.jfree.data.time.SerialDate)var13);
//     boolean var15 = var9.isOnOrAfter((org.jfree.data.time.SerialDate)var13);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var18 = var17.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
//     boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
//     boolean var27 = var9.isInRange((org.jfree.data.time.SerialDate)var17, (org.jfree.data.time.SerialDate)var24);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var9);
//     java.util.Date var29 = var9.toDate();
//     java.util.Date var30 = var4.rollDate(var29);
//     org.jfree.chart.plot.CategoryMarker var31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var30);
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var30);
//     java.lang.String var33 = var32.toString();
//     org.jfree.data.time.Year var34 = var32.getYear();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var37 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var39 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var37, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var37, var41, var42, var43);
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var46 = var45.getLabelOutlinePaint();
//     var44.setRangeCrosshairPaint(var46);
//     int var48 = var44.getDomainAxisCount();
//     org.jfree.chart.axis.AxisSpace var49 = new org.jfree.chart.axis.AxisSpace();
//     var44.setFixedRangeAxisSpace(var49);
//     org.jfree.chart.axis.AxisSpace var51 = new org.jfree.chart.axis.AxisSpace();
//     var44.setFixedRangeAxisSpace(var51);
//     java.lang.String var53 = var44.getPlotType();
//     java.awt.Paint var54 = var44.getDomainGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     java.awt.Stroke var57 = var56.getTickMarkStroke();
//     org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var59 = null;
//     var58.setLabelOutlinePaint(var59);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var67 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var68 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var69 = var68.clone();
//     java.awt.Paint var70 = var68.getBasePaint();
//     org.jfree.chart.LegendItem var71 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var67, var70);
//     var61.setSeriesOutlinePaint(0, var70, true);
//     var58.setBackgroundPaint(var70);
//     java.awt.Stroke var75 = null;
//     org.jfree.chart.plot.IntervalMarker var77 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var54, var57, var70, var75, 0.0f);
//     org.jfree.data.general.WaferMapDataset var78 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var79 = null;
//     org.jfree.chart.plot.WaferMapPlot var80 = new org.jfree.chart.plot.WaferMapPlot(var78, var79);
//     org.jfree.chart.JFreeChart var81 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var80);
//     java.awt.Image var82 = null;
//     var81.setBackgroundImage(var82);
//     var81.fireChartChanged();
//     org.jfree.chart.util.RectangleInsets var85 = var81.getPadding();
//     var77.setLabelOffset(var85);
//     java.lang.Object var87 = var77.clone();
//     int var88 = var34.compareTo(var87);
//     long var89 = var34.getFirstMillisecond();
//     long var90 = var34.getLastMillisecond();
//     org.jfree.data.gantt.Task var91 = new org.jfree.data.gantt.Task("RectangleEdge.TOP", (org.jfree.data.time.TimePeriod)var34);
//     org.jfree.data.time.TimePeriod var92 = var91.getDuration();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "12/31/69"+ "'", var6.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "May 2058"+ "'", var33.equals("May 2058"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + "Category Plot"+ "'", var53.equals("Category Plot"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == 2777097600000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 2808633599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test116"); }


    org.jfree.data.general.WaferMapDataset var1 = null;
    org.jfree.chart.renderer.WaferMapRenderer var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var1, var2);
    org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    java.awt.Image var5 = null;
    var4.setBackgroundImage(var5);
    org.jfree.chart.title.TextTitle var7 = null;
    var4.setTitle(var7);
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)true, var4);
    org.jfree.chart.event.ChartChangeEventType var10 = var9.getType();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.5f);
    boolean var13 = var10.equals((java.lang.Object)var12);
    java.lang.String var14 = var10.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var14.equals("ChartChangeEventType.GENERAL"));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test117"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    java.lang.Object var3 = null;
    var0.add((org.jfree.chart.block.Block)var2, var3);
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets(0.2d, (-10.0d), 1.0d, 0.0d);
    double var11 = var9.calculateTopOutset(2.0d);
    var2.setPadding(var9);
    java.lang.String var13 = var2.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test118"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey((-2097352));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test119"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var26 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var28 = var27.clone();
//     java.awt.Paint var29 = var27.getBasePaint();
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var26, var29);
//     var20.setSeriesOutlinePaint(0, var29, true);
//     org.jfree.chart.text.TextMeasurer var34 = null;
//     org.jfree.chart.text.TextBlock var35 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, var29, 0.0f, var34);
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var37 = null;
//     var36.setLabelOutlinePaint(var37);
//     java.awt.Stroke var39 = var36.getLabelOutlineStroke();
//     java.awt.Paint var40 = var36.getLabelPaint();
//     org.jfree.chart.text.TextLine var41 = new org.jfree.chart.text.TextLine("", var14, var40);
//     org.jfree.chart.text.TextFragment var42 = var41.getFirstTextFragment();
//     java.awt.Graphics2D var43 = null;
//     org.jfree.chart.util.Size2D var44 = var41.calculateDimensions(var43);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test120"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
    java.util.List var5 = var0.getColumnKeys();
    int var7 = var0.getColumnIndex((java.lang.Comparable)"RectangleEdge.TOP");
    int var8 = var0.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test121"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    java.awt.Stroke var3 = var0.getLabelOutlineStroke();
    var0.setBackgroundImageAlignment(28);
    java.awt.Color var10 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    int var11 = var10.getAlpha();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var12 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var14 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var12, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var12, var16, var17, var18);
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var21 = var20.getLabelOutlinePaint();
    var19.setRangeCrosshairPaint(var21);
    int var23 = var19.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var24 = new org.jfree.chart.axis.AxisSpace();
    var19.setFixedRangeAxisSpace(var24);
    org.jfree.chart.axis.AxisSpace var26 = new org.jfree.chart.axis.AxisSpace();
    var19.setFixedRangeAxisSpace(var26);
    var19.setRangeCrosshairValue(4.0d);
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var31 = null;
    var30.setLabelOutlinePaint(var31);
    java.awt.Stroke var33 = var30.getLabelOutlineStroke();
    java.awt.Paint var34 = var30.getLabelPaint();
    org.jfree.data.general.WaferMapDataset var35 = null;
    org.jfree.chart.renderer.WaferMapRenderer var36 = null;
    org.jfree.chart.plot.WaferMapPlot var37 = new org.jfree.chart.plot.WaferMapPlot(var35, var36);
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var37);
    java.awt.Stroke var39 = var37.getOutlineStroke();
    var30.setBaseSectionOutlineStroke(var39);
    var19.setDomainGridlineStroke(var39);
    org.jfree.chart.plot.CategoryMarker var42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(short)0, (java.awt.Paint)var10, var39);
    var0.setBaseSectionOutlineStroke(var39);
    org.jfree.chart.util.Rotation var44 = var0.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test122"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    org.jfree.chart.title.TextTitle var6 = null;
    var3.setTitle(var6);
    var3.setAntiAlias(false);
    float var10 = var3.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
    var11.setHeight(0.0d);
    org.jfree.chart.block.BlockContainer var14 = var11.getItemContainer();
    org.jfree.chart.util.RectangleEdge var15 = var11.getPosition();
    org.jfree.chart.util.RectangleEdge var16 = var11.getPosition();
    java.awt.Paint var17 = var11.getItemPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test123"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
    var0.setItemMargin(1.0d);
    double var7 = var0.getItemMargin();
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    var8.setLegendItemShape((java.awt.Shape)var10);
    var0.setBaseShape((java.awt.Shape)var10);
    org.jfree.chart.entity.LegendItemEntity var13 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var10);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var16 = var15.getCategoryLabelPositionOffset();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    org.jfree.chart.title.LegendGraphic var18 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var10, var17);
    java.awt.Stroke var19 = var18.getLineStroke();
    var18.setShapeVisible(false);
    java.awt.Stroke var22 = var18.getOutlineStroke();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var23 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    java.awt.Paint var24 = var23.getFirstBarPaint();
    var18.setLinePaint(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test124"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var1 = var0.getURLGenerator();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.setTitle("ThreadContext");
    java.awt.Color var11 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var12 = var11.darker();
    var5.setBorderPaint((java.awt.Paint)var12);
    java.lang.String var14 = org.jfree.chart.util.PaintUtilities.colorToString(var12);
    var0.setLabelOutlinePaint((java.awt.Paint)var12);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var17 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var18 = var17.clone();
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
    boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
    org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
    int var29 = var28.getYYYY();
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var36 = var33.isOnOrBefore((org.jfree.data.time.SerialDate)var35);
    boolean var37 = var31.isOnOrAfter((org.jfree.data.time.SerialDate)var35);
    boolean var38 = var20.isInRange((org.jfree.data.time.SerialDate)var28, (org.jfree.data.time.SerialDate)var35);
    boolean var39 = var17.equals((java.lang.Object)var28);
    org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addMonths(1900, (org.jfree.data.time.SerialDate)var28);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var41 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var42 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var44 = var42.getSeriesNegativeItemLabelPosition((-1));
    var41.setNegativeItemLabelPositionFallback(var44);
    java.awt.Paint var48 = var41.getItemFillPaint(1900, 0);
    var0.setSectionOutlinePaint((java.lang.Comparable)var28, var48);
    var0.setIgnoreZeroValues(false);
    var0.setMinimumArcAngleToDraw(5.0d);
    double var54 = var0.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "black"+ "'", var14.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 4.0d);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test125"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Paint var3 = var0.getItemFillPaint(3, 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test126"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
    java.util.Date var4 = var3.getStart();
    java.lang.Number var6 = var0.getMeanValue((java.lang.Comparable)var3, (java.lang.Comparable)"AxisLocation.BOTTOM_OR_RIGHT");
    org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var13 = var10.isOnOrBefore((org.jfree.data.time.SerialDate)var12);
    boolean var14 = var8.isOnOrAfter((org.jfree.data.time.SerialDate)var12);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
    org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
    int var22 = var21.getYYYY();
    int var23 = var16.compare((org.jfree.data.time.SerialDate)var21);
    org.jfree.data.DefaultKeyedValues2D var24 = new org.jfree.data.DefaultKeyedValues2D();
    var24.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    int var30 = var24.getColumnIndex((java.lang.Comparable)(byte)0);
    var24.removeRow(0);
    boolean var33 = var16.equals((java.lang.Object)0);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var34 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var36 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var34, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var34, var38, var39, var40);
    java.lang.Number var44 = var34.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
    org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var51 = var48.isOnOrBefore((org.jfree.data.time.SerialDate)var50);
    boolean var52 = var46.isOnOrAfter((org.jfree.data.time.SerialDate)var50);
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var61 = var58.isOnOrBefore((org.jfree.data.time.SerialDate)var60);
    boolean var62 = var56.isOnOrAfter((org.jfree.data.time.SerialDate)var60);
    org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(4);
    int var65 = var64.getYYYY();
    org.jfree.data.time.SpreadsheetDate var67 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var69 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var71 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var72 = var69.isOnOrBefore((org.jfree.data.time.SerialDate)var71);
    boolean var73 = var67.isOnOrAfter((org.jfree.data.time.SerialDate)var71);
    boolean var74 = var56.isInRange((org.jfree.data.time.SerialDate)var64, (org.jfree.data.time.SerialDate)var71);
    org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var56);
    org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.addYears(1, (org.jfree.data.time.SerialDate)var56);
    java.lang.Number var77 = var34.getValue((java.lang.Comparable)var46, (java.lang.Comparable)var76);
    int var78 = var16.compare((org.jfree.data.time.SerialDate)var46);
    java.lang.Number var79 = var0.getValue((java.lang.Comparable)var14, (java.lang.Comparable)var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test127"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperMargin(0.0d);
    var1.setInverted(true);
    boolean var6 = var1.isVerticalTickLabels();
    var1.configure();
    var1.setAutoRangeMinimumSize(4.0d, false);
    java.text.NumberFormat var11 = var1.getNumberFormatOverride();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var14 = var13.getNumberFormatOverride();
    var13.setRangeWithMargins(0.0d, 1.0d);
    float var18 = var13.getTickMarkInsideLength();
    java.awt.Shape var19 = var13.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var22 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var19, "", "black");
    org.jfree.data.category.DefaultCategoryDataset var25 = new org.jfree.data.category.DefaultCategoryDataset();
    var25.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
    var25.clear();
    java.text.DateFormat var34 = null;
    org.jfree.chart.axis.DateTickUnit var35 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var34);
    var25.setValue((java.lang.Number)(byte)100, (java.lang.Comparable)1900, (java.lang.Comparable)"CONTRACT");
    var25.clear();
    org.jfree.data.KeyedObjects2D var39 = new org.jfree.data.KeyedObjects2D();
    int var40 = var39.getRowCount();
    org.jfree.chart.axis.CategoryLabelPosition var41 = new org.jfree.chart.axis.CategoryLabelPosition();
    double var42 = var41.getAngle();
    org.jfree.chart.axis.CategoryLabelWidthType var43 = var41.getWidthType();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var47 = var46.getCategoryLabelPositionOffset();
    var46.setUpperMargin(2.0d);
    var46.setLabelAngle((-1.0d));
    org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
    int var54 = var53.getYYYY();
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var59 = var56.isOnOrBefore((org.jfree.data.time.SerialDate)var58);
    org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var65 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var66 = var63.isOnOrBefore((org.jfree.data.time.SerialDate)var65);
    boolean var67 = var61.isOnOrAfter((org.jfree.data.time.SerialDate)var65);
    boolean var68 = var58.isBefore((org.jfree.data.time.SerialDate)var65);
    org.jfree.data.time.SpreadsheetDate var70 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var72 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var73 = var70.isOnOrBefore((org.jfree.data.time.SerialDate)var72);
    org.jfree.data.time.SpreadsheetDate var75 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var77 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var79 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var80 = var77.isOnOrBefore((org.jfree.data.time.SerialDate)var79);
    boolean var81 = var75.isOnOrAfter((org.jfree.data.time.SerialDate)var79);
    boolean var82 = var72.isBefore((org.jfree.data.time.SerialDate)var79);
    boolean var83 = var65.isOn((org.jfree.data.time.SerialDate)var72);
    int var84 = var53.compare((org.jfree.data.time.SerialDate)var72);
    int var85 = var72.getYYYY();
    java.awt.Paint var86 = var46.getTickLabelPaint((java.lang.Comparable)var72);
    var39.addObject((java.lang.Object)var41, (java.lang.Comparable)"ThreadContext", (java.lang.Comparable)var72);
    org.jfree.data.time.SpreadsheetDate var89 = new org.jfree.data.time.SpreadsheetDate(4);
    int var90 = var89.getYYYY();
    java.util.Date var91 = var89.toDate();
    boolean var92 = var72.isAfter((org.jfree.data.time.SerialDate)var89);
    org.jfree.chart.entity.CategoryItemEntity var94 = new org.jfree.chart.entity.CategoryItemEntity(var19, "ItemLabelAnchor.CENTER", "SerialDate.weekInMonthToString(): invalid code.", (org.jfree.data.category.CategoryDataset)var25, (java.lang.Comparable)var92, (java.lang.Comparable)false);
    org.jfree.chart.axis.NumberAxis var95 = new org.jfree.chart.axis.NumberAxis();
    boolean var96 = var94.equals((java.lang.Object)var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test128"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var14 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var15 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition((-1));
    var14.setNegativeItemLabelPositionFallback(var17);
    java.awt.Font var19 = var14.getBaseItemLabelFont();
    var7.setNoDataMessageFont(var19);
    boolean var21 = var7.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var25 = var24.getLabel();
    org.jfree.data.KeyedObject var26 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var24);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var29 = var28.getLabelInsets();
    double var31 = var29.calculateTopInset(100.0d);
    var24.setTickLabelInsets(var29);
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var37 = var36.getLabelInsets();
    double var39 = var37.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var40 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var41 = var40.getChartArea();
    java.awt.geom.Rectangle2D var44 = var37.createInsetRectangle(var41, true, false);
    java.lang.Object var46 = var33.draw(var34, var41, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.entity.AxisLabelEntity var49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var24, (java.awt.Shape)var41, "XY Plot", "WMAP_Plot");
    var24.setTickLabelsVisible(false);
    var7.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var24);
    var24.setMaximumCategoryLabelLines(2);
    java.awt.Paint var55 = var24.getTickLabelPaint();
    java.lang.Object var56 = var24.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test129"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(0.0d, 16.05d, false);
    java.awt.Graphics2D var4 = null;
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, var9, var10, var11);
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelOutlinePaint();
    var12.setRangeCrosshairPaint(var14);
    java.lang.String var16 = var12.getPlotType();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var19 = var18.getLabelInsets();
    double var20 = var18.getLowerBound();
    var18.centerRange((-27.0d));
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var23 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition((-1));
    var23.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var29 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var32 = var29.isItemLabelVisible(1, 0);
    double var33 = var29.getBase();
    boolean var34 = var29.getBaseCreateEntities();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var38 = var37.getLabelInsets();
    double var40 = var38.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var41 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var42 = var41.getChartArea();
    java.awt.geom.Rectangle2D var45 = var38.createInsetRectangle(var42, true, false);
    var29.setSeriesShape(0, (java.awt.Shape)var42);
    var23.setSeriesShape(28, (java.awt.Shape)var42);
    var3.drawRangeGridline(var4, var12, (org.jfree.chart.axis.ValueAxis)var18, var42, 1.0d);
    org.jfree.chart.util.Layer var51 = null;
    java.util.Collection var52 = var12.getDomainMarkers((-127), var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Category Plot"+ "'", var16.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test130"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var5, var6, var7);
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var10 = var9.getLabelOutlinePaint();
    var8.setRangeCrosshairPaint(var10);
    int var12 = var8.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var13 = new org.jfree.chart.axis.AxisSpace();
    var8.setFixedRangeAxisSpace(var13);
    org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
    var8.setFixedRangeAxisSpace(var15);
    java.lang.String var17 = var8.getPlotType();
    java.awt.Paint var18 = var8.getDomainGridlinePaint();
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var23.zoomDomainAxes((-1.0d), 0.2d, var26, var27);
    java.awt.Paint var29 = var23.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var31 = var23.getRangeAxisLocation(1);
    var8.setDomainAxisLocation(var31);
    boolean var33 = var0.equals((java.lang.Object)var8);
    var0.setItemLabelAnchorOffset(Double.POSITIVE_INFINITY);
    org.jfree.data.gantt.TaskSeriesCollection var36 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var37 = var36.getColumnCount();
    org.jfree.data.Range var38 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var41 = var36.getStartValue((java.lang.Comparable)31, (java.lang.Comparable)(-127));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Category Plot"+ "'", var17.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test131"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.data.xy.XYDataset var1 = var0.getDataset();
    java.awt.Stroke var2 = var0.getAngleGridlineStroke();
    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var7 = var6.getBorderStroke();
    var0.setRadiusGridlineStroke(var7);
    org.jfree.chart.axis.ValueAxis var9 = var0.getAxis();
    var0.addCornerTextItem("Last");
    org.jfree.chart.LegendItemCollection var12 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = var12.get(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test132"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    java.awt.Paint var2 = var1.getPaint();
    java.lang.Object var3 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test133"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    java.awt.Paint var12 = null;
    var4.setRangeTickBandPaint(var12);
    java.awt.geom.Point2D var14 = var4.getQuadrantOrigin();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomDomainAxes((-1.0d), 0.2d, var22, var23);
    java.awt.Paint var25 = var19.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var27 = var19.getRangeAxisLocation(1);
    java.lang.Object var28 = null;
    boolean var29 = var27.equals(var28);
    var4.setRangeAxisLocation(var27);
    java.awt.Paint var31 = var4.getRangeZeroBaselinePaint();
    org.jfree.chart.LegendItemCollection var32 = var4.getLegendItems();
    java.lang.String var33 = var4.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test134"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("CategoryLabelWidthType.CATEGORY", "Last", "org.jfree.data.general.SeriesChangeEvent[source=4]", "(10, 31)", "");

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test135"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    double var11 = var4.getDomainCrosshairValue();
    var4.setRangeZeroBaselineVisible(true);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    var16.setUpperMargin(0.0d);
    var16.setInverted(true);
    boolean var21 = var16.isVerticalTickLabels();
    var16.setPositiveArrowVisible(false);
    var4.setDomainAxis(3, (org.jfree.chart.axis.ValueAxis)var16);
    var4.clearDomainMarkers();
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.util.Layer var33 = null;
    java.util.Collection var34 = var31.getRangeMarkers(0, var33);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    java.awt.geom.Point2D var38 = null;
    var31.zoomDomainAxes(2.0d, 1.0d, var37, var38);
    org.jfree.chart.plot.PlotOrientation var40 = var31.getOrientation();
    org.jfree.chart.axis.AxisLocation var42 = var31.getDomainAxisLocation(28);
    var4.setDomainAxisLocation(255, var42, false);
    java.lang.String var45 = var42.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var45.equals("AxisLocation.TOP_OR_RIGHT"));

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test136"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    double var5 = var4.getDomainCrosshairValue();
    int var6 = var4.getSeriesCount();
    boolean var7 = var4.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test137"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(false);
    var0.setTranslateX(16.05d);
    double var5 = var0.getTranslateX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 16.05d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test138"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    var12.setLeft((-33.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test139"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    org.jfree.chart.title.TextTitle var6 = null;
    var3.setTitle(var6);
    var3.setAntiAlias(false);
    float var10 = var3.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var11 = var3.getLegend();
    var11.setHeight(0.0d);
    org.jfree.chart.util.RectangleAnchor var14 = var11.getLegendItemGraphicLocation();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var17 = var16.getLabelInsets();
    double var19 = var17.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var21 = var20.getChartArea();
    java.awt.geom.Rectangle2D var24 = var17.createInsetRectangle(var21, true, false);
    var11.setPadding(var17);
    org.jfree.chart.util.UnitType var26 = var17.getUnitType();
    java.lang.String var27 = var26.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "UnitType.ABSOLUTE"+ "'", var27.equals("UnitType.ABSOLUTE"));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test140"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
    var0.setItemMargin(1.0d);
    double var7 = var0.getItemMargin();
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    var8.setLegendItemShape((java.awt.Shape)var10);
    var0.setBaseShape((java.awt.Shape)var10);
    org.jfree.chart.entity.LegendItemEntity var13 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var10);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var16 = var15.getCategoryLabelPositionOffset();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    org.jfree.chart.title.LegendGraphic var18 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var10, var17);
    boolean var19 = var18.isShapeOutlineVisible();
    java.awt.Paint var20 = var18.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test141"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var11.setTitle("ThreadContext");
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var11.setBorderPaint((java.awt.Paint)var18);
    var7.setRangeGridlinePaint((java.awt.Paint)var18);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var25.zoomDomainAxes((-1.0d), 0.2d, var28, var29);
    java.awt.Paint var31 = var25.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var33 = var25.getRangeAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var34 = org.jfree.chart.axis.AxisLocation.getOpposite(var33);
    var7.setDomainAxisLocation(var33, true);
    java.awt.Paint var37 = var7.getBackgroundPaint();
    org.jfree.chart.util.RectangleEdge var38 = var7.getRangeAxisEdge();
    var7.clearAnnotations();
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var40 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    var40.setFillBox(false);
    var40.setItemMargin(2.0d);
    java.awt.Paint var45 = var40.getArtifactPaint();
    double var46 = var40.getItemMargin();
    int var47 = var7.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-1));

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test142"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    double var3 = var1.getMaximumBarWidth();
    int var4 = var1.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)var1);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var8 = null;
    var7.setLabelOutlinePaint(var8);
    java.awt.Stroke var10 = var7.getLabelOutlineStroke();
    java.awt.Paint var11 = var7.getLabelPaint();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    org.jfree.chart.labels.PieToolTipGenerator var14 = var7.getToolTipGenerator();
    org.jfree.data.general.PieDataset var15 = var7.getDataset();
    boolean var16 = var7.isCircular();
    boolean var17 = var0.equals((java.lang.Object)var7);
    java.awt.Stroke var18 = var7.getBaseSectionOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test143"); }
// 
// 
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(3, 100, 0, 1, var4);
//     java.awt.Shape var10 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var11 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var12 = var11.clone();
//     java.awt.Paint var13 = var11.getBasePaint();
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var10, var13);
//     java.awt.Stroke var15 = var14.getOutlineStroke();
//     int var16 = var14.getDatasetIndex();
//     java.text.AttributedString var17 = var14.getAttributedLabel();
//     java.lang.String var18 = var14.getURLText();
//     java.awt.Paint var19 = var14.getLinePaint();
//     java.lang.Comparable var20 = var14.getSeriesKey();
//     boolean var21 = var14.isShapeOutlineVisible();
//     java.text.DateFormat var24 = null;
//     org.jfree.chart.axis.DateTickUnit var25 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var24);
//     java.lang.String var27 = var25.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var35 = var32.isOnOrBefore((org.jfree.data.time.SerialDate)var34);
//     boolean var36 = var30.isOnOrAfter((org.jfree.data.time.SerialDate)var34);
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var39 = var38.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var46 = var43.isOnOrBefore((org.jfree.data.time.SerialDate)var45);
//     boolean var47 = var41.isOnOrAfter((org.jfree.data.time.SerialDate)var45);
//     boolean var48 = var30.isInRange((org.jfree.data.time.SerialDate)var38, (org.jfree.data.time.SerialDate)var45);
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var30);
//     java.util.Date var50 = var30.toDate();
//     java.util.Date var51 = var25.rollDate(var50);
//     org.jfree.chart.plot.CategoryMarker var52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var51);
//     org.jfree.data.time.Month var53 = new org.jfree.data.time.Month(var51);
//     boolean var54 = var14.equals((java.lang.Object)var51);
//     java.util.Date var55 = var5.addToDate(var51);
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "12/31/69"+ "'", var27.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test144"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var14 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var15 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition((-1));
    var14.setNegativeItemLabelPositionFallback(var17);
    java.awt.Font var19 = var14.getBaseItemLabelFont();
    var7.setNoDataMessageFont(var19);
    boolean var21 = var7.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var25 = var24.getLabel();
    org.jfree.data.KeyedObject var26 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var24);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var29 = var28.getLabelInsets();
    double var31 = var29.calculateTopInset(100.0d);
    var24.setTickLabelInsets(var29);
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var37 = var36.getLabelInsets();
    double var39 = var37.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var40 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var41 = var40.getChartArea();
    java.awt.geom.Rectangle2D var44 = var37.createInsetRectangle(var41, true, false);
    java.lang.Object var46 = var33.draw(var34, var41, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.entity.AxisLabelEntity var49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var24, (java.awt.Shape)var41, "XY Plot", "WMAP_Plot");
    var24.setTickLabelsVisible(false);
    var7.setDomainAxis((org.jfree.chart.axis.CategoryAxis)var24);
    org.jfree.chart.event.RendererChangeEvent var53 = null;
    var7.rendererChanged(var53);
    org.jfree.chart.axis.CategoryAxis var55 = var7.getDomainAxis();
    org.jfree.chart.axis.CategoryAxis3D var59 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var60 = var59.getLabel();
    org.jfree.data.KeyedObject var61 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var59);
    var7.setDomainAxis(3, (org.jfree.chart.axis.CategoryAxis)var59, false);
    var59.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var60 + "' != '" + ""+ "'", var60.equals(""));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test145"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var1 = null;
    var0.setLabelOutlinePaint(var1);
    java.awt.Stroke var3 = var0.getLabelOutlineStroke();
    java.awt.Paint var4 = var0.getLabelPaint();
    org.jfree.data.general.DatasetChangeEvent var5 = null;
    var0.datasetChanged(var5);
    java.lang.Object var7 = var0.clone();
    java.lang.String var8 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Pie Plot"+ "'", var8.equals("Pie Plot"));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test146"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperMargin(0.0d);
    var9.setInverted(true);
    boolean var14 = var9.isVerticalTickLabels();
    double var15 = var9.getFixedAutoRange();
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var9);
    java.awt.Paint var17 = null;
    var4.setOutlinePaint(var17);
    var4.mapDatasetToRangeAxis(0, 100);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var22 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var22, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, var26, var27, var28);
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var31 = var30.getLabelOutlinePaint();
    var29.setRangeCrosshairPaint(var31);
    int var33 = var29.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var34 = new org.jfree.chart.axis.AxisSpace();
    var29.setFixedRangeAxisSpace(var34);
    org.jfree.chart.axis.AxisSpace var36 = new org.jfree.chart.axis.AxisSpace();
    var29.setFixedRangeAxisSpace(var36);
    java.lang.String var38 = var29.getPlotType();
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    java.awt.geom.Point2D var47 = null;
    var43.zoomDomainAxes((-1.0d), 0.2d, var46, var47);
    java.awt.Paint var49 = var43.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var51 = var43.getRangeAxisLocation(1);
    var29.setDomainAxisLocation(var51, false);
    var4.setRangeAxisLocation(var51);
    var4.configureDomainAxes();
    boolean var56 = var4.isDomainZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "Category Plot"+ "'", var38.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test147"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    org.jfree.chart.JFreeChart var3 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    java.awt.Image var4 = null;
    var3.setBackgroundImage(var4);
    var3.fireChartChanged();
    int var7 = var3.getSubtitleCount();
    org.jfree.chart.title.LegendTitle var9 = var3.getLegend(3);
    org.jfree.chart.event.ChartProgressListener var10 = null;
    var3.removeProgressListener(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test148"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
//     java.awt.Paint var10 = var4.getRangeCrosshairPaint();
//     double var11 = var4.getDomainCrosshairValue();
//     var4.setRangeZeroBaselineVisible(true);
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var15 = var14.getLabelOutlinePaint();
//     var4.setRangeTickBandPaint(var15);
//     var4.setWeight(3);
//     boolean var19 = var4.isRangeCrosshairVisible();
//     java.awt.Paint var20 = var4.getOutlinePaint();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("");
//     org.jfree.chart.util.RectangleInsets var26 = var25.getLabelInsets();
//     double var28 = var26.calculateTopInset(100.0d);
//     org.jfree.chart.ChartRenderingInfo var29 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var30 = var29.getChartArea();
//     java.awt.geom.Rectangle2D var33 = var26.createInsetRectangle(var30, true, false);
//     java.lang.Object var35 = var22.draw(var23, var30, (java.lang.Object)"WMAP_Plot");
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     org.jfree.chart.util.Layer var42 = null;
//     java.util.Collection var43 = var40.getRangeMarkers(0, var42);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     java.awt.geom.Point2D var47 = null;
//     var40.zoomDomainAxes(2.0d, 1.0d, var46, var47);
//     org.jfree.chart.ChartRenderingInfo var50 = new org.jfree.chart.ChartRenderingInfo();
//     java.awt.geom.Rectangle2D var51 = var50.getChartArea();
//     java.lang.Object var52 = var50.clone();
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var50);
//     java.awt.geom.Point2D var54 = null;
//     var40.zoomDomainAxes(2.0d, var53, var54);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var56 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var53);
//     var4.drawAnnotations(var21, var30, var53);
//     
//     // Checks the contract:  equals-hashcode on var29 and var50
//     assertTrue("Contract failed: equals-hashcode on var29 and var50", var29.equals(var50) ? var29.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var29
//     assertTrue("Contract failed: equals-hashcode on var50 and var29", var50.equals(var29) ? var50.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test149"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    double var3 = var1.getMaximumBarWidth();
    int var4 = var1.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)var1);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var8 = null;
    var7.setLabelOutlinePaint(var8);
    java.awt.Stroke var10 = var7.getLabelOutlineStroke();
    java.awt.Paint var11 = var7.getLabelPaint();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    org.jfree.chart.labels.PieToolTipGenerator var14 = var7.getToolTipGenerator();
    org.jfree.data.general.PieDataset var15 = var7.getDataset();
    boolean var16 = var7.isCircular();
    boolean var17 = var0.equals((java.lang.Object)var7);
    java.text.NumberFormat var18 = var0.getNumberFormat();
    java.text.NumberFormat var19 = var0.getNumberFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test150"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var5.getRangeMarkers(0, var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.data.Range var10 = var5.getDataRange(var9);
    var5.clearAnnotations();
    boolean var12 = var0.equals((java.lang.Object)var5);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var0.calculateBounds(var13, 100.0f, 0.95f, var16, 0.5f, 2.0f, 12.0d);
    org.jfree.chart.text.TextLine var21 = var0.getLastLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test151"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
    org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var15 = var14.getChartArea();
    java.lang.Object var16 = var14.clone();
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
    java.awt.geom.Point2D var18 = null;
    var4.zoomDomainAxes(2.0d, var17, var18);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var30, var31, var32);
    org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var35 = var34.getLabelOutlinePaint();
    var33.setRangeCrosshairPaint(var35);
    var25.setDomainTickBandPaint(var35);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var38 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var41 = var38.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var43 = null;
    org.jfree.chart.renderer.WaferMapRenderer var44 = null;
    org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var45);
    java.awt.Stroke var47 = var46.getBorderStroke();
    var38.setSeriesStroke(100, var47, true);
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(0.0d, var35, var47);
    org.jfree.chart.util.LengthAdjustmentType var51 = var50.getLabelOffsetType();
    org.jfree.chart.event.MarkerChangeListener var52 = null;
    var50.addChangeListener(var52);
    org.jfree.chart.util.RectangleInsets var54 = var50.getLabelOffset();
    java.awt.Stroke var55 = var50.getOutlineStroke();
    var4.setRangeZeroBaselineStroke(var55);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
    org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
    org.jfree.chart.plot.PlotRenderingInfo var64 = null;
    java.awt.geom.Point2D var65 = null;
    var61.zoomDomainAxes((-1.0d), 0.2d, var64, var65);
    java.awt.Paint var67 = var61.getRangeCrosshairPaint();
    double var68 = var61.getDomainCrosshairValue();
    var61.setRangeZeroBaselineVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
    var61.setRenderer(var71);
    org.jfree.chart.axis.ValueAxis var74 = var61.getDomainAxis(10);
    org.jfree.chart.plot.DatasetRenderingOrder var75 = var61.getDatasetRenderingOrder();
    var4.setDatasetRenderingOrder(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test152"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    double var11 = var4.getDomainCrosshairValue();
    var4.setRangeZeroBaselineVisible(true);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("");
    var16.setUpperMargin(0.0d);
    var16.setInverted(true);
    boolean var21 = var16.isVerticalTickLabels();
    var16.setPositiveArrowVisible(false);
    var4.setDomainAxis(3, (org.jfree.chart.axis.ValueAxis)var16);
    var4.mapDatasetToDomainAxis(31, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test153"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    var0.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    int var6 = var0.getColumnIndex((java.lang.Comparable)(byte)0);
    int var7 = var0.getRowCount();
    var0.removeColumn((java.lang.Comparable)1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test154"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");
    var1.setUpperMargin(0.0d);
    var1.setInverted(true);
    boolean var6 = var1.isVerticalTickLabels();
    var1.configure();
    var1.setAutoRangeMinimumSize(4.0d, false);
    java.text.NumberFormat var11 = var1.getNumberFormatOverride();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var14 = var13.getNumberFormatOverride();
    var13.setRangeWithMargins(0.0d, 1.0d);
    float var18 = var13.getTickMarkInsideLength();
    java.awt.Shape var19 = var13.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var22 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var19, "", "black");
    org.jfree.data.category.DefaultCategoryDataset var25 = new org.jfree.data.category.DefaultCategoryDataset();
    var25.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
    var25.clear();
    java.text.DateFormat var34 = null;
    org.jfree.chart.axis.DateTickUnit var35 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var34);
    var25.setValue((java.lang.Number)(byte)100, (java.lang.Comparable)1900, (java.lang.Comparable)"CONTRACT");
    var25.clear();
    org.jfree.data.KeyedObjects2D var39 = new org.jfree.data.KeyedObjects2D();
    int var40 = var39.getRowCount();
    org.jfree.chart.axis.CategoryLabelPosition var41 = new org.jfree.chart.axis.CategoryLabelPosition();
    double var42 = var41.getAngle();
    org.jfree.chart.axis.CategoryLabelWidthType var43 = var41.getWidthType();
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var47 = var46.getCategoryLabelPositionOffset();
    var46.setUpperMargin(2.0d);
    var46.setLabelAngle((-1.0d));
    org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
    int var54 = var53.getYYYY();
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var59 = var56.isOnOrBefore((org.jfree.data.time.SerialDate)var58);
    org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var65 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var66 = var63.isOnOrBefore((org.jfree.data.time.SerialDate)var65);
    boolean var67 = var61.isOnOrAfter((org.jfree.data.time.SerialDate)var65);
    boolean var68 = var58.isBefore((org.jfree.data.time.SerialDate)var65);
    org.jfree.data.time.SpreadsheetDate var70 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var72 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var73 = var70.isOnOrBefore((org.jfree.data.time.SerialDate)var72);
    org.jfree.data.time.SpreadsheetDate var75 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var77 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var79 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var80 = var77.isOnOrBefore((org.jfree.data.time.SerialDate)var79);
    boolean var81 = var75.isOnOrAfter((org.jfree.data.time.SerialDate)var79);
    boolean var82 = var72.isBefore((org.jfree.data.time.SerialDate)var79);
    boolean var83 = var65.isOn((org.jfree.data.time.SerialDate)var72);
    int var84 = var53.compare((org.jfree.data.time.SerialDate)var72);
    int var85 = var72.getYYYY();
    java.awt.Paint var86 = var46.getTickLabelPaint((java.lang.Comparable)var72);
    var39.addObject((java.lang.Object)var41, (java.lang.Comparable)"ThreadContext", (java.lang.Comparable)var72);
    org.jfree.data.time.SpreadsheetDate var89 = new org.jfree.data.time.SpreadsheetDate(4);
    int var90 = var89.getYYYY();
    java.util.Date var91 = var89.toDate();
    boolean var92 = var72.isAfter((org.jfree.data.time.SerialDate)var89);
    org.jfree.chart.entity.CategoryItemEntity var94 = new org.jfree.chart.entity.CategoryItemEntity(var19, "ItemLabelAnchor.CENTER", "SerialDate.weekInMonthToString(): invalid code.", (org.jfree.data.category.CategoryDataset)var25, (java.lang.Comparable)var92, (java.lang.Comparable)false);
    java.lang.String var95 = var94.toString();
    java.lang.Comparable var96 = var94.getColumnKey();
    java.lang.Comparable var97 = var94.getRowKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var96 + "' != '" + false+ "'", var96.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var97 + "' != '" + false+ "'", var97.equals(false));

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test155"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var2 = var1.clone();
    int var3 = var1.getMaximumCategoryLabelLines();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    boolean var8 = var5.getBaseSeriesVisible();
    org.jfree.chart.util.GradientPaintTransformer var9 = null;
    var5.setGradientPaintTransformer(var9);
    java.awt.Paint var13 = var5.getItemLabelPaint(31, 1900);
    var1.setTickLabelPaint((java.lang.Comparable)"rect", var13);
    var1.setMaximumCategoryLabelLines((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test156"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var3 = null;
    var2.setLabelOutlinePaint(var3);
    java.awt.Stroke var5 = var2.getLabelOutlineStroke();
    var1.setOutlineStroke(var5);
    java.awt.Paint var7 = var1.getAggregatedItemsPaint();
    org.jfree.chart.JFreeChart var8 = var1.getPieChart();
    org.jfree.chart.event.ChartProgressListener var9 = null;
    var8.addProgressListener(var9);
    org.jfree.chart.event.ChartChangeListener var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.removeChangeListener(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test157"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(10);
    java.awt.Paint var3 = var0.getBaseItemLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test158"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    double var3 = var2.getLength();
    org.jfree.data.Range var6 = new org.jfree.data.Range(0.0d, 0.0d);
    double var7 = var6.getUpperBound();
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var2, var6);
    org.jfree.data.Range var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var10 = var8.toRangeWidth(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test159"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.2d, 3.0d);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)'a');
//     org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var5, true);
//     java.text.DateFormat var12 = null;
//     org.jfree.chart.axis.DateTickUnit var13 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var12);
//     java.lang.String var15 = var13.valueToString(1.0d);
//     java.lang.String var17 = var13.valueToString(1.0d);
//     java.lang.Number var19 = var5.getMinRegularValue((java.lang.Comparable)var17, (java.lang.Comparable)0);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var26 = var23.isOnOrBefore((org.jfree.data.time.SerialDate)var25);
//     boolean var27 = var21.isOnOrAfter((org.jfree.data.time.SerialDate)var25);
//     java.text.DateFormat var30 = null;
//     org.jfree.chart.axis.DateTickUnit var31 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var30);
//     java.lang.String var33 = var31.valueToString(1.0d);
//     java.lang.Number var34 = var5.getMedianValue((java.lang.Comparable)var27, (java.lang.Comparable)1.0d);
//     boolean var35 = var4.equals((java.lang.Object)var5);
//     org.jfree.chart.axis.SegmentedTimeline var39 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var41 = var39.getSegment(100L);
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var49 = var46.isOnOrBefore((org.jfree.data.time.SerialDate)var48);
//     boolean var50 = var44.isOnOrAfter((org.jfree.data.time.SerialDate)var48);
//     org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var53 = var52.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var60 = var57.isOnOrBefore((org.jfree.data.time.SerialDate)var59);
//     boolean var61 = var55.isOnOrAfter((org.jfree.data.time.SerialDate)var59);
//     boolean var62 = var44.isInRange((org.jfree.data.time.SerialDate)var52, (org.jfree.data.time.SerialDate)var59);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var44);
//     java.util.Date var64 = var44.toDate();
//     boolean var65 = var39.containsDomainValue(var64);
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var64);
//     java.text.DateFormat var71 = null;
//     org.jfree.chart.axis.DateTickUnit var72 = new org.jfree.chart.axis.DateTickUnit(3, 100, 0, 1, var71);
//     java.util.List var73 = var5.getOutliers((java.lang.Comparable)var64, (java.lang.Comparable)100);
//     java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
//     org.jfree.chart.entity.CategoryLabelEntity var78 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)100, var75, "", "SerialDate.weekInMonthToString(): invalid code.");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "12/31/69"+ "'", var15.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "12/31/69"+ "'", var17.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "12/31/69"+ "'", var33.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test160"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
    java.awt.Color var4 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var0.setBaseFillPaint((java.awt.Paint)var4);
    org.jfree.data.general.WaferMapDataset var7 = null;
    org.jfree.chart.renderer.WaferMapRenderer var8 = null;
    org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var7, var8);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
    var10.setTitle("ThreadContext");
    java.awt.Color var16 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var17 = var16.darker();
    var10.setBorderPaint((java.awt.Paint)var17);
    int var19 = var17.getBlue();
    var0.setSeriesFillPaint(255, (java.awt.Paint)var17, false);
    var0.setDrawBarOutline(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test161"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     var0.addValue(4.0d, (java.lang.Comparable)"XY Plot", (java.lang.Comparable)10.0d);
//     java.lang.Object var5 = var0.clone();
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var11 = var8.isOnOrBefore((org.jfree.data.time.SerialDate)var10);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var18 = var15.isOnOrBefore((org.jfree.data.time.SerialDate)var17);
//     boolean var19 = var13.isOnOrAfter((org.jfree.data.time.SerialDate)var17);
//     boolean var20 = var10.isBefore((org.jfree.data.time.SerialDate)var17);
//     java.text.DateFormat var23 = null;
//     org.jfree.chart.axis.DateTickUnit var24 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var23);
//     java.lang.String var26 = var24.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var34 = var31.isOnOrBefore((org.jfree.data.time.SerialDate)var33);
//     boolean var35 = var29.isOnOrAfter((org.jfree.data.time.SerialDate)var33);
//     org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var38 = var37.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var45 = var42.isOnOrBefore((org.jfree.data.time.SerialDate)var44);
//     boolean var46 = var40.isOnOrAfter((org.jfree.data.time.SerialDate)var44);
//     boolean var47 = var29.isInRange((org.jfree.data.time.SerialDate)var37, (org.jfree.data.time.SerialDate)var44);
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var29);
//     java.util.Date var49 = var29.toDate();
//     java.util.Date var50 = var24.rollDate(var49);
//     int var51 = var24.getUnit();
//     org.jfree.chart.axis.SegmentedTimeline var55 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var57 = var55.getSegment(100L);
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var62 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var64 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var65 = var62.isOnOrBefore((org.jfree.data.time.SerialDate)var64);
//     boolean var66 = var60.isOnOrAfter((org.jfree.data.time.SerialDate)var64);
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var69 = var68.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var71 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var73 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var75 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var76 = var73.isOnOrBefore((org.jfree.data.time.SerialDate)var75);
//     boolean var77 = var71.isOnOrAfter((org.jfree.data.time.SerialDate)var75);
//     boolean var78 = var60.isInRange((org.jfree.data.time.SerialDate)var68, (org.jfree.data.time.SerialDate)var75);
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var60);
//     java.util.Date var80 = var60.toDate();
//     boolean var81 = var55.containsDomainValue(var80);
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.createInstance(var80);
//     java.util.Date var83 = var24.addToDate(var80);
//     org.jfree.data.time.SerialDate var84 = org.jfree.data.time.SerialDate.createInstance(var83);
//     var0.addValue(8.05d, (java.lang.Comparable)var17, (java.lang.Comparable)var84);
//     org.jfree.data.DefaultKeyedValue var87 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable)8.05d, (java.lang.Number)10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "12/31/69"+ "'", var26.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test162"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("");
    var9.setUpperMargin(0.0d);
    var9.setInverted(true);
    boolean var14 = var9.isVerticalTickLabels();
    double var15 = var9.getFixedAutoRange();
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var9);
    java.awt.Paint var17 = null;
    var4.setOutlinePaint(var17);
    var4.mapDatasetToRangeAxis(0, 100);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var22 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var24 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var22, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, var26, var27, var28);
    org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var31 = var30.getLabelOutlinePaint();
    var29.setRangeCrosshairPaint(var31);
    int var33 = var29.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var34 = new org.jfree.chart.axis.AxisSpace();
    var29.setFixedRangeAxisSpace(var34);
    org.jfree.chart.axis.AxisSpace var36 = new org.jfree.chart.axis.AxisSpace();
    var29.setFixedRangeAxisSpace(var36);
    java.lang.String var38 = var29.getPlotType();
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var39, var40, var41, var42);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    java.awt.geom.Point2D var47 = null;
    var43.zoomDomainAxes((-1.0d), 0.2d, var46, var47);
    java.awt.Paint var49 = var43.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var51 = var43.getRangeAxisLocation(1);
    var29.setDomainAxisLocation(var51, false);
    var4.setRangeAxisLocation(var51);
    org.jfree.chart.util.RectangleEdge var56 = var4.getRangeAxisEdge(28);
    org.jfree.chart.util.RectangleEdge var57 = org.jfree.chart.util.RectangleEdge.opposite(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "Category Plot"+ "'", var38.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test163"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    int var1 = var0.getColumnCount();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.awt.Image var6 = null;
    var5.setBackgroundImage(var6);
    org.jfree.chart.title.TextTitle var8 = null;
    var5.setTitle(var8);
    var5.setAntiAlias(false);
    float var12 = var5.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var13 = var5.getLegend();
    var13.setHeight(0.0d);
    org.jfree.chart.block.BlockContainer var16 = var13.getItemContainer();
    org.jfree.chart.block.BlockFrame var17 = var16.getFrame();
    var16.clear();
    boolean var19 = var0.equals((java.lang.Object)var16);
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var22 = var21.getCategoryLabelPositionOffset();
    java.awt.Paint var23 = var21.getAxisLinePaint();
    java.awt.Stroke var24 = var21.getTickMarkStroke();
    int var25 = var21.getCategoryLabelPositionOffset();
    org.jfree.data.general.SeriesChangeEvent var26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
    java.lang.Object var27 = var26.getSource();
    var0.seriesChanged(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + 4+ "'", var27.equals(4));

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test164"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var12 = var4.getRangeAxisLocation(1);
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.data.DefaultKeyedValues2D var15 = new org.jfree.data.DefaultKeyedValues2D();
    var15.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var20 = null;
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var28 = var25.isOnOrBefore((org.jfree.data.time.SerialDate)var27);
    boolean var29 = var23.isOnOrAfter((org.jfree.data.time.SerialDate)var27);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    int var32 = var31.getYYYY();
    org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var39 = var36.isOnOrBefore((org.jfree.data.time.SerialDate)var38);
    boolean var40 = var34.isOnOrAfter((org.jfree.data.time.SerialDate)var38);
    boolean var41 = var23.isInRange((org.jfree.data.time.SerialDate)var31, (org.jfree.data.time.SerialDate)var38);
    var15.addValue(var20, (java.lang.Comparable)' ', (java.lang.Comparable)var23);
    java.util.List var43 = var15.getColumnKeys();
    java.util.List var44 = var15.getColumnKeys();
    var4.drawDomainTickBands(var13, var14, var44);
    var4.mapDatasetToRangeAxis(0, (-914420));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test165"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState((-10.0d));
    var1.setMax(3.0d);
    java.util.List var4 = var1.getTicks();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test166"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var7 = var4.isOnOrBefore((org.jfree.data.time.SerialDate)var6);
    boolean var8 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    int var9 = var0.getIndex((java.lang.Comparable)var8);
    var0.clear();
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
    int var13 = var12.getYYYY();
    org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var18 = var15.isOnOrBefore((org.jfree.data.time.SerialDate)var17);
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
    boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
    boolean var27 = var17.isBefore((org.jfree.data.time.SerialDate)var24);
    org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var32 = var29.isOnOrBefore((org.jfree.data.time.SerialDate)var31);
    org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var39 = var36.isOnOrBefore((org.jfree.data.time.SerialDate)var38);
    boolean var40 = var34.isOnOrAfter((org.jfree.data.time.SerialDate)var38);
    boolean var41 = var31.isBefore((org.jfree.data.time.SerialDate)var38);
    boolean var42 = var24.isOn((org.jfree.data.time.SerialDate)var31);
    int var43 = var12.compare((org.jfree.data.time.SerialDate)var31);
    var0.setValue((java.lang.Comparable)var43, (java.lang.Number)12.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var47 = var0.getKey((-2097352));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test167"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isRangeCrosshairVisible();
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var8 = var7.getTickMarkStroke();
    var4.setDomainCrosshairStroke(var8);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("");
    var12.setUpperMargin(0.0d);
    var12.setInverted(true);
    boolean var17 = var12.isVerticalTickLabels();
    double var18 = var12.getFixedAutoRange();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    java.lang.Object var20 = var19.clone();
    boolean var21 = var12.equals(var20);
    var12.setAutoRangeIncludesZero(false);
    var12.setFixedAutoRange(2.0d);
    var12.setFixedDimension(12.0d);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var28 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var29 = var28.clone();
    java.awt.Paint var30 = var28.getBasePaint();
    boolean var31 = var28.getBaseSeriesVisible();
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var34 = var33.getCategoryLabelPositionOffset();
    java.awt.Paint var35 = var33.getAxisLinePaint();
    java.awt.Stroke var36 = var33.getTickMarkStroke();
    var28.setBaseStroke(var36, true);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
    java.awt.Paint var42 = var41.getWallPaint();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var49 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var50 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var51 = var50.clone();
    java.awt.Paint var52 = var50.getBasePaint();
    org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var49, var52);
    var43.setSeriesOutlinePaint(0, var52, true);
    boolean var56 = var41.equals((java.lang.Object)var52);
    org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var59 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var60 = var59.getChartArea();
    var58.setLegendItemShape((java.awt.Shape)var60);
    var41.setSeriesShape(4, (java.awt.Shape)var60);
    var28.setBaseShape((java.awt.Shape)var60, true);
    var12.setRightArrow((java.awt.Shape)var60);
    java.util.List var66 = null;
    var4.drawDomainTickBands(var10, var60, var66);
    org.jfree.chart.util.RectangleEdge var69 = var4.getDomainAxisEdge((-1));
    var4.setDomainCrosshairValue(0.05d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test168"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    var0.setEndPercent(2.0d);
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var4 = var3.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var10 = var9.getLabelOutlinePaint();
    var7.setBackgroundPaint(var10);
    var3.setLabelShadowPaint(var10);
    var3.setOutlineVisible(false);
    var3.setLabelLinkMargin((-10.0d));
    org.jfree.chart.labels.PieToolTipGenerator var17 = var3.getToolTipGenerator();
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var19 = var18.getURLGenerator();
    java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var18.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var24);
    java.awt.color.ColorSpace var26 = var24.getColorSpace();
    int var27 = var24.getGreen();
    var3.setBaseSectionOutlinePaint((java.awt.Paint)var24);
    var0.setCompletePaint((java.awt.Paint)var24);
    java.awt.Stroke var30 = var0.getBaseStroke();
    boolean var31 = var0.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.labels.ItemLabelPosition var33 = var0.getSeriesPositiveItemLabelPosition(2058);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test169"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var2 = var1.getTickMarkStroke();
    java.lang.Object var3 = var1.clone();
    double var4 = var1.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test170"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     long var4 = var3.getSegmentsGroupSize();
//     int var5 = var3.getSegmentsExcluded();
//     org.jfree.chart.axis.SegmentedTimeline var9 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var11 = var9.getSegment(100L);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     boolean var20 = var14.isOnOrAfter((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var23 = var22.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var30 = var27.isOnOrBefore((org.jfree.data.time.SerialDate)var29);
//     boolean var31 = var25.isOnOrAfter((org.jfree.data.time.SerialDate)var29);
//     boolean var32 = var14.isInRange((org.jfree.data.time.SerialDate)var22, (org.jfree.data.time.SerialDate)var29);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var14);
//     java.util.Date var34 = var14.toDate();
//     boolean var35 = var9.containsDomainValue(var34);
//     long var36 = var3.getTime(var34);
//     org.jfree.chart.axis.SegmentedTimeline.Segment var38 = var3.getSegment((-2208787199569L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-13L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == (-2208787199796L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test171"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var14 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var15 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition((-1));
    var14.setNegativeItemLabelPositionFallback(var17);
    java.awt.Font var19 = var14.getBaseItemLabelFont();
    var7.setNoDataMessageFont(var19);
    org.jfree.chart.axis.AxisLocation var22 = var7.getDomainAxisLocation(4);
    var7.configureDomainAxes();
    boolean var24 = var7.isDomainZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test172"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
    org.jfree.data.DefaultKeyedValues2D var7 = new org.jfree.data.DefaultKeyedValues2D();
    var7.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var12 = null;
    org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var20 = var17.isOnOrBefore((org.jfree.data.time.SerialDate)var19);
    boolean var21 = var15.isOnOrAfter((org.jfree.data.time.SerialDate)var19);
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    int var24 = var23.getYYYY();
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var31 = var28.isOnOrBefore((org.jfree.data.time.SerialDate)var30);
    boolean var32 = var26.isOnOrAfter((org.jfree.data.time.SerialDate)var30);
    boolean var33 = var15.isInRange((org.jfree.data.time.SerialDate)var23, (org.jfree.data.time.SerialDate)var30);
    var7.addValue(var12, (java.lang.Comparable)' ', (java.lang.Comparable)var15);
    boolean var35 = var6.equals((java.lang.Object)var12);
    java.lang.String var37 = var6.valueToString(0.0d);
    org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var42 = var39.isOnOrBefore((org.jfree.data.time.SerialDate)var41);
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var49 = var46.isOnOrBefore((org.jfree.data.time.SerialDate)var48);
    boolean var50 = var44.isOnOrAfter((org.jfree.data.time.SerialDate)var48);
    boolean var51 = var41.isBefore((org.jfree.data.time.SerialDate)var48);
    org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var56 = var53.isOnOrBefore((org.jfree.data.time.SerialDate)var55);
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var62 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var63 = var60.isOnOrBefore((org.jfree.data.time.SerialDate)var62);
    boolean var64 = var58.isOnOrAfter((org.jfree.data.time.SerialDate)var62);
    boolean var65 = var55.isBefore((org.jfree.data.time.SerialDate)var62);
    boolean var66 = var48.isOn((org.jfree.data.time.SerialDate)var55);
    var48.setDescription("April");
    java.lang.String var69 = var48.toString();
    java.lang.Number var70 = var0.getMaxRegularValue((java.lang.Comparable)var37, (java.lang.Comparable)var48);
    java.lang.Object var71 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0d+ "'", var4.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "0"+ "'", var37.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "3-January-1900"+ "'", var69.equals("3-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test173"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.lang.Boolean var2 = var0.getSeriesShapesVisible(100);
    java.lang.Boolean var4 = var0.getSeriesShapesVisible(0);
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    java.awt.Image var9 = null;
    var8.setBackgroundImage(var9);
    var8.fireChartChanged();
    org.jfree.chart.util.RectangleInsets var12 = var8.getPadding();
    boolean var13 = var0.equals((java.lang.Object)var12);
    java.lang.Boolean var15 = var0.getSeriesVisibleInLegend((-668));
    boolean var16 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test174"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    java.lang.Number var5 = var0.getMeanValue((java.lang.Comparable)(short)1, (java.lang.Comparable)2.0d);
    int var6 = var0.getColumnCount();
    java.lang.Comparable var7 = null;
    java.lang.Number var9 = var0.getMaxOutlier(var7, (java.lang.Comparable)"Range[0.0,0.0]");
    org.jfree.data.Range var11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var0.getMaxOutlier(100, 1901);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test175"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    int var10 = var8.getDatasetIndex();
    java.text.AttributedString var11 = var8.getAttributedLabel();
    boolean var12 = var8.isShapeVisible();
    int var13 = var8.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test176"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    double var3 = var2.getAngle();
    org.jfree.chart.axis.CategoryLabelWidthType var4 = var2.getWidthType();
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var8 = var7.getCategoryLabelPositionOffset();
    var7.setUpperMargin(2.0d);
    var7.setLabelAngle((-1.0d));
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
    int var15 = var14.getYYYY();
    org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var20 = var17.isOnOrBefore((org.jfree.data.time.SerialDate)var19);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var27 = var24.isOnOrBefore((org.jfree.data.time.SerialDate)var26);
    boolean var28 = var22.isOnOrAfter((org.jfree.data.time.SerialDate)var26);
    boolean var29 = var19.isBefore((org.jfree.data.time.SerialDate)var26);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var34 = var31.isOnOrBefore((org.jfree.data.time.SerialDate)var33);
    org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var41 = var38.isOnOrBefore((org.jfree.data.time.SerialDate)var40);
    boolean var42 = var36.isOnOrAfter((org.jfree.data.time.SerialDate)var40);
    boolean var43 = var33.isBefore((org.jfree.data.time.SerialDate)var40);
    boolean var44 = var26.isOn((org.jfree.data.time.SerialDate)var33);
    int var45 = var14.compare((org.jfree.data.time.SerialDate)var33);
    int var46 = var33.getYYYY();
    java.awt.Paint var47 = var7.getTickLabelPaint((java.lang.Comparable)var33);
    var0.addObject((java.lang.Object)var2, (java.lang.Comparable)"ThreadContext", (java.lang.Comparable)var33);
    org.jfree.data.KeyToGroupMap var49 = new org.jfree.data.KeyToGroupMap();
    org.jfree.chart.axis.NumberTickUnit var51 = new org.jfree.chart.axis.NumberTickUnit(0.2d);
    var49.mapKeyToGroup((java.lang.Comparable)0.2d, (java.lang.Comparable)100.0f);
    org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var59 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var60 = var57.isOnOrBefore((org.jfree.data.time.SerialDate)var59);
    boolean var61 = var55.isOnOrAfter((org.jfree.data.time.SerialDate)var59);
    org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(4);
    int var64 = var63.getYYYY();
    org.jfree.data.time.SpreadsheetDate var66 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var70 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var71 = var68.isOnOrBefore((org.jfree.data.time.SerialDate)var70);
    boolean var72 = var66.isOnOrAfter((org.jfree.data.time.SerialDate)var70);
    boolean var73 = var55.isInRange((org.jfree.data.time.SerialDate)var63, (org.jfree.data.time.SerialDate)var70);
    org.jfree.data.time.SerialDate var75 = var70.getPreviousDayOfWeek(3);
    int var76 = var49.getGroupIndex((java.lang.Comparable)var75);
    int var77 = var0.getColumnIndex((java.lang.Comparable)var76);
    java.util.List var78 = var0.getColumnKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test177"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test178"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    int var5 = var4.getAlpha();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var10, var11, var12);
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var15 = var14.getLabelOutlinePaint();
    var13.setRangeCrosshairPaint(var15);
    int var17 = var13.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var18 = new org.jfree.chart.axis.AxisSpace();
    var13.setFixedRangeAxisSpace(var18);
    org.jfree.chart.axis.AxisSpace var20 = new org.jfree.chart.axis.AxisSpace();
    var13.setFixedRangeAxisSpace(var20);
    var13.setRangeCrosshairValue(4.0d);
    org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var25 = null;
    var24.setLabelOutlinePaint(var25);
    java.awt.Stroke var27 = var24.getLabelOutlineStroke();
    java.awt.Paint var28 = var24.getLabelPaint();
    org.jfree.data.general.WaferMapDataset var29 = null;
    org.jfree.chart.renderer.WaferMapRenderer var30 = null;
    org.jfree.chart.plot.WaferMapPlot var31 = new org.jfree.chart.plot.WaferMapPlot(var29, var30);
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var31);
    java.awt.Stroke var33 = var31.getOutlineStroke();
    var24.setBaseSectionOutlineStroke(var33);
    var13.setDomainGridlineStroke(var33);
    org.jfree.chart.plot.CategoryMarker var36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)(short)0, (java.awt.Paint)var4, var33);
    var36.setKey((java.lang.Comparable)8.05d);
    org.jfree.chart.axis.SegmentedTimeline var42 = new org.jfree.chart.axis.SegmentedTimeline((-1L), 13, 0);
    org.jfree.chart.axis.SegmentedTimeline.Segment var44 = var42.getSegment(100L);
    org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var52 = var49.isOnOrBefore((org.jfree.data.time.SerialDate)var51);
    boolean var53 = var47.isOnOrAfter((org.jfree.data.time.SerialDate)var51);
    org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(4);
    int var56 = var55.getYYYY();
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var62 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var63 = var60.isOnOrBefore((org.jfree.data.time.SerialDate)var62);
    boolean var64 = var58.isOnOrAfter((org.jfree.data.time.SerialDate)var62);
    boolean var65 = var47.isInRange((org.jfree.data.time.SerialDate)var55, (org.jfree.data.time.SerialDate)var62);
    org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var47);
    java.util.Date var67 = var47.toDate();
    boolean var68 = var42.containsDomainValue(var67);
    org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.createInstance(var67);
    var36.setKey((java.lang.Comparable)var69);
    java.lang.String var71 = var36.getLabel();
    var36.setDrawAsLine(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test179"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    java.lang.String var16 = var7.getPlotType();
    java.awt.Paint var17 = var7.getDomainGridlinePaint();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    var20.setUpperMargin(0.0d);
    var7.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var20, true);
    org.jfree.data.xy.XYDataset var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
    org.jfree.chart.util.Layer var31 = null;
    java.util.Collection var32 = var29.getRangeMarkers(0, var31);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    java.awt.geom.Point2D var36 = null;
    var29.zoomDomainAxes(2.0d, 1.0d, var35, var36);
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var42.zoomDomainAxes((-1.0d), 0.2d, var45, var46);
    java.awt.Paint var48 = var42.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var50 = var42.getRangeAxisLocation(1);
    java.lang.Object var51 = null;
    boolean var52 = var50.equals(var51);
    var29.setDomainAxisLocation(var50);
    java.awt.Graphics2D var54 = null;
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    var56.setUpperMargin(0.0d);
    var56.setInverted(true);
    boolean var61 = var56.isVerticalTickLabels();
    var56.configure();
    boolean var63 = var56.isTickLabelsVisible();
    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var65 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var66 = var65.getItemMargin();
    org.jfree.chart.LegendItem var69 = var65.getLegendItem(100, 0);
    var65.setItemMargin(1.0d);
    double var72 = var65.getItemMargin();
    org.jfree.chart.plot.PiePlot var73 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var74 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var75 = var74.getChartArea();
    var73.setLegendItemShape((java.awt.Shape)var75);
    var65.setBaseShape((java.awt.Shape)var75);
    org.jfree.chart.entity.LegendItemEntity var78 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var75);
    org.jfree.chart.block.BlockContainer var79 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var80 = var79.clone();
    org.jfree.chart.title.TextTitle var81 = new org.jfree.chart.title.TextTitle();
    java.lang.String var82 = var81.getToolTipText();
    var79.add((org.jfree.chart.block.Block)var81);
    org.jfree.chart.util.RectangleEdge var84 = var81.getPosition();
    double var85 = var56.lengthToJava2D(8.05d, var75, var84);
    org.jfree.data.KeyedObjects2D var86 = new org.jfree.data.KeyedObjects2D();
    int var88 = var86.getColumnIndex((java.lang.Comparable)"February");
    java.util.List var89 = var86.getColumnKeys();
    var29.drawDomainTickBands(var54, var75, var89);
    org.jfree.chart.entity.AxisLabelEntity var93 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var20, (java.awt.Shape)var75, "RectangleConstraintType.RANGE", "ChartChangeEventType.GENERAL");
    java.awt.Paint var94 = var20.getAxisLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Category Plot"+ "'", var16.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test180"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getMargin();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.setTitle("ThreadContext");
    java.awt.Color var11 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var12 = var11.darker();
    var5.setBorderPaint((java.awt.Paint)var12);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var18 = var17.getLabelInsets();
    double var20 = var18.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var21 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var22 = var21.getChartArea();
    java.awt.geom.Rectangle2D var25 = var18.createInsetRectangle(var22, true, false);
    java.lang.Object var27 = var14.draw(var15, var22, (java.lang.Object)"WMAP_Plot");
    var5.addSubtitle((org.jfree.chart.title.Title)var14);
    var0.add((org.jfree.chart.block.Block)var14);
    org.jfree.chart.block.Arrangement var30 = var0.getArrangement();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var32 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var31);
    org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var40 = var37.isOnOrBefore((org.jfree.data.time.SerialDate)var39);
    boolean var41 = var35.isOnOrAfter((org.jfree.data.time.SerialDate)var39);
    org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
    int var44 = var43.getYYYY();
    org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var51 = var48.isOnOrBefore((org.jfree.data.time.SerialDate)var50);
    boolean var52 = var46.isOnOrAfter((org.jfree.data.time.SerialDate)var50);
    boolean var53 = var35.isInRange((org.jfree.data.time.SerialDate)var43, (org.jfree.data.time.SerialDate)var50);
    org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var35);
    java.lang.String var55 = var54.getDescription();
    org.jfree.chart.title.LegendItemBlockContainer var56 = new org.jfree.chart.title.LegendItemBlockContainer(var30, (org.jfree.data.general.Dataset)var31, (java.lang.Comparable)var54);
    var56.setToolTipText("Multiple Pie Plot");
    java.lang.String var59 = var56.getURLText();
    java.lang.String var60 = var56.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test181"); }
// 
// 
//     org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var1 = null;
//     var0.setLabelOutlinePaint(var1);
//     java.awt.Stroke var3 = var0.getLabelOutlineStroke();
//     double var4 = var0.getShadowYOffset();
//     java.text.DateFormat var7 = null;
//     org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var7);
//     java.lang.String var10 = var8.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var18 = var15.isOnOrBefore((org.jfree.data.time.SerialDate)var17);
//     boolean var19 = var13.isOnOrAfter((org.jfree.data.time.SerialDate)var17);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var22 = var21.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var29 = var26.isOnOrBefore((org.jfree.data.time.SerialDate)var28);
//     boolean var30 = var24.isOnOrAfter((org.jfree.data.time.SerialDate)var28);
//     boolean var31 = var13.isInRange((org.jfree.data.time.SerialDate)var21, (org.jfree.data.time.SerialDate)var28);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var13);
//     java.util.Date var33 = var13.toDate();
//     java.util.Date var34 = var8.rollDate(var33);
//     int var35 = var8.getUnit();
//     int var36 = var8.getRollUnit();
//     java.awt.Paint var37 = var0.getSectionOutlinePaint((java.lang.Comparable)var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "12/31/69"+ "'", var10.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test182"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Comparable var1 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var4 = var3.clone();
//     java.awt.Paint var5 = var3.getBasePaint();
//     boolean var6 = var3.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
//     java.awt.Font var11 = null;
//     var3.setSeriesItemLabelFont(0, var11, true);
//     java.awt.Font var14 = var3.getBaseItemLabelFont();
//     boolean var15 = var2.equals((java.lang.Object)var3);
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var17 = null;
//     var16.setLabelOutlinePaint(var17);
//     java.awt.Stroke var19 = var16.getLabelOutlineStroke();
//     java.awt.Paint var20 = var16.getLabelPaint();
//     var16.setIgnoreZeroValues(true);
//     boolean var23 = var2.equals((java.lang.Object)true);
//     java.text.DateFormat var24 = null;
//     var2.setDateFormatOverride(var24);
//     org.jfree.chart.axis.DateTickMarkPosition var26 = var2.getTickMarkPosition();
//     java.awt.Font var27 = var2.getTickLabelFont();
//     java.text.DateFormat var30 = null;
//     org.jfree.chart.axis.DateTickUnit var31 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var30);
//     java.lang.String var33 = var31.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var41 = var38.isOnOrBefore((org.jfree.data.time.SerialDate)var40);
//     boolean var42 = var36.isOnOrAfter((org.jfree.data.time.SerialDate)var40);
//     org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var45 = var44.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var52 = var49.isOnOrBefore((org.jfree.data.time.SerialDate)var51);
//     boolean var53 = var47.isOnOrAfter((org.jfree.data.time.SerialDate)var51);
//     boolean var54 = var36.isInRange((org.jfree.data.time.SerialDate)var44, (org.jfree.data.time.SerialDate)var51);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var36);
//     java.util.Date var56 = var36.toDate();
//     java.util.Date var57 = var31.rollDate(var56);
//     int var58 = var31.getUnit();
//     java.lang.String var59 = var31.toString();
//     java.lang.String var61 = var31.valueToString(1.0d);
//     var2.setTickUnit(var31, false, true);
//     java.lang.Number var65 = var0.getStdDevValue(var1, (java.lang.Comparable)false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "12/31/69"+ "'", var33.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + "DateTickUnit[MONTH, 1900]"+ "'", var59.equals("DateTickUnit[MONTH, 1900]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var61 + "' != '" + "12/31/69"+ "'", var61.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var65);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test183"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var5, var6, var7);
    java.lang.Number var11 = var1.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
    org.jfree.data.Range var12 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.renderer.AreaRendererEndType var13 = var0.getEndType();
    java.lang.String var14 = var13.toString();
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers(0, var21);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.data.Range var24 = var19.getDataRange(var23);
    var19.clearDomainMarkers();
    org.jfree.data.general.WaferMapDataset var26 = null;
    org.jfree.chart.renderer.WaferMapRenderer var27 = null;
    org.jfree.chart.plot.WaferMapPlot var28 = new org.jfree.chart.plot.WaferMapPlot(var26, var27);
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var28);
    java.awt.Stroke var30 = var29.getBorderStroke();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var37 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var38 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var39 = var38.clone();
    java.awt.Paint var40 = var38.getBasePaint();
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var37, var40);
    var31.setSeriesOutlinePaint(0, var40, true);
    java.awt.Stroke var45 = var31.lookupSeriesOutlineStroke(10);
    var29.setBorderStroke(var45);
    var19.setRangeZeroBaselineStroke(var45);
    boolean var48 = var13.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "AreaRendererEndType.TAPER"+ "'", var14.equals("AreaRendererEndType.TAPER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test184"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var6 = var3.isOnOrBefore((org.jfree.data.time.SerialDate)var5);
//     boolean var7 = var1.isOnOrAfter((org.jfree.data.time.SerialDate)var5);
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var10 = var9.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var17 = var14.isOnOrBefore((org.jfree.data.time.SerialDate)var16);
//     boolean var18 = var12.isOnOrAfter((org.jfree.data.time.SerialDate)var16);
//     boolean var19 = var1.isInRange((org.jfree.data.time.SerialDate)var9, (org.jfree.data.time.SerialDate)var16);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var26 = var23.isOnOrBefore((org.jfree.data.time.SerialDate)var25);
//     boolean var27 = var21.isOnOrAfter((org.jfree.data.time.SerialDate)var25);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var30 = var29.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var37 = var34.isOnOrBefore((org.jfree.data.time.SerialDate)var36);
//     boolean var38 = var32.isOnOrAfter((org.jfree.data.time.SerialDate)var36);
//     boolean var39 = var21.isInRange((org.jfree.data.time.SerialDate)var29, (org.jfree.data.time.SerialDate)var36);
//     org.jfree.data.time.SerialDate var41 = var36.getPreviousDayOfWeek(3);
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var50 = var47.isOnOrBefore((org.jfree.data.time.SerialDate)var49);
//     boolean var51 = var45.isOnOrAfter((org.jfree.data.time.SerialDate)var49);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var54 = var53.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var61 = var58.isOnOrBefore((org.jfree.data.time.SerialDate)var60);
//     boolean var62 = var56.isOnOrAfter((org.jfree.data.time.SerialDate)var60);
//     boolean var63 = var45.isInRange((org.jfree.data.time.SerialDate)var53, (org.jfree.data.time.SerialDate)var60);
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var45);
//     java.util.Date var65 = var45.toDate();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addMonths(4, (org.jfree.data.time.SerialDate)var45);
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var69 = var68.getYYYY();
//     java.util.Date var70 = var68.toDate();
//     boolean var71 = var36.isInRange(var66, (org.jfree.data.time.SerialDate)var68);
//     org.jfree.data.time.SerialDate var72 = null;
//     boolean var73 = var9.isInRange((org.jfree.data.time.SerialDate)var36, var72);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test185"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var4.zoomDomainAxes((-1.0d), 0.2d, var7, var8);
    java.awt.Paint var10 = var4.getRangeCrosshairPaint();
    double var11 = var4.getDomainCrosshairValue();
    var4.setRangeZeroBaselineVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    var4.setRenderer(var14);
    org.jfree.chart.axis.ValueAxis var17 = var4.getDomainAxis(10);
    org.jfree.chart.plot.DatasetRenderingOrder var18 = var4.getDatasetRenderingOrder();
    org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
    java.lang.String var20 = var19.getToolTipText();
    org.jfree.data.general.WaferMapDataset var21 = null;
    org.jfree.chart.renderer.WaferMapRenderer var22 = null;
    org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot(var21, var22);
    org.jfree.chart.JFreeChart var24 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    java.awt.Image var25 = null;
    var24.setBackgroundImage(var25);
    org.jfree.chart.title.TextTitle var27 = null;
    var24.setTitle(var27);
    var24.setAntiAlias(false);
    float var31 = var24.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var32 = var24.getLegend();
    java.awt.Paint var33 = var32.getBackgroundPaint();
    var32.setMargin(10.0d, 0.2d, 1.0E-5d, (-1.0d));
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var41 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var42 = var41.clone();
    java.awt.Paint var43 = var41.getBasePaint();
    boolean var44 = var41.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var47 = var41.getURLGenerator(100, 4);
    java.awt.Font var49 = null;
    var41.setSeriesItemLabelFont(0, var49, true);
    java.awt.Font var52 = var41.getBaseItemLabelFont();
    java.awt.Color var56 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var57 = org.jfree.chart.text.TextUtilities.createTextBlock("", var52, (java.awt.Paint)var56);
    org.jfree.chart.plot.PiePlot var58 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var60 = var58.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var61 = var58.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("hi!", var52, (org.jfree.chart.plot.Plot)var58, false);
    var32.setItemFont(var52);
    var19.setFont(var52);
    boolean var66 = var18.equals((java.lang.Object)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test186"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
    var0.setItemMargin(1.0d);
    double var7 = var0.getItemMargin();
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    var8.setLegendItemShape((java.awt.Shape)var10);
    var0.setBaseShape((java.awt.Shape)var10);
    org.jfree.chart.entity.LegendItemEntity var13 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var10);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var16 = var15.getCategoryLabelPositionOffset();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    org.jfree.chart.title.LegendGraphic var18 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var10, var17);
    org.jfree.chart.util.RectangleAnchor var19 = var18.getShapeLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test187"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    var4.setRangeCrosshairValue(1.0d);
    boolean var7 = var4.isDomainCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test188"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    var0.setFillBox(false);
    var0.setItemMargin(2.0d);
    java.awt.Paint var5 = var0.getArtifactPaint();
    java.awt.Paint var6 = var0.getArtifactPaint();
    var0.setItemMargin(1.05d);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    double var15 = var14.getDomainCrosshairValue();
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var18 = null;
    var17.setLabelOutlinePaint(var18);
    java.awt.Stroke var20 = var17.getLabelOutlineStroke();
    java.awt.Paint var21 = var17.getLabelPaint();
    org.jfree.chart.JFreeChart var22 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var17);
    double var23 = var17.getLabelGap();
    org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var25 = var24.getURLGenerator();
    java.awt.Color var30 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var24.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var30);
    java.awt.color.ColorSpace var32 = var30.getColorSpace();
    var17.setShadowPaint((java.awt.Paint)var30);
    var14.setRangeGridlinePaint((java.awt.Paint)var30);
    var0.setSeriesOutlinePaint(0, (java.awt.Paint)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test189"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.time.SimpleTimePeriod var3 = new org.jfree.data.time.SimpleTimePeriod((-1L), 10L);
    java.util.Date var4 = var3.getStart();
    java.lang.Number var6 = var0.getMeanValue((java.lang.Comparable)var3, (java.lang.Comparable)"AxisLocation.BOTTOM_OR_RIGHT");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.getMeanValue((-622), (-2097352));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test190"); }


    org.jfree.chart.renderer.category.LevelRenderer var0 = new org.jfree.chart.renderer.category.LevelRenderer();
    double var1 = var0.getItemMargin();
    double var2 = var0.getItemMargin();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var0.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test191"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(true);
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    java.awt.Paint var13 = var7.getRangeCrosshairPaint();
    double var14 = var7.getDomainCrosshairValue();
    var7.setRangeZeroBaselineVisible(true);
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var18 = var17.getLabelOutlinePaint();
    var7.setRangeTickBandPaint(var18);
    java.awt.Paint var20 = var7.getDomainCrosshairPaint();
    var1.setSeriesOutlinePaint(1900, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test192"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setXOffset(100.0d);
    java.awt.Paint var3 = var0.getWallPaint();
    java.lang.Number var4 = null;
    org.jfree.data.DefaultKeyedValues2D var12 = new org.jfree.data.DefaultKeyedValues2D();
    var12.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var17 = null;
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var25 = var22.isOnOrBefore((org.jfree.data.time.SerialDate)var24);
    boolean var26 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var24);
    org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
    int var29 = var28.getYYYY();
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var36 = var33.isOnOrBefore((org.jfree.data.time.SerialDate)var35);
    boolean var37 = var31.isOnOrAfter((org.jfree.data.time.SerialDate)var35);
    boolean var38 = var20.isInRange((org.jfree.data.time.SerialDate)var28, (org.jfree.data.time.SerialDate)var35);
    var12.addValue(var17, (java.lang.Comparable)' ', (java.lang.Comparable)var20);
    java.util.List var40 = var12.getRowKeys();
    org.jfree.data.statistics.BoxAndWhiskerItem var41 = new org.jfree.data.statistics.BoxAndWhiskerItem(var4, (java.lang.Number)1900, (java.lang.Number)(short)100, (java.lang.Number)Double.NaN, (java.lang.Number)10L, (java.lang.Number)2, (java.lang.Number)(short)1, (java.lang.Number)(byte)1, var40);
    java.lang.Number var42 = var41.getMinRegularValue();
    boolean var43 = var0.equals((java.lang.Object)var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + 10L+ "'", var42.equals(10L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test193"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    java.awt.Font var16 = var7.getNoDataMessageFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test194"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var15 = var14.getNumberFormatOverride();
    org.jfree.data.Range var18 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
    var14.setRangeWithMargins((org.jfree.data.Range)var19);
    org.jfree.data.Range var23 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange(var23);
    var14.setDefaultAutoRange(var23);
    java.awt.Paint var26 = var14.getTickLabelPaint();
    boolean var27 = var14.getAutoRangeIncludesZero();
    java.lang.Object var28 = var14.clone();
    int var29 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
    java.awt.Paint var30 = var4.getOutlinePaint();
    org.jfree.chart.plot.Marker var32 = null;
    org.jfree.chart.util.Layer var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker((-1), var32, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test195"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var4.zoomDomainAxes(2.0d, 1.0d, var10, var11);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var17.zoomDomainAxes((-1.0d), 0.2d, var20, var21);
    java.awt.Paint var23 = var17.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var25 = var17.getRangeAxisLocation(1);
    java.lang.Object var26 = null;
    boolean var27 = var25.equals(var26);
    var4.setDomainAxisLocation(var25);
    java.lang.String var29 = var4.getPlotType();
    var4.setDomainCrosshairLockedOnData(false);
    org.jfree.data.xy.XYDataset var32 = null;
    int var33 = var4.indexOf(var32);
    var4.setOutlineVisible(false);
    var4.clearRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "XY Plot"+ "'", var29.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test196"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getObjectIcon();
    boolean var2 = var0.isDrawLines();
    java.awt.Shape var5 = var0.getItemShape(1900, 31);
    org.jfree.chart.entity.TickLabelEntity var8 = new org.jfree.chart.entity.TickLabelEntity(var5, "RangeType.FULL", "");
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var9.getBaseItemLabelGenerator();
    java.lang.Boolean var12 = var9.getSeriesVisibleInLegend(4);
    java.awt.Paint var13 = var9.getBasePaint();
    int var14 = var9.getRowCount();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Color var20 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var16.setBaseFillPaint((java.awt.Paint)var20);
    var9.setSeriesItemLabelPaint(1, (java.awt.Paint)var20);
    org.jfree.chart.title.LegendGraphic var23 = new org.jfree.chart.title.LegendGraphic(var5, (java.awt.Paint)var20);
    org.jfree.chart.util.RectangleInsets var24 = var23.getPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test197"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var15 = var14.getNumberFormatOverride();
    org.jfree.data.Range var18 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var19 = new org.jfree.data.time.DateRange(var18);
    var14.setRangeWithMargins((org.jfree.data.Range)var19);
    org.jfree.data.Range var23 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var24 = new org.jfree.data.time.DateRange(var23);
    var14.setDefaultAutoRange(var23);
    java.awt.Paint var26 = var14.getTickLabelPaint();
    boolean var27 = var14.getAutoRangeIncludesZero();
    java.lang.Object var28 = var14.clone();
    int var29 = var4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var14);
    boolean var30 = var4.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.AxisLocation var32 = var4.getRangeAxisLocation(1900);
    java.awt.Paint var33 = var4.getRangeCrosshairPaint();
    java.awt.Paint var34 = var4.getDomainTickBandPaint();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var37 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var38 = var37.clone();
    java.awt.Paint var39 = var37.getBasePaint();
    boolean var40 = var37.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var43 = var37.getURLGenerator(100, 4);
    java.awt.Font var45 = null;
    var37.setSeriesItemLabelFont(0, var45, true);
    java.awt.Font var48 = var37.getBaseItemLabelFont();
    java.awt.Color var52 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("", var48, (java.awt.Paint)var52);
    org.jfree.chart.plot.PiePlot var54 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var56 = var54.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var57 = var54.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart("hi!", var48, (org.jfree.chart.plot.Plot)var54, false);
    java.awt.Paint var60 = var59.getBorderPaint();
    var4.setDomainCrosshairPaint(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test198"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition((-1));
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.util.StandardGradientPaintTransformer var5 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var5);
    org.jfree.chart.util.GradientPaintTransformType var7 = var5.getType();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var12.getRangeMarkers(0, var14);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var12.zoomDomainAxes(2.0d, 1.0d, var18, var19);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Color var25 = java.awt.Color.getHSBColor(100.0f, 0.0f, 0.0f);
    var21.setBaseFillPaint((java.awt.Paint)var25);
    var12.setDomainGridlinePaint((java.awt.Paint)var25);
    org.jfree.data.xy.XYDataset var28 = null;
    var12.setDataset(var28);
    double var30 = var12.getRangeCrosshairValue();
    boolean var31 = var12.isRangeCrosshairLockedOnData();
    float var32 = var12.getBackgroundImageAlpha();
    boolean var33 = var7.equals((java.lang.Object)var12);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var34 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var37 = var34.isItemLabelVisible(1, 0);
    double var38 = var34.getBase();
    boolean var39 = var34.getBaseCreateEntities();
    boolean var40 = var7.equals((java.lang.Object)var39);
    java.lang.String var41 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var41.equals("GradientPaintTransformType.VERTICAL"));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test199"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, var5, var6, var7);
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var10 = var9.getLabelOutlinePaint();
    var8.setRangeCrosshairPaint(var10);
    int var12 = var8.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var13 = new org.jfree.chart.axis.AxisSpace();
    var8.setFixedRangeAxisSpace(var13);
    org.jfree.chart.axis.AxisSpace var15 = new org.jfree.chart.axis.AxisSpace();
    var8.setFixedRangeAxisSpace(var15);
    java.lang.String var17 = var8.getPlotType();
    java.awt.Paint var18 = var8.getDomainGridlinePaint();
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var23.zoomDomainAxes((-1.0d), 0.2d, var26, var27);
    java.awt.Paint var29 = var23.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var31 = var23.getRangeAxisLocation(1);
    var8.setDomainAxisLocation(var31);
    boolean var33 = var0.equals((java.lang.Object)var8);
    org.jfree.data.general.WaferMapDataset var34 = null;
    org.jfree.chart.renderer.WaferMapRenderer var35 = null;
    org.jfree.chart.plot.WaferMapPlot var36 = new org.jfree.chart.plot.WaferMapPlot(var34, var35);
    org.jfree.chart.JFreeChart var37 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var36);
    org.jfree.chart.title.LegendTitle var38 = var37.getLegend();
    var37.setTitle("RectangleConstraintType.RANGE");
    org.jfree.chart.axis.CategoryLabelPositions var42 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
    org.jfree.chart.axis.CategoryLabelPosition var43 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var44 = var43.getWidthType();
    org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var42, var43);
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
    boolean var47 = var42.equals((java.lang.Object)var46);
    org.jfree.chart.event.PlotChangeEvent var48 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var46);
    var37.plotChanged(var48);
    var8.notifyListeners(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "Category Plot"+ "'", var17.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test200"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var6 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var8 = var7.clone();
    java.awt.Paint var9 = var7.getBasePaint();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var6, var9);
    var0.setSeriesOutlinePaint(0, var9, true);
    java.lang.Boolean var14 = var0.getSeriesShapesVisible((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test201"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("ThreadContext", "XY Plot", "XY Plot", var3, "WMAP_Plot", "April", "April");
    var7.setVersion("");
    java.lang.String var10 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "ThreadContext version .\nWMAP_Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:XY Plot\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ThreadContext:None\nThreadContext LICENCE TERMS:\nApril"+ "'", var10.equals("ThreadContext version .\nWMAP_Plot.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:XY Plot\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY ThreadContext:None\nThreadContext LICENCE TERMS:\nApril"));

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test202"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test203"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var7 = var4.isOnOrBefore((org.jfree.data.time.SerialDate)var6);
    boolean var8 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var6);
    int var9 = var0.getIndex((java.lang.Comparable)var8);
    var0.clear();
    var0.addValue((java.lang.Comparable)(short)(-1), 100.0d);
    int var15 = var0.getIndex((java.lang.Comparable)"0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test204"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var8 = var5.isOnOrBefore((org.jfree.data.time.SerialDate)var7);
    boolean var9 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
    org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
    int var12 = var11.getYYYY();
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
    boolean var20 = var14.isOnOrAfter((org.jfree.data.time.SerialDate)var18);
    boolean var21 = var3.isInRange((org.jfree.data.time.SerialDate)var11, (org.jfree.data.time.SerialDate)var18);
    boolean var22 = var0.equals((java.lang.Object)var11);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
    java.awt.Paint var29 = var28.getPaint();
    var0.setSeriesOutlinePaint(0, var29);
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var32 = null;
    var31.setLabelOutlinePaint(var32);
    java.awt.Stroke var34 = var31.getLabelOutlineStroke();
    java.awt.Paint var35 = var31.getLabelPaint();
    var0.setBasePaint(var35, false);
    java.awt.Paint var39 = var0.lookupSeriesOutlinePaint((-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test205"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.setSeriesItemLabelsVisible(4, true);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, var8, var9, var10);
    java.lang.Number var14 = var4.getMinOutlier((java.lang.Comparable)(byte)1, (java.lang.Comparable)"XY Plot");
    org.jfree.data.Range var15 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var19 = var18.getLabel();
    org.jfree.data.KeyedObject var20 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var18);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var23 = var22.getLabelInsets();
    double var25 = var23.calculateTopInset(100.0d);
    var18.setTickLabelInsets(var23);
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var31 = var30.getLabelInsets();
    double var33 = var31.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var35 = var34.getChartArea();
    java.awt.geom.Rectangle2D var38 = var31.createInsetRectangle(var35, true, false);
    java.lang.Object var40 = var27.draw(var28, var35, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.entity.AxisLabelEntity var43 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, (java.awt.Shape)var35, "XY Plot", "WMAP_Plot");
    org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var50 = var47.isOnOrBefore((org.jfree.data.time.SerialDate)var49);
    boolean var51 = var45.isOnOrAfter((org.jfree.data.time.SerialDate)var49);
    org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(4);
    int var54 = var53.getYYYY();
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var61 = var58.isOnOrBefore((org.jfree.data.time.SerialDate)var60);
    boolean var62 = var56.isOnOrAfter((org.jfree.data.time.SerialDate)var60);
    boolean var63 = var45.isInRange((org.jfree.data.time.SerialDate)var53, (org.jfree.data.time.SerialDate)var60);
    boolean var64 = var18.equals((java.lang.Object)var53);
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var67 = var66.getNumberFormatOverride();
    org.jfree.data.Range var70 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var71 = new org.jfree.data.time.DateRange(var70);
    var66.setRangeWithMargins((org.jfree.data.Range)var71);
    double var73 = var66.getLowerMargin();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var74 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var75 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var77 = var75.getSeriesNegativeItemLabelPosition((-1));
    var74.setNegativeItemLabelPositionFallback(var77);
    double var79 = var74.getLowerClip();
    org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var66, (org.jfree.chart.renderer.category.CategoryItemRenderer)var74);
    var18.setMaximumCategoryLabelWidthRatio(0.95f);
    var18.setCategoryMargin(0.35d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + ""+ "'", var19.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test206"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    var0.setFillBox(false);
    var0.setItemMargin(2.0d);
    java.awt.Paint var5 = var0.getArtifactPaint();
    java.awt.Paint var6 = var0.getArtifactPaint();
    java.awt.Paint var8 = var0.getSeriesFillPaint(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test207"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var3 = var2.clone();
    java.awt.Paint var4 = var2.getBasePaint();
    boolean var5 = var2.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var8 = var2.getURLGenerator(100, 4);
    java.awt.Font var10 = null;
    var2.setSeriesItemLabelFont(0, var10, true);
    java.awt.Font var13 = var2.getBaseItemLabelFont();
    boolean var14 = var1.equals((java.lang.Object)var2);
    java.text.DateFormat var15 = var1.getDateFormatOverride();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var18 = var17.getNumberFormatOverride();
    org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var22 = new org.jfree.data.time.DateRange(var21);
    var17.setRangeWithMargins((org.jfree.data.Range)var22);
    org.jfree.data.Range var26 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var27 = new org.jfree.data.time.DateRange(var26);
    var17.setDefaultAutoRange(var26);
    java.awt.Paint var29 = var17.getTickLabelPaint();
    org.jfree.data.Range var32 = new org.jfree.data.Range(0.0d, 0.0d);
    double var33 = var32.getUpperBound();
    double var34 = var32.getUpperBound();
    var17.setDefaultAutoRange(var32);
    var1.setRange(var32);
    org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(100.0d, var32);
    org.jfree.chart.block.LengthConstraintType var38 = var37.getHeightConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test208"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     var0.zoomRange(0.2d, 0.0d);
//     var0.setLowerMargin(10.0d);
//     org.jfree.chart.axis.DateTickUnit var8 = new org.jfree.chart.axis.DateTickUnit(4, 100);
//     org.jfree.data.Range var11 = new org.jfree.data.Range(0.0d, 0.0d);
//     org.jfree.data.time.DateRange var12 = new org.jfree.data.time.DateRange(var11);
//     java.util.Date var13 = var12.getLowerDate();
//     java.lang.String var14 = var8.dateToString(var13);
//     var0.setTickUnit(var8, true, true);
//     var0.setUpperMargin(0.2d);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.data.general.WaferMapDataset var22 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var23 = null;
//     org.jfree.chart.plot.WaferMapPlot var24 = new org.jfree.chart.plot.WaferMapPlot(var22, var23);
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     java.awt.Image var26 = null;
//     var25.setBackgroundImage(var26);
//     org.jfree.chart.title.TextTitle var28 = null;
//     var25.setTitle(var28);
//     var25.setAntiAlias(false);
//     float var32 = var25.getBackgroundImageAlpha();
//     org.jfree.chart.title.LegendTitle var33 = var25.getLegend();
//     org.jfree.chart.util.RectangleEdge var34 = var33.getLegendItemGraphicEdge();
//     double var35 = var0.valueToJava2D(16.05d, var21, var34);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test209"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.util.RectangleInsets var1 = var0.getMargin();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.setTitle("ThreadContext");
    java.awt.Color var11 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var12 = var11.darker();
    var5.setBorderPaint((java.awt.Paint)var12);
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var18 = var17.getLabelInsets();
    double var20 = var18.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var21 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var22 = var21.getChartArea();
    java.awt.geom.Rectangle2D var25 = var18.createInsetRectangle(var22, true, false);
    java.lang.Object var27 = var14.draw(var15, var22, (java.lang.Object)"WMAP_Plot");
    var5.addSubtitle((org.jfree.chart.title.Title)var14);
    var0.add((org.jfree.chart.block.Block)var14);
    org.jfree.chart.block.Arrangement var30 = var0.getArrangement();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var31 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.chart.plot.MultiplePiePlot var32 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var31);
    org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var40 = var37.isOnOrBefore((org.jfree.data.time.SerialDate)var39);
    boolean var41 = var35.isOnOrAfter((org.jfree.data.time.SerialDate)var39);
    org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
    int var44 = var43.getYYYY();
    org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var51 = var48.isOnOrBefore((org.jfree.data.time.SerialDate)var50);
    boolean var52 = var46.isOnOrAfter((org.jfree.data.time.SerialDate)var50);
    boolean var53 = var35.isInRange((org.jfree.data.time.SerialDate)var43, (org.jfree.data.time.SerialDate)var50);
    org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var35);
    java.lang.String var55 = var54.getDescription();
    org.jfree.chart.title.LegendItemBlockContainer var56 = new org.jfree.chart.title.LegendItemBlockContainer(var30, (org.jfree.data.general.Dataset)var31, (java.lang.Comparable)var54);
    var56.setToolTipText("Multiple Pie Plot");
    java.lang.String var59 = var56.getURLText();
    org.jfree.data.general.Dataset var60 = var56.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test210"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var3 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    java.awt.Paint var4 = var3.getLastBarPaint();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var5 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    boolean var6 = var3.equals((java.lang.Object)var5);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var7 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var8 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var7);
    java.awt.Paint var9 = var3.getLastBarPaint();
    var0.setSeriesItemLabelPaint(3, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test211"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("ChartEntity: tooltip = XY Plot");
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    boolean var7 = var6.isRangeCrosshairVisible();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var10 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var10, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var14, var15, var16);
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var19 = var18.getLabelOutlinePaint();
    var17.setRangeCrosshairPaint(var19);
    int var21 = var17.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
    var17.setFixedRangeAxisSpace(var22);
    org.jfree.chart.axis.AxisSpace var24 = new org.jfree.chart.axis.AxisSpace();
    var17.setFixedRangeAxisSpace(var24);
    java.lang.String var26 = var17.getPlotType();
    java.awt.Paint var27 = var17.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var30 = var29.getTickMarkStroke();
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var32 = null;
    var31.setLabelOutlinePaint(var32);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var40 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var41 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var42 = var41.clone();
    java.awt.Paint var43 = var41.getBasePaint();
    org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var40, var43);
    var34.setSeriesOutlinePaint(0, var43, true);
    var31.setBackgroundPaint(var43);
    java.awt.Stroke var48 = null;
    org.jfree.chart.plot.IntervalMarker var50 = new org.jfree.chart.plot.IntervalMarker(2.0d, 2.0d, var27, var30, var43, var48, 0.0f);
    var6.setRangeGridlinePaint(var27);
    java.awt.Paint var52 = var6.getRangeCrosshairPaint();
    boolean var53 = var1.equals((java.lang.Object)var52);
    java.beans.PropertyChangeListener var54 = null;
    var1.addPropertyChangeListener(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "Category Plot"+ "'", var26.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test212"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.lang.String var3 = var2.getLabel();
    org.jfree.data.KeyedObject var4 = new org.jfree.data.KeyedObject((java.lang.Comparable)2.0d, (java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var7 = var6.getLabelInsets();
    double var9 = var7.calculateTopInset(100.0d);
    var2.setTickLabelInsets(var7);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var15 = var14.getLabelInsets();
    double var17 = var15.calculateTopInset(100.0d);
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var19 = var18.getChartArea();
    java.awt.geom.Rectangle2D var22 = var15.createInsetRectangle(var19, true, false);
    java.lang.Object var24 = var11.draw(var12, var19, (java.lang.Object)"WMAP_Plot");
    org.jfree.chart.entity.AxisLabelEntity var27 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, (java.awt.Shape)var19, "XY Plot", "WMAP_Plot");
    java.lang.String var28 = var27.toString();
    org.jfree.chart.axis.Axis var29 = var27.getAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "ChartEntity: tooltip = XY Plot"+ "'", var28.equals("ChartEntity: tooltip = XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test213"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
    var0.setItemMargin(1.0d);
    double var7 = var0.getItemMargin();
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    var8.setLegendItemShape((java.awt.Shape)var10);
    var0.setBaseShape((java.awt.Shape)var10);
    org.jfree.chart.entity.LegendItemEntity var13 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var10);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var16 = var15.getCategoryLabelPositionOffset();
    java.awt.Paint var17 = var15.getAxisLinePaint();
    org.jfree.chart.title.LegendGraphic var18 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var10, var17);
    boolean var19 = var18.isShapeOutlineVisible();
    org.jfree.chart.axis.CategoryLabelPosition var20 = new org.jfree.chart.axis.CategoryLabelPosition();
    double var21 = var20.getAngle();
    org.jfree.chart.axis.CategoryLabelWidthType var22 = var20.getWidthType();
    org.jfree.chart.text.TextAnchor var23 = var20.getRotationAnchor();
    org.jfree.chart.util.RectangleAnchor var24 = var20.getCategoryAnchor();
    var18.setShapeAnchor(var24);
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var28 = var26.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var29 = var26.getLabelLinksVisible();
    java.awt.Paint var30 = var26.getLabelBackgroundPaint();
    org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var37 = var34.isOnOrBefore((org.jfree.data.time.SerialDate)var36);
    boolean var38 = var32.isOnOrAfter((org.jfree.data.time.SerialDate)var36);
    java.awt.Color var42 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.lang.String var43 = org.jfree.chart.util.PaintUtilities.colorToString(var42);
    var26.setSectionOutlinePaint((java.lang.Comparable)var38, (java.awt.Paint)var42);
    int var45 = var42.getTransparency();
    var18.setLinePaint((java.awt.Paint)var42);
    int var47 = var42.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "black"+ "'", var43.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-16777216));

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test214"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var10, var11, var12);
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var15 = var14.getLabelOutlinePaint();
//     var13.setRangeCrosshairPaint(var15);
//     var5.setDomainTickBandPaint(var15);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var21 = var18.isItemLabelVisible(1, 0);
//     org.jfree.data.general.WaferMapDataset var23 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var24 = null;
//     org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
//     java.awt.Stroke var27 = var26.getBorderStroke();
//     var18.setSeriesStroke(100, var27, true);
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d, var15, var27);
//     org.jfree.chart.util.LengthAdjustmentType var31 = var30.getLabelOffsetType();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var33 = var32.clone();
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var40 = var37.isOnOrBefore((org.jfree.data.time.SerialDate)var39);
//     boolean var41 = var35.isOnOrAfter((org.jfree.data.time.SerialDate)var39);
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var44 = var43.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var51 = var48.isOnOrBefore((org.jfree.data.time.SerialDate)var50);
//     boolean var52 = var46.isOnOrAfter((org.jfree.data.time.SerialDate)var50);
//     boolean var53 = var35.isInRange((org.jfree.data.time.SerialDate)var43, (org.jfree.data.time.SerialDate)var50);
//     boolean var54 = var32.equals((java.lang.Object)var43);
//     org.jfree.chart.block.BlockBorder var60 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
//     java.awt.Paint var61 = var60.getPaint();
//     var32.setSeriesOutlinePaint(0, var61);
//     var30.setPaint(var61);
//     java.lang.Class var64 = null;
//     java.util.EventListener[] var65 = var30.getListeners(var64);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test215"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    java.lang.String var16 = var7.getPlotType();
    java.awt.Paint var17 = var7.getDomainGridlinePaint();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("");
    var20.setUpperMargin(0.0d);
    var7.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var20, true);
    java.util.List var25 = var7.getAnnotations();
    java.util.Collection var26 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Category Plot"+ "'", var16.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test216"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     var7.setRenderer(var8, true);
//     java.text.DateFormat var13 = null;
//     org.jfree.chart.axis.DateTickUnit var14 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var13);
//     java.lang.String var16 = var14.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var24 = var21.isOnOrBefore((org.jfree.data.time.SerialDate)var23);
//     boolean var25 = var19.isOnOrAfter((org.jfree.data.time.SerialDate)var23);
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var28 = var27.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var35 = var32.isOnOrBefore((org.jfree.data.time.SerialDate)var34);
//     boolean var36 = var30.isOnOrAfter((org.jfree.data.time.SerialDate)var34);
//     boolean var37 = var19.isInRange((org.jfree.data.time.SerialDate)var27, (org.jfree.data.time.SerialDate)var34);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var19);
//     java.util.Date var39 = var19.toDate();
//     java.util.Date var40 = var14.rollDate(var39);
//     org.jfree.chart.plot.CategoryMarker var41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var40);
//     var7.addRangeMarker((org.jfree.chart.plot.Marker)var41);
//     org.jfree.chart.util.LengthAdjustmentType var43 = var41.getLabelOffsetType();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var47 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var48 = var47.clone();
//     java.awt.Paint var49 = var47.getBasePaint();
//     boolean var50 = var47.getBaseSeriesVisible();
//     org.jfree.chart.urls.CategoryURLGenerator var53 = var47.getURLGenerator(100, 4);
//     java.awt.Font var55 = null;
//     var47.setSeriesItemLabelFont(0, var55, true);
//     java.awt.Font var58 = var47.getBaseItemLabelFont();
//     java.awt.Color var62 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
//     org.jfree.chart.text.TextBlock var63 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, (java.awt.Paint)var62);
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var64 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
//     java.awt.Shape var70 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var71 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     java.lang.Object var72 = var71.clone();
//     java.awt.Paint var73 = var71.getBasePaint();
//     org.jfree.chart.LegendItem var74 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var70, var73);
//     var64.setSeriesOutlinePaint(0, var73, true);
//     org.jfree.chart.text.TextMeasurer var78 = null;
//     org.jfree.chart.text.TextBlock var79 = org.jfree.chart.text.TextUtilities.createTextBlock("", var58, var73, 0.0f, var78);
//     org.jfree.chart.plot.PiePlot var80 = new org.jfree.chart.plot.PiePlot();
//     java.awt.Paint var81 = null;
//     var80.setLabelOutlinePaint(var81);
//     java.awt.Stroke var83 = var80.getLabelOutlineStroke();
//     java.awt.Paint var84 = var80.getLabelPaint();
//     org.jfree.chart.text.TextLine var85 = new org.jfree.chart.text.TextLine("", var58, var84);
//     org.jfree.chart.text.TextFragment var86 = var85.getFirstTextFragment();
//     float var87 = var86.getBaselineOffset();
//     java.awt.Font var88 = var86.getFont();
//     java.awt.Paint var89 = var86.getPaint();
//     boolean var90 = var43.equals((java.lang.Object)var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "12/31/69"+ "'", var16.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 0.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == false);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test217"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
    var0.setItemMargin(1.0d);
    double var7 = var0.getItemMargin();
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.ChartRenderingInfo var9 = new org.jfree.chart.ChartRenderingInfo();
    java.awt.geom.Rectangle2D var10 = var9.getChartArea();
    var8.setLegendItemShape((java.awt.Shape)var10);
    var0.setBaseShape((java.awt.Shape)var10);
    org.jfree.chart.entity.LegendItemEntity var13 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var10);
    java.lang.Object var14 = var13.clone();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var15 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var15, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var19, var20, var21);
    java.lang.Number var25 = var15.getMinRegularValue((java.lang.Comparable)1, (java.lang.Comparable)false);
    java.lang.Number var26 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var15);
    var13.setDataset((org.jfree.data.general.Dataset)var15);
    org.jfree.data.general.Dataset var28 = var13.getDataset();
    boolean var30 = var13.equals((java.lang.Object)(-1.0f));
    java.lang.String var31 = var13.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + 0.0d+ "'", var26.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test218"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getSeriesNegativeItemLabelPosition(1900);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var0.getSeriesURLGenerator((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test219"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    double var3 = var1.getMaximumBarWidth();
    int var4 = var1.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)var1);
    java.lang.Object var6 = var0.clone();
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var8 = null;
    var7.setLabelOutlinePaint(var8);
    java.awt.Stroke var10 = var7.getLabelOutlineStroke();
    java.awt.Paint var11 = var7.getLabelPaint();
    org.jfree.data.general.DatasetChangeEvent var12 = null;
    var7.datasetChanged(var12);
    org.jfree.chart.labels.PieToolTipGenerator var14 = var7.getToolTipGenerator();
    org.jfree.data.general.PieDataset var15 = var7.getDataset();
    boolean var16 = var7.isCircular();
    boolean var17 = var0.equals((java.lang.Object)var7);
    java.awt.Stroke var18 = var7.getLabelOutlineStroke();
    double var19 = var7.getShadowXOffset();
    org.jfree.chart.labels.PieToolTipGenerator var20 = null;
    var7.setToolTipGenerator(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 4.0d);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test220"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState((-10.0d));
    var1.setMax(3.0d);
    var1.cursorRight(2.787634800486E12d);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test221"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    java.lang.Object var10 = var4.clone();
    boolean var11 = var4.isDomainGridlinesVisible();
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var4.getRangeMarkers(1900, var13);
    var4.mapDatasetToDomainAxis(3, (-509068));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test222"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.LegendItem var4 = var0.getLegendItem(100, 0);
    var0.setItemMargin(1.0d);
    var0.setItemMargin(0.05d);
    java.awt.Paint var9 = var0.getArtifactPaint();
    java.awt.Paint var12 = var0.getItemOutlinePaint(0, 31);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var15 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var16 = var15.clone();
    java.awt.Paint var17 = var15.getBasePaint();
    boolean var18 = var15.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var21 = var15.getURLGenerator(100, 4);
    java.awt.Font var23 = null;
    var15.setSeriesItemLabelFont(0, var23, true);
    java.awt.Font var26 = var15.getBaseItemLabelFont();
    boolean var27 = var14.equals((java.lang.Object)var15);
    java.text.DateFormat var28 = var14.getDateFormatOverride();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("");
    java.text.NumberFormat var31 = var30.getNumberFormatOverride();
    org.jfree.data.Range var34 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var35 = new org.jfree.data.time.DateRange(var34);
    var30.setRangeWithMargins((org.jfree.data.Range)var35);
    org.jfree.data.Range var39 = new org.jfree.data.Range(0.0d, 0.0d);
    org.jfree.data.time.DateRange var40 = new org.jfree.data.time.DateRange(var39);
    var30.setDefaultAutoRange(var39);
    java.awt.Paint var42 = var30.getTickLabelPaint();
    org.jfree.data.Range var45 = new org.jfree.data.Range(0.0d, 0.0d);
    double var46 = var45.getUpperBound();
    double var47 = var45.getUpperBound();
    var30.setDefaultAutoRange(var45);
    var14.setRange(var45);
    var14.zoomRange(0.0d, 1.0d);
    java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    org.jfree.chart.entity.AxisLabelEntity var57 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var14, var54, "AxisLocation.TOP_OR_RIGHT", "12/31/69");
    var0.setSeriesShape(3, var54, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test223"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    var11.setTitle("ThreadContext");
    java.awt.Color var17 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var18 = var17.darker();
    var11.setBorderPaint((java.awt.Paint)var18);
    var7.setRangeGridlinePaint((java.awt.Paint)var18);
    var7.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.Plot var23 = var7.getRootPlot();
    var7.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test224"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.data.Range var5 = new org.jfree.data.Range(0.0d, 0.0d);
    double var6 = var5.getLength();
    double var7 = var5.getLength();
    double var8 = var5.getCentralValue();
    var2.setRange(var5, true, true);
    boolean var12 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test225"); }


    org.jfree.chart.labels.StandardCategoryToolTipGenerator var0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var2 = var1.clone();
    double var3 = var1.getMaximumBarWidth();
    int var4 = var1.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)var1);
    java.text.NumberFormat var6 = var0.getNumberFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test226"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    var0.clear();
    org.jfree.chart.renderer.category.WaterfallBarRenderer var2 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var7.zoomDomainAxes((-1.0d), 0.2d, var10, var11);
    java.awt.Paint var13 = var7.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var14 = null;
    var7.rendererChanged(var14);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    java.awt.geom.Point2D var24 = null;
    var20.zoomDomainAxes((-1.0d), 0.2d, var23, var24);
    java.awt.Paint var26 = var20.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var28 = var20.getRangeAxisLocation(1);
    var7.setDomainAxisLocation(var28);
    java.awt.Paint var30 = var7.getDomainTickBandPaint();
    java.awt.Shape var35 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var36 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var37 = var36.clone();
    java.awt.Paint var38 = var36.getBasePaint();
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var35, var38);
    java.awt.Stroke var40 = var39.getOutlineStroke();
    int var41 = var39.getDatasetIndex();
    java.awt.Stroke var42 = var39.getOutlineStroke();
    var7.setRangeZeroBaselineStroke(var42);
    var2.setBaseOutlineStroke(var42);
    java.awt.Paint var45 = var2.getNegativeBarPaint();
    boolean var46 = var0.equals((java.lang.Object)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test227"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setXOffset(100.0d);
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var4 = var3.getLabelOutlinePaint();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var10 = var9.getLabelOutlinePaint();
    var7.setBackgroundPaint(var10);
    var3.setLabelShadowPaint(var10);
    var0.setWallPaint(var10);
    var0.setYOffset(0.0d);
    var0.setYOffset(5.0d);
    java.lang.Boolean var19 = null;
    var0.setSeriesVisible(100, var19, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test228"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(5.0d);
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
    org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition();
    double var5 = var4.getAngle();
    org.jfree.chart.axis.CategoryLabelWidthType var6 = var4.getWidthType();
    org.jfree.chart.axis.CategoryLabelPositions var7 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var3, var4);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var14 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var16 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var14, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var14, var18, var19, var20);
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var23 = var22.getLabelOutlinePaint();
    var21.setRangeCrosshairPaint(var23);
    var13.setDomainTickBandPaint(var23);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var29 = var26.isItemLabelVisible(1, 0);
    org.jfree.data.general.WaferMapDataset var31 = null;
    org.jfree.chart.renderer.WaferMapRenderer var32 = null;
    org.jfree.chart.plot.WaferMapPlot var33 = new org.jfree.chart.plot.WaferMapPlot(var31, var32);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    java.awt.Stroke var35 = var34.getBorderStroke();
    var26.setSeriesStroke(100, var35, true);
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(0.0d, var23, var35);
    org.jfree.chart.util.LengthAdjustmentType var39 = var38.getLabelOffsetType();
    org.jfree.chart.util.LengthAdjustmentType var40 = var38.getLabelOffsetType();
    boolean var41 = var7.equals((java.lang.Object)var38);
    org.jfree.chart.axis.CategoryLabelPositions var43 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(4.0d);
    org.jfree.chart.axis.CategoryLabelPosition var44 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelWidthType var45 = var44.getWidthType();
    org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var43, var44);
    double var47 = var44.getAngle();
    org.jfree.chart.axis.CategoryLabelPositions var48 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var7, var44);
    org.jfree.chart.axis.CategoryLabelPositions var49 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test229"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)"February");
    java.util.List var3 = var0.getColumnKeys();
    var0.removeObject((java.lang.Comparable)0.0d, (java.lang.Comparable)"RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var8 = var7.clone();
    org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var15 = var12.isOnOrBefore((org.jfree.data.time.SerialDate)var14);
    boolean var16 = var10.isOnOrAfter((org.jfree.data.time.SerialDate)var14);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    int var19 = var18.getYYYY();
    org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var26 = var23.isOnOrBefore((org.jfree.data.time.SerialDate)var25);
    boolean var27 = var21.isOnOrAfter((org.jfree.data.time.SerialDate)var25);
    boolean var28 = var10.isInRange((org.jfree.data.time.SerialDate)var18, (org.jfree.data.time.SerialDate)var25);
    boolean var29 = var7.equals((java.lang.Object)var18);
    java.lang.Comparable var31 = null;
    var0.setObject((java.lang.Object)var29, (java.lang.Comparable)100.0d, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var34 = var0.getColumnKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test230"); }


    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var2 = null;
    var1.setLabelOutlinePaint(var2);
    java.awt.Stroke var4 = var1.getLabelOutlineStroke();
    java.awt.Paint var5 = var1.getLabelPaint();
    org.jfree.chart.JFreeChart var6 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    double var7 = var1.getLabelGap();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var8 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var9 = var8.clone();
    java.awt.Paint var10 = var8.getBasePaint();
    var1.setLabelPaint(var10);
    java.awt.Shape var16 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var17 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var18 = var17.clone();
    java.awt.Paint var19 = var17.getBasePaint();
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var16, var19);
    java.awt.Stroke var21 = var20.getOutlineStroke();
    int var22 = var20.getDatasetIndex();
    java.text.AttributedString var23 = var20.getAttributedLabel();
    boolean var24 = var20.isShapeVisible();
    org.jfree.chart.util.GradientPaintTransformer var25 = var20.getFillPaintTransformer();
    java.awt.Stroke var26 = var20.getLineStroke();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.util.RectangleInsets var29 = var28.getLabelInsets();
    org.jfree.data.general.SeriesChangeEvent var30 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var29);
    double var32 = var29.calculateBottomInset(8.0d);
    org.jfree.chart.block.LineBorder var33 = new org.jfree.chart.block.LineBorder(var10, var26, var29);
    java.awt.Paint var34 = var33.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test231"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var6 = null;
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var4, var5, var6);
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var9 = var8.getLabelOutlinePaint();
    var7.setRangeCrosshairPaint(var9);
    int var11 = var7.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var12);
    org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
    var7.setFixedRangeAxisSpace(var14);
    java.lang.String var16 = var7.getPlotType();
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    java.awt.geom.Point2D var25 = null;
    var21.zoomDomainAxes((-1.0d), 0.2d, var24, var25);
    java.awt.Paint var27 = var21.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var29 = var21.getRangeAxisLocation(1);
    var7.setDomainAxisLocation(var29, false);
    var7.clearDomainMarkers(10);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var35 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var37 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var35, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var35, var39, var40, var41);
    org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var44 = var43.getLabelOutlinePaint();
    var42.setRangeCrosshairPaint(var44);
    int var46 = var42.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var47 = new org.jfree.chart.axis.AxisSpace();
    var42.setFixedRangeAxisSpace(var47);
    org.jfree.chart.axis.AxisSpace var49 = new org.jfree.chart.axis.AxisSpace();
    var42.setFixedRangeAxisSpace(var49);
    java.lang.String var51 = var42.getPlotType();
    boolean var52 = var42.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("");
    var54.setUpperMargin(0.0d);
    var54.setInverted(true);
    boolean var59 = var54.isVerticalTickLabels();
    var54.configure();
    var42.setRangeAxis((org.jfree.chart.axis.ValueAxis)var54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setRangeAxis((-453), (org.jfree.chart.axis.ValueAxis)var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "Category Plot"+ "'", var16.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "Category Plot"+ "'", var51.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test232"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline((-2208787199289L), (-16777216), 28);
    java.util.Date var5 = var3.getDate((-13L));
    java.lang.Object var6 = var3.clone();
    org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var11 = var8.isOnOrBefore((org.jfree.data.time.SerialDate)var10);
    org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(4);
    int var14 = var13.getYYYY();
    int var15 = var8.compare((org.jfree.data.time.SerialDate)var13);
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var21 = var18.isOnOrBefore((org.jfree.data.time.SerialDate)var20);
    int var22 = var20.getDayOfMonth();
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var29 = var26.isOnOrBefore((org.jfree.data.time.SerialDate)var28);
    boolean var30 = var24.isOnOrAfter((org.jfree.data.time.SerialDate)var28);
    org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(4);
    int var33 = var32.getYYYY();
    org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var40 = var37.isOnOrBefore((org.jfree.data.time.SerialDate)var39);
    boolean var41 = var35.isOnOrAfter((org.jfree.data.time.SerialDate)var39);
    boolean var42 = var24.isInRange((org.jfree.data.time.SerialDate)var32, (org.jfree.data.time.SerialDate)var39);
    org.jfree.data.time.SpreadsheetDate var44 = new org.jfree.data.time.SpreadsheetDate(4);
    int var45 = var44.getDayOfMonth();
    boolean var46 = var32.isOn((org.jfree.data.time.SerialDate)var44);
    boolean var47 = var20.isOnOrAfter((org.jfree.data.time.SerialDate)var44);
    org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate)var44);
    org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var54 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var57 = var54.isOnOrBefore((org.jfree.data.time.SerialDate)var56);
    boolean var58 = var52.isOnOrAfter((org.jfree.data.time.SerialDate)var56);
    org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(4);
    int var61 = var60.getYYYY();
    org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var65 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var67 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var68 = var65.isOnOrBefore((org.jfree.data.time.SerialDate)var67);
    boolean var69 = var63.isOnOrAfter((org.jfree.data.time.SerialDate)var67);
    boolean var70 = var52.isInRange((org.jfree.data.time.SerialDate)var60, (org.jfree.data.time.SerialDate)var67);
    org.jfree.data.time.SerialDate var71 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var52);
    org.jfree.data.time.SerialDate var72 = org.jfree.data.time.SerialDate.addYears(1, (org.jfree.data.time.SerialDate)var52);
    boolean var73 = var13.isInRange(var48, (org.jfree.data.time.SerialDate)var52);
    boolean var74 = var3.equals((java.lang.Object)var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var76 = var48.getNearestDayOfWeek(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test233"); }


    org.jfree.chart.renderer.category.GanttRenderer var0 = new org.jfree.chart.renderer.category.GanttRenderer();
    var0.setEndPercent(2.0d);
    java.awt.Paint var3 = var0.getIncompletePaint();
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var6 = var4.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var7 = var4.getLabelLinksVisible();
    java.awt.Paint var8 = var4.getLabelBackgroundPaint();
    boolean var9 = var0.equals((java.lang.Object)var8);
    org.jfree.chart.renderer.category.LineRenderer3D var10 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var10.setXOffset(100.0d);
    java.awt.Paint var13 = var10.getWallPaint();
    var0.setIncompletePaint(var13);
    java.awt.Stroke var16 = var0.lookupSeriesStroke(3);
    double var17 = var0.getEndPercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0d);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test234"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.2d, 3.0d);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var7 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var8 = var7.clone();
    java.awt.Paint var9 = var7.getBasePaint();
    boolean var10 = var7.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var13 = var7.getURLGenerator(100, 4);
    java.awt.Font var15 = null;
    var7.setSeriesItemLabelFont(0, var15, true);
    java.awt.Font var18 = var7.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var19 = new org.jfree.chart.block.LabelBlock("January", var18);
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle("hi!", var18);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var25.zoomDomainAxes((-1.0d), 0.2d, var28, var29);
    java.awt.Paint var31 = var25.getRangeCrosshairPaint();
    double var32 = var25.getDomainCrosshairValue();
    var25.setRangeZeroBaselineVisible(true);
    java.awt.Stroke var35 = var25.getRangeGridlineStroke();
    java.lang.String var36 = var25.getPlotType();
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
    org.jfree.chart.util.Layer var43 = null;
    java.util.Collection var44 = var41.getRangeMarkers(0, var43);
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("");
    var46.setUpperMargin(0.0d);
    var46.setInverted(true);
    boolean var51 = var46.isVerticalTickLabels();
    double var52 = var46.getFixedAutoRange();
    org.jfree.data.Range var53 = var41.getDataRange((org.jfree.chart.axis.ValueAxis)var46);
    org.jfree.data.Range var54 = var25.getDataRange((org.jfree.chart.axis.ValueAxis)var46);
    java.awt.Shape var55 = var46.getUpArrow();
    org.jfree.chart.axis.TickUnitSource var56 = var46.getStandardTickUnits();
    var4.add((org.jfree.chart.block.Block)var20, (java.lang.Object)var56);
    boolean var59 = var4.equals((java.lang.Object)2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "XY Plot"+ "'", var36.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test235"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var4.getRangeMarkers(var8);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var11 = var10.clone();
    java.awt.Paint var12 = var10.getBasePaint();
    boolean var13 = var10.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var16 = var10.getURLGenerator(100, 4);
    java.awt.Font var18 = null;
    var10.setSeriesItemLabelFont(0, var18, true);
    java.awt.Paint var21 = var10.getBasePaint();
    var4.setDomainGridlinePaint(var21);
    int var23 = var4.getWeight();
    java.awt.Stroke var24 = var4.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test236"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isRangeCrosshairVisible();
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var8 = var7.getTickMarkStroke();
    var4.setDomainCrosshairStroke(var8);
    int var10 = var4.getDomainAxisCount();
    org.jfree.chart.plot.Plot var11 = var4.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test237"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    boolean var3 = var0.isItemLabelVisible(1, 0);
    double var4 = var0.getBase();
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = var0.getBaseToolTipGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var7 = var0.getSeriesURLGenerator(0);
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
    java.awt.Stroke var12 = var11.getBorderStroke();
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var19 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var20 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var21 = var20.clone();
    java.awt.Paint var22 = var20.getBasePaint();
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var19, var22);
    var13.setSeriesOutlinePaint(0, var22, true);
    java.awt.Stroke var27 = var13.lookupSeriesOutlineStroke(10);
    var11.setBorderStroke(var27);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isRangeCrosshairVisible();
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    java.awt.Stroke var37 = var36.getTickMarkStroke();
    var33.setDomainCrosshairStroke(var37);
    var11.setBorderStroke(var37);
    var0.setBaseOutlineStroke(var37, false);
    org.jfree.chart.labels.ItemLabelPosition var42 = var0.getBaseNegativeItemLabelPosition();
    org.jfree.chart.plot.DrawingSupplier var43 = var0.getDrawingSupplier();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var47 = var46.clone();
    java.awt.Paint var48 = var46.getBasePaint();
    boolean var49 = var46.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var52 = var46.getURLGenerator(100, 4);
    java.awt.Font var54 = null;
    var46.setSeriesItemLabelFont(0, var54, true);
    java.awt.Font var57 = var46.getBaseItemLabelFont();
    java.awt.Color var61 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("", var57, (java.awt.Paint)var61);
    org.jfree.chart.plot.PiePlot var63 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var65 = var63.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var66 = var63.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart("hi!", var57, (org.jfree.chart.plot.Plot)var63, false);
    java.awt.Paint var69 = var68.getBorderPaint();
    org.jfree.chart.title.TextTitle var70 = var68.getTitle();
    boolean var71 = var0.equals((java.lang.Object)var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test238"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var8 = var5.isOnOrBefore((org.jfree.data.time.SerialDate)var7);
//     boolean var9 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var7);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var12 = var11.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var19 = var16.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     boolean var20 = var14.isOnOrAfter((org.jfree.data.time.SerialDate)var18);
//     boolean var21 = var3.isInRange((org.jfree.data.time.SerialDate)var11, (org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var3);
//     java.util.Date var23 = var3.toDate();
//     java.text.DateFormat var26 = null;
//     org.jfree.chart.axis.DateTickUnit var27 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var26);
//     java.lang.String var29 = var27.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var37 = var34.isOnOrBefore((org.jfree.data.time.SerialDate)var36);
//     boolean var38 = var32.isOnOrAfter((org.jfree.data.time.SerialDate)var36);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var41 = var40.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var47 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var48 = var45.isOnOrBefore((org.jfree.data.time.SerialDate)var47);
//     boolean var49 = var43.isOnOrAfter((org.jfree.data.time.SerialDate)var47);
//     boolean var50 = var32.isInRange((org.jfree.data.time.SerialDate)var40, (org.jfree.data.time.SerialDate)var47);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var32);
//     java.util.Date var52 = var32.toDate();
//     java.util.Date var53 = var27.rollDate(var52);
//     org.jfree.chart.plot.CategoryMarker var54 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var53);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month(var53);
//     org.jfree.data.gantt.Task var56 = new org.jfree.data.gantt.Task("", var23, var53);
//     java.lang.String var57 = var56.getDescription();
//     java.lang.Object var58 = var56.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "12/31/69"+ "'", var29.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + ""+ "'", var57.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test239"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var1 = var0.getURLGenerator();
    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    var5.setTitle("ThreadContext");
    java.awt.Color var11 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var12 = var11.darker();
    var5.setBorderPaint((java.awt.Paint)var12);
    java.lang.String var14 = org.jfree.chart.util.PaintUtilities.colorToString(var12);
    var0.setLabelOutlinePaint((java.awt.Paint)var12);
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    java.awt.Shape var22 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var23 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var24 = var23.clone();
    java.awt.Paint var25 = var23.getBasePaint();
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var22, var25);
    var16.setSeriesOutlinePaint(0, var25, true);
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D("");
    int var32 = var31.getCategoryLabelPositionOffset();
    java.awt.Paint var33 = var31.getAxisLinePaint();
    var16.setSeriesItemLabelPaint(0, var33, true);
    var0.setLabelLinkPaint(var33);
    var0.setInteriorGap(0.05d);
    double var39 = var0.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "black"+ "'", var14.equals("black"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 4.0d);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test240"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.util.List var1 = var0.getContributors();
    java.lang.Number var2 = null;
    org.jfree.data.DefaultKeyedValues2D var10 = new org.jfree.data.DefaultKeyedValues2D();
    var10.addValue((java.lang.Number)(short)100, (java.lang.Comparable)1, (java.lang.Comparable)0.0d);
    java.lang.Number var15 = null;
    org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var23 = var20.isOnOrBefore((org.jfree.data.time.SerialDate)var22);
    boolean var24 = var18.isOnOrAfter((org.jfree.data.time.SerialDate)var22);
    org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(4);
    int var27 = var26.getYYYY();
    org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var34 = var31.isOnOrBefore((org.jfree.data.time.SerialDate)var33);
    boolean var35 = var29.isOnOrAfter((org.jfree.data.time.SerialDate)var33);
    boolean var36 = var18.isInRange((org.jfree.data.time.SerialDate)var26, (org.jfree.data.time.SerialDate)var33);
    var10.addValue(var15, (java.lang.Comparable)' ', (java.lang.Comparable)var18);
    java.util.List var38 = var10.getRowKeys();
    org.jfree.data.statistics.BoxAndWhiskerItem var39 = new org.jfree.data.statistics.BoxAndWhiskerItem(var2, (java.lang.Number)1900, (java.lang.Number)(short)100, (java.lang.Number)Double.NaN, (java.lang.Number)10L, (java.lang.Number)2, (java.lang.Number)(short)1, (java.lang.Number)(byte)1, var38);
    java.lang.Number var40 = var39.getQ3();
    java.util.List var41 = var39.getOutliers();
    var0.setContributors(var41);
    var0.setCopyright("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var0.setLicenceText("WMAP_Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + Double.NaN+ "'", var40.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test241"); }


    java.lang.Comparable var0 = null;
    java.awt.Shape var5 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var7 = var6.clone();
    java.awt.Paint var8 = var6.getBasePaint();
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var5, var8);
    java.awt.Stroke var10 = var9.getOutlineStroke();
    int var11 = var9.getDatasetIndex();
    java.text.AttributedString var12 = var9.getAttributedLabel();
    boolean var13 = var9.isShapeVisible();
    java.awt.Shape var14 = var9.getLine();
    org.jfree.chart.entity.CategoryLabelEntity var17 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var14, "ChartEntity: tooltip = XY Plot", "Last");
    java.lang.Comparable var18 = var17.getKey();
    java.lang.String var19 = var17.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "CategoryLabelEntity: category=null, tooltip=ChartEntity: tooltip = XY Plot, url=Last"+ "'", var19.equals("CategoryLabelEntity: category=null, tooltip=ChartEntity: tooltip = XY Plot, url=Last"));

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test242"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.String[] var3 = org.jfree.data.time.SerialDate.getMonths(true);
//     java.lang.Number[][] var4 = null;
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var7 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, (java.lang.Comparable[])var3, var4, var6);
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("");
//     int var10 = var9.getCategoryLabelPositionOffset();
//     java.awt.Paint var11 = var9.getAxisLinePaint();
//     java.awt.Stroke var12 = var9.getTickMarkStroke();
//     int var13 = var9.getCategoryLabelPositionOffset();
//     org.jfree.data.general.SeriesChangeEvent var14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var13);
//     java.lang.Object var15 = var14.getSource();
//     var7.seriesChanged(var14);
//     java.lang.Comparable var18 = var7.getRowKey((-668));
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test243"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setYOffset(10.0d);
    org.jfree.chart.renderer.category.WaterfallBarRenderer var4 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var5, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, var9, var10, var11);
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var14 = var13.getLabelOutlinePaint();
    var12.setRangeCrosshairPaint(var14);
    int var16 = var12.getDomainAxisCount();
    org.jfree.chart.axis.AxisSpace var17 = new org.jfree.chart.axis.AxisSpace();
    var12.setFixedRangeAxisSpace(var17);
    org.jfree.chart.axis.AxisSpace var19 = new org.jfree.chart.axis.AxisSpace();
    var12.setFixedRangeAxisSpace(var19);
    java.lang.String var21 = var12.getPlotType();
    java.awt.Paint var22 = var12.getDomainGridlinePaint();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    java.awt.geom.Point2D var31 = null;
    var27.zoomDomainAxes((-1.0d), 0.2d, var30, var31);
    java.awt.Paint var33 = var27.getRangeCrosshairPaint();
    org.jfree.chart.axis.AxisLocation var35 = var27.getRangeAxisLocation(1);
    var12.setDomainAxisLocation(var35);
    boolean var37 = var4.equals((java.lang.Object)var12);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var38 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var39 = var38.clone();
    org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var46 = var43.isOnOrBefore((org.jfree.data.time.SerialDate)var45);
    boolean var47 = var41.isOnOrAfter((org.jfree.data.time.SerialDate)var45);
    org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(4);
    int var50 = var49.getYYYY();
    org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var54 = new org.jfree.data.time.SpreadsheetDate(4);
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(4);
    boolean var57 = var54.isOnOrBefore((org.jfree.data.time.SerialDate)var56);
    boolean var58 = var52.isOnOrAfter((org.jfree.data.time.SerialDate)var56);
    boolean var59 = var41.isInRange((org.jfree.data.time.SerialDate)var49, (org.jfree.data.time.SerialDate)var56);
    boolean var60 = var38.equals((java.lang.Object)var49);
    org.jfree.chart.block.BlockBorder var66 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 100.0d, 2.0d);
    java.awt.Paint var67 = var66.getPaint();
    var38.setSeriesOutlinePaint(0, var67);
    var4.setPositiveBarPaint(var67);
    var0.setSeriesFillPaint(5, var67, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "Category Plot"+ "'", var21.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test244"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var6 = var5.clone();
    java.awt.Paint var7 = var5.getBasePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "", var4, var7);
    java.awt.Stroke var9 = var8.getOutlineStroke();
    int var10 = var8.getDatasetIndex();
    java.awt.Stroke var11 = var8.getOutlineStroke();
    java.awt.Paint var12 = var8.getOutlinePaint();
    java.awt.Paint var13 = var8.getFillPaint();
    boolean var14 = var8.isLineVisible();
    java.lang.String var15 = var8.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + ""+ "'", var15.equals(""));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test245"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(0, var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.Range var9 = var4.getDataRange(var8);
    org.jfree.chart.axis.AxisSpace var10 = null;
    var4.setFixedDomainAxisSpace(var10);
    java.awt.Paint var12 = null;
    var4.setRangeTickBandPaint(var12);
    java.awt.Paint var14 = var4.getNoDataMessagePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test246"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setBottom(0.0d);
    double var3 = var0.getLeft();
    var0.setLeft((-1.0d));
    var0.setBottom(2.78763480078E12d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test247"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("");
    var2.setUpperMargin(0.0d);
    double var5 = var2.getLowerMargin();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("");
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var11);
    var10.setLowerMargin(0.0d);
    org.jfree.chart.labels.StandardCategoryToolTipGenerator var16 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var17 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var18 = var17.clone();
    double var19 = var17.getMaximumBarWidth();
    int var20 = var17.getPassCount();
    boolean var21 = var16.equals((java.lang.Object)var17);
    java.lang.Object var22 = var16.clone();
    org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var24 = null;
    var23.setLabelOutlinePaint(var24);
    java.awt.Stroke var26 = var23.getLabelOutlineStroke();
    java.awt.Paint var27 = var23.getLabelPaint();
    org.jfree.data.general.DatasetChangeEvent var28 = null;
    var23.datasetChanged(var28);
    org.jfree.chart.labels.PieToolTipGenerator var30 = var23.getToolTipGenerator();
    org.jfree.data.general.PieDataset var31 = var23.getDataset();
    boolean var32 = var23.isCircular();
    boolean var33 = var16.equals((java.lang.Object)var23);
    java.text.NumberFormat var34 = var16.getNumberFormat();
    org.jfree.chart.labels.StandardCategoryToolTipGenerator var35 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("DateTickUnit[MONTH, 1900]", var34);
    var10.setNumberFormatOverride(var34);
    var2.setNumberFormatOverride(var34);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var38 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test248"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod((-2208787199289L), 0L);
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var3 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var4 = var3.getObjectIcon();
    boolean var5 = var3.isDrawLines();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var6 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var7 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var8 = var7.getObjectIcon();
    var6.setMaxIcon(var8);
    var3.setMinIcon(var8);
    boolean var11 = var2.equals((java.lang.Object)var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test249"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = var0.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var2 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var3 = var2.getObjectIcon();
    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var4 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var5 = var4.getObjectIcon();
    var2.setMaxIcon(var5);
    var0.setObjectIcon(var5);
    boolean var10 = var0.isItemLabelVisible(10, (-1));
    java.awt.Paint var13 = var0.getItemLabelPaint(4, 255);
    java.io.ObjectOutputStream var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test250"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var2 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, var6, var7, var8);
    org.jfree.data.general.WaferMapDataset var10 = null;
    org.jfree.chart.renderer.WaferMapRenderer var11 = null;
    org.jfree.chart.plot.WaferMapPlot var12 = new org.jfree.chart.plot.WaferMapPlot(var10, var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var12);
    var13.setTitle("ThreadContext");
    java.awt.Color var19 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    java.awt.Color var20 = var19.darker();
    var13.setBorderPaint((java.awt.Paint)var20);
    var9.setRangeGridlinePaint((java.awt.Paint)var20);
    var0.setPaint(2, (java.awt.Paint)var20);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
    java.awt.Paint var28 = var27.getWallPaint();
    var0.setPaint(100, var28);
    java.lang.Object var30 = null;
    boolean var31 = var0.equals(var30);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), (-1.0d));
    java.awt.Paint var36 = var35.getWallPaint();
    var0.setPaint(1900, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test251"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(1, 1900, var2);
//     java.lang.String var5 = var3.valueToString(1.0d);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var13 = var10.isOnOrBefore((org.jfree.data.time.SerialDate)var12);
//     boolean var14 = var8.isOnOrAfter((org.jfree.data.time.SerialDate)var12);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(4);
//     int var17 = var16.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var21 = new org.jfree.data.time.SpreadsheetDate(4);
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(4);
//     boolean var24 = var21.isOnOrBefore((org.jfree.data.time.SerialDate)var23);
//     boolean var25 = var19.isOnOrAfter((org.jfree.data.time.SerialDate)var23);
//     boolean var26 = var8.isInRange((org.jfree.data.time.SerialDate)var16, (org.jfree.data.time.SerialDate)var23);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addDays(10, (org.jfree.data.time.SerialDate)var8);
//     java.util.Date var28 = var8.toDate();
//     java.util.Date var29 = var3.rollDate(var28);
//     org.jfree.chart.plot.CategoryMarker var30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var29);
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(var29);
//     java.lang.String var32 = var31.toString();
//     org.jfree.data.time.Year var33 = var31.getYear();
//     java.lang.Object var34 = null;
//     org.jfree.data.KeyedObject var35 = new org.jfree.data.KeyedObject((java.lang.Comparable)var31, var34);
//     long var36 = var31.getLastMillisecond();
//     int var37 = var31.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "12/31/69"+ "'", var5.equals("12/31/69"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + "May 2058"+ "'", var32.equals("May 2058"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 2790140399999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 2058);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test252"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);
    double var3 = var2.getWidth();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var4 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, (java.lang.Comparable)'a');
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var4);
    org.jfree.data.Range var9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var4, true);
    org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var4, 10);
    org.jfree.data.Range var13 = var4.getRangeBounds(false);
    org.jfree.chart.block.RectangleConstraint var14 = var2.toRangeHeight(var13);
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange();
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint((-10.0d), (org.jfree.data.Range)var16);
    org.jfree.chart.block.RectangleConstraint var18 = var2.toRangeWidth((org.jfree.data.Range)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test253"); }


    java.awt.Graphics2D var0 = null;
    org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test254"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.lang.Object var4 = var3.clone();
    java.awt.Paint var5 = var3.getBasePaint();
    boolean var6 = var3.getBaseSeriesVisible();
    org.jfree.chart.urls.CategoryURLGenerator var9 = var3.getURLGenerator(100, 4);
    java.awt.Font var11 = null;
    var3.setSeriesItemLabelFont(0, var11, true);
    java.awt.Font var14 = var3.getBaseItemLabelFont();
    java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18);
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot();
    java.awt.Paint var22 = var20.getSectionPaint((java.lang.Comparable)10.0d);
    boolean var23 = var20.getLabelLinksVisible();
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("hi!", var14, (org.jfree.chart.plot.Plot)var20, false);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var26 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)'a');
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var30, var31, var32);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
    org.jfree.chart.util.Layer var43 = null;
    java.util.Collection var44 = var41.getRangeMarkers(0, var43);
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.data.Range var46 = var41.getDataRange(var45);
    org.jfree.chart.axis.AxisSpace var47 = null;
    var41.setFixedDomainAxisSpace(var47);
    java.awt.Paint var49 = null;
    var41.setRangeTickBandPaint(var49);
    java.awt.geom.Point2D var51 = var41.getQuadrantOrigin();
    var33.zoomRangeAxes(10.0d, 0.0d, var36, var51);
    org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("", var14, (org.jfree.chart.plot.Plot)var33, false);
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("");
    var33.setRangeAxis((org.jfree.chart.axis.ValueAxis)var56);
    java.awt.Paint var58 = var56.getLabelPaint();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var60 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var61 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var63 = var61.getSeriesNegativeItemLabelPosition((-1));
    var60.setNegativeItemLabelPositionFallback(var63);
    java.awt.Font var65 = var60.getBaseItemLabelFont();
    org.jfree.chart.plot.PiePlot var66 = new org.jfree.chart.plot.PiePlot();
    org.jfree.chart.urls.PieURLGenerator var67 = var66.getURLGenerator();
    java.awt.Color var72 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    var66.setSectionPaint((java.lang.Comparable)100, (java.awt.Paint)var72);
    java.awt.color.ColorSpace var74 = var72.getColorSpace();
    org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("Category Plot", var65, (java.awt.Paint)var72);
    var56.setTickLabelPaint((java.awt.Paint)var72);
    boolean var77 = var56.isAutoTickUnitSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == true);

  }

}
