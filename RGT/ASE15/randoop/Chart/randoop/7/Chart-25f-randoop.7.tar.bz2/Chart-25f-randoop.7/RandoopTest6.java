
import junit.framework.*;

public class RandoopTest6 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test1"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)100.0f, var1, var2, var5, 1.0d);
    org.jfree.chart.text.TextBlock var8 = var7.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test2"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.ValueAxis var39 = null;
    var33.setRangeAxis(var39);
    boolean var41 = var33.isRangeZoomable();
    java.lang.String var42 = var33.getPlotType();
    java.awt.Paint var43 = var33.getRangeGridlinePaint();
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var46.setMaximumCategoryLabelLines(0);
    var46.setMaximumCategoryLabelLines((-1));
    var46.setUpperMargin(1.0d);
    var46.setUpperMargin((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setDomainAxis((-16579997), var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "Category Plot"+ "'", var42.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test3"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var9 = var8.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var11 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)100.0f, var5, var6, var9, 1.0d);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Category Plot", var1, 0.95f, 0.8f, var9, (-9.0d), 0.8f, 0.0f);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test4"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    var1.setLabel("hi!");
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    int var16 = var15.getColumnCount();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var20 = var19.isNegativeArrowVisible();
    var19.setAutoRangeStickyZero(false);
    java.awt.Stroke var23 = var19.getTickMarkStroke();
    var15.setSeriesOutlineStroke(1, var23, false);
    boolean var27 = var15.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    java.awt.Paint var34 = var29.getAxisLinePaint();
    var15.setBasePaint(var34);
    org.jfree.chart.labels.CategoryToolTipGenerator var36 = null;
    var15.setBaseToolTipGenerator(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var5, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    var38.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var41 = null;
    var38.markerChanged(var41);
    boolean var43 = var38.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var44 = var38.getLegendItems();
    var4.setPlot(var38);
    org.jfree.chart.axis.ValueAxis var47 = var38.getRangeAxisForDataset(1);
    int var48 = var38.getWeight();
    var38.clearRangeMarkers();
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("hi!");
    var51.zoomRange((-1.0d), 0.0d);
    boolean var55 = var51.isPositiveArrowVisible();
    java.awt.Paint var56 = var51.getAxisLinePaint();
    var51.setUpperMargin(0.0d);
    org.jfree.chart.axis.TickUnitSource var59 = var51.getStandardTickUnits();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var60 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var61 = var60.getGroup();
    java.lang.Number var64 = var60.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    java.lang.Number var65 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var60);
    java.lang.Comparable var66 = null;
    java.lang.Number var68 = var60.getStdDevValue(var66, (java.lang.Comparable)(byte)(-1));
    org.jfree.data.Range var70 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var60, 1.0d);
    org.jfree.data.general.DatasetGroup var72 = new org.jfree.data.general.DatasetGroup("RectangleInsets[t=10.0,l=1.0,b=-1.0,r=10.0]");
    var60.setGroup(var72);
    boolean var74 = var51.equals((java.lang.Object)var60);
    org.jfree.chart.renderer.category.CategoryItemRenderer var75 = var38.getRendererForDataset((org.jfree.data.category.CategoryDataset)var60);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + Double.NaN+ "'", var65.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test5"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = var0.getToolTipGenerator(10, 10);
    java.awt.Paint var6 = var0.getItemPaint(0, 4);
    java.awt.Shape var7 = var0.getBaseShape();
    java.awt.Shape var10 = var0.getItemShape(0, (-16579997));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test6"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var5 = var4.getBackgroundPaint();
    java.awt.Paint var6 = var4.getPaint();
    var1.setTickLabelPaint(var6);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    int var9 = var8.getColumnCount();
    var8.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = null;
    var8.setSeriesNegativeItemLabelPosition(100, var13, true);
    var8.setSeriesVisible(100, (java.lang.Boolean)false, true);
    boolean var22 = var8.isItemLabelVisible(10, 1);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    var27.zoomRange((-1.0d), 0.0d);
    boolean var31 = var27.isPositiveArrowVisible();
    boolean var32 = var27.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    int var34 = var33.getColumnCount();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var38 = var37.isNegativeArrowVisible();
    var37.setAutoRangeStickyZero(false);
    java.awt.Stroke var41 = var37.getTickMarkStroke();
    var33.setSeriesOutlineStroke(1, var41, false);
    boolean var45 = var33.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
    var47.zoomRange((-1.0d), 0.0d);
    boolean var51 = var47.isPositiveArrowVisible();
    java.awt.Paint var52 = var47.getAxisLinePaint();
    var33.setBasePaint(var52);
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var33.setBaseToolTipGenerator(var54);
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var23, var25, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
    var56.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var56.markerChanged(var59);
    org.jfree.chart.util.SortOrder var61 = var56.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var62 = new org.jfree.data.KeyedObjects();
    java.lang.Object var64 = var62.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var65 = null;
    org.jfree.chart.event.ChartProgressEvent var68 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var62, var65, 0, 0);
    boolean var69 = var56.equals((java.lang.Object)var65);
    java.awt.Paint var70 = var56.getOutlinePaint();
    var8.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var56);
    var1.setPlot((org.jfree.chart.plot.Plot)var56);
    org.jfree.chart.util.HorizontalAlignment var73 = null;
    org.jfree.chart.util.VerticalAlignment var74 = null;
    org.jfree.chart.block.FlowArrangement var77 = new org.jfree.chart.block.FlowArrangement(var73, var74, 100.0d, Double.POSITIVE_INFINITY);
    org.jfree.chart.block.ColumnArrangement var78 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var79 = null;
    org.jfree.chart.axis.AxisState var80 = new org.jfree.chart.axis.AxisState();
    var80.cursorDown(0.0d);
    java.util.List var83 = var80.getTicks();
    var78.add(var79, (java.lang.Object)var80);
    org.jfree.chart.title.LegendTitle var85 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56, (org.jfree.chart.block.Arrangement)var77, (org.jfree.chart.block.Arrangement)var78);
    org.jfree.data.category.CategoryDataset var86 = var56.getDataset();
    org.jfree.chart.plot.PlotOrientation var87 = var56.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test7"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    java.awt.Paint var10 = var5.getAxisLinePaint();
    boolean var11 = var5.getAutoRangeStickyZero();
    var5.setLabelAngle((-1.0d));
    var5.setTickLabelsVisible(true);
    boolean var16 = var5.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    int var19 = var18.getColumnCount();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var18.setSeriesShape(100, var23, false);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var23, "", "0");
    var5.setDownArrow(var23);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    var30.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var30.setSeriesToolTipGenerator(1, var44);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var30.getLegendItemToolTipGenerator();
    var30.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
    var50.setHeight(100.0d);
    boolean var53 = var50.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var55 = var54.getErrorIndicatorPaint();
    var50.setPaint(var55);
    org.jfree.chart.ChartColor var60 = new org.jfree.chart.ChartColor(4, 1, 100);
    var50.setBackgroundPaint((java.awt.Paint)var60);
    var30.setBaseFillPaint((java.awt.Paint)var60, true);
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("poly", "ChartChangeEventType.GENERAL", "Size2D[width=-1.0, height=0.0]", "RangeType.FULL", var23, (java.awt.Paint)var60);
    boolean var65 = var64.isShapeFilled();
    java.awt.Shape var66 = var64.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test8"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var34.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var37 = null;
    var34.markerChanged(var37);
    boolean var39 = var34.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var40 = var34.getLegendItems();
    var0.setPlot(var34);
    org.jfree.chart.axis.ValueAxis var43 = var34.getRangeAxisForDataset(1);
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var47 = var46.getLabelOffset();
    java.awt.Paint var48 = var46.getPaint();
    java.awt.Paint var49 = var46.getOutlinePaint();
    org.jfree.chart.util.Layer var50 = null;
    var34.addRangeMarker(0, (org.jfree.chart.plot.Marker)var46, var50);
    int var52 = var34.getDatasetCount();
    java.util.List var53 = var34.getAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test9"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    int var4 = var3.getGreen();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    int var16 = var15.getColumnCount();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var20 = var19.isNegativeArrowVisible();
    var19.setAutoRangeStickyZero(false);
    java.awt.Stroke var23 = var19.getTickMarkStroke();
    var15.setSeriesOutlineStroke(1, var23, false);
    boolean var27 = var15.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    java.awt.Paint var34 = var29.getAxisLinePaint();
    var15.setBasePaint(var34);
    org.jfree.chart.labels.CategoryToolTipGenerator var36 = null;
    var15.setBaseToolTipGenerator(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var5, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    var38.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var41 = null;
    var38.markerChanged(var41);
    var38.setWeight((-1));
    org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
    java.lang.Object var46 = var45.getTextAntiAlias();
    org.jfree.chart.event.ChartChangeEvent var47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4, var45);
    org.jfree.chart.title.TextTitle var48 = var45.getTitle();
    org.jfree.chart.title.TextTitle var49 = var45.getTitle();
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    boolean var62 = var50.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    java.awt.Paint var69 = var64.getAxisLinePaint();
    var50.setBasePaint(var69);
    org.jfree.chart.labels.CategoryItemLabelGenerator var73 = var50.getItemLabelGenerator(0, (-1));
    java.awt.Paint var76 = var50.getItemOutlinePaint(5, (-16580609));
    var45.setBorderPaint(var76);
    boolean var78 = var45.getAntiAlias();
    org.jfree.chart.plot.Plot var79 = var45.getPlot();
    boolean var80 = var79.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test10"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    java.awt.Paint var10 = var5.getAxisLinePaint();
    boolean var11 = var5.getAutoRangeStickyZero();
    var5.setLabelAngle((-1.0d));
    var5.setTickLabelsVisible(true);
    boolean var16 = var5.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    int var19 = var18.getColumnCount();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var18.setSeriesShape(100, var23, false);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var23, "", "0");
    var5.setDownArrow(var23);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    var30.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var30.setSeriesToolTipGenerator(1, var44);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var30.getLegendItemToolTipGenerator();
    var30.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
    var50.setHeight(100.0d);
    boolean var53 = var50.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var55 = var54.getErrorIndicatorPaint();
    var50.setPaint(var55);
    org.jfree.chart.ChartColor var60 = new org.jfree.chart.ChartColor(4, 1, 100);
    var50.setBackgroundPaint((java.awt.Paint)var60);
    var30.setBaseFillPaint((java.awt.Paint)var60, true);
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("poly", "ChartChangeEventType.GENERAL", "Size2D[width=-1.0, height=0.0]", "RangeType.FULL", var23, (java.awt.Paint)var60);
    java.awt.Paint var65 = var64.getFillPaint();
    java.text.AttributedString var66 = var64.getAttributedLabel();
    var64.setSeriesIndex(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test11"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    var1.setMaximumCategoryLabelLines((-1));
    var1.setMaximumCategoryLabelLines((-1));
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var11 = var10.getBackgroundPaint();
    java.awt.Paint var12 = var10.getPaint();
    java.awt.Font var13 = var10.getFont();
    org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("", var13);
    var1.setTickLabelFont((java.lang.Comparable)(byte)1, var13);
    java.awt.Paint var16 = var1.getTickLabelPaint();
    var1.addCategoryLabelToolTip((java.lang.Comparable)10.0f, "hi!");
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var22 = var21.getLabelOffset();
    java.awt.Paint var23 = var21.getOutlinePaint();
    var1.setAxisLinePaint(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test12"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var2 = var1.getMarkerBand();
    var1.configure();
    var1.setRangeWithMargins(10.0d, 100.0d);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var9 = null;
    var8.addChangeListener(var9);
    java.awt.Shape var11 = var8.getRightArrow();
    var1.setUpArrow(var11);
    org.jfree.data.Range var13 = var1.getRange();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var17 = null;
    var16.addChangeListener(var17);
    java.awt.Shape var19 = var16.getRightArrow();
    org.jfree.chart.entity.CategoryLabelEntity var22 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)Double.POSITIVE_INFINITY, var19, "ChartChangeEventType.GENERAL", "AxisLocation.BOTTOM_OR_LEFT");
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.clone(var19);
    var1.setUpArrow(var19);
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    boolean var34 = var29.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
    int var36 = var35.getColumnCount();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var40 = var39.isNegativeArrowVisible();
    var39.setAutoRangeStickyZero(false);
    java.awt.Stroke var43 = var39.getTickMarkStroke();
    var35.setSeriesOutlineStroke(1, var43, false);
    boolean var47 = var35.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
    var49.zoomRange((-1.0d), 0.0d);
    boolean var53 = var49.isPositiveArrowVisible();
    java.awt.Paint var54 = var49.getAxisLinePaint();
    var35.setBasePaint(var54);
    org.jfree.chart.labels.CategoryToolTipGenerator var56 = null;
    var35.setBaseToolTipGenerator(var56);
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var25, var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
    var58.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var61 = null;
    var58.markerChanged(var61);
    boolean var63 = var58.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var58.markerChanged(var64);
    var58.setAnchorValue(0.0d);
    org.jfree.chart.util.SortOrder var68 = var58.getColumnRenderingOrder();
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    var33.setAnchorValue(0.0d);
    var33.mapDatasetToDomainAxis(0, 10);
    var33.clearRangeAxes();
    org.jfree.chart.axis.AxisLocation var47 = var33.getRangeAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test14"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var4.setLowerMargin(1.0d);
    var4.setAutoTickUnitSelection(true, true);
    boolean var39 = var4.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test15"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    org.jfree.chart.util.RectangleAnchor var50 = null;
    var49.setLegendItemGraphicLocation(var50);
    org.jfree.chart.util.RectangleInsets var52 = var49.getLegendItemGraphicPadding();
    org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var54 = var53.getBackgroundPaint();
    java.awt.Paint var55 = var53.getPaint();
    java.awt.Font var56 = var53.getFont();
    org.jfree.chart.util.HorizontalAlignment var57 = var53.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var58 = null;
    org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 4.0d, 4.0d);
    var49.setHorizontalAlignment(var57);
    org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle();
    double var64 = var63.getContentXOffset();
    java.awt.geom.Rectangle2D var65 = var63.getBounds();
    org.jfree.chart.util.VerticalAlignment var66 = var63.getVerticalAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var68 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    boolean var69 = var66.equals((java.lang.Object)var68);
    org.jfree.chart.block.ColumnArrangement var72 = new org.jfree.chart.block.ColumnArrangement(var57, var66, 0.0d, (-12.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test16"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    org.jfree.chart.util.Size2D var4 = new org.jfree.chart.util.Size2D(0.0d, 0.2d);
    boolean var5 = var1.equals((java.lang.Object)0.2d);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var9 = null;
    var8.addChangeListener(var9);
    java.awt.Shape var11 = var8.getRightArrow();
    org.jfree.chart.event.AxisChangeListener var12 = null;
    var8.addChangeListener(var12);
    org.jfree.data.Range var16 = new org.jfree.data.Range(0.0d, 0.0d);
    var8.setDefaultAutoRange(var16);
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var16, 1.0d);
    org.jfree.chart.block.LengthConstraintType var20 = var19.getWidthConstraintType();
    org.jfree.chart.util.Size2D var21 = var1.arrange(var6, var19);
    double var22 = var19.getHeight();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var25 = null;
    var24.addChangeListener(var25);
    java.awt.Shape var27 = var24.getRightArrow();
    org.jfree.chart.event.AxisChangeListener var28 = null;
    var24.addChangeListener(var28);
    org.jfree.data.Range var32 = new org.jfree.data.Range(0.0d, 0.0d);
    var24.setDefaultAutoRange(var32);
    org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(var32, 1.0d);
    org.jfree.data.Range var38 = new org.jfree.data.Range(0.0d, 0.0d);
    double var39 = var38.getLowerBound();
    double var40 = var38.getLowerBound();
    org.jfree.data.Range var43 = org.jfree.data.Range.expand(var38, 1.0d, 6.0d);
    org.jfree.chart.block.RectangleConstraint var44 = new org.jfree.chart.block.RectangleConstraint(var32, var38);
    org.jfree.data.Range var45 = var44.getWidthRange();
    org.jfree.chart.block.RectangleConstraint var46 = var19.toRangeWidth(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test17"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    boolean var3 = var0.getExpandToFitSpace();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var5 = var4.getBackgroundPaint();
    java.awt.Paint var6 = var4.getPaint();
    java.awt.Font var7 = var4.getFont();
    org.jfree.chart.util.HorizontalAlignment var8 = var4.getHorizontalAlignment();
    var0.setHorizontalAlignment(var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    double var11 = var10.getContentXOffset();
    java.awt.geom.Rectangle2D var12 = var10.getBounds();
    org.jfree.chart.util.VerticalAlignment var13 = var10.getVerticalAlignment();
    org.jfree.chart.axis.CategoryLabelPositions var15 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    boolean var16 = var13.equals((java.lang.Object)var15);
    org.jfree.chart.block.FlowArrangement var19 = new org.jfree.chart.block.FlowArrangement(var8, var13, 4.0d, (-2.5d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test18"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("0", var1, 0.5f, 0.0f, 0.0d, 2.0f, 10.0f);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test19"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    var0.setMinimumBarLength(4.0d);
    java.awt.Paint var6 = var0.lookupSeriesPaint((-16514716));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test20"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var39 = var38.isNegativeArrowVisible();
    var38.setAutoRangeStickyZero(false);
    java.awt.Stroke var42 = var38.getTickMarkStroke();
    var34.setSeriesOutlineStroke(1, var42, false);
    var34.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var48 = null;
    var34.setSeriesToolTipGenerator(1, var48);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var50 = var34.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var53 = var34.getPositiveItemLabelPosition(10, (-1));
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var54 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var34};
    var33.setRenderers(var54);
    org.jfree.chart.event.PlotChangeListener var56 = null;
    var33.addChangeListener(var56);
    org.jfree.chart.axis.CategoryAxis var58 = var33.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test21"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    var33.setWeight((-1));
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    org.jfree.chart.event.ChartProgressListener var41 = null;
    var40.removeProgressListener(var41);
    org.jfree.data.category.CategoryDataset var43 = null;
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
    var47.zoomRange((-1.0d), 0.0d);
    boolean var51 = var47.isPositiveArrowVisible();
    boolean var52 = var47.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
    int var54 = var53.getColumnCount();
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var58 = var57.isNegativeArrowVisible();
    var57.setAutoRangeStickyZero(false);
    java.awt.Stroke var61 = var57.getTickMarkStroke();
    var53.setSeriesOutlineStroke(1, var61, false);
    boolean var65 = var53.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("hi!");
    var67.zoomRange((-1.0d), 0.0d);
    boolean var71 = var67.isPositiveArrowVisible();
    java.awt.Paint var72 = var67.getAxisLinePaint();
    var53.setBasePaint(var72);
    org.jfree.chart.labels.CategoryToolTipGenerator var74 = null;
    var53.setBaseToolTipGenerator(var74);
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot(var43, var45, (org.jfree.chart.axis.ValueAxis)var47, (org.jfree.chart.renderer.category.CategoryItemRenderer)var53);
    var76.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var79 = null;
    var76.markerChanged(var79);
    boolean var81 = var76.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var82 = var76.getLegendItems();
    org.jfree.chart.ChartColor var86 = new org.jfree.chart.ChartColor(4, 1, 100);
    var76.setNoDataMessagePaint((java.awt.Paint)var86);
    float[] var88 = null;
    float[] var89 = var86.getRGBColorComponents(var88);
    boolean var90 = var40.equals((java.lang.Object)var88);
    org.jfree.chart.ChartRenderingInfo var95 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var96 = var40.createBufferedImage(100, (-16580609), 102.0d, (-1.0d), var95);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test22"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var1.set(4, (java.lang.Object)10.0d);
    var0.addObject((java.lang.Object)10.0d, (java.lang.Comparable)0.0f, (java.lang.Comparable)Double.POSITIVE_INFINITY);
    int var9 = var0.getColumnCount();
    int var10 = var0.getColumnCount();
    java.util.List var11 = var0.getColumnKeys();
    int var13 = var0.getColumnIndex((java.lang.Comparable)"-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    java.util.List var14 = var0.getRowKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test23"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(8.0d);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test24"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var2 = var1.getMarkerBand();
    var1.setRangeAboutValue(2.0d, 0.0d);
    org.jfree.data.RangeType var6 = var1.getRangeType();
    java.lang.String var7 = var6.toString();
    java.lang.String var8 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "RangeType.FULL"+ "'", var7.equals("RangeType.FULL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RangeType.FULL"+ "'", var8.equals("RangeType.FULL"));

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test25"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.plot.CategoryPlot var34 = var10.getPlot();
    boolean var35 = var34.isRangeGridlinesVisible();
    org.jfree.chart.ChartRenderingInfo var37 = null;
    org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    int var40 = var39.getColumnCount();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var44 = var43.isNegativeArrowVisible();
    var43.setAutoRangeStickyZero(false);
    java.awt.Stroke var47 = var43.getTickMarkStroke();
    var39.setSeriesOutlineStroke(1, var47, false);
    boolean var51 = var39.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("hi!");
    var53.zoomRange((-1.0d), 0.0d);
    boolean var57 = var53.isPositiveArrowVisible();
    java.awt.Paint var58 = var53.getAxisLinePaint();
    var39.setBasePaint(var58);
    boolean var60 = var38.equals((java.lang.Object)var58);
    java.awt.geom.Point2D var61 = null;
    var34.zoomRangeAxes(Double.POSITIVE_INFINITY, var38, var61);
    org.jfree.chart.renderer.category.BarRenderer var63 = new org.jfree.chart.renderer.category.BarRenderer();
    int var64 = var63.getColumnCount();
    org.jfree.chart.annotations.CategoryAnnotation var65 = null;
    boolean var66 = var63.removeAnnotation(var65);
    org.jfree.chart.labels.ItemLabelPosition var68 = var63.getSeriesNegativeItemLabelPosition(1);
    org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var71 = var70.getLabelOffset();
    java.awt.Paint var72 = var70.getPaint();
    var63.setBaseFillPaint(var72);
    var34.setNoDataMessagePaint(var72);
    org.jfree.chart.LegendItemCollection var75 = var34.getFixedLegendItems();
    org.jfree.chart.plot.Plot var76 = var34.getRootPlot();
    int var77 = var34.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 1);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test26"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var1, var2, var5, 0.0d);
    double var8 = var7.getAngle();
    java.lang.Object var9 = var7.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test27"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    java.awt.Font var12 = var0.getSeriesItemLabelFont(100);
    boolean var13 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test28"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     boolean var34 = var4.isVerticalTickLabels();
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var36.zoomRange((-1.0d), 0.0d);
//     boolean var40 = var36.isPositiveArrowVisible();
//     java.awt.Paint var41 = var36.getAxisLinePaint();
//     org.jfree.chart.util.RectangleInsets var42 = var36.getTickLabelInsets();
//     org.jfree.chart.axis.NumberTickUnit var43 = var36.getTickUnit();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var46 = null;
//     var45.addChangeListener(var46);
//     java.awt.Shape var48 = var45.getRightArrow();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var51 = null;
//     var50.addChangeListener(var51);
//     java.awt.Shape var53 = var50.getRightArrow();
//     var45.setRightArrow(var53);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var57 = null;
//     var56.addChangeListener(var57);
//     java.awt.Shape var59 = var56.getRightArrow();
//     org.jfree.chart.event.AxisChangeListener var60 = null;
//     var56.addChangeListener(var60);
//     org.jfree.data.Range var64 = new org.jfree.data.Range(0.0d, 0.0d);
//     var56.setDefaultAutoRange(var64);
//     var45.setRange(var64);
//     var36.setRangeWithMargins(var64, false, false);
//     var4.setRangeWithMargins(var64, false, true);
//     org.jfree.chart.axis.NumberTickUnit var73 = var4.getTickUnit();
//     double var74 = var73.getSize();
//     int var75 = var73.getMinorTickCount();
//     java.lang.Comparable[] var76 = new java.lang.Comparable[] { var75};
//     org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var78.zoomRange((-1.0d), 0.0d);
//     boolean var82 = var78.isPositiveArrowVisible();
//     boolean var83 = var78.getAutoRangeIncludesZero();
//     java.awt.geom.Rectangle2D var85 = null;
//     org.jfree.chart.util.RectangleEdge var86 = null;
//     double var87 = var78.valueToJava2D(4.0d, var85, var86);
//     org.jfree.chart.axis.NumberTickUnit var89 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
//     java.lang.String var91 = var89.valueToString(0.0d);
//     var78.setTickUnit(var89, true, true);
//     java.lang.String var95 = var89.toString();
//     java.lang.Comparable[] var96 = new java.lang.Comparable[] { var95};
//     double[] var97 = null;
//     double[][] var98 = new double[][] { var97};
//     org.jfree.data.category.CategoryDataset var99 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var76, var96, var98);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test29"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.TickUnits var1 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1L);
    java.lang.Object var4 = var3.getSource();
    boolean var5 = var1.equals(var4);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var7.setMaximumCategoryLabelLines(0);
    var7.setMaximumCategoryLabelLines((-1));
    var7.setUpperMargin(1.0d);
    boolean var14 = var1.equals((java.lang.Object)var7);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    boolean var22 = var16.getAutoRangeStickyZero();
    double var23 = var16.getUpperBound();
    org.jfree.chart.event.AxisChangeListener var24 = null;
    var16.addChangeListener(var24);
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var16, var26);
    org.jfree.chart.ChartColor var32 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var33 = var32.brighter();
    var7.setTickLabelPaint((java.lang.Comparable)"CategoryAnchor.MIDDLE", (java.awt.Paint)var33);
    double var35 = var7.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1L+ "'", var4.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test30"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"0", var3, "0", "CategoryLabelEntity: category=false, tooltip=, url=0");
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Paint var9 = var8.getPaint();
    org.jfree.chart.title.LegendGraphic var10 = new org.jfree.chart.title.LegendGraphic(var3, var9);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    var11.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var18 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var11.setMargin(var18);
    double var21 = var18.calculateTopInset(0.0d);
    double var23 = var18.calculateBottomInset(10.0d);
    double var24 = var18.getLeft();
    var10.setPadding(var18);
    java.awt.Shape var26 = var10.getLine();
    org.jfree.chart.util.StandardGradientPaintTransformer var27 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    var10.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var27);
    java.lang.Object var29 = var27.clone();
    org.jfree.chart.util.GradientPaintTransformType var30 = var27.getType();
    org.jfree.chart.util.GradientPaintTransformType var31 = var27.getType();
    org.jfree.chart.block.BorderArrangement var32 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var34 = var33.getBackgroundPaint();
    java.awt.Paint var35 = var33.getPaint();
    java.awt.Font var36 = var33.getFont();
    org.jfree.chart.util.HorizontalAlignment var37 = var33.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var38 = null;
    org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, 6.0d, (-1.0d));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var42 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var43 = var42.getGroup();
    var42.validateObject();
    org.jfree.chart.title.LegendItemBlockContainer var46 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var41, (org.jfree.data.general.Dataset)var42, (java.lang.Comparable)1.0f);
    java.lang.Comparable var47 = var46.getSeriesKey();
    java.awt.Graphics2D var48 = null;
    org.jfree.data.Range var52 = new org.jfree.data.Range(0.0d, 0.0d);
    double var53 = var52.getLowerBound();
    double var54 = var52.getLowerBound();
    org.jfree.data.Range var57 = org.jfree.data.Range.expand(var52, 1.0d, 6.0d);
    org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint(2.0d, var52);
    double var59 = var58.getHeight();
    org.jfree.chart.block.RectangleConstraint var61 = var58.toFixedWidth(Double.NaN);
    org.jfree.chart.util.Size2D var62 = var32.arrange((org.jfree.chart.block.BlockContainer)var46, var48, var58);
    boolean var63 = var27.equals((java.lang.Object)var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + 1.0f+ "'", var47.equals(1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test31"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    boolean var34 = var33.isRangeCrosshairVisible();
    float var35 = var33.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.5f);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test32"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    var1.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    int var7 = var6.getColumnCount();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var11 = var10.isNegativeArrowVisible();
    var10.setAutoRangeStickyZero(false);
    java.awt.Stroke var14 = var10.getTickMarkStroke();
    var6.setSeriesOutlineStroke(1, var14, false);
    var1.setSeriesOutlineStroke(0, var14, false);
    java.awt.Paint var20 = var1.getSeriesItemLabelPaint(10);
    boolean var21 = var1.isDrawBarOutline();
    boolean var22 = var1.getBaseCreateEntities();
    var1.setBaseSeriesVisibleInLegend(true);
    java.awt.Font var27 = var1.getItemLabelFont(10, (-886407));
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ChartChangeEventType.GENERAL");
    java.lang.Object var30 = var29.clone();
    org.jfree.data.category.CategoryDataset var31 = null;
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    var35.zoomRange((-1.0d), 0.0d);
    boolean var39 = var35.isPositiveArrowVisible();
    boolean var40 = var35.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var46 = var45.isNegativeArrowVisible();
    var45.setAutoRangeStickyZero(false);
    java.awt.Stroke var49 = var45.getTickMarkStroke();
    var41.setSeriesOutlineStroke(1, var49, false);
    boolean var53 = var41.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("hi!");
    var55.zoomRange((-1.0d), 0.0d);
    boolean var59 = var55.isPositiveArrowVisible();
    java.awt.Paint var60 = var55.getAxisLinePaint();
    var41.setBasePaint(var60);
    org.jfree.chart.labels.CategoryToolTipGenerator var62 = null;
    var41.setBaseToolTipGenerator(var62);
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var31, var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
    org.jfree.chart.plot.CategoryPlot var65 = var41.getPlot();
    boolean var66 = var29.equals((java.lang.Object)var65);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var74 = var68.getTickLabelInsets();
    var65.setInsets(var74, true);
    org.jfree.chart.util.RectangleInsets var77 = new org.jfree.chart.util.RectangleInsets();
    var65.setInsets(var77);
    org.jfree.chart.JFreeChart var80 = new org.jfree.chart.JFreeChart("0", var27, (org.jfree.chart.plot.Plot)var65, false);
    java.util.List var81 = var80.getSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test33"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    java.awt.Font var12 = var0.getSeriesItemLabelFont(100);
    var0.setBaseSeriesVisible(false, false);
    java.awt.Stroke var17 = var0.lookupSeriesOutlineStroke(1);
    java.awt.Font var18 = var0.getBaseItemLabelFont();
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = var0.getToolTipGenerator(255, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-16514716), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test34"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    var22.zoomRange((-1.0d), 0.0d);
    boolean var26 = var22.isPositiveArrowVisible();
    boolean var27 = var22.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var28.setBaseToolTipGenerator(var49);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var18, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    var0.setPlot(var51);
    org.jfree.chart.axis.AxisLocation var54 = var51.getRangeAxisLocation(4);
    var51.setAnchorValue(14.0d);
    boolean var57 = var51.isSubplot();
    java.lang.String var58 = var51.getNoDataMessage();
    float var59 = var51.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0f);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-16579997), 100, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test36"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var1 = var0.getErrorIndicatorPaint();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    var4.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var14 = var13.isNegativeArrowVisible();
    var13.setAutoRangeStickyZero(false);
    java.awt.Stroke var17 = var13.getTickMarkStroke();
    var9.setSeriesOutlineStroke(1, var17, false);
    var4.setSeriesOutlineStroke(0, var17, false);
    var3.setAxisLineStroke(var17);
    var0.setErrorIndicatorStroke(var17);
    var0.setItemLabelAnchorOffset(2.0d);
    boolean var26 = var0.getBaseItemLabelsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test37"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    var41.setBaseSeriesVisible(false);
    var41.setBaseSeriesVisible(true);
    var33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var41, true);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    double var50 = var49.getWidth();
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var52.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var55 = var52.getLabelInsets();
    var49.setItemLabelPadding(var55);
    java.awt.geom.Rectangle2D var57 = var49.getBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test38"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var2.zoomRange((-1.0d), 0.0d);
//     boolean var6 = var2.isPositiveArrowVisible();
//     java.awt.Paint var7 = var2.getAxisLinePaint();
//     org.jfree.chart.util.RectangleInsets var8 = var2.getTickLabelInsets();
//     double var10 = var8.calculateLeftOutset(0.0d);
//     org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var12 = var11.getBackgroundPaint();
//     java.awt.Paint var13 = var11.getPaint();
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(var8, var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var18 = var17.isNegativeArrowVisible();
//     org.jfree.chart.util.RectangleInsets var19 = var17.getLabelInsets();
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
//     double var21 = var20.getContentXOffset();
//     java.awt.geom.Rectangle2D var22 = var20.getBounds();
//     org.jfree.chart.util.LengthAdjustmentType var23 = null;
//     org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.util.RectangleInsets var26 = var25.getLabelOffset();
//     org.jfree.chart.util.RectangleInsets var27 = var25.getLabelOffset();
//     java.awt.Paint var28 = var25.getLabelPaint();
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     var29.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.labels.ItemLabelPosition var32 = null;
//     var29.setPositiveItemLabelPositionFallback(var32);
//     org.jfree.chart.labels.ItemLabelPosition var34 = var29.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var36.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var40 = var39.getBackgroundPaint();
//     java.awt.Paint var41 = var39.getPaint();
//     var36.setTickLabelPaint(var41);
//     var29.setBaseOutlinePaint(var41, false);
//     var25.setLabelPaint(var41);
//     org.jfree.chart.util.LengthAdjustmentType var46 = var25.getLabelOffsetType();
//     org.jfree.chart.axis.AxisState var48 = new org.jfree.chart.axis.AxisState(0.2d);
//     boolean var49 = var46.equals((java.lang.Object)var48);
//     java.awt.geom.Rectangle2D var50 = var19.createAdjustedRectangle(var22, var23, var46);
//     java.awt.geom.Rectangle2D var51 = var8.createOutsetRectangle(var50);
//     boolean var52 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var50);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test39"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((java.lang.Comparable)1);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    var4.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var9 = var8.getMarkerBand();
    boolean var10 = var4.equals((java.lang.Object)var8);
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.AxisState var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    java.util.List var15 = var8.refreshTicks(var11, var12, var13, var14);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    var20.zoomRange((-1.0d), 0.0d);
    boolean var24 = var20.isPositiveArrowVisible();
    boolean var25 = var20.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    boolean var38 = var26.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
    var40.zoomRange((-1.0d), 0.0d);
    boolean var44 = var40.isPositiveArrowVisible();
    java.awt.Paint var45 = var40.getAxisLinePaint();
    var26.setBasePaint(var45);
    org.jfree.chart.labels.CategoryToolTipGenerator var47 = null;
    var26.setBaseToolTipGenerator(var47);
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var16, var18, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
    org.jfree.chart.ChartRenderingInfo var52 = null;
    org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
    org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
    int var55 = var54.getColumnCount();
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var59 = var58.isNegativeArrowVisible();
    var58.setAutoRangeStickyZero(false);
    java.awt.Stroke var62 = var58.getTickMarkStroke();
    var54.setSeriesOutlineStroke(1, var62, false);
    boolean var66 = var54.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    var54.setBasePaint(var73);
    boolean var75 = var53.equals((java.lang.Object)var73);
    var49.handleClick(0, 100, var53);
    java.awt.Stroke var77 = var49.getOutlineStroke();
    var8.setAxisLineStroke(var77);
    var8.setRange(10.0d, 10.0d);
    var0.setObject((java.lang.Comparable)"RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]", (java.lang.Object)10.0d);
    java.lang.Comparable var83 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(var83);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test40"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var3 = var0.getToolTipGenerator(10, 10);
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var5 = var4.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var4.getLegendItemLabelGenerator();
//     var0.setLegendItemToolTipGenerator(var6);
//     java.awt.Paint var9 = var0.lookupSeriesPaint((-1));
//     org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
//     var0.setSeriesToolTipGenerator(10, var11);
//     var0.setAutoPopulateSeriesOutlineStroke(true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var20.zoomRange((-1.0d), 0.0d);
//     boolean var24 = var20.isPositiveArrowVisible();
//     boolean var25 = var20.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var27 = var26.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var31 = var30.isNegativeArrowVisible();
//     var30.setAutoRangeStickyZero(false);
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var26.setSeriesOutlineStroke(1, var34, false);
//     boolean var38 = var26.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var40.zoomRange((-1.0d), 0.0d);
//     boolean var44 = var40.isPositiveArrowVisible();
//     java.awt.Paint var45 = var40.getAxisLinePaint();
//     var26.setBasePaint(var45);
//     org.jfree.chart.labels.CategoryToolTipGenerator var47 = null;
//     var26.setBaseToolTipGenerator(var47);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var16, var18, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
//     org.jfree.chart.axis.AxisLocation var50 = var49.getDomainAxisLocation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = var49.getRenderer(1);
//     boolean var53 = var15.hasListener((java.util.EventListener)var49);
//     org.jfree.data.Range var54 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var15);
//     org.jfree.data.Range var55 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var15);
//     double var57 = var15.getRangeUpperBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Comparable var59 = var15.getRowKey((-16777216));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == Double.NaN);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test41"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    boolean var19 = var0.isSeriesVisible(5);
    var0.setMinimumBarLength(2.0d);
    org.jfree.chart.urls.CategoryURLGenerator var22 = null;
    var0.setBaseURLGenerator(var22);
    boolean var24 = var0.getAutoPopulateSeriesPaint();
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-886407), var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test42"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    var33.configureDomainAxes();
    org.jfree.chart.util.SortOrder var40 = var33.getColumnRenderingOrder();
    var33.clearDomainMarkers((-16514716));
    java.lang.String var43 = var33.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "Category Plot"+ "'", var43.equals("Category Plot"));

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test43"); }


    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    var8.zoomRange((-1.0d), 0.0d);
    boolean var12 = var8.isPositiveArrowVisible();
    boolean var13 = var8.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    int var15 = var14.getColumnCount();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var19 = var18.isNegativeArrowVisible();
    var18.setAutoRangeStickyZero(false);
    java.awt.Stroke var22 = var18.getTickMarkStroke();
    var14.setSeriesOutlineStroke(1, var22, false);
    boolean var26 = var14.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    java.awt.Paint var33 = var28.getAxisLinePaint();
    var14.setBasePaint(var33);
    org.jfree.chart.labels.CategoryToolTipGenerator var35 = null;
    var14.setBaseToolTipGenerator(var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var4, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.plot.CategoryPlot var38 = var14.getPlot();
    boolean var39 = var38.isRangeGridlinesVisible();
    org.jfree.chart.ChartRenderingInfo var41 = null;
    org.jfree.chart.plot.PlotRenderingInfo var42 = new org.jfree.chart.plot.PlotRenderingInfo(var41);
    org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
    int var44 = var43.getColumnCount();
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var48 = var47.isNegativeArrowVisible();
    var47.setAutoRangeStickyZero(false);
    java.awt.Stroke var51 = var47.getTickMarkStroke();
    var43.setSeriesOutlineStroke(1, var51, false);
    boolean var55 = var43.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("hi!");
    var57.zoomRange((-1.0d), 0.0d);
    boolean var61 = var57.isPositiveArrowVisible();
    java.awt.Paint var62 = var57.getAxisLinePaint();
    var43.setBasePaint(var62);
    boolean var64 = var42.equals((java.lang.Object)var62);
    java.awt.geom.Point2D var65 = null;
    var38.zoomRangeAxes(Double.POSITIVE_INFINITY, var42, var65);
    org.jfree.chart.renderer.category.BarRenderer var67 = new org.jfree.chart.renderer.category.BarRenderer();
    int var68 = var67.getColumnCount();
    org.jfree.chart.annotations.CategoryAnnotation var69 = null;
    boolean var70 = var67.removeAnnotation(var69);
    org.jfree.chart.labels.ItemLabelPosition var72 = var67.getSeriesNegativeItemLabelPosition(1);
    org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var75 = var74.getLabelOffset();
    java.awt.Paint var76 = var74.getPaint();
    var67.setBaseFillPaint(var76);
    var38.setNoDataMessagePaint(var76);
    org.jfree.chart.LegendItemCollection var79 = var38.getFixedLegendItems();
    org.jfree.chart.plot.Plot var80 = var38.getRootPlot();
    java.awt.Paint var81 = var80.getNoDataMessagePaint();
    org.jfree.chart.block.BlockBorder var82 = new org.jfree.chart.block.BlockBorder(Double.POSITIVE_INFINITY, (-1.99999999d), 100.0d, 2.0d, var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test44"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    var41.setBaseSeriesVisible(false);
    var41.setBaseSeriesVisible(true);
    var33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var41, true);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    double var50 = var49.getWidth();
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var52.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var55 = var52.getLabelInsets();
    var49.setItemLabelPadding(var55);
    double var58 = var55.calculateTopInset((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 3.0d);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test45"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    int var4 = var3.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemLabelGenerator(var5);
    double var7 = var0.getUpperClip();
    int var8 = var0.getPassCount();
    var0.setMaximumBarWidth(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test46"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var0.setBasePaint(var19);
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder(var19);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    boolean var23 = var21.equals((java.lang.Object)var22);
    org.jfree.chart.LegendItemCollection var24 = var22.getLegendItems();
    org.jfree.chart.labels.ItemLabelPosition var26 = var22.getSeriesPositiveItemLabelPosition((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test47"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    var22.zoomRange((-1.0d), 0.0d);
    boolean var26 = var22.isPositiveArrowVisible();
    boolean var27 = var22.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var28.setBaseToolTipGenerator(var49);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var18, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    var0.setPlot(var51);
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var55.setMaximumCategoryLabelLines(0);
    var55.setMaximumCategoryLabelLines((-1));
    var55.setMaximumCategoryLabelLines((-1));
    double var62 = var55.getCategoryMargin();
    org.jfree.chart.axis.CategoryLabelPositions var63 = var55.getCategoryLabelPositions();
    var51.setDomainAxis(100, var55, false);
    var55.setLabelURL("Size2D[width=-1.0, height=6.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test48"); }


    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    var2.setBaseSeriesVisible(false);
    java.awt.Font var6 = var2.getBaseItemLabelFont();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Font var8 = var7.getNoDataMessageFont();
    var7.setRangeCrosshairValue((-1.0d));
    java.awt.Paint var11 = var7.getDomainGridlinePaint();
    org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=0", var6, var11);
    org.jfree.chart.text.TextLine var13 = new org.jfree.chart.text.TextLine("", var6);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
    java.awt.Font var16 = var15.getFont();
    var13.removeFragment(var15);
    org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var21 = var20.getBackgroundPaint();
    java.awt.Paint var22 = var20.getPaint();
    java.awt.Font var23 = var20.getFont();
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("", var23);
    java.awt.Font var25 = var24.getFont();
    org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("", var25);
    var13.removeFragment(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test49"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorDown(0.0d);
    double var3 = var0.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test50"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleEdge.TOP");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test51"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var1.valueToJava2D(4.0d, var8, var9);
    var1.setLowerMargin(1.0E-8d);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var15 = null;
    var14.addChangeListener(var15);
    java.awt.Shape var17 = var14.getRightArrow();
    org.jfree.chart.event.AxisChangeListener var18 = null;
    var14.addChangeListener(var18);
    org.jfree.data.Range var22 = new org.jfree.data.Range(0.0d, 0.0d);
    var14.setDefaultAutoRange(var22);
    org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var22, 1.0d);
    var1.setRange(var22, true, false);
    var1.centerRange((-4.0d));
    var1.setPositiveArrowVisible(false);
    java.lang.String var33 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test52"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test53"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    var6.zoomRange((-1.0d), 0.0d);
    boolean var10 = var6.isPositiveArrowVisible();
    boolean var11 = var6.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    int var13 = var12.getColumnCount();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var17 = var16.isNegativeArrowVisible();
    var16.setAutoRangeStickyZero(false);
    java.awt.Stroke var20 = var16.getTickMarkStroke();
    var12.setSeriesOutlineStroke(1, var20, false);
    boolean var24 = var12.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    var26.zoomRange((-1.0d), 0.0d);
    boolean var30 = var26.isPositiveArrowVisible();
    java.awt.Paint var31 = var26.getAxisLinePaint();
    var12.setBasePaint(var31);
    org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
    var12.setBaseToolTipGenerator(var33);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var2, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var35.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var38 = null;
    var35.markerChanged(var38);
    boolean var40 = var35.isOutlineVisible();
    int var41 = var35.getDomainAxisCount();
    org.jfree.chart.LegendItemCollection var42 = null;
    var35.setFixedLegendItems(var42);
    org.jfree.chart.axis.AxisSpace var44 = var35.getFixedRangeAxisSpace();
    boolean var45 = var1.hasListener((java.util.EventListener)var35);
    double var46 = var1.getFixedDimension();
    org.jfree.chart.axis.CategoryLabelPositions var48 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(Double.POSITIVE_INFINITY);
    var1.setCategoryLabelPositions(var48);
    java.awt.Paint var50 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test54"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(2.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test55"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var5 = var4.getMarkerBand();
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var4.refreshTicks(var7, var8, var9, var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    boolean var21 = var16.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var27 = var26.isNegativeArrowVisible();
    var26.setAutoRangeStickyZero(false);
    java.awt.Stroke var30 = var26.getTickMarkStroke();
    var22.setSeriesOutlineStroke(1, var30, false);
    boolean var34 = var22.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    var36.zoomRange((-1.0d), 0.0d);
    boolean var40 = var36.isPositiveArrowVisible();
    java.awt.Paint var41 = var36.getAxisLinePaint();
    var22.setBasePaint(var41);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var22.setBaseToolTipGenerator(var43);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var12, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    org.jfree.chart.ChartRenderingInfo var48 = null;
    org.jfree.chart.plot.PlotRenderingInfo var49 = new org.jfree.chart.plot.PlotRenderingInfo(var48);
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    boolean var62 = var50.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    java.awt.Paint var69 = var64.getAxisLinePaint();
    var50.setBasePaint(var69);
    boolean var71 = var49.equals((java.lang.Object)var69);
    var45.handleClick(0, 100, var49);
    java.awt.Stroke var73 = var45.getOutlineStroke();
    var4.setAxisLineStroke(var73);
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var77 = null;
    var76.addChangeListener(var77);
    java.awt.Shape var79 = var76.getRightArrow();
    var4.setRightArrow(var79);
    org.jfree.chart.entity.LegendItemEntity var81 = new org.jfree.chart.entity.LegendItemEntity(var79);
    java.lang.Comparable var82 = null;
    var81.setSeriesKey(var82);
    org.jfree.data.general.Dataset var84 = var81.getDataset();
    java.lang.String var85 = var81.toString();
    java.lang.Comparable var86 = var81.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var85 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var85.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test56"); }


    org.jfree.chart.block.BlockResult var0 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var1 = var0.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test57"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    var2.zoomRange((-1.0d), 0.0d);
    boolean var6 = var2.isPositiveArrowVisible();
    boolean var7 = var2.getAutoRangeIncludesZero();
    var2.resizeRange(4.0d);
    double var10 = var2.getFixedDimension();
    boolean var11 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    var13.zoomRange((-1.0d), 0.0d);
    boolean var17 = var13.isPositiveArrowVisible();
    boolean var18 = var13.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var20 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var22 = var20.valueToString(0.0d);
    var13.setTickUnit(var20);
    org.jfree.chart.JFreeChart var24 = null;
    org.jfree.chart.event.ChartProgressEvent var27 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var13, var24, (-1), 10);
    var13.setPositiveArrowVisible(true);
    var13.resizeRange(6.0d, 0.0d);
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    var34.zoomRange((-1.0d), 0.0d);
    boolean var38 = var34.isPositiveArrowVisible();
    boolean var39 = var34.isInverted();
    java.awt.Shape var40 = var34.getDownArrow();
    var13.setUpArrow(var40);
    org.jfree.data.RangeType var42 = var13.getRangeType();
    var2.setRangeType(var42);
    java.lang.String var44 = var42.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "0"+ "'", var22.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "RangeType.FULL"+ "'", var44.equals("RangeType.FULL"));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test58"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.LegendItemCollection var38 = var33.getFixedLegendItems();
    boolean var39 = var33.isDomainZoomable();
    org.jfree.chart.axis.CategoryAxis var41 = var33.getDomainAxis((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test59"); }


    java.lang.Number var0 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(var0, (java.lang.Number)10.0f);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test60"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((java.lang.Comparable)1);
    int var4 = var0.getIndex((java.lang.Comparable)(short)(-1));
    java.lang.Comparable var6 = var0.getKey((-33));
    java.lang.Object var7 = var0.clone();
    java.lang.Object var9 = var0.getObject((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test61"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Paint var2 = var0.getBaseFillPaint();
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    double var6 = var4.getValue();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("hi!");
    var12.zoomRange((-1.0d), 0.0d);
    boolean var16 = var12.isPositiveArrowVisible();
    boolean var17 = var12.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    int var19 = var18.getColumnCount();
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var23 = var22.isNegativeArrowVisible();
    var22.setAutoRangeStickyZero(false);
    java.awt.Stroke var26 = var22.getTickMarkStroke();
    var18.setSeriesOutlineStroke(1, var26, false);
    boolean var30 = var18.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    var32.zoomRange((-1.0d), 0.0d);
    boolean var36 = var32.isPositiveArrowVisible();
    java.awt.Paint var37 = var32.getAxisLinePaint();
    var18.setBasePaint(var37);
    org.jfree.chart.labels.CategoryToolTipGenerator var39 = null;
    var18.setBaseToolTipGenerator(var39);
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var8, var10, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.axis.AxisLocation var42 = var41.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = var41.getRenderer(1);
    boolean var45 = var7.hasListener((java.util.EventListener)var41);
    java.awt.Paint var46 = var41.getRangeGridlinePaint();
    var4.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var41);
    org.jfree.chart.LegendItemCollection var48 = var41.getLegendItems();
    org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
    int var50 = var49.getColumnCount();
    var49.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var54 = null;
    var49.setSeriesNegativeItemLabelPosition(100, var54, true);
    java.awt.Font var57 = null;
    var49.setBaseItemLabelFont(var57, true);
    java.awt.Stroke var62 = var49.getItemStroke(1, (-1));
    var41.setDomainGridlineStroke(var62);
    var0.setBaseStroke(var62, false);
    boolean var66 = var0.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test62"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextBlockAnchor var2 = var1.getLabelAnchor();
    java.lang.String var3 = var2.toString();
    java.lang.String var4 = var2.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var5 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER"+ "'", var3.equals("TextBlockAnchor.BOTTOM_CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "TextBlockAnchor.BOTTOM_CENTER"+ "'", var4.equals("TextBlockAnchor.BOTTOM_CENTER"));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test63"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.add((org.jfree.chart.block.Block)var1, (java.lang.Object)var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    var8.zoomRange((-1.0d), 0.0d);
    boolean var12 = var8.isPositiveArrowVisible();
    boolean var13 = var8.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    int var15 = var14.getColumnCount();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var19 = var18.isNegativeArrowVisible();
    var18.setAutoRangeStickyZero(false);
    java.awt.Stroke var22 = var18.getTickMarkStroke();
    var14.setSeriesOutlineStroke(1, var22, false);
    boolean var26 = var14.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    java.awt.Paint var33 = var28.getAxisLinePaint();
    var14.setBasePaint(var33);
    org.jfree.chart.labels.CategoryToolTipGenerator var35 = null;
    var14.setBaseToolTipGenerator(var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var4, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    var37.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var40 = null;
    var37.markerChanged(var40);
    org.jfree.chart.util.SortOrder var42 = var37.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var43 = new org.jfree.data.KeyedObjects();
    java.lang.Object var45 = var43.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var46 = null;
    org.jfree.chart.event.ChartProgressEvent var49 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var43, var46, 0, 0);
    boolean var50 = var37.equals((java.lang.Object)var46);
    java.awt.Paint var51 = var37.getOutlinePaint();
    var2.setErrorIndicatorPaint(var51);
    org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
    var53.setAutoPopulateSeriesFillPaint(true);
    java.awt.Font var58 = var53.getItemLabelFont(0, 5);
    java.awt.Stroke var59 = var53.getBaseStroke();
    java.awt.Paint var62 = var53.getItemPaint((-1), 0);
    var2.setBaseItemLabelPaint(var62);
    org.jfree.chart.labels.CategoryItemLabelGenerator var64 = null;
    var2.setBaseItemLabelGenerator(var64, false);
    java.lang.Boolean var68 = var2.getSeriesVisibleInLegend(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test64"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var1.setSeriesShape(100, var6, false);
    org.jfree.chart.entity.CategoryLabelEntity var11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var6, "", "0");
    java.lang.String var12 = var11.getShapeCoords();
    java.lang.String var13 = var11.toString();
    java.lang.String var14 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"+ "'", var12.equals("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=0"+ "'", var13.equals("CategoryLabelEntity: category=false, tooltip=, url=0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=0"+ "'", var14.equals("CategoryLabelEntity: category=false, tooltip=, url=0"));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test65"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var5 = var4.getMarkerBand();
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var4.refreshTicks(var7, var8, var9, var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    boolean var21 = var16.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var27 = var26.isNegativeArrowVisible();
    var26.setAutoRangeStickyZero(false);
    java.awt.Stroke var30 = var26.getTickMarkStroke();
    var22.setSeriesOutlineStroke(1, var30, false);
    boolean var34 = var22.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    var36.zoomRange((-1.0d), 0.0d);
    boolean var40 = var36.isPositiveArrowVisible();
    java.awt.Paint var41 = var36.getAxisLinePaint();
    var22.setBasePaint(var41);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var22.setBaseToolTipGenerator(var43);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var12, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    org.jfree.chart.ChartRenderingInfo var48 = null;
    org.jfree.chart.plot.PlotRenderingInfo var49 = new org.jfree.chart.plot.PlotRenderingInfo(var48);
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    boolean var62 = var50.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    java.awt.Paint var69 = var64.getAxisLinePaint();
    var50.setBasePaint(var69);
    boolean var71 = var49.equals((java.lang.Object)var69);
    var45.handleClick(0, 100, var49);
    java.awt.Stroke var73 = var45.getOutlineStroke();
    var4.setAxisLineStroke(var73);
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var77 = null;
    var76.addChangeListener(var77);
    java.awt.Shape var79 = var76.getRightArrow();
    var4.setRightArrow(var79);
    org.jfree.chart.entity.LegendItemEntity var81 = new org.jfree.chart.entity.LegendItemEntity(var79);
    java.lang.Comparable var82 = null;
    var81.setSeriesKey(var82);
    java.lang.Comparable var84 = var81.getSeriesKey();
    java.lang.Object var85 = var81.clone();
    org.jfree.data.general.Dataset var86 = null;
    var81.setDataset(var86);
    java.lang.String var88 = var81.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + "poly"+ "'", var88.equals("poly"));

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test66"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    java.awt.Paint var10 = var5.getAxisLinePaint();
    boolean var11 = var5.getAutoRangeStickyZero();
    var5.setLabelAngle((-1.0d));
    var5.setTickLabelsVisible(true);
    boolean var16 = var5.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    int var19 = var18.getColumnCount();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var18.setSeriesShape(100, var23, false);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var23, "", "0");
    var5.setDownArrow(var23);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    var30.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var30.setSeriesToolTipGenerator(1, var44);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var30.getLegendItemToolTipGenerator();
    var30.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
    var50.setHeight(100.0d);
    boolean var53 = var50.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var55 = var54.getErrorIndicatorPaint();
    var50.setPaint(var55);
    org.jfree.chart.ChartColor var60 = new org.jfree.chart.ChartColor(4, 1, 100);
    var50.setBackgroundPaint((java.awt.Paint)var60);
    var30.setBaseFillPaint((java.awt.Paint)var60, true);
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("poly", "ChartChangeEventType.GENERAL", "Size2D[width=-1.0, height=0.0]", "RangeType.FULL", var23, (java.awt.Paint)var60);
    boolean var65 = var64.isShapeOutlineVisible();
    int var66 = var64.getDatasetIndex();
    java.lang.String var67 = var64.getLabel();
    java.lang.Comparable var68 = var64.getSeriesKey();
    java.lang.String var69 = var64.getToolTipText();
    java.awt.Shape var70 = var64.getLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "poly"+ "'", var67.equals("poly"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "Size2D[width=-1.0, height=0.0]"+ "'", var69.equals("Size2D[width=-1.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test67"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Set var1 = var0.keySet();
    java.util.Set var2 = var0.keySet();
    java.lang.Object[][] var3 = var0.getContents();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject("RangeType.FULL");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test68"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    org.jfree.chart.util.SortOrder var47 = var33.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var50.setMaximumCategoryLabelLines(0);
    org.jfree.chart.JFreeChart var53 = null;
    org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var50, var53, 10, 100);
    java.awt.Font var57 = var50.getLabelFont();
    int var58 = var50.getMaximumCategoryLabelLines();
    var33.setDomainAxis(1, var50);
    float var60 = var33.getBackgroundImageAlpha();
    var33.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.axis.CategoryAxis var64 = var33.getDomainAxisForDataset(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test69"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getSeriesPositiveItemLabelPosition(100);
    java.awt.Paint var6 = var0.getBaseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test70"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("AxisLocation.BOTTOM_OR_LEFT");
    java.util.Locale var3 = var0.getLocale();
    java.util.Locale var4 = var0.getLocale();
    java.util.Enumeration var5 = var0.getKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test71"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    boolean var36 = var33.isRangeCrosshairVisible();
    var33.setRangeCrosshairVisible(false);
    org.jfree.data.category.CategoryDataset var40 = var33.getDataset(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test72"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var7 = var6.isNegativeArrowVisible();
    var6.setAutoRangeStickyZero(false);
    java.awt.Stroke var10 = var6.getTickMarkStroke();
    var2.setSeriesOutlineStroke(1, var10, false);
    boolean var14 = var2.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    var2.setBasePaint(var21);
    boolean var23 = var1.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.RendererState var24 = new org.jfree.chart.renderer.RendererState(var1);
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var26 = var25.getBackgroundPaint();
    java.awt.Paint var27 = var25.getPaint();
    java.awt.Font var28 = var25.getFont();
    boolean var29 = var1.equals((java.lang.Object)var25);
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
    int var33 = var32.getColumnCount();
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var37 = var36.isNegativeArrowVisible();
    var36.setAutoRangeStickyZero(false);
    java.awt.Stroke var40 = var36.getTickMarkStroke();
    var32.setSeriesOutlineStroke(1, var40, false);
    boolean var44 = var32.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
    var46.zoomRange((-1.0d), 0.0d);
    boolean var50 = var46.isPositiveArrowVisible();
    java.awt.Paint var51 = var46.getAxisLinePaint();
    var32.setBasePaint(var51);
    boolean var53 = var31.equals((java.lang.Object)var51);
    org.jfree.chart.renderer.RendererState var54 = new org.jfree.chart.renderer.RendererState(var31);
    int var55 = var31.getSubplotCount();
    var1.addSubplotInfo(var31);
    org.jfree.chart.renderer.category.CategoryItemRendererState var57 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var31);
    double var58 = var57.getBarWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test73"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    var1.resizeRange(4.0d);
    var1.setRange(6.0d, 6.0d);
    var1.setUpperMargin((-1.0d));
    double var14 = var1.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 6.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test74"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var0.set(4, (java.lang.Object)10.0d);
    int var5 = var0.size();
    java.lang.Object var6 = var0.clone();
    java.lang.Object var8 = var0.get(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test75"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
//     var0.add((java.lang.Number)Double.NaN, (java.lang.Number)Double.POSITIVE_INFINITY, (java.lang.Comparable)100.0f, (java.lang.Comparable)(-1L));
//     java.lang.Number var8 = null;
//     var0.add((java.lang.Number)(-1.0d), var8, (java.lang.Comparable)(-1), (java.lang.Comparable)(short)10);
//     org.jfree.data.KeyToGroupMap var12 = null;
//     org.jfree.data.Range var13 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var12);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test76"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    var0.clear();
    java.lang.Object var2 = null;
    boolean var3 = var0.equals(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test77"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    java.awt.Paint var10 = var5.getAxisLinePaint();
    boolean var11 = var5.getAutoRangeStickyZero();
    var5.setLabelAngle((-1.0d));
    var5.setTickLabelsVisible(true);
    boolean var16 = var5.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    int var19 = var18.getColumnCount();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var18.setSeriesShape(100, var23, false);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var23, "", "0");
    var5.setDownArrow(var23);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    var30.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var30.setSeriesToolTipGenerator(1, var44);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var30.getLegendItemToolTipGenerator();
    var30.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
    var50.setHeight(100.0d);
    boolean var53 = var50.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var55 = var54.getErrorIndicatorPaint();
    var50.setPaint(var55);
    org.jfree.chart.ChartColor var60 = new org.jfree.chart.ChartColor(4, 1, 100);
    var50.setBackgroundPaint((java.awt.Paint)var60);
    var30.setBaseFillPaint((java.awt.Paint)var60, true);
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("poly", "ChartChangeEventType.GENERAL", "Size2D[width=-1.0, height=0.0]", "RangeType.FULL", var23, (java.awt.Paint)var60);
    java.awt.Paint var65 = var64.getFillPaint();
    java.lang.Comparable var66 = var64.getSeriesKey();
    boolean var67 = var64.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test78"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    org.jfree.chart.ChartColor var43 = new org.jfree.chart.ChartColor(4, 1, 100);
    var33.setNoDataMessagePaint((java.awt.Paint)var43);
    int var45 = var43.getTransparency();
    org.jfree.chart.ui.BasicProjectInfo var51 = new org.jfree.chart.ui.BasicProjectInfo("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "1", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "", "AxisLocation.BOTTOM_OR_LEFT");
    org.jfree.chart.ui.Library var56 = new org.jfree.chart.ui.Library("ChartChangeEventType.GENERAL", "AxisLocation.BOTTOM_OR_LEFT", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "poly");
    var51.addLibrary(var56);
    boolean var58 = var43.equals((java.lang.Object)var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test79"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    java.lang.Object var1 = var0.clone();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Comparable var4 = null;
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var3, var4);
    org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, 0);
    org.jfree.data.general.PieDataset var10 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var7, (java.lang.Comparable)"CategoryLabelEntity: category=-1, tooltip=, url=ChartChangeEventType.GENERAL", 14.0d);
    org.jfree.data.category.CategoryDataset var11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)(-16777216), (org.jfree.data.KeyedValues)var7);
    boolean var12 = var0.equals((java.lang.Object)(-16777216));
    java.lang.Object var13 = var0.clone();
    org.jfree.chart.util.GradientPaintTransformType var14 = var0.getType();
    org.jfree.chart.util.StandardGradientPaintTransformer var15 = new org.jfree.chart.util.StandardGradientPaintTransformer(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test80"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var7 = var6.isNegativeArrowVisible();
    var6.setAutoRangeStickyZero(false);
    java.awt.Stroke var10 = var6.getTickMarkStroke();
    var2.setSeriesOutlineStroke(1, var10, false);
    boolean var14 = var2.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    var2.setBasePaint(var21);
    boolean var23 = var1.equals((java.lang.Object)var21);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    boolean var30 = var25.isInverted();
    var25.configure();
    var25.setAutoRangeIncludesZero(true);
    boolean var34 = var1.equals((java.lang.Object)true);
    int var35 = var1.getSubplotCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test81"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var1.set(4, (java.lang.Object)10.0d);
    var0.addObject((java.lang.Object)10.0d, (java.lang.Comparable)0.0f, (java.lang.Comparable)Double.POSITIVE_INFINITY);
    java.lang.Object var9 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var12 = var0.getObject(1, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test82"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    java.awt.Font var3 = var0.getFont();
    org.jfree.chart.util.HorizontalAlignment var4 = var0.getHorizontalAlignment();
    java.lang.String var5 = var0.getText();
    org.jfree.chart.util.VerticalAlignment var6 = var0.getVerticalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test83"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var1 = var0.getErrorIndicatorPaint();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    var4.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var14 = var13.isNegativeArrowVisible();
    var13.setAutoRangeStickyZero(false);
    java.awt.Stroke var17 = var13.getTickMarkStroke();
    var9.setSeriesOutlineStroke(1, var17, false);
    var4.setSeriesOutlineStroke(0, var17, false);
    var3.setAxisLineStroke(var17);
    var0.setErrorIndicatorStroke(var17);
    var0.setItemLabelAnchorOffset(2.0d);
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    var30.zoomRange((-1.0d), 0.0d);
    boolean var34 = var30.isPositiveArrowVisible();
    boolean var35 = var30.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    int var37 = var36.getColumnCount();
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var41 = var40.isNegativeArrowVisible();
    var40.setAutoRangeStickyZero(false);
    java.awt.Stroke var44 = var40.getTickMarkStroke();
    var36.setSeriesOutlineStroke(1, var44, false);
    boolean var48 = var36.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
    var50.zoomRange((-1.0d), 0.0d);
    boolean var54 = var50.isPositiveArrowVisible();
    java.awt.Paint var55 = var50.getAxisLinePaint();
    var36.setBasePaint(var55);
    org.jfree.chart.labels.CategoryToolTipGenerator var57 = null;
    var36.setBaseToolTipGenerator(var57);
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var26, var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
    var59.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var62 = null;
    var59.markerChanged(var62);
    boolean var64 = var59.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var65 = null;
    var59.markerChanged(var65);
    var59.setAnchorValue(0.0d);
    var59.mapDatasetToDomainAxis(0, 10);
    var59.setAnchorValue((-1.99999999d), false);
    boolean var75 = var59.isRangeCrosshairLockedOnData();
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test84"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    var1.centerRange(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test85"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.data.category.CategoryDataset var36 = var33.getDataset();
    int var37 = var33.getRangeAxisCount();
    org.jfree.chart.plot.PlotOrientation var38 = var33.getOrientation();
    org.jfree.chart.axis.CategoryAxis var39 = var33.getDomainAxis();
    var39.setAxisLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test86"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var2 = null;
    var1.addChangeListener(var2);
    java.awt.Shape var4 = var1.getRightArrow();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var7 = null;
    var6.addChangeListener(var7);
    java.awt.Shape var9 = var6.getRightArrow();
    var1.setRightArrow(var9);
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var9);
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity(var9, "CategoryLabelEntity: category=false, tooltip=, url=0");
    java.lang.String var14 = var13.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "poly"+ "'", var14.equals("poly"));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test87"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = var0.getToolTipGenerator(10, 10);
    java.awt.Paint var6 = var0.getItemPaint(0, 4);
    java.awt.Shape var7 = var0.getBaseShape();
    java.lang.Boolean var9 = var0.getSeriesItemLabelsVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test88"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextLine var1 = var0.getLastLine();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var3 = var2.getBackgroundPaint();
    java.awt.Paint var4 = var2.getPaint();
    boolean var5 = var2.getExpandToFitSpace();
    var2.setPadding(11.05d, (-1.0d), 0.2d, 11.05d);
    var2.setToolTipText("ChartChangeEventType.GENERAL");
    boolean var13 = var0.equals((java.lang.Object)"ChartChangeEventType.GENERAL");
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var17 = var16.getLabelTextAnchor();
    java.awt.Stroke var18 = var16.getStroke();
    org.jfree.chart.util.RectangleAnchor var19 = var16.getLabelAnchor();
    java.awt.Font var20 = var16.getLabelFont();
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var22 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var21.add((org.jfree.chart.block.Block)var22, (java.lang.Object)var23);
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    boolean var34 = var29.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
    int var36 = var35.getColumnCount();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var40 = var39.isNegativeArrowVisible();
    var39.setAutoRangeStickyZero(false);
    java.awt.Stroke var43 = var39.getTickMarkStroke();
    var35.setSeriesOutlineStroke(1, var43, false);
    boolean var47 = var35.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
    var49.zoomRange((-1.0d), 0.0d);
    boolean var53 = var49.isPositiveArrowVisible();
    java.awt.Paint var54 = var49.getAxisLinePaint();
    var35.setBasePaint(var54);
    org.jfree.chart.labels.CategoryToolTipGenerator var56 = null;
    var35.setBaseToolTipGenerator(var56);
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var25, var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
    var58.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var61 = null;
    var58.markerChanged(var61);
    org.jfree.chart.util.SortOrder var63 = var58.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var64 = new org.jfree.data.KeyedObjects();
    java.lang.Object var66 = var64.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var67 = null;
    org.jfree.chart.event.ChartProgressEvent var70 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var64, var67, 0, 0);
    boolean var71 = var58.equals((java.lang.Object)var67);
    java.awt.Paint var72 = var58.getOutlinePaint();
    var23.setErrorIndicatorPaint(var72);
    org.jfree.chart.renderer.category.BarRenderer var75 = new org.jfree.chart.renderer.category.BarRenderer();
    int var76 = var75.getColumnCount();
    var75.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var79 = var75.getBasePositiveItemLabelPosition();
    var23.setSeriesNegativeItemLabelPosition(4, var79, true);
    java.lang.Boolean var83 = var23.getSeriesVisibleInLegend(0);
    org.jfree.chart.renderer.category.BarRenderer var85 = new org.jfree.chart.renderer.category.BarRenderer();
    int var86 = var85.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var87 = var85.getLegendItemLabelGenerator();
    boolean var90 = var85.getItemVisible((-1), 1);
    java.awt.Paint var93 = var85.getItemFillPaint(100, (-1));
    var23.setSeriesItemLabelPaint(10, var93);
    var0.addLine("AxisLocation.BOTTOM_OR_RIGHT", var20, var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test89"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    org.jfree.chart.ChartColor var43 = new org.jfree.chart.ChartColor(4, 1, 100);
    var33.setNoDataMessagePaint((java.awt.Paint)var43);
    org.jfree.chart.axis.AxisLocation var45 = var33.getDomainAxisLocation();
    var33.setAnchorValue(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test90"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var5.zoomRange((-1.0d), 0.0d);
//     boolean var9 = var5.isPositiveArrowVisible();
//     java.awt.Paint var10 = var5.getAxisLinePaint();
//     boolean var11 = var5.getAutoRangeStickyZero();
//     var5.setLabelAngle((-1.0d));
//     var5.setTickLabelsVisible(true);
//     boolean var16 = var5.isVerticalTickLabels();
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var19 = var18.getColumnCount();
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var18.setSeriesShape(100, var23, false);
//     org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var23, "", "0");
//     var5.setDownArrow(var23);
//     org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var31 = var30.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var35 = var34.isNegativeArrowVisible();
//     var34.setAutoRangeStickyZero(false);
//     java.awt.Stroke var38 = var34.getTickMarkStroke();
//     var30.setSeriesOutlineStroke(1, var38, false);
//     var30.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
//     var30.setSeriesToolTipGenerator(1, var44);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var30.getLegendItemToolTipGenerator();
//     var30.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
//     var50.setHeight(100.0d);
//     boolean var53 = var50.getNotify();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Paint var55 = var54.getErrorIndicatorPaint();
//     var50.setPaint(var55);
//     org.jfree.chart.ChartColor var60 = new org.jfree.chart.ChartColor(4, 1, 100);
//     var50.setBackgroundPaint((java.awt.Paint)var60);
//     var30.setBaseFillPaint((java.awt.Paint)var60, true);
//     org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("poly", "ChartChangeEventType.GENERAL", "Size2D[width=-1.0, height=0.0]", "RangeType.FULL", var23, (java.awt.Paint)var60);
//     boolean var65 = var64.isShapeOutlineVisible();
//     int var66 = var64.getDatasetIndex();
//     java.lang.String var67 = var64.getToolTipText();
//     java.awt.Shape var68 = var64.getShape();
//     org.jfree.chart.renderer.category.BarRenderer var69 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var70 = var69.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var71 = var69.getLegendItemToolTipGenerator();
//     org.jfree.chart.renderer.category.BarRenderer var72 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var73 = var72.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var74 = var72.getLegendItemLabelGenerator();
//     var69.setLegendItemLabelGenerator(var74);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var78 = var69.getItemLabelGenerator(1, 4);
//     java.awt.Paint var80 = var69.getSeriesPaint(1);
//     org.jfree.chart.renderer.category.BarRenderer var81 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var84 = var81.getItemOutlinePaint(4, 10);
//     var69.setBasePaint(var84);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var86 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.DatasetGroup var87 = var86.getGroup();
//     var86.validateObject();
//     org.jfree.data.Range var89 = var69.findRangeBounds((org.jfree.data.category.CategoryDataset)var86);
//     var64.setDataset((org.jfree.data.general.Dataset)var86);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var72 and var18.", var72.equals(var18) == var18.equals(var72));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var81 and var18.", var81.equals(var18) == var18.equals(var81));
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test91"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var3 = var2.getBackgroundPaint();
//     java.awt.Paint var4 = var2.getPaint();
//     java.awt.Font var5 = var2.getFont();
//     org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("", var5);
//     java.awt.Font var7 = var6.getFont();
//     org.jfree.chart.text.TextFragment var8 = new org.jfree.chart.text.TextFragment("", var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextBlock var11 = null;
//     org.jfree.chart.text.TextBlockAnchor var12 = null;
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var15 = var14.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var17 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var11, var12, var15, 0.0d);
//     java.lang.Comparable var18 = var17.getCategory();
//     java.lang.String var19 = var17.toString();
//     org.jfree.chart.text.TextAnchor var20 = var17.getRotationAnchor();
//     org.jfree.chart.text.TextAnchor var21 = var17.getTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var23 = var22.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var27 = var26.isNegativeArrowVisible();
//     var26.setAutoRangeStickyZero(false);
//     java.awt.Stroke var30 = var26.getTickMarkStroke();
//     var22.setSeriesOutlineStroke(1, var30, false);
//     java.awt.Font var34 = var22.getSeriesItemLabelFont(100);
//     var22.setBaseSeriesVisible(false, false);
//     java.awt.Stroke var38 = var22.getBaseOutlineStroke();
//     java.lang.Boolean var40 = null;
//     var22.setSeriesCreateEntities(0, var40);
//     java.awt.Paint var43 = var22.lookupSeriesFillPaint(0);
//     var22.setIncludeBaseInRange(true);
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var51.zoomRange((-1.0d), 0.0d);
//     boolean var55 = var51.isPositiveArrowVisible();
//     boolean var56 = var51.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var58 = var57.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var62 = var61.isNegativeArrowVisible();
//     var61.setAutoRangeStickyZero(false);
//     java.awt.Stroke var65 = var61.getTickMarkStroke();
//     var57.setSeriesOutlineStroke(1, var65, false);
//     boolean var69 = var57.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var71.zoomRange((-1.0d), 0.0d);
//     boolean var75 = var71.isPositiveArrowVisible();
//     java.awt.Paint var76 = var71.getAxisLinePaint();
//     var57.setBasePaint(var76);
//     org.jfree.chart.labels.CategoryToolTipGenerator var78 = null;
//     var57.setBaseToolTipGenerator(var78);
//     org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot(var47, var49, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
//     var80.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var83 = null;
//     var80.markerChanged(var83);
//     org.jfree.data.general.DatasetGroup var85 = var80.getDatasetGroup();
//     org.jfree.chart.util.RectangleEdge var86 = var80.getDomainAxisEdge();
//     org.jfree.chart.ChartColor var90 = new org.jfree.chart.ChartColor(4, 1, 100);
//     java.awt.Color var91 = var90.brighter();
//     java.awt.Color var92 = var91.darker();
//     java.awt.color.ColorSpace var93 = var92.getColorSpace();
//     var80.setOutlinePaint((java.awt.Paint)var92);
//     var22.setSeriesItemLabelPaint(0, (java.awt.Paint)var92);
//     boolean var96 = var21.equals((java.lang.Object)0);
//     float var97 = var8.calculateBaselineOffset(var9, var21);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test92"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"0", var3, "0", "CategoryLabelEntity: category=false, tooltip=, url=0");
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Paint var9 = var8.getPaint();
    org.jfree.chart.title.LegendGraphic var10 = new org.jfree.chart.title.LegendGraphic(var3, var9);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    var11.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var18 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var11.setMargin(var18);
    double var21 = var18.calculateTopInset(0.0d);
    double var23 = var18.calculateBottomInset(10.0d);
    double var24 = var18.getLeft();
    var10.setPadding(var18);
    var10.setShapeOutlineVisible(true);
    java.awt.Paint var28 = var10.getOutlinePaint();
    boolean var29 = var10.isLineVisible();
    java.awt.Paint var30 = var10.getFillPaint();
    boolean var31 = var10.isLineVisible();
    java.lang.Object var32 = var10.clone();
    java.awt.Stroke var33 = var10.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test93"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.axis.AxisState var2 = new org.jfree.chart.axis.AxisState();
    var2.cursorDown(0.0d);
    java.util.List var5 = var2.getTicks();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    java.lang.String var8 = var7.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test94"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var2 = var1.getLabelTextAnchor();
    java.awt.Stroke var3 = null;
    var1.setOutlineStroke(var3);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    var10.zoomRange((-1.0d), 0.0d);
    boolean var14 = var10.isPositiveArrowVisible();
    boolean var15 = var10.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    int var17 = var16.getColumnCount();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var21 = var20.isNegativeArrowVisible();
    var20.setAutoRangeStickyZero(false);
    java.awt.Stroke var24 = var20.getTickMarkStroke();
    var16.setSeriesOutlineStroke(1, var24, false);
    boolean var28 = var16.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    var30.zoomRange((-1.0d), 0.0d);
    boolean var34 = var30.isPositiveArrowVisible();
    java.awt.Paint var35 = var30.getAxisLinePaint();
    var16.setBasePaint(var35);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var16.setBaseToolTipGenerator(var37);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.axis.AxisLocation var40 = var39.getDomainAxisLocation();
    java.lang.String var41 = var40.toString();
    org.jfree.chart.axis.AxisLocation var42 = var40.getOpposite();
    org.jfree.chart.axis.AxisLocation var43 = var40.getOpposite();
    var5.setDomainAxisLocation(var40);
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var46.setMaximumCategoryLabelLines(0);
    var46.setMaximumCategoryLabelLines((-1));
    var46.setMaximumCategoryLabelLines((-1));
    double var53 = var46.getCategoryMargin();
    var46.setLowerMargin(0.0d);
    double var56 = var46.getLabelAngle();
    var5.setDomainAxis(var46);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var5);
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var1.notifyListeners(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var41 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var41.equals("AxisLocation.BOTTOM_OR_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test95"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var4 = var3.isNegativeArrowVisible();
    var3.setAutoRangeStickyZero(false);
    java.awt.Stroke var7 = var3.getTickMarkStroke();
    var3.setAutoRangeMinimumSize(100.0d);
    var0.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var3, false);
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    int var15 = var14.getColumnCount();
    var14.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var18 = var14.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var19 = var18.getRotationAnchor();
    org.jfree.chart.text.TextBlock var21 = null;
    org.jfree.chart.text.TextBlockAnchor var22 = null;
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var25 = var24.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var27 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var21, var22, var25, 0.0d);
    java.lang.Comparable var28 = var27.getCategory();
    java.lang.String var29 = var27.toString();
    org.jfree.chart.text.TextAnchor var30 = var27.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var31 = var27.getTextAnchor();
    org.jfree.chart.axis.NumberTick var33 = new org.jfree.chart.axis.NumberTick((java.lang.Number)4, "", var19, var31, 6.0d);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var36 = var35.isNegativeArrowVisible();
    java.awt.Shape var37 = var35.getDownArrow();
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    int var43 = var42.getColumnCount();
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var42.setSeriesShape(100, var47, false);
    org.jfree.chart.entity.CategoryLabelEntity var52 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var47, "", "0");
    java.awt.Shape var53 = var52.getArea();
    boolean var54 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var40, (java.lang.Object)var53);
    boolean var55 = org.jfree.chart.util.ShapeUtilities.equal(var37, var53);
    boolean var56 = var33.equals((java.lang.Object)var53);
    var3.setDownArrow(var53);
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var60 = null;
    var59.addChangeListener(var60);
    java.awt.Shape var62 = var59.getRightArrow();
    org.jfree.chart.event.AxisChangeListener var63 = null;
    var59.addChangeListener(var63);
    org.jfree.data.Range var67 = new org.jfree.data.Range(0.0d, 0.0d);
    var59.setDefaultAutoRange(var67);
    org.jfree.data.Range var70 = org.jfree.data.Range.shift(var67, 10.0d);
    var3.setRangeWithMargins(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "1"+ "'", var28.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + ""+ "'", var29.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test96"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var7 = var6.isNegativeArrowVisible();
    var6.setAutoRangeStickyZero(false);
    java.awt.Stroke var10 = var6.getTickMarkStroke();
    var2.setSeriesOutlineStroke(1, var10, false);
    boolean var14 = var2.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    var2.setBasePaint(var21);
    boolean var23 = var1.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.RendererState var24 = new org.jfree.chart.renderer.RendererState(var1);
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var26 = var25.getBackgroundPaint();
    java.awt.Paint var27 = var25.getPaint();
    java.awt.Font var28 = var25.getFont();
    boolean var29 = var1.equals((java.lang.Object)var25);
    java.lang.Object var30 = var25.clone();
    java.lang.Object var31 = var25.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test97"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    int var4 = var3.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemLabelGenerator(var5);
    int var7 = var0.getColumnCount();
    boolean var8 = var0.getAutoPopulateSeriesOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test98"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    java.lang.String var36 = var33.getNoDataMessage();
    var33.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisState var39 = new org.jfree.chart.axis.AxisState();
    double var40 = var39.getCursor();
    java.util.List var41 = var39.getTicks();
    boolean var42 = var33.equals((java.lang.Object)var41);
    float var43 = var33.getBackgroundAlpha();
    org.jfree.chart.util.SortOrder var44 = var33.getColumnRenderingOrder();
    java.lang.String var45 = var44.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "SortOrder.ASCENDING"+ "'", var45.equals("SortOrder.ASCENDING"));

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test99"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var0.setBasePaint(var19);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var0.setBaseToolTipGenerator(var21);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    var27.zoomRange((-1.0d), 0.0d);
    boolean var31 = var27.isPositiveArrowVisible();
    boolean var32 = var27.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    int var34 = var33.getColumnCount();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var38 = var37.isNegativeArrowVisible();
    var37.setAutoRangeStickyZero(false);
    java.awt.Stroke var41 = var37.getTickMarkStroke();
    var33.setSeriesOutlineStroke(1, var41, false);
    boolean var45 = var33.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
    var47.zoomRange((-1.0d), 0.0d);
    boolean var51 = var47.isPositiveArrowVisible();
    java.awt.Paint var52 = var47.getAxisLinePaint();
    var33.setBasePaint(var52);
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var33.setBaseToolTipGenerator(var54);
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var23, var25, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
    var56.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var56.markerChanged(var59);
    var56.setForegroundAlpha(0.0f);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var56);
    boolean var64 = var56.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var66 = null;
    var56.setRangeAxis(1, var66, false);
    boolean var69 = var56.isDomainGridlinesVisible();
    java.lang.Object var70 = var56.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test100"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    int var4 = var3.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemLabelGenerator(var5);
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var0.getItemLabelGenerator(1, 4);
    java.awt.Paint var11 = var0.getSeriesPaint(1);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var15 = var12.getItemOutlinePaint(4, 10);
    var0.setBasePaint(var15);
    java.awt.Shape var18 = var0.lookupSeriesShape(1);
    java.awt.Paint var19 = var0.getBaseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test101"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var33.markerChanged(var36);
//     var33.setWeight((-1));
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
//     var40.setNotify(false);
//     var40.setBorderVisible(false);
//     org.jfree.chart.event.TitleChangeEvent var45 = null;
//     var40.titleChanged(var45);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test102"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    boolean var36 = var33.isRangeCrosshairVisible();
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    boolean var47 = var42.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    int var49 = var48.getColumnCount();
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var53 = var52.isNegativeArrowVisible();
    var52.setAutoRangeStickyZero(false);
    java.awt.Stroke var56 = var52.getTickMarkStroke();
    var48.setSeriesOutlineStroke(1, var56, false);
    boolean var60 = var48.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("hi!");
    var62.zoomRange((-1.0d), 0.0d);
    boolean var66 = var62.isPositiveArrowVisible();
    java.awt.Paint var67 = var62.getAxisLinePaint();
    var48.setBasePaint(var67);
    org.jfree.chart.labels.CategoryToolTipGenerator var69 = null;
    var48.setBaseToolTipGenerator(var69);
    org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var38, var40, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
    org.jfree.chart.axis.AxisLocation var72 = var71.getDomainAxisLocation();
    java.lang.String var73 = var72.toString();
    org.jfree.chart.axis.AxisLocation var74 = var72.getOpposite();
    org.jfree.chart.axis.AxisLocation var75 = var72.getOpposite();
    org.jfree.chart.axis.AxisLocation var76 = org.jfree.chart.axis.AxisLocation.getOpposite(var75);
    var33.setDomainAxisLocation(100, var75);
    org.jfree.chart.util.Layer var79 = null;
    java.util.Collection var80 = var33.getDomainMarkers(4, var79);
    float var81 = var33.getForegroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var73 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var73.equals("AxisLocation.BOTTOM_OR_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 1.0f);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test103"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(4);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test104"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var3 = var2.getMarkerBand();
    var2.configure();
    var2.setRangeWithMargins(10.0d, 100.0d);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var10 = null;
    var9.addChangeListener(var10);
    java.awt.Shape var12 = var9.getRightArrow();
    var2.setUpArrow(var12);
    org.jfree.data.Range var14 = var2.getRange();
    org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var14);
    org.jfree.data.Range var18 = org.jfree.data.Range.expand(var14, 14.0d, 10.0d);
    double var19 = var18.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-143.0d));

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test105"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var12, (-1), 10);
    var1.setPositiveArrowVisible(true);
    var1.resizeRange(6.0d, 0.0d);
    org.jfree.data.Range var21 = var1.getRange();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    int var30 = var29.getColumnCount();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var29.setSeriesShape(100, var34, false);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var34, "", "0");
    java.awt.Shape var40 = var39.getArea();
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)var40);
    var23.setDownArrow(var40);
    var1.setDownArrow(var40);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    boolean var53 = var48.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
    int var55 = var54.getColumnCount();
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var59 = var58.isNegativeArrowVisible();
    var58.setAutoRangeStickyZero(false);
    java.awt.Stroke var62 = var58.getTickMarkStroke();
    var54.setSeriesOutlineStroke(1, var62, false);
    boolean var66 = var54.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    var54.setBasePaint(var73);
    org.jfree.chart.labels.CategoryToolTipGenerator var75 = null;
    var54.setBaseToolTipGenerator(var75);
    org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot(var44, var46, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var54);
    var77.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var80 = null;
    var77.markerChanged(var80);
    org.jfree.chart.util.SortOrder var82 = var77.getRowRenderingOrder();
    var77.setRangeGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var86 = var85.getBackgroundPaint();
    java.awt.Paint var87 = var85.getPaint();
    var77.setDomainGridlinePaint(var87);
    org.jfree.chart.title.LegendGraphic var89 = new org.jfree.chart.title.LegendGraphic(var40, var87);
    org.jfree.chart.title.TextTitle var90 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var91 = var90.getBackgroundPaint();
    java.awt.Paint var92 = var90.getPaint();
    org.jfree.data.general.Dataset var93 = null;
    org.jfree.data.general.DatasetChangeEvent var94 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var92, var93);
    var89.setOutlinePaint(var92);
    org.jfree.chart.util.RectangleInsets var96 = var89.getMargin();
    var89.setShapeFilled(true);
    java.awt.Shape var99 = var89.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test106"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    java.awt.Shape var15 = var14.getArea();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var54 = var53.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var53.getRenderer(1);
    boolean var57 = var19.hasListener((java.util.EventListener)var53);
    java.lang.Comparable var59 = null;
    org.jfree.chart.entity.CategoryItemEntity var60 = new org.jfree.chart.entity.CategoryItemEntity(var15, "poly", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)(-1.0f), var59);
    org.jfree.data.category.CategoryDataset var61 = var60.getDataset();
    var60.setColumnKey((java.lang.Comparable)0.0f);
    org.jfree.data.category.CategoryDataset var64 = var60.getDataset();
    java.lang.String var65 = var60.getShapeCoords();
    var60.setColumnKey((java.lang.Comparable)0.2d);
    org.jfree.chart.block.BlockContainer var68 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.ColumnArrangement var69 = new org.jfree.chart.block.ColumnArrangement();
    var68.setArrangement((org.jfree.chart.block.Arrangement)var69);
    boolean var71 = var60.equals((java.lang.Object)var69);
    var69.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"+ "'", var65.equals("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test107"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    org.jfree.chart.util.RectangleAnchor var50 = null;
    var49.setLegendItemGraphicLocation(var50);
    org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var54 = var53.getBackgroundPaint();
    java.awt.Paint var55 = var53.getPaint();
    java.awt.Font var56 = var53.getFont();
    org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("0", var56);
    java.lang.String var58 = var57.getToolTipText();
    boolean var59 = var49.equals((java.lang.Object)var57);
    var57.setURLText("CategoryLabelEntity: category=false, tooltip=, url=0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test108"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.Number var4 = var0.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.clearCategoryLabelToolTips();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.isInverted();
    var9.configure();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var6, (org.jfree.chart.axis.ValueAxis)var9, var16);
    java.lang.Number var20 = var0.getValue((java.lang.Comparable)1, (java.lang.Comparable)"Range[0.0,0.0]");
    org.jfree.data.general.DatasetGroup var22 = new org.jfree.data.general.DatasetGroup("RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]");
    var0.setGroup(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test109"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    var33.configureDomainAxes();
    org.jfree.chart.util.SortOrder var40 = var33.getColumnRenderingOrder();
    org.jfree.chart.util.Size2D var43 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var43.setWidth((-1.0d));
    double var46 = var43.getHeight();
    double var47 = var43.getWidth();
    boolean var48 = var33.equals((java.lang.Object)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test110"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    java.lang.String var35 = var34.toString();
    org.jfree.chart.axis.AxisLocation var36 = var34.getOpposite();
    org.jfree.chart.axis.AxisLocation var37 = var34.getOpposite();
    org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var39 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var38.add((org.jfree.chart.block.Block)var39, (java.lang.Object)var40);
    boolean var42 = var34.equals((java.lang.Object)var40);
    boolean var43 = var40.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    int var45 = var44.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var44.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var47 = var44.getNegativeItemLabelPositionFallback();
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(0.2d);
    java.awt.Stroke var51 = var50.getOutlineStroke();
    var44.setSeriesStroke(5, var51);
    var40.setBaseStroke(var51, false);
    java.awt.Paint var56 = var40.getSeriesPaint((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var35.equals("AxisLocation.BOTTOM_OR_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test111"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var41 = var40.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAxis[] var42 = new org.jfree.chart.axis.CategoryAxis[] { var40};
    var33.setDomainAxes(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = var33.getRenderer();
    java.awt.Paint var45 = var33.getRangeGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test112"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    java.lang.String var3 = var0.getToolTipText();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var5 = var4.getBackgroundPaint();
    java.awt.Paint var6 = var4.getPaint();
    boolean var7 = var4.getExpandToFitSpace();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var9 = var8.getBackgroundPaint();
    java.awt.Paint var10 = var8.getPaint();
    java.awt.Font var11 = var8.getFont();
    org.jfree.chart.util.HorizontalAlignment var12 = var8.getHorizontalAlignment();
    var4.setHorizontalAlignment(var12);
    var0.setTextAlignment(var12);
    var0.setText("CategoryLabelEntity: category=-1, tooltip=, url=ChartChangeEventType.GENERAL");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test113"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    org.jfree.chart.LegendItemSource[] var50 = var49.getSources();
    org.jfree.chart.util.HorizontalAlignment var51 = var49.getHorizontalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test114"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    double var18 = var0.getBase();
    var0.setIncludeBaseInRange(true);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var22.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var25 = var22.getLabelInsets();
    org.jfree.chart.ChartRenderingInfo var26 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = new org.jfree.chart.plot.PlotRenderingInfo(var26);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    boolean var49 = var27.equals((java.lang.Object)var47);
    org.jfree.chart.renderer.RendererState var50 = new org.jfree.chart.renderer.RendererState(var27);
    java.awt.geom.Rectangle2D var51 = var27.getDataArea();
    java.awt.geom.Rectangle2D var52 = var25.createInsetRectangle(var51);
    var0.setBaseShape((java.awt.Shape)var51);
    org.jfree.chart.LegendItemCollection var54 = var0.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test115"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    var0.setBaseSeriesVisibleInLegend(false);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var0.getURLGenerator((-1), (-16514716));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test116"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();
    org.jfree.chart.block.Arrangement var2 = var0.getArrangement();
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("hi!");
    var7.zoomRange((-1.0d), 0.0d);
    boolean var11 = var7.isPositiveArrowVisible();
    boolean var12 = var7.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    int var14 = var13.getColumnCount();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var18 = var17.isNegativeArrowVisible();
    var17.setAutoRangeStickyZero(false);
    java.awt.Stroke var21 = var17.getTickMarkStroke();
    var13.setSeriesOutlineStroke(1, var21, false);
    boolean var25 = var13.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    var27.zoomRange((-1.0d), 0.0d);
    boolean var31 = var27.isPositiveArrowVisible();
    java.awt.Paint var32 = var27.getAxisLinePaint();
    var13.setBasePaint(var32);
    org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
    var13.setBaseToolTipGenerator(var34);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var3, var5, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    var36.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var36.markerChanged(var39);
    org.jfree.chart.util.SortOrder var41 = var36.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var42 = new org.jfree.data.KeyedObjects();
    java.lang.Object var44 = var42.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var45 = null;
    org.jfree.chart.event.ChartProgressEvent var48 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var42, var45, 0, 0);
    boolean var49 = var36.equals((java.lang.Object)var45);
    java.awt.Paint var50 = var36.getOutlinePaint();
    org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var54 = var53.getLabelOffset();
    java.awt.Paint var55 = var53.getOutlinePaint();
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("hi!");
    var57.zoomRange((-1.0d), 0.0d);
    boolean var61 = var57.isPositiveArrowVisible();
    boolean var62 = var57.isInverted();
    var57.configure();
    var57.setAutoRangeIncludesZero(true);
    double var66 = var57.getLowerMargin();
    boolean var67 = var53.equals((java.lang.Object)var66);
    org.jfree.chart.util.Layer var68 = null;
    var36.addRangeMarker(1, (org.jfree.chart.plot.Marker)var53, var68);
    boolean var70 = var0.equals((java.lang.Object)var53);
    java.awt.Graphics2D var71 = null;
    org.jfree.chart.text.TextFragment var73 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
    java.awt.Font var74 = var73.getFont();
    org.jfree.data.Range var75 = null;
    org.jfree.data.Range var76 = null;
    org.jfree.chart.block.RectangleConstraint var77 = new org.jfree.chart.block.RectangleConstraint(var75, var76);
    org.jfree.chart.block.RectangleConstraint var78 = var77.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var79 = var77.toUnconstrainedWidth();
    boolean var80 = var73.equals((java.lang.Object)var79);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var81 = var0.arrange(var71, var79);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test117"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Font var1 = var0.getNoDataMessageFont();
    var0.setRangeCrosshairValue((-1.0d));
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var6 = var5.getLabelOffset();
    java.awt.Paint var7 = var5.getOutlinePaint();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.isInverted();
    var9.configure();
    var9.setAutoRangeIncludesZero(true);
    double var18 = var9.getLowerMargin();
    boolean var19 = var5.equals((java.lang.Object)var18);
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    boolean var30 = var25.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    int var32 = var31.getColumnCount();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var36 = var35.isNegativeArrowVisible();
    var35.setAutoRangeStickyZero(false);
    java.awt.Stroke var39 = var35.getTickMarkStroke();
    var31.setSeriesOutlineStroke(1, var39, false);
    boolean var43 = var31.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
    var45.zoomRange((-1.0d), 0.0d);
    boolean var49 = var45.isPositiveArrowVisible();
    java.awt.Paint var50 = var45.getAxisLinePaint();
    var31.setBasePaint(var50);
    org.jfree.chart.labels.CategoryToolTipGenerator var52 = null;
    var31.setBaseToolTipGenerator(var52);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var21, var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    java.lang.String var56 = var23.getCategoryLabelToolTip((java.lang.Comparable)true);
    var0.setDomainAxis(var23);
    org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
    int var59 = var58.getColumnCount();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var63 = var62.isNegativeArrowVisible();
    var62.setAutoRangeStickyZero(false);
    java.awt.Stroke var66 = var62.getTickMarkStroke();
    var58.setSeriesOutlineStroke(1, var66, false);
    var58.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var72 = null;
    var58.setSeriesToolTipGenerator(1, var72);
    java.awt.Paint var75 = var58.getSeriesItemLabelPaint(0);
    var58.setBaseCreateEntities(true, true);
    java.awt.Stroke var80 = var58.lookupSeriesStroke((-33));
    var0.setDomainGridlineStroke(var80);
    java.awt.Font var82 = var0.getNoDataMessageFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test118"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var1.setSeriesShape(100, var6, false);
    org.jfree.chart.entity.CategoryLabelEntity var11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var6, "", "0");
    java.lang.String var12 = var11.getShapeCoords();
    java.lang.String var13 = var11.toString();
    var11.setURLText("CategoryLabelEntity: category=0, tooltip=0, url=CategoryLabelEntity: category=false, tooltip=, url=0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"+ "'", var12.equals("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=0"+ "'", var13.equals("CategoryLabelEntity: category=false, tooltip=, url=0"));

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test119"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var2.zoomRange((-1.0d), 0.0d);
//     var2.setPositiveArrowVisible(false);
//     double var8 = var2.getFixedAutoRange();
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var10 = var9.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var11 = var9.getLegendItemToolTipGenerator();
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var13 = var12.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var12.getLegendItemLabelGenerator();
//     var9.setLegendItemLabelGenerator(var14);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var9.getItemLabelGenerator(1, 4);
//     java.awt.Paint var20 = var9.getSeriesPaint(1);
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var24 = var21.getItemOutlinePaint(4, 10);
//     var9.setBasePaint(var24);
//     java.awt.Shape var27 = var9.lookupSeriesShape(1);
//     org.jfree.chart.entity.AxisLabelEntity var30 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var2, var27, "RectangleEdge.TOP", "Category Plot");
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var27, 4.0d, 0.5f, 100.0f);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test120"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.lang.String var2 = var1.getURLText();
    var1.setURLText("ChartChangeEventType.GENERAL");
    java.awt.Font var5 = var1.getFont();
    java.lang.Object var6 = null;
    boolean var7 = var1.equals(var6);
    org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var10 = var9.getLabelOffset();
    java.awt.Paint var11 = var9.getOutlinePaint();
    boolean var12 = var1.equals((java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test121"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var1 = var0.getCategoryAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test122"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    java.awt.Shape var15 = var14.getArea();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var54 = var53.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var53.getRenderer(1);
    boolean var57 = var19.hasListener((java.util.EventListener)var53);
    java.lang.Comparable var59 = null;
    org.jfree.chart.entity.CategoryItemEntity var60 = new org.jfree.chart.entity.CategoryItemEntity(var15, "poly", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)(-1.0f), var59);
    org.jfree.data.category.CategoryDataset var61 = var60.getDataset();
    var60.setColumnKey((java.lang.Comparable)0.0f);
    org.jfree.data.category.CategoryDataset var64 = var60.getDataset();
    java.lang.String var65 = var60.getShapeCoords();
    java.lang.Comparable var66 = var60.getRowKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"+ "'", var65.equals("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + (-1.0f)+ "'", var66.equals((-1.0f)));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test123"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    java.awt.Font var8 = null;
    var0.setBaseItemLabelFont(var8, true);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(100, var14, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = var0.getBaseToolTipGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var0.setSeriesURLGenerator(1, var19, false);
    java.awt.Stroke var23 = var0.getSeriesStroke(4);
    org.jfree.chart.labels.CategoryToolTipGenerator var25 = null;
    var0.setSeriesToolTipGenerator(255, var25);
    int var27 = var0.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test124"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    int var20 = var0.getRowCount();
    double var21 = var0.getItemMargin();
    var0.setSeriesItemLabelsVisible(4, (java.lang.Boolean)false);
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    boolean var34 = var29.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
    int var36 = var35.getColumnCount();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var40 = var39.isNegativeArrowVisible();
    var39.setAutoRangeStickyZero(false);
    java.awt.Stroke var43 = var39.getTickMarkStroke();
    var35.setSeriesOutlineStroke(1, var43, false);
    boolean var47 = var35.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
    var49.zoomRange((-1.0d), 0.0d);
    boolean var53 = var49.isPositiveArrowVisible();
    java.awt.Paint var54 = var49.getAxisLinePaint();
    var35.setBasePaint(var54);
    org.jfree.chart.labels.CategoryToolTipGenerator var56 = null;
    var35.setBaseToolTipGenerator(var56);
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var25, var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
    var58.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var61 = null;
    var58.markerChanged(var61);
    var58.setWeight((-1));
    org.jfree.chart.JFreeChart var65 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var58);
    var65.setNotify(false);
    var65.setBorderVisible(false);
    org.jfree.chart.event.ChartChangeEvent var70 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test125"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    java.awt.Font var12 = var0.getSeriesItemLabelFont(100);
    var0.setBaseSeriesVisible(false, false);
    java.awt.Stroke var16 = var0.getBaseOutlineStroke();
    org.jfree.chart.labels.CategoryItemLabelGenerator var17 = null;
    var0.setBaseItemLabelGenerator(var17);
    java.lang.Boolean var20 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.urls.CategoryURLGenerator var22 = null;
    var0.setSeriesURLGenerator(0, var22);
    var0.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = var28.getToolTipGenerator(10, 10);
    org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
    int var33 = var32.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var34 = var32.getLegendItemLabelGenerator();
    var28.setLegendItemToolTipGenerator(var34);
    java.awt.Paint var37 = var28.lookupSeriesPaint((-1));
    org.jfree.chart.labels.CategoryToolTipGenerator var39 = null;
    var28.setSeriesToolTipGenerator(10, var39);
    org.jfree.chart.labels.ItemLabelPosition var41 = var28.getBasePositiveItemLabelPosition();
    org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
    int var44 = var43.getColumnCount();
    var43.setBaseSeriesVisible(false);
    var43.setBaseSeriesVisible(true, true);
    java.awt.Paint var52 = var43.getItemOutlinePaint((-1), 0);
    java.awt.Shape var54 = var43.getSeriesShape(0);
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    var55.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.ItemLabelPosition var58 = null;
    var55.setPositiveItemLabelPositionFallback(var58);
    org.jfree.chart.labels.ItemLabelPosition var60 = var55.getBaseNegativeItemLabelPosition();
    var43.setBaseNegativeItemLabelPosition(var60);
    var28.setSeriesPositiveItemLabelPosition(0, var60);
    var0.setSeriesNegativeItemLabelPosition(15, var60, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var65 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)15);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test126"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.util.Size2D var4 = var0.arrange(var3);
    double var5 = var4.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test127"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    var33.setWeight((-1));
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    org.jfree.chart.event.ChartProgressListener var41 = null;
    var40.removeProgressListener(var41);
    var40.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.title.LegendTitle var45 = var40.getLegend();
    org.jfree.chart.util.RectangleInsets var46 = var45.getPadding();
    org.jfree.chart.renderer.category.BarRenderer var47 = new org.jfree.chart.renderer.category.BarRenderer();
    var47.setAutoPopulateSeriesFillPaint(true);
    java.awt.Font var52 = var47.getItemLabelFont(0, 5);
    java.awt.Stroke var53 = var47.getBaseStroke();
    java.awt.Paint var56 = var47.getItemPaint((-1), 0);
    org.jfree.chart.ChartColor var60 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var61 = var60.brighter();
    int var62 = var61.getGreen();
    var47.setBaseFillPaint((java.awt.Paint)var61);
    java.awt.Paint var64 = var47.getBaseOutlinePaint();
    var45.setItemPaint(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test128"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1L);
    org.jfree.chart.event.ChartChangeEventType var2 = var1.getType();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var5 = null;
    var4.addChangeListener(var5);
    java.awt.Shape var7 = var4.getRightArrow();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    org.jfree.chart.entity.CategoryLabelEntity var19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var14, "", "0");
    boolean var20 = org.jfree.chart.util.ShapeUtilities.equal(var7, var14);
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7);
    org.jfree.chart.event.ChartChangeEventType var22 = var21.getType();
    var1.setType(var22);
    org.jfree.chart.event.ChartChangeEventType var24 = var1.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test129"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    var33.clearAnnotations();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    boolean var48 = var42.getAutoRangeStickyZero();
    double var49 = var42.getUpperBound();
    var42.setTickLabelsVisible(true);
    java.awt.Paint var52 = var42.getLabelPaint();
    var33.setNoDataMessagePaint(var52);
    var33.setAnchorValue(11.05d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test130"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.setMaximumCategoryLabelLines(0);
    var2.setMaximumCategoryLabelLines((-1));
    var2.setMaximumCategoryLabelLines((-1));
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var12 = var11.getBackgroundPaint();
    java.awt.Paint var13 = var11.getPaint();
    java.awt.Font var14 = var11.getFont();
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var14);
    var2.setTickLabelFont((java.lang.Comparable)(byte)1, var14);
    org.jfree.data.general.DatasetGroup var18 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    int var20 = var19.getColumnCount();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var19.setSeriesShape(100, var24, false);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var28.setSeriesShape(100, var33, false);
    var19.setSeriesShape(1, var33);
    boolean var37 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var39 = var38.getBackgroundPaint();
    java.awt.Paint var40 = var38.getPaint();
    org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder(var40);
    var19.setBaseItemLabelPaint(var40, false);
    org.jfree.chart.block.LabelBlock var44 = new org.jfree.chart.block.LabelBlock("", var14, var40);
    java.lang.Object var45 = var44.clone();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var47 = var46.getErrorIndicatorPaint();
    var44.setPaint(var47);
    java.lang.String var49 = var44.getToolTipText();
    org.jfree.data.category.CategoryDataset var50 = null;
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    var54.zoomRange((-1.0d), 0.0d);
    boolean var58 = var54.isPositiveArrowVisible();
    boolean var59 = var54.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var60 = new org.jfree.chart.renderer.category.BarRenderer();
    int var61 = var60.getColumnCount();
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var65 = var64.isNegativeArrowVisible();
    var64.setAutoRangeStickyZero(false);
    java.awt.Stroke var68 = var64.getTickMarkStroke();
    var60.setSeriesOutlineStroke(1, var68, false);
    boolean var72 = var60.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("hi!");
    var74.zoomRange((-1.0d), 0.0d);
    boolean var78 = var74.isPositiveArrowVisible();
    java.awt.Paint var79 = var74.getAxisLinePaint();
    var60.setBasePaint(var79);
    org.jfree.chart.labels.CategoryToolTipGenerator var81 = null;
    var60.setBaseToolTipGenerator(var81);
    org.jfree.chart.plot.CategoryPlot var83 = new org.jfree.chart.plot.CategoryPlot(var50, var52, (org.jfree.chart.axis.ValueAxis)var54, (org.jfree.chart.renderer.category.CategoryItemRenderer)var60);
    var83.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var86 = null;
    var83.markerChanged(var86);
    var83.setWeight((-1));
    org.jfree.chart.JFreeChart var90 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var83);
    org.jfree.chart.event.ChartProgressListener var91 = null;
    var90.removeProgressListener(var91);
    var90.setBackgroundImageAlpha(100.0f);
    java.awt.Stroke var95 = var90.getBorderStroke();
    java.lang.Object var96 = var90.getTextAntiAlias();
    java.awt.Paint var97 = var90.getBorderPaint();
    var44.setPaint(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test131"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    var2.zoomRange((-1.0d), 0.0d);
    boolean var6 = var2.isPositiveArrowVisible();
    boolean var7 = var2.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var2.valueToJava2D(4.0d, var9, var10);
    org.jfree.chart.axis.NumberTickUnit var12 = var2.getTickUnit();
    boolean var13 = var0.equals((java.lang.Object)var2);
    var2.setLowerBound(0.2d);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    var20.zoomRange((-1.0d), 0.0d);
    boolean var24 = var20.isPositiveArrowVisible();
    boolean var25 = var20.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    boolean var38 = var26.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
    var40.zoomRange((-1.0d), 0.0d);
    boolean var44 = var40.isPositiveArrowVisible();
    java.awt.Paint var45 = var40.getAxisLinePaint();
    var26.setBasePaint(var45);
    org.jfree.chart.labels.CategoryToolTipGenerator var47 = null;
    var26.setBaseToolTipGenerator(var47);
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var16, var18, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
    var49.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var52 = null;
    var49.markerChanged(var52);
    org.jfree.chart.util.SortOrder var54 = var49.getRowRenderingOrder();
    var49.configureDomainAxes();
    org.jfree.chart.util.SortOrder var56 = var49.getColumnRenderingOrder();
    var2.setPlot((org.jfree.chart.plot.Plot)var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.zoomRange((-1.0d), (-12.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test132"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setHeight(100.0d);
    boolean var3 = var0.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var5 = var4.getErrorIndicatorPaint();
    var0.setPaint(var5);
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(4, 1, 100);
    var0.setBackgroundPaint((java.awt.Paint)var10);
    org.jfree.chart.block.BlockFrame var12 = var0.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test133"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine();
//     org.jfree.chart.text.TextFragment var2 = null;
//     var1.addFragment(var2);
//     org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets();
//     double var6 = var4.calculateBottomInset(0.0d);
//     boolean var7 = var1.equals((java.lang.Object)var6);
//     org.jfree.chart.text.TextFragment var8 = var1.getFirstTextFragment();
//     var0.addLine(var1);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("UnitType.ABSOLUTE");
//     var1.removeFragment(var11);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var17 = var16.getColumnCount();
//     var16.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var16.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var21 = var20.getRotationAnchor();
//     org.jfree.chart.text.TextAnchor var22 = var20.getRotationAnchor();
//     var1.draw(var13, 10.0f, 0.5f, var22, 0.0f, 0.0f, 10.0d);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test134"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var5 = var2.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var6 = var2.toUnconstrainedWidth();
    org.jfree.data.Range var7 = var6.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test135"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    var33.clearAnnotations();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    boolean var48 = var42.getAutoRangeStickyZero();
    double var49 = var42.getUpperBound();
    var42.setTickLabelsVisible(true);
    java.awt.Paint var52 = var42.getLabelPaint();
    var33.setNoDataMessagePaint(var52);
    java.awt.Paint var54 = var33.getOutlinePaint();
    java.awt.Stroke var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setRangeCrosshairStroke(var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test136"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var1.valueToJava2D(4.0d, var8, var9);
    var1.setUpperMargin(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test137"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.plot.CategoryPlot var34 = var10.getPlot();
    int var35 = var34.getDatasetCount();
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    int var37 = var36.getColumnCount();
    var36.setBaseSeriesVisible(false);
    var36.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
    int var44 = var43.getColumnCount();
    var43.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var48 = null;
    var43.setSeriesNegativeItemLabelPosition(100, var48, true);
    var43.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
    int var58 = var57.getColumnCount();
    var57.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var62 = new org.jfree.chart.renderer.category.BarRenderer();
    int var63 = var62.getColumnCount();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var67 = var66.isNegativeArrowVisible();
    var66.setAutoRangeStickyZero(false);
    java.awt.Stroke var70 = var66.getTickMarkStroke();
    var62.setSeriesOutlineStroke(1, var70, false);
    var57.setSeriesOutlineStroke(0, var70, false);
    var56.setAxisLineStroke(var70);
    var43.setBaseStroke(var70, true);
    var36.setSeriesOutlineStroke(0, var70, true);
    org.jfree.chart.block.FlowArrangement var80 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var81 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var80);
    org.jfree.chart.block.ColumnArrangement var82 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var83 = null;
    boolean var84 = var82.equals(var83);
    org.jfree.chart.title.LegendTitle var85 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var36, (org.jfree.chart.block.Arrangement)var80, (org.jfree.chart.block.Arrangement)var82);
    org.jfree.chart.axis.NumberAxis var87 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var88 = null;
    var87.addChangeListener(var88);
    java.awt.Shape var90 = var87.getRightArrow();
    org.jfree.data.Range var91 = var87.getDefaultAutoRange();
    boolean var92 = var80.equals((java.lang.Object)var87);
    var34.setRangeAxis((org.jfree.chart.axis.ValueAxis)var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test138"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    var2.zoomRange((-1.0d), 0.0d);
    boolean var6 = var2.isPositiveArrowVisible();
    boolean var7 = var2.getAutoRangeIncludesZero();
    var2.resizeRange(4.0d);
    double var10 = var2.getFixedDimension();
    boolean var11 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    var12.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var17 = var16.getMarkerBand();
    boolean var18 = var12.equals((java.lang.Object)var16);
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.axis.AxisState var20 = null;
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    java.util.List var23 = var16.refreshTicks(var19, var20, var21, var22);
    org.jfree.data.Range var24 = var16.getRange();
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    double var26 = var25.getContentXOffset();
    java.lang.Object var27 = var25.clone();
    boolean var28 = var24.equals((java.lang.Object)var25);
    var2.setRange(var24, true, false);
    org.jfree.chart.axis.MarkerAxisBand var32 = null;
    var2.setMarkerBand(var32);
    boolean var34 = var2.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test139"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.Number var4 = var0.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.clearCategoryLabelToolTips();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.isInverted();
    var9.configure();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var6, (org.jfree.chart.axis.ValueAxis)var9, var16);
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var17);
    int var19 = var18.getSubtitleCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test140"); }


    int var3 = java.awt.Color.HSBtoRGB(2.0f, (-1.0f), 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-524308));

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test141"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    var1.setBaseSeriesVisible(false);
    java.awt.Font var5 = var1.getBaseItemLabelFont();
    org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("RectangleEdge.BOTTOM", var5);
    java.awt.Font var7 = var6.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test142"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), (-1.0d));
    java.lang.Number var3 = var2.getMean();
    java.lang.Number var4 = var2.getStandardDeviation();
    java.lang.Number var5 = var2.getMean();
    java.lang.Number var6 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1.0d)+ "'", var4.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0d)+ "'", var5.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (-1.0d)+ "'", var6.equals((-1.0d)));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test143"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    var2.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var7 = var6.getMarkerBand();
    boolean var8 = var2.equals((java.lang.Object)var6);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var6.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.Range var14 = var6.getRange();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
    double var16 = var15.getContentXOffset();
    java.lang.Object var17 = var15.clone();
    boolean var18 = var14.equals((java.lang.Object)var15);
    var1.setRangeWithMargins(var14);
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var14, 0.0d);
    java.lang.String var22 = var21.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Range[0.0,1.0]"+ "'", var22.equals("Range[0.0,1.0]"));

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test144"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    java.lang.String var36 = var33.getNoDataMessage();
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var39.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var42 = var39.getLabelInsets();
    org.jfree.chart.ChartRenderingInfo var43 = null;
    org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
    org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
    int var46 = var45.getColumnCount();
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var50 = var49.isNegativeArrowVisible();
    var49.setAutoRangeStickyZero(false);
    java.awt.Stroke var53 = var49.getTickMarkStroke();
    var45.setSeriesOutlineStroke(1, var53, false);
    boolean var57 = var45.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("hi!");
    var59.zoomRange((-1.0d), 0.0d);
    boolean var63 = var59.isPositiveArrowVisible();
    java.awt.Paint var64 = var59.getAxisLinePaint();
    var45.setBasePaint(var64);
    boolean var66 = var44.equals((java.lang.Object)var64);
    org.jfree.chart.renderer.RendererState var67 = new org.jfree.chart.renderer.RendererState(var44);
    java.awt.geom.Rectangle2D var68 = var44.getDataArea();
    java.awt.geom.Rectangle2D var69 = var42.createInsetRectangle(var68);
    var33.drawBackgroundImage(var37, var69);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var73 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var74 = var73.getGroup();
    org.jfree.data.Range var75 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var73);
    boolean var76 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var73);
    var73.add(1.0E-8d, 1.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)0);
    org.jfree.chart.entity.CategoryItemEntity var84 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var69, "RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]", "CategoryLabelEntity: category=false, tooltip=, url=0", (org.jfree.data.category.CategoryDataset)var73, (java.lang.Comparable)Double.NaN, (java.lang.Comparable)(short)1);
    java.lang.Number var85 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var85 + "' != '" + 0.0d+ "'", var85.equals(0.0d));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test145"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    org.jfree.chart.axis.AxisSpace var35 = var33.getFixedRangeAxisSpace();
    org.jfree.chart.axis.CategoryAxis var37 = var33.getDomainAxis(0);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    boolean var47 = var42.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    int var49 = var48.getColumnCount();
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var53 = var52.isNegativeArrowVisible();
    var52.setAutoRangeStickyZero(false);
    java.awt.Stroke var56 = var52.getTickMarkStroke();
    var48.setSeriesOutlineStroke(1, var56, false);
    boolean var60 = var48.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("hi!");
    var62.zoomRange((-1.0d), 0.0d);
    boolean var66 = var62.isPositiveArrowVisible();
    java.awt.Paint var67 = var62.getAxisLinePaint();
    var48.setBasePaint(var67);
    org.jfree.chart.labels.CategoryToolTipGenerator var69 = null;
    var48.setBaseToolTipGenerator(var69);
    org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var38, var40, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
    var71.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var74 = null;
    var71.markerChanged(var74);
    var71.setWeight((-1));
    var37.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var71);
    boolean var79 = var71.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test146"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     var0.setRight(1.0d);
//     var0.setRight(1.0d);
//     java.lang.String var5 = var0.toString();
//     var0.setBottom(0.05d);
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     var8.setWidth(0.0d);
//     var8.setURLText("hi!");
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var15.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.util.RectangleInsets var18 = var15.getLabelInsets();
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var22 = var21.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var26 = var25.isNegativeArrowVisible();
//     var25.setAutoRangeStickyZero(false);
//     java.awt.Stroke var29 = var25.getTickMarkStroke();
//     var21.setSeriesOutlineStroke(1, var29, false);
//     boolean var33 = var21.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var35.zoomRange((-1.0d), 0.0d);
//     boolean var39 = var35.isPositiveArrowVisible();
//     java.awt.Paint var40 = var35.getAxisLinePaint();
//     var21.setBasePaint(var40);
//     boolean var42 = var20.equals((java.lang.Object)var40);
//     org.jfree.chart.renderer.RendererState var43 = new org.jfree.chart.renderer.RendererState(var20);
//     java.awt.geom.Rectangle2D var44 = var20.getDataArea();
//     java.awt.geom.Rectangle2D var45 = var18.createInsetRectangle(var44);
//     var8.draw(var13, var45);
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var51.zoomRange((-1.0d), 0.0d);
//     boolean var55 = var51.isPositiveArrowVisible();
//     boolean var56 = var51.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var58 = var57.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var62 = var61.isNegativeArrowVisible();
//     var61.setAutoRangeStickyZero(false);
//     java.awt.Stroke var65 = var61.getTickMarkStroke();
//     var57.setSeriesOutlineStroke(1, var65, false);
//     boolean var69 = var57.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var71.zoomRange((-1.0d), 0.0d);
//     boolean var75 = var71.isPositiveArrowVisible();
//     java.awt.Paint var76 = var71.getAxisLinePaint();
//     var57.setBasePaint(var76);
//     org.jfree.chart.labels.CategoryToolTipGenerator var78 = null;
//     var57.setBaseToolTipGenerator(var78);
//     org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot(var47, var49, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
//     var80.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var83 = null;
//     var80.markerChanged(var83);
//     org.jfree.data.general.DatasetGroup var85 = var80.getDatasetGroup();
//     org.jfree.chart.util.RectangleEdge var86 = var80.getDomainAxisEdge();
//     java.awt.geom.Rectangle2D var87 = var0.reserved(var45, var86);
//     org.jfree.chart.entity.ChartEntity var90 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var87, "ChartChangeEventType.GENERAL", "TextAnchor.CENTER");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var91 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var92 = null;
//     java.lang.String var93 = var90.getImageMapAreaTag(var91, var92);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test147"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var7 = var6.getErrorIndicatorPaint();
    var5.setBaseFillPaint(var7);
    java.awt.Paint var10 = var5.lookupSeriesPaint(255);
    var0.setSeriesFillPaint(0, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test148"); }


    java.awt.Font var1 = null;
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.lang.String var3 = var2.getText();
    java.awt.Paint var4 = var2.getPaint();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    var5.setHeight(100.0d);
    boolean var8 = var5.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var10 = var9.getErrorIndicatorPaint();
    var5.setPaint(var10);
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(4, 1, 100);
    var5.setBackgroundPaint((java.awt.Paint)var15);
    var2.setPaint((java.awt.Paint)var15);
    int var18 = var15.getAlpha();
    java.lang.String var19 = var15.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=-1, tooltip=, url=ChartChangeEventType.GENERAL", var1, (java.awt.Paint)var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "org.jfree.chart.ChartColor[r=4,g=1,b=100]"+ "'", var19.equals("org.jfree.chart.ChartColor[r=4,g=1,b=100]"));

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test149"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var34.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var37 = null;
    var34.markerChanged(var37);
    boolean var39 = var34.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.ValueAxis var40 = null;
    var34.setRangeAxis(var40);
    boolean var42 = var34.isRangeZoomable();
    java.lang.String var43 = var34.getPlotType();
    java.awt.Paint var44 = var34.getRangeGridlinePaint();
    org.jfree.data.KeyedObject var45 = new org.jfree.data.KeyedObject((java.lang.Comparable)"", (java.lang.Object)var44);
    java.lang.Object var46 = var45.getObject();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "Category Plot"+ "'", var43.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test150"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var7 = var6.isNegativeArrowVisible();
    var6.setAutoRangeStickyZero(false);
    java.awt.Stroke var10 = var6.getTickMarkStroke();
    var2.setSeriesOutlineStroke(1, var10, false);
    boolean var14 = var2.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    var2.setBasePaint(var21);
    boolean var23 = var1.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.RendererState var24 = new org.jfree.chart.renderer.RendererState(var1);
    java.awt.geom.Rectangle2D var25 = null;
    var1.setDataArea(var25);
    org.jfree.chart.renderer.category.CategoryItemRendererState var27 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var1);
    double var28 = var27.getSeriesRunningTotal();
    var27.setBarWidth((-2.5d));
    var27.setBarWidth(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test151"); }


    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var3 = var2.getBackgroundPaint();
    java.awt.Paint var4 = var2.getPaint();
    java.awt.Font var5 = var2.getFont();
    org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("", var5);
    java.awt.Font var7 = var6.getFont();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle("ChartChangeEventType.GENERAL", var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test152"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    boolean var7 = var1.getAutoRangeStickyZero();
    var1.setLabelAngle((-1.0d));
    var1.setTickLabelsVisible(true);
    boolean var12 = var1.isVerticalTickLabels();
    boolean var13 = var1.isVerticalTickLabels();
    var1.resizeRange(20.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test153"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.plot.Plot var34 = var4.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test154"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.add((org.jfree.chart.block.Block)var1, (java.lang.Object)var2);
    org.jfree.chart.LegendItemCollection var4 = var2.getLegendItems();
    org.jfree.chart.LegendItem var5 = null;
    var4.add(var5);
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("hi!");
    var11.zoomRange((-1.0d), 0.0d);
    boolean var15 = var11.isPositiveArrowVisible();
    boolean var16 = var11.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
    int var18 = var17.getColumnCount();
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var22 = var21.isNegativeArrowVisible();
    var21.setAutoRangeStickyZero(false);
    java.awt.Stroke var25 = var21.getTickMarkStroke();
    var17.setSeriesOutlineStroke(1, var25, false);
    boolean var29 = var17.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("hi!");
    var31.zoomRange((-1.0d), 0.0d);
    boolean var35 = var31.isPositiveArrowVisible();
    java.awt.Paint var36 = var31.getAxisLinePaint();
    var17.setBasePaint(var36);
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = null;
    var17.setBaseToolTipGenerator(var38);
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var7, var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
    var40.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var43 = null;
    var40.markerChanged(var43);
    org.jfree.chart.util.SortOrder var45 = var40.getRowRenderingOrder();
    var40.setRangeGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var49 = var48.getBackgroundPaint();
    java.awt.Paint var50 = var48.getPaint();
    var40.setDomainGridlinePaint(var50);
    org.jfree.chart.LegendItemCollection var52 = var40.getLegendItems();
    java.lang.Object var53 = null;
    boolean var54 = var52.equals(var53);
    var4.addAll(var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var57 = var4.get(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test155"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((java.lang.Comparable)1);
    java.lang.Object var3 = var0.clone();
    int var4 = var0.getItemCount();
    org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(14.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)14.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test156"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    double var18 = var0.getBase();
    java.awt.Paint var21 = var0.getItemOutlinePaint(0, (-1));
    boolean var22 = var0.isDrawBarOutline();
    double var23 = var0.getLowerClip();
    org.jfree.chart.util.GradientPaintTransformer var24 = var0.getGradientPaintTransformer();
    var0.setBaseItemLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test157"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var1, var2, var5, 0.0d);
    double var8 = var7.getAngle();
    org.jfree.chart.text.TextAnchor var9 = var7.getTextAnchor();
    org.jfree.chart.text.TextAnchor var10 = var7.getTextAnchor();
    org.jfree.chart.text.TextBlockAnchor var11 = var7.getLabelAnchor();
    org.jfree.chart.text.TextBlock var12 = var7.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test158"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    java.awt.Font var8 = null;
    var0.setBaseItemLabelFont(var8, true);
    var0.setBaseSeriesVisibleInLegend(true);
    java.awt.Paint var13 = var0.getBasePaint();
    org.jfree.chart.labels.ItemLabelPosition var14 = null;
    var0.setNegativeItemLabelPositionFallback(var14);
    int var16 = var0.getPassCount();
    var0.setBaseItemLabelsVisible(false);
    java.awt.Stroke var19 = var0.getBaseOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test159"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var5 = var4.getBackgroundPaint();
    java.awt.Paint var6 = var4.getPaint();
    var1.setTickLabelPaint(var6);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    int var9 = var8.getColumnCount();
    var8.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = null;
    var8.setSeriesNegativeItemLabelPosition(100, var13, true);
    var8.setSeriesVisible(100, (java.lang.Boolean)false, true);
    boolean var22 = var8.isItemLabelVisible(10, 1);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    var27.zoomRange((-1.0d), 0.0d);
    boolean var31 = var27.isPositiveArrowVisible();
    boolean var32 = var27.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    int var34 = var33.getColumnCount();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var38 = var37.isNegativeArrowVisible();
    var37.setAutoRangeStickyZero(false);
    java.awt.Stroke var41 = var37.getTickMarkStroke();
    var33.setSeriesOutlineStroke(1, var41, false);
    boolean var45 = var33.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
    var47.zoomRange((-1.0d), 0.0d);
    boolean var51 = var47.isPositiveArrowVisible();
    java.awt.Paint var52 = var47.getAxisLinePaint();
    var33.setBasePaint(var52);
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var33.setBaseToolTipGenerator(var54);
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var23, var25, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
    var56.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var56.markerChanged(var59);
    org.jfree.chart.util.SortOrder var61 = var56.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var62 = new org.jfree.data.KeyedObjects();
    java.lang.Object var64 = var62.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var65 = null;
    org.jfree.chart.event.ChartProgressEvent var68 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var62, var65, 0, 0);
    boolean var69 = var56.equals((java.lang.Object)var65);
    java.awt.Paint var70 = var56.getOutlinePaint();
    var8.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var56);
    var1.setPlot((org.jfree.chart.plot.Plot)var56);
    org.jfree.chart.util.HorizontalAlignment var73 = null;
    org.jfree.chart.util.VerticalAlignment var74 = null;
    org.jfree.chart.block.FlowArrangement var77 = new org.jfree.chart.block.FlowArrangement(var73, var74, 100.0d, Double.POSITIVE_INFINITY);
    org.jfree.chart.block.ColumnArrangement var78 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var79 = null;
    org.jfree.chart.axis.AxisState var80 = new org.jfree.chart.axis.AxisState();
    var80.cursorDown(0.0d);
    java.util.List var83 = var80.getTicks();
    var78.add(var79, (java.lang.Object)var80);
    org.jfree.chart.title.LegendTitle var85 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56, (org.jfree.chart.block.Arrangement)var77, (org.jfree.chart.block.Arrangement)var78);
    java.awt.Graphics2D var86 = null;
    org.jfree.data.Range var87 = null;
    org.jfree.data.Range var88 = null;
    org.jfree.chart.block.RectangleConstraint var89 = new org.jfree.chart.block.RectangleConstraint(var87, var88);
    org.jfree.chart.block.RectangleConstraint var90 = var89.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var91 = var89.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var92 = var89.getHeightConstraintType();
    org.jfree.chart.block.LengthConstraintType var93 = var89.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var95 = var89.toFixedWidth(100.0d);
    org.jfree.chart.util.Size2D var96 = var85.arrange(var86, var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test160"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    java.lang.String var3 = var0.getToolTipText();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var5 = var4.getBackgroundPaint();
    java.awt.Paint var6 = var4.getPaint();
    boolean var7 = var4.getExpandToFitSpace();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var9 = var8.getBackgroundPaint();
    java.awt.Paint var10 = var8.getPaint();
    java.awt.Font var11 = var8.getFont();
    org.jfree.chart.util.HorizontalAlignment var12 = var8.getHorizontalAlignment();
    var4.setHorizontalAlignment(var12);
    var0.setTextAlignment(var12);
    java.awt.geom.Rectangle2D var15 = var0.getBounds();
    var0.setExpandToFitSpace(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test161"); }


    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    var2.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
    org.jfree.chart.text.TextBlock var9 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var13 = var12.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var9, var10, var13, 0.0d);
    java.lang.Comparable var16 = var15.getCategory();
    java.lang.String var17 = var15.toString();
    org.jfree.chart.text.TextAnchor var18 = var15.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var19 = var15.getTextAnchor();
    org.jfree.chart.axis.NumberTick var21 = new org.jfree.chart.axis.NumberTick((java.lang.Number)4, "", var7, var19, 6.0d);
    org.jfree.chart.axis.AxisSpace var22 = new org.jfree.chart.axis.AxisSpace();
    var22.setBottom(10.0d);
    var22.setTop(0.0d);
    org.jfree.chart.ChartRenderingInfo var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = new org.jfree.chart.plot.PlotRenderingInfo(var27);
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    int var30 = var29.getColumnCount();
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var34 = var33.isNegativeArrowVisible();
    var33.setAutoRangeStickyZero(false);
    java.awt.Stroke var37 = var33.getTickMarkStroke();
    var29.setSeriesOutlineStroke(1, var37, false);
    boolean var41 = var29.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    var43.zoomRange((-1.0d), 0.0d);
    boolean var47 = var43.isPositiveArrowVisible();
    java.awt.Paint var48 = var43.getAxisLinePaint();
    var29.setBasePaint(var48);
    boolean var50 = var28.equals((java.lang.Object)var48);
    org.jfree.chart.renderer.RendererState var51 = new org.jfree.chart.renderer.RendererState(var28);
    java.awt.geom.Rectangle2D var52 = var28.getDataArea();
    org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var54.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var57 = var54.getLabelInsets();
    org.jfree.chart.ChartRenderingInfo var58 = null;
    org.jfree.chart.plot.PlotRenderingInfo var59 = new org.jfree.chart.plot.PlotRenderingInfo(var58);
    org.jfree.chart.renderer.category.BarRenderer var60 = new org.jfree.chart.renderer.category.BarRenderer();
    int var61 = var60.getColumnCount();
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var65 = var64.isNegativeArrowVisible();
    var64.setAutoRangeStickyZero(false);
    java.awt.Stroke var68 = var64.getTickMarkStroke();
    var60.setSeriesOutlineStroke(1, var68, false);
    boolean var72 = var60.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("hi!");
    var74.zoomRange((-1.0d), 0.0d);
    boolean var78 = var74.isPositiveArrowVisible();
    java.awt.Paint var79 = var74.getAxisLinePaint();
    var60.setBasePaint(var79);
    boolean var81 = var59.equals((java.lang.Object)var79);
    org.jfree.chart.renderer.RendererState var82 = new org.jfree.chart.renderer.RendererState(var59);
    java.awt.geom.Rectangle2D var83 = var59.getDataArea();
    java.awt.geom.Rectangle2D var84 = var57.createInsetRectangle(var83);
    java.awt.geom.Rectangle2D var85 = var22.expand(var52, var83);
    var22.setRight(11.05d);
    double var88 = var22.getLeft();
    boolean var89 = var21.equals((java.lang.Object)var22);
    java.lang.Number var90 = var21.getNumber();
    double var91 = var21.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "1"+ "'", var16.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var90 + "' != '" + 4+ "'", var90.equals(4));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 6.0d);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test162"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    var1.setLabelAngle(6.0d);
    org.jfree.chart.axis.MarkerAxisBand var5 = var1.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test163"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    int var4 = var3.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = var3.getLegendItemLabelGenerator();
    var0.setLegendItemLabelGenerator(var5);
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var0.getItemLabelGenerator(1, 4);
    var0.setBaseItemLabelsVisible(true, false);
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    int var15 = var14.getColumnCount();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var19 = var18.isNegativeArrowVisible();
    var18.setAutoRangeStickyZero(false);
    java.awt.Stroke var22 = var18.getTickMarkStroke();
    var14.setSeriesOutlineStroke(1, var22, false);
    java.awt.Font var26 = var14.getSeriesItemLabelFont(100);
    var14.setBaseSeriesVisible(false, false);
    java.awt.Stroke var30 = var14.getBaseOutlineStroke();
    java.lang.Boolean var32 = null;
    var14.setSeriesCreateEntities(0, var32);
    java.awt.Paint var35 = var14.lookupSeriesFillPaint(0);
    var14.setIncludeBaseInRange(true);
    org.jfree.data.category.CategoryDataset var39 = null;
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    var43.zoomRange((-1.0d), 0.0d);
    boolean var47 = var43.isPositiveArrowVisible();
    boolean var48 = var43.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
    int var50 = var49.getColumnCount();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var54 = var53.isNegativeArrowVisible();
    var53.setAutoRangeStickyZero(false);
    java.awt.Stroke var57 = var53.getTickMarkStroke();
    var49.setSeriesOutlineStroke(1, var57, false);
    boolean var61 = var49.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("hi!");
    var63.zoomRange((-1.0d), 0.0d);
    boolean var67 = var63.isPositiveArrowVisible();
    java.awt.Paint var68 = var63.getAxisLinePaint();
    var49.setBasePaint(var68);
    org.jfree.chart.labels.CategoryToolTipGenerator var70 = null;
    var49.setBaseToolTipGenerator(var70);
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var39, var41, (org.jfree.chart.axis.ValueAxis)var43, (org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
    var72.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var75 = null;
    var72.markerChanged(var75);
    org.jfree.data.general.DatasetGroup var77 = var72.getDatasetGroup();
    org.jfree.chart.util.RectangleEdge var78 = var72.getDomainAxisEdge();
    org.jfree.chart.ChartColor var82 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var83 = var82.brighter();
    java.awt.Color var84 = var83.darker();
    java.awt.color.ColorSpace var85 = var84.getColorSpace();
    var72.setOutlinePaint((java.awt.Paint)var84);
    var14.setSeriesItemLabelPaint(0, (java.awt.Paint)var84);
    var0.setSeriesPaint(15, (java.awt.Paint)var84);
    java.awt.Color var89 = var84.darker();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test164"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.axis.TickUnits var1 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1L);
    java.lang.Object var4 = var3.getSource();
    boolean var5 = var1.equals(var4);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var7.setMaximumCategoryLabelLines(0);
    var7.setMaximumCategoryLabelLines((-1));
    var7.setUpperMargin(1.0d);
    boolean var14 = var1.equals((java.lang.Object)var7);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    boolean var22 = var16.getAutoRangeStickyZero();
    double var23 = var16.getUpperBound();
    org.jfree.chart.event.AxisChangeListener var24 = null;
    var16.addChangeListener(var24);
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var7, (org.jfree.chart.axis.ValueAxis)var16, var26);
    var27.setAnchorValue(0.0d);
    var27.setRangeCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1L+ "'", var4.equals(1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test165"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    org.jfree.chart.util.RectangleAnchor var50 = null;
    var49.setLegendItemGraphicLocation(var50);
    org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var54 = var53.getBackgroundPaint();
    java.awt.Paint var55 = var53.getPaint();
    java.awt.Font var56 = var53.getFont();
    org.jfree.chart.block.LabelBlock var57 = new org.jfree.chart.block.LabelBlock("0", var56);
    java.lang.String var58 = var57.getToolTipText();
    boolean var59 = var49.equals((java.lang.Object)var57);
    org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle();
    double var61 = var60.getContentXOffset();
    java.lang.String var62 = var60.getURLText();
    java.awt.Paint var63 = var60.getPaint();
    var49.setBackgroundPaint(var63);
    org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var66.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var69 = var66.getLabelInsets();
    org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
    java.awt.Font var73 = var72.getFont();
    var66.setTickLabelFont((java.lang.Comparable)0.0d, var73);
    var49.setItemFont(var73);
    org.jfree.chart.block.BlockContainer var76 = null;
    var49.setWrapper(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test166"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelInsets();
    boolean var4 = var1.isNegativeArrowVisible();
    var1.setUpperBound(0.0d);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var8.setMaximumCategoryLabelLines(0);
    var8.setMaximumCategoryLabelLines((-1));
    var8.setMaximumCategoryLabelLines((-1));
    double var15 = var8.getCategoryMargin();
    var8.setMaximumCategoryLabelWidthRatio(100.0f);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    var19.zoomRange((-1.0d), 0.0d);
    boolean var23 = var19.isPositiveArrowVisible();
    boolean var24 = var19.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var19.valueToJava2D(4.0d, var26, var27);
    org.jfree.chart.axis.NumberTickUnit var30 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var32 = var30.valueToString(0.0d);
    var19.setTickUnit(var30, true, true);
    java.awt.Font var36 = var8.getTickLabelFont((java.lang.Comparable)var30);
    var1.setTickUnit(var30);
    var1.zoomRange((-12.0d), 1.0d);
    org.jfree.chart.axis.NumberTickUnit var41 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "0"+ "'", var32.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test167"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    int var1 = var0.size();
    int var2 = var0.size();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    int var4 = var3.getColumnCount();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var3.setSeriesShape(100, var8, false);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    int var13 = var12.getColumnCount();
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var12.setSeriesShape(100, var17, false);
    var3.setSeriesShape(1, var17);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    boolean var30 = var25.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    int var32 = var31.getColumnCount();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var36 = var35.isNegativeArrowVisible();
    var35.setAutoRangeStickyZero(false);
    java.awt.Stroke var39 = var35.getTickMarkStroke();
    var31.setSeriesOutlineStroke(1, var39, false);
    boolean var43 = var31.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
    var45.zoomRange((-1.0d), 0.0d);
    boolean var49 = var45.isPositiveArrowVisible();
    java.awt.Paint var50 = var45.getAxisLinePaint();
    var31.setBasePaint(var50);
    org.jfree.chart.labels.CategoryToolTipGenerator var52 = null;
    var31.setBaseToolTipGenerator(var52);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var21, var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    var3.setPlot(var54);
    org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var58.setMaximumCategoryLabelLines(0);
    var58.setMaximumCategoryLabelLines((-1));
    var58.setMaximumCategoryLabelLines((-1));
    double var65 = var58.getCategoryMargin();
    org.jfree.chart.axis.CategoryLabelPositions var66 = var58.getCategoryLabelPositions();
    var54.setDomainAxis(100, var58, false);
    var58.setLabelURL("RectangleInsets[t=10.0,l=1.0,b=-1.0,r=10.0]");
    var58.setLabelURL("ChartChangeEventType.GENERAL");
    boolean var73 = var0.equals((java.lang.Object)"ChartChangeEventType.GENERAL");
    java.lang.Boolean var75 = var0.getBoolean((-524308));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test168"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Number var42 = var0.getValue((java.lang.Comparable)1.0d, (java.lang.Comparable)(short)10);
    org.jfree.data.general.PieDataset var44 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)0.5f);
    org.jfree.data.general.PieDataset var47 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var44, (java.lang.Comparable)"org.jfree.chart.ChartColor[r=4,g=1,b=100]", 102.0d);
    java.lang.Comparable var48 = null;
    org.jfree.data.general.PieDataset var50 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var44, var48, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test169"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker((-20.0d));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test170"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.KeyedObjects2D var6 = new org.jfree.data.KeyedObjects2D();
    java.util.List var7 = var6.getColumnKeys();
    var6.removeColumn((java.lang.Comparable)"ChartChangeEventType.GENERAL");
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("hi!");
    var12.zoomRange((-1.0d), 0.0d);
    boolean var16 = var12.isPositiveArrowVisible();
    boolean var17 = var12.isInverted();
    var12.configure();
    var12.setAutoRangeIncludesZero(true);
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.util.RectangleEdge var23 = null;
    double var24 = var12.valueToJava2D(100.0d, var22, var23);
    org.jfree.chart.axis.MarkerAxisBand var25 = var12.getMarkerBand();
    boolean var26 = var12.isAxisLineVisible();
    org.jfree.chart.axis.TickUnits var27 = new org.jfree.chart.axis.TickUnits();
    java.lang.Object var28 = null;
    boolean var29 = var27.equals(var28);
    var12.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource)var27);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Comparable var32 = null;
    org.jfree.data.general.PieDataset var33 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var31, var32);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    var35.zoomRange((-1.0d), 0.0d);
    boolean var39 = var35.isPositiveArrowVisible();
    java.awt.Paint var40 = var35.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var41 = var35.getTickLabelInsets();
    org.jfree.chart.axis.NumberTickUnit var42 = var35.getTickUnit();
    org.jfree.data.general.PieDataset var45 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var33, (java.lang.Comparable)var42, 1.0d, 1);
    var27.add((org.jfree.chart.axis.TickUnit)var42);
    java.lang.Object var47 = var6.getObject((java.lang.Comparable)2.0f, (java.lang.Comparable)var42);
    var0.add((-4.0d), 14.0d, (java.lang.Comparable)(byte)0, (java.lang.Comparable)var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test171"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    var33.setWeight((-1));
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    java.lang.Object var41 = var40.getTextAntiAlias();
    var40.setBackgroundImageAlignment((-16777216));
    org.jfree.chart.event.ChartProgressListener var44 = null;
    var40.removeProgressListener(var44);
    var40.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test172"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var0.setBasePaint(var19);
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var0.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    boolean var33 = var28.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var39 = var38.isNegativeArrowVisible();
    var38.setAutoRangeStickyZero(false);
    java.awt.Stroke var42 = var38.getTickMarkStroke();
    var34.setSeriesOutlineStroke(1, var42, false);
    boolean var46 = var34.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    java.awt.Paint var53 = var48.getAxisLinePaint();
    var34.setBasePaint(var53);
    org.jfree.chart.labels.CategoryToolTipGenerator var55 = null;
    var34.setBaseToolTipGenerator(var55);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var24, var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    var57.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var60 = null;
    var57.markerChanged(var60);
    org.jfree.chart.util.SortOrder var62 = var57.getRowRenderingOrder();
    boolean var63 = var0.hasListener((java.util.EventListener)var57);
    org.jfree.chart.LegendItem var66 = var0.getLegendItem(0, 1);
    org.jfree.chart.renderer.category.BarRenderer var67 = new org.jfree.chart.renderer.category.BarRenderer();
    int var68 = var67.getColumnCount();
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var72 = var71.isNegativeArrowVisible();
    var71.setAutoRangeStickyZero(false);
    java.awt.Stroke var75 = var71.getTickMarkStroke();
    var67.setSeriesOutlineStroke(1, var75, false);
    var67.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var81 = null;
    var67.setSeriesToolTipGenerator(1, var81);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var83 = var67.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var86 = var67.getPositiveItemLabelPosition(10, (-1));
    var0.setNegativeItemLabelPositionFallback(var86);
    java.awt.Font var90 = var0.getItemLabelFont((-1), (-16579997));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test173"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.isInverted();
    var1.configure();
    var1.setAutoRangeIncludesZero(true);
    var1.setUpperBound(2.0d);
    org.jfree.chart.axis.MarkerAxisBand var12 = var1.getMarkerBand();
    var1.setTickLabelsVisible(true);
    org.jfree.chart.util.RectangleInsets var15 = var1.getTickLabelInsets();
    double var17 = var15.trimHeight(3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test174"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var5 = var4.getBackgroundPaint();
    java.awt.Paint var6 = var4.getPaint();
    var1.setTickLabelPaint(var6);
    var1.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test175"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.getAutoRangeStickyZero();
    org.jfree.chart.axis.MarkerAxisBand var6 = var1.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test176"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.ValueAxis var39 = null;
    var33.setRangeAxis(var39);
    boolean var41 = var33.isRangeZoomable();
    org.jfree.chart.event.AxisChangeEvent var42 = null;
    var33.axisChanged(var42);
    org.jfree.data.KeyedObjects var44 = new org.jfree.data.KeyedObjects();
    java.lang.Object var46 = var44.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var47 = null;
    org.jfree.chart.event.ChartProgressEvent var50 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var44, var47, 0, 0);
    java.util.List var51 = var44.getKeys();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var52 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Comparable var53 = null;
    org.jfree.data.general.PieDataset var54 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var52, var53);
    org.jfree.data.general.DatasetChangeEvent var55 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var51, (org.jfree.data.general.Dataset)var52);
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var33.getRendererForDataset((org.jfree.data.category.CategoryDataset)var52);
    java.lang.Number var57 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + Double.NaN+ "'", var57.equals(Double.NaN));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test177"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    var0.setBaseItemLabelsVisible(false, false);
    org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(4, 1, 100);
    int var18 = var17.getGreen();
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    var23.zoomRange((-1.0d), 0.0d);
    boolean var27 = var23.isPositiveArrowVisible();
    boolean var28 = var23.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    int var30 = var29.getColumnCount();
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var34 = var33.isNegativeArrowVisible();
    var33.setAutoRangeStickyZero(false);
    java.awt.Stroke var37 = var33.getTickMarkStroke();
    var29.setSeriesOutlineStroke(1, var37, false);
    boolean var41 = var29.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    var43.zoomRange((-1.0d), 0.0d);
    boolean var47 = var43.isPositiveArrowVisible();
    java.awt.Paint var48 = var43.getAxisLinePaint();
    var29.setBasePaint(var48);
    org.jfree.chart.labels.CategoryToolTipGenerator var50 = null;
    var29.setBaseToolTipGenerator(var50);
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot(var19, var21, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
    var52.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var55 = null;
    var52.markerChanged(var55);
    var52.setWeight((-1));
    org.jfree.chart.JFreeChart var59 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var52);
    java.lang.Object var60 = var59.getTextAntiAlias();
    org.jfree.chart.event.ChartChangeEvent var61 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var18, var59);
    org.jfree.chart.title.TextTitle var62 = var59.getTitle();
    org.jfree.chart.title.TextTitle var63 = var59.getTitle();
    org.jfree.chart.renderer.category.BarRenderer var64 = new org.jfree.chart.renderer.category.BarRenderer();
    int var65 = var64.getColumnCount();
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var69 = var68.isNegativeArrowVisible();
    var68.setAutoRangeStickyZero(false);
    java.awt.Stroke var72 = var68.getTickMarkStroke();
    var64.setSeriesOutlineStroke(1, var72, false);
    boolean var76 = var64.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis("hi!");
    var78.zoomRange((-1.0d), 0.0d);
    boolean var82 = var78.isPositiveArrowVisible();
    java.awt.Paint var83 = var78.getAxisLinePaint();
    var64.setBasePaint(var83);
    org.jfree.chart.labels.CategoryItemLabelGenerator var87 = var64.getItemLabelGenerator(0, (-1));
    java.awt.Paint var90 = var64.getItemOutlinePaint(5, (-16580609));
    var59.setBorderPaint(var90);
    boolean var92 = var59.getAntiAlias();
    org.jfree.chart.event.ChartProgressEvent var95 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var59, 255, (-16777216));
    var59.removeLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test178"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.DatasetGroup var41 = new org.jfree.data.general.DatasetGroup("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    var0.setGroup(var41);
    org.jfree.data.category.CategoryDataset var43 = null;
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
    var47.zoomRange((-1.0d), 0.0d);
    boolean var51 = var47.isPositiveArrowVisible();
    boolean var52 = var47.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
    int var54 = var53.getColumnCount();
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var58 = var57.isNegativeArrowVisible();
    var57.setAutoRangeStickyZero(false);
    java.awt.Stroke var61 = var57.getTickMarkStroke();
    var53.setSeriesOutlineStroke(1, var61, false);
    boolean var65 = var53.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("hi!");
    var67.zoomRange((-1.0d), 0.0d);
    boolean var71 = var67.isPositiveArrowVisible();
    java.awt.Paint var72 = var67.getAxisLinePaint();
    var53.setBasePaint(var72);
    org.jfree.chart.labels.CategoryToolTipGenerator var74 = null;
    var53.setBaseToolTipGenerator(var74);
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot(var43, var45, (org.jfree.chart.axis.ValueAxis)var47, (org.jfree.chart.renderer.category.CategoryItemRenderer)var53);
    var76.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var79 = null;
    var76.markerChanged(var79);
    org.jfree.data.general.DatasetGroup var81 = var76.getDatasetGroup();
    org.jfree.chart.axis.AxisSpace var82 = var76.getFixedRangeAxisSpace();
    var76.mapDatasetToRangeAxis(0, 4);
    var76.setForegroundAlpha(10.0f);
    org.jfree.chart.axis.AxisLocation var88 = var76.getRangeAxisLocation();
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var76);
    org.jfree.data.Range var91 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    int var92 = var0.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test179"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    var33.setWeight((-1));
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    java.lang.Object var41 = var40.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    org.jfree.chart.util.SortOrder var47 = var33.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var50.setMaximumCategoryLabelLines(0);
    org.jfree.chart.JFreeChart var53 = null;
    org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var50, var53, 10, 100);
    java.awt.Font var57 = var50.getLabelFont();
    int var58 = var50.getMaximumCategoryLabelLines();
    var33.setDomainAxis(1, var50);
    org.jfree.chart.renderer.category.BarRenderer var60 = new org.jfree.chart.renderer.category.BarRenderer();
    int var61 = var60.getColumnCount();
    var60.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var65 = new org.jfree.chart.renderer.category.BarRenderer();
    int var66 = var65.getColumnCount();
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var70 = var69.isNegativeArrowVisible();
    var69.setAutoRangeStickyZero(false);
    java.awt.Stroke var73 = var69.getTickMarkStroke();
    var65.setSeriesOutlineStroke(1, var73, false);
    var60.setSeriesOutlineStroke(0, var73, false);
    var60.setBaseSeriesVisible(false);
    var60.setBaseCreateEntities(true);
    int var82 = var60.getRowCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var84 = null;
    var60.setSeriesItemLabelGenerator(4, var84, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var88 = null;
    var60.setSeriesToolTipGenerator(4, var88, true);
    var60.setItemLabelAnchorOffset((-1.99999999d));
    int var93 = var33.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == (-1));

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test181"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    org.jfree.chart.util.SortOrder var47 = var33.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var50.setMaximumCategoryLabelLines(0);
    org.jfree.chart.JFreeChart var53 = null;
    org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var50, var53, 10, 100);
    java.awt.Font var57 = var50.getLabelFont();
    int var58 = var50.getMaximumCategoryLabelLines();
    var33.setDomainAxis(1, var50);
    var50.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.TickUnits var62 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var64.setMaximumCategoryLabelLines(0);
    var64.setMaximumCategoryLabelLines((-1));
    var64.setMaximumCategoryLabelLines((-1));
    double var71 = var64.getCategoryMargin();
    var64.setMaximumCategoryLabelWidthRatio(100.0f);
    org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("hi!");
    var75.zoomRange((-1.0d), 0.0d);
    boolean var79 = var75.isPositiveArrowVisible();
    boolean var80 = var75.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var82 = null;
    org.jfree.chart.util.RectangleEdge var83 = null;
    double var84 = var75.valueToJava2D(4.0d, var82, var83);
    org.jfree.chart.axis.NumberTickUnit var86 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var88 = var86.valueToString(0.0d);
    var75.setTickUnit(var86, true, true);
    java.awt.Font var92 = var64.getTickLabelFont((java.lang.Comparable)var86);
    var62.add((org.jfree.chart.axis.TickUnit)var86);
    java.awt.Font var94 = var50.getTickLabelFont((java.lang.Comparable)var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + "0"+ "'", var88.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test182"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.util.LengthAdjustmentType var3 = var1.getLabelOffsetType();
    java.lang.String var4 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test183"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var0.setMargin(var7);
    var0.setURLText("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    java.lang.String var11 = var0.getID();
    double var12 = var0.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test184"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = var0.getToolTipGenerator(10, 10);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var6 = var4.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var6);
    org.jfree.chart.block.FlowArrangement var8 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var8.add((org.jfree.chart.block.Block)var9, (java.lang.Object)var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    boolean var21 = var16.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var27 = var26.isNegativeArrowVisible();
    var26.setAutoRangeStickyZero(false);
    java.awt.Stroke var30 = var26.getTickMarkStroke();
    var22.setSeriesOutlineStroke(1, var30, false);
    boolean var34 = var22.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    var36.zoomRange((-1.0d), 0.0d);
    boolean var40 = var36.isPositiveArrowVisible();
    java.awt.Paint var41 = var36.getAxisLinePaint();
    var22.setBasePaint(var41);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var22.setBaseToolTipGenerator(var43);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var12, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    var45.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var48 = null;
    var45.markerChanged(var48);
    org.jfree.chart.util.SortOrder var50 = var45.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var51 = new org.jfree.data.KeyedObjects();
    java.lang.Object var53 = var51.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var54 = null;
    org.jfree.chart.event.ChartProgressEvent var57 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var51, var54, 0, 0);
    boolean var58 = var45.equals((java.lang.Object)var54);
    java.awt.Paint var59 = var45.getOutlinePaint();
    var10.setErrorIndicatorPaint(var59);
    org.jfree.chart.renderer.category.BarRenderer var62 = new org.jfree.chart.renderer.category.BarRenderer();
    int var63 = var62.getColumnCount();
    var62.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var66 = var62.getBasePositiveItemLabelPosition();
    var10.setSeriesNegativeItemLabelPosition(4, var66, true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var69 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    boolean var70 = var66.equals((java.lang.Object)var69);
    var0.setBaseNegativeItemLabelPosition(var66);
    double var72 = var0.getMinimumBarLength();
    double var73 = var0.getBase();
    org.jfree.chart.labels.ItemLabelPosition var74 = var0.getNegativeItemLabelPositionFallback();
    java.awt.Shape var75 = var0.getBaseShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test185"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemLabelGenerator();
    java.awt.Font var4 = var0.getSeriesItemLabelFont((-1));
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var5.add((org.jfree.chart.block.Block)var6, (java.lang.Object)var7);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    var13.zoomRange((-1.0d), 0.0d);
    boolean var17 = var13.isPositiveArrowVisible();
    boolean var18 = var13.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    int var20 = var19.getColumnCount();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    var23.setAutoRangeStickyZero(false);
    java.awt.Stroke var27 = var23.getTickMarkStroke();
    var19.setSeriesOutlineStroke(1, var27, false);
    boolean var31 = var19.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi!");
    var33.zoomRange((-1.0d), 0.0d);
    boolean var37 = var33.isPositiveArrowVisible();
    java.awt.Paint var38 = var33.getAxisLinePaint();
    var19.setBasePaint(var38);
    org.jfree.chart.labels.CategoryToolTipGenerator var40 = null;
    var19.setBaseToolTipGenerator(var40);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var9, var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    var42.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var45 = null;
    var42.markerChanged(var45);
    org.jfree.chart.util.SortOrder var47 = var42.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var48 = new org.jfree.data.KeyedObjects();
    java.lang.Object var50 = var48.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var51 = null;
    org.jfree.chart.event.ChartProgressEvent var54 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var48, var51, 0, 0);
    boolean var55 = var42.equals((java.lang.Object)var51);
    java.awt.Paint var56 = var42.getOutlinePaint();
    var7.setErrorIndicatorPaint(var56);
    org.jfree.chart.renderer.category.BarRenderer var59 = new org.jfree.chart.renderer.category.BarRenderer();
    int var60 = var59.getColumnCount();
    var59.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var63 = var59.getBasePositiveItemLabelPosition();
    var7.setSeriesNegativeItemLabelPosition(4, var63, true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var66 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    boolean var67 = var63.equals((java.lang.Object)var66);
    var0.setBasePositiveItemLabelPosition(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test186"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.Number var4 = var0.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.clearCategoryLabelToolTips();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.isInverted();
    var9.configure();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var6, (org.jfree.chart.axis.ValueAxis)var9, var16);
    java.lang.Number var20 = var0.getValue((java.lang.Comparable)1, (java.lang.Comparable)"Range[0.0,0.0]");
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    boolean var30 = var25.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    int var32 = var31.getColumnCount();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var36 = var35.isNegativeArrowVisible();
    var35.setAutoRangeStickyZero(false);
    java.awt.Stroke var39 = var35.getTickMarkStroke();
    var31.setSeriesOutlineStroke(1, var39, false);
    boolean var43 = var31.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
    var45.zoomRange((-1.0d), 0.0d);
    boolean var49 = var45.isPositiveArrowVisible();
    java.awt.Paint var50 = var45.getAxisLinePaint();
    var31.setBasePaint(var50);
    org.jfree.chart.labels.CategoryToolTipGenerator var52 = null;
    var31.setBaseToolTipGenerator(var52);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var21, var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    var54.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var57 = null;
    var54.markerChanged(var57);
    var54.setWeight((-1));
    org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var54);
    org.jfree.chart.event.MarkerChangeEvent var62 = null;
    var54.markerChanged(var62);
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var54);
    java.awt.Image var65 = var54.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test187"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var0.setSeriesToolTipGenerator(1, var14);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var16 = var0.getLegendItemToolTipGenerator();
    java.awt.Paint var19 = var0.getItemLabelPaint(5, 1);
    var0.setAutoPopulateSeriesShape(false);
    java.awt.Stroke var23 = var0.lookupSeriesStroke((-16580609));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test188"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    var0.setBaseCreateEntities(true);
    java.awt.Stroke var24 = var0.getItemStroke(100, 0);
    java.awt.Shape var26 = var0.lookupSeriesShape(1);
    var0.removeAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-16777216), (java.lang.Boolean)true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test189"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleEdge.TOP", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test190"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)100.0f, var1, var2, var5, 1.0d);
    java.lang.Comparable var8 = var7.getCategory();
    org.jfree.chart.text.TextBlock var9 = var7.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 100.0f+ "'", var8.equals(100.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test191"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("RectangleEdge.TOP");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.data.Range var6 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var7 = var6.getLowerBound();
//     double var8 = var6.getLowerBound();
//     boolean var10 = var6.contains(1.0d);
//     org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(Double.POSITIVE_INFINITY, (-1.0d));
//     org.jfree.chart.block.LengthConstraintType var14 = var13.getHeightConstraintType();
//     org.jfree.data.Range var18 = new org.jfree.data.Range(0.0d, 0.0d);
//     double var19 = var18.getLowerBound();
//     double var20 = var18.getLowerBound();
//     org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var18);
//     double var22 = var18.getUpperBound();
//     org.jfree.data.Range var25 = org.jfree.data.Range.shift(var18, 0.0d, true);
//     org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 1.0d);
//     org.jfree.data.Range var28 = null;
//     org.jfree.data.Range var29 = null;
//     org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(var28, var29);
//     org.jfree.chart.block.RectangleConstraint var31 = var30.toUnconstrainedWidth();
//     org.jfree.chart.block.RectangleConstraint var32 = var30.toUnconstrainedWidth();
//     org.jfree.chart.block.LengthConstraintType var33 = var30.getHeightConstraintType();
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint((-20.0d), var6, var14, 8.0d, var25, var33);
//     org.jfree.chart.util.Size2D var35 = var1.arrange(var2, var34);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test192"); }


    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    var2.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
    org.jfree.chart.text.TextBlock var9 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var13 = var12.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var15 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var9, var10, var13, 0.0d);
    java.lang.Comparable var16 = var15.getCategory();
    java.lang.String var17 = var15.toString();
    org.jfree.chart.text.TextAnchor var18 = var15.getRotationAnchor();
    org.jfree.chart.text.TextAnchor var19 = var15.getTextAnchor();
    org.jfree.chart.axis.NumberTick var21 = new org.jfree.chart.axis.NumberTick((java.lang.Number)4, "", var7, var19, 6.0d);
    java.lang.String var22 = var21.toString();
    java.lang.String var23 = var21.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "1"+ "'", var16.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + ""+ "'", var22.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + ""+ "'", var23.equals(""));

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test193"); }


    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    java.awt.Paint var10 = var5.getAxisLinePaint();
    boolean var11 = var5.getAutoRangeStickyZero();
    var5.setLabelAngle((-1.0d));
    var5.setTickLabelsVisible(true);
    boolean var16 = var5.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    int var19 = var18.getColumnCount();
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var18.setSeriesShape(100, var23, false);
    org.jfree.chart.entity.CategoryLabelEntity var28 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var23, "", "0");
    var5.setDownArrow(var23);
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    var30.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var30.setSeriesToolTipGenerator(1, var44);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = var30.getLegendItemToolTipGenerator();
    var30.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
    var50.setHeight(100.0d);
    boolean var53 = var50.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var55 = var54.getErrorIndicatorPaint();
    var50.setPaint(var55);
    org.jfree.chart.ChartColor var60 = new org.jfree.chart.ChartColor(4, 1, 100);
    var50.setBackgroundPaint((java.awt.Paint)var60);
    var30.setBaseFillPaint((java.awt.Paint)var60, true);
    org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("poly", "ChartChangeEventType.GENERAL", "Size2D[width=-1.0, height=0.0]", "RangeType.FULL", var23, (java.awt.Paint)var60);
    boolean var65 = var64.isShapeOutlineVisible();
    boolean var66 = var64.isShapeFilled();
    var64.setDatasetIndex(4);
    java.lang.String var69 = var64.getToolTipText();
    var64.setSeriesKey((java.lang.Comparable)1L);
    var64.setSeriesIndex((-16514716));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + "Size2D[width=-1.0, height=0.0]"+ "'", var69.equals("Size2D[width=-1.0, height=0.0]"));

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test194"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    var33.setAnchorValue(0.0d);
    org.jfree.data.general.DatasetGroup var43 = var33.getDatasetGroup();
    org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Stroke var45 = var44.getNextOutlineStroke();
    java.awt.Shape var46 = var44.getNextShape();
    var33.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test195"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    java.awt.Paint var47 = var33.getOutlinePaint();
    boolean var48 = var33.isDomainZoomable();
    org.jfree.chart.axis.CategoryAxis var49 = var33.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setRangeAxisLocation((-524308), var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test196"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    var0.setMaximumBarWidth(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test197"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("CategoryLabelEntity: category=-1, tooltip=, url=ChartChangeEventType.GENERAL");
    org.jfree.data.general.DatasetGroup var3 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    int var14 = var13.getColumnCount();
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var13.setSeriesShape(100, var18, false);
    var4.setSeriesShape(1, var18);
    boolean var22 = var3.equals((java.lang.Object)var4);
    org.jfree.chart.labels.CategoryToolTipGenerator var23 = var4.getBaseToolTipGenerator();
    java.awt.Font var24 = var4.getBaseItemLabelFont();
    java.awt.Font var27 = var4.getItemLabelFont(15, (-16777216));
    var1.setFont(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test198"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    var33.configureDomainAxes();
    boolean var40 = var33.isDomainZoomable();
    org.jfree.chart.ChartRenderingInfo var42 = null;
    org.jfree.chart.plot.PlotRenderingInfo var43 = new org.jfree.chart.plot.PlotRenderingInfo(var42);
    java.awt.geom.Point2D var44 = null;
    var33.zoomRangeAxes(0.0d, var43, var44);
    var33.clearDomainMarkers();
    org.jfree.chart.util.RectangleEdge var47 = var33.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test199"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("0");
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
    java.awt.Font var4 = var3.getFont();
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var6 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, var6);
    org.jfree.chart.block.RectangleConstraint var8 = var7.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var9 = var7.toUnconstrainedWidth();
    boolean var10 = var3.equals((java.lang.Object)var9);
    var1.removeFragment(var3);
    java.awt.Font var12 = var3.getFont();
    org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var13);
    var14.clear();
    double var16 = var14.getContentYOffset();
    boolean var17 = var3.equals((java.lang.Object)var16);
    float var18 = var3.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test200"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    var33.setRangeGridlinesVisible(false);
    org.jfree.chart.util.RectangleEdge var42 = var33.getDomainAxisEdge(0);
    boolean var43 = var33.isOutlineVisible();
    org.jfree.chart.util.Layer var44 = null;
    java.util.Collection var45 = var33.getRangeMarkers(var44);
    org.jfree.chart.util.RectangleEdge var47 = var33.getRangeAxisEdge(10);
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    var48.setAutoPopulateSeriesFillPaint(true);
    java.awt.Font var53 = var48.getItemLabelFont(0, 5);
    java.awt.Stroke var54 = var48.getBaseStroke();
    java.awt.Paint var57 = var48.getItemPaint((-1), 0);
    var33.setDomainGridlinePaint(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test201"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtTop();
    java.util.List var2 = var0.getAxesAtLeft();
    java.util.List var3 = var0.getAxesAtTop();
    java.util.List var4 = var0.getAxesAtTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test202"); }


    java.awt.Color var2 = java.awt.Color.getColor("RectangleAnchor.CENTER", (-33));
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "java.awt.Color[r=255,g=255,b=223]"+ "'", var3.equals("java.awt.Color[r=255,g=255,b=223]"));

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test203"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var0.add((org.jfree.chart.block.Block)var1, (java.lang.Object)var2);
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var5 = var4.getColumnCount();
//     var4.setBaseSeriesVisible(false);
//     var4.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var12 = var11.getColumnCount();
//     var11.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var16 = null;
//     var11.setSeriesNegativeItemLabelPosition(100, var16, true);
//     var11.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var26 = var25.getColumnCount();
//     var25.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var31 = var30.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var35 = var34.isNegativeArrowVisible();
//     var34.setAutoRangeStickyZero(false);
//     java.awt.Stroke var38 = var34.getTickMarkStroke();
//     var30.setSeriesOutlineStroke(1, var38, false);
//     var25.setSeriesOutlineStroke(0, var38, false);
//     var24.setAxisLineStroke(var38);
//     var11.setBaseStroke(var38, true);
//     var4.setSeriesOutlineStroke(0, var38, true);
//     org.jfree.chart.block.FlowArrangement var48 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var49 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var48);
//     org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var51 = null;
//     boolean var52 = var50.equals(var51);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4, (org.jfree.chart.block.Arrangement)var48, (org.jfree.chart.block.Arrangement)var50);
//     org.jfree.chart.util.RectangleAnchor var54 = null;
//     var53.setLegendItemGraphicLocation(var54);
//     double var56 = var53.getContentXOffset();
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var61.zoomRange((-1.0d), 0.0d);
//     boolean var65 = var61.isPositiveArrowVisible();
//     boolean var66 = var61.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var67 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var68 = var67.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var72 = var71.isNegativeArrowVisible();
//     var71.setAutoRangeStickyZero(false);
//     java.awt.Stroke var75 = var71.getTickMarkStroke();
//     var67.setSeriesOutlineStroke(1, var75, false);
//     boolean var79 = var67.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var81 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var81.zoomRange((-1.0d), 0.0d);
//     boolean var85 = var81.isPositiveArrowVisible();
//     java.awt.Paint var86 = var81.getAxisLinePaint();
//     var67.setBasePaint(var86);
//     org.jfree.chart.labels.CategoryToolTipGenerator var88 = null;
//     var67.setBaseToolTipGenerator(var88);
//     org.jfree.chart.plot.CategoryPlot var90 = new org.jfree.chart.plot.CategoryPlot(var57, var59, (org.jfree.chart.axis.ValueAxis)var61, (org.jfree.chart.renderer.category.CategoryItemRenderer)var67);
//     var90.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var93 = null;
//     var90.markerChanged(var93);
//     org.jfree.chart.util.SortOrder var95 = var90.getRowRenderingOrder();
//     var90.configureDomainAxes();
//     boolean var97 = var90.isDomainZoomable();
//     var0.add((org.jfree.chart.block.Block)var53, (java.lang.Object)var97);
//     
//     // Checks the contract:  equals-hashcode on var0 and var48
//     assertTrue("Contract failed: equals-hashcode on var0 and var48", var0.equals(var48) ? var0.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var0
//     assertTrue("Contract failed: equals-hashcode on var48 and var0", var48.equals(var0) ? var48.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test204"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.data.general.DatasetGroup var38 = var33.getDatasetGroup();
    org.jfree.chart.axis.AxisSpace var39 = var33.getFixedRangeAxisSpace();
    var33.mapDatasetToRangeAxis(0, 4);
    org.jfree.chart.ChartColor var46 = new org.jfree.chart.ChartColor(4, 1, 100);
    int var47 = var46.getGreen();
    org.jfree.data.category.CategoryDataset var48 = null;
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    boolean var57 = var52.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
    int var59 = var58.getColumnCount();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var63 = var62.isNegativeArrowVisible();
    var62.setAutoRangeStickyZero(false);
    java.awt.Stroke var66 = var62.getTickMarkStroke();
    var58.setSeriesOutlineStroke(1, var66, false);
    boolean var70 = var58.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("hi!");
    var72.zoomRange((-1.0d), 0.0d);
    boolean var76 = var72.isPositiveArrowVisible();
    java.awt.Paint var77 = var72.getAxisLinePaint();
    var58.setBasePaint(var77);
    org.jfree.chart.labels.CategoryToolTipGenerator var79 = null;
    var58.setBaseToolTipGenerator(var79);
    org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot(var48, var50, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var58);
    var81.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var84 = null;
    var81.markerChanged(var84);
    var81.setWeight((-1));
    org.jfree.chart.JFreeChart var88 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var81);
    java.lang.Object var89 = var88.getTextAntiAlias();
    org.jfree.chart.event.ChartChangeEvent var90 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var47, var88);
    var33.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var88);
    org.jfree.chart.event.ChartProgressListener var92 = null;
    var88.addProgressListener(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test205"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var7 = var6.isNegativeArrowVisible();
    var6.setAutoRangeStickyZero(false);
    java.awt.Stroke var10 = var6.getTickMarkStroke();
    var2.setSeriesOutlineStroke(1, var10, false);
    boolean var14 = var2.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    var2.setBasePaint(var21);
    boolean var23 = var1.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.RendererState var24 = new org.jfree.chart.renderer.RendererState(var1);
    java.awt.geom.Rectangle2D var25 = var1.getDataArea();
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    var26.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    int var32 = var31.getColumnCount();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var36 = var35.isNegativeArrowVisible();
    var35.setAutoRangeStickyZero(false);
    java.awt.Stroke var39 = var35.getTickMarkStroke();
    var31.setSeriesOutlineStroke(1, var39, false);
    var26.setSeriesOutlineStroke(0, var39, false);
    double var44 = var26.getBase();
    var26.setIncludeBaseInRange(true);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var48.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var51 = var48.getLabelInsets();
    org.jfree.chart.ChartRenderingInfo var52 = null;
    org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
    org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
    int var55 = var54.getColumnCount();
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var59 = var58.isNegativeArrowVisible();
    var58.setAutoRangeStickyZero(false);
    java.awt.Stroke var62 = var58.getTickMarkStroke();
    var54.setSeriesOutlineStroke(1, var62, false);
    boolean var66 = var54.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    var54.setBasePaint(var73);
    boolean var75 = var53.equals((java.lang.Object)var73);
    org.jfree.chart.renderer.RendererState var76 = new org.jfree.chart.renderer.RendererState(var53);
    java.awt.geom.Rectangle2D var77 = var53.getDataArea();
    java.awt.geom.Rectangle2D var78 = var51.createInsetRectangle(var77);
    var26.setBaseShape((java.awt.Shape)var77);
    var1.setPlotArea(var77);
    org.jfree.chart.axis.CategoryLabelPositions var82 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var83 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var84 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var85 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var83, var84);
    double var86 = var84.getAngle();
    org.jfree.chart.axis.CategoryLabelPositions var87 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var82, var84);
    org.jfree.chart.util.RectangleAnchor var88 = var84.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var89 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.text.TextBlockAnchor var90 = var89.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var91 = new org.jfree.chart.axis.CategoryLabelPosition(var88, var90);
    java.awt.geom.Point2D var92 = org.jfree.chart.util.RectangleAnchor.coordinates(var77, var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test206"); }


    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var4 = var3.getLabelTextAnchor();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    var5.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var5.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var10 = var9.getRotationAnchor();
    org.jfree.chart.axis.NumberTick var12 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0d, "0", var4, var10, Double.POSITIVE_INFINITY);
    java.lang.Number var13 = var12.getNumber();
    org.jfree.chart.axis.TickType var14 = var12.getTickType();
    org.jfree.chart.util.PaintList var15 = new org.jfree.chart.util.PaintList();
    java.lang.Object var16 = var15.clone();
    boolean var17 = var14.equals(var16);
    java.lang.String var18 = var14.toString();
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var21 = var20.getLabelOffset();
    org.jfree.chart.util.RectangleInsets var22 = var20.getLabelOffset();
    var20.setValue((-1.0d));
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    boolean var34 = var29.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
    int var36 = var35.getColumnCount();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var40 = var39.isNegativeArrowVisible();
    var39.setAutoRangeStickyZero(false);
    java.awt.Stroke var43 = var39.getTickMarkStroke();
    var35.setSeriesOutlineStroke(1, var43, false);
    boolean var47 = var35.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
    var49.zoomRange((-1.0d), 0.0d);
    boolean var53 = var49.isPositiveArrowVisible();
    java.awt.Paint var54 = var49.getAxisLinePaint();
    var35.setBasePaint(var54);
    org.jfree.chart.labels.CategoryToolTipGenerator var56 = null;
    var35.setBaseToolTipGenerator(var56);
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var25, var27, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
    var58.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var61 = null;
    var58.markerChanged(var61);
    boolean var63 = var58.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var58.markerChanged(var64);
    var58.setAnchorValue(0.0d);
    org.jfree.chart.plot.DatasetRenderingOrder var68 = var58.getDatasetRenderingOrder();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var69 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var70 = var69.getErrorIndicatorPaint();
    var58.setNoDataMessagePaint(var70);
    var20.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var58);
    boolean var73 = var14.equals((java.lang.Object)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 100.0d+ "'", var13.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "MAJOR"+ "'", var18.equals("MAJOR"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test207"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    var1.setMaximumCategoryLabelLines((-1));
    var1.setMaximumCategoryLabelLines((-1));
    double var8 = var1.getCategoryMargin();
    org.jfree.chart.axis.CategoryLabelPositions var9 = var1.getCategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
    org.jfree.chart.axis.CategoryLabelPositions var12 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var13 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var14 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var12, var13);
    double var15 = var13.getAngle();
    org.jfree.chart.axis.CategoryLabelPositions var16 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var11, var13);
    org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var9, var13);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
    var18.setHeight(100.0d);
    boolean var21 = var18.getNotify();
    org.jfree.chart.event.TitleChangeListener var22 = null;
    var18.removeChangeListener(var22);
    org.jfree.chart.util.RectangleEdge var24 = var18.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var25 = var17.getLabelPosition(var24);
    boolean var26 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var24);
    boolean var27 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test208"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtLeft();
    java.util.List var2 = var0.getAxesAtRight();
    java.util.List var3 = var0.getAxesAtBottom();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var5.setMaximumCategoryLabelLines(0);
    var5.setMaximumCategoryLabelLines((-1));
    var5.setMaximumCategoryLabelLines((-1));
    double var12 = var5.getCategoryMargin();
    var5.setLowerMargin(0.0d);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    int var16 = var15.getColumnCount();
    var15.setBaseSeriesVisible(false);
    java.awt.Font var19 = var15.getBaseItemLabelFont();
    var5.setLabelFont(var19);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    boolean var30 = var25.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    int var32 = var31.getColumnCount();
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var36 = var35.isNegativeArrowVisible();
    var35.setAutoRangeStickyZero(false);
    java.awt.Stroke var39 = var35.getTickMarkStroke();
    var31.setSeriesOutlineStroke(1, var39, false);
    boolean var43 = var31.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
    var45.zoomRange((-1.0d), 0.0d);
    boolean var49 = var45.isPositiveArrowVisible();
    java.awt.Paint var50 = var45.getAxisLinePaint();
    var31.setBasePaint(var50);
    org.jfree.chart.labels.CategoryToolTipGenerator var52 = null;
    var31.setBaseToolTipGenerator(var52);
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var21, var23, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    var54.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var57 = null;
    var54.markerChanged(var57);
    org.jfree.data.general.DatasetGroup var59 = var54.getDatasetGroup();
    org.jfree.chart.axis.AxisSpace var60 = var54.getFixedRangeAxisSpace();
    var54.mapDatasetToRangeAxis(0, 4);
    var54.setForegroundAlpha(10.0f);
    var54.setAnchorValue(1.0E-8d, false);
    org.jfree.chart.util.RectangleEdge var69 = var54.getDomainAxisEdge();
    var0.add((org.jfree.chart.axis.Axis)var5, var69);
    double var71 = var5.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0.2d);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test209"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var2 = var1.getColumnCount();
//     var1.setBaseSeriesVisible(false);
//     java.awt.Font var5 = var1.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var7 = var6.getText();
//     java.lang.Object var8 = var6.clone();
//     java.awt.Paint var9 = var6.getPaint();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.text.G2TextMeasurer var13 = new org.jfree.chart.text.G2TextMeasurer(var12);
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("Size2D[width=0.0, height=0.2]", var5, var9, 1.0f, (-16514716), (org.jfree.chart.text.TextMeasurer)var13);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test210"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    var33.setWeight((-1));
    org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
    org.jfree.chart.event.ChartProgressListener var41 = null;
    var40.removeProgressListener(var41);
    var40.setBackgroundImageAlpha(100.0f);
    java.awt.Stroke var45 = var40.getBorderStroke();
    org.jfree.chart.util.RectangleInsets var46 = var40.getPadding();
    int var47 = var40.getSubtitleCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test211"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("0,0,0,0,0,0,0,0", "");

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test212"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var3 = var0.getObject((java.lang.Comparable)(short)100);
    int var4 = var0.getItemCount();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("hi!");
    var7.zoomRange((-1.0d), 0.0d);
    boolean var11 = var7.isPositiveArrowVisible();
    boolean var12 = var7.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var14 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var16 = var14.valueToString(0.0d);
    var7.setTickUnit(var14);
    org.jfree.chart.JFreeChart var18 = null;
    org.jfree.chart.event.ChartProgressEvent var21 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var18, (-1), 10);
    org.jfree.chart.JFreeChart var22 = var21.getChart();
    var21.setType(5);
    var21.setType(4);
    var0.setObject((java.lang.Comparable)"-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (java.lang.Object)var21);
    java.lang.String var28 = var21.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "0"+ "'", var16.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test213"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 4.0d, 1.0E-8d);
    var4.clear();

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test214"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("MAJOR");

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test215"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.isInverted();
    var1.configure();
    var1.setAutoRangeIncludesZero(true);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var1.valueToJava2D(100.0d, var11, var12);
    var1.setAutoTickUnitSelection(true, false);
    org.jfree.chart.util.RectangleInsets var17 = new org.jfree.chart.util.RectangleInsets();
    var1.setTickLabelInsets(var17);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var21 = null;
    var20.addChangeListener(var21);
    java.awt.Shape var23 = var20.getRightArrow();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var26 = null;
    var25.addChangeListener(var26);
    java.awt.Shape var28 = var25.getRightArrow();
    var20.setRightArrow(var28);
    org.jfree.chart.entity.TickLabelEntity var32 = new org.jfree.chart.entity.TickLabelEntity(var28, "", "hi!");
    var1.setLeftArrow(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test216"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    boolean var5 = var1.getAutoRangeStickyZero();
    var1.setLowerMargin(1.0E-8d);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    java.awt.Paint var14 = var9.getAxisLinePaint();
    boolean var15 = var9.getAutoRangeStickyZero();
    var9.setLabelAngle((-1.0d));
    var9.setTickLabelsVisible(true);
    boolean var20 = var9.isVerticalTickLabels();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var22.setSeriesShape(100, var27, false);
    org.jfree.chart.entity.CategoryLabelEntity var32 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var27, "", "0");
    var9.setDownArrow(var27);
    org.jfree.chart.entity.AxisLabelEntity var36 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var27, "RectangleAnchor.CENTER", "RectangleInsets[t=10.0,l=1.0,b=-1.0,r=10.0]");
    org.jfree.chart.axis.TickUnitSource var37 = var1.getStandardTickUnits();
    var1.setAutoTickUnitSelection(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test217"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    var2.zoomRange((-1.0d), 0.0d);
    boolean var6 = var2.isPositiveArrowVisible();
    boolean var7 = var2.getAutoRangeIncludesZero();
    var2.resizeRange(4.0d);
    double var10 = var2.getFixedDimension();
    boolean var11 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    var12.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var17 = var16.getMarkerBand();
    boolean var18 = var12.equals((java.lang.Object)var16);
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.axis.AxisState var20 = null;
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    java.util.List var23 = var16.refreshTicks(var19, var20, var21, var22);
    org.jfree.data.Range var24 = var16.getRange();
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    double var26 = var25.getContentXOffset();
    java.lang.Object var27 = var25.clone();
    boolean var28 = var24.equals((java.lang.Object)var25);
    var2.setRange(var24, true, false);
    org.jfree.chart.axis.MarkerAxisBand var32 = null;
    var2.setMarkerBand(var32);
    org.jfree.data.Range var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setRangeWithMargins(var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test218"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    java.awt.Font var8 = null;
    var0.setBaseItemLabelFont(var8, true);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(100, var14, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = var0.getBaseToolTipGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var20 = var0.getURLGenerator(0, 4);
    java.awt.Stroke var23 = var0.getItemStroke(4, 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test219"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var2 = var1.getLabelTextAnchor();
    double var3 = var1.getValue();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    int var16 = var15.getColumnCount();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var20 = var19.isNegativeArrowVisible();
    var19.setAutoRangeStickyZero(false);
    java.awt.Stroke var23 = var19.getTickMarkStroke();
    var15.setSeriesOutlineStroke(1, var23, false);
    boolean var27 = var15.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    java.awt.Paint var34 = var29.getAxisLinePaint();
    var15.setBasePaint(var34);
    org.jfree.chart.labels.CategoryToolTipGenerator var36 = null;
    var15.setBaseToolTipGenerator(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var5, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var39 = var38.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = var38.getRenderer(1);
    boolean var42 = var4.hasListener((java.util.EventListener)var38);
    java.awt.Paint var43 = var38.getRangeGridlinePaint();
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var38);
    org.jfree.chart.LegendItemCollection var45 = var38.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var47 = var45.get(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test220"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var3 = var2.getLabelTextAnchor();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    var4.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var4.setMargin(var11);
    var4.setURLText("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    boolean var15 = var3.equals((java.lang.Object)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var16 = new org.jfree.chart.labels.ItemLabelPosition(var0, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test221"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var1, var2, var5, 0.0d);
    org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
    double var9 = var7.getAngle();
    double var10 = var7.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test222"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    var33.configureDomainAxes();
    var33.clearDomainMarkers((-16777216));
    java.awt.Stroke var38 = var33.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test223"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setBaseSeriesVisible(false);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test224"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, 0.0f, 0.05d, 1.0f, 0.5f);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test225"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
    java.awt.Paint var4 = var1.getLabelPaint();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    var5.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    var5.setPositiveItemLabelPositionFallback(var8);
    org.jfree.chart.labels.ItemLabelPosition var10 = var5.getBaseNegativeItemLabelPosition();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var12.setMaximumCategoryLabelLines(0);
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var16 = var15.getBackgroundPaint();
    java.awt.Paint var17 = var15.getPaint();
    var12.setTickLabelPaint(var17);
    var5.setBaseOutlinePaint(var17, false);
    var1.setLabelPaint(var17);
    org.jfree.chart.util.LengthAdjustmentType var22 = var1.getLabelOffsetType();
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    int var24 = var23.getColumnCount();
    var23.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var28 = null;
    var23.setSeriesNegativeItemLabelPosition(100, var28, true);
    var23.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
    int var38 = var37.getColumnCount();
    var37.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    int var43 = var42.getColumnCount();
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var47 = var46.isNegativeArrowVisible();
    var46.setAutoRangeStickyZero(false);
    java.awt.Stroke var50 = var46.getTickMarkStroke();
    var42.setSeriesOutlineStroke(1, var50, false);
    var37.setSeriesOutlineStroke(0, var50, false);
    var36.setAxisLineStroke(var50);
    var23.setBaseStroke(var50, true);
    boolean var58 = var22.equals((java.lang.Object)var23);
    double var59 = var23.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.2d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test226"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    int var39 = var33.getDomainAxisCount();
    org.jfree.chart.util.SortOrder var40 = var33.getRowRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test227"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var34.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var37 = null;
    var34.markerChanged(var37);
    boolean var39 = var34.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var40 = var34.getLegendItems();
    var0.setPlot(var34);
    org.jfree.chart.axis.ValueAxis var43 = var34.getRangeAxisForDataset(1);
    int var44 = var34.getWeight();
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
    org.jfree.chart.util.RectangleInsets var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var45.setLegendItemGraphicPadding(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test228"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var4 = var3.brighter();
    java.awt.Color var7 = java.awt.Color.getColor("RangeType.FULL", 100);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    double var9 = var8.getContentXOffset();
    java.lang.Object var10 = var8.clone();
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var8.addChangeListener(var11);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    var13.setHeight(100.0d);
    boolean var16 = var13.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var18 = var17.getErrorIndicatorPaint();
    var13.setPaint(var18);
    org.jfree.chart.ChartColor var23 = new org.jfree.chart.ChartColor(4, 1, 100);
    var13.setBackgroundPaint((java.awt.Paint)var23);
    int var25 = var23.getGreen();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var26 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    boolean var27 = var26.getAutoPopulateSeriesStroke();
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    var32.zoomRange((-1.0d), 0.0d);
    boolean var36 = var32.isPositiveArrowVisible();
    boolean var37 = var32.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    int var39 = var38.getColumnCount();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var43 = var42.isNegativeArrowVisible();
    var42.setAutoRangeStickyZero(false);
    java.awt.Stroke var46 = var42.getTickMarkStroke();
    var38.setSeriesOutlineStroke(1, var46, false);
    boolean var50 = var38.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var38.setBasePaint(var57);
    org.jfree.chart.labels.CategoryToolTipGenerator var59 = null;
    var38.setBaseToolTipGenerator(var59);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var28, var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
    var61.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var61.markerChanged(var64);
    boolean var66 = var61.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var67 = var61.getLegendItems();
    org.jfree.chart.ChartColor var71 = new org.jfree.chart.ChartColor(4, 1, 100);
    var61.setNoDataMessagePaint((java.awt.Paint)var71);
    var26.setErrorIndicatorPaint((java.awt.Paint)var71);
    float[] var74 = null;
    float[] var75 = var71.getComponents(var74);
    float[] var76 = var23.getRGBComponents(var75);
    boolean var77 = var8.equals((java.lang.Object)var75);
    float[] var78 = var7.getColorComponents(var75);
    float[] var79 = var3.getRGBColorComponents(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test229"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.plot.ValueMarker var4 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var5 = var4.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var7 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var1, var2, var5, 0.0d);
    java.lang.Comparable var8 = var7.getCategory();
    java.lang.String var9 = var7.toString();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryItemLabelGenerator var33 = var10.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var34 = null;
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    var38.zoomRange((-1.0d), 0.0d);
    boolean var42 = var38.isPositiveArrowVisible();
    boolean var43 = var38.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    int var45 = var44.getColumnCount();
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var49 = var48.isNegativeArrowVisible();
    var48.setAutoRangeStickyZero(false);
    java.awt.Stroke var52 = var48.getTickMarkStroke();
    var44.setSeriesOutlineStroke(1, var52, false);
    boolean var56 = var44.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    var58.zoomRange((-1.0d), 0.0d);
    boolean var62 = var58.isPositiveArrowVisible();
    java.awt.Paint var63 = var58.getAxisLinePaint();
    var44.setBasePaint(var63);
    org.jfree.chart.labels.CategoryToolTipGenerator var65 = null;
    var44.setBaseToolTipGenerator(var65);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var34, var36, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var44);
    var67.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var70 = null;
    var67.markerChanged(var70);
    org.jfree.chart.util.SortOrder var72 = var67.getRowRenderingOrder();
    boolean var73 = var10.hasListener((java.util.EventListener)var67);
    org.jfree.chart.util.RectangleInsets var78 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, (-1.0d), 10.0d);
    double var80 = var78.calculateLeftOutset(10.0d);
    double var82 = var78.extendWidth(0.05d);
    var67.setInsets(var78);
    boolean var84 = var7.equals((java.lang.Object)var78);
    org.jfree.chart.text.TextBlockAnchor var85 = var7.getLabelAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "1"+ "'", var8.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 11.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test230"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "CategoryLabelEntity: category=false, tooltip=, url=0", var3);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test231"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var4 = var3.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var6 = var5.getColumnCount();
//     var5.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var5.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var10 = var9.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var12 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0d, "0", var4, var10, Double.POSITIVE_INFINITY);
//     double var13 = var12.getValue();
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(6.0d, Double.NaN, 6.0d, Double.NaN);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
//     double var21 = var19.calculateRightInset(8.0d);
//     org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.util.RectangleInsets var24 = var23.getLabelOffset();
//     org.jfree.chart.util.RectangleInsets var25 = var23.getLabelOffset();
//     var23.setValue((-1.0d));
//     java.awt.Paint var28 = var23.getOutlinePaint();
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(var19, var28);
//     boolean var30 = var12.equals((java.lang.Object)var19);
//     double var31 = var12.getValue();
//     double var32 = var12.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 100.0d);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test232"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    double var1 = var0.getContentXOffset();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var4 = var3.getBackgroundPaint();
    java.awt.Paint var5 = var3.getPaint();
    java.awt.Font var6 = var3.getFont();
    org.jfree.chart.util.HorizontalAlignment var7 = var3.getHorizontalAlignment();
    var0.setTextAlignment(var7);
    var0.setURLText("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]");
    var0.setHeight(6.0d);
    org.jfree.chart.util.HorizontalAlignment var13 = var0.getTextAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test233"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
    org.jfree.chart.block.CenterArrangement var3 = new org.jfree.chart.block.CenterArrangement();
    var3.clear();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var3);
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var7 = var6.getBackgroundPaint();
    java.awt.Paint var8 = var6.getPaint();
    java.lang.String var9 = var6.getToolTipText();
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var11 = var10.getBackgroundPaint();
    java.awt.Paint var12 = var10.getPaint();
    boolean var13 = var10.getExpandToFitSpace();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var15 = var14.getBackgroundPaint();
    java.awt.Paint var16 = var14.getPaint();
    java.awt.Font var17 = var14.getFont();
    org.jfree.chart.util.HorizontalAlignment var18 = var14.getHorizontalAlignment();
    var10.setHorizontalAlignment(var18);
    var6.setTextAlignment(var18);
    boolean var21 = var0.equals((java.lang.Object)var18);
    java.lang.String var22 = var18.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var22.equals("HorizontalAlignment.CENTER"));

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest6.test234"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var5.zoomRange((-1.0d), 0.0d);
//     boolean var9 = var5.isPositiveArrowVisible();
//     boolean var10 = var5.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var12 = var11.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var16 = var15.isNegativeArrowVisible();
//     var15.setAutoRangeStickyZero(false);
//     java.awt.Stroke var19 = var15.getTickMarkStroke();
//     var11.setSeriesOutlineStroke(1, var19, false);
//     boolean var23 = var11.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var25.zoomRange((-1.0d), 0.0d);
//     boolean var29 = var25.isPositiveArrowVisible();
//     java.awt.Paint var30 = var25.getAxisLinePaint();
//     var11.setBasePaint(var30);
//     org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
//     var11.setBaseToolTipGenerator(var32);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
//     org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
//     boolean var38 = var0.hasListener((java.util.EventListener)var34);
//     org.jfree.data.general.PieDataset var40 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, 5);
//     java.util.List var41 = var0.getColumnKeys();
//     org.jfree.data.KeyToGroupMap var42 = null;
//     org.jfree.data.Range var43 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var42);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test235"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.axis.NumberTickUnit var13 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var15 = var13.valueToString(0.0d);
    var1.setTickUnit(var13, true, false);
    var1.setFixedAutoRange(3.0d);
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    var22.setBaseSeriesVisible(false);
    java.awt.Font var26 = var22.getBaseItemLabelFont();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Font var28 = var27.getNoDataMessageFont();
    var27.setRangeCrosshairValue((-1.0d));
    java.awt.Paint var31 = var27.getDomainGridlinePaint();
    org.jfree.chart.text.TextLine var32 = new org.jfree.chart.text.TextLine("CategoryLabelEntity: category=false, tooltip=, url=0", var26, var31);
    var1.setTickLabelFont(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "0"+ "'", var15.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test236"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    boolean var22 = var0.getItemVisible(4, 5);
    java.lang.Boolean var24 = var0.getSeriesVisibleInLegend(0);
    org.jfree.chart.labels.ItemLabelPosition var26 = var0.getSeriesPositiveItemLabelPosition(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test237"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = var1.getLegendItemLabelGenerator();
    java.awt.Shape var6 = var1.getItemShape(5, (-1));
    org.jfree.chart.entity.CategoryLabelEntity var9 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)11.05d, var6, "NOID", "TextAnchor.CENTER");
    java.lang.String var10 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "CategoryLabelEntity: category=11.05, tooltip=NOID, url=TextAnchor.CENTER"+ "'", var10.equals("CategoryLabelEntity: category=11.05, tooltip=NOID, url=TextAnchor.CENTER"));

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test238"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    org.jfree.chart.util.SortOrder var47 = var33.getColumnRenderingOrder();
    org.jfree.chart.event.AxisChangeEvent var48 = null;
    var33.axisChanged(var48);
    java.awt.Stroke var50 = var33.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test239"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var1.valueToJava2D(4.0d, var8, var9);
    java.lang.Object var11 = var1.clone();
    double var12 = var1.getAutoRangeMinimumSize();
    org.jfree.chart.axis.NumberTickUnit var13 = var1.getTickUnit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test240"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
    org.jfree.chart.block.CenterArrangement var3 = new org.jfree.chart.block.CenterArrangement();
    var3.clear();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var3);
    var3.clear();

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test241"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var0.setSeriesToolTipGenerator(1, var14);
    int var16 = var0.getRowCount();
    boolean var17 = var0.getBaseCreateEntities();
    boolean var19 = var0.isSeriesVisibleInLegend((-33));
    org.jfree.chart.labels.ItemLabelPosition var21 = var0.getSeriesPositiveItemLabelPosition(0);
    java.awt.Paint var23 = var0.getSeriesOutlinePaint((-1));
    var0.setIncludeBaseInRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test242"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    java.awt.Shape var21 = var0.getSeriesShape(0);
    java.awt.Stroke var23 = var0.getSeriesStroke(100);
    boolean var26 = var0.isItemLabelVisible(1, 10);
    boolean var29 = var0.isItemLabelVisible(5, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test243"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.setLicenceName("UnitType.ABSOLUTE");
    java.lang.String var3 = var0.getVersion();
    var0.setCopyright("RectangleEdge.BOTTOM");
    java.awt.Image var6 = null;
    var0.setLogo(var6);
    var0.setLicenceText("CategoryLabelEntity: category=false, tooltip=, url=0");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test244"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var4 = var3.isNegativeArrowVisible();
    var3.setAutoRangeStickyZero(false);
    java.awt.Stroke var7 = var3.getTickMarkStroke();
    var3.setAutoRangeMinimumSize(100.0d);
    var0.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var3, false);
    var3.setAutoRange(true);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(6.0d, Double.NaN, 6.0d, Double.NaN);
    org.jfree.chart.util.RectangleInsets var19 = var18.getInsets();
    var3.setTickLabelInsets(var19);
    org.jfree.chart.event.AxisChangeEvent var21 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var3);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    var22.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var22.setMargin(var29);
    double var32 = var29.calculateTopInset(0.0d);
    java.lang.String var33 = var29.toString();
    var3.setLabelInsets(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]"+ "'", var33.equals("RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]"));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test245"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var5 = var4.getMarkerBand();
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.lang.Object var7 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test246"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.data.general.DatasetGroup var38 = var33.getDatasetGroup();
    org.jfree.chart.axis.AxisSpace var39 = var33.getFixedRangeAxisSpace();
    org.jfree.data.category.CategoryDataset var40 = var33.getDataset();
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33);
    var33.clearDomainMarkers(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest6.test247"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.text.TextLine var1 = var0.getLastLine();
    java.util.List var2 = var0.getLines();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    var4.setHeight(100.0d);
    java.awt.Font var7 = var4.getFont();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.Paint var11 = var9.getPaint();
    java.awt.Font var12 = var9.getFont();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var12);
    var4.setFont(var12);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    var19.zoomRange((-1.0d), 0.0d);
    boolean var23 = var19.isPositiveArrowVisible();
    boolean var24 = var19.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    int var26 = var25.getColumnCount();
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var30 = var29.isNegativeArrowVisible();
    var29.setAutoRangeStickyZero(false);
    java.awt.Stroke var33 = var29.getTickMarkStroke();
    var25.setSeriesOutlineStroke(1, var33, false);
    boolean var37 = var25.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("hi!");
    var39.zoomRange((-1.0d), 0.0d);
    boolean var43 = var39.isPositiveArrowVisible();
    java.awt.Paint var44 = var39.getAxisLinePaint();
    var25.setBasePaint(var44);
    org.jfree.chart.labels.CategoryToolTipGenerator var46 = null;
    var25.setBaseToolTipGenerator(var46);
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var15, var17, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
    int var50 = var49.getColumnCount();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var54 = var53.isNegativeArrowVisible();
    var53.setAutoRangeStickyZero(false);
    java.awt.Stroke var57 = var53.getTickMarkStroke();
    var49.setSeriesOutlineStroke(1, var57, false);
    var49.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var63 = null;
    var49.setSeriesToolTipGenerator(1, var63);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var65 = var49.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var68 = var49.getPositiveItemLabelPosition(10, (-1));
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var69 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var49};
    var48.setRenderers(var69);
    java.awt.Paint var71 = var48.getOutlinePaint();
    org.jfree.chart.text.TextLine var72 = new org.jfree.chart.text.TextLine("0", var12, var71);
    var0.addLine(var72);
    org.jfree.chart.text.TextLine var75 = new org.jfree.chart.text.TextLine("0");
    var0.addLine(var75);
    org.jfree.chart.util.HorizontalAlignment var77 = var0.getLineAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

}
