
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)(short)1, (java.lang.Object)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("", var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"0", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 100.0d, 100.0d, 10.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    var2.zoomRange((-1.0d), 0.0d);
    boolean var6 = var0.equals((java.lang.Object)(-1.0d));
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var0.createInsetRectangle(var7, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)'#', var1, var2, var3, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    var6.zoomRange((-1.0d), 0.0d);
    boolean var10 = var6.isPositiveArrowVisible();
    java.awt.Paint var11 = var6.getAxisLinePaint();
    java.awt.Stroke var12 = null;
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem(var0, "0", "", "hi!", var4, var11, var12, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 1.0d, false);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    boolean var7 = var1.getAutoRangeStickyZero();
    double var8 = var1.getUpperBound();
    org.jfree.data.Range var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(var9, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(1.0d, var1, var2, 100.0d, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    var8.zoomRange((-1.0d), 0.0d);
    boolean var12 = var8.isPositiveArrowVisible();
    java.awt.Paint var13 = var8.getAxisLinePaint();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    java.awt.Stroke var22 = null;
    java.awt.Shape var24 = null;
    java.awt.Stroke var25 = null;
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    var27.zoomRange((-1.0d), 0.0d);
    boolean var31 = var27.isPositiveArrowVisible();
    java.awt.Paint var32 = var27.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem(var0, "0", "", "", false, var5, false, var13, false, var21, var22, true, var24, var25, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("0", var1);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDownArrow(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("hi!");
    var7.zoomRange((-1.0d), 0.0d);
    boolean var11 = var7.isPositiveArrowVisible();
    java.awt.Paint var12 = var7.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("", "", "", "0", var4, var5, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    java.awt.Stroke var7 = null;
    org.jfree.chart.util.RectangleInsets var12 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var13 = new org.jfree.chart.block.LineBorder(var6, var7, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, (-1.0d), 10.0d);
    double var6 = var4.calculateLeftOutset(10.0d);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var4.createInsetRectangle(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(10.0d, var1, var2, 100.0d, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var5.zoomRange((-1.0d), 0.0d);
//     boolean var9 = var5.isPositiveArrowVisible();
//     java.awt.Paint var10 = var5.getAxisLinePaint();
//     org.jfree.chart.util.Layer var11 = null;
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     var0.drawAnnotations(var1, var2, var3, (org.jfree.chart.axis.ValueAxis)var5, var11, var13);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.cursorDown(0.0d);
    var0.setMax(1.0d);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var3.zoomRange((-1.0d), 0.0d);
//     boolean var7 = var3.isPositiveArrowVisible();
//     java.awt.Paint var8 = var3.getAxisLinePaint();
//     org.jfree.chart.text.TextMeasurer var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("0", var1, var8, 10.0f, var10);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.Font var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickLabelFont(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     var0.drawItem(var1, var2, var3, var4, var5, var6, var7, 100, 100, 1);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    double var1 = var0.getContentXOffset();
    org.jfree.chart.util.VerticalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setVerticalAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Point2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var1.getSubplotIndex(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var9 = var8.isNegativeArrowVisible();
    var8.setAutoRangeStickyZero(false);
    java.awt.Stroke var12 = var8.getTickMarkStroke();
    org.jfree.chart.util.RectangleInsets var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var14 = new org.jfree.chart.block.LineBorder(var6, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var2 = null;
    var1.addChangeListener(var2);
    java.awt.Font var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    java.lang.Object var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1, var2, 0.0d, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)1.0f, "", var2, var3, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.CategoryPlot var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var0.drawDomainGridline(var2, var3, var4, 1.0d);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    var2.zoomRange((-1.0d), 0.0d);
    boolean var6 = var2.isPositiveArrowVisible();
    java.awt.Paint var7 = var2.getAxisLinePaint();
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    int var9 = var8.getColumnCount();
    var8.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    int var14 = var13.getColumnCount();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var18 = var17.isNegativeArrowVisible();
    var17.setAutoRangeStickyZero(false);
    java.awt.Stroke var21 = var17.getTickMarkStroke();
    var13.setSeriesOutlineStroke(1, var21, false);
    var8.setSeriesOutlineStroke(0, var21, false);
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    var27.zoomRange((-1.0d), 0.0d);
    boolean var31 = var27.isPositiveArrowVisible();
    java.awt.Paint var32 = var27.getAxisLinePaint();
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    int var34 = var33.getColumnCount();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var38 = var37.isNegativeArrowVisible();
    var37.setAutoRangeStickyZero(false);
    java.awt.Stroke var41 = var37.getTickMarkStroke();
    var33.setSeriesOutlineStroke(1, var41, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(100.0d, var7, var21, var32, var41, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 10.0d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.awt.Font var1 = null;
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("hi!");
    var3.zoomRange((-1.0d), 0.0d);
    boolean var7 = var3.isPositiveArrowVisible();
    java.awt.Paint var8 = var3.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("0", var1, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("0", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.axis.Axis var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var3 = null;
    var2.addChangeListener(var3);
    java.awt.Shape var5 = var2.getRightArrow();
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var7.setSeriesShape(100, var12, false);
    org.jfree.chart.entity.CategoryLabelEntity var17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var12, "", "0");
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var5, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var21 = new org.jfree.chart.entity.AxisLabelEntity(var0, var5, "CategoryLabelEntity: category=false, tooltip=, url=0", "0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)true, var1, var2, var3, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var0.setSeriesShape(100, var5, false);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.plot.CategoryMarker var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.drawDomainMarker(var8, var9, var10, var11, var12);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var1.zoomRange((-1.0d), 0.0d);
//     boolean var5 = var1.isPositiveArrowVisible();
//     java.awt.Paint var6 = var1.getAxisLinePaint();
//     org.jfree.chart.util.RectangleInsets var7 = var1.getTickLabelInsets();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     org.jfree.chart.ChartRenderingInfo var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = new org.jfree.chart.plot.PlotRenderingInfo(var13);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var16 = var15.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var20 = var19.isNegativeArrowVisible();
//     var19.setAutoRangeStickyZero(false);
//     java.awt.Stroke var23 = var19.getTickMarkStroke();
//     var15.setSeriesOutlineStroke(1, var23, false);
//     boolean var27 = var15.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var29.zoomRange((-1.0d), 0.0d);
//     boolean var33 = var29.isPositiveArrowVisible();
//     java.awt.Paint var34 = var29.getAxisLinePaint();
//     var15.setBasePaint(var34);
//     boolean var36 = var14.equals((java.lang.Object)var34);
//     org.jfree.chart.axis.AxisState var37 = var1.draw(var8, 0.0d, var10, var11, var12, var14);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemLabelGenerator();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var8.zoomRange((-1.0d), 0.0d);
//     boolean var12 = var8.isPositiveArrowVisible();
//     boolean var13 = var8.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var15 = var14.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var19 = var18.isNegativeArrowVisible();
//     var18.setAutoRangeStickyZero(false);
//     java.awt.Stroke var22 = var18.getTickMarkStroke();
//     var14.setSeriesOutlineStroke(1, var22, false);
//     boolean var26 = var14.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var28.zoomRange((-1.0d), 0.0d);
//     boolean var32 = var28.isPositiveArrowVisible();
//     java.awt.Paint var33 = var28.getAxisLinePaint();
//     var14.setBasePaint(var33);
//     org.jfree.chart.labels.CategoryToolTipGenerator var35 = null;
//     var14.setBaseToolTipGenerator(var35);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var4, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.AxisLocation var38 = var37.getDomainAxisLocation();
//     java.awt.geom.Rectangle2D var39 = null;
//     var0.drawDomainGridline(var3, var37, var39, 0.0d);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var2 = var0.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var3 = null;
    org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)1L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)10.0f, (java.lang.Number)(short)1);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("CategoryLabelEntity: category=false, tooltip=, url=0");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    int var14 = var13.getColumnCount();
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var13.setSeriesShape(100, var18, false);
    var4.setSeriesShape(1, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-1), var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    float[] var4 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(10, 4, 0, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var2 = var1.getColumnCount();
//     java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var1.setSeriesShape(100, var6, false);
//     org.jfree.chart.entity.CategoryLabelEntity var11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var6, "", "0");
//     java.lang.Comparable var12 = var11.getKey();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var15 = null;
//     var14.addChangeListener(var15);
//     java.awt.Shape var17 = var14.getRightArrow();
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var20 = var19.getColumnCount();
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var19.setSeriesShape(100, var24, false);
//     org.jfree.chart.entity.CategoryLabelEntity var29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var24, "", "0");
//     boolean var30 = org.jfree.chart.util.ShapeUtilities.equal(var17, var24);
//     var11.setArea(var24);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    var41.setBaseSeriesVisible(false);
    var41.setBaseSeriesVisible(true);
    var33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var41, true);
    org.jfree.chart.plot.PlotOrientation var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setOrientation(var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    var1.setAutoRangeStickyZero(false);
    java.awt.Font var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("AxisLocation.BOTTOM_OR_LEFT", var1, var2);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var5 = var4.getMarkerBand();
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var4.refreshTicks(var7, var8, var9, var10);
    double var12 = var4.getFixedAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    boolean var7 = var1.getAutoRangeStickyZero();
    var1.setLabelAngle((-1.0d));
    var1.setUpperBound(0.0d);
    org.jfree.data.Range var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var8 = var7.getErrorIndicatorPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem(var0, "CategoryLabelEntity: category=false, tooltip=, url=0", "", "AxisLocation.BOTTOM_OR_LEFT", var6, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var33.markerChanged(var36);
//     boolean var38 = var33.isOutlineVisible();
//     int var39 = var33.getDomainAxisCount();
//     org.jfree.data.category.CategoryDataset var40 = null;
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var44.zoomRange((-1.0d), 0.0d);
//     boolean var48 = var44.isPositiveArrowVisible();
//     boolean var49 = var44.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var51 = var50.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var55 = var54.isNegativeArrowVisible();
//     var54.setAutoRangeStickyZero(false);
//     java.awt.Stroke var58 = var54.getTickMarkStroke();
//     var50.setSeriesOutlineStroke(1, var58, false);
//     boolean var62 = var50.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var64.zoomRange((-1.0d), 0.0d);
//     boolean var68 = var64.isPositiveArrowVisible();
//     java.awt.Paint var69 = var64.getAxisLinePaint();
//     var50.setBasePaint(var69);
//     org.jfree.chart.labels.CategoryToolTipGenerator var71 = null;
//     var50.setBaseToolTipGenerator(var71);
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var40, var42, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
//     var73.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var76 = null;
//     var73.markerChanged(var76);
//     org.jfree.chart.util.SortOrder var78 = var73.getRowRenderingOrder();
//     var33.setParent((org.jfree.chart.plot.Plot)var73);
//     
//     // Checks the contract:  equals-hashcode on var33 and var73
//     assertTrue("Contract failed: equals-hashcode on var33 and var73", var33.equals(var73) ? var33.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var33
//     assertTrue("Contract failed: equals-hashcode on var73 and var33", var73.equals(var33) ? var73.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var3 = var2.getColumnCount();
//     var2.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var8 = var7.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var12 = var11.isNegativeArrowVisible();
//     var11.setAutoRangeStickyZero(false);
//     java.awt.Stroke var15 = var11.getTickMarkStroke();
//     var7.setSeriesOutlineStroke(1, var15, false);
//     var2.setSeriesOutlineStroke(0, var15, false);
//     var0.setBaseOutlineStroke(var15);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var7.", var0.equals(var7) == var7.equals(var0));
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"0", var3, "0", "CategoryLabelEntity: category=false, tooltip=, url=0");
    java.lang.String var7 = var6.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "poly"+ "'", var7.equals("poly"));

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    boolean var7 = var1.getAutoRangeStickyZero();
    double var8 = var1.getUpperBound();
    var1.setTickLabelsVisible(true);
    java.text.NumberFormat var11 = null;
    var1.setNumberFormatOverride(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     java.awt.geom.Rectangle2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = var0.expand(var1, var2);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("poly", var1, 0.0d, 0.0f, 0.0f);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "AxisLocation.BOTTOM_OR_LEFT", var3);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 10.0d, 100.0d, 10, (java.lang.Comparable)10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("hi!");
    var2.zoomRange((-1.0d), 0.0d);
    boolean var6 = var2.isPositiveArrowVisible();
    java.awt.Paint var7 = var2.getAxisLinePaint();
    boolean var8 = var2.getAutoRangeStickyZero();
    double var9 = var2.getUpperBound();
    var2.setTickLabelsVisible(true);
    java.awt.Paint var12 = var2.getLabelPaint();
    java.awt.Stroke var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(0.2d, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.ItemLabelPosition var3 = null;
    var0.setPositiveItemLabelPositionFallback(var3);
    var0.setAutoPopulateSeriesStroke(false);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(0.2d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var1.setSeriesShape(100, var6, false);
    org.jfree.chart.entity.CategoryLabelEntity var11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var6, "", "0");
    java.lang.String var12 = var11.getShapeType();
    java.lang.String var13 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "poly"+ "'", var12.equals("poly"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=0"+ "'", var13.equals("CategoryLabelEntity: category=false, tooltip=, url=0"));

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"0", var3, "0", "CategoryLabelEntity: category=false, tooltip=, url=0");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var7 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var8 = null;
//     java.lang.String var9 = var6.getImageMapAreaTag(var7, var8);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    org.jfree.chart.annotations.CategoryAnnotation var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addAnnotation(var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var3 = var2.getColumnCount();
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var2.setSeriesShape(100, var7, false);
//     org.jfree.chart.entity.CategoryLabelEntity var12 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var7, "", "0");
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var7, 10.0d, 10.0f, 0.0f);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "", "0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("0", var1, var2);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 100.0d, var2);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    var0.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    int var15 = var14.getColumnCount();
    var14.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    int var20 = var19.getColumnCount();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    var23.setAutoRangeStickyZero(false);
    java.awt.Stroke var27 = var23.getTickMarkStroke();
    var19.setSeriesOutlineStroke(1, var27, false);
    var14.setSeriesOutlineStroke(0, var27, false);
    var13.setAxisLineStroke(var27);
    var0.setBaseStroke(var27, true);
    java.awt.Paint var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlinePaint(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var35 = var34.getOpposite();
    org.jfree.chart.plot.PlotOrientation var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var37 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var35, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var2 = null;
    var1.addChangeListener(var2);
    java.awt.Shape var4 = var1.getRightArrow();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var7 = null;
    var6.addChangeListener(var7);
    java.awt.Shape var9 = var6.getRightArrow();
    var1.setRightArrow(var9);
    java.lang.String var11 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryLabelEntity: category=false, tooltip=, url=0", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

//  public void test115() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("0", var1, 100.0f, 1.0f, var4, 0.2d, (-1.0f), 0.0f);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var6 = null;
    var5.addChangeListener(var6);
    java.awt.Shape var8 = var5.getRightArrow();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var11 = null;
    var10.addChangeListener(var11);
    java.awt.Shape var13 = var10.getRightArrow();
    var5.setRightArrow(var13);
    org.jfree.chart.entity.ChartEntity var15 = new org.jfree.chart.entity.ChartEntity(var13);
    org.jfree.chart.entity.ChartEntity var17 = new org.jfree.chart.entity.ChartEntity(var13, "CategoryLabelEntity: category=false, tooltip=, url=0");
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    var19.zoomRange((-1.0d), 0.0d);
    boolean var23 = var19.isPositiveArrowVisible();
    java.awt.Paint var24 = var19.getAxisLinePaint();
    boolean var25 = var19.getAutoRangeStickyZero();
    double var26 = var19.getUpperBound();
    var19.setTickLabelsVisible(true);
    java.awt.Paint var29 = var19.getLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem(var0, "", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", var13, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var1.valueToJava2D(4.0d, var8, var9);
    var1.setVerticalTickLabels(false);
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.util.RectangleEdge var15 = null;
    double var16 = var1.java2DToValue(1.0d, var14, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == Double.POSITIVE_INFINITY);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var7 = var6.isNegativeArrowVisible();
    var6.setAutoRangeStickyZero(false);
    java.awt.Stroke var10 = var6.getTickMarkStroke();
    var2.setSeriesOutlineStroke(1, var10, false);
    boolean var14 = var2.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    var2.setBasePaint(var21);
    boolean var23 = var1.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.RendererState var24 = new org.jfree.chart.renderer.RendererState(var1);
    org.jfree.chart.entity.EntityCollection var25 = var24.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
//     org.jfree.chart.text.TextFragment var1 = null;
//     var0.addFragment(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var0.calculateDimensions(var3);
// 
//   }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var2 = var0.getObject((java.lang.Comparable)1);
//     org.jfree.chart.JFreeChart var3 = null;
//     org.jfree.chart.event.ChartProgressEvent var6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var0, var3, 0, 0);
//     java.lang.Object var7 = var0.clone();
//     java.lang.Object var8 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var7 and var8
//     assertTrue("Contract failed: equals-hashcode on var7 and var8", var7.equals(var8) ? var7.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var7
//     assertTrue("Contract failed: equals-hashcode on var8 and var7", var8.equals(var7) ? var8.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var6 = var5.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var10 = var9.isNegativeArrowVisible();
//     var9.setAutoRangeStickyZero(false);
//     java.awt.Stroke var13 = var9.getTickMarkStroke();
//     var5.setSeriesOutlineStroke(1, var13, false);
//     var0.setSeriesOutlineStroke(0, var13, false);
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseCreateEntities(true);
//     java.awt.Stroke var24 = var0.getItemStroke(100, 0);
//     java.awt.Graphics2D var25 = null;
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var30.zoomRange((-1.0d), 0.0d);
//     boolean var34 = var30.isPositiveArrowVisible();
//     boolean var35 = var30.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var37 = var36.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var41 = var40.isNegativeArrowVisible();
//     var40.setAutoRangeStickyZero(false);
//     java.awt.Stroke var44 = var40.getTickMarkStroke();
//     var36.setSeriesOutlineStroke(1, var44, false);
//     boolean var48 = var36.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var50.zoomRange((-1.0d), 0.0d);
//     boolean var54 = var50.isPositiveArrowVisible();
//     java.awt.Paint var55 = var50.getAxisLinePaint();
//     var36.setBasePaint(var55);
//     org.jfree.chart.labels.CategoryToolTipGenerator var57 = null;
//     var36.setBaseToolTipGenerator(var57);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var26, var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     var59.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var62 = null;
//     var59.markerChanged(var62);
//     org.jfree.chart.util.SortOrder var64 = var59.getRowRenderingOrder();
//     org.jfree.data.KeyedObjects var65 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var67 = var65.getObject((java.lang.Comparable)1);
//     org.jfree.chart.JFreeChart var68 = null;
//     org.jfree.chart.event.ChartProgressEvent var71 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var65, var68, 0, 0);
//     boolean var72 = var59.equals((java.lang.Object)var68);
//     java.awt.Paint var73 = var59.getOutlinePaint();
//     java.awt.geom.Rectangle2D var74 = null;
//     var0.drawBackground(var25, var59, var74);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.plot.CategoryMarker var38 = null;
    org.jfree.chart.util.Layer var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addDomainMarker(var38, var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    org.jfree.chart.plot.PlotOrientation var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var36 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var34, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setHeight(100.0d);
    java.awt.Font var3 = var0.getFont();
    org.jfree.chart.util.RectangleEdge var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPosition(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setHeight(100.0d);
    java.awt.Font var3 = var0.getFont();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var6 = var5.getBackgroundPaint();
    java.awt.Paint var7 = var5.getPaint();
    java.awt.Font var8 = var5.getFont();
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("", var8);
    var0.setFont(var8);
    org.jfree.chart.util.VerticalAlignment var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setVerticalAlignment(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     var5.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.labels.ItemLabelPosition var8 = null;
//     var5.setPositiveItemLabelPositionFallback(var8);
//     org.jfree.chart.labels.ItemLabelPosition var10 = var5.getBaseNegativeItemLabelPosition();
//     var0.setSeriesNegativeItemLabelPosition(1, var10);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var0.", var5.equals(var0) == var0.equals(var5));
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    boolean var34 = var33.isRangeCrosshairVisible();
    org.jfree.chart.annotations.CategoryAnnotation var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var36 = var33.removeAnnotation(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    var0.setBaseCreateEntities(true, true);
    java.awt.Stroke var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateY(10.0d);
    var0.setTranslateY(0.0d);
    var0.setGenerateEntities(true);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setTickMarksVisible(false);
    var1.setTickMarkInsideLength((-1.0f));

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.KeyToGroupMap var1 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, var1);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var1 = var0.getErrorIndicatorPaint();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    var4.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var14 = var13.isNegativeArrowVisible();
    var13.setAutoRangeStickyZero(false);
    java.awt.Stroke var17 = var13.getTickMarkStroke();
    var9.setSeriesOutlineStroke(1, var17, false);
    var4.setSeriesOutlineStroke(0, var17, false);
    var3.setAxisLineStroke(var17);
    var0.setErrorIndicatorStroke(var17);
    java.lang.Boolean var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-1), var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var2 = var1.getBackgroundPaint();
//     java.awt.Paint var3 = var1.getPaint();
//     java.awt.Font var4 = var1.getFont();
//     org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("", var4);
//     java.awt.Paint var6 = var5.getPaint();
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var9 = var8.getColumnCount();
//     var8.setBaseSeriesVisible(false);
//     var8.setBaseSeriesVisible(true, true);
//     java.awt.Paint var17 = var8.getItemOutlinePaint((-1), 0);
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var17};
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var20.zoomRange((-1.0d), 0.0d);
//     boolean var24 = var20.isPositiveArrowVisible();
//     java.awt.Paint var25 = var20.getAxisLinePaint();
//     boolean var26 = var20.getAutoRangeStickyZero();
//     double var27 = var20.getUpperBound();
//     var20.setTickLabelsVisible(true);
//     java.awt.Paint var30 = var20.getLabelPaint();
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var30};
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var34 = var33.isNegativeArrowVisible();
//     var33.setAutoRangeStickyZero(false);
//     java.awt.Stroke var37 = var33.getTickMarkStroke();
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var40 = var39.getColumnCount();
//     var39.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var45 = var44.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var49 = var48.isNegativeArrowVisible();
//     var48.setAutoRangeStickyZero(false);
//     java.awt.Stroke var52 = var48.getTickMarkStroke();
//     var44.setSeriesOutlineStroke(1, var52, false);
//     var39.setSeriesOutlineStroke(0, var52, false);
//     java.awt.Stroke[] var57 = new java.awt.Stroke[] { var52};
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     org.jfree.chart.renderer.category.BarRenderer var62 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var63 = var62.getColumnCount();
//     java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var62.setSeriesShape(100, var67, false);
//     org.jfree.chart.entity.CategoryLabelEntity var72 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var67, "", "0");
//     java.awt.Shape var73 = var72.getArea();
//     boolean var74 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var60, (java.lang.Object)var73);
//     java.awt.Shape[] var75 = new java.awt.Shape[] { var60};
//     org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var18, var31, var38, var57, var75);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var44.", var8.equals(var44) == var44.equals(var8));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var8 and var62.", var8.equals(var62) == var62.equals(var8));
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
//     org.jfree.chart.block.FlowArrangement var3 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var4 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var3.add((org.jfree.chart.block.Block)var4, (java.lang.Object)var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.data.Range var9 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, var9);
//     org.jfree.chart.block.RectangleConstraint var11 = var10.toUnconstrainedWidth();
//     org.jfree.chart.util.Size2D var12 = var1.arrange(var4, var7, var10);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    java.lang.String var7 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.ChartRenderingInfo var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    int var39 = var38.getColumnCount();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var43 = var42.isNegativeArrowVisible();
    var42.setAutoRangeStickyZero(false);
    java.awt.Stroke var46 = var42.getTickMarkStroke();
    var38.setSeriesOutlineStroke(1, var46, false);
    boolean var50 = var38.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var38.setBasePaint(var57);
    boolean var59 = var37.equals((java.lang.Object)var57);
    var33.handleClick(0, 100, var37);
    java.awt.Stroke var61 = var33.getOutlineStroke();
    org.jfree.chart.annotations.CategoryAnnotation var62 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addAnnotation(var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.plot.CategoryPlot var34 = var10.getPlot();
    org.jfree.chart.annotations.CategoryAnnotation var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.addAnnotation(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var0.setBasePaint(var19);
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var0.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    boolean var33 = var28.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var39 = var38.isNegativeArrowVisible();
    var38.setAutoRangeStickyZero(false);
    java.awt.Stroke var42 = var38.getTickMarkStroke();
    var34.setSeriesOutlineStroke(1, var42, false);
    boolean var46 = var34.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    java.awt.Paint var53 = var48.getAxisLinePaint();
    var34.setBasePaint(var53);
    org.jfree.chart.labels.CategoryToolTipGenerator var55 = null;
    var34.setBaseToolTipGenerator(var55);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var24, var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    var57.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var60 = null;
    var57.markerChanged(var60);
    org.jfree.chart.util.SortOrder var62 = var57.getRowRenderingOrder();
    boolean var63 = var0.hasListener((java.util.EventListener)var57);
    var57.setRangeCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "0", var3);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var2 = null;
//     var1.addChangeListener(var2);
//     java.awt.Shape var4 = var1.getRightArrow();
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var7 = null;
//     var6.addChangeListener(var7);
//     java.awt.Shape var9 = var6.getRightArrow();
//     var1.setRightArrow(var9);
//     org.jfree.chart.entity.TickLabelEntity var13 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "hi!");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var14 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var15 = null;
//     java.lang.String var16 = var13.getImageMapAreaTag(var14, var15);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var6 = var5.isNegativeArrowVisible();
    var5.setAutoRangeStickyZero(false);
    java.awt.Stroke var9 = var5.getTickMarkStroke();
    var5.setAutoRangeMinimumSize(100.0d);
    java.awt.Shape var12 = var5.getRightArrow();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    var53.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var56 = null;
    var53.markerChanged(var56);
    org.jfree.chart.util.SortOrder var58 = var53.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var61 = var60.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAxis[] var62 = new org.jfree.chart.axis.CategoryAxis[] { var60};
    var53.setDomainAxes(var62);
    org.jfree.chart.renderer.category.CategoryItemRenderer var64 = var53.getRenderer();
    java.awt.Stroke var65 = var53.getOutlineStroke();
    org.jfree.chart.renderer.category.BarRenderer var66 = new org.jfree.chart.renderer.category.BarRenderer();
    int var67 = var66.getColumnCount();
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var71 = var70.isNegativeArrowVisible();
    var70.setAutoRangeStickyZero(false);
    java.awt.Stroke var74 = var70.getTickMarkStroke();
    var66.setSeriesOutlineStroke(1, var74, false);
    boolean var78 = var66.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis("hi!");
    var80.zoomRange((-1.0d), 0.0d);
    boolean var84 = var80.isPositiveArrowVisible();
    java.awt.Paint var85 = var80.getAxisLinePaint();
    var66.setBasePaint(var85);
    org.jfree.chart.title.TextTitle var87 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var88 = var87.getBackgroundPaint();
    java.awt.Paint var89 = var87.getPaint();
    var66.setBaseItemLabelPaint(var89);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem(var0, "ChartChangeEventType.GENERAL", "", "AxisLocation.BOTTOM_OR_LEFT", var12, var19, var65, var89);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.plot.Marker var36 = null;
//     var33.addRangeMarker(var36);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var1.setSeriesShape(100, var6, false);
    org.jfree.chart.entity.CategoryLabelEntity var11 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var6, "", "0");
    java.awt.Shape var12 = var11.getArea();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.05d, 0.05d);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 6.0d, Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.ChartRenderingInfo var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    int var39 = var38.getColumnCount();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var43 = var42.isNegativeArrowVisible();
    var42.setAutoRangeStickyZero(false);
    java.awt.Stroke var46 = var42.getTickMarkStroke();
    var38.setSeriesOutlineStroke(1, var46, false);
    boolean var50 = var38.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var38.setBasePaint(var57);
    boolean var59 = var37.equals((java.lang.Object)var57);
    var33.handleClick(0, 100, var37);
    java.awt.Stroke var61 = var33.getOutlineStroke();
    org.jfree.chart.axis.ValueAxis var62 = var33.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();
    org.jfree.chart.util.RectangleInsets var2 = var0.getMargin();
    double var4 = var2.calculateBottomInset(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    double var5 = var4.getTop();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.LengthAdjustmentType var7 = null;
    org.jfree.chart.util.LengthAdjustmentType var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var4.createAdjustedRectangle(var6, var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0d);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.plot.CategoryPlot var34 = var10.getPlot();
    boolean var35 = var34.isRangeGridlinesVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var34.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("CategoryLabelEntity: category=false, tooltip=, url=0", var1);
// 
//   }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.ChartRenderingInfo var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    int var39 = var38.getColumnCount();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var43 = var42.isNegativeArrowVisible();
    var42.setAutoRangeStickyZero(false);
    java.awt.Stroke var46 = var42.getTickMarkStroke();
    var38.setSeriesOutlineStroke(1, var46, false);
    boolean var50 = var38.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var38.setBasePaint(var57);
    boolean var59 = var37.equals((java.lang.Object)var57);
    var33.handleClick(0, 100, var37);
    var33.clearRangeAxes();
    boolean var62 = var33.isRangeCrosshairLockedOnData();
    var33.setDrawSharedDomainAxis(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var8 = var7.getColumnCount();
//     var7.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var7.setSeriesNegativeItemLabelPosition(100, var12, true);
//     var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var22 = var21.getColumnCount();
//     var21.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var27 = var26.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var31 = var30.isNegativeArrowVisible();
//     var30.setAutoRangeStickyZero(false);
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var26.setSeriesOutlineStroke(1, var34, false);
//     var21.setSeriesOutlineStroke(0, var34, false);
//     var20.setAxisLineStroke(var34);
//     var7.setBaseStroke(var34, true);
//     var0.setSeriesOutlineStroke(0, var34, true);
//     org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
//     org.jfree.chart.block.FlowArrangement var50 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var51 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var50);
//     double var52 = var51.getContentXOffset();
//     var49.setWrapper(var51);
//     
//     // Checks the contract:  equals-hashcode on var44 and var50
//     assertTrue("Contract failed: equals-hashcode on var44 and var50", var44.equals(var50) ? var44.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var44
//     assertTrue("Contract failed: equals-hashcode on var50 and var44", var50.equals(var44) ? var50.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var51
//     assertTrue("Contract failed: equals-hashcode on var45 and var51", var45.equals(var51) ? var45.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var45
//     assertTrue("Contract failed: equals-hashcode on var51 and var45", var51.equals(var45) ? var51.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     org.jfree.chart.ChartRenderingInfo var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
//     org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var39 = var38.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var43 = var42.isNegativeArrowVisible();
//     var42.setAutoRangeStickyZero(false);
//     java.awt.Stroke var46 = var42.getTickMarkStroke();
//     var38.setSeriesOutlineStroke(1, var46, false);
//     boolean var50 = var38.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var52.zoomRange((-1.0d), 0.0d);
//     boolean var56 = var52.isPositiveArrowVisible();
//     java.awt.Paint var57 = var52.getAxisLinePaint();
//     var38.setBasePaint(var57);
//     boolean var59 = var37.equals((java.lang.Object)var57);
//     var33.handleClick(0, 100, var37);
//     var33.clearRangeAxes();
//     boolean var62 = var33.isRangeCrosshairLockedOnData();
//     java.awt.Graphics2D var63 = null;
//     java.awt.geom.Rectangle2D var64 = null;
//     java.awt.geom.Point2D var65 = null;
//     org.jfree.chart.plot.PlotState var66 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var67 = null;
//     var33.draw(var63, var64, var65, var66, var67);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.awt.Paint var0 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var2 = var1.getErrorIndicatorPaint();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    var5.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    var5.setSeriesOutlineStroke(0, var18, false);
    var4.setAxisLineStroke(var18);
    var1.setErrorIndicatorStroke(var18);
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    var25.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var32 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var25.setMargin(var32);
    double var34 = var32.getLeft();
    double var35 = var32.getTop();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder(var0, var18, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10.0d);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    var22.zoomRange((-1.0d), 0.0d);
    boolean var26 = var22.isPositiveArrowVisible();
    boolean var27 = var22.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var28.setBaseToolTipGenerator(var49);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var18, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    var0.setPlot(var51);
    double var53 = var0.getBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var0.setMargin(var7);
    double var10 = var7.calculateTopInset(0.0d);
    double var12 = var7.calculateBottomInset(10.0d);
    double var14 = var7.calculateLeftInset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     var0.setHeight(100.0d);
//     boolean var3 = var0.getNotify();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var6 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, var6);
//     org.jfree.chart.util.Size2D var8 = var0.arrange(var4, var7);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    java.lang.String var3 = var0.getURLText();
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTextAlignment(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    org.jfree.chart.ChartRenderingInfo var49 = null;
    org.jfree.chart.plot.PlotRenderingInfo var50 = new org.jfree.chart.plot.PlotRenderingInfo(var49);
    org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
    int var52 = var51.getColumnCount();
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var56 = var55.isNegativeArrowVisible();
    var55.setAutoRangeStickyZero(false);
    java.awt.Stroke var59 = var55.getTickMarkStroke();
    var51.setSeriesOutlineStroke(1, var59, false);
    boolean var63 = var51.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("hi!");
    var65.zoomRange((-1.0d), 0.0d);
    boolean var69 = var65.isPositiveArrowVisible();
    java.awt.Paint var70 = var65.getAxisLinePaint();
    var51.setBasePaint(var70);
    boolean var72 = var50.equals((java.lang.Object)var70);
    org.jfree.chart.renderer.RendererState var73 = new org.jfree.chart.renderer.RendererState(var50);
    java.awt.geom.Point2D var74 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.zoomRangeAxes(1.0E-8d, 0.0d, var50, var74);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var38 = var37.getColumnCount();
//     var37.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var43 = var42.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var47 = var46.isNegativeArrowVisible();
//     var46.setAutoRangeStickyZero(false);
//     java.awt.Stroke var50 = var46.getTickMarkStroke();
//     var42.setSeriesOutlineStroke(1, var50, false);
//     var37.setSeriesOutlineStroke(0, var50, false);
//     var37.setBaseSeriesVisible(false);
//     var37.setBaseCreateEntities(true);
//     int var59 = var37.getRowCount();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var61 = null;
//     var37.setSeriesItemLabelGenerator(4, var61, true);
//     var33.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.chart.renderer.category.BarRenderer var65 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var66 = var65.getColumnCount();
//     var65.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var69 = var65.getBasePositiveItemLabelPosition();
//     double var70 = var69.getAngle();
//     var37.setBasePositiveItemLabelPosition(var69, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var65 and var37.", var65.equals(var37) == var37.equals(var65));
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var4 = var2.toUnconstrainedWidth();
    double var5 = var2.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var0.setSeriesToolTipGenerator(1, var14);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var16 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var19.setMaximumCategoryLabelLines(0);
    var19.setMaximumCategoryLabelLines((-1));
    var19.setMaximumCategoryLabelLines((-1));
    double var26 = var19.getCategoryMargin();
    var19.setMaximumCategoryLabelWidthRatio(100.0f);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    var30.zoomRange((-1.0d), 0.0d);
    boolean var34 = var30.isPositiveArrowVisible();
    boolean var35 = var30.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleEdge var38 = null;
    double var39 = var30.valueToJava2D(4.0d, var37, var38);
    org.jfree.chart.axis.NumberTickUnit var41 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var43 = var41.valueToString(0.0d);
    var30.setTickUnit(var41, true, true);
    java.awt.Font var47 = var19.getTickLabelFont((java.lang.Comparable)var41);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelFont((-1), var47, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "0"+ "'", var43.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    var1.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = var1.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var6 = var5.getRotationAnchor();
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var11 = var7.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var14 = new org.jfree.chart.labels.ItemLabelPosition(var0, var6, var12, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    var2.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var11 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var7, 0.0d, var9, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var33.markerChanged(var36);
//     org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     int var41 = var40.getCategoryLabelPositionOffset();
//     int var42 = var33.getDomainAxisIndex(var40);
//     float var43 = var40.getMaximumCategoryLabelWidthRatio();
//     var40.setLabelAngle(100.0d);
//     java.awt.Graphics2D var46 = null;
//     java.awt.geom.Rectangle2D var48 = null;
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     org.jfree.chart.ChartRenderingInfo var51 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var52 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
//     org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var54 = var53.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var58 = var57.isNegativeArrowVisible();
//     var57.setAutoRangeStickyZero(false);
//     java.awt.Stroke var61 = var57.getTickMarkStroke();
//     var53.setSeriesOutlineStroke(1, var61, false);
//     boolean var65 = var53.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var67.zoomRange((-1.0d), 0.0d);
//     boolean var71 = var67.isPositiveArrowVisible();
//     java.awt.Paint var72 = var67.getAxisLinePaint();
//     var53.setBasePaint(var72);
//     boolean var74 = var52.equals((java.lang.Object)var72);
//     org.jfree.chart.renderer.RendererState var75 = new org.jfree.chart.renderer.RendererState(var52);
//     org.jfree.chart.axis.AxisState var76 = var40.draw(var46, 6.0d, var48, var49, var50, var52);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    var0.setAutoPopulateSeriesFillPaint(true);
    org.jfree.chart.labels.ItemLabelPosition var3 = null;
    var0.setPositiveItemLabelPositionFallback(var3);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBaseNegativeItemLabelPosition();
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var14 = var13.isNegativeArrowVisible();
    var13.setAutoRangeStickyZero(false);
    java.awt.Stroke var17 = var13.getTickMarkStroke();
    var9.setSeriesOutlineStroke(1, var17, false);
    boolean var21 = var9.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    var23.zoomRange((-1.0d), 0.0d);
    boolean var27 = var23.isPositiveArrowVisible();
    java.awt.Paint var28 = var23.getAxisLinePaint();
    var9.setBasePaint(var28);
    boolean var30 = var8.equals((java.lang.Object)var28);
    org.jfree.chart.renderer.RendererState var31 = new org.jfree.chart.renderer.RendererState(var8);
    java.awt.geom.Rectangle2D var32 = null;
    var8.setDataArea(var32);
    org.jfree.chart.renderer.category.CategoryItemRendererState var34 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var8);
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
    var40.zoomRange((-1.0d), 0.0d);
    boolean var44 = var40.isPositiveArrowVisible();
    boolean var45 = var40.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
    int var47 = var46.getColumnCount();
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var51 = var50.isNegativeArrowVisible();
    var50.setAutoRangeStickyZero(false);
    java.awt.Stroke var54 = var50.getTickMarkStroke();
    var46.setSeriesOutlineStroke(1, var54, false);
    boolean var58 = var46.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("hi!");
    var60.zoomRange((-1.0d), 0.0d);
    boolean var64 = var60.isPositiveArrowVisible();
    java.awt.Paint var65 = var60.getAxisLinePaint();
    var46.setBasePaint(var65);
    org.jfree.chart.labels.CategoryToolTipGenerator var67 = null;
    var46.setBaseToolTipGenerator(var67);
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var36, var38, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.renderer.category.CategoryItemRenderer)var46);
    var69.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var72 = null;
    var69.markerChanged(var72);
    org.jfree.chart.util.SortOrder var74 = var69.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var77 = var76.getCategoryLabelPositionOffset();
    int var78 = var69.getDomainAxisIndex(var76);
    org.jfree.chart.axis.CategoryAxis var80 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var80.setMaximumCategoryLabelLines(0);
    var80.setMaximumCategoryLabelLines((-1));
    var80.setMaximumCategoryLabelLines((-1));
    double var87 = var80.getCategoryMargin();
    org.jfree.chart.axis.CategoryLabelPositions var88 = var80.getCategoryLabelPositions();
    double var89 = var80.getCategoryMargin();
    org.jfree.chart.axis.NumberAxis var91 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var92 = var91.isNegativeArrowVisible();
    var91.setAutoRangeStickyZero(false);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var95 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var6, var34, var35, var69, var80, (org.jfree.chart.axis.ValueAxis)var91, (org.jfree.data.category.CategoryDataset)var95, 4, 0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == false);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    java.awt.Font var12 = var0.getSeriesItemLabelFont(100);
    var0.setBaseSeriesVisible(false, false);
    java.awt.Stroke var17 = var0.getSeriesStroke(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    org.jfree.chart.JFreeChart var4 = null;
    org.jfree.chart.event.ChartProgressEvent var7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var4, 10, 100);
    java.awt.Font var8 = var1.getLabelFont();
    int var9 = var1.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.setMaximumCategoryLabelLines(0);
//     var1.setMaximumCategoryLabelLines((-1));
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var11.zoomRange((-1.0d), 0.0d);
//     boolean var15 = var11.isPositiveArrowVisible();
//     boolean var16 = var11.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var18 = var17.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var22 = var21.isNegativeArrowVisible();
//     var21.setAutoRangeStickyZero(false);
//     java.awt.Stroke var25 = var21.getTickMarkStroke();
//     var17.setSeriesOutlineStroke(1, var25, false);
//     boolean var29 = var17.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var31.zoomRange((-1.0d), 0.0d);
//     boolean var35 = var31.isPositiveArrowVisible();
//     java.awt.Paint var36 = var31.getAxisLinePaint();
//     var17.setBasePaint(var36);
//     org.jfree.chart.labels.CategoryToolTipGenerator var38 = null;
//     var17.setBaseToolTipGenerator(var38);
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var7, var9, (org.jfree.chart.axis.ValueAxis)var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var46 = var45.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var50 = var49.isNegativeArrowVisible();
//     var49.setAutoRangeStickyZero(false);
//     java.awt.Stroke var53 = var49.getTickMarkStroke();
//     var45.setSeriesOutlineStroke(1, var53, false);
//     boolean var57 = var45.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var59.zoomRange((-1.0d), 0.0d);
//     boolean var63 = var59.isPositiveArrowVisible();
//     java.awt.Paint var64 = var59.getAxisLinePaint();
//     var45.setBasePaint(var64);
//     boolean var66 = var44.equals((java.lang.Object)var64);
//     var40.handleClick(0, 100, var44);
//     java.awt.Stroke var68 = var40.getOutlineStroke();
//     org.jfree.chart.axis.CategoryAxis var69 = var40.getDomainAxis();
//     java.awt.geom.Rectangle2D var70 = null;
//     org.jfree.chart.util.RectangleEdge var71 = null;
//     org.jfree.chart.axis.AxisSpace var72 = new org.jfree.chart.axis.AxisSpace();
//     var72.setRight(1.0d);
//     var72.setRight(1.0d);
//     java.lang.String var77 = var72.toString();
//     org.jfree.chart.axis.AxisSpace var78 = var1.reserveSpace(var6, (org.jfree.chart.plot.Plot)var40, var70, var71, var72);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    var33.setForegroundAlpha(1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setBackgroundImageAlpha((-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var0.setBasePaint(var19);
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var0.setBaseURLGenerator(var21, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.LengthAdjustmentType var6 = null;
    org.jfree.chart.util.LengthAdjustmentType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var4.createAdjustedRectangle(var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    var41.setBaseSeriesVisible(false);
    var41.setBaseSeriesVisible(true);
    var33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var41, true);
    org.jfree.chart.annotations.CategoryAnnotation var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var41.addAnnotation(var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var1 = var0.getErrorIndicatorPaint();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.ChartRenderingInfo var3 = null;
    org.jfree.chart.plot.PlotRenderingInfo var4 = new org.jfree.chart.plot.PlotRenderingInfo(var3);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    boolean var17 = var5.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    var19.zoomRange((-1.0d), 0.0d);
    boolean var23 = var19.isPositiveArrowVisible();
    java.awt.Paint var24 = var19.getAxisLinePaint();
    var5.setBasePaint(var24);
    boolean var26 = var4.equals((java.lang.Object)var24);
    org.jfree.chart.renderer.RendererState var27 = new org.jfree.chart.renderer.RendererState(var4);
    java.awt.geom.Rectangle2D var28 = null;
    var4.setDataArea(var28);
    org.jfree.chart.renderer.category.CategoryItemRendererState var30 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var4);
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = null;
    org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var34.setMaximumCategoryLabelLines(0);
    org.jfree.chart.JFreeChart var37 = null;
    org.jfree.chart.event.ChartProgressEvent var40 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var34, var37, 10, 100);
    java.awt.Font var41 = var34.getLabelFont();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    var43.zoomRange((-1.0d), 0.0d);
    boolean var47 = var43.isPositiveArrowVisible();
    java.lang.Object var48 = var43.clone();
    org.jfree.data.category.CategoryDataset var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var2, var30, var31, var32, var34, (org.jfree.chart.axis.ValueAxis)var43, var49, 4, 4, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    java.awt.Paint var47 = var33.getOutlinePaint();
    org.jfree.data.category.CategoryDataset var48 = null;
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    boolean var57 = var52.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
    int var59 = var58.getColumnCount();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var63 = var62.isNegativeArrowVisible();
    var62.setAutoRangeStickyZero(false);
    java.awt.Stroke var66 = var62.getTickMarkStroke();
    var58.setSeriesOutlineStroke(1, var66, false);
    boolean var70 = var58.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("hi!");
    var72.zoomRange((-1.0d), 0.0d);
    boolean var76 = var72.isPositiveArrowVisible();
    java.awt.Paint var77 = var72.getAxisLinePaint();
    var58.setBasePaint(var77);
    org.jfree.chart.labels.CategoryToolTipGenerator var79 = null;
    var58.setBaseToolTipGenerator(var79);
    org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot(var48, var50, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var58);
    var81.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var84 = null;
    var81.markerChanged(var84);
    org.jfree.chart.util.SortOrder var86 = var81.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var88 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var89 = var88.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAxis[] var90 = new org.jfree.chart.axis.CategoryAxis[] { var88};
    var81.setDomainAxes(var90);
    org.jfree.chart.renderer.category.CategoryItemRenderer var92 = var81.getRenderer();
    java.awt.Stroke var93 = var81.getOutlineStroke();
    var33.setDomainGridlineStroke(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.data.category.CategoryDataset var36 = var33.getDataset();
//     int var37 = var33.getRangeAxisCount();
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var38 = null;
//     var33.setRenderers(var38);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.isInverted();
    var1.configure();
    var1.setAutoRangeIncludesZero(true);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var1.valueToJava2D(100.0d, var11, var12);
    var1.setAutoTickUnitSelection(true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAboutValue(11.05d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var0.add((org.jfree.chart.block.Block)var1, (java.lang.Object)var2);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var1.draw(var4, var5);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    var22.zoomRange((-1.0d), 0.0d);
    boolean var26 = var22.isPositiveArrowVisible();
    boolean var27 = var22.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var28.setBaseToolTipGenerator(var49);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var18, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    var0.setPlot(var51);
    var51.setRangeCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("0", "1", var3);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    var33.setForegroundAlpha(1.0f);
    org.jfree.chart.plot.PlotOrientation var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setOrientation(var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var34.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var37 = null;
    var34.markerChanged(var37);
    org.jfree.data.general.DatasetGroup var39 = var34.getDatasetGroup();
    org.jfree.chart.axis.AxisSpace var40 = var34.getFixedRangeAxisSpace();
    java.awt.Font var41 = var34.getNoDataMessageFont();
    org.jfree.data.general.DatasetGroup var43 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    int var45 = var44.getColumnCount();
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var44.setSeriesShape(100, var49, false);
    org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
    int var54 = var53.getColumnCount();
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var53.setSeriesShape(100, var58, false);
    var44.setSeriesShape(1, var58);
    boolean var62 = var43.equals((java.lang.Object)var44);
    org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var64 = var63.getBackgroundPaint();
    java.awt.Paint var65 = var63.getPaint();
    org.jfree.chart.block.BlockBorder var66 = new org.jfree.chart.block.BlockBorder(var65);
    var44.setBaseItemLabelPaint(var65, false);
    org.jfree.chart.util.RectangleEdge var69 = null;
    org.jfree.chart.util.HorizontalAlignment var70 = null;
    org.jfree.chart.util.VerticalAlignment var71 = null;
    org.jfree.chart.util.RectangleInsets var72 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("1", var41, var65, var69, var70, var71, var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    java.awt.Paint var19 = var0.getSeriesFillPaint(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
//     var33.setForegroundAlpha(1.0f);
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     var33.drawBackground(var37, var38);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("CategoryLabelEntity: category=false, tooltip=, url=0", var1, 0.0f, 0.0f, 0.2d, 0.0f, 1.0f);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    var33.setDomainGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    var0.clear();
    java.lang.Object var3 = var0.get(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    int var20 = var0.getRowCount();
    java.awt.Stroke var22 = var0.getSeriesStroke(1);
    boolean var24 = var0.isSeriesVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    java.awt.Color var1 = java.awt.Color.getColor("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var2.setSeriesShape(100, var7, false);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var11.setSeriesShape(100, var16, false);
    var2.setSeriesShape(1, var16);
    boolean var20 = var1.equals((java.lang.Object)var2);
    java.lang.String var21 = var1.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "hi!"+ "'", var21.equals("hi!"));

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var5.zoomRange((-1.0d), 0.0d);
//     boolean var9 = var5.isPositiveArrowVisible();
//     boolean var10 = var5.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var12 = var11.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var16 = var15.isNegativeArrowVisible();
//     var15.setAutoRangeStickyZero(false);
//     java.awt.Stroke var19 = var15.getTickMarkStroke();
//     var11.setSeriesOutlineStroke(1, var19, false);
//     boolean var23 = var11.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var25.zoomRange((-1.0d), 0.0d);
//     boolean var29 = var25.isPositiveArrowVisible();
//     java.awt.Paint var30 = var25.getAxisLinePaint();
//     var11.setBasePaint(var30);
//     org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
//     var11.setBaseToolTipGenerator(var32);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
//     var34.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var37 = null;
//     var34.markerChanged(var37);
//     org.jfree.data.general.DatasetGroup var39 = var34.getDatasetGroup();
//     org.jfree.chart.axis.AxisSpace var40 = var34.getFixedRangeAxisSpace();
//     java.awt.Font var41 = var34.getNoDataMessageFont();
//     org.jfree.chart.ChartColor var45 = new org.jfree.chart.ChartColor(4, 1, 100);
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.text.G2TextMeasurer var49 = new org.jfree.chart.text.G2TextMeasurer(var48);
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("poly", var41, (java.awt.Paint)var45, 1.0f, 1, (org.jfree.chart.text.TextMeasurer)var49);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var2 = null;
    var1.addChangeListener(var2);
    java.awt.Shape var4 = var1.getRightArrow();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    int var7 = var6.getColumnCount();
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var6.setSeriesShape(100, var11, false);
    org.jfree.chart.entity.CategoryLabelEntity var16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var11, "", "0");
    boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4);
    org.jfree.chart.event.ChartChangeEventType var19 = var18.getType();
    java.lang.String var20 = var18.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
//     org.jfree.chart.text.TextFragment var1 = null;
//     var0.addFragment(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     var0.draw(var3, 10.0f, 0.0f, var6, 0.0f, 10.0f, 10.0d);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    org.jfree.chart.ChartColor var43 = new org.jfree.chart.ChartColor(4, 1, 100);
    var33.setNoDataMessagePaint((java.awt.Paint)var43);
    java.awt.Paint var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setRangeGridlinePaint(var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var2 = null;
    var1.addChangeListener(var2);
    java.awt.Shape var4 = var1.getRightArrow();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var7 = null;
    var6.addChangeListener(var7);
    java.awt.Shape var9 = var6.getRightArrow();
    var1.setRightArrow(var9);
    org.jfree.chart.entity.ChartEntity var11 = new org.jfree.chart.entity.ChartEntity(var9);
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var12 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var13 = null;
    java.lang.String var14 = var11.getImageMapAreaTag(var12, var13);
    java.lang.String var15 = var11.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + ""+ "'", var14.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var2.setLowerMargin(100.0d);
    var2.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    org.jfree.chart.ChartColor var43 = new org.jfree.chart.ChartColor(4, 1, 100);
    var33.setNoDataMessagePaint((java.awt.Paint)var43);
    float[] var46 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var47 = var43.getRGBColorComponents(var46);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    var2.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var11 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var7, 100.0d, var9, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    org.jfree.chart.block.BlockBorder var3 = new org.jfree.chart.block.BlockBorder(var2);
    org.jfree.chart.util.RectangleInsets var4 = var3.getInsets();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    org.jfree.chart.entity.CategoryLabelEntity var19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var14, "", "0");
    java.awt.Shape var20 = var19.getArea();
    boolean var21 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var7, (java.lang.Object)var20);
    boolean var22 = var4.equals((java.lang.Object)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    java.awt.Font var8 = null;
    var0.setBaseItemLabelFont(var8, true);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(100, var14, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = var0.getBaseToolTipGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var20 = var0.getURLGenerator(0, 4);
    org.jfree.chart.event.RendererChangeListener var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addChangeListener(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseSeriesVisible(true, true);
//     java.awt.Paint var9 = var0.getItemOutlinePaint((-1), 0);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var12 = var11.getColumnCount();
//     var11.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var11.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var16 = var15.getRotationAnchor();
//     var0.setSeriesNegativeItemLabelPosition(4, var15);
//     org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var19.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.JFreeChart var22 = null;
//     org.jfree.chart.event.ChartProgressEvent var25 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var19, var22, 10, 100);
//     java.awt.Font var26 = var19.getLabelFont();
//     var0.setBaseItemLabelFont(var26);
//     boolean var28 = var0.getBaseCreateEntities();
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var30 = var29.getColumnCount();
//     var29.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var33 = var29.getBasePositiveItemLabelPosition();
//     var0.setBasePositiveItemLabelPosition(var33);
//     
//     // Checks the contract:  equals-hashcode on var15 and var33
//     assertTrue("Contract failed: equals-hashcode on var15 and var33", var15.equals(var33) ? var15.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var15
//     assertTrue("Contract failed: equals-hashcode on var33 and var15", var33.equals(var15) ? var33.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    var1.setRightArrow(var9);
    org.jfree.chart.entity.ChartEntity var16 = new org.jfree.chart.entity.ChartEntity(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var9 = var8.getColumnCount();
//     var8.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var8.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var13 = var12.getRotationAnchor();
//     java.awt.Shape var14 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 1.0f, 1.0f, var6, 1.0d, var13);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.block.FlowArrangement var3 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var4 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var3);
    org.jfree.chart.util.Size2D var7 = new org.jfree.chart.util.Size2D(0.0d, 0.2d);
    boolean var8 = var4.equals((java.lang.Object)0.2d);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    var13.zoomRange((-1.0d), 0.0d);
    boolean var17 = var13.isPositiveArrowVisible();
    boolean var18 = var13.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    int var20 = var19.getColumnCount();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    var23.setAutoRangeStickyZero(false);
    java.awt.Stroke var27 = var23.getTickMarkStroke();
    var19.setSeriesOutlineStroke(1, var27, false);
    boolean var31 = var19.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi!");
    var33.zoomRange((-1.0d), 0.0d);
    boolean var37 = var33.isPositiveArrowVisible();
    java.awt.Paint var38 = var33.getAxisLinePaint();
    var19.setBasePaint(var38);
    org.jfree.chart.labels.CategoryToolTipGenerator var40 = null;
    var19.setBaseToolTipGenerator(var40);
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var9, var11, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.plot.CategoryPlot var43 = var19.getPlot();
    boolean var44 = var19.isDrawBarOutline();
    var19.setBase(Double.POSITIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var4, (java.lang.Object)Double.POSITIVE_INFINITY);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getNegativeItemLabelPositionFallback();
    var0.setBaseCreateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var8 = var7.getColumnCount();
//     var7.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var7.setSeriesNegativeItemLabelPosition(100, var12, true);
//     var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var22 = var21.getColumnCount();
//     var21.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var27 = var26.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var31 = var30.isNegativeArrowVisible();
//     var30.setAutoRangeStickyZero(false);
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var26.setSeriesOutlineStroke(1, var34, false);
//     var21.setSeriesOutlineStroke(0, var34, false);
//     var20.setAxisLineStroke(var34);
//     var7.setBaseStroke(var34, true);
//     var0.setSeriesOutlineStroke(0, var34, true);
//     org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
//     java.awt.Font var50 = var49.getItemFont();
//     org.jfree.chart.block.BlockContainer var51 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement();
//     var51.setArrangement((org.jfree.chart.block.Arrangement)var52);
//     var49.setWrapper(var51);
//     
//     // Checks the contract:  equals-hashcode on var46 and var52
//     assertTrue("Contract failed: equals-hashcode on var46 and var52", var46.equals(var52) ? var46.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var46
//     assertTrue("Contract failed: equals-hashcode on var52 and var46", var52.equals(var46) ? var52.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    java.awt.Shape var15 = var14.getArea();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var54 = var53.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var53.getRenderer(1);
    boolean var57 = var19.hasListener((java.util.EventListener)var53);
    java.lang.Comparable var59 = null;
    org.jfree.chart.entity.CategoryItemEntity var60 = new org.jfree.chart.entity.CategoryItemEntity(var15, "poly", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)(-1.0f), var59);
    int var62 = var19.getRowIndex((java.lang.Comparable)"-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var65 = var19.getMeanValue(5, 5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == (-1));

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("CategoryLabelEntity: category=false, tooltip=, url=0", var1, var2);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    java.lang.Object var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var12, (-1), 10);
    org.jfree.chart.JFreeChart var16 = var15.getChart();
    int var17 = var15.getPercent();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Font var3 = var0.getSeriesItemLabelFont(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ChartChangeEventType.GENERAL", var1);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    var0.setBaseCreateEntities(true);
    java.lang.Boolean var23 = var0.getSeriesVisibleInLegend((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("6");

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var2 = var0.calculateLeftInset(0.0d);
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var0.createInsetRectangle(var3, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var41 = var40.getCategoryLabelPositionOffset();
    int var42 = var33.getDomainAxisIndex(var40);
    double var43 = var40.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.05d);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("AxisLocation.BOTTOM_OR_LEFT", var1, var2);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(2.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var6 = var5.isNegativeArrowVisible();
    var5.setAutoRangeStickyZero(false);
    java.awt.Stroke var9 = var5.getTickMarkStroke();
    var1.setSeriesOutlineStroke(1, var9, false);
    java.awt.Font var13 = var1.getSeriesItemLabelFont(100);
    var1.setBaseSeriesVisible(false, false);
    java.awt.Stroke var17 = var1.getBaseOutlineStroke();
    java.lang.Boolean var19 = null;
    var1.setSeriesCreateEntities(0, var19);
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var23 = var22.getBackgroundPaint();
    java.awt.Paint var24 = var22.getPaint();
    java.awt.Font var25 = var22.getFont();
    var1.setSeriesItemLabelFont(100, var25);
    org.jfree.data.category.CategoryDataset var27 = null;
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("hi!");
    var31.zoomRange((-1.0d), 0.0d);
    boolean var35 = var31.isPositiveArrowVisible();
    boolean var36 = var31.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
    int var38 = var37.getColumnCount();
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var42 = var41.isNegativeArrowVisible();
    var41.setAutoRangeStickyZero(false);
    java.awt.Stroke var45 = var41.getTickMarkStroke();
    var37.setSeriesOutlineStroke(1, var45, false);
    boolean var49 = var37.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("hi!");
    var51.zoomRange((-1.0d), 0.0d);
    boolean var55 = var51.isPositiveArrowVisible();
    java.awt.Paint var56 = var51.getAxisLinePaint();
    var37.setBasePaint(var56);
    org.jfree.chart.labels.CategoryToolTipGenerator var58 = null;
    var37.setBaseToolTipGenerator(var58);
    org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var27, var29, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
    var60.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var63 = null;
    var60.markerChanged(var63);
    org.jfree.chart.util.SortOrder var65 = var60.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var66 = new org.jfree.data.KeyedObjects();
    java.lang.Object var68 = var66.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var69 = null;
    org.jfree.chart.event.ChartProgressEvent var72 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var66, var69, 0, 0);
    boolean var73 = var60.equals((java.lang.Object)var69);
    java.awt.Paint var74 = var60.getOutlinePaint();
    org.jfree.chart.block.LabelBlock var75 = new org.jfree.chart.block.LabelBlock("", var25, var74);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var76 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetChangeEvent var77 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var74, (org.jfree.data.general.Dataset)var76);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var80 = var76.getMeanValue(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var4 = var3.getLabelOffset();
    java.awt.Paint var5 = var3.getPaint();
    java.awt.Paint var6 = var3.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("AxisLocation.BOTTOM_OR_LEFT", var1, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var6 = var5.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var10 = var9.isNegativeArrowVisible();
//     var9.setAutoRangeStickyZero(false);
//     java.awt.Stroke var13 = var9.getTickMarkStroke();
//     var5.setSeriesOutlineStroke(1, var13, false);
//     var0.setSeriesOutlineStroke(0, var13, false);
//     var0.setBaseSeriesVisible(false);
//     int var20 = var0.getRowCount();
//     var0.setAutoPopulateSeriesShape(true);
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var25 = var24.getColumnCount();
//     var24.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var24.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var29 = var28.getRotationAnchor();
//     var0.setSeriesPositiveItemLabelPosition(100, var28, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var0.", var24.equals(var0) == var0.equals(var24));
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
    java.awt.Font var2 = var1.getFont();
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(var3, var4);
    org.jfree.chart.block.RectangleConstraint var6 = var5.toUnconstrainedWidth();
    org.jfree.chart.block.RectangleConstraint var7 = var5.toUnconstrainedWidth();
    boolean var8 = var1.equals((java.lang.Object)var7);
    java.lang.String var9 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"+ "'", var9.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]"));

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.ChartRenderingInfo var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    int var39 = var38.getColumnCount();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var43 = var42.isNegativeArrowVisible();
    var42.setAutoRangeStickyZero(false);
    java.awt.Stroke var46 = var42.getTickMarkStroke();
    var38.setSeriesOutlineStroke(1, var46, false);
    boolean var50 = var38.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var38.setBasePaint(var57);
    boolean var59 = var37.equals((java.lang.Object)var57);
    var33.handleClick(0, 100, var37);
    int var61 = var37.getSubplotCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setHeight(100.0d);
    boolean var3 = var0.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var5 = var4.getErrorIndicatorPaint();
    var0.setPaint(var5);
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(4, 1, 100);
    var0.setBackgroundPaint((java.awt.Paint)var10);
    int var12 = var10.getTransparency();
    float[] var15 = new float[] { 100.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var16 = var10.getColorComponents(var15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    var0.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    int var15 = var14.getColumnCount();
    var14.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    int var20 = var19.getColumnCount();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    var23.setAutoRangeStickyZero(false);
    java.awt.Stroke var27 = var23.getTickMarkStroke();
    var19.setSeriesOutlineStroke(1, var27, false);
    var14.setSeriesOutlineStroke(0, var27, false);
    var13.setAxisLineStroke(var27);
    var0.setBaseStroke(var27, true);
    boolean var35 = var0.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.data.general.DatasetGroup var15 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    int var17 = var16.getColumnCount();
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var16.setSeriesShape(100, var21, false);
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    int var26 = var25.getColumnCount();
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var25.setSeriesShape(100, var30, false);
    var16.setSeriesShape(1, var30);
    boolean var34 = var15.equals((java.lang.Object)var16);
    org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var36 = var35.getBackgroundPaint();
    java.awt.Paint var37 = var35.getPaint();
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var37);
    var16.setBaseItemLabelPaint(var37, false);
    var0.setSeriesItemLabelPaint(1, var37, true);
    var0.setBaseCreateEntities(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var5 = var4.getMarkerBand();
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var4.refreshTicks(var7, var8, var9, var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    boolean var21 = var16.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var27 = var26.isNegativeArrowVisible();
    var26.setAutoRangeStickyZero(false);
    java.awt.Stroke var30 = var26.getTickMarkStroke();
    var22.setSeriesOutlineStroke(1, var30, false);
    boolean var34 = var22.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    var36.zoomRange((-1.0d), 0.0d);
    boolean var40 = var36.isPositiveArrowVisible();
    java.awt.Paint var41 = var36.getAxisLinePaint();
    var22.setBasePaint(var41);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var22.setBaseToolTipGenerator(var43);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var12, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    org.jfree.chart.ChartRenderingInfo var48 = null;
    org.jfree.chart.plot.PlotRenderingInfo var49 = new org.jfree.chart.plot.PlotRenderingInfo(var48);
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    boolean var62 = var50.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    java.awt.Paint var69 = var64.getAxisLinePaint();
    var50.setBasePaint(var69);
    boolean var71 = var49.equals((java.lang.Object)var69);
    var45.handleClick(0, 100, var49);
    java.awt.Stroke var73 = var45.getOutlineStroke();
    var4.setAxisLineStroke(var73);
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var77 = null;
    var76.addChangeListener(var77);
    java.awt.Shape var79 = var76.getRightArrow();
    var4.setRightArrow(var79);
    org.jfree.chart.axis.NumberAxis var82 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var83 = var82.isNegativeArrowVisible();
    org.jfree.chart.renderer.category.BarRenderer var85 = new org.jfree.chart.renderer.category.BarRenderer();
    int var86 = var85.getColumnCount();
    java.awt.Shape var90 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var85.setSeriesShape(100, var90, false);
    org.jfree.chart.entity.CategoryLabelEntity var95 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var90, "", "0");
    var82.setRightArrow(var90);
    var4.setUpArrow(var90);
    org.jfree.chart.axis.MarkerAxisBand var98 = var4.getMarkerBand();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var98);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", var1);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "CategoryLabelEntity: category=false, tooltip=, url=0", "", "ChartChangeEventType.GENERAL");
    java.lang.String var5 = var4.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "CategoryLabelEntity: category=false, tooltip=, url=0"+ "'", var5.equals("CategoryLabelEntity: category=false, tooltip=, url=0"));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var12, (-1), 10);
    var1.setPositiveArrowVisible(true);
    double var18 = var1.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var12, (-1), 10);
    var1.setPositiveArrowVisible(true);
    var1.resizeRange(6.0d, 0.0d);
    org.jfree.data.Range var21 = var1.getRange();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    int var30 = var29.getColumnCount();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var29.setSeriesShape(100, var34, false);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var34, "", "0");
    java.awt.Shape var40 = var39.getArea();
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)var40);
    var23.setDownArrow(var40);
    var1.setDownArrow(var40);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    boolean var53 = var48.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
    int var55 = var54.getColumnCount();
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var59 = var58.isNegativeArrowVisible();
    var58.setAutoRangeStickyZero(false);
    java.awt.Stroke var62 = var58.getTickMarkStroke();
    var54.setSeriesOutlineStroke(1, var62, false);
    boolean var66 = var54.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    var54.setBasePaint(var73);
    org.jfree.chart.labels.CategoryToolTipGenerator var75 = null;
    var54.setBaseToolTipGenerator(var75);
    org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot(var44, var46, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var54);
    var77.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var80 = null;
    var77.markerChanged(var80);
    org.jfree.chart.util.SortOrder var82 = var77.getRowRenderingOrder();
    var77.setRangeGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var86 = var85.getBackgroundPaint();
    java.awt.Paint var87 = var85.getPaint();
    var77.setDomainGridlinePaint(var87);
    org.jfree.chart.title.LegendGraphic var89 = new org.jfree.chart.title.LegendGraphic(var40, var87);
    boolean var90 = var89.isShapeOutlineVisible();
    org.jfree.chart.util.RectangleAnchor var91 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var89.setShapeAnchor(var91);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);

  }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
//     java.awt.color.ColorSpace var4 = null;
//     float[] var7 = new float[] { 0.0f, 100.0f};
//     float[] var8 = var3.getComponents(var4, var7);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var33.markerChanged(var36);
//     boolean var38 = var33.isOutlineVisible();
//     org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeEvent var41 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var40);
//     boolean var42 = var39.equals((java.lang.Object)var40);
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var47.zoomRange((-1.0d), 0.0d);
//     boolean var51 = var47.isPositiveArrowVisible();
//     boolean var52 = var47.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var54 = var53.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var58 = var57.isNegativeArrowVisible();
//     var57.setAutoRangeStickyZero(false);
//     java.awt.Stroke var61 = var57.getTickMarkStroke();
//     var53.setSeriesOutlineStroke(1, var61, false);
//     boolean var65 = var53.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var67.zoomRange((-1.0d), 0.0d);
//     boolean var71 = var67.isPositiveArrowVisible();
//     java.awt.Paint var72 = var67.getAxisLinePaint();
//     var53.setBasePaint(var72);
//     org.jfree.chart.labels.CategoryToolTipGenerator var74 = null;
//     var53.setBaseToolTipGenerator(var74);
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot(var43, var45, (org.jfree.chart.axis.ValueAxis)var47, (org.jfree.chart.renderer.category.CategoryItemRenderer)var53);
//     var76.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var79 = null;
//     var76.markerChanged(var79);
//     boolean var81 = var76.isOutlineVisible();
//     org.jfree.chart.LegendItemCollection var82 = var76.getLegendItems();
//     var39.addAll(var82);
//     
//     // Checks the contract:  equals-hashcode on var33 and var76
//     assertTrue("Contract failed: equals-hashcode on var33 and var76", var33.equals(var76) ? var33.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var33
//     assertTrue("Contract failed: equals-hashcode on var76 and var33", var76.equals(var33) ? var76.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var82
//     assertTrue("Contract failed: equals-hashcode on var39 and var82", var39.equals(var82) ? var39.hashCode() == var82.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var82 and var39
//     assertTrue("Contract failed: equals-hashcode on var82 and var39", var82.equals(var39) ? var82.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "1", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "", "AxisLocation.BOTTOM_OR_LEFT");
    java.lang.Object var6 = null;
    boolean var7 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.labels.ItemLabelPosition var3 = null;
//     var0.setPositiveItemLabelPositionFallback(var3);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var7 = var6.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var11 = var10.isNegativeArrowVisible();
//     var10.setAutoRangeStickyZero(false);
//     java.awt.Stroke var14 = var10.getTickMarkStroke();
//     var6.setSeriesOutlineStroke(1, var14, false);
//     var0.setBaseOutlineStroke(var14, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var6.", var0.equals(var6) == var6.equals(var0));
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getValue(10, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    boolean var3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getMeanValue(5, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.annotations.CategoryAnnotation var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var2 = null;
    var1.addChangeListener(var2);
    java.awt.Shape var4 = var1.getRightArrow();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var7 = null;
    var6.addChangeListener(var7);
    java.awt.Shape var9 = var6.getRightArrow();
    var1.setRightArrow(var9);
    org.jfree.chart.entity.TickLabelEntity var13 = new org.jfree.chart.entity.TickLabelEntity(var9, "", "hi!");
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 0.0d);
    org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var16, "CategoryLabelEntity: category=false, tooltip=, url=0", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.clone(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     double var2 = var0.calculateLeftInset(0.0d);
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.trim(var3);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
//     org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var4 = var3.getColumnCount();
//     var3.setBaseSeriesVisible(false);
//     var3.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     var10.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var15 = null;
//     var10.setSeriesNegativeItemLabelPosition(100, var15, true);
//     var10.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var25 = var24.getColumnCount();
//     var24.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var30 = var29.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var34 = var33.isNegativeArrowVisible();
//     var33.setAutoRangeStickyZero(false);
//     java.awt.Stroke var37 = var33.getTickMarkStroke();
//     var29.setSeriesOutlineStroke(1, var37, false);
//     var24.setSeriesOutlineStroke(0, var37, false);
//     var23.setAxisLineStroke(var37);
//     var10.setBaseStroke(var37, true);
//     var3.setSeriesOutlineStroke(0, var37, true);
//     org.jfree.chart.block.FlowArrangement var47 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var48 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var47);
//     org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var50 = null;
//     boolean var51 = var49.equals(var50);
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var3, (org.jfree.chart.block.Arrangement)var47, (org.jfree.chart.block.Arrangement)var49);
//     org.jfree.chart.util.RectangleAnchor var53 = null;
//     var52.setLegendItemGraphicLocation(var53);
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var57 = var56.getBackgroundPaint();
//     java.awt.Paint var58 = var56.getPaint();
//     java.awt.Font var59 = var56.getFont();
//     org.jfree.chart.block.LabelBlock var60 = new org.jfree.chart.block.LabelBlock("0", var59);
//     java.lang.String var61 = var60.getToolTipText();
//     boolean var62 = var52.equals((java.lang.Object)var60);
//     org.jfree.chart.axis.CategoryLabelPositions var64 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(100.0d);
//     var1.add((org.jfree.chart.block.Block)var52, (java.lang.Object)var64);
//     
//     // Checks the contract:  equals-hashcode on var1 and var49
//     assertTrue("Contract failed: equals-hashcode on var1 and var49", var1.equals(var49) ? var1.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var1
//     assertTrue("Contract failed: equals-hashcode on var49 and var1", var49.equals(var1) ? var49.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    java.awt.Paint var47 = var33.getOutlinePaint();
    org.jfree.chart.plot.CategoryMarker var48 = null;
    org.jfree.chart.util.Layer var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addDomainMarker(var48, var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    float[] var7 = new float[] { 100.0f, 10.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var8 = var3.getComponents(var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var4 = var3.brighter();
    float[] var5 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var4.getRGBComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var6 = var5.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var10 = var9.isNegativeArrowVisible();
//     var9.setAutoRangeStickyZero(false);
//     java.awt.Stroke var13 = var9.getTickMarkStroke();
//     var5.setSeriesOutlineStroke(1, var13, false);
//     var0.setSeriesOutlineStroke(0, var13, false);
//     var0.setBaseSeriesVisible(false);
//     int var20 = var0.getRowCount();
//     java.awt.Stroke var22 = var0.getSeriesStroke(1);
//     java.awt.Font var25 = var0.getItemLabelFont(5, 0);
//     org.jfree.chart.block.FlowArrangement var27 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var28 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var27.add((org.jfree.chart.block.Block)var28, (java.lang.Object)var29);
//     org.jfree.data.category.CategoryDataset var31 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var35.zoomRange((-1.0d), 0.0d);
//     boolean var39 = var35.isPositiveArrowVisible();
//     boolean var40 = var35.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var42 = var41.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var46 = var45.isNegativeArrowVisible();
//     var45.setAutoRangeStickyZero(false);
//     java.awt.Stroke var49 = var45.getTickMarkStroke();
//     var41.setSeriesOutlineStroke(1, var49, false);
//     boolean var53 = var41.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var55.zoomRange((-1.0d), 0.0d);
//     boolean var59 = var55.isPositiveArrowVisible();
//     java.awt.Paint var60 = var55.getAxisLinePaint();
//     var41.setBasePaint(var60);
//     org.jfree.chart.labels.CategoryToolTipGenerator var62 = null;
//     var41.setBaseToolTipGenerator(var62);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var31, var33, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
//     var64.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var67 = null;
//     var64.markerChanged(var67);
//     org.jfree.chart.util.SortOrder var69 = var64.getRowRenderingOrder();
//     org.jfree.data.KeyedObjects var70 = new org.jfree.data.KeyedObjects();
//     java.lang.Object var72 = var70.getObject((java.lang.Comparable)1);
//     org.jfree.chart.JFreeChart var73 = null;
//     org.jfree.chart.event.ChartProgressEvent var76 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var70, var73, 0, 0);
//     boolean var77 = var64.equals((java.lang.Object)var73);
//     java.awt.Paint var78 = var64.getOutlinePaint();
//     var29.setErrorIndicatorPaint(var78);
//     org.jfree.chart.renderer.category.BarRenderer var81 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var82 = var81.getColumnCount();
//     var81.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var85 = var81.getBasePositiveItemLabelPosition();
//     var29.setSeriesNegativeItemLabelPosition(4, var85, true);
//     var0.setSeriesNegativeItemLabelPosition(1, var85);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var81 and var0.", var81.equals(var0) == var0.equals(var81));
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.2d, 0.2d, 1.0E-8d, 0.0d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    int var3 = java.awt.Color.HSBtoRGB(2.0f, 10.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    org.jfree.chart.util.Size2D var4 = new org.jfree.chart.util.Size2D(0.0d, 0.2d);
    boolean var5 = var1.equals((java.lang.Object)0.2d);
    java.util.List var6 = var1.getBlocks();
    org.jfree.chart.block.Arrangement var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setArrangement(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.isInverted();
    var1.configure();
    var1.setAutoRangeIncludesZero(true);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var1.valueToJava2D(100.0d, var11, var12);
    java.awt.Stroke var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkStroke(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     var1.setHeight(100.0d);
//     java.awt.Font var4 = var1.getFont();
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var7 = var6.getBackgroundPaint();
//     java.awt.Paint var8 = var6.getPaint();
//     java.awt.Font var9 = var6.getFont();
//     org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("", var9);
//     var1.setFont(var9);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
//     var12.setHeight(100.0d);
//     boolean var15 = var12.getNotify();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Paint var17 = var16.getErrorIndicatorPaint();
//     var12.setPaint(var17);
//     org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(4, 1, 100);
//     var12.setBackgroundPaint((java.awt.Paint)var22);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.text.G2TextMeasurer var27 = new org.jfree.chart.text.G2TextMeasurer(var26);
//     org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]", var9, (java.awt.Paint)var22, 1.0f, (-1), (org.jfree.chart.text.TextMeasurer)var27);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    var22.zoomRange((-1.0d), 0.0d);
    boolean var26 = var22.isPositiveArrowVisible();
    boolean var27 = var22.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var28.setBaseToolTipGenerator(var49);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var18, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    var0.setPlot(var51);
    org.jfree.chart.labels.CategoryToolTipGenerator var53 = var0.getBaseToolTipGenerator();
    boolean var55 = var0.isSeriesItemLabelsVisible(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    var0.clear();
    java.lang.Object var3 = var0.get(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 10);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var4 = var3.brighter();
    java.awt.Color var5 = var4.darker();
    java.awt.color.ColorSpace var6 = var5.getColorSpace();
    float[] var8 = new float[] { 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var9 = var5.getRGBColorComponents(var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    var1.clear();
    var1.setID("");

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.Number var4 = var0.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    var10.zoomRange((-1.0d), 0.0d);
    boolean var14 = var10.isPositiveArrowVisible();
    boolean var15 = var10.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    int var17 = var16.getColumnCount();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var21 = var20.isNegativeArrowVisible();
    var20.setAutoRangeStickyZero(false);
    java.awt.Stroke var24 = var20.getTickMarkStroke();
    var16.setSeriesOutlineStroke(1, var24, false);
    boolean var28 = var16.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    var30.zoomRange((-1.0d), 0.0d);
    boolean var34 = var30.isPositiveArrowVisible();
    java.awt.Paint var35 = var30.getAxisLinePaint();
    var16.setBasePaint(var35);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var16.setBaseToolTipGenerator(var37);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    var39.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var42 = null;
    var39.markerChanged(var42);
    org.jfree.chart.util.SortOrder var44 = var39.getRowRenderingOrder();
    var39.configureDomainAxes();
    org.jfree.chart.util.SortOrder var46 = var39.getColumnRenderingOrder();
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var39);
    org.jfree.chart.annotations.CategoryAnnotation var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var49 = var39.removeAnnotation(var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    var1.setHeight(100.0d);
    java.awt.Font var4 = var1.getFont();
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    double var3 = var2.getLowerBound();
    double var4 = var2.getLowerBound();
    org.jfree.data.Range var7 = org.jfree.data.Range.expand(var2, 1.0d, 6.0d);
    double var9 = var7.constrain(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState((-1.0d));
    java.util.List var2 = var1.getTicks();
    var1.cursorUp(Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var41 = var40.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAxis[] var42 = new org.jfree.chart.axis.CategoryAxis[] { var40};
    var33.setDomainAxes(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = var33.getRenderer();
    java.awt.Stroke var45 = var33.getOutlineStroke();
    org.jfree.chart.axis.AxisLocation var47 = var33.getDomainAxisLocation((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    java.lang.String var3 = var2.getText();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var6 = null;
    var5.addChangeListener(var6);
    java.awt.Shape var8 = var5.getRightArrow();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var10.setSeriesShape(100, var15, false);
    org.jfree.chart.entity.CategoryLabelEntity var20 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var15, "", "0");
    boolean var21 = org.jfree.chart.util.ShapeUtilities.equal(var8, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var2, (java.lang.Object)var15);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(0.05d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
//     double var2 = var1.getContentXOffset();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var5.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.util.RectangleInsets var8 = var5.getLabelInsets();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var12 = var11.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var16 = var15.isNegativeArrowVisible();
//     var15.setAutoRangeStickyZero(false);
//     java.awt.Stroke var19 = var15.getTickMarkStroke();
//     var11.setSeriesOutlineStroke(1, var19, false);
//     boolean var23 = var11.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var25.zoomRange((-1.0d), 0.0d);
//     boolean var29 = var25.isPositiveArrowVisible();
//     java.awt.Paint var30 = var25.getAxisLinePaint();
//     var11.setBasePaint(var30);
//     boolean var32 = var10.equals((java.lang.Object)var30);
//     org.jfree.chart.renderer.RendererState var33 = new org.jfree.chart.renderer.RendererState(var10);
//     java.awt.geom.Rectangle2D var34 = var10.getDataArea();
//     java.awt.geom.Rectangle2D var35 = var8.createInsetRectangle(var34);
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var37 = var36.getColumnCount();
//     var36.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var42 = var41.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var46 = var45.isNegativeArrowVisible();
//     var45.setAutoRangeStickyZero(false);
//     java.awt.Stroke var49 = var45.getTickMarkStroke();
//     var41.setSeriesOutlineStroke(1, var49, false);
//     var36.setSeriesOutlineStroke(0, var49, false);
//     double var54 = var36.getBase();
//     java.awt.Paint var57 = var36.getItemOutlinePaint(0, (-1));
//     org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var59 = var58.getColumnCount();
//     var58.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var63 = null;
//     var58.setSeriesNegativeItemLabelPosition(100, var63, true);
//     var58.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var72 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var73 = var72.getColumnCount();
//     var72.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var77 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var78 = var77.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var81 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var82 = var81.isNegativeArrowVisible();
//     var81.setAutoRangeStickyZero(false);
//     java.awt.Stroke var85 = var81.getTickMarkStroke();
//     var77.setSeriesOutlineStroke(1, var85, false);
//     var72.setSeriesOutlineStroke(0, var85, false);
//     var71.setAxisLineStroke(var85);
//     var58.setBaseStroke(var85, true);
//     org.jfree.chart.title.TextTitle var93 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var94 = var93.getBackgroundPaint();
//     java.awt.Paint var95 = var93.getPaint();
//     org.jfree.chart.block.BlockBorder var96 = new org.jfree.chart.block.BlockBorder(var95);
//     org.jfree.chart.util.RectangleInsets var97 = var96.getInsets();
//     org.jfree.chart.block.LineBorder var98 = new org.jfree.chart.block.LineBorder(var57, var85, var97);
//     java.lang.Object var99 = var1.draw(var3, var35, (java.lang.Object)var85);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.plot.CategoryPlot var34 = var10.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var34.mapDatasetToRangeAxis((-16777216), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("1", var1);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = var2.getLegendItemToolTipGenerator();
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = var5.getLegendItemLabelGenerator();
    var2.setLegendItemLabelGenerator(var7);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var2.getItemLabelGenerator(1, 4);
    java.awt.Paint var13 = var2.getSeriesPaint(1);
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var17 = var14.getItemOutlinePaint(4, 10);
    var2.setBasePaint(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]", var1, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("0", var1);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var8 = var7.getLabelOffset();
    org.jfree.chart.util.RectangleInsets var9 = var7.getLabelOffset();
    java.awt.Paint var10 = var7.getLabelPaint();
    var0.setBaseFillPaint(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    var1.setMaximumCategoryLabelLines((-1));
    var1.setMaximumCategoryLabelLines((-1));
    double var8 = var1.getCategoryMargin();
    var1.setLowerMargin(0.0d);
    java.awt.Paint var12 = var1.getTickLabelPaint((java.lang.Comparable)10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=10.0,l=1.0,b=-1.0,r=10.0]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var4 = var2.valueToString(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var5 = var0.getLargerTickUnit((org.jfree.chart.axis.TickUnit)var2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "0"+ "'", var4.equals("0"));

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    var33.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    boolean var49 = var44.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    boolean var62 = var50.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    java.awt.Paint var69 = var64.getAxisLinePaint();
    var50.setBasePaint(var69);
    org.jfree.chart.labels.CategoryToolTipGenerator var71 = null;
    var50.setBaseToolTipGenerator(var71);
    org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var40, var42, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
    var73.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var76 = null;
    var73.markerChanged(var76);
    boolean var78 = var73.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var79 = null;
    var73.markerChanged(var79);
    org.jfree.chart.renderer.category.BarRenderer var81 = new org.jfree.chart.renderer.category.BarRenderer();
    int var82 = var81.getColumnCount();
    var81.setBaseSeriesVisible(false);
    var81.setBaseSeriesVisible(true);
    var73.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var81, true);
    boolean var90 = var81.isSeriesVisible(0);
    org.jfree.chart.plot.DrawingSupplier var91 = var81.getDrawingSupplier();
    var33.setDrawingSupplier(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    double var18 = var0.getBase();
    java.awt.Paint var21 = var0.getItemOutlinePaint(0, (-1));
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    var22.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var27 = null;
    var22.setSeriesNegativeItemLabelPosition(100, var27, true);
    var22.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    int var37 = var36.getColumnCount();
    var36.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var46 = var45.isNegativeArrowVisible();
    var45.setAutoRangeStickyZero(false);
    java.awt.Stroke var49 = var45.getTickMarkStroke();
    var41.setSeriesOutlineStroke(1, var49, false);
    var36.setSeriesOutlineStroke(0, var49, false);
    var35.setAxisLineStroke(var49);
    var22.setBaseStroke(var49, true);
    org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var58 = var57.getBackgroundPaint();
    java.awt.Paint var59 = var57.getPaint();
    org.jfree.chart.block.BlockBorder var60 = new org.jfree.chart.block.BlockBorder(var59);
    org.jfree.chart.util.RectangleInsets var61 = var60.getInsets();
    org.jfree.chart.block.LineBorder var62 = new org.jfree.chart.block.LineBorder(var21, var49, var61);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    boolean var69 = var64.isInverted();
    var64.configure();
    var64.setAutoRangeIncludesZero(true);
    java.awt.geom.Rectangle2D var74 = null;
    org.jfree.chart.util.RectangleEdge var75 = null;
    double var76 = var64.valueToJava2D(100.0d, var74, var75);
    boolean var77 = var62.equals((java.lang.Object)var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    java.awt.Font var12 = var0.getSeriesItemLabelFont(100);
    var0.setBaseSeriesVisible(false, false);
    java.awt.Stroke var17 = var0.lookupSeriesOutlineStroke(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-16777216), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var7 = var1.getTickLabelInsets();
    java.lang.Object var8 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    java.awt.Shape var15 = var14.getArea();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var54 = var53.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var53.getRenderer(1);
    boolean var57 = var19.hasListener((java.util.EventListener)var53);
    java.lang.Comparable var59 = null;
    org.jfree.chart.entity.CategoryItemEntity var60 = new org.jfree.chart.entity.CategoryItemEntity(var15, "poly", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)(-1.0f), var59);
    java.lang.Comparable var61 = null;
    var60.setRowKey(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    int var41 = var0.getColumnIndex((java.lang.Comparable)(byte)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 2.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16580609));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    float[] var6 = new float[] { 100.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    var1.setMaximumCategoryLabelLines((-1));
    var1.setMaximumCategoryLabelLines((-1));
    double var8 = var1.getCategoryMargin();
    var1.setLowerMargin(0.0d);
    var1.setCategoryLabelPositionOffset(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
    int var38 = var37.getColumnCount();
    var37.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    int var43 = var42.getColumnCount();
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var47 = var46.isNegativeArrowVisible();
    var46.setAutoRangeStickyZero(false);
    java.awt.Stroke var50 = var46.getTickMarkStroke();
    var42.setSeriesOutlineStroke(1, var50, false);
    var37.setSeriesOutlineStroke(0, var50, false);
    var37.setBaseSeriesVisible(false);
    var37.setBaseCreateEntities(true);
    int var59 = var37.getRowCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var61 = null;
    var37.setSeriesItemLabelGenerator(4, var61, true);
    var33.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
    org.jfree.chart.event.PlotChangeListener var65 = null;
    var33.removeChangeListener(var65);
    boolean var67 = var33.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateY(10.0d);
    var0.setTranslateY(0.0d);
    var0.setTranslateY(0.0d);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("CategoryLabelEntity: category=false, tooltip=, url=0", "AxisLocation.BOTTOM_OR_LEFT", var3);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var2 = null;
    var1.addChangeListener(var2);
    java.awt.Shape var4 = var1.getRightArrow();
    org.jfree.chart.event.AxisChangeListener var5 = null;
    var1.addChangeListener(var5);
    org.jfree.data.Range var9 = new org.jfree.data.Range(0.0d, 0.0d);
    var1.setDefaultAutoRange(var9);
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(var9, 1.0d);
    org.jfree.chart.block.LengthConstraintType var13 = var12.getWidthConstraintType();
    org.jfree.chart.block.LengthConstraintType var14 = var12.getWidthConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var39 = new org.jfree.data.KeyedObjects();
    java.lang.Object var41 = var39.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartProgressEvent var45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var39, var42, 0, 0);
    boolean var46 = var33.equals((java.lang.Object)var42);
    org.jfree.chart.util.SortOrder var47 = var33.getColumnRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var48 = null;
    java.util.List var49 = var33.getCategoriesForAxis(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("CategoryLabelEntity: category=false, tooltip=, url=0");
    double var2 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var8 = var7.getColumnCount();
//     var7.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var7.setSeriesNegativeItemLabelPosition(100, var12, true);
//     var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var22 = var21.getColumnCount();
//     var21.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var27 = var26.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var31 = var30.isNegativeArrowVisible();
//     var30.setAutoRangeStickyZero(false);
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var26.setSeriesOutlineStroke(1, var34, false);
//     var21.setSeriesOutlineStroke(0, var34, false);
//     var20.setAxisLineStroke(var34);
//     var7.setBaseStroke(var34, true);
//     var0.setSeriesOutlineStroke(0, var34, true);
//     org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
//     var50.setHeight(100.0d);
//     boolean var53 = var50.getNotify();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Paint var55 = var54.getErrorIndicatorPaint();
//     var50.setPaint(var55);
//     boolean var57 = var49.equals((java.lang.Object)var55);
//     org.jfree.chart.text.TextFragment var59 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
//     java.awt.Font var60 = var59.getFont();
//     var49.setItemFont(var60);
//     org.jfree.chart.block.BlockContainer var62 = var49.getItemContainer();
//     
//     // Checks the contract:  equals-hashcode on var45 and var62
//     assertTrue("Contract failed: equals-hashcode on var45 and var62", var45.equals(var62) ? var45.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var45
//     assertTrue("Contract failed: equals-hashcode on var62 and var45", var62.equals(var45) ? var62.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.plot.CategoryPlot var34 = var10.getPlot();
    boolean var35 = var34.isRangeGridlinesVisible();
    org.jfree.chart.ChartRenderingInfo var37 = null;
    org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    int var40 = var39.getColumnCount();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var44 = var43.isNegativeArrowVisible();
    var43.setAutoRangeStickyZero(false);
    java.awt.Stroke var47 = var43.getTickMarkStroke();
    var39.setSeriesOutlineStroke(1, var47, false);
    boolean var51 = var39.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("hi!");
    var53.zoomRange((-1.0d), 0.0d);
    boolean var57 = var53.isPositiveArrowVisible();
    java.awt.Paint var58 = var53.getAxisLinePaint();
    var39.setBasePaint(var58);
    boolean var60 = var38.equals((java.lang.Object)var58);
    java.awt.geom.Point2D var61 = null;
    var34.zoomRangeAxes(Double.POSITIVE_INFINITY, var38, var61);
    int var63 = var38.getSubplotCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var12, (-1), 10);
    var1.setPositiveArrowVisible(true);
    var1.resizeRange(6.0d, 0.0d);
    org.jfree.data.Range var21 = var1.getRange();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    int var30 = var29.getColumnCount();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var29.setSeriesShape(100, var34, false);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var34, "", "0");
    java.awt.Shape var40 = var39.getArea();
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)var40);
    var23.setDownArrow(var40);
    var1.setDownArrow(var40);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    boolean var53 = var48.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
    int var55 = var54.getColumnCount();
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var59 = var58.isNegativeArrowVisible();
    var58.setAutoRangeStickyZero(false);
    java.awt.Stroke var62 = var58.getTickMarkStroke();
    var54.setSeriesOutlineStroke(1, var62, false);
    boolean var66 = var54.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    var54.setBasePaint(var73);
    org.jfree.chart.labels.CategoryToolTipGenerator var75 = null;
    var54.setBaseToolTipGenerator(var75);
    org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot(var44, var46, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var54);
    var77.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var80 = null;
    var77.markerChanged(var80);
    org.jfree.chart.util.SortOrder var82 = var77.getRowRenderingOrder();
    var77.setRangeGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var86 = var85.getBackgroundPaint();
    java.awt.Paint var87 = var85.getPaint();
    var77.setDomainGridlinePaint(var87);
    org.jfree.chart.title.LegendGraphic var89 = new org.jfree.chart.title.LegendGraphic(var40, var87);
    boolean var90 = var89.isShapeOutlineVisible();
    java.awt.Shape var91 = var89.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.Number var4 = var0.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    java.util.List var5 = var0.getColumnKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     java.lang.String var36 = var33.getNoDataMessage();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var39.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.util.RectangleInsets var42 = var39.getLabelInsets();
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var46 = var45.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var50 = var49.isNegativeArrowVisible();
//     var49.setAutoRangeStickyZero(false);
//     java.awt.Stroke var53 = var49.getTickMarkStroke();
//     var45.setSeriesOutlineStroke(1, var53, false);
//     boolean var57 = var45.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var59.zoomRange((-1.0d), 0.0d);
//     boolean var63 = var59.isPositiveArrowVisible();
//     java.awt.Paint var64 = var59.getAxisLinePaint();
//     var45.setBasePaint(var64);
//     boolean var66 = var44.equals((java.lang.Object)var64);
//     org.jfree.chart.renderer.RendererState var67 = new org.jfree.chart.renderer.RendererState(var44);
//     java.awt.geom.Rectangle2D var68 = var44.getDataArea();
//     java.awt.geom.Rectangle2D var69 = var42.createInsetRectangle(var68);
//     var33.drawBackgroundImage(var37, var69);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var73 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.DatasetGroup var74 = var73.getGroup();
//     org.jfree.data.Range var75 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var73);
//     boolean var76 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var73);
//     var73.add(1.0E-8d, 1.0d, (java.lang.Comparable)(-1.0d), (java.lang.Comparable)0);
//     org.jfree.chart.entity.CategoryItemEntity var84 = new org.jfree.chart.entity.CategoryItemEntity((java.awt.Shape)var69, "RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]", "CategoryLabelEntity: category=false, tooltip=, url=0", (org.jfree.data.category.CategoryDataset)var73, (java.lang.Comparable)Double.NaN, (java.lang.Comparable)(short)1);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var85 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.DatasetGroup var86 = var85.getGroup();
//     org.jfree.data.Range var87 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var85);
//     double var89 = var85.getRangeUpperBound(false);
//     var84.setDataset((org.jfree.data.category.CategoryDataset)var85);
//     
//     // Checks the contract:  equals-hashcode on var74 and var86
//     assertTrue("Contract failed: equals-hashcode on var74 and var86", var74.equals(var86) ? var74.hashCode() == var86.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var86 and var74
//     assertTrue("Contract failed: equals-hashcode on var86 and var74", var86.equals(var74) ? var86.hashCode() == var74.hashCode() : true);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     var0.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Font var5 = var0.getItemLabelFont(0, 5);
//     java.awt.Stroke var6 = var0.getBaseStroke();
//     java.awt.Paint var9 = var0.getItemPaint((-1), 0);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var12 = var11.getColumnCount();
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var11.setSeriesShape(100, var16, false);
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var21 = var20.getColumnCount();
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var20.setSeriesShape(100, var25, false);
//     var11.setSeriesShape(1, var25);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var33.zoomRange((-1.0d), 0.0d);
//     boolean var37 = var33.isPositiveArrowVisible();
//     boolean var38 = var33.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var40 = var39.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var44 = var43.isNegativeArrowVisible();
//     var43.setAutoRangeStickyZero(false);
//     java.awt.Stroke var47 = var43.getTickMarkStroke();
//     var39.setSeriesOutlineStroke(1, var47, false);
//     boolean var51 = var39.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var53.zoomRange((-1.0d), 0.0d);
//     boolean var57 = var53.isPositiveArrowVisible();
//     java.awt.Paint var58 = var53.getAxisLinePaint();
//     var39.setBasePaint(var58);
//     org.jfree.chart.labels.CategoryToolTipGenerator var60 = null;
//     var39.setBaseToolTipGenerator(var60);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var29, var31, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     var11.setPlot(var62);
//     org.jfree.chart.axis.AxisLocation var65 = var62.getRangeAxisLocation(4);
//     org.jfree.chart.ChartRenderingInfo var67 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var68 = new org.jfree.chart.plot.PlotRenderingInfo(var67);
//     org.jfree.chart.renderer.category.BarRenderer var69 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var70 = var69.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var74 = var73.isNegativeArrowVisible();
//     var73.setAutoRangeStickyZero(false);
//     java.awt.Stroke var77 = var73.getTickMarkStroke();
//     var69.setSeriesOutlineStroke(1, var77, false);
//     boolean var81 = var69.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var83.zoomRange((-1.0d), 0.0d);
//     boolean var87 = var83.isPositiveArrowVisible();
//     java.awt.Paint var88 = var83.getAxisLinePaint();
//     var69.setBasePaint(var88);
//     boolean var90 = var68.equals((java.lang.Object)var88);
//     org.jfree.chart.renderer.RendererState var91 = new org.jfree.chart.renderer.RendererState(var68);
//     java.awt.geom.Point2D var92 = null;
//     var62.zoomDomainAxes(11.05d, var68, var92);
//     java.awt.geom.Rectangle2D var94 = null;
//     var0.drawOutline(var10, var62, var94);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var6 = var5.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var10 = var9.isNegativeArrowVisible();
//     var9.setAutoRangeStickyZero(false);
//     java.awt.Stroke var13 = var9.getTickMarkStroke();
//     var5.setSeriesOutlineStroke(1, var13, false);
//     var0.setSeriesOutlineStroke(0, var13, false);
//     var0.setBaseSeriesVisible(false);
//     boolean var22 = var0.getItemVisible(4, 5);
//     java.lang.Boolean var24 = var0.getSeriesVisibleInLegend(0);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var30.zoomRange((-1.0d), 0.0d);
//     boolean var34 = var30.isPositiveArrowVisible();
//     boolean var35 = var30.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var37 = var36.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var41 = var40.isNegativeArrowVisible();
//     var40.setAutoRangeStickyZero(false);
//     java.awt.Stroke var44 = var40.getTickMarkStroke();
//     var36.setSeriesOutlineStroke(1, var44, false);
//     boolean var48 = var36.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var50.zoomRange((-1.0d), 0.0d);
//     boolean var54 = var50.isPositiveArrowVisible();
//     java.awt.Paint var55 = var50.getAxisLinePaint();
//     var36.setBasePaint(var55);
//     org.jfree.chart.labels.CategoryToolTipGenerator var57 = null;
//     var36.setBaseToolTipGenerator(var57);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var26, var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     var59.setDomainGridlinesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var63 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var64 = var63.getColumnCount();
//     var63.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var68 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var69 = var68.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var73 = var72.isNegativeArrowVisible();
//     var72.setAutoRangeStickyZero(false);
//     java.awt.Stroke var76 = var72.getTickMarkStroke();
//     var68.setSeriesOutlineStroke(1, var76, false);
//     var63.setSeriesOutlineStroke(0, var76, false);
//     var63.setBaseSeriesVisible(false);
//     var63.setBaseCreateEntities(true);
//     int var85 = var63.getRowCount();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var87 = null;
//     var63.setSeriesItemLabelGenerator(4, var87, true);
//     var59.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
//     org.jfree.chart.labels.ItemLabelPosition var92 = var63.getSeriesNegativeItemLabelPosition(0);
//     var0.setSeriesPositiveItemLabelPosition(4, var92, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var63 and var0.", var63.equals(var0) == var0.equals(var63));
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    java.awt.Paint var40 = var33.getDomainGridlinePaint();
    org.jfree.chart.plot.DatasetRenderingOrder var41 = var33.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var8 = var7.getColumnCount();
//     var7.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var7.setSeriesNegativeItemLabelPosition(100, var12, true);
//     var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var22 = var21.getColumnCount();
//     var21.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var27 = var26.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var31 = var30.isNegativeArrowVisible();
//     var30.setAutoRangeStickyZero(false);
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var26.setSeriesOutlineStroke(1, var34, false);
//     var21.setSeriesOutlineStroke(0, var34, false);
//     var20.setAxisLineStroke(var34);
//     var7.setBaseStroke(var34, true);
//     var0.setSeriesOutlineStroke(0, var34, true);
//     org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
//     var50.setHeight(100.0d);
//     boolean var53 = var50.getNotify();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var54 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.awt.Paint var55 = var54.getErrorIndicatorPaint();
//     var50.setPaint(var55);
//     boolean var57 = var49.equals((java.lang.Object)var55);
//     org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var59 = var58.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var60 = var58.getLegendItemToolTipGenerator();
//     org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var62 = var61.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var63 = var61.getLegendItemLabelGenerator();
//     var58.setLegendItemLabelGenerator(var63);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var67 = var58.getItemLabelGenerator(1, 4);
//     java.awt.Paint var69 = var58.getSeriesPaint(1);
//     org.jfree.chart.renderer.category.BarRenderer var70 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var73 = var70.getItemOutlinePaint(4, 10);
//     var58.setBasePaint(var73);
//     var49.setBackgroundPaint(var73);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var61 and var0.", var61.equals(var0) == var0.equals(var61));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var61 and var26.", var61.equals(var26) == var26.equals(var61));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var70 and var0.", var70.equals(var0) == var0.equals(var70));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var70 and var26.", var70.equals(var26) == var26.equals(var70));
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("1", var1, 0.0f, 2.0f, 0.2d, 2.0f, 1.0f);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var39 = var38.isNegativeArrowVisible();
    var38.setAutoRangeStickyZero(false);
    java.awt.Stroke var42 = var38.getTickMarkStroke();
    var34.setSeriesOutlineStroke(1, var42, false);
    var34.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var48 = null;
    var34.setSeriesToolTipGenerator(1, var48);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var50 = var34.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var53 = var34.getPositiveItemLabelPosition(10, (-1));
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var54 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var34};
    var33.setRenderers(var54);
    java.awt.Paint var56 = var33.getOutlinePaint();
    org.jfree.chart.axis.AxisLocation var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setDomainAxisLocation(var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    var1.setMaximumCategoryLabelLines((-1));
    var1.setMaximumCategoryLabelLines((-1));
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var11 = var10.getBackgroundPaint();
    java.awt.Paint var12 = var10.getPaint();
    java.awt.Font var13 = var10.getFont();
    org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("", var13);
    var1.setTickLabelFont((java.lang.Comparable)(byte)1, var13);
    var1.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    boolean var36 = var33.isRangeCrosshairVisible();
    var33.setRangeCrosshairVisible(false);
    org.jfree.chart.LegendItemCollection var39 = var33.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    java.awt.Shape var21 = var0.getSeriesShape(0);
    java.awt.Stroke var23 = var0.getSeriesStroke(100);
    boolean var24 = var0.getAutoPopulateSeriesShape();
    var0.setSeriesVisibleInLegend(1, (java.lang.Boolean)true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var8 = null;
    var7.addChangeListener(var8);
    java.awt.Shape var10 = var7.getRightArrow();
    org.jfree.chart.entity.CategoryLabelEntity var13 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)Double.POSITIVE_INFINITY, var10, "ChartChangeEventType.GENERAL", "AxisLocation.BOTTOM_OR_LEFT");
    org.jfree.chart.entity.CategoryLabelEntity var16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)1, var10, "AxisLocation.BOTTOM_OR_LEFT", "poly");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var19 = var18.getErrorIndicatorPaint();
    var17.setBaseFillPaint(var19);
    java.awt.Stroke var21 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    boolean var23 = var22.getAutoPopulateSeriesStroke();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    boolean var33 = var28.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var39 = var38.isNegativeArrowVisible();
    var38.setAutoRangeStickyZero(false);
    java.awt.Stroke var42 = var38.getTickMarkStroke();
    var34.setSeriesOutlineStroke(1, var42, false);
    boolean var46 = var34.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    java.awt.Paint var53 = var48.getAxisLinePaint();
    var34.setBasePaint(var53);
    org.jfree.chart.labels.CategoryToolTipGenerator var55 = null;
    var34.setBaseToolTipGenerator(var55);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var24, var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    var57.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var60 = null;
    var57.markerChanged(var60);
    boolean var62 = var57.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var63 = var57.getLegendItems();
    org.jfree.chart.ChartColor var67 = new org.jfree.chart.ChartColor(4, 1, 100);
    var57.setNoDataMessagePaint((java.awt.Paint)var67);
    var22.setErrorIndicatorPaint((java.awt.Paint)var67);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("ChartChangeEventType.GENERAL", "AxisLocation.BOTTOM_OR_LEFT", "", "hi!", var10, var19, var21, (java.awt.Paint)var67);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Category Plot", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    java.awt.Stroke var38 = null;
    var33.setOutlineStroke(var38);
    org.jfree.chart.axis.ValueAxis var41 = var33.getRangeAxisForDataset(0);
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
    var46.zoomRange((-1.0d), 0.0d);
    boolean var50 = var46.isPositiveArrowVisible();
    boolean var51 = var46.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
    int var53 = var52.getColumnCount();
    org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var57 = var56.isNegativeArrowVisible();
    var56.setAutoRangeStickyZero(false);
    java.awt.Stroke var60 = var56.getTickMarkStroke();
    var52.setSeriesOutlineStroke(1, var60, false);
    boolean var64 = var52.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
    var66.zoomRange((-1.0d), 0.0d);
    boolean var70 = var66.isPositiveArrowVisible();
    java.awt.Paint var71 = var66.getAxisLinePaint();
    var52.setBasePaint(var71);
    org.jfree.chart.labels.CategoryToolTipGenerator var73 = null;
    var52.setBaseToolTipGenerator(var73);
    org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot(var42, var44, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.renderer.category.CategoryItemRenderer)var52);
    org.jfree.chart.axis.AxisLocation var76 = var75.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var77 = var76.getOpposite();
    var33.setDomainAxisLocation(var77, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var80 = var33.getRenderer();
    org.jfree.data.category.CategoryDataset var81 = var33.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.String var2 = var1.getID();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "NOID"+ "'", var2.equals("NOID"));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"0", var3, "0", "CategoryLabelEntity: category=false, tooltip=, url=0");
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Paint var9 = var8.getPaint();
    org.jfree.chart.title.LegendGraphic var10 = new org.jfree.chart.title.LegendGraphic(var3, var9);
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    var11.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var18 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var11.setMargin(var18);
    double var21 = var18.calculateTopInset(0.0d);
    double var23 = var18.calculateBottomInset(10.0d);
    double var24 = var18.getLeft();
    var10.setPadding(var18);
    double var27 = var18.trimHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-20.0d));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("CategoryLabelEntity: category=false, tooltip=, url=0");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Category Plot");

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Shape var2 = var0.lookupSeriesShape(10);
    java.awt.Stroke var4 = var0.getSeriesStroke(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    java.awt.Paint var2 = var1.getLabelPaint();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    int var4 = var3.getColumnCount();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var8 = var7.isNegativeArrowVisible();
    var7.setAutoRangeStickyZero(false);
    java.awt.Stroke var11 = var7.getTickMarkStroke();
    var3.setSeriesOutlineStroke(1, var11, false);
    boolean var15 = var3.isSeriesVisible(10);
    org.jfree.data.general.DatasetGroup var18 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    int var20 = var19.getColumnCount();
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var19.setSeriesShape(100, var24, false);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var28.setSeriesShape(100, var33, false);
    var19.setSeriesShape(1, var33);
    boolean var37 = var18.equals((java.lang.Object)var19);
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var39 = var38.getBackgroundPaint();
    java.awt.Paint var40 = var38.getPaint();
    org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder(var40);
    var19.setBaseItemLabelPaint(var40, false);
    var3.setSeriesItemLabelPaint(1, var40, true);
    var1.setLabelPaint(var40);
    org.jfree.chart.util.RectangleAnchor var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var0.getMeanValue(0, (-16580609));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", var1);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var39 = var33.getLegendItems();
    org.jfree.chart.ChartColor var43 = new org.jfree.chart.ChartColor(4, 1, 100);
    var33.setNoDataMessagePaint((java.awt.Paint)var43);
    org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var47 = var46.getLabelOffset();
    org.jfree.chart.util.RectangleInsets var48 = var46.getLabelOffset();
    var33.setInsets(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("0");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
//     java.awt.Font var4 = var3.getFont();
//     org.jfree.data.Range var5 = null;
//     org.jfree.data.Range var6 = null;
//     org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, var6);
//     org.jfree.chart.block.RectangleConstraint var8 = var7.toUnconstrainedWidth();
//     org.jfree.chart.block.RectangleConstraint var9 = var7.toUnconstrainedWidth();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     var1.removeFragment(var3);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var19 = var18.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var21 = var20.getColumnCount();
//     var20.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var20.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var25 = var24.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var27 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0d, "0", var19, var25, Double.POSITIVE_INFINITY);
//     var1.draw(var12, 2.0f, (-1.0f), var19, 10.0f, 1.0f, 0.05d);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var41 = var40.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAxis[] var42 = new org.jfree.chart.axis.CategoryAxis[] { var40};
    var33.setDomainAxes(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = var33.getRenderer();
    org.jfree.chart.plot.DatasetRenderingOrder var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setDatasetRenderingOrder(var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var4 = var3.brighter();
    float[] var8 = new float[] { 100.0f, 10.0f, (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var9 = var3.getRGBComponents(var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseSeriesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var8 = var7.getColumnCount();
//     var7.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var12 = null;
//     var7.setSeriesNegativeItemLabelPosition(100, var12, true);
//     var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var22 = var21.getColumnCount();
//     var21.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var27 = var26.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var31 = var30.isNegativeArrowVisible();
//     var30.setAutoRangeStickyZero(false);
//     java.awt.Stroke var34 = var30.getTickMarkStroke();
//     var26.setSeriesOutlineStroke(1, var34, false);
//     var21.setSeriesOutlineStroke(0, var34, false);
//     var20.setAxisLineStroke(var34);
//     var7.setBaseStroke(var34, true);
//     var0.setSeriesOutlineStroke(0, var34, true);
//     org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
//     java.lang.Object var47 = null;
//     boolean var48 = var46.equals(var47);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
//     org.jfree.chart.block.BlockContainer var50 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
//     
//     // Checks the contract:  equals-hashcode on var45 and var50
//     assertTrue("Contract failed: equals-hashcode on var45 and var50", var45.equals(var50) ? var45.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var45
//     assertTrue("Contract failed: equals-hashcode on var50 and var45", var50.equals(var45) ? var50.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "1", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "", "AxisLocation.BOTTOM_OR_LEFT");
    java.lang.String var6 = var5.getCopyright();
    var5.addOptionalLibrary("RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    java.awt.Font var8 = null;
    var0.setBaseItemLabelFont(var8, true);
    var0.setBaseSeriesVisibleInLegend(true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = null;
    var0.setSeriesItemLabelGenerator(100, var14, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = var0.getBaseToolTipGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var19 = null;
    var0.setSeriesURLGenerator(1, var19, false);
    java.awt.Stroke var23 = var0.getSeriesStroke(4);
    var0.setAutoPopulateSeriesStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    var0.setBaseCreateEntities(true);
    int var22 = var0.getRowCount();
    boolean var23 = var0.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.TickUnit var1 = null;
//     var0.add(var1);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    int var20 = var0.getRowCount();
    java.awt.Stroke var22 = var0.getSeriesStroke(1);
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle();
    var24.setHeight(100.0d);
    boolean var27 = var24.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var28 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var29 = var28.getErrorIndicatorPaint();
    var24.setPaint(var29);
    org.jfree.chart.ChartColor var34 = new org.jfree.chart.ChartColor(4, 1, 100);
    var24.setBackgroundPaint((java.awt.Paint)var34);
    int var36 = var34.getTransparency();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-16777216), (java.awt.Paint)var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(11.05d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, 100.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-33));

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 0.0d);
    double var3 = var2.getLowerBound();
    double var4 = var2.getLowerBound();
    org.jfree.data.Range var7 = org.jfree.data.Range.expand(var2, 1.0d, 6.0d);
    org.jfree.data.Range var10 = new org.jfree.data.Range(0.0d, 0.0d);
    double var11 = var10.getLowerBound();
    double var12 = var10.getLowerBound();
    org.jfree.data.Range var15 = org.jfree.data.Range.expand(var10, 1.0d, 6.0d);
    org.jfree.data.Range var16 = org.jfree.data.Range.combine(var7, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.plot.CategoryMarker var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addDomainMarker(var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    java.awt.Font var50 = var49.getItemFont();
    java.awt.Paint var51 = var49.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    java.awt.Font var12 = var0.getSeriesItemLabelFont(100);
    var0.setBaseSeriesVisible(false, false);
    java.awt.Stroke var16 = var0.getBaseOutlineStroke();
    org.jfree.chart.labels.CategoryItemLabelGenerator var17 = null;
    var0.setBaseItemLabelGenerator(var17);
    java.lang.Boolean var20 = var0.getSeriesItemLabelsVisible(100);
    org.jfree.chart.urls.CategoryURLGenerator var22 = null;
    var0.setSeriesURLGenerator(0, var22);
    var0.setSeriesItemLabelsVisible(0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    var1.clear();
    double var3 = var1.getWidth();
    double var4 = var1.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    var1.setAutoTickUnitSelection(true);
    boolean var8 = var1.isAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var6.zoomRange((-1.0d), 0.0d);
//     boolean var10 = var6.isPositiveArrowVisible();
//     boolean var11 = var6.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var13 = var12.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var17 = var16.isNegativeArrowVisible();
//     var16.setAutoRangeStickyZero(false);
//     java.awt.Stroke var20 = var16.getTickMarkStroke();
//     var12.setSeriesOutlineStroke(1, var20, false);
//     boolean var24 = var12.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var26.zoomRange((-1.0d), 0.0d);
//     boolean var30 = var26.isPositiveArrowVisible();
//     java.awt.Paint var31 = var26.getAxisLinePaint();
//     var12.setBasePaint(var31);
//     org.jfree.chart.labels.CategoryToolTipGenerator var33 = null;
//     var12.setBaseToolTipGenerator(var33);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var2, var4, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.plot.CategoryPlot var36 = var12.getPlot();
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
//     org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var41 = var40.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var45 = var44.isNegativeArrowVisible();
//     var44.setAutoRangeStickyZero(false);
//     java.awt.Stroke var48 = var44.getTickMarkStroke();
//     var40.setSeriesOutlineStroke(1, var48, false);
//     boolean var52 = var40.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var54.zoomRange((-1.0d), 0.0d);
//     boolean var58 = var54.isPositiveArrowVisible();
//     java.awt.Paint var59 = var54.getAxisLinePaint();
//     var40.setBasePaint(var59);
//     boolean var61 = var39.equals((java.lang.Object)var59);
//     org.jfree.chart.renderer.RendererState var62 = new org.jfree.chart.renderer.RendererState(var39);
//     org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var64 = var63.getBackgroundPaint();
//     java.awt.Paint var65 = var63.getPaint();
//     java.awt.Font var66 = var63.getFont();
//     boolean var67 = var39.equals((java.lang.Object)var63);
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.util.RectangleAnchor var69 = null;
//     java.awt.geom.Point2D var70 = org.jfree.chart.util.RectangleAnchor.coordinates(var68, var69);
//     var36.zoomDomainAxes(Double.POSITIVE_INFINITY, var39, var70);
//     int var72 = var1.getSubplotIndex(var70);
//     
//     // Checks the contract:  equals-hashcode on var1 and var39
//     assertTrue("Contract failed: equals-hashcode on var1 and var39", var1.equals(var39) ? var1.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var1
//     assertTrue("Contract failed: equals-hashcode on var39 and var1", var39.equals(var1) ? var39.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.ChartRenderingInfo var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = new org.jfree.chart.plot.PlotRenderingInfo(var36);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    int var39 = var38.getColumnCount();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var43 = var42.isNegativeArrowVisible();
    var42.setAutoRangeStickyZero(false);
    java.awt.Stroke var46 = var42.getTickMarkStroke();
    var38.setSeriesOutlineStroke(1, var46, false);
    boolean var50 = var38.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var38.setBasePaint(var57);
    boolean var59 = var37.equals((java.lang.Object)var57);
    var33.handleClick(0, 100, var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var62 = var37.getSubplotInfo((-33));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var7.setSeriesShape(100, var12, false);
    org.jfree.chart.entity.CategoryLabelEntity var17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var12, "", "0");
    java.awt.Shape var18 = var17.getArea();
    boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var18);
    var1.setDownArrow(var18);
    java.awt.Font var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    org.jfree.chart.axis.AxisSpace var35 = var33.getFixedRangeAxisSpace();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
    var37.zoomRange((-1.0d), 0.0d);
    boolean var41 = var37.isPositiveArrowVisible();
    boolean var42 = var37.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var44 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var46 = var44.valueToString(0.0d);
    var37.setTickUnit(var44);
    org.jfree.chart.JFreeChart var48 = null;
    org.jfree.chart.event.ChartProgressEvent var51 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var37, var48, (-1), 10);
    var37.setPositiveArrowVisible(true);
    var37.resizeRange(6.0d, 0.0d);
    org.jfree.data.Range var57 = var37.getRange();
    org.jfree.data.Range var58 = var33.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
    org.jfree.chart.plot.CategoryMarker var59 = null;
    org.jfree.chart.util.Layer var60 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addDomainMarker(var59, var60);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "0"+ "'", var46.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.axis.AxisCollection var0 = new org.jfree.chart.axis.AxisCollection();
    java.util.List var1 = var0.getAxesAtBottom();
    java.util.List var2 = var0.getAxesAtTop();
    org.jfree.chart.axis.Axis var3 = null;
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    var8.zoomRange((-1.0d), 0.0d);
    boolean var12 = var8.isPositiveArrowVisible();
    boolean var13 = var8.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    int var15 = var14.getColumnCount();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var19 = var18.isNegativeArrowVisible();
    var18.setAutoRangeStickyZero(false);
    java.awt.Stroke var22 = var18.getTickMarkStroke();
    var14.setSeriesOutlineStroke(1, var22, false);
    boolean var26 = var14.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    java.awt.Paint var33 = var28.getAxisLinePaint();
    var14.setBasePaint(var33);
    org.jfree.chart.labels.CategoryToolTipGenerator var35 = null;
    var14.setBaseToolTipGenerator(var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var4, var6, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    var37.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var40 = null;
    var37.markerChanged(var40);
    java.awt.Stroke var42 = null;
    var37.setOutlineStroke(var42);
    org.jfree.chart.axis.ValueAxis var45 = var37.getRangeAxisForDataset(0);
    org.jfree.data.category.CategoryDataset var46 = null;
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
    var50.zoomRange((-1.0d), 0.0d);
    boolean var54 = var50.isPositiveArrowVisible();
    boolean var55 = var50.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    int var57 = var56.getColumnCount();
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var61 = var60.isNegativeArrowVisible();
    var60.setAutoRangeStickyZero(false);
    java.awt.Stroke var64 = var60.getTickMarkStroke();
    var56.setSeriesOutlineStroke(1, var64, false);
    boolean var68 = var56.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("hi!");
    var70.zoomRange((-1.0d), 0.0d);
    boolean var74 = var70.isPositiveArrowVisible();
    java.awt.Paint var75 = var70.getAxisLinePaint();
    var56.setBasePaint(var75);
    org.jfree.chart.labels.CategoryToolTipGenerator var77 = null;
    var56.setBaseToolTipGenerator(var77);
    org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot(var46, var48, (org.jfree.chart.axis.ValueAxis)var50, (org.jfree.chart.renderer.category.CategoryItemRenderer)var56);
    org.jfree.chart.axis.AxisLocation var80 = var79.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var81 = var80.getOpposite();
    var37.setDomainAxisLocation(var81, false);
    org.jfree.chart.util.RectangleEdge var84 = var37.getDomainAxisEdge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var3, var84);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("1", var1);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    var41.setBaseSeriesVisible(false);
    var41.setBaseSeriesVisible(true);
    var33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var41, true);
    boolean var50 = var41.isSeriesVisible(0);
    org.jfree.chart.plot.DrawingSupplier var51 = var41.getDrawingSupplier();
    double var52 = var41.getLowerClip();
    java.awt.Paint var54 = var41.getSeriesPaint(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 11.05d, Double.NaN, 0, (java.lang.Comparable)"AxisLocation.BOTTOM_OR_LEFT");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
//     java.awt.Paint var3 = var1.getOutlinePaint();
//     org.jfree.chart.text.TextBlock var5 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var9 = var8.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var11 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var5, var6, var9, 0.0d);
//     var1.setLabelTextAnchor(var9);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "1", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "", "AxisLocation.BOTTOM_OR_LEFT");
    org.jfree.chart.ui.Library[] var6 = var5.getOptionalLibraries();
    var5.setName("CategoryAnchor.MIDDLE");
    var5.setCopyright("poly");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("[size=10]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    org.jfree.chart.plot.CategoryMarker var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addDomainMarker(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var4 = var3.brighter();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    var6.zoomRange((-1.0d), 0.0d);
    boolean var10 = var6.isPositiveArrowVisible();
    boolean var11 = var6.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var13 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var15 = var13.valueToString(0.0d);
    var6.setTickUnit(var13);
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartProgressEvent var20 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var6, var17, (-1), 10);
    var6.setPositiveArrowVisible(true);
    var6.resizeRange(6.0d, 0.0d);
    org.jfree.data.Range var26 = var6.getRange();
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var29 = var28.isNegativeArrowVisible();
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var34.setSeriesShape(100, var39, false);
    org.jfree.chart.entity.CategoryLabelEntity var44 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var39, "", "0");
    java.awt.Shape var45 = var44.getArea();
    boolean var46 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var32, (java.lang.Object)var45);
    var28.setDownArrow(var45);
    var6.setDownArrow(var45);
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("hi!");
    var53.zoomRange((-1.0d), 0.0d);
    boolean var57 = var53.isPositiveArrowVisible();
    boolean var58 = var53.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var59 = new org.jfree.chart.renderer.category.BarRenderer();
    int var60 = var59.getColumnCount();
    org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var64 = var63.isNegativeArrowVisible();
    var63.setAutoRangeStickyZero(false);
    java.awt.Stroke var67 = var63.getTickMarkStroke();
    var59.setSeriesOutlineStroke(1, var67, false);
    boolean var71 = var59.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var73 = new org.jfree.chart.axis.NumberAxis("hi!");
    var73.zoomRange((-1.0d), 0.0d);
    boolean var77 = var73.isPositiveArrowVisible();
    java.awt.Paint var78 = var73.getAxisLinePaint();
    var59.setBasePaint(var78);
    org.jfree.chart.labels.CategoryToolTipGenerator var80 = null;
    var59.setBaseToolTipGenerator(var80);
    org.jfree.chart.plot.CategoryPlot var82 = new org.jfree.chart.plot.CategoryPlot(var49, var51, (org.jfree.chart.axis.ValueAxis)var53, (org.jfree.chart.renderer.category.CategoryItemRenderer)var59);
    var82.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var85 = null;
    var82.markerChanged(var85);
    org.jfree.chart.util.SortOrder var87 = var82.getRowRenderingOrder();
    var82.setRangeGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var90 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var91 = var90.getBackgroundPaint();
    java.awt.Paint var92 = var90.getPaint();
    var82.setDomainGridlinePaint(var92);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic(var45, var92);
    boolean var95 = var94.isShapeOutlineVisible();
    org.jfree.chart.util.RectangleAnchor var96 = var94.getShapeLocation();
    org.jfree.chart.util.RectangleAnchor var97 = var94.getShapeLocation();
    boolean var98 = var4.equals((java.lang.Object)var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "0"+ "'", var15.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == false);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.axis.NumberTickUnit var13 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var15 = var13.valueToString(0.0d);
    var1.setTickUnit(var13, true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(1.0d, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "0"+ "'", var15.equals("0"));

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     java.lang.String var36 = var33.getNoDataMessage();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var39.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.util.RectangleInsets var42 = var39.getLabelInsets();
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var46 = var45.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var50 = var49.isNegativeArrowVisible();
//     var49.setAutoRangeStickyZero(false);
//     java.awt.Stroke var53 = var49.getTickMarkStroke();
//     var45.setSeriesOutlineStroke(1, var53, false);
//     boolean var57 = var45.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var59.zoomRange((-1.0d), 0.0d);
//     boolean var63 = var59.isPositiveArrowVisible();
//     java.awt.Paint var64 = var59.getAxisLinePaint();
//     var45.setBasePaint(var64);
//     boolean var66 = var44.equals((java.lang.Object)var64);
//     org.jfree.chart.renderer.RendererState var67 = new org.jfree.chart.renderer.RendererState(var44);
//     java.awt.geom.Rectangle2D var68 = var44.getDataArea();
//     java.awt.geom.Rectangle2D var69 = var42.createInsetRectangle(var68);
//     var33.drawBackgroundImage(var37, var69);
//     java.awt.geom.Rectangle2D var71 = null;
//     boolean var72 = org.jfree.chart.util.ShapeUtilities.intersects(var69, var71);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var2.setSeriesShape(100, var7, false);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var11.setSeriesShape(100, var16, false);
    var2.setSeriesShape(1, var16);
    boolean var20 = var1.equals((java.lang.Object)var2);
    java.lang.Object var21 = var1.clone();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    var23.zoomRange((-1.0d), 0.0d);
    boolean var27 = var23.isPositiveArrowVisible();
    boolean var28 = var23.isInverted();
    var23.configure();
    boolean var30 = var1.equals((java.lang.Object)var23);
    var23.centerRange(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("RectangleInsets[t=10.0,l=-1.0,b=10.0,r=-1.0]", 100, 10);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    org.jfree.chart.labels.CategoryToolTipGenerator var52 = var0.getToolTipGenerator(4, 0);
    double var53 = var0.getLowerClip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.Number var4 = var0.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    var10.zoomRange((-1.0d), 0.0d);
    boolean var14 = var10.isPositiveArrowVisible();
    boolean var15 = var10.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    int var17 = var16.getColumnCount();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var21 = var20.isNegativeArrowVisible();
    var20.setAutoRangeStickyZero(false);
    java.awt.Stroke var24 = var20.getTickMarkStroke();
    var16.setSeriesOutlineStroke(1, var24, false);
    boolean var28 = var16.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    var30.zoomRange((-1.0d), 0.0d);
    boolean var34 = var30.isPositiveArrowVisible();
    java.awt.Paint var35 = var30.getAxisLinePaint();
    var16.setBasePaint(var35);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var16.setBaseToolTipGenerator(var37);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    var39.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var42 = null;
    var39.markerChanged(var42);
    org.jfree.chart.util.SortOrder var44 = var39.getRowRenderingOrder();
    var39.configureDomainAxes();
    org.jfree.chart.util.SortOrder var46 = var39.getColumnRenderingOrder();
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var39);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var50 = var0.getStdDevValue((-1), (-16580609));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextBlock var2 = null;
    org.jfree.chart.text.TextBlockAnchor var3 = null;
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var8 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)100.0f, var2, var3, var6, 1.0d);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    var9.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var9.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var16 = new org.jfree.chart.labels.ItemLabelPosition(var0, var6, var14, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isRangeCrosshairLockedOnData();
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    int var40 = var39.getColumnCount();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var44 = var43.isNegativeArrowVisible();
    var43.setAutoRangeStickyZero(false);
    java.awt.Stroke var47 = var43.getTickMarkStroke();
    var39.setSeriesOutlineStroke(1, var47, false);
    java.awt.Font var51 = var39.getSeriesItemLabelFont(100);
    var39.setBaseSeriesVisible(false, false);
    java.awt.Stroke var55 = var39.getBaseOutlineStroke();
    var33.setDomainGridlineStroke(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-16580609), 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    double var1 = var0.getCursor();
    java.util.List var2 = var0.getTicks();
    var0.cursorLeft((-1.0d));
    java.util.List var5 = var0.getTicks();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    java.lang.Number var4 = var0.getValue((java.lang.Comparable)11.05d, (java.lang.Comparable)1.0E-8d);
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    var10.zoomRange((-1.0d), 0.0d);
    boolean var14 = var10.isPositiveArrowVisible();
    boolean var15 = var10.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    int var17 = var16.getColumnCount();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var21 = var20.isNegativeArrowVisible();
    var20.setAutoRangeStickyZero(false);
    java.awt.Stroke var24 = var20.getTickMarkStroke();
    var16.setSeriesOutlineStroke(1, var24, false);
    boolean var28 = var16.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    var30.zoomRange((-1.0d), 0.0d);
    boolean var34 = var30.isPositiveArrowVisible();
    java.awt.Paint var35 = var30.getAxisLinePaint();
    var16.setBasePaint(var35);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var16.setBaseToolTipGenerator(var37);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    var39.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var42 = null;
    var39.markerChanged(var42);
    org.jfree.chart.util.SortOrder var44 = var39.getRowRenderingOrder();
    var39.configureDomainAxes();
    org.jfree.chart.util.SortOrder var46 = var39.getColumnRenderingOrder();
    var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var39);
    org.jfree.chart.plot.CategoryMarker var48 = null;
    org.jfree.chart.util.Layer var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var39.addDomainMarker(var48, var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(false);
    boolean var3 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.axis.TickType var0 = null;
//     org.jfree.chart.text.TextBlock var4 = null;
//     org.jfree.chart.text.TextBlockAnchor var5 = null;
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var8 = var7.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var4, var5, var8, 0.0d);
//     org.jfree.chart.text.TextAnchor var11 = var10.getRotationAnchor();
//     org.jfree.chart.text.TextBlock var13 = null;
//     org.jfree.chart.text.TextBlockAnchor var14 = null;
//     org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var17 = var16.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var19 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var13, var14, var17, 0.0d);
//     java.lang.Comparable var20 = var19.getCategory();
//     java.lang.String var21 = var19.toString();
//     org.jfree.chart.text.TextAnchor var22 = var19.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var24 = new org.jfree.chart.axis.NumberTick(var0, 1.0d, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", var11, var22, 1.0E-8d);
//     
//     // Checks the contract:  equals-hashcode on var7 and var16
//     assertTrue("Contract failed: equals-hashcode on var7 and var16", var7.equals(var16) ? var7.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var7
//     assertTrue("Contract failed: equals-hashcode on var16 and var7", var16.equals(var7) ? var16.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var12, (-1), 10);
    var1.setPositiveArrowVisible(true);
    var1.resizeRange(6.0d, 0.0d);
    org.jfree.data.Range var21 = var1.getRange();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    int var30 = var29.getColumnCount();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var29.setSeriesShape(100, var34, false);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var34, "", "0");
    java.awt.Shape var40 = var39.getArea();
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)var40);
    var23.setDownArrow(var40);
    var1.setDownArrow(var40);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    boolean var53 = var48.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
    int var55 = var54.getColumnCount();
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var59 = var58.isNegativeArrowVisible();
    var58.setAutoRangeStickyZero(false);
    java.awt.Stroke var62 = var58.getTickMarkStroke();
    var54.setSeriesOutlineStroke(1, var62, false);
    boolean var66 = var54.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    var54.setBasePaint(var73);
    org.jfree.chart.labels.CategoryToolTipGenerator var75 = null;
    var54.setBaseToolTipGenerator(var75);
    org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot(var44, var46, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var54);
    var77.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var80 = null;
    var77.markerChanged(var80);
    org.jfree.chart.util.SortOrder var82 = var77.getRowRenderingOrder();
    var77.setRangeGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var86 = var85.getBackgroundPaint();
    java.awt.Paint var87 = var85.getPaint();
    var77.setDomainGridlinePaint(var87);
    org.jfree.chart.title.LegendGraphic var89 = new org.jfree.chart.title.LegendGraphic(var40, var87);
    boolean var90 = var89.isShapeOutlineVisible();
    boolean var91 = var89.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == true);

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(0.2d);
    java.awt.Paint var16 = var15.getLabelPaint();
    org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
    int var18 = var17.getColumnCount();
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var22 = var21.isNegativeArrowVisible();
    var21.setAutoRangeStickyZero(false);
    java.awt.Stroke var25 = var21.getTickMarkStroke();
    var17.setSeriesOutlineStroke(1, var25, false);
    boolean var29 = var17.isSeriesVisible(10);
    org.jfree.data.general.DatasetGroup var32 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    int var34 = var33.getColumnCount();
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var33.setSeriesShape(100, var38, false);
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    int var43 = var42.getColumnCount();
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var42.setSeriesShape(100, var47, false);
    var33.setSeriesShape(1, var47);
    boolean var51 = var32.equals((java.lang.Object)var33);
    org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var53 = var52.getBackgroundPaint();
    java.awt.Paint var54 = var52.getPaint();
    org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder(var54);
    var33.setBaseItemLabelPaint(var54, false);
    var17.setSeriesItemLabelPaint(1, var54, true);
    var15.setLabelPaint(var54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-16580609), var54, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Paint var2 = var1.getPaint();
    org.jfree.chart.text.TextBlock var4 = null;
    org.jfree.chart.text.TextBlockAnchor var5 = null;
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var8 = var7.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var4, var5, var8, 0.0d);
    java.lang.Comparable var11 = var10.getCategory();
    java.lang.String var12 = var10.toString();
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    int var14 = var13.getColumnCount();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var18 = var17.isNegativeArrowVisible();
    var17.setAutoRangeStickyZero(false);
    java.awt.Stroke var21 = var17.getTickMarkStroke();
    var13.setSeriesOutlineStroke(1, var21, false);
    boolean var25 = var13.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    var27.zoomRange((-1.0d), 0.0d);
    boolean var31 = var27.isPositiveArrowVisible();
    java.awt.Paint var32 = var27.getAxisLinePaint();
    var13.setBasePaint(var32);
    org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var13.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var41 = new org.jfree.chart.axis.NumberAxis("hi!");
    var41.zoomRange((-1.0d), 0.0d);
    boolean var45 = var41.isPositiveArrowVisible();
    boolean var46 = var41.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var47 = new org.jfree.chart.renderer.category.BarRenderer();
    int var48 = var47.getColumnCount();
    org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var52 = var51.isNegativeArrowVisible();
    var51.setAutoRangeStickyZero(false);
    java.awt.Stroke var55 = var51.getTickMarkStroke();
    var47.setSeriesOutlineStroke(1, var55, false);
    boolean var59 = var47.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("hi!");
    var61.zoomRange((-1.0d), 0.0d);
    boolean var65 = var61.isPositiveArrowVisible();
    java.awt.Paint var66 = var61.getAxisLinePaint();
    var47.setBasePaint(var66);
    org.jfree.chart.labels.CategoryToolTipGenerator var68 = null;
    var47.setBaseToolTipGenerator(var68);
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var37, var39, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.renderer.category.CategoryItemRenderer)var47);
    var70.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var73 = null;
    var70.markerChanged(var73);
    org.jfree.chart.util.SortOrder var75 = var70.getRowRenderingOrder();
    boolean var76 = var13.hasListener((java.util.EventListener)var70);
    org.jfree.chart.util.RectangleInsets var81 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, (-1.0d), 10.0d);
    double var83 = var81.calculateLeftOutset(10.0d);
    double var85 = var81.extendWidth(0.05d);
    var70.setInsets(var81);
    boolean var87 = var10.equals((java.lang.Object)var81);
    java.lang.Comparable var88 = var10.getCategory();
    java.lang.Object var89 = var10.clone();
    boolean var90 = var1.equals((java.lang.Object)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "1"+ "'", var11.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 11.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + "1"+ "'", var88.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var1.valueToJava2D(4.0d, var8, var9);
    org.jfree.chart.axis.NumberTickUnit var12 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var14 = var12.valueToString(0.0d);
    var1.setTickUnit(var12, true, true);
    var1.setRange(1.0d, 6.0d);
    org.jfree.chart.axis.NumberTickUnit var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "0"+ "'", var14.equals("0"));

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var4 = var3.getLabelTextAnchor();
    org.jfree.chart.text.TextAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var7 = new org.jfree.chart.axis.NumberTick((java.lang.Number)4.0d, "ChartChangeEventType.GENERAL", var4, var5, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "1", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "", "AxisLocation.BOTTOM_OR_LEFT");
    org.jfree.chart.ui.Library[] var6 = var5.getOptionalLibraries();
    var5.setName("CategoryAnchor.MIDDLE");
    var5.setCopyright("[size=10]");
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    var15.zoomRange((-1.0d), 0.0d);
    boolean var19 = var15.isPositiveArrowVisible();
    boolean var20 = var15.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var26 = var25.isNegativeArrowVisible();
    var25.setAutoRangeStickyZero(false);
    java.awt.Stroke var29 = var25.getTickMarkStroke();
    var21.setSeriesOutlineStroke(1, var29, false);
    boolean var33 = var21.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi!");
    var35.zoomRange((-1.0d), 0.0d);
    boolean var39 = var35.isPositiveArrowVisible();
    java.awt.Paint var40 = var35.getAxisLinePaint();
    var21.setBasePaint(var40);
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var21.setBaseToolTipGenerator(var42);
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var11, var13, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    var44.setDomainGridlinesVisible(true);
    boolean var47 = var5.equals((java.lang.Object)true);
    java.lang.Object var48 = null;
    boolean var49 = var5.equals(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    double var1 = var0.getCursor();
    var0.cursorUp(Double.POSITIVE_INFINITY);
    var0.cursorLeft(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.event.MarkerChangeEvent var39 = null;
    var33.markerChanged(var39);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    int var42 = var41.getColumnCount();
    var41.setBaseSeriesVisible(false);
    var41.setBaseSeriesVisible(true);
    var33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var41, true);
    org.jfree.chart.axis.AxisLocation var50 = var33.getRangeAxisLocation(100);
    boolean var51 = var33.isRangeZoomable();
    boolean var52 = var33.getDrawSharedDomainAxis();
    org.jfree.data.category.CategoryDataset var54 = null;
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    var58.zoomRange((-1.0d), 0.0d);
    boolean var62 = var58.isPositiveArrowVisible();
    boolean var63 = var58.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var64 = new org.jfree.chart.renderer.category.BarRenderer();
    int var65 = var64.getColumnCount();
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var69 = var68.isNegativeArrowVisible();
    var68.setAutoRangeStickyZero(false);
    java.awt.Stroke var72 = var68.getTickMarkStroke();
    var64.setSeriesOutlineStroke(1, var72, false);
    boolean var76 = var64.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var78 = new org.jfree.chart.axis.NumberAxis("hi!");
    var78.zoomRange((-1.0d), 0.0d);
    boolean var82 = var78.isPositiveArrowVisible();
    java.awt.Paint var83 = var78.getAxisLinePaint();
    var64.setBasePaint(var83);
    org.jfree.chart.labels.CategoryToolTipGenerator var85 = null;
    var64.setBaseToolTipGenerator(var85);
    org.jfree.chart.plot.CategoryPlot var87 = new org.jfree.chart.plot.CategoryPlot(var54, var56, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.renderer.category.CategoryItemRenderer)var64);
    org.jfree.chart.axis.AxisLocation var88 = var87.getDomainAxisLocation();
    java.lang.String var89 = var88.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.setRangeAxisLocation((-1), var88);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var89 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var89.equals("AxisLocation.BOTTOM_OR_LEFT"));

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var7 = var1.getTickLabelInsets();
    var1.resizeRange(1.0d);
    var1.setTickMarkInsideLength(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), (-1.0d));
    java.lang.Number var3 = var2.getMean();
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, var5);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedWidth();
    boolean var8 = var2.equals((java.lang.Object)var6);
    java.lang.String var9 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"+ "'", var9.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 4.0d, 1.0E-8d);
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement();
//     org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     var7.add((org.jfree.chart.block.Block)var8, (java.lang.Object)var9);
//     java.lang.Object var11 = var8.clone();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.data.Range var13 = null;
//     org.jfree.data.Range var14 = null;
//     org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(var13, var14);
//     org.jfree.chart.block.RectangleConstraint var16 = var15.toUnconstrainedWidth();
//     org.jfree.chart.block.RectangleConstraint var17 = var15.toUnconstrainedHeight();
//     org.jfree.chart.util.Size2D var18 = var4.arrange(var8, var12, var15);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), (-1.0d));
    java.lang.Number var3 = var2.getMean();
    boolean var5 = var2.equals((java.lang.Object)0L);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    var10.zoomRange((-1.0d), 0.0d);
    boolean var14 = var10.isPositiveArrowVisible();
    boolean var15 = var10.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    int var17 = var16.getColumnCount();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var21 = var20.isNegativeArrowVisible();
    var20.setAutoRangeStickyZero(false);
    java.awt.Stroke var24 = var20.getTickMarkStroke();
    var16.setSeriesOutlineStroke(1, var24, false);
    boolean var28 = var16.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    var30.zoomRange((-1.0d), 0.0d);
    boolean var34 = var30.isPositiveArrowVisible();
    java.awt.Paint var35 = var30.getAxisLinePaint();
    var16.setBasePaint(var35);
    org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
    var16.setBaseToolTipGenerator(var37);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot(var6, var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    var39.setDomainGridlinesVisible(true);
    boolean var42 = var39.isRangeCrosshairVisible();
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    boolean var49 = var44.getAutoRangeIncludesZero();
    var44.resizeRange(4.0d);
    var44.setAxisLineVisible(false);
    org.jfree.chart.axis.ValueAxis[] var54 = new org.jfree.chart.axis.ValueAxis[] { var44};
    var39.setRangeAxes(var54);
    boolean var56 = var2.equals((java.lang.Object)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.DatasetGroup var41 = new org.jfree.data.general.DatasetGroup("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    var0.setGroup(var41);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var44 = var0.getRowKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    java.awt.Shape var15 = var14.getArea();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var54 = var53.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var53.getRenderer(1);
    boolean var57 = var19.hasListener((java.util.EventListener)var53);
    java.lang.Comparable var59 = null;
    org.jfree.chart.entity.CategoryItemEntity var60 = new org.jfree.chart.entity.CategoryItemEntity(var15, "poly", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)(-1.0f), var59);
    int var62 = var19.getRowIndex((java.lang.Comparable)"-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10");
    java.lang.Comparable var65 = null;
    var19.add((java.lang.Number)(short)10, (java.lang.Number)0.0d, var65, (java.lang.Comparable)10.0d);
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("hi!");
    var69.zoomRange((-1.0d), 0.0d);
    boolean var73 = var69.isPositiveArrowVisible();
    boolean var74 = var69.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var76 = null;
    org.jfree.chart.util.RectangleEdge var77 = null;
    double var78 = var69.valueToJava2D(4.0d, var76, var77);
    org.jfree.chart.axis.NumberTickUnit var80 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var82 = var80.valueToString(0.0d);
    var69.setTickUnit(var80, true, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var86 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var82 + "' != '" + "0"+ "'", var82.equals("0"));

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    var0.setMaximumBarWidth(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var33.markerChanged(var36);
//     boolean var38 = var33.isOutlineVisible();
//     org.jfree.chart.event.MarkerChangeEvent var39 = null;
//     var33.markerChanged(var39);
//     var33.setAnchorValue(0.0d);
//     boolean var43 = var33.isSubplot();
//     org.jfree.chart.axis.CategoryAxis[] var44 = null;
//     var33.setDomainAxes(var44);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var0.setBasePaint(var19);
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var0.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    boolean var33 = var28.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var39 = var38.isNegativeArrowVisible();
    var38.setAutoRangeStickyZero(false);
    java.awt.Stroke var42 = var38.getTickMarkStroke();
    var34.setSeriesOutlineStroke(1, var42, false);
    boolean var46 = var34.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    java.awt.Paint var53 = var48.getAxisLinePaint();
    var34.setBasePaint(var53);
    org.jfree.chart.labels.CategoryToolTipGenerator var55 = null;
    var34.setBaseToolTipGenerator(var55);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var24, var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    var57.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var60 = null;
    var57.markerChanged(var60);
    org.jfree.chart.util.SortOrder var62 = var57.getRowRenderingOrder();
    boolean var63 = var0.hasListener((java.util.EventListener)var57);
    org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var65.setMaximumCategoryLabelLines(0);
    org.jfree.chart.JFreeChart var68 = null;
    org.jfree.chart.event.ChartProgressEvent var71 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var65, var68, 10, 100);
    java.awt.Font var72 = var65.getLabelFont();
    int var73 = var57.getDomainAxisIndex(var65);
    var57.setRangeCrosshairValue(0.0d, true);
    boolean var77 = var57.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NOID", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", var3);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     double var1 = var0.getContentXOffset();
//     java.lang.String var2 = var0.getURLText();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var6 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), (-1.0d));
//     java.lang.Number var7 = var6.getMean();
//     org.jfree.data.Range var8 = null;
//     org.jfree.data.Range var9 = null;
//     org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, var9);
//     org.jfree.chart.block.RectangleConstraint var11 = var10.toUnconstrainedWidth();
//     boolean var12 = var6.equals((java.lang.Object)var10);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     var14.setWidth(0.0d);
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.axis.MarkerAxisBand var19 = var18.getMarkerBand();
//     boolean var20 = var14.equals((java.lang.Object)var18);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.axis.AxisState var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     java.util.List var25 = var18.refreshTicks(var21, var22, var23, var24);
//     org.jfree.data.Range var26 = var18.getRange();
//     org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(0.0d, var26);
//     org.jfree.chart.block.RectangleConstraint var28 = var10.toRangeHeight(var26);
//     org.jfree.chart.util.Size2D var29 = var0.arrange(var3, var10);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setMaximumCategoryLabelLines(0);
    var1.setMaximumCategoryLabelLines((-1));
    var1.setMaximumCategoryLabelLines((-1));
    double var8 = var1.getCategoryMargin();
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var12 = null;
    var11.addChangeListener(var12);
    java.awt.Shape var14 = var11.getRightArrow();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    int var17 = var16.getColumnCount();
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var16.setSeriesShape(100, var21, false);
    org.jfree.chart.entity.CategoryLabelEntity var26 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var21, "", "0");
    boolean var27 = org.jfree.chart.util.ShapeUtilities.equal(var14, var21);
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var14);
    org.jfree.chart.event.ChartChangeEventType var29 = var28.getType();
    java.lang.String var30 = var29.toString();
    org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var9, var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var32 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var30.equals("ChartChangeEventType.GENERAL"));

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var33.getRenderer(1);
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("hi!");
    var39.zoomRange((-1.0d), 0.0d);
    boolean var43 = var39.isPositiveArrowVisible();
    var33.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var39, true);
    org.jfree.chart.LegendItemCollection var46 = var33.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var48 = var46.get(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    java.awt.Shape var15 = var14.getArea();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var54 = var53.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var53.getRenderer(1);
    boolean var57 = var19.hasListener((java.util.EventListener)var53);
    java.lang.Comparable var59 = null;
    org.jfree.chart.entity.CategoryItemEntity var60 = new org.jfree.chart.entity.CategoryItemEntity(var15, "poly", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)(-1.0f), var59);
    org.jfree.data.category.CategoryDataset var61 = var60.getDataset();
    var60.setColumnKey((java.lang.Comparable)0.0f);
    org.jfree.data.category.CategoryDataset var64 = var60.getDataset();
    java.lang.String var65 = var60.getShapeCoords();
    org.jfree.data.category.CategoryDataset var66 = var60.getDataset();
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var74 = var68.getTickLabelInsets();
    double var76 = var74.calculateLeftOutset(0.0d);
    org.jfree.chart.title.TextTitle var77 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var78 = var77.getBackgroundPaint();
    java.awt.Paint var79 = var77.getPaint();
    org.jfree.chart.block.BlockBorder var80 = new org.jfree.chart.block.BlockBorder(var79);
    org.jfree.chart.block.BlockBorder var81 = new org.jfree.chart.block.BlockBorder(var74, var79);
    double var82 = var74.getRight();
    boolean var83 = var60.equals((java.lang.Object)var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"+ "'", var65.equals("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var41 = var40.getCategoryLabelPositionOffset();
    int var42 = var33.getDomainAxisIndex(var40);
    float var43 = var40.getMaximumCategoryLabelWidthRatio();
    var40.setLabelAngle(100.0d);
    org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
    int var47 = var46.getColumnCount();
    var46.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
    int var52 = var51.getColumnCount();
    org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var56 = var55.isNegativeArrowVisible();
    var55.setAutoRangeStickyZero(false);
    java.awt.Stroke var59 = var55.getTickMarkStroke();
    var51.setSeriesOutlineStroke(1, var59, false);
    var46.setSeriesOutlineStroke(0, var59, false);
    var46.setBaseSeriesVisible(false);
    var46.setBaseCreateEntities(true);
    int var68 = var46.getRowCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var70 = null;
    var46.setSeriesItemLabelGenerator(4, var70, true);
    java.awt.Paint var73 = var46.getBaseItemLabelPaint();
    var40.setTickLabelPaint(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    int var1 = var0.size();
    java.lang.Boolean var3 = var0.getBoolean(5);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    var4.setHeight(100.0d);
    boolean var7 = var4.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var9 = var8.getErrorIndicatorPaint();
    var4.setPaint(var9);
    java.awt.Paint var11 = var4.getBackgroundPaint();
    boolean var12 = var0.equals((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var3 = var2.getErrorIndicatorPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("Category Plot", var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    var0.setMax((-1.0d));

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var10 = var8.valueToString(0.0d);
    var1.setTickUnit(var8);
    org.jfree.chart.JFreeChart var12 = null;
    org.jfree.chart.event.ChartProgressEvent var15 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var12, (-1), 10);
    var1.setPositiveArrowVisible(true);
    var1.resizeRange(6.0d, 0.0d);
    org.jfree.data.Range var21 = var1.getRange();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var24 = var23.isNegativeArrowVisible();
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    int var30 = var29.getColumnCount();
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var29.setSeriesShape(100, var34, false);
    org.jfree.chart.entity.CategoryLabelEntity var39 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var34, "", "0");
    java.awt.Shape var40 = var39.getArea();
    boolean var41 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var27, (java.lang.Object)var40);
    var23.setDownArrow(var40);
    var1.setDownArrow(var40);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    boolean var53 = var48.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
    int var55 = var54.getColumnCount();
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var59 = var58.isNegativeArrowVisible();
    var58.setAutoRangeStickyZero(false);
    java.awt.Stroke var62 = var58.getTickMarkStroke();
    var54.setSeriesOutlineStroke(1, var62, false);
    boolean var66 = var54.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
    var68.zoomRange((-1.0d), 0.0d);
    boolean var72 = var68.isPositiveArrowVisible();
    java.awt.Paint var73 = var68.getAxisLinePaint();
    var54.setBasePaint(var73);
    org.jfree.chart.labels.CategoryToolTipGenerator var75 = null;
    var54.setBaseToolTipGenerator(var75);
    org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot(var44, var46, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var54);
    var77.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var80 = null;
    var77.markerChanged(var80);
    org.jfree.chart.util.SortOrder var82 = var77.getRowRenderingOrder();
    var77.setRangeGridlinesVisible(false);
    org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var86 = var85.getBackgroundPaint();
    java.awt.Paint var87 = var85.getPaint();
    var77.setDomainGridlinePaint(var87);
    org.jfree.chart.title.LegendGraphic var89 = new org.jfree.chart.title.LegendGraphic(var40, var87);
    org.jfree.chart.title.TextTitle var90 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var91 = var90.getBackgroundPaint();
    java.awt.Paint var92 = var90.getPaint();
    org.jfree.data.general.Dataset var93 = null;
    org.jfree.data.general.DatasetChangeEvent var94 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var92, var93);
    var89.setOutlinePaint(var92);
    org.jfree.chart.util.RectangleAnchor var96 = var89.getShapeLocation();
    java.awt.Stroke var97 = var89.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "0"+ "'", var10.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var97);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    org.jfree.chart.annotations.CategoryAnnotation var8 = null;
    boolean var9 = var0.removeAnnotation(var8);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getBaseNegativeItemLabelPosition();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.Range var3 = new org.jfree.data.Range(0.0d, 0.0d);
    double var4 = var3.getLowerBound();
    double var5 = var3.getLowerBound();
    org.jfree.data.Range var8 = org.jfree.data.Range.expand(var3, 1.0d, 6.0d);
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(2.0d, var3);
    org.jfree.data.Range var10 = var9.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var2 = null;
//     var1.addChangeListener(var2);
//     java.awt.Shape var4 = var1.getRightArrow();
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var7 = var6.getColumnCount();
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var6.setSeriesShape(100, var11, false);
//     org.jfree.chart.entity.CategoryLabelEntity var16 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var11, "", "0");
//     boolean var17 = org.jfree.chart.util.ShapeUtilities.equal(var4, var11);
//     org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4);
//     org.jfree.chart.event.ChartChangeEventType var19 = var18.getType();
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     boolean var29 = var24.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var31 = var30.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var35 = var34.isNegativeArrowVisible();
//     var34.setAutoRangeStickyZero(false);
//     java.awt.Stroke var38 = var34.getTickMarkStroke();
//     var30.setSeriesOutlineStroke(1, var38, false);
//     boolean var42 = var30.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var44.zoomRange((-1.0d), 0.0d);
//     boolean var48 = var44.isPositiveArrowVisible();
//     java.awt.Paint var49 = var44.getAxisLinePaint();
//     var30.setBasePaint(var49);
//     org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
//     var30.setBaseToolTipGenerator(var51);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
//     var53.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var56 = null;
//     var53.markerChanged(var56);
//     boolean var58 = var53.isOutlineVisible();
//     org.jfree.chart.event.MarkerChangeEvent var59 = null;
//     var53.markerChanged(var59);
//     org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var62 = var61.getColumnCount();
//     var61.setBaseSeriesVisible(false);
//     var61.setBaseSeriesVisible(true);
//     var53.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var61, true);
//     org.jfree.chart.axis.AxisLocation var70 = var53.getRangeAxisLocation(100);
//     boolean var71 = var53.isRangeCrosshairLockedOnData();
//     boolean var72 = var19.equals((java.lang.Object)var71);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var61 and var6.", var61.equals(var6) == var6.equals(var61));
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.ChartColor var4 = new org.jfree.chart.ChartColor(4, 1, 100);
    java.awt.Color var5 = var4.brighter();
    java.awt.Color var6 = java.awt.Color.getColor("1", var5);
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle();
    var7.setHeight(100.0d);
    boolean var10 = var7.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var12 = var11.getErrorIndicatorPaint();
    var7.setPaint(var12);
    org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(4, 1, 100);
    var7.setBackgroundPaint((java.awt.Paint)var17);
    java.awt.color.ColorSpace var19 = var17.getColorSpace();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    var53.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var56 = null;
    var53.markerChanged(var56);
    boolean var58 = var53.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var59 = var53.getLegendItems();
    org.jfree.chart.ChartColor var63 = new org.jfree.chart.ChartColor(4, 1, 100);
    var53.setNoDataMessagePaint((java.awt.Paint)var63);
    float[] var65 = null;
    float[] var66 = var63.getRGBColorComponents(var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var67 = var5.getComponents(var19, var66);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
//     org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
//     java.awt.Paint var4 = var1.getLabelPaint();
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     var5.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.labels.ItemLabelPosition var8 = null;
//     var5.setPositiveItemLabelPositionFallback(var8);
//     org.jfree.chart.labels.ItemLabelPosition var10 = var5.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var12.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var16 = var15.getBackgroundPaint();
//     java.awt.Paint var17 = var15.getPaint();
//     var12.setTickLabelPaint(var17);
//     var5.setBaseOutlinePaint(var17, false);
//     var1.setLabelPaint(var17);
//     org.jfree.chart.text.TextBlock var23 = null;
//     org.jfree.chart.text.TextBlockAnchor var24 = null;
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var27 = var26.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var29 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var23, var24, var27, 0.0d);
//     org.jfree.chart.text.TextAnchor var30 = var29.getRotationAnchor();
//     var1.setLabelTextAnchor(var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var26
//     assertTrue("Contract failed: equals-hashcode on var1 and var26", var1.equals(var26) ? var1.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var1
//     assertTrue("Contract failed: equals-hashcode on var26 and var1", var26.equals(var1) ? var26.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    var10.zoomRange((-1.0d), 0.0d);
    boolean var14 = var10.isPositiveArrowVisible();
    boolean var15 = var10.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var10.valueToJava2D(4.0d, var17, var18);
    var10.setTickMarkInsideLength(0.0f);
    var10.setAutoRange(true);
    org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Paint var26 = var25.getPaint();
    var10.setAxisLinePaint(var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-33), var26, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    var22.zoomRange((-1.0d), 0.0d);
    boolean var26 = var22.isPositiveArrowVisible();
    boolean var27 = var22.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var28.setBaseToolTipGenerator(var49);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var18, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    var0.setPlot(var51);
    org.jfree.chart.axis.AxisLocation var54 = var51.getRangeAxisLocation(4);
    org.jfree.chart.ChartRenderingInfo var56 = null;
    org.jfree.chart.plot.PlotRenderingInfo var57 = new org.jfree.chart.plot.PlotRenderingInfo(var56);
    org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
    int var59 = var58.getColumnCount();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var63 = var62.isNegativeArrowVisible();
    var62.setAutoRangeStickyZero(false);
    java.awt.Stroke var66 = var62.getTickMarkStroke();
    var58.setSeriesOutlineStroke(1, var66, false);
    boolean var70 = var58.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("hi!");
    var72.zoomRange((-1.0d), 0.0d);
    boolean var76 = var72.isPositiveArrowVisible();
    java.awt.Paint var77 = var72.getAxisLinePaint();
    var58.setBasePaint(var77);
    boolean var79 = var57.equals((java.lang.Object)var77);
    org.jfree.chart.renderer.RendererState var80 = new org.jfree.chart.renderer.RendererState(var57);
    java.awt.geom.Point2D var81 = null;
    var51.zoomDomainAxes(11.05d, var57, var81);
    org.jfree.chart.renderer.category.CategoryItemRendererState var83 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var57);
    org.jfree.chart.plot.PlotRenderingInfo var84 = var83.getInfo();
    double var85 = var83.getSeriesRunningTotal();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0.0d);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    var0.setBaseCreateEntities(true);
    int var22 = var0.getRowCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var24 = null;
    var0.setSeriesItemLabelGenerator(4, var24, true);
    java.awt.Paint var27 = var0.getBaseItemLabelPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = var0.getBaseToolTipGenerator();
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = var0.getToolTipGenerator((-16777216), (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setMaximumCategoryLabelWidthRatio(2.0f);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 11.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var41 = var40.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryAxis[] var42 = new org.jfree.chart.axis.CategoryAxis[] { var40};
    var33.setDomainAxes(var42);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var50.setMaximumCategoryLabelLines(0);
    org.jfree.chart.util.RectangleInsets var53 = var50.getLabelInsets();
    org.jfree.chart.ChartRenderingInfo var54 = null;
    org.jfree.chart.plot.PlotRenderingInfo var55 = new org.jfree.chart.plot.PlotRenderingInfo(var54);
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    int var57 = var56.getColumnCount();
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var61 = var60.isNegativeArrowVisible();
    var60.setAutoRangeStickyZero(false);
    java.awt.Stroke var64 = var60.getTickMarkStroke();
    var56.setSeriesOutlineStroke(1, var64, false);
    boolean var68 = var56.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis("hi!");
    var70.zoomRange((-1.0d), 0.0d);
    boolean var74 = var70.isPositiveArrowVisible();
    java.awt.Paint var75 = var70.getAxisLinePaint();
    var56.setBasePaint(var75);
    boolean var77 = var55.equals((java.lang.Object)var75);
    org.jfree.chart.renderer.RendererState var78 = new org.jfree.chart.renderer.RendererState(var55);
    java.awt.geom.Rectangle2D var79 = var55.getDataArea();
    java.awt.geom.Rectangle2D var80 = var53.createInsetRectangle(var79);
    java.awt.geom.Point2D var81 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.2d, 0.05d, var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.zoomRangeAxes(11.05d, 6.0d, var46, var81);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    boolean var12 = var0.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    var14.zoomRange((-1.0d), 0.0d);
    boolean var18 = var14.isPositiveArrowVisible();
    java.awt.Paint var19 = var14.getAxisLinePaint();
    var0.setBasePaint(var19);
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var0.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi!");
    var28.zoomRange((-1.0d), 0.0d);
    boolean var32 = var28.isPositiveArrowVisible();
    boolean var33 = var28.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    int var35 = var34.getColumnCount();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var39 = var38.isNegativeArrowVisible();
    var38.setAutoRangeStickyZero(false);
    java.awt.Stroke var42 = var38.getTickMarkStroke();
    var34.setSeriesOutlineStroke(1, var42, false);
    boolean var46 = var34.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
    var48.zoomRange((-1.0d), 0.0d);
    boolean var52 = var48.isPositiveArrowVisible();
    java.awt.Paint var53 = var48.getAxisLinePaint();
    var34.setBasePaint(var53);
    org.jfree.chart.labels.CategoryToolTipGenerator var55 = null;
    var34.setBaseToolTipGenerator(var55);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot(var24, var26, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    var57.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var60 = null;
    var57.markerChanged(var60);
    org.jfree.chart.util.SortOrder var62 = var57.getRowRenderingOrder();
    boolean var63 = var0.hasListener((java.util.EventListener)var57);
    org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var65.setMaximumCategoryLabelLines(0);
    org.jfree.chart.JFreeChart var68 = null;
    org.jfree.chart.event.ChartProgressEvent var71 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var65, var68, 10, 100);
    java.awt.Font var72 = var65.getLabelFont();
    int var73 = var57.getDomainAxisIndex(var65);
    var65.setMaximumCategoryLabelLines((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == (-1));

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var1.set(4, (java.lang.Object)10.0d);
    var0.addObject((java.lang.Object)10.0d, (java.lang.Comparable)0.0f, (java.lang.Comparable)Double.POSITIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((java.lang.Comparable)(byte)1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    int var6 = var5.getColumnCount();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var10 = var9.isNegativeArrowVisible();
    var9.setAutoRangeStickyZero(false);
    java.awt.Stroke var13 = var9.getTickMarkStroke();
    var5.setSeriesOutlineStroke(1, var13, false);
    var0.setSeriesOutlineStroke(0, var13, false);
    var0.setBaseSeriesVisible(false);
    java.awt.Shape var21 = var0.getSeriesShape(0);
    java.awt.Stroke var23 = var0.getSeriesStroke(100);
    boolean var24 = var0.getAutoPopulateSeriesShape();
    org.jfree.chart.labels.CategoryToolTipGenerator var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-1), var26, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("ChartChangeEventType.GENERAL", var1);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBasePositiveItemLabelPosition();
    double var4 = var0.getMinimumBarLength();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-16777216), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var4 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var1, "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=0.0]", "CategoryLabelEntity: category=false, tooltip=, url=0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var1.set(4, (java.lang.Object)10.0d);
    var0.addObject((java.lang.Object)10.0d, (java.lang.Comparable)0.0f, (java.lang.Comparable)Double.POSITIVE_INFINITY);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((java.lang.Comparable)(byte)100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("CategoryAnchor.MIDDLE", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLabelOffset();
    java.awt.Paint var4 = var1.getLabelPaint();
    java.awt.Stroke var5 = var1.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var5 = var4.isNegativeArrowVisible();
    var4.setAutoRangeStickyZero(false);
    java.awt.Stroke var8 = var4.getTickMarkStroke();
    var0.setSeriesOutlineStroke(1, var8, false);
    java.awt.Font var12 = var0.getSeriesItemLabelFont(100);
    var0.setBaseSeriesVisible(false, false);
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var5 = var4.getMarkerBand();
    boolean var6 = var0.equals((java.lang.Object)var4);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.axis.AxisState var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    java.util.List var11 = var4.refreshTicks(var7, var8, var9, var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    boolean var21 = var16.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var27 = var26.isNegativeArrowVisible();
    var26.setAutoRangeStickyZero(false);
    java.awt.Stroke var30 = var26.getTickMarkStroke();
    var22.setSeriesOutlineStroke(1, var30, false);
    boolean var34 = var22.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    var36.zoomRange((-1.0d), 0.0d);
    boolean var40 = var36.isPositiveArrowVisible();
    java.awt.Paint var41 = var36.getAxisLinePaint();
    var22.setBasePaint(var41);
    org.jfree.chart.labels.CategoryToolTipGenerator var43 = null;
    var22.setBaseToolTipGenerator(var43);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var12, var14, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    org.jfree.chart.ChartRenderingInfo var48 = null;
    org.jfree.chart.plot.PlotRenderingInfo var49 = new org.jfree.chart.plot.PlotRenderingInfo(var48);
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    boolean var62 = var50.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    java.awt.Paint var69 = var64.getAxisLinePaint();
    var50.setBasePaint(var69);
    boolean var71 = var49.equals((java.lang.Object)var69);
    var45.handleClick(0, 100, var49);
    java.awt.Stroke var73 = var45.getOutlineStroke();
    var4.setAxisLineStroke(var73);
    org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var77 = null;
    var76.addChangeListener(var77);
    java.awt.Shape var79 = var76.getRightArrow();
    var4.setRightArrow(var79);
    org.jfree.chart.entity.LegendItemEntity var81 = new org.jfree.chart.entity.LegendItemEntity(var79);
    java.lang.Comparable var82 = null;
    var81.setSeriesKey(var82);
    java.lang.Comparable var84 = var81.getSeriesKey();
    java.lang.Object var85 = var81.clone();
    java.awt.Shape var87 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var81.setArea(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var1 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getColumnKey((-16580609));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    java.awt.Font var3 = var0.getFont();
    org.jfree.chart.util.HorizontalAlignment var4 = var0.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement(var4, var5, 6.0d, (-1.0d));
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.general.DatasetGroup var10 = var9.getGroup();
    var9.validateObject();
    org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var8, (org.jfree.data.general.Dataset)var9, (java.lang.Comparable)1.0f);
    org.jfree.chart.block.FlowArrangement var14 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var14);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
    var18.setWidth(0.0d);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.axis.MarkerAxisBand var23 = var22.getMarkerBand();
    boolean var24 = var18.equals((java.lang.Object)var22);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.axis.AxisState var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    java.util.List var29 = var22.refreshTicks(var25, var26, var27, var28);
    org.jfree.data.Range var30 = var22.getRange();
    org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(0.0d, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var32 = var8.arrange(var15, var16, var31);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    boolean var1 = var0.getAutoPopulateSeriesStroke();
    org.jfree.chart.annotations.CategoryAnnotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var0.setSeriesShape(100, var5, false);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    int var10 = var9.getColumnCount();
    java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var9.setSeriesShape(100, var14, false);
    var0.setSeriesShape(1, var14);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    var22.zoomRange((-1.0d), 0.0d);
    boolean var26 = var22.isPositiveArrowVisible();
    boolean var27 = var22.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    int var29 = var28.getColumnCount();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var33 = var32.isNegativeArrowVisible();
    var32.setAutoRangeStickyZero(false);
    java.awt.Stroke var36 = var32.getTickMarkStroke();
    var28.setSeriesOutlineStroke(1, var36, false);
    boolean var40 = var28.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    var42.zoomRange((-1.0d), 0.0d);
    boolean var46 = var42.isPositiveArrowVisible();
    java.awt.Paint var47 = var42.getAxisLinePaint();
    var28.setBasePaint(var47);
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var28.setBaseToolTipGenerator(var49);
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var18, var20, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    var0.setPlot(var51);
    org.jfree.chart.axis.AxisLocation var54 = var51.getRangeAxisLocation(4);
    org.jfree.chart.ChartRenderingInfo var56 = null;
    org.jfree.chart.plot.PlotRenderingInfo var57 = new org.jfree.chart.plot.PlotRenderingInfo(var56);
    org.jfree.chart.renderer.category.BarRenderer var58 = new org.jfree.chart.renderer.category.BarRenderer();
    int var59 = var58.getColumnCount();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var63 = var62.isNegativeArrowVisible();
    var62.setAutoRangeStickyZero(false);
    java.awt.Stroke var66 = var62.getTickMarkStroke();
    var58.setSeriesOutlineStroke(1, var66, false);
    boolean var70 = var58.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("hi!");
    var72.zoomRange((-1.0d), 0.0d);
    boolean var76 = var72.isPositiveArrowVisible();
    java.awt.Paint var77 = var72.getAxisLinePaint();
    var58.setBasePaint(var77);
    boolean var79 = var57.equals((java.lang.Object)var77);
    org.jfree.chart.renderer.RendererState var80 = new org.jfree.chart.renderer.RendererState(var57);
    java.awt.geom.Point2D var81 = null;
    var51.zoomDomainAxes(11.05d, var57, var81);
    org.jfree.chart.axis.AxisLocation var84 = null;
    var51.setRangeAxisLocation(1, var84);
    java.lang.String var86 = var51.getPlotType();
    var51.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.CategoryMarker var89 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var51.addDomainMarker(var89);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + "Category Plot"+ "'", var86.equals("Category Plot"));

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    int var2 = var1.getColumnCount();
    var1.setBaseSeriesVisible(false);
    var1.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    int var9 = var8.getColumnCount();
    var8.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = null;
    var8.setSeriesNegativeItemLabelPosition(100, var13, true);
    var8.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    int var23 = var22.getColumnCount();
    var22.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    int var28 = var27.getColumnCount();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var32 = var31.isNegativeArrowVisible();
    var31.setAutoRangeStickyZero(false);
    java.awt.Stroke var35 = var31.getTickMarkStroke();
    var27.setSeriesOutlineStroke(1, var35, false);
    var22.setSeriesOutlineStroke(0, var35, false);
    var21.setAxisLineStroke(var35);
    var8.setBaseStroke(var35, true);
    var1.setSeriesOutlineStroke(0, var35, true);
    org.jfree.chart.block.FlowArrangement var45 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var46 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var45);
    org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var48 = null;
    boolean var49 = var47.equals(var48);
    org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var1, (org.jfree.chart.block.Arrangement)var45, (org.jfree.chart.block.Arrangement)var47);
    java.awt.Font var51 = var50.getItemFont();
    java.awt.Font var52 = var50.getItemFont();
    java.awt.Paint var53 = var50.getBackgroundPaint();
    java.lang.Object var54 = null;
    var0.add((org.jfree.chart.block.Block)var50, var54);
    org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle();
    double var57 = var56.getContentXOffset();
    java.lang.Object var58 = var56.clone();
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var61 = null;
    var60.addChangeListener(var61);
    java.awt.Shape var63 = var60.getRightArrow();
    org.jfree.chart.renderer.category.BarRenderer var65 = new org.jfree.chart.renderer.category.BarRenderer();
    int var66 = var65.getColumnCount();
    java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var65.setSeriesShape(100, var70, false);
    org.jfree.chart.entity.CategoryLabelEntity var75 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var70, "", "0");
    boolean var76 = org.jfree.chart.util.ShapeUtilities.equal(var63, var70);
    org.jfree.chart.event.ChartChangeEvent var77 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var63);
    org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var80 = null;
    var79.addChangeListener(var80);
    java.awt.Shape var82 = var79.getRightArrow();
    org.jfree.chart.renderer.category.BarRenderer var84 = new org.jfree.chart.renderer.category.BarRenderer();
    int var85 = var84.getColumnCount();
    java.awt.Shape var89 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var84.setSeriesShape(100, var89, false);
    org.jfree.chart.entity.CategoryLabelEntity var94 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var89, "", "0");
    boolean var95 = org.jfree.chart.util.ShapeUtilities.equal(var82, var89);
    org.jfree.chart.event.ChartChangeEvent var96 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var82);
    org.jfree.chart.event.ChartChangeEventType var97 = var96.getType();
    var77.setType(var97);
    var0.add((org.jfree.chart.block.Block)var56, (java.lang.Object)var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    org.jfree.chart.annotations.CategoryAnnotation var8 = null;
    boolean var9 = var0.removeAnnotation(var8);
    var0.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getBaseNegativeItemLabelPosition();
    var0.setDrawBarOutline(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Number var42 = var0.getValue((java.lang.Comparable)1.0d, (java.lang.Comparable)(short)10);
    org.jfree.data.Range var43 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 0);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var9 = var8.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryTick var11 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var5, var6, var9, 0.0d);
//     java.lang.Comparable var12 = var11.getCategory();
//     org.jfree.chart.text.TextAnchor var13 = var11.getTextAnchor();
//     java.awt.geom.Rectangle2D var14 = org.jfree.chart.text.TextUtilities.drawAlignedString("[size=10]", var1, 1.0f, 2.0f, var13);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    java.awt.Paint var6 = var1.getAxisLinePaint();
    org.jfree.chart.axis.NumberTickUnit var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var7, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.event.AxisChangeListener var4 = null;
//     var3.addChangeListener(var4);
//     java.awt.Shape var6 = var3.getRightArrow();
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var9 = var8.getColumnCount();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var8.setSeriesShape(100, var13, false);
//     org.jfree.chart.entity.CategoryLabelEntity var18 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var13, "", "0");
//     boolean var19 = org.jfree.chart.util.ShapeUtilities.equal(var6, var13);
//     java.awt.GradientPaint var20 = var0.transform(var1, var6);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.2d);
    var1.setValue(0.2d);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    var4.setHeight(100.0d);
    org.jfree.chart.util.RectangleInsets var11 = new org.jfree.chart.util.RectangleInsets(10.0d, (-1.0d), 10.0d, (-1.0d));
    var4.setMargin(var11);
    var1.setLabelOffset(var11);
    double var15 = var11.calculateBottomInset((-20.0d));
    double var17 = var11.calculateRightOutset(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1.0d));

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    var0.add((org.jfree.chart.block.Block)var1, (java.lang.Object)var2);
    org.jfree.chart.plot.DrawingSupplier var4 = var2.getDrawingSupplier();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.setMaximumCategoryLabelLines(0);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.Paint var11 = var9.getPaint();
    var6.setTickLabelPaint(var11);
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    int var14 = var13.getColumnCount();
    var13.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var13.setSeriesNegativeItemLabelPosition(100, var18, true);
    var13.setSeriesVisible(100, (java.lang.Boolean)false, true);
    boolean var27 = var13.isItemLabelVisible(10, 1);
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
    var32.zoomRange((-1.0d), 0.0d);
    boolean var36 = var32.isPositiveArrowVisible();
    boolean var37 = var32.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    int var39 = var38.getColumnCount();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var43 = var42.isNegativeArrowVisible();
    var42.setAutoRangeStickyZero(false);
    java.awt.Stroke var46 = var42.getTickMarkStroke();
    var38.setSeriesOutlineStroke(1, var46, false);
    boolean var50 = var38.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis("hi!");
    var52.zoomRange((-1.0d), 0.0d);
    boolean var56 = var52.isPositiveArrowVisible();
    java.awt.Paint var57 = var52.getAxisLinePaint();
    var38.setBasePaint(var57);
    org.jfree.chart.labels.CategoryToolTipGenerator var59 = null;
    var38.setBaseToolTipGenerator(var59);
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var28, var30, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
    var61.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var64 = null;
    var61.markerChanged(var64);
    org.jfree.chart.util.SortOrder var66 = var61.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var67 = new org.jfree.data.KeyedObjects();
    java.lang.Object var69 = var67.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var70 = null;
    org.jfree.chart.event.ChartProgressEvent var73 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var67, var70, 0, 0);
    boolean var74 = var61.equals((java.lang.Object)var70);
    java.awt.Paint var75 = var61.getOutlinePaint();
    var13.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var61);
    var6.setPlot((org.jfree.chart.plot.Plot)var61);
    org.jfree.chart.title.TextTitle var78 = new org.jfree.chart.title.TextTitle();
    var78.setHeight(100.0d);
    java.awt.Font var81 = var78.getFont();
    var6.setTickLabelFont(var81);
    double var83 = var6.getUpperMargin();
    org.jfree.chart.axis.NumberTickUnit var85 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    java.lang.String var87 = var85.valueToString(0.0d);
    java.awt.Paint var88 = var6.getTickLabelPaint((java.lang.Comparable)0.0d);
    var2.setBaseFillPaint(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var87 + "' != '" + "0"+ "'", var87.equals("0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(11.05d, (-20.0d));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    var1.clear();
    org.jfree.chart.util.RectangleInsets var3 = var1.getMargin();
    org.jfree.chart.block.Arrangement var4 = var1.getArrangement();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var8 = null;
    var7.addChangeListener(var8);
    java.awt.Shape var10 = var7.getRightArrow();
    org.jfree.chart.event.AxisChangeListener var11 = null;
    var7.addChangeListener(var11);
    org.jfree.data.Range var15 = new org.jfree.data.Range(0.0d, 0.0d);
    var7.setDefaultAutoRange(var15);
    org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var15, 1.0d);
    org.jfree.data.Range var21 = new org.jfree.data.Range(0.0d, 0.0d);
    double var22 = var21.getLowerBound();
    double var23 = var21.getLowerBound();
    org.jfree.data.Range var26 = org.jfree.data.Range.expand(var21, 1.0d, 6.0d);
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var15, var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var28 = var0.arrange(var1, var5, var27);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    boolean var38 = var33.isOutlineVisible();
    org.jfree.chart.axis.ValueAxis var40 = null;
    var33.setRangeAxis(5, var40);
    org.jfree.chart.util.Layer var43 = null;
    java.util.Collection var44 = var33.getDomainMarkers(4, var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
    var1.clear();

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    var1.setPositiveArrowVisible(false);
    double var7 = var1.getFixedAutoRange();
    org.jfree.data.Range var8 = var1.getRange();
    double var9 = var8.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1.0d));

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var1 = var0.getBackgroundPaint();
//     java.awt.Paint var2 = var0.getPaint();
//     java.awt.Font var3 = var0.getFont();
//     org.jfree.chart.util.HorizontalAlignment var4 = var0.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var5 = null;
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement(var4, var5, 6.0d, (-1.0d));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     org.jfree.data.general.DatasetGroup var10 = var9.getGroup();
//     var9.validateObject();
//     org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var8, (org.jfree.data.general.Dataset)var9, (java.lang.Comparable)1.0f);
//     java.lang.String var14 = var13.getToolTipText();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.AxisSpace var16 = new org.jfree.chart.axis.AxisSpace();
//     var16.setBottom(10.0d);
//     var16.setTop(0.0d);
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var22 = new org.jfree.chart.plot.PlotRenderingInfo(var21);
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var24 = var23.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var28 = var27.isNegativeArrowVisible();
//     var27.setAutoRangeStickyZero(false);
//     java.awt.Stroke var31 = var27.getTickMarkStroke();
//     var23.setSeriesOutlineStroke(1, var31, false);
//     boolean var35 = var23.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var37.zoomRange((-1.0d), 0.0d);
//     boolean var41 = var37.isPositiveArrowVisible();
//     java.awt.Paint var42 = var37.getAxisLinePaint();
//     var23.setBasePaint(var42);
//     boolean var44 = var22.equals((java.lang.Object)var42);
//     org.jfree.chart.renderer.RendererState var45 = new org.jfree.chart.renderer.RendererState(var22);
//     java.awt.geom.Rectangle2D var46 = var22.getDataArea();
//     org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var48.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.util.RectangleInsets var51 = var48.getLabelInsets();
//     org.jfree.chart.ChartRenderingInfo var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = new org.jfree.chart.plot.PlotRenderingInfo(var52);
//     org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var55 = var54.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var59 = var58.isNegativeArrowVisible();
//     var58.setAutoRangeStickyZero(false);
//     java.awt.Stroke var62 = var58.getTickMarkStroke();
//     var54.setSeriesOutlineStroke(1, var62, false);
//     boolean var66 = var54.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var68.zoomRange((-1.0d), 0.0d);
//     boolean var72 = var68.isPositiveArrowVisible();
//     java.awt.Paint var73 = var68.getAxisLinePaint();
//     var54.setBasePaint(var73);
//     boolean var75 = var53.equals((java.lang.Object)var73);
//     org.jfree.chart.renderer.RendererState var76 = new org.jfree.chart.renderer.RendererState(var53);
//     java.awt.geom.Rectangle2D var77 = var53.getDataArea();
//     java.awt.geom.Rectangle2D var78 = var51.createInsetRectangle(var77);
//     java.awt.geom.Rectangle2D var79 = var16.expand(var46, var77);
//     var13.draw(var15, var79);
// 
//   }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemLabelGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var0.getBasePositiveItemLabelPosition();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     var5.setValue(0.2d);
//     org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var9 = var8.getColumnCount();
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var8.setSeriesShape(100, var13, false);
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var18 = var17.getColumnCount();
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var17.setSeriesShape(100, var22, false);
//     var8.setSeriesShape(1, var22);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var30.zoomRange((-1.0d), 0.0d);
//     boolean var34 = var30.isPositiveArrowVisible();
//     boolean var35 = var30.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var37 = var36.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var41 = var40.isNegativeArrowVisible();
//     var40.setAutoRangeStickyZero(false);
//     java.awt.Stroke var44 = var40.getTickMarkStroke();
//     var36.setSeriesOutlineStroke(1, var44, false);
//     boolean var48 = var36.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var50.zoomRange((-1.0d), 0.0d);
//     boolean var54 = var50.isPositiveArrowVisible();
//     java.awt.Paint var55 = var50.getAxisLinePaint();
//     var36.setBasePaint(var55);
//     org.jfree.chart.labels.CategoryToolTipGenerator var57 = null;
//     var36.setBaseToolTipGenerator(var57);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var26, var28, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     var8.setPlot(var59);
//     org.jfree.chart.axis.AxisLocation var62 = var59.getRangeAxisLocation(4);
//     var5.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var59);
//     boolean var64 = var3.equals((java.lang.Object)var5);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var8.", var0.equals(var8) == var8.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var17.", var0.equals(var17) == var17.equals(var0));
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var2 = var1.isNegativeArrowVisible();
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var5 = var4.getColumnCount();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var4.setSeriesShape(100, var9, false);
//     org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
//     var1.setRightArrow(var9);
//     boolean var16 = var1.getAutoRangeIncludesZero();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var22 = var21.isNegativeArrowVisible();
//     var21.setAutoRangeStickyZero(false);
//     java.awt.Stroke var25 = var21.getTickMarkStroke();
//     var21.setAutoRangeMinimumSize(100.0d);
//     var18.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var21, false);
//     double var30 = var18.getRangeCrosshairValue();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var34 = var33.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var38 = var37.isNegativeArrowVisible();
//     var37.setAutoRangeStickyZero(false);
//     java.awt.Stroke var41 = var37.getTickMarkStroke();
//     var33.setSeriesOutlineStroke(1, var41, false);
//     boolean var45 = var33.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var47.zoomRange((-1.0d), 0.0d);
//     boolean var51 = var47.isPositiveArrowVisible();
//     java.awt.Paint var52 = var47.getAxisLinePaint();
//     var33.setBasePaint(var52);
//     boolean var54 = var32.equals((java.lang.Object)var52);
//     org.jfree.chart.renderer.RendererState var55 = new org.jfree.chart.renderer.RendererState(var32);
//     java.awt.geom.Rectangle2D var56 = var32.getDataArea();
//     java.awt.geom.Rectangle2D var57 = var32.getDataArea();
//     org.jfree.chart.title.TextTitle var58 = new org.jfree.chart.title.TextTitle();
//     var58.setHeight(100.0d);
//     boolean var61 = var58.getNotify();
//     org.jfree.chart.event.TitleChangeListener var62 = null;
//     var58.removeChangeListener(var62);
//     org.jfree.chart.util.RectangleEdge var64 = var58.getPosition();
//     org.jfree.chart.axis.AxisSpace var65 = new org.jfree.chart.axis.AxisSpace();
//     var65.setBottom(10.0d);
//     java.lang.String var68 = var65.toString();
//     java.lang.String var69 = var65.toString();
//     org.jfree.chart.axis.AxisSpace var70 = var1.reserveSpace(var17, (org.jfree.chart.plot.Plot)var18, var57, var64, var65);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    org.jfree.data.Range var39 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    boolean var40 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setBottom(0.05d);
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.event.ChartChangeEvent var4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    var0.setSeriesNegativeItemLabelPosition(100, var5, true);
    var0.setBaseCreateEntities(true, true);
    java.awt.Paint var12 = var0.getSeriesItemLabelPaint(0);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    var13.setHeight(100.0d);
    boolean var16 = var13.getNotify();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var17 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Paint var18 = var17.getErrorIndicatorPaint();
    var13.setPaint(var18);
    org.jfree.chart.ChartColor var23 = new org.jfree.chart.ChartColor(4, 1, 100);
    var13.setBackgroundPaint((java.awt.Paint)var23);
    var0.setBaseFillPaint((java.awt.Paint)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=false, tooltip=, url=0");
//     java.awt.Font var2 = var1.getFont();
//     org.jfree.data.Range var3 = null;
//     org.jfree.data.Range var4 = null;
//     org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(var3, var4);
//     org.jfree.chart.block.RectangleConstraint var6 = var5.toUnconstrainedWidth();
//     org.jfree.chart.block.RectangleConstraint var7 = var5.toUnconstrainedWidth();
//     boolean var8 = var1.equals((java.lang.Object)var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var14 = var13.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var16 = var15.getColumnCount();
//     var15.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var19 = var15.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var20 = var19.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var22 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0d, "0", var14, var20, Double.POSITIVE_INFINITY);
//     float var23 = var1.calculateBaselineOffset(var9, var20);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.chart.util.SortOrder var38 = var33.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    int var41 = var40.getCategoryLabelPositionOffset();
    int var42 = var33.getDomainAxisIndex(var40);
    float var43 = var40.getMaximumCategoryLabelWidthRatio();
    var40.setLabelAngle(100.0d);
    java.awt.Paint var46 = var40.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "1", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", "", "AxisLocation.BOTTOM_OR_LEFT");
    var5.addOptionalLibrary("1");
    var5.setInfo("");
    java.lang.String var10 = var5.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    int var5 = var4.getColumnCount();
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var4.setSeriesShape(100, var9, false);
    org.jfree.chart.entity.CategoryLabelEntity var14 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var9, "", "0");
    java.awt.Shape var15 = var14.getArea();
    boolean var16 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var2, (java.lang.Object)var15);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    boolean var29 = var24.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
    int var31 = var30.getColumnCount();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var35 = var34.isNegativeArrowVisible();
    var34.setAutoRangeStickyZero(false);
    java.awt.Stroke var38 = var34.getTickMarkStroke();
    var30.setSeriesOutlineStroke(1, var38, false);
    boolean var42 = var30.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    java.awt.Paint var49 = var44.getAxisLinePaint();
    var30.setBasePaint(var49);
    org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
    var30.setBaseToolTipGenerator(var51);
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var20, var22, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var54 = var53.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var53.getRenderer(1);
    boolean var57 = var19.hasListener((java.util.EventListener)var53);
    java.lang.Comparable var59 = null;
    org.jfree.chart.entity.CategoryItemEntity var60 = new org.jfree.chart.entity.CategoryItemEntity(var15, "poly", "-10,10,-10,10,-10,10,10,10,10,10,10,10,10,-10,10,-10,10,-10,-10,-10,-10,-10,-10,-10,-10,-10", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)(-1.0f), var59);
    org.jfree.data.category.CategoryDataset var61 = var60.getDataset();
    var60.setColumnKey((java.lang.Comparable)0.0f);
    java.lang.String var64 = var60.toString();
    java.lang.Object var65 = var60.clone();
    java.awt.Shape var66 = var60.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var0);
    org.jfree.chart.title.Title var2 = var1.getTitle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Paint var3 = var0.getItemOutlinePaint(4, 10);
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var5 = var4.getColumnCount();
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var4.setSeriesShape(100, var9, false);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var14 = var13.getColumnCount();
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
//     var13.setSeriesShape(100, var18, false);
//     var4.setSeriesShape(1, var18);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var26.zoomRange((-1.0d), 0.0d);
//     boolean var30 = var26.isPositiveArrowVisible();
//     boolean var31 = var26.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var33 = var32.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var37 = var36.isNegativeArrowVisible();
//     var36.setAutoRangeStickyZero(false);
//     java.awt.Stroke var40 = var36.getTickMarkStroke();
//     var32.setSeriesOutlineStroke(1, var40, false);
//     boolean var44 = var32.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var46.zoomRange((-1.0d), 0.0d);
//     boolean var50 = var46.isPositiveArrowVisible();
//     java.awt.Paint var51 = var46.getAxisLinePaint();
//     var32.setBasePaint(var51);
//     org.jfree.chart.labels.CategoryToolTipGenerator var53 = null;
//     var32.setBaseToolTipGenerator(var53);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var22, var24, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
//     var4.setPlot(var55);
//     org.jfree.chart.axis.AxisLocation var58 = var55.getRangeAxisLocation(4);
//     org.jfree.chart.ChartRenderingInfo var60 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var61 = new org.jfree.chart.plot.PlotRenderingInfo(var60);
//     org.jfree.chart.renderer.category.BarRenderer var62 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var63 = var62.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var67 = var66.isNegativeArrowVisible();
//     var66.setAutoRangeStickyZero(false);
//     java.awt.Stroke var70 = var66.getTickMarkStroke();
//     var62.setSeriesOutlineStroke(1, var70, false);
//     boolean var74 = var62.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var76 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var76.zoomRange((-1.0d), 0.0d);
//     boolean var80 = var76.isPositiveArrowVisible();
//     java.awt.Paint var81 = var76.getAxisLinePaint();
//     var62.setBasePaint(var81);
//     boolean var83 = var61.equals((java.lang.Object)var81);
//     org.jfree.chart.renderer.RendererState var84 = new org.jfree.chart.renderer.RendererState(var61);
//     java.awt.geom.Point2D var85 = null;
//     var55.zoomDomainAxes(11.05d, var61, var85);
//     org.jfree.chart.axis.AxisLocation var88 = null;
//     var55.setRangeAxisLocation(1, var88);
//     org.jfree.chart.event.PlotChangeListener var90 = null;
//     var55.addChangeListener(var90);
//     var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var55);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var4.", var0.equals(var4) == var4.equals(var0));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var13.", var0.equals(var13) == var13.equals(var0));
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var1.valueToJava2D(4.0d, var8, var9);
    var1.setTickMarkInsideLength(0.0f);
    boolean var13 = var1.isAxisLineVisible();
    var1.setRangeAboutValue(Double.POSITIVE_INFINITY, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var6 = var5.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var10 = var9.isNegativeArrowVisible();
//     var9.setAutoRangeStickyZero(false);
//     java.awt.Stroke var13 = var9.getTickMarkStroke();
//     var5.setSeriesOutlineStroke(1, var13, false);
//     var0.setSeriesOutlineStroke(0, var13, false);
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseCreateEntities(true);
//     int var22 = var0.getRowCount();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var24 = null;
//     var0.setSeriesItemLabelGenerator(4, var24, true);
//     org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var28 = var27.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = var27.getLegendItemLabelGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var30 = var27.getBasePositiveItemLabelPosition();
//     var0.setNegativeItemLabelPositionFallback(var30);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var27 and var5.", var27.equals(var5) == var5.equals(var27));
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.ChartRenderingInfo var0 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var5.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.util.RectangleInsets var8 = var5.getLabelInsets();
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var12 = var11.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var16 = var15.isNegativeArrowVisible();
//     var15.setAutoRangeStickyZero(false);
//     java.awt.Stroke var19 = var15.getTickMarkStroke();
//     var11.setSeriesOutlineStroke(1, var19, false);
//     boolean var23 = var11.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var25.zoomRange((-1.0d), 0.0d);
//     boolean var29 = var25.isPositiveArrowVisible();
//     java.awt.Paint var30 = var25.getAxisLinePaint();
//     var11.setBasePaint(var30);
//     boolean var32 = var10.equals((java.lang.Object)var30);
//     org.jfree.chart.renderer.RendererState var33 = new org.jfree.chart.renderer.RendererState(var10);
//     java.awt.geom.Rectangle2D var34 = var10.getDataArea();
//     java.awt.geom.Rectangle2D var35 = var8.createInsetRectangle(var34);
//     java.awt.geom.Point2D var36 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.2d, 0.05d, var35);
//     boolean var37 = var1.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var1);
    java.lang.String var3 = var0.getGPL();

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var7 = var6.isNegativeArrowVisible();
    var6.setAutoRangeStickyZero(false);
    java.awt.Stroke var10 = var6.getTickMarkStroke();
    var2.setSeriesOutlineStroke(1, var10, false);
    boolean var14 = var2.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    var16.zoomRange((-1.0d), 0.0d);
    boolean var20 = var16.isPositiveArrowVisible();
    java.awt.Paint var21 = var16.getAxisLinePaint();
    var2.setBasePaint(var21);
    boolean var23 = var1.equals((java.lang.Object)var21);
    org.jfree.chart.renderer.RendererState var24 = new org.jfree.chart.renderer.RendererState(var1);
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var26 = var25.getBackgroundPaint();
    java.awt.Paint var27 = var25.getPaint();
    java.awt.Font var28 = var25.getFont();
    boolean var29 = var1.equals((java.lang.Object)var25);
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
    int var33 = var32.getColumnCount();
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var37 = var36.isNegativeArrowVisible();
    var36.setAutoRangeStickyZero(false);
    java.awt.Stroke var40 = var36.getTickMarkStroke();
    var32.setSeriesOutlineStroke(1, var40, false);
    boolean var44 = var32.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
    var46.zoomRange((-1.0d), 0.0d);
    boolean var50 = var46.isPositiveArrowVisible();
    java.awt.Paint var51 = var46.getAxisLinePaint();
    var32.setBasePaint(var51);
    boolean var53 = var31.equals((java.lang.Object)var51);
    org.jfree.chart.renderer.RendererState var54 = new org.jfree.chart.renderer.RendererState(var31);
    int var55 = var31.getSubplotCount();
    var1.addSubplotInfo(var31);
    org.jfree.chart.renderer.category.CategoryItemRendererState var57 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 2.0f);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextBlock var2 = null;
    org.jfree.chart.text.TextBlockAnchor var3 = null;
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var8 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)100.0f, var2, var3, var6, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var9 = new org.jfree.chart.labels.ItemLabelPosition(var0, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     var0.setBaseSeriesVisible(true, true);
//     java.awt.Paint var9 = var0.getItemOutlinePaint((-1), 0);
//     java.awt.Shape var11 = var0.getSeriesShape(0);
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     var12.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.labels.ItemLabelPosition var15 = null;
//     var12.setPositiveItemLabelPositionFallback(var15);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getBaseNegativeItemLabelPosition();
//     var0.setBaseNegativeItemLabelPosition(var17);
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getLabelOffset();
//     org.jfree.chart.util.RectangleInsets var22 = var20.getLabelOffset();
//     java.awt.Paint var23 = var20.getLabelPaint();
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     var24.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.labels.ItemLabelPosition var27 = null;
//     var24.setPositiveItemLabelPositionFallback(var27);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var24.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var31.setMaximumCategoryLabelLines(0);
//     org.jfree.chart.title.TextTitle var34 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var35 = var34.getBackgroundPaint();
//     java.awt.Paint var36 = var34.getPaint();
//     var31.setTickLabelPaint(var36);
//     var24.setBaseOutlinePaint(var36, false);
//     var20.setLabelPaint(var36);
//     org.jfree.chart.util.LengthAdjustmentType var41 = var20.getLabelOffsetType();
//     boolean var42 = var17.equals((java.lang.Object)var20);
//     
//     // Checks the contract:  equals-hashcode on var17 and var29
//     assertTrue("Contract failed: equals-hashcode on var17 and var29", var17.equals(var29) ? var17.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var17
//     assertTrue("Contract failed: equals-hashcode on var29 and var17", var29.equals(var17) ? var29.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var34.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var37 = null;
    var34.markerChanged(var37);
    boolean var39 = var34.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var40 = var34.getLegendItems();
    var0.setPlot(var34);
    org.jfree.chart.plot.DatasetRenderingOrder var42 = var34.getDatasetRenderingOrder();
    java.lang.String var43 = var42.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var43.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(11.05d);
    org.jfree.chart.text.TextBlock var3 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.2d);
    org.jfree.chart.text.TextAnchor var7 = var6.getLabelTextAnchor();
    org.jfree.chart.axis.CategoryTick var9 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"1", var3, var4, var7, 0.0d);
    java.lang.Comparable var10 = var9.getCategory();
    java.lang.String var11 = var9.toString();
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    int var13 = var12.getColumnCount();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var17 = var16.isNegativeArrowVisible();
    var16.setAutoRangeStickyZero(false);
    java.awt.Stroke var20 = var16.getTickMarkStroke();
    var12.setSeriesOutlineStroke(1, var20, false);
    boolean var24 = var12.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    var26.zoomRange((-1.0d), 0.0d);
    boolean var30 = var26.isPositiveArrowVisible();
    java.awt.Paint var31 = var26.getAxisLinePaint();
    var12.setBasePaint(var31);
    org.jfree.chart.labels.CategoryItemLabelGenerator var35 = var12.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
    var40.zoomRange((-1.0d), 0.0d);
    boolean var44 = var40.isPositiveArrowVisible();
    boolean var45 = var40.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
    int var47 = var46.getColumnCount();
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var51 = var50.isNegativeArrowVisible();
    var50.setAutoRangeStickyZero(false);
    java.awt.Stroke var54 = var50.getTickMarkStroke();
    var46.setSeriesOutlineStroke(1, var54, false);
    boolean var58 = var46.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("hi!");
    var60.zoomRange((-1.0d), 0.0d);
    boolean var64 = var60.isPositiveArrowVisible();
    java.awt.Paint var65 = var60.getAxisLinePaint();
    var46.setBasePaint(var65);
    org.jfree.chart.labels.CategoryToolTipGenerator var67 = null;
    var46.setBaseToolTipGenerator(var67);
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var36, var38, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.renderer.category.CategoryItemRenderer)var46);
    var69.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var72 = null;
    var69.markerChanged(var72);
    org.jfree.chart.util.SortOrder var74 = var69.getRowRenderingOrder();
    boolean var75 = var12.hasListener((java.util.EventListener)var69);
    org.jfree.chart.util.RectangleInsets var80 = new org.jfree.chart.util.RectangleInsets(10.0d, 1.0d, (-1.0d), 10.0d);
    double var82 = var80.calculateLeftOutset(10.0d);
    double var84 = var80.extendWidth(0.05d);
    var69.setInsets(var80);
    boolean var86 = var9.equals((java.lang.Object)var80);
    java.lang.Comparable var87 = var9.getCategory();
    java.lang.Object var88 = var9.clone();
    boolean var89 = var1.equals(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "1"+ "'", var10.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 11.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var87 + "' != '" + "1"+ "'", var87.equals("1"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.axis.AxisLocation var34 = var33.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var33.getRenderer(1);
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("hi!");
    var39.zoomRange((-1.0d), 0.0d);
    boolean var43 = var39.isPositiveArrowVisible();
    var33.setRangeAxis(4, (org.jfree.chart.axis.ValueAxis)var39, true);
    org.jfree.chart.event.AxisChangeListener var46 = null;
    var39.removeChangeListener(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.awt.Paint var2 = var0.getPaint();
    java.awt.Font var3 = var0.getFont();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    int var7 = var6.getColumnCount();
    var6.setBaseSeriesVisible(false);
    java.lang.Object var10 = var0.draw(var4, var5, (java.lang.Object)var6);
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var14 = null;
    var13.addChangeListener(var14);
    java.awt.Shape var16 = var13.getRightArrow();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var19 = null;
    var18.addChangeListener(var19);
    java.awt.Shape var21 = var18.getRightArrow();
    var13.setRightArrow(var21);
    org.jfree.chart.entity.ChartEntity var23 = new org.jfree.chart.entity.ChartEntity(var21);
    var6.setSeriesShape(5, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    var1.setLabelAngle(6.0d);
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
    var9.zoomRange((-1.0d), 0.0d);
    boolean var13 = var9.isPositiveArrowVisible();
    boolean var14 = var9.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    int var16 = var15.getColumnCount();
    org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var20 = var19.isNegativeArrowVisible();
    var19.setAutoRangeStickyZero(false);
    java.awt.Stroke var23 = var19.getTickMarkStroke();
    var15.setSeriesOutlineStroke(1, var23, false);
    boolean var27 = var15.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("hi!");
    var29.zoomRange((-1.0d), 0.0d);
    boolean var33 = var29.isPositiveArrowVisible();
    java.awt.Paint var34 = var29.getAxisLinePaint();
    var15.setBasePaint(var34);
    org.jfree.chart.labels.CategoryToolTipGenerator var36 = null;
    var15.setBaseToolTipGenerator(var36);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var5, var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    var38.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var41 = null;
    var38.markerChanged(var41);
    org.jfree.chart.util.SortOrder var43 = var38.getRowRenderingOrder();
    var38.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("hi!");
    var49.zoomRange((-1.0d), 0.0d);
    boolean var53 = var49.isPositiveArrowVisible();
    boolean var54 = var49.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    int var56 = var55.getColumnCount();
    org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var60 = var59.isNegativeArrowVisible();
    var59.setAutoRangeStickyZero(false);
    java.awt.Stroke var63 = var59.getTickMarkStroke();
    var55.setSeriesOutlineStroke(1, var63, false);
    boolean var67 = var55.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("hi!");
    var69.zoomRange((-1.0d), 0.0d);
    boolean var73 = var69.isPositiveArrowVisible();
    java.awt.Paint var74 = var69.getAxisLinePaint();
    var55.setBasePaint(var74);
    org.jfree.chart.labels.CategoryToolTipGenerator var76 = null;
    var55.setBaseToolTipGenerator(var76);
    org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot(var45, var47, (org.jfree.chart.axis.ValueAxis)var49, (org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
    var78.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var81 = null;
    var78.markerChanged(var81);
    org.jfree.chart.util.SortOrder var83 = var78.getRowRenderingOrder();
    org.jfree.data.KeyedObjects var84 = new org.jfree.data.KeyedObjects();
    java.lang.Object var86 = var84.getObject((java.lang.Comparable)1);
    org.jfree.chart.JFreeChart var87 = null;
    org.jfree.chart.event.ChartProgressEvent var90 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var84, var87, 0, 0);
    boolean var91 = var78.equals((java.lang.Object)var87);
    java.awt.Paint var92 = var78.getOutlinePaint();
    var38.setRangeGridlinePaint(var92);
    boolean var94 = var1.equals((java.lang.Object)var38);
    var1.setNegativeArrowVisible(true);
    var1.setRangeAboutValue(4.0d, 6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
    var4.zoomRange((-1.0d), 0.0d);
    boolean var8 = var4.isPositiveArrowVisible();
    boolean var9 = var4.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    int var11 = var10.getColumnCount();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var15 = var14.isNegativeArrowVisible();
    var14.setAutoRangeStickyZero(false);
    java.awt.Stroke var18 = var14.getTickMarkStroke();
    var10.setSeriesOutlineStroke(1, var18, false);
    boolean var22 = var10.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
    var24.zoomRange((-1.0d), 0.0d);
    boolean var28 = var24.isPositiveArrowVisible();
    java.awt.Paint var29 = var24.getAxisLinePaint();
    var10.setBasePaint(var29);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var10.setBaseToolTipGenerator(var31);
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    var33.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var36 = null;
    var33.markerChanged(var36);
    org.jfree.data.general.DatasetGroup var38 = var33.getDatasetGroup();
    var33.clearAnnotations();
    org.jfree.chart.annotations.CategoryAnnotation var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.addAnnotation(var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setTickMarksVisible(false);
    var1.setTickMarkInsideLength(0.0f);
    double var6 = var1.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    var50.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var64 = null;
    var50.setSeriesToolTipGenerator(1, var64);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var66 = var50.getLegendItemToolTipGenerator();
    org.jfree.chart.labels.ItemLabelPosition var69 = var50.getPositiveItemLabelPosition(10, (-1));
    var0.setPositiveItemLabelPositionFallback(var69);
    int var71 = var0.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    var34.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var37 = null;
    var34.markerChanged(var37);
    boolean var39 = var34.isOutlineVisible();
    org.jfree.chart.LegendItemCollection var40 = var34.getLegendItems();
    var0.setPlot(var34);
    org.jfree.chart.axis.ValueAxis var43 = var34.getRangeAxisForDataset(1);
    org.jfree.chart.axis.ValueAxis var45 = null;
    var34.setRangeAxis(0, var45);
    org.jfree.chart.plot.DatasetRenderingOrder var47 = var34.getDatasetRenderingOrder();
    boolean var48 = var34.isRangeGridlinesVisible();
    org.jfree.chart.annotations.CategoryAnnotation var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var50 = var34.removeAnnotation(var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("AxisLocation.BOTTOM_OR_LEFT", var1);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(10.0d);
    var0.set(4, (java.lang.Object)10.0d);
    int var5 = var0.size();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    int var7 = var6.getColumnCount();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var11 = var10.isNegativeArrowVisible();
    var10.setAutoRangeStickyZero(false);
    java.awt.Stroke var14 = var10.getTickMarkStroke();
    var6.setSeriesOutlineStroke(1, var14, false);
    boolean var18 = var6.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    var20.zoomRange((-1.0d), 0.0d);
    boolean var24 = var20.isPositiveArrowVisible();
    java.awt.Paint var25 = var20.getAxisLinePaint();
    var6.setBasePaint(var25);
    org.jfree.chart.labels.CategoryItemLabelGenerator var29 = var6.getItemLabelGenerator(0, (-1));
    org.jfree.data.category.CategoryDataset var30 = null;
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    var34.zoomRange((-1.0d), 0.0d);
    boolean var38 = var34.isPositiveArrowVisible();
    boolean var39 = var34.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var40 = new org.jfree.chart.renderer.category.BarRenderer();
    int var41 = var40.getColumnCount();
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var45 = var44.isNegativeArrowVisible();
    var44.setAutoRangeStickyZero(false);
    java.awt.Stroke var48 = var44.getTickMarkStroke();
    var40.setSeriesOutlineStroke(1, var48, false);
    boolean var52 = var40.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    var54.zoomRange((-1.0d), 0.0d);
    boolean var58 = var54.isPositiveArrowVisible();
    java.awt.Paint var59 = var54.getAxisLinePaint();
    var40.setBasePaint(var59);
    org.jfree.chart.labels.CategoryToolTipGenerator var61 = null;
    var40.setBaseToolTipGenerator(var61);
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var30, var32, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
    var63.setDomainGridlinesVisible(true);
    org.jfree.chart.event.MarkerChangeEvent var66 = null;
    var63.markerChanged(var66);
    org.jfree.chart.util.SortOrder var68 = var63.getRowRenderingOrder();
    boolean var69 = var6.hasListener((java.util.EventListener)var63);
    int var70 = var0.indexOf((java.lang.Object)var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.set((-16580609), (java.lang.Object)"poly");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == (-1));

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setRight(1.0d);
    var0.setRight(1.0d);
    java.lang.String var5 = var0.toString();
    double var6 = var0.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("");
    java.awt.Font var2 = var1.getFont();
    java.awt.Paint var3 = var1.getPaint();
    var1.setWidth(11.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    int var3 = var2.getColumnCount();
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var2.setSeriesShape(100, var7, false);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var11.setSeriesShape(100, var16, false);
    var2.setSeriesShape(1, var16);
    boolean var20 = var1.equals((java.lang.Object)var2);
    java.lang.Object var21 = var1.clone();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    var23.zoomRange((-1.0d), 0.0d);
    boolean var27 = var23.isPositiveArrowVisible();
    boolean var28 = var23.isInverted();
    var23.configure();
    boolean var30 = var1.equals((java.lang.Object)var23);
    java.awt.Shape var31 = var23.getDownArrow();
    float var32 = var23.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 2.0f);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.zoomRange((-1.0d), 0.0d);
    boolean var5 = var1.isPositiveArrowVisible();
    boolean var6 = var1.getAutoRangeIncludesZero();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var1.valueToJava2D(4.0d, var8, var9);
    var1.setTickMarkInsideLength(0.0f);
    org.jfree.data.RangeType var13 = var1.getRangeType();
    java.lang.String var14 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RangeType.FULL"+ "'", var14.equals("RangeType.FULL"));

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var2 = var1.isNegativeArrowVisible();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createRegularCross(10.0f, 10.0f);
    var7.setSeriesShape(100, var12, false);
    org.jfree.chart.entity.CategoryLabelEntity var17 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)false, var12, "", "0");
    java.awt.Shape var18 = var17.getArea();
    boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var18);
    var1.setDownArrow(var18);
    double var21 = var1.getAutoRangeMinimumSize();
    java.awt.Shape var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRightArrow(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0E-8d);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.block.FlowArrangement var0 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var0);
    org.jfree.chart.util.Size2D var4 = new org.jfree.chart.util.Size2D(0.0d, 0.2d);
    boolean var5 = var1.equals((java.lang.Object)0.2d);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.event.AxisChangeListener var9 = null;
    var8.addChangeListener(var9);
    java.awt.Shape var11 = var8.getRightArrow();
    org.jfree.chart.event.AxisChangeListener var12 = null;
    var8.addChangeListener(var12);
    org.jfree.data.Range var16 = new org.jfree.data.Range(0.0d, 0.0d);
    var8.setDefaultAutoRange(var16);
    org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var16, 1.0d);
    org.jfree.chart.block.LengthConstraintType var20 = var19.getWidthConstraintType();
    org.jfree.chart.util.Size2D var21 = var1.arrange(var6, var19);
    var21.setWidth(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    var5.zoomRange((-1.0d), 0.0d);
    boolean var9 = var5.isPositiveArrowVisible();
    boolean var10 = var5.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    int var12 = var11.getColumnCount();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var16 = var15.isNegativeArrowVisible();
    var15.setAutoRangeStickyZero(false);
    java.awt.Stroke var19 = var15.getTickMarkStroke();
    var11.setSeriesOutlineStroke(1, var19, false);
    boolean var23 = var11.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("hi!");
    var25.zoomRange((-1.0d), 0.0d);
    boolean var29 = var25.isPositiveArrowVisible();
    java.awt.Paint var30 = var25.getAxisLinePaint();
    var11.setBasePaint(var30);
    org.jfree.chart.labels.CategoryToolTipGenerator var32 = null;
    var11.setBaseToolTipGenerator(var32);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var1, var3, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.axis.AxisLocation var35 = var34.getDomainAxisLocation();
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = var34.getRenderer(1);
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    java.awt.Paint var39 = var34.getRangeGridlinePaint();
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.axis.NumberAxis var44 = new org.jfree.chart.axis.NumberAxis("hi!");
    var44.zoomRange((-1.0d), 0.0d);
    boolean var48 = var44.isPositiveArrowVisible();
    boolean var49 = var44.getAutoRangeIncludesZero();
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    int var51 = var50.getColumnCount();
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var55 = var54.isNegativeArrowVisible();
    var54.setAutoRangeStickyZero(false);
    java.awt.Stroke var58 = var54.getTickMarkStroke();
    var50.setSeriesOutlineStroke(1, var58, false);
    boolean var62 = var50.isSeriesVisible(10);
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("hi!");
    var64.zoomRange((-1.0d), 0.0d);
    boolean var68 = var64.isPositiveArrowVisible();
    java.awt.Paint var69 = var64.getAxisLinePaint();
    var50.setBasePaint(var69);
    org.jfree.chart.labels.CategoryToolTipGenerator var71 = null;
    var50.setBaseToolTipGenerator(var71);
    org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot(var40, var42, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
    org.jfree.chart.axis.AxisLocation var74 = var73.getDomainAxisLocation();
    java.lang.String var75 = var74.toString();
    org.jfree.chart.axis.AxisLocation var76 = var74.getOpposite();
    var34.setRangeAxisLocation(var74, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var75.equals("AxisLocation.BOTTOM_OR_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setHeight(100.0d);
    java.awt.Font var3 = var0.getFont();
    var0.setExpandToFitSpace(true);
    var0.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    boolean var4 = var2.equals((java.lang.Object)1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.2d);
//     org.jfree.chart.text.TextAnchor var8 = var7.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var10 = var9.getColumnCount();
//     var9.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var9.getBasePositiveItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var14 = var13.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var16 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100.0d, "0", var8, var14, Double.POSITIVE_INFINITY);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.ChartColor[r=4,g=1,b=100]", var1, 0.0f, 100.0f, var8, 0.05d, 100.0f, 0.0f);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var1 = var0.getColumnCount();
//     var0.setBaseSeriesVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var4 = var0.getBasePositiveItemLabelPosition();
//     org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var7 = var6.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var11 = var10.isNegativeArrowVisible();
//     var10.setAutoRangeStickyZero(false);
//     java.awt.Stroke var14 = var10.getTickMarkStroke();
//     var6.setSeriesOutlineStroke(1, var14, false);
//     var6.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var20 = null;
//     var6.setSeriesToolTipGenerator(1, var20);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var22 = var6.getLegendItemToolTipGenerator();
//     java.awt.Paint var25 = var6.getItemLabelPaint(5, 1);
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var27 = var26.getColumnCount();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = var26.getLegendItemLabelGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var29 = var26.getBasePositiveItemLabelPosition();
//     var6.setNegativeItemLabelPositionFallback(var29);
//     var0.setSeriesPositiveItemLabelPosition(4, var29);
//     
//     // Checks the contract:  equals-hashcode on var4 and var29
//     assertTrue("Contract failed: equals-hashcode on var4 and var29", var4.equals(var29) ? var4.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var4
//     assertTrue("Contract failed: equals-hashcode on var29 and var4", var29.equals(var4) ? var29.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var4.zoomRange((-1.0d), 0.0d);
//     boolean var8 = var4.isPositiveArrowVisible();
//     boolean var9 = var4.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var11 = var10.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var15 = var14.isNegativeArrowVisible();
//     var14.setAutoRangeStickyZero(false);
//     java.awt.Stroke var18 = var14.getTickMarkStroke();
//     var10.setSeriesOutlineStroke(1, var18, false);
//     boolean var22 = var10.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var24.zoomRange((-1.0d), 0.0d);
//     boolean var28 = var24.isPositiveArrowVisible();
//     java.awt.Paint var29 = var24.getAxisLinePaint();
//     var10.setBasePaint(var29);
//     org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
//     var10.setBaseToolTipGenerator(var31);
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
//     var33.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var36 = null;
//     var33.markerChanged(var36);
//     org.jfree.data.general.DatasetGroup var38 = var33.getDatasetGroup();
//     org.jfree.chart.axis.AxisSpace var39 = var33.getFixedRangeAxisSpace();
//     java.awt.Font var40 = var33.getNoDataMessageFont();
//     org.jfree.data.category.CategoryDataset var41 = null;
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var45.zoomRange((-1.0d), 0.0d);
//     boolean var49 = var45.isPositiveArrowVisible();
//     boolean var50 = var45.getAutoRangeIncludesZero();
//     org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
//     int var52 = var51.getColumnCount();
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis("hi!");
//     boolean var56 = var55.isNegativeArrowVisible();
//     var55.setAutoRangeStickyZero(false);
//     java.awt.Stroke var59 = var55.getTickMarkStroke();
//     var51.setSeriesOutlineStroke(1, var59, false);
//     boolean var63 = var51.isSeriesVisible(10);
//     org.jfree.chart.axis.NumberAxis var65 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var65.zoomRange((-1.0d), 0.0d);
//     boolean var69 = var65.isPositiveArrowVisible();
//     java.awt.Paint var70 = var65.getAxisLinePaint();
//     var51.setBasePaint(var70);
//     org.jfree.chart.labels.CategoryToolTipGenerator var72 = null;
//     var51.setBaseToolTipGenerator(var72);
//     org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot(var41, var43, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
//     var74.setDomainGridlinesVisible(true);
//     org.jfree.chart.event.MarkerChangeEvent var77 = null;
//     var74.markerChanged(var77);
//     org.jfree.chart.util.SortOrder var79 = var74.getRowRenderingOrder();
//     var33.setRowRenderingOrder(var79);
//     
//     // Checks the contract:  equals-hashcode on var33 and var74
//     assertTrue("Contract failed: equals-hashcode on var33 and var74", var33.equals(var74) ? var33.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var33
//     assertTrue("Contract failed: equals-hashcode on var74 and var33", var74.equals(var33) ? var74.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0E-8d, (-20.0d), 10, (java.lang.Comparable)"AxisLocation.BOTTOM_OR_LEFT");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    int var1 = var0.getColumnCount();
    var0.setBaseSeriesVisible(false);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    int var8 = var7.getColumnCount();
    var7.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var12 = null;
    var7.setSeriesNegativeItemLabelPosition(100, var12, true);
    var7.setSeriesVisible(100, (java.lang.Boolean)false, true);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    int var22 = var21.getColumnCount();
    var21.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
    int var27 = var26.getColumnCount();
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi!");
    boolean var31 = var30.isNegativeArrowVisible();
    var30.setAutoRangeStickyZero(false);
    java.awt.Stroke var34 = var30.getTickMarkStroke();
    var26.setSeriesOutlineStroke(1, var34, false);
    var21.setSeriesOutlineStroke(0, var34, false);
    var20.setAxisLineStroke(var34);
    var7.setBaseStroke(var34, true);
    var0.setSeriesOutlineStroke(0, var34, true);
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement();
    org.jfree.chart.block.BlockContainer var45 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement();
    java.lang.Object var47 = null;
    boolean var48 = var46.equals(var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var46);
    java.awt.Font var50 = var49.getItemFont();
    java.awt.Font var51 = var49.getItemFont();
    org.jfree.chart.event.TitleChangeEvent var52 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var49);
    org.jfree.chart.util.RectangleInsets var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var49.setLegendItemGraphicPadding(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

}
