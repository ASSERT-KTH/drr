
import junit.framework.*;

public class RandoopTest5 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test1"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
//     java.lang.Comparable var7 = var2.getKey();
//     long var8 = var2.getMaximumItemAge();
//     java.beans.PropertyChangeListener var9 = null;
//     var2.removePropertyChangeListener(var9);
//     boolean var12 = var2.equals((java.lang.Object)1419159506934L);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
//     java.beans.PropertyChangeListener var16 = null;
//     var15.removePropertyChangeListener(var16);
//     java.lang.Comparable var18 = var15.getKey();
//     java.lang.Object var19 = new java.lang.Object();
//     boolean var20 = var15.equals(var19);
//     var15.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var24);
//     java.beans.PropertyChangeListener var26 = null;
//     var25.removePropertyChangeListener(var26);
//     java.lang.Comparable var28 = var25.getKey();
//     java.util.Collection var29 = var25.getTimePeriods();
//     var25.fireSeriesChanged();
//     org.jfree.data.time.TimeSeries var31 = var15.addAndOrUpdate(var25);
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var34 = var33.getYear();
//     int var35 = var32.compareTo((java.lang.Object)var33);
//     java.util.Calendar var36 = null;
//     long var37 = var32.getFirstMillisecond(var36);
//     int var39 = var32.compareTo((java.lang.Object)520764324);
//     long var40 = var32.getMiddleMillisecond();
//     int var41 = var31.getIndex((org.jfree.data.time.RegularTimePeriod)var32);
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var43);
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var47 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var45, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.TimeSeriesDataItem var48 = var31.getDataItem((org.jfree.data.time.RegularTimePeriod)var45);
//     org.jfree.data.time.TimeSeries var49 = var2.addAndOrUpdate(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + (short)(-1)+ "'", var18.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + (short)(-1)+ "'", var28.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419159602870L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419159602870L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test2"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getLastMillisecond();
//     boolean var3 = var0.equals((java.lang.Object)41994L);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var8 = var0.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419159602952L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159602952L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test3"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(12, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test4"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.lang.String var8 = var4.getDescription();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = var9.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
//     java.lang.Object var13 = var4.clone();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var15);
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var16.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var20 = var16.getKey();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var16.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)10.0d);
//     java.lang.Object var24 = var23.clone();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     java.util.Date var26 = var25.getStart();
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year(var26);
//     boolean var28 = var23.equals((java.lang.Object)var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(var26);
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var29);
//     java.util.Date var31 = var29.getTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + (short)(-1)+ "'", var20.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-10560));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test6"); }


    org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    java.util.Date var6 = var5.getStart();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
    java.util.Date var9 = var8.getStart();
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
    org.jfree.data.time.SerialDate var11 = var7.getEndOfCurrentMonth(var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths(0, var10);
    org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
    java.util.Date var14 = var13.getStart();
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
    org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
    java.util.Date var17 = var16.getStart();
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
    org.jfree.data.time.SerialDate var19 = var15.getEndOfCurrentMonth(var18);
    org.jfree.data.time.SerialDate var20 = var10.getEndOfCurrentMonth(var19);
    org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
    java.util.Date var22 = var21.getStart();
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
    org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
    java.util.Date var25 = var24.getStart();
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
    org.jfree.data.time.SerialDate var27 = var23.getEndOfCurrentMonth(var26);
    java.lang.Class var30 = null;
    org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var26, "December 2014", "Sunday", var30);
    boolean var33 = var3.isInRange(var20, var26, 2147483647);
    org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addMonths(12, var26);
    org.jfree.data.time.SerialDate var36 = var26.getFollowingDayOfWeek(7);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addDays(3, var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test7"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = var2.getEndOfCurrentMonth(var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     java.util.Date var10 = var9.getStart();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var12 = var7.equals((java.lang.Object)var11);
//     org.jfree.data.time.SerialDate var13 = var6.getEndOfCurrentMonth(var11);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     java.util.Date var17 = var16.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.SerialDate var22 = var18.getEndOfCurrentMonth(var21);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     long var24 = var23.getFirstMillisecond();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     java.util.Date var26 = var25.getStart();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(var26);
//     boolean var28 = var23.equals((java.lang.Object)var27);
//     org.jfree.data.time.SerialDate var29 = var22.getEndOfCurrentMonth(var27);
//     boolean var30 = var15.isAfter(var27);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     java.util.Date var32 = var31.getStart();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.SerialDate var34 = var15.getEndOfCurrentMonth(var33);
//     org.jfree.data.time.SerialDate var35 = var11.getEndOfCurrentMonth(var34);
//     var34.setDescription("31-December-2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test8"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    java.lang.String var8 = var2.getRangeDescription();
    java.beans.PropertyChangeListener var9 = null;
    var2.addPropertyChangeListener(var9);
    java.util.List var11 = var2.getItems();
    org.jfree.data.general.SeriesChangeListener var12 = null;
    var2.addChangeListener(var12);
    java.beans.PropertyChangeListener var14 = null;
    var2.addPropertyChangeListener(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "Value"+ "'", var8.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test9"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     org.jfree.data.time.SpreadsheetDate var5 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     java.util.Date var10 = var9.getStart();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     org.jfree.data.time.SerialDate var12 = var8.getEndOfCurrentMonth(var11);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     long var14 = var13.getFirstMillisecond();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     java.util.Date var16 = var15.getStart();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     boolean var18 = var13.equals((java.lang.Object)var17);
//     org.jfree.data.time.SerialDate var19 = var12.getEndOfCurrentMonth(var17);
//     boolean var20 = var5.isAfter(var17);
//     org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     java.util.Date var27 = var26.getStart();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
//     org.jfree.data.time.SerialDate var29 = var25.getEndOfCurrentMonth(var28);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     long var31 = var30.getFirstMillisecond();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     java.util.Date var33 = var32.getStart();
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(var33);
//     boolean var35 = var30.equals((java.lang.Object)var34);
//     org.jfree.data.time.SerialDate var36 = var29.getEndOfCurrentMonth(var34);
//     boolean var37 = var22.isAfter(var34);
//     boolean var38 = var5.isOnOrBefore((org.jfree.data.time.SerialDate)var22);
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     java.util.Date var42 = var41.getStart();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     java.util.Date var45 = var44.getStart();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.SerialDate var47 = var43.getEndOfCurrentMonth(var46);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     long var49 = var48.getFirstMillisecond();
//     org.jfree.data.time.Year var50 = new org.jfree.data.time.Year();
//     java.util.Date var51 = var50.getStart();
//     org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(var51);
//     boolean var53 = var48.equals((java.lang.Object)var52);
//     org.jfree.data.time.SerialDate var54 = var47.getEndOfCurrentMonth(var52);
//     boolean var55 = var40.isAfter(var52);
//     boolean var56 = var22.isAfter((org.jfree.data.time.SerialDate)var40);
//     int var57 = var40.toSerial();
//     java.lang.String var58 = var40.toString();
//     java.lang.Class var60 = null;
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var60);
//     org.jfree.data.time.Month var62 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var64 = var61.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var62, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var65 = var61.getKey();
//     org.jfree.data.time.Year var66 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var68 = var61.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var66, (java.lang.Number)10.0d);
//     long var69 = var66.getSerialIndex();
//     java.lang.String var70 = var66.toString();
//     java.lang.Class var72 = null;
//     org.jfree.data.time.TimeSeries var73 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var72);
//     org.jfree.data.time.Month var74 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var76 = var73.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var74, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var77 = var73.getKey();
//     org.jfree.data.time.Year var78 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var80 = var73.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var78, (java.lang.Number)10.0d);
//     java.lang.Object var81 = var80.clone();
//     org.jfree.data.time.Year var82 = new org.jfree.data.time.Year();
//     java.util.Date var83 = var82.getStart();
//     org.jfree.data.time.Year var84 = new org.jfree.data.time.Year(var83);
//     boolean var85 = var80.equals((java.lang.Object)var83);
//     int var86 = var66.compareTo((java.lang.Object)var83);
//     org.jfree.data.time.SerialDate var87 = org.jfree.data.time.SerialDate.createInstance(var83);
//     var87.setDescription("ERROR : Relative To String");
//     java.lang.String var90 = var87.getDescription();
//     boolean var91 = var1.isInRange((org.jfree.data.time.SerialDate)var40, var87);
//     int var92 = var1.getDayOfMonth();
//     org.jfree.data.time.Year var93 = new org.jfree.data.time.Year();
//     java.util.Date var94 = var93.getStart();
//     org.jfree.data.time.SerialDate var95 = org.jfree.data.time.SerialDate.createInstance(var94);
//     int var96 = var1.compare(var95);
//     org.jfree.data.time.Day var97 = new org.jfree.data.time.Day(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var58 + "' != '" + "20-January-1900"+ "'", var58.equals("20-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var65 + "' != '" + (short)(-1)+ "'", var65.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var70 + "' != '" + "2014"+ "'", var70.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var77 + "' != '" + (short)(-1)+ "'", var77.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var90 + "' != '" + "ERROR : Relative To String"+ "'", var90.equals("ERROR : Relative To String"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == (-41619));
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test10"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     int var2 = var0.getMonth();
//     long var3 = var0.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test11"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.SerialDate var20 = var1.getEndOfCurrentMonth(var19);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var24 = var23.toSerial();
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var23);
//     boolean var26 = var1.isOn((org.jfree.data.time.SerialDate)var23);
//     java.lang.String var27 = var23.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "20-January-1900"+ "'", var27.equals("20-January-1900"));
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test12"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    java.lang.String var13 = var4.getDescription();
    var4.clear();
    var4.setMaximumItemAge(1419159508686L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test13"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var7 = var6.getYear();
//     int var8 = var5.compareTo((java.lang.Object)var6);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
//     java.util.Calendar var11 = null;
//     long var12 = var5.getFirstMillisecond(var11);
//     long var13 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15);
//     java.lang.Class var18 = var17.getTimePeriodClass();
//     java.lang.Class var19 = org.jfree.data.time.RegularTimePeriod.downsize(var18);
//     java.lang.Class var20 = null;
//     java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var19, var20);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var24 = var23.getYear();
//     int var25 = var22.compareTo((java.lang.Object)var23);
//     java.util.Calendar var26 = null;
//     long var27 = var22.getFirstMillisecond(var26);
//     java.util.Calendar var28 = null;
//     long var29 = var22.getFirstMillisecond(var28);
//     long var30 = var22.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 10.0d);
//     java.lang.Object var33 = var32.clone();
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var32);
//     java.lang.Class var35 = var34.getTimePeriodClass();
//     java.lang.Class var36 = org.jfree.data.time.RegularTimePeriod.downsize(var35);
//     java.lang.Object var37 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 02:58:46 PST 2014", var19, var35);
//     java.io.InputStream var38 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Preceding", var19);
//     java.net.URL var39 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=2014]", var19);
//     java.lang.Class var40 = org.jfree.data.time.RegularTimePeriod.downsize(var19);
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1419159529837L, var19);
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var43);
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var47 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var45, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var48 = var44.getKey();
//     org.jfree.data.time.Year var49 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var51 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)10.0d);
//     java.lang.Object var52 = var51.clone();
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year();
//     java.util.Date var54 = var53.getStart();
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year(var54);
//     boolean var56 = var51.equals((java.lang.Object)var54);
//     org.jfree.data.time.Month var57 = new org.jfree.data.time.Month(var54);
//     java.lang.Class var61 = null;
//     org.jfree.data.time.TimeSeries var62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var61);
//     boolean var63 = var62.isEmpty();
//     var62.removeAgedItems(true);
//     java.util.List var66 = var62.getItems();
//     int var67 = var62.getItemCount();
//     var62.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var70 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var71 = var70.getYear();
//     long var72 = var70.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var73 = var62.getDataItem((org.jfree.data.time.RegularTimePeriod)var70);
//     java.util.Date var74 = var70.getEnd();
//     boolean var75 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var57, (java.lang.Object)var74);
//     java.util.TimeZone var76 = null;
//     org.jfree.data.time.RegularTimePeriod var77 = org.jfree.data.time.RegularTimePeriod.createInstance(var19, var74, var76);
//     java.lang.Class var78 = org.jfree.data.time.RegularTimePeriod.downsize(var19);
//     org.jfree.data.time.FixedMillisecond var79 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var80 = var79.next();
//     boolean var82 = var79.equals((java.lang.Object)1419159549366L);
//     java.util.Date var83 = var79.getTime();
//     java.util.TimeZone var84 = null;
//     org.jfree.data.time.RegularTimePeriod var85 = org.jfree.data.time.RegularTimePeriod.createInstance(var19, var83, var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419159603371L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419159603371L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419159603371L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419159603373L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419159603373L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1419159603373L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var48 + "' != '" + (short)(-1)+ "'", var48.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var85);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test14"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     long var2 = var0.getSerialIndex();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var6);
//     boolean var8 = var7.isEmpty();
//     var7.setDomainDescription("");
//     java.beans.PropertyChangeListener var11 = null;
//     var7.removePropertyChangeListener(var11);
//     org.jfree.data.general.SeriesChangeListener var13 = null;
//     var7.addChangeListener(var13);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var16);
//     java.beans.PropertyChangeListener var18 = null;
//     var17.removePropertyChangeListener(var18);
//     java.lang.Comparable var20 = var17.getKey();
//     java.lang.String var21 = var17.getRangeDescription();
//     java.lang.String var22 = var17.getRangeDescription();
//     boolean var23 = var7.equals((java.lang.Object)var17);
//     boolean var25 = var17.equals((java.lang.Object)(byte)(-1));
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var28 = var26.previous();
//     org.jfree.data.time.SerialDate var29 = var26.getSerialDate();
//     var17.setKey((java.lang.Comparable)var26);
//     boolean var31 = var0.equals((java.lang.Object)var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + (short)(-1)+ "'", var20.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "Value"+ "'", var21.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "Value"+ "'", var22.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test15"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var4.removeChangeListener(var14);
//     java.lang.String var16 = var4.getDomainDescription();
//     java.lang.Comparable var17 = var4.getKey();
//     int var18 = var4.getMaximumItemCount();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var20);
//     java.beans.PropertyChangeListener var22 = null;
//     var21.removePropertyChangeListener(var22);
//     java.lang.Comparable var24 = var21.getKey();
//     java.lang.Object var25 = new java.lang.Object();
//     boolean var26 = var21.equals(var25);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var31);
//     java.beans.PropertyChangeListener var33 = null;
//     var32.removePropertyChangeListener(var33);
//     java.lang.Comparable var35 = var32.getKey();
//     java.lang.Object var36 = new java.lang.Object();
//     boolean var37 = var32.equals(var36);
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     int var40 = var29.compareTo((java.lang.Object)var38);
//     long var41 = var29.getFirstMillisecond();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var43 = var42.getYear();
//     long var44 = var42.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var45 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var29, (org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.data.time.TimeSeries var46 = var4.addAndOrUpdate(var21);
//     var46.clear();
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond(1419159513507L);
//     java.util.Date var50 = var49.getStart();
//     java.lang.Number var51 = var46.getValue((org.jfree.data.time.RegularTimePeriod)var49);
//     org.jfree.data.time.RegularTimePeriod var52 = var49.previous();
//     long var53 = var49.getSerialIndex();
//     java.util.Calendar var54 = null;
//     var49.peg(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + '#'+ "'", var17.equals('#'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + (short)(-1)+ "'", var35.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1419159513507L);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test16"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     int var35 = var19.toSerial();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.String var41 = var39.getDescription();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths((-460), var39);
//     boolean var44 = var1.isInRange((org.jfree.data.time.SerialDate)var19, var39, 10);
//     int var45 = var19.getMonth();
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     long var47 = var46.getFirstMillisecond();
//     org.jfree.data.time.Year var48 = new org.jfree.data.time.Year();
//     java.util.Date var49 = var48.getStart();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     boolean var51 = var46.equals((java.lang.Object)var50);
//     org.jfree.data.time.SerialDate var52 = var19.getEndOfCurrentMonth(var50);
//     org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year();
//     java.util.Date var57 = var56.getStart();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var57);
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year();
//     java.util.Date var60 = var59.getStart();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var60);
//     org.jfree.data.time.SerialDate var62 = var58.getEndOfCurrentMonth(var61);
//     org.jfree.data.time.Day var63 = new org.jfree.data.time.Day();
//     long var64 = var63.getFirstMillisecond();
//     org.jfree.data.time.Year var65 = new org.jfree.data.time.Year();
//     java.util.Date var66 = var65.getStart();
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(var66);
//     boolean var68 = var63.equals((java.lang.Object)var67);
//     org.jfree.data.time.SerialDate var69 = var62.getEndOfCurrentMonth(var67);
//     boolean var70 = var55.isAfter(var67);
//     int var71 = var55.toSerial();
//     org.jfree.data.time.SerialDate var72 = org.jfree.data.time.SerialDate.addDays(12, (org.jfree.data.time.SerialDate)var55);
//     boolean var73 = var19.isOn(var72);
//     org.jfree.data.time.SpreadsheetDate var76 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var77 = new org.jfree.data.time.Year();
//     java.util.Date var78 = var77.getStart();
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.createInstance(var78);
//     org.jfree.data.time.Year var80 = new org.jfree.data.time.Year();
//     java.util.Date var81 = var80.getStart();
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.createInstance(var81);
//     org.jfree.data.time.SerialDate var83 = var79.getEndOfCurrentMonth(var82);
//     org.jfree.data.time.Day var84 = new org.jfree.data.time.Day();
//     long var85 = var84.getFirstMillisecond();
//     org.jfree.data.time.Year var86 = new org.jfree.data.time.Year();
//     java.util.Date var87 = var86.getStart();
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.createInstance(var87);
//     boolean var89 = var84.equals((java.lang.Object)var88);
//     org.jfree.data.time.SerialDate var90 = var83.getEndOfCurrentMonth(var88);
//     boolean var91 = var76.isAfter(var88);
//     org.jfree.data.time.Year var92 = new org.jfree.data.time.Year();
//     java.util.Date var93 = var92.getStart();
//     org.jfree.data.time.SerialDate var94 = org.jfree.data.time.SerialDate.createInstance(var93);
//     org.jfree.data.time.SerialDate var95 = var76.getEndOfCurrentMonth(var94);
//     org.jfree.data.time.SerialDate var96 = org.jfree.data.time.SerialDate.addDays(0, var95);
//     java.lang.String var97 = var95.toString();
//     boolean var98 = var19.isOn(var95);
//     org.jfree.data.time.Day var99 = new org.jfree.data.time.Day(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var97 + "' != '" + "31-January-2014"+ "'", var97.equals("31-January-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == false);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test17"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("October");
    java.lang.String var2 = var1.toString();
    org.jfree.data.general.SeriesException var4 = new org.jfree.data.general.SeriesException("");
    var1.addSuppressed((java.lang.Throwable)var4);
    org.jfree.data.general.SeriesException var7 = new org.jfree.data.general.SeriesException("October");
    java.lang.String var8 = var7.toString();
    org.jfree.data.general.SeriesException var10 = new org.jfree.data.general.SeriesException("");
    var7.addSuppressed((java.lang.Throwable)var10);
    var1.addSuppressed((java.lang.Throwable)var7);
    java.lang.String var13 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var2.equals("org.jfree.data.general.SeriesException: October"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var8.equals("org.jfree.data.general.SeriesException: October"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var13.equals("org.jfree.data.general.SeriesException: October"));

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test18"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getFirstMillisecond(var6);
//     long var8 = var0.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 10.0d);
//     var10.setValue((java.lang.Number)1420099199999L);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var14 = var13.getYear();
//     long var15 = var13.getFirstMillisecond();
//     int var16 = var10.compareTo((java.lang.Object)var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159603844L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419159603844L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419159603844L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test19"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     var4.setMaximumItemAge(10L);
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var11 = var9.equals((java.lang.Object)(-460));
//     int var12 = var9.getMaximumItemCount();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var20 = var19.getYear();
//     long var21 = var19.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var22 = var9.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var19);
//     boolean var23 = var4.equals((java.lang.Object)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var25 = var4.getTimePeriod(3);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test20"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setDomainDescription("");
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var4.addChangeListener(var10);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     java.beans.PropertyChangeListener var15 = null;
//     var14.removePropertyChangeListener(var15);
//     java.lang.Comparable var17 = var14.getKey();
//     java.lang.String var18 = var14.getRangeDescription();
//     java.lang.String var19 = var14.getRangeDescription();
//     boolean var20 = var4.equals((java.lang.Object)var14);
//     boolean var22 = var14.equals((java.lang.Object)(byte)(-1));
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     long var24 = var23.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var25 = var23.previous();
//     org.jfree.data.time.SerialDate var26 = var23.getSerialDate();
//     var14.setKey((java.lang.Comparable)var23);
//     java.util.Calendar var28 = null;
//     long var29 = var23.getFirstMillisecond(var28);
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test21"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var4 = var3.getYear();
//     int var5 = var2.compareTo((java.lang.Object)var3);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var2.getFirstMillisecond(var8);
//     long var10 = var2.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 10.0d);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var12);
//     java.lang.Class var15 = var14.getTimePeriodClass();
//     java.net.URL var16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var15);
//     java.net.URL var17 = org.jfree.chart.util.ObjectUtilities.getResource("", var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419159603862L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419159603862L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419159603862L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test22"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     int var4 = var1.compareTo((java.lang.Object)var2);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     java.util.Calendar var7 = null;
//     long var8 = var1.getFirstMillisecond(var7);
//     long var9 = var1.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, 10.0d);
//     java.lang.Object var12 = var11.clone();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11);
//     java.lang.Class var14 = var13.getTimePeriodClass();
//     java.lang.Class var15 = org.jfree.data.time.RegularTimePeriod.downsize(var14);
//     java.lang.Class var16 = null;
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var15, var16);
//     java.lang.Class var18 = org.jfree.data.time.RegularTimePeriod.downsize(var15);
//     java.lang.ClassLoader var19 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var18);
//     java.lang.ClassLoader var20 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419159603871L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419159603871L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419159603871L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test23"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var5 = var4.getYear();
//     int var6 = var3.compareTo((java.lang.Object)var4);
//     long var7 = var4.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, (-1.0d));
//     java.lang.String var10 = var4.toString();
//     org.jfree.data.time.RegularTimePeriod var11 = var4.next();
//     long var12 = var4.getFirstMillisecond();
//     java.util.Calendar var13 = null;
//     long var14 = var4.getFirstMillisecond(var13);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test24"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.String var6 = var2.getRangeDescription();
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    boolean var9 = var2.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Value"+ "'", var6.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test25"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var4 = var3.getYear();
//     int var5 = var2.compareTo((java.lang.Object)var3);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
//     java.util.Calendar var8 = null;
//     long var9 = var2.getFirstMillisecond(var8);
//     long var10 = var2.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, 10.0d);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var12);
//     java.lang.Class var15 = var14.getTimePeriodClass();
//     java.net.URL var16 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var15);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var19);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var20.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var24 = var20.getKey();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var20.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)10.0d);
//     java.lang.Object var28 = var27.clone();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year(var30);
//     boolean var32 = var27.equals((java.lang.Object)var30);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day(var30);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     long var35 = var34.getFirstMillisecond();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var37 = var36.getYear();
//     boolean var38 = var34.equals((java.lang.Object)var37);
//     int var39 = var34.getMonth();
//     boolean var40 = var33.equals((java.lang.Object)var34);
//     java.lang.String var41 = var34.toString();
//     org.jfree.data.time.FixedMillisecond var47 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var48 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var49 = var48.getYear();
//     int var50 = var47.compareTo((java.lang.Object)var48);
//     java.util.Calendar var51 = null;
//     long var52 = var47.getFirstMillisecond(var51);
//     java.util.Calendar var53 = null;
//     long var54 = var47.getFirstMillisecond(var53);
//     long var55 = var47.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var57 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, 10.0d);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var57);
//     java.lang.Class var60 = var59.getTimePeriodClass();
//     java.lang.Class var61 = org.jfree.data.time.RegularTimePeriod.downsize(var60);
//     java.lang.Class var62 = null;
//     java.lang.Object var63 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var61, var62);
//     org.jfree.data.time.FixedMillisecond var64 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var65 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var66 = var65.getYear();
//     int var67 = var64.compareTo((java.lang.Object)var65);
//     java.util.Calendar var68 = null;
//     long var69 = var64.getFirstMillisecond(var68);
//     java.util.Calendar var70 = null;
//     long var71 = var64.getFirstMillisecond(var70);
//     long var72 = var64.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var64, 10.0d);
//     java.lang.Object var75 = var74.clone();
//     org.jfree.data.time.TimeSeries var76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var74);
//     java.lang.Class var77 = var76.getTimePeriodClass();
//     java.lang.Class var78 = org.jfree.data.time.RegularTimePeriod.downsize(var77);
//     java.lang.Object var79 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 02:58:46 PST 2014", var61, var77);
//     java.util.Date var80 = null;
//     java.util.TimeZone var81 = null;
//     org.jfree.data.time.RegularTimePeriod var82 = org.jfree.data.time.RegularTimePeriod.createInstance(var77, var80, var81);
//     org.jfree.data.time.TimeSeries var83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1420099199999L, var77);
//     org.jfree.data.time.TimeSeries var84 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var34, "21-December-2014", "December 2014", var77);
//     java.net.URL var85 = org.jfree.chart.util.ObjectUtilities.getResource("Time", var77);
//     java.lang.ClassLoader var86 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var77);
//     java.lang.Object var87 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 1900", var15, var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419159603888L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419159603888L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419159603888L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "21-December-2014"+ "'", var41.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419159603894L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1419159603894L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1419159603894L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1419159603897L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1419159603897L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1419159603897L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var87);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test26"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     java.util.Date var41 = var40.getStart();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = var39.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     long var45 = var44.getFirstMillisecond();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     java.util.Date var47 = var46.getStart();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     boolean var49 = var44.equals((java.lang.Object)var48);
//     org.jfree.data.time.SerialDate var50 = var43.getEndOfCurrentMonth(var48);
//     boolean var51 = var36.isAfter(var48);
//     boolean var52 = var18.isAfter((org.jfree.data.time.SerialDate)var36);
//     int var53 = var36.getMonth();
//     java.util.Date var54 = var36.toDate();
//     java.lang.Object var55 = null;
//     boolean var56 = var36.equals(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == false);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test27"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    java.lang.Comparable var8 = var2.getKey();
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var12 = var10.equals((java.lang.Object)(-460));
    var10.setNotify(false);
    org.jfree.data.time.TimeSeries var15 = var2.addAndOrUpdate(var10);
    java.lang.String var16 = var10.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)(-1)+ "'", var8.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test28"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.setKey((java.lang.Comparable)"October");
//     org.jfree.data.time.TimeSeries var9 = var4.createCopy(0, 0);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(1419159506275L);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getMiddleMillisecond(var12);
//     var9.add((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)1419159575841L, false);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test29"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     java.lang.Object var6 = var4.clone();
//     java.util.List var7 = var4.getItems();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(1419159508002L);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.String var11 = var4.getDescription();
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var14 = var13.getDescription();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var17 = var16.getYear();
//     int var18 = var15.compareTo((java.lang.Object)var16);
//     long var19 = var16.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (-1.0d));
//     org.jfree.data.time.TimeSeriesDataItem var22 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.general.SeriesChangeListener var23 = null;
//     var4.removeChangeListener(var23);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     long var26 = var25.getFirstMillisecond();
//     org.jfree.data.time.Year var27 = var25.getYear();
//     long var28 = var25.getSerialIndex();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)1419159521832L);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test30"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
//     var2.fireSeriesChanged();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var11);
//     boolean var13 = var12.isEmpty();
//     var12.removeAgedItems(true);
//     java.beans.PropertyChangeListener var16 = null;
//     var12.removePropertyChangeListener(var16);
//     java.lang.Class var18 = var12.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var12.removeChangeListener(var19);
//     java.lang.String var21 = var12.getDescription();
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var12.removeChangeListener(var22);
//     java.lang.String var24 = var12.getDomainDescription();
//     java.lang.Comparable var25 = var12.getKey();
//     int var26 = var12.getMaximumItemCount();
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var28);
//     java.beans.PropertyChangeListener var30 = null;
//     var29.removePropertyChangeListener(var30);
//     java.lang.Comparable var32 = var29.getKey();
//     java.lang.Object var33 = new java.lang.Object();
//     boolean var34 = var29.equals(var33);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var39);
//     java.beans.PropertyChangeListener var41 = null;
//     var40.removePropertyChangeListener(var41);
//     java.lang.Comparable var43 = var40.getKey();
//     java.lang.Object var44 = new java.lang.Object();
//     boolean var45 = var40.equals(var44);
//     java.beans.PropertyChangeListener var46 = null;
//     var40.removePropertyChangeListener(var46);
//     int var48 = var37.compareTo((java.lang.Object)var46);
//     long var49 = var37.getFirstMillisecond();
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var51 = var50.getYear();
//     long var52 = var50.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var53 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var37, (org.jfree.data.time.RegularTimePeriod)var50);
//     org.jfree.data.time.TimeSeries var54 = var12.addAndOrUpdate(var29);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var56 = var55.getYear();
//     java.lang.String var57 = var56.toString();
//     org.jfree.data.time.Day var58 = new org.jfree.data.time.Day();
//     long var59 = var58.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var60 = var58.previous();
//     java.lang.Class var64 = null;
//     org.jfree.data.time.TimeSeries var65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var64);
//     java.lang.Object var66 = var65.clone();
//     org.jfree.data.time.FixedMillisecond var67 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var68 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var69 = var68.getYear();
//     int var70 = var67.compareTo((java.lang.Object)var68);
//     java.util.Calendar var71 = null;
//     long var72 = var67.getFirstMillisecond(var71);
//     java.util.Calendar var73 = null;
//     long var74 = var67.getFirstMillisecond(var73);
//     org.jfree.data.time.TimeSeriesDataItem var75 = var65.getDataItem((org.jfree.data.time.RegularTimePeriod)var67);
//     boolean var76 = var58.equals((java.lang.Object)var65);
//     org.jfree.data.time.TimeSeries var77 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var56, (org.jfree.data.time.RegularTimePeriod)var58);
//     org.jfree.data.time.TimeSeries var78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var56);
//     org.jfree.data.time.FixedMillisecond var79 = new org.jfree.data.time.FixedMillisecond();
//     int var81 = var79.compareTo((java.lang.Object)1.0d);
//     java.util.Date var82 = var79.getTime();
//     java.util.Calendar var83 = null;
//     long var84 = var79.getLastMillisecond(var83);
//     long var85 = var79.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var86 = var79.next();
//     int var87 = var56.compareTo((java.lang.Object)var79);
//     org.jfree.data.time.TimeSeriesDataItem var89 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var56, 100.0d);
//     org.jfree.data.time.FixedMillisecond var90 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var91 = var90.next();
//     long var92 = var90.getLastMillisecond();
//     java.util.Calendar var93 = null;
//     var90.peg(var93);
//     java.util.Date var95 = var90.getTime();
//     int var96 = var89.compareTo((java.lang.Object)var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + ""+ "'", var24.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + '#'+ "'", var25.equals('#'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + (short)(-1)+ "'", var32.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + (short)(-1)+ "'", var43.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "2014"+ "'", var57.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1419159604117L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1419159604117L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1419159604119L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1419159604119L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == 1419159604120L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == 1);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test31"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var3);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var7 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var8 = var4.getKey();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var11 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)10.0d);
//     java.lang.Object var12 = var11.clone();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     java.util.Date var14 = var13.getStart();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year(var14);
//     boolean var16 = var11.equals((java.lang.Object)var14);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var14);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     long var19 = var18.getFirstMillisecond();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var21 = var20.getYear();
//     boolean var22 = var18.equals((java.lang.Object)var21);
//     int var23 = var18.getMonth();
//     boolean var24 = var17.equals((java.lang.Object)var18);
//     java.lang.String var25 = var18.toString();
//     org.jfree.data.time.FixedMillisecond var31 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var33 = var32.getYear();
//     int var34 = var31.compareTo((java.lang.Object)var32);
//     java.util.Calendar var35 = null;
//     long var36 = var31.getFirstMillisecond(var35);
//     java.util.Calendar var37 = null;
//     long var38 = var31.getFirstMillisecond(var37);
//     long var39 = var31.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, 10.0d);
//     java.lang.Object var42 = var41.clone();
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var41);
//     java.lang.Class var44 = var43.getTimePeriodClass();
//     java.lang.Class var45 = org.jfree.data.time.RegularTimePeriod.downsize(var44);
//     java.lang.Class var46 = null;
//     java.lang.Object var47 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var45, var46);
//     org.jfree.data.time.FixedMillisecond var48 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var49 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var50 = var49.getYear();
//     int var51 = var48.compareTo((java.lang.Object)var49);
//     java.util.Calendar var52 = null;
//     long var53 = var48.getFirstMillisecond(var52);
//     java.util.Calendar var54 = null;
//     long var55 = var48.getFirstMillisecond(var54);
//     long var56 = var48.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, 10.0d);
//     java.lang.Object var59 = var58.clone();
//     org.jfree.data.time.TimeSeries var60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var58);
//     java.lang.Class var61 = var60.getTimePeriodClass();
//     java.lang.Class var62 = org.jfree.data.time.RegularTimePeriod.downsize(var61);
//     java.lang.Object var63 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 02:58:46 PST 2014", var45, var61);
//     java.util.Date var64 = null;
//     java.util.TimeZone var65 = null;
//     org.jfree.data.time.RegularTimePeriod var66 = org.jfree.data.time.RegularTimePeriod.createInstance(var61, var64, var65);
//     org.jfree.data.time.TimeSeries var67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1420099199999L, var61);
//     org.jfree.data.time.TimeSeries var68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var18, "21-December-2014", "December 2014", var61);
//     java.net.URL var69 = org.jfree.chart.util.ObjectUtilities.getResource("Time", var61);
//     java.io.InputStream var70 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + (short)(-1)+ "'", var8.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + "21-December-2014"+ "'", var25.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1419159604186L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1419159604186L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419159604186L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1419159604189L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 1419159604189L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419159604189L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test32"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21, 0, (-2013));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test33"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.util.Collection var11 = var4.getTimePeriods();
    java.beans.PropertyChangeListener var12 = null;
    var4.addPropertyChangeListener(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var15 = var4.getValue((-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test34"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-41619), 0, 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test35"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    var4.setDomainDescription("October");
    org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
    int var17 = var15.compareTo((java.lang.Object)1.0d);
    java.util.Date var18 = var15.getTime();
    org.jfree.data.time.TimeSeriesDataItem var20 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 1.0d);
    var4.setDescription("Sat Jan 20 00:00:00 PST 1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test36"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     var1.setDescription("");
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     java.util.Date var40 = var39.getStart();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.Year var42 = new org.jfree.data.time.Year();
//     java.util.Date var43 = var42.getStart();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(var43);
//     org.jfree.data.time.SerialDate var45 = var41.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     long var47 = var46.getFirstMillisecond();
//     org.jfree.data.time.Year var48 = new org.jfree.data.time.Year();
//     java.util.Date var49 = var48.getStart();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     boolean var51 = var46.equals((java.lang.Object)var50);
//     org.jfree.data.time.SerialDate var52 = var45.getEndOfCurrentMonth(var50);
//     boolean var53 = var38.isAfter(var50);
//     int var54 = var38.toSerial();
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year();
//     java.util.Date var58 = var57.getStart();
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.createInstance(var58);
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year();
//     java.util.Date var61 = var60.getStart();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var61);
//     org.jfree.data.time.SerialDate var63 = var59.getEndOfCurrentMonth(var62);
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day();
//     long var65 = var64.getFirstMillisecond();
//     org.jfree.data.time.Year var66 = new org.jfree.data.time.Year();
//     java.util.Date var67 = var66.getStart();
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
//     boolean var69 = var64.equals((java.lang.Object)var68);
//     org.jfree.data.time.SerialDate var70 = var63.getEndOfCurrentMonth(var68);
//     boolean var71 = var56.isAfter(var68);
//     int var72 = var56.toSerial();
//     org.jfree.data.time.Year var74 = new org.jfree.data.time.Year();
//     java.util.Date var75 = var74.getStart();
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.createInstance(var75);
//     java.lang.String var77 = var76.getDescription();
//     java.lang.String var78 = var76.getDescription();
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.addMonths((-460), var76);
//     boolean var81 = var38.isInRange((org.jfree.data.time.SerialDate)var56, var76, 10);
//     int var82 = var56.getDayOfMonth();
//     int var83 = var56.toSerial();
//     boolean var84 = var1.isOn((org.jfree.data.time.SerialDate)var56);
//     int var85 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var87 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var88 = var87.getDayOfMonth();
//     int var89 = var87.getMonth();
//     int var90 = var87.toSerial();
//     boolean var91 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var87);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var90 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var91 == true);
// 
//   }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test37"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.util.Date var16 = var12.getEnd();
//     org.jfree.data.time.RegularTimePeriod var17 = var12.previous();
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var12);
//     long var19 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     int var22 = var12.getYearValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 2014);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test38"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     java.lang.Object var5 = var4.clone();
//     java.util.List var6 = var4.getItems();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var13 = var9.getNextTimePeriod();
//     var9.fireSeriesChanged();
//     long var15 = var9.getMaximumItemAge();
//     java.util.List var16 = var9.getItems();
//     java.util.Collection var17 = var4.getTimePeriodsUniqueToOtherSeries(var9);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var21);
//     boolean var23 = var22.isEmpty();
//     var22.removeAgedItems(true);
//     java.util.List var26 = var22.getItems();
//     int var27 = var22.getItemCount();
//     var22.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var31 = var30.getYear();
//     long var32 = var30.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var33 = var22.getDataItem((org.jfree.data.time.RegularTimePeriod)var30);
//     java.util.Date var34 = var30.getEnd();
//     org.jfree.data.time.RegularTimePeriod var35 = var30.previous();
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var30);
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var40);
//     boolean var42 = var41.isEmpty();
//     var41.removeAgedItems(true);
//     java.beans.PropertyChangeListener var45 = null;
//     var41.removePropertyChangeListener(var45);
//     java.lang.Class var47 = var41.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var48 = null;
//     var41.removeChangeListener(var48);
//     java.lang.String var50 = var41.getDescription();
//     org.jfree.data.time.TimeSeries var51 = var36.addAndOrUpdate(var41);
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month();
//     long var53 = var52.getFirstMillisecond();
//     int var54 = var52.getYearValue();
//     org.jfree.data.time.TimeSeriesDataItem var56 = var51.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var52, (-1.0d));
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var52);
//     org.jfree.data.general.SeriesChangeListener var58 = null;
//     var4.addChangeListener(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test39"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    var4.clear();
    var4.setMaximumItemAge(10L);
    java.lang.Class var8 = var4.getTimePeriodClass();
    var4.setDomainDescription("Sun Dec 21 02:58:58 PST 2014");
    java.util.List var11 = var4.getItems();
    int var12 = var4.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2147483647);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test40"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var3 = var1.equals((java.lang.Object)(-460));
//     int var4 = var1.getMaximumItemCount();
//     var1.setRangeDescription("hi!");
//     java.util.Collection var7 = var1.getTimePeriods();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var13 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var14 = var10.getKey();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10.0d);
//     java.lang.Object var18 = var17.clone();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var20);
//     boolean var22 = var17.equals((java.lang.Object)var20);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var20);
//     long var24 = var23.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 10.0d);
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var31 = var29.equals((java.lang.Object)(-460));
//     int var32 = var29.getMaximumItemCount();
//     java.lang.Class var34 = null;
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var34);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var38 = var35.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var36, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var40 = var39.getYear();
//     long var41 = var39.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var42 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var36, (org.jfree.data.time.RegularTimePeriod)var39);
//     org.jfree.data.time.RegularTimePeriod var43 = var39.previous();
//     java.lang.Class var47 = null;
//     org.jfree.data.time.TimeSeries var48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var47);
//     boolean var49 = var48.isEmpty();
//     var48.removeAgedItems(true);
//     java.util.List var52 = var48.getItems();
//     int var53 = var48.getItemCount();
//     int var54 = var39.compareTo((java.lang.Object)var48);
//     int var55 = var23.compareTo((java.lang.Object)var39);
//     org.jfree.data.time.Year var56 = var23.getYear();
//     java.util.Date var57 = var23.getStart();
//     java.util.Calendar var58 = null;
//     long var59 = var23.getFirstMillisecond(var58);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test41"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     int var35 = var19.toSerial();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.String var41 = var39.getDescription();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths((-460), var39);
//     boolean var44 = var1.isInRange((org.jfree.data.time.SerialDate)var19, var39, 10);
//     int var45 = var19.getMonth();
//     org.jfree.data.time.Day var46 = new org.jfree.data.time.Day();
//     long var47 = var46.getFirstMillisecond();
//     org.jfree.data.time.Year var48 = new org.jfree.data.time.Year();
//     java.util.Date var49 = var48.getStart();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     boolean var51 = var46.equals((java.lang.Object)var50);
//     org.jfree.data.time.SerialDate var52 = var19.getEndOfCurrentMonth(var50);
//     int var53 = var19.getDayOfMonth();
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year();
//     java.util.Date var56 = var55.getStart();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.Year var58 = new org.jfree.data.time.Year();
//     java.util.Date var59 = var58.getStart();
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(var59);
//     org.jfree.data.time.SerialDate var61 = var57.getEndOfCurrentMonth(var60);
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day();
//     long var63 = var62.getFirstMillisecond();
//     org.jfree.data.time.Year var64 = new org.jfree.data.time.Year();
//     java.util.Date var65 = var64.getStart();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var65);
//     boolean var67 = var62.equals((java.lang.Object)var66);
//     org.jfree.data.time.SerialDate var68 = var61.getEndOfCurrentMonth(var66);
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.addDays(1, var68);
//     boolean var70 = var19.isOnOrBefore(var68);
//     org.jfree.data.time.Day var71 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == true);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test42"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.String var12 = var7.toString();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     java.lang.Object var15 = var14.clone();
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.util.Date var19 = var18.getStart();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.SerialDate var24 = var20.getEndOfCurrentMonth(var23);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     long var26 = var25.getFirstMillisecond();
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     java.util.Date var28 = var27.getStart();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     boolean var30 = var25.equals((java.lang.Object)var29);
//     org.jfree.data.time.SerialDate var31 = var24.getEndOfCurrentMonth(var29);
//     boolean var32 = var17.isAfter(var29);
//     org.jfree.data.time.SpreadsheetDate var34 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     java.util.Date var36 = var35.getStart();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     java.util.Date var39 = var38.getStart();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var41 = var37.getEndOfCurrentMonth(var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     long var43 = var42.getFirstMillisecond();
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     java.util.Date var45 = var44.getStart();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     boolean var47 = var42.equals((java.lang.Object)var46);
//     org.jfree.data.time.SerialDate var48 = var41.getEndOfCurrentMonth(var46);
//     boolean var49 = var34.isAfter(var46);
//     boolean var50 = var17.isOnOrBefore((org.jfree.data.time.SerialDate)var34);
//     org.jfree.data.time.SpreadsheetDate var52 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year();
//     java.util.Date var54 = var53.getStart();
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(var54);
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year();
//     java.util.Date var57 = var56.getStart();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var57);
//     org.jfree.data.time.SerialDate var59 = var55.getEndOfCurrentMonth(var58);
//     org.jfree.data.time.Day var60 = new org.jfree.data.time.Day();
//     long var61 = var60.getFirstMillisecond();
//     org.jfree.data.time.Year var62 = new org.jfree.data.time.Year();
//     java.util.Date var63 = var62.getStart();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(var63);
//     boolean var65 = var60.equals((java.lang.Object)var64);
//     org.jfree.data.time.SerialDate var66 = var59.getEndOfCurrentMonth(var64);
//     boolean var67 = var52.isAfter(var64);
//     boolean var68 = var34.isAfter((org.jfree.data.time.SerialDate)var52);
//     int var69 = var52.getMonth();
//     java.util.Date var70 = var52.toDate();
//     java.util.Date var71 = var52.toDate();
//     org.jfree.data.time.SpreadsheetDate var73 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var74 = var73.toSerial();
//     org.jfree.data.time.Year var76 = new org.jfree.data.time.Year();
//     java.util.Date var77 = var76.getStart();
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var77);
//     java.lang.String var79 = var78.getDescription();
//     java.lang.String var80 = var78.getDescription();
//     org.jfree.data.time.SerialDate var81 = org.jfree.data.time.SerialDate.addMonths((-460), var78);
//     boolean var82 = var73.isOnOrAfter(var81);
//     boolean var83 = var52.isOnOrBefore(var81);
//     boolean var84 = var14.equals((java.lang.Object)var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test43"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var2);
//     java.beans.PropertyChangeListener var4 = null;
//     var3.removePropertyChangeListener(var4);
//     java.lang.Comparable var6 = var3.getKey();
//     java.lang.Object var7 = new java.lang.Object();
//     boolean var8 = var3.equals(var7);
//     java.beans.PropertyChangeListener var9 = null;
//     var3.removePropertyChangeListener(var9);
//     int var11 = var0.compareTo((java.lang.Object)var9);
//     long var12 = var0.getLastMillisecond();
//     long var13 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 2014L);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test44"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.SerialDate var16 = var9.getEndOfCurrentMonth(var14);
//     boolean var17 = var2.isAfter(var14);
//     int var18 = var2.toSerial();
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.util.Date var25 = var24.getStart();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = var23.getEndOfCurrentMonth(var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     long var29 = var28.getFirstMillisecond();
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.util.Date var31 = var30.getStart();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     boolean var33 = var28.equals((java.lang.Object)var32);
//     org.jfree.data.time.SerialDate var34 = var27.getEndOfCurrentMonth(var32);
//     boolean var35 = var20.isAfter(var32);
//     int var36 = var20.toSerial();
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     java.util.Date var39 = var38.getStart();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     java.lang.String var41 = var40.getDescription();
//     java.lang.String var42 = var40.getDescription();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths((-460), var40);
//     boolean var45 = var2.isInRange((org.jfree.data.time.SerialDate)var20, var40, 10);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate)var20);
//     org.jfree.data.time.Year var48 = new org.jfree.data.time.Year();
//     java.util.Date var49 = var48.getStart();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     java.util.Date var52 = var51.getStart();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.SerialDate var54 = var50.getEndOfCurrentMonth(var53);
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.addMonths(0, var53);
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year();
//     java.util.Date var57 = var56.getStart();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var57);
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year();
//     java.util.Date var60 = var59.getStart();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var60);
//     org.jfree.data.time.SerialDate var62 = var58.getEndOfCurrentMonth(var61);
//     org.jfree.data.time.SerialDate var63 = var53.getEndOfCurrentMonth(var62);
//     org.jfree.data.time.Year var65 = new org.jfree.data.time.Year();
//     java.util.Date var66 = var65.getStart();
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(var66);
//     org.jfree.data.time.Year var68 = new org.jfree.data.time.Year();
//     java.util.Date var69 = var68.getStart();
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.createInstance(var69);
//     org.jfree.data.time.SerialDate var71 = var67.getEndOfCurrentMonth(var70);
//     org.jfree.data.time.SerialDate var72 = org.jfree.data.time.SerialDate.addMonths(0, var70);
//     org.jfree.data.time.SerialDate var73 = var53.getEndOfCurrentMonth(var70);
//     boolean var74 = var20.isOnOrBefore(var73);
//     org.jfree.data.time.Year var76 = new org.jfree.data.time.Year();
//     java.util.Date var77 = var76.getStart();
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var77);
//     org.jfree.data.time.Year var79 = new org.jfree.data.time.Year();
//     java.util.Date var80 = var79.getStart();
//     org.jfree.data.time.SerialDate var81 = org.jfree.data.time.SerialDate.createInstance(var80);
//     org.jfree.data.time.SerialDate var82 = var78.getEndOfCurrentMonth(var81);
//     org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.addMonths(0, var81);
//     org.jfree.data.time.Year var84 = new org.jfree.data.time.Year();
//     java.util.Date var85 = var84.getStart();
//     org.jfree.data.time.SerialDate var86 = org.jfree.data.time.SerialDate.createInstance(var85);
//     org.jfree.data.time.Year var87 = new org.jfree.data.time.Year();
//     java.util.Date var88 = var87.getStart();
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.createInstance(var88);
//     org.jfree.data.time.SerialDate var90 = var86.getEndOfCurrentMonth(var89);
//     org.jfree.data.time.SerialDate var91 = var81.getEndOfCurrentMonth(var90);
//     boolean var92 = var20.isAfter(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var85);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
// 
//   }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test45"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.util.Date var2 = var1.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.RegularTimePeriod var4 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var2, var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var2);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var13 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var14 = var10.getKey();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10.0d);
//     long var18 = var15.getSerialIndex();
//     java.lang.String var19 = var15.toString();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var21);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var22.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var26 = var22.getKey();
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var29 = var22.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, (java.lang.Number)10.0d);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     java.util.Date var32 = var31.getStart();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year(var32);
//     boolean var34 = var29.equals((java.lang.Object)var32);
//     int var35 = var15.compareTo((java.lang.Object)var32);
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var37);
//     int var39 = var6.compareTo((java.lang.Object)var37);
//     var37.setDescription("Preceding");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + (short)(-1)+ "'", var14.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + "2014"+ "'", var19.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + (short)(-1)+ "'", var26.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1);
// 
//   }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test46"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     long var6 = var0.getFirstMillisecond();
//     long var7 = var0.getLastMillisecond();
//     java.util.Date var8 = var0.getTime();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var19 = var15.getKey();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)10.0d);
//     java.lang.Object var23 = var22.clone();
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.util.Date var25 = var24.getStart();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year(var25);
//     boolean var27 = var22.equals((java.lang.Object)var25);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day(var25);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     long var30 = var29.getFirstMillisecond();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var32 = var31.getYear();
//     boolean var33 = var29.equals((java.lang.Object)var32);
//     int var34 = var29.getMonth();
//     boolean var35 = var28.equals((java.lang.Object)var29);
//     java.lang.String var36 = var29.toString();
//     org.jfree.data.time.FixedMillisecond var42 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var44 = var43.getYear();
//     int var45 = var42.compareTo((java.lang.Object)var43);
//     java.util.Calendar var46 = null;
//     long var47 = var42.getFirstMillisecond(var46);
//     java.util.Calendar var48 = null;
//     long var49 = var42.getFirstMillisecond(var48);
//     long var50 = var42.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var42, 10.0d);
//     java.lang.Object var53 = var52.clone();
//     org.jfree.data.time.TimeSeries var54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var52);
//     java.lang.Class var55 = var54.getTimePeriodClass();
//     java.lang.Class var56 = org.jfree.data.time.RegularTimePeriod.downsize(var55);
//     java.lang.Class var57 = null;
//     java.lang.Object var58 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var56, var57);
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var60 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var61 = var60.getYear();
//     int var62 = var59.compareTo((java.lang.Object)var60);
//     java.util.Calendar var63 = null;
//     long var64 = var59.getFirstMillisecond(var63);
//     java.util.Calendar var65 = null;
//     long var66 = var59.getFirstMillisecond(var65);
//     long var67 = var59.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var59, 10.0d);
//     java.lang.Object var70 = var69.clone();
//     org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var69);
//     java.lang.Class var72 = var71.getTimePeriodClass();
//     java.lang.Class var73 = org.jfree.data.time.RegularTimePeriod.downsize(var72);
//     java.lang.Object var74 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 02:58:46 PST 2014", var56, var72);
//     java.util.Date var75 = null;
//     java.util.TimeZone var76 = null;
//     org.jfree.data.time.RegularTimePeriod var77 = org.jfree.data.time.RegularTimePeriod.createInstance(var72, var75, var76);
//     org.jfree.data.time.TimeSeries var78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1420099199999L, var72);
//     org.jfree.data.time.TimeSeries var79 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var29, "21-December-2014", "December 2014", var72);
//     java.net.URL var80 = org.jfree.chart.util.ObjectUtilities.getResource("Time", var72);
//     java.lang.ClassLoader var81 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var72);
//     org.jfree.data.time.TimeSeries var82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1419159537169L, "First", "Sun Dec 21 02:58:46 PST 2014", var72);
//     java.lang.String var83 = var82.getRangeDescription();
//     int var84 = var0.compareTo((java.lang.Object)var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159605414L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419159605414L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419159605414L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + (short)(-1)+ "'", var19.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "21-December-2014"+ "'", var36.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1419159605418L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419159605418L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1419159605418L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419159605421L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1419159605421L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1419159605421L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var83 + "' != '" + "Sun Dec 21 02:58:46 PST 2014"+ "'", var83.equals("Sun Dec 21 02:58:46 PST 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test47"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var1 = var0.getYear();
//     int var2 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test48"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     var4.setDomainDescription("October");
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     int var17 = var15.compareTo((java.lang.Object)1.0d);
//     java.util.Date var18 = var15.getTime();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 1.0d);
//     java.util.Calendar var21 = null;
//     long var22 = var15.getLastMillisecond(var21);
//     java.util.Date var23 = var15.getTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419159605485L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test49"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     java.util.Date var41 = var40.getStart();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = var39.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     long var45 = var44.getFirstMillisecond();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     java.util.Date var47 = var46.getStart();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     boolean var49 = var44.equals((java.lang.Object)var48);
//     org.jfree.data.time.SerialDate var50 = var43.getEndOfCurrentMonth(var48);
//     boolean var51 = var36.isAfter(var48);
//     boolean var52 = var18.isAfter((org.jfree.data.time.SerialDate)var36);
//     java.lang.Class var54 = null;
//     org.jfree.data.time.TimeSeries var55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var54);
//     org.jfree.data.time.Month var56 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var58 = var55.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var56, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var59 = var55.getKey();
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0f));
//     java.lang.Class var63 = null;
//     org.jfree.data.time.TimeSeries var64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var63);
//     org.jfree.data.time.Month var65 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var67 = var64.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var65, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var68 = var64.getKey();
//     org.jfree.data.time.Year var69 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var71 = var64.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var69, (java.lang.Number)10.0d);
//     java.lang.Object var72 = var71.clone();
//     java.lang.Number var73 = var71.getValue();
//     org.jfree.data.time.RegularTimePeriod var74 = var71.getPeriod();
//     boolean var75 = var61.equals((java.lang.Object)var74);
//     var55.update(var74, (java.lang.Number)1419159506650L);
//     boolean var78 = var18.equals((java.lang.Object)var74);
//     java.lang.String var79 = var18.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var59 + "' != '" + (short)(-1)+ "'", var59.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var68 + "' != '" + (short)(-1)+ "'", var68.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var73 + "' != '" + (-1.0f)+ "'", var73.equals((-1.0f)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var79 + "' != '" + "20-January-1900"+ "'", var79.equals("20-January-1900"));
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test50"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
    java.lang.Comparable var7 = var2.getKey();
    long var8 = var2.getMaximumItemAge();
    int var9 = var2.getMaximumItemCount();
    var2.removeAgedItems(true);
    java.lang.String var12 = var2.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test51"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.lang.Object var6 = new java.lang.Object();
//     boolean var7 = var2.equals(var6);
//     var2.removeAgedItems(true);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var12);
//     java.beans.PropertyChangeListener var14 = null;
//     var13.removePropertyChangeListener(var14);
//     java.lang.Comparable var16 = var13.getKey();
//     java.lang.Object var17 = new java.lang.Object();
//     boolean var18 = var13.equals(var17);
//     java.beans.PropertyChangeListener var19 = null;
//     var13.removePropertyChangeListener(var19);
//     int var21 = var10.compareTo((java.lang.Object)var19);
//     long var22 = var10.getFirstMillisecond();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var24 = var23.getYear();
//     long var25 = var23.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var26 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var10, (org.jfree.data.time.RegularTimePeriod)var23);
//     long var27 = var23.getFirstMillisecond();
//     long var28 = var23.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + (short)(-1)+ "'", var16.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1417420800000L);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test52"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SerialDate var17 = null;
//     boolean var18 = var1.isAfter(var17);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest5.test53"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("31-January-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest5.test54"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var4);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var8 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var9 = var5.getKey();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)10.0d);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     java.util.Date var15 = var14.getStart();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(var15);
//     boolean var17 = var12.equals((java.lang.Object)var15);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var15);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var22 = var21.getYear();
//     boolean var23 = var19.equals((java.lang.Object)var22);
//     int var24 = var19.getMonth();
//     boolean var25 = var18.equals((java.lang.Object)var19);
//     java.lang.String var26 = var19.toString();
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var34 = var33.getYear();
//     int var35 = var32.compareTo((java.lang.Object)var33);
//     java.util.Calendar var36 = null;
//     long var37 = var32.getFirstMillisecond(var36);
//     java.util.Calendar var38 = null;
//     long var39 = var32.getFirstMillisecond(var38);
//     long var40 = var32.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, 10.0d);
//     java.lang.Object var43 = var42.clone();
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var42);
//     java.lang.Class var45 = var44.getTimePeriodClass();
//     java.lang.Class var46 = org.jfree.data.time.RegularTimePeriod.downsize(var45);
//     java.lang.Class var47 = null;
//     java.lang.Object var48 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var46, var47);
//     org.jfree.data.time.FixedMillisecond var49 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var51 = var50.getYear();
//     int var52 = var49.compareTo((java.lang.Object)var50);
//     java.util.Calendar var53 = null;
//     long var54 = var49.getFirstMillisecond(var53);
//     java.util.Calendar var55 = null;
//     long var56 = var49.getFirstMillisecond(var55);
//     long var57 = var49.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var59 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 10.0d);
//     java.lang.Object var60 = var59.clone();
//     org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var59);
//     java.lang.Class var62 = var61.getTimePeriodClass();
//     java.lang.Class var63 = org.jfree.data.time.RegularTimePeriod.downsize(var62);
//     java.lang.Object var64 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 02:58:46 PST 2014", var46, var62);
//     java.util.Date var65 = null;
//     java.util.TimeZone var66 = null;
//     org.jfree.data.time.RegularTimePeriod var67 = org.jfree.data.time.RegularTimePeriod.createInstance(var62, var65, var66);
//     org.jfree.data.time.TimeSeries var68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1420099199999L, var62);
//     org.jfree.data.time.TimeSeries var69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var19, "21-December-2014", "December 2014", var62);
//     java.net.URL var70 = org.jfree.chart.util.ObjectUtilities.getResource("Time", var62);
//     java.lang.ClassLoader var71 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var62);
//     java.io.InputStream var72 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sun Dec 21 02:58:50 PST 2014", var62);
//     java.net.URL var73 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Sunday", var62);
//     org.jfree.data.time.Year var74 = new org.jfree.data.time.Year();
//     java.util.Date var75 = var74.getStart();
//     java.util.TimeZone var76 = null;
//     org.jfree.data.time.RegularTimePeriod var77 = org.jfree.data.time.RegularTimePeriod.createInstance(var62, var75, var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + (short)(-1)+ "'", var9.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "21-December-2014"+ "'", var26.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1419159605663L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1419159605663L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1419159605663L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == 1419159605666L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1419159605666L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 1419159605666L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var77);
// 
//   }

}
