
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries(var0, "hi!", "", var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    java.lang.Number var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + ""+ "'", var0.equals(""));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    org.jfree.data.time.RegularTimePeriod var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var4.getIndex(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, var1);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    org.jfree.data.time.RegularTimePeriod var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var4.getValue(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    org.jfree.data.time.RegularTimePeriod var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var5, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    org.jfree.data.time.RegularTimePeriod var6 = null;
    java.lang.Number var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    org.jfree.data.time.TimeSeriesDataItem var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(0L, false);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    org.jfree.data.time.RegularTimePeriod var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var10 = var4.addOrUpdate(var8, (java.lang.Number)(short)100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, var1);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    org.jfree.data.time.RegularTimePeriod var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-1), 1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var1);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "October"+ "'", var2.equals("October"));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    org.jfree.data.time.RegularTimePeriod var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var5, (java.lang.Number)0.0d, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(100, var1);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    java.lang.Object var6 = var4.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var9 = var4.createCopy(10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, var1);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(0, var1);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1, (-460), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     long var6 = var5.getFirstMillisecond();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var5, 10.0d);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, (-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Sunday"+ "'", var1.equals("Sunday"));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1, 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     var4.clear();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     boolean var3 = var0.equals((java.lang.Object)'a');
//     java.util.Calendar var4 = null;
//     long var5 = var0.getMiddleMillisecond(var4);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var3 = new org.jfree.data.time.Month((-460), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var4.createCopy(100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    java.lang.Class var0 = null;
    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    java.util.TimeZone var3 = null;
    org.jfree.data.time.RegularTimePeriod var4 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var2, var3);
    java.util.TimeZone var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var2, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var12);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var17 = var13.getNextTimePeriod();
//     var4.add(var17, 0.0d);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var3 = var1.equals((java.lang.Object)(-460));
    int var4 = var1.getMaximumItemCount();
    var1.setRangeDescription("hi!");
    java.lang.Class var8 = null;
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var8);
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var12 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var10, (-1.0d));
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getMiddleMillisecond(var3);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.util.Collection var11 = var4.getTimePeriods();
    java.util.Collection var12 = var4.getTimePeriods();
    org.jfree.data.time.RegularTimePeriod var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var13, (java.lang.Number)1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths((-1), var1);
// 
//   }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0f));
//     boolean var4 = var0.equals((java.lang.Object)(-1.0f));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     long var3 = var2.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    java.util.Date var1 = var0.getStart();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var4 = var2.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.util.List var8 = var4.getItems();
    int var9 = var4.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(31, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sunday", var1);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.general.SeriesException var2 = new org.jfree.data.general.SeriesException("");
    boolean var3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)' ', (java.lang.Object)"");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var1.getLastMillisecond(var4);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    java.util.Date var1 = var0.getStart();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var4 = var2.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 520764324);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
    java.lang.Comparable var7 = var2.getKey();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((-1), (java.lang.Number)0L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var3 = var1.equals((java.lang.Object)(-460));
//     int var4 = var1.getMaximumItemCount();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var6);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var12 = var11.getYear();
//     long var13 = var11.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var14 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var8, (org.jfree.data.time.RegularTimePeriod)var11);
//     java.util.Calendar var15 = null;
//     long var16 = var8.getFirstMillisecond(var15);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(byte)10);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     var4.setMaximumItemAge(10L);
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var11 = var9.equals((java.lang.Object)(-460));
//     int var12 = var9.getMaximumItemCount();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var20 = var19.getYear();
//     long var21 = var19.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var22 = var9.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var19);
//     boolean var23 = var4.equals((java.lang.Object)var9);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var25);
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var29 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var30 = var26.getKey();
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var33 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var31, (java.lang.Number)10.0d);
//     java.lang.Object var34 = var33.clone();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var9.add(var33, false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + (short)(-1)+ "'", var30.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesException: October");

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)100);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.util.Collection var6 = var2.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var2.getValue(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var3 = var1.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2147483647);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.util.Collection var11 = var4.getTimePeriods();
    java.util.Collection var12 = var4.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var13 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     long var9 = var8.getFirstMillisecond();
//     org.jfree.data.time.Year var10 = var8.getYear();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)1419159506302L);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var15 = var13.equals((java.lang.Object)(-460));
//     int var16 = var13.getMaximumItemCount();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var18);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var19.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var24 = var23.getYear();
//     long var25 = var23.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var26 = var13.createCopy((org.jfree.data.time.RegularTimePeriod)var20, (org.jfree.data.time.RegularTimePeriod)var23);
//     org.jfree.data.time.RegularTimePeriod var27 = var23.previous();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var23, 100.0d, true);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     java.util.Calendar var4 = null;
//     var2.peg(var4);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setDomainDescription("");
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var13 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var14 = var10.getKey();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10.0d);
//     java.lang.Object var18 = var17.clone();
//     var4.add(var17, false);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var1, var3);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.lang.String var2 = var1.getDescription();
    org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var5 = var4.getYear();
    int var6 = var3.compareTo((java.lang.Object)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add((org.jfree.data.time.RegularTimePeriod)var4, 0.0d);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var8 = var4.createCopy(1, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Sunday");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, (-460), 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(31, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var8 = var2.getDataItem((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var2.createCopy((-1), (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.util.List var8 = var4.getItems();
    int var9 = var4.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var10 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("October");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     var4.setMaximumItemAge(10L);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var10 = var9.getYear();
//     int var11 = var8.compareTo((java.lang.Object)var9);
//     java.util.Calendar var12 = null;
//     long var13 = var8.getFirstMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var8.getFirstMillisecond(var14);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var8, 0.0d);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var13 = var9.getKey();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)10.0d);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.util.Date var19 = var18.getStart();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(var19);
//     boolean var21 = var16.equals((java.lang.Object)var19);
//     var2.add(var16, true);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var8.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     int var5 = var0.getMonth();
//     java.util.Calendar var6 = null;
//     long var7 = var0.getLastMillisecond(var6);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-460), 31, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("December 2014", var1);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(12, 100, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(21, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    java.lang.Comparable var6 = var2.getKey();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
    boolean var11 = var9.equals((java.lang.Object)'a');
    java.lang.Object var12 = var9.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     boolean var5 = var0.equals((java.lang.Object)var4);
//     var4.setDescription("");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(21, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     boolean var9 = var4.equals((java.lang.Object)"Sunday");
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var4.addChangeListener(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var14 = var13.getYear();
//     int var15 = var12.compareTo((java.lang.Object)var13);
//     long var16 = var12.getMiddleMillisecond();
//     java.lang.Number var17 = null;
//     var4.add((org.jfree.data.time.RegularTimePeriod)var12, var17, true);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.general.SeriesException: ", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0f));
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setKey(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var11 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)10.0d);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year(var18);
//     boolean var20 = var15.equals((java.lang.Object)var18);
//     org.jfree.data.time.RegularTimePeriod var21 = var15.getPeriod();
//     var2.add(var15);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     var4.removeAgedItems(1419159506800L, true);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
//     java.util.Calendar var5 = null;
//     long var6 = var2.getFirstMillisecond(var5);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("SerialDate.weekInMonthToString(): invalid code.");

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getMiddleMillisecond(var4);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var12);
//     boolean var14 = var9.equals((java.lang.Object)var12);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var12);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var12);
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var12, var17);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.util.Date var16 = var12.getEnd();
//     java.util.TimeZone var17 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var16, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((-460), (java.lang.Number)1419159506650L);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var3 = var1.equals((java.lang.Object)(-460));
    int var4 = var1.getMaximumItemCount();
    org.jfree.data.general.SeriesChangeListener var5 = null;
    var1.removeChangeListener(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var1.getValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(520764324);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(100, 31, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 0, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    java.util.Date var1 = var0.getStart();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
    org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    org.jfree.data.time.SerialDate var6 = var2.getEndOfCurrentMonth(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = var6.getPreviousDayOfWeek(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var2);
//     java.beans.PropertyChangeListener var4 = null;
//     var3.removePropertyChangeListener(var4);
//     java.lang.Comparable var6 = var3.getKey();
//     java.lang.Object var7 = new java.lang.Object();
//     boolean var8 = var3.equals(var7);
//     var3.removeAgedItems(true);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     java.beans.PropertyChangeListener var15 = null;
//     var14.removePropertyChangeListener(var15);
//     java.lang.Comparable var17 = var14.getKey();
//     java.lang.Object var18 = new java.lang.Object();
//     boolean var19 = var14.equals(var18);
//     java.beans.PropertyChangeListener var20 = null;
//     var14.removePropertyChangeListener(var20);
//     int var22 = var11.compareTo((java.lang.Object)var20);
//     long var23 = var11.getFirstMillisecond();
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var25 = var24.getYear();
//     long var26 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var27 = var3.createCopy((org.jfree.data.time.RegularTimePeriod)var11, (org.jfree.data.time.RegularTimePeriod)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var28 = new org.jfree.data.time.Month((-1), var11);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (short)(-1)+ "'", var17.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    java.lang.String var13 = var4.getDescription();
    org.jfree.data.general.SeriesChangeListener var14 = null;
    var4.removeChangeListener(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var16 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var11 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-1.0f));
//     int var12 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var19 = var15.getKey();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)10.0d);
//     boolean var24 = var22.equals((java.lang.Object)'a');
//     var4.add(var22, false);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("");
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var6);
//     java.lang.Object var8 = var7.clone();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var11 = var10.getYear();
//     int var12 = var9.compareTo((java.lang.Object)var10);
//     java.util.Calendar var13 = null;
//     long var14 = var9.getFirstMillisecond(var13);
//     java.util.Calendar var15 = null;
//     long var16 = var9.getFirstMillisecond(var15);
//     org.jfree.data.time.TimeSeriesDataItem var17 = var7.getDataItem((org.jfree.data.time.RegularTimePeriod)var9);
//     boolean var18 = var0.equals((java.lang.Object)var7);
//     java.util.Calendar var19 = null;
//     long var20 = var0.getLastMillisecond(var19);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    java.util.Date var1 = var0.getStart();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
    org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
    java.util.Date var4 = var3.getStart();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    org.jfree.data.time.SerialDate var6 = var2.getEndOfCurrentMonth(var5);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "December 2014", "Sunday", var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = var5.getNearestDayOfWeek(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "December"+ "'", var2.equals("December"));

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(520764324, 31, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     java.util.Calendar var3 = null;
//     var2.peg(var3);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.util.List var8 = var4.getItems();
    int var9 = var4.getItemCount();
    var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    boolean var12 = var4.getNotify();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(31, 31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var8 = var4.createCopy(2014, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1.0f));
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var10);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var15 = var11.getKey();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)10.0d);
//     java.lang.Object var19 = var18.clone();
//     java.lang.Number var20 = var18.getValue();
//     org.jfree.data.time.RegularTimePeriod var21 = var18.getPeriod();
//     boolean var22 = var8.equals((java.lang.Object)var21);
//     var2.update(var21, (java.lang.Number)1419159506650L);
//     var2.removeAgedItems(1419159507193L, false);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10, 0, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "First"+ "'", var1.equals("First"));

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.util.Calendar var11 = null;
//     long var12 = var7.getLastMillisecond(var11);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    java.util.Date var1 = var0.getStart();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var4 = var2.getNearestDayOfWeek(21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Preceding"+ "'", var1.equals("Preceding"));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Preceding");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-460), var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.setDomainDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(0, (java.lang.Number)21);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
    java.lang.Comparable var7 = var2.getKey();
    long var8 = var2.getMaximumItemAge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(31, 2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9223372036854775807L);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, 31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=2014]", var1);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    java.util.List var10 = var2.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(520764324, 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var18 = var14.getKey();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)10.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year(var24);
//     boolean var26 = var21.equals((java.lang.Object)var24);
//     int var27 = var7.compareTo((java.lang.Object)var24);
//     java.util.TimeZone var28 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var29 = new org.jfree.data.time.Day(var24, var28);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + (short)(-1)+ "'", var18.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.util.List var8 = var4.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var8);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(520764324, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    java.lang.Comparable var6 = var2.getKey();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
    java.lang.Object var10 = var9.clone();
    org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
    java.util.Date var12 = var11.getStart();
    org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var12);
    boolean var14 = var9.equals((java.lang.Object)var12);
    org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var12);
    java.util.TimeZone var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var12, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("October");
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.util.Calendar var16 = null;
//     long var17 = var12.getFirstMillisecond(var16);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var6 = var4.equals((java.lang.Object)(-460));
    int var7 = var4.getMaximumItemCount();
    var4.setRangeDescription("hi!");
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var4);
    java.lang.Comparable var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setKey(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    var4.setDomainDescription("October");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var15 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var2 = var1.getYear();
    int var3 = var0.compareTo((java.lang.Object)var1);
    boolean var5 = var0.equals((java.lang.Object)(-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var2);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var6 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var7 = var3.getKey();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)10.0d);
//     long var11 = var8.getSerialIndex();
//     java.lang.String var12 = var8.toString();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var19 = var15.getKey();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var22 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)10.0d);
//     java.lang.Object var23 = var22.clone();
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.util.Date var25 = var24.getStart();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year(var25);
//     boolean var27 = var22.equals((java.lang.Object)var25);
//     int var28 = var8.compareTo((java.lang.Object)var25);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var25);
//     var29.setDescription("ERROR : Relative To String");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-460), var29);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var19 + "' != '" + (short)(-1)+ "'", var19.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     var4.setNotify(true);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond();
//     int var18 = var16.compareTo((java.lang.Object)1.0d);
//     java.util.Date var19 = var16.getTime();
//     java.util.Calendar var20 = null;
//     long var21 = var16.getLastMillisecond(var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1419159506623L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419159508114L);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(520764324);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    java.lang.String var13 = var4.getDescription();
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var15 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sunday");

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var8 = var7.getYear();
//     int var9 = var6.compareTo((java.lang.Object)var7);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var6.getFirstMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var16 = var15.getYear();
//     long var17 = var15.getFirstMillisecond();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var15, 1.0d, true);
// 
//   }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("First", var1);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     int var4 = var0.compareTo((java.lang.Object)'a');
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(520764324);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1900, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     long var6 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159508359L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419159508359L);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Value");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var12);
//     boolean var14 = var9.equals((java.lang.Object)var12);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var12);
//     java.util.Calendar var16 = null;
//     long var17 = var15.getLastMillisecond(var16);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var2 = var1.previous();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     long var16 = var4.getMaximumItemAge();
//     boolean var17 = var4.getNotify();
//     var4.removeAgedItems(1419159506928L, true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(21, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var8 = var7.getYear();
//     int var9 = var6.compareTo((java.lang.Object)var7);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var6.getFirstMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     int var15 = var4.getItemCount();
//     var4.setMaximumItemCount(0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419159508627L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419159508627L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Preceding");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     int var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getLastMillisecond(var3);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(31, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var19 = var1.getPreviousDayOfWeek(1900);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var5 = var4.getYear();
//     int var6 = var3.compareTo((java.lang.Object)var4);
//     long var7 = var4.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, (-1.0d));
//     long var10 = var4.getSerialIndex();
//     org.jfree.data.time.Year var11 = var4.getYear();
//     org.jfree.data.time.RegularTimePeriod var12 = var4.previous();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     long var1 = var0.getLastMillisecond();
//     boolean var3 = var0.equals((java.lang.Object)41994L);
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var5);
//     java.beans.PropertyChangeListener var7 = null;
//     var6.removePropertyChangeListener(var7);
//     java.lang.Comparable var9 = var6.getKey();
//     java.lang.Object var10 = new java.lang.Object();
//     boolean var11 = var6.equals(var10);
//     var6.removeAgedItems(true);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var16);
//     java.beans.PropertyChangeListener var18 = null;
//     var17.removePropertyChangeListener(var18);
//     java.lang.Comparable var20 = var17.getKey();
//     java.lang.Object var21 = new java.lang.Object();
//     boolean var22 = var17.equals(var21);
//     java.beans.PropertyChangeListener var23 = null;
//     var17.removePropertyChangeListener(var23);
//     int var25 = var14.compareTo((java.lang.Object)var23);
//     long var26 = var14.getFirstMillisecond();
//     org.jfree.data.time.Month var27 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var28 = var27.getYear();
//     long var29 = var27.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var30 = var6.createCopy((org.jfree.data.time.RegularTimePeriod)var14, (org.jfree.data.time.RegularTimePeriod)var27);
//     int var31 = var0.compareTo((java.lang.Object)var14);
//     long var32 = var14.getSerialIndex();
//     java.util.Calendar var33 = null;
//     long var34 = var14.getFirstMillisecond(var33);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     long var3 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 41994L);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.SerialDate var20 = var1.getEndOfCurrentMonth(var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var22 = var20.getFollowingDayOfWeek(31);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.util.Calendar var11 = null;
//     var7.peg(var11);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.util.Date var16 = var12.getEnd();
//     org.jfree.data.time.RegularTimePeriod var17 = var12.previous();
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var12);
//     long var19 = var12.getFirstMillisecond();
//     java.util.Calendar var20 = null;
//     long var21 = var12.getFirstMillisecond(var20);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(10, 0, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
    java.lang.Comparable var7 = var2.getKey();
    long var8 = var2.getMaximumItemAge();
    java.lang.Number var10 = var2.getValue(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1.0f)+ "'", var10.equals((-1.0f)));

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var3 = var1.equals((java.lang.Object)(-460));
    int var4 = var1.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var1.createCopy((-1), 520764324);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = var2.getEndOfCurrentMonth(var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     java.util.Date var10 = var9.getStart();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var12 = var7.equals((java.lang.Object)var11);
//     org.jfree.data.time.SerialDate var13 = var6.getEndOfCurrentMonth(var11);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     java.util.Date var17 = var16.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.SerialDate var22 = var18.getEndOfCurrentMonth(var21);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     long var24 = var23.getFirstMillisecond();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     java.util.Date var26 = var25.getStart();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(var26);
//     boolean var28 = var23.equals((java.lang.Object)var27);
//     org.jfree.data.time.SerialDate var29 = var22.getEndOfCurrentMonth(var27);
//     boolean var30 = var15.isAfter(var27);
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     java.util.Date var32 = var31.getStart();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.SerialDate var34 = var15.getEndOfCurrentMonth(var33);
//     org.jfree.data.time.SerialDate var35 = var11.getEndOfCurrentMonth(var34);
//     var35.setDescription("2014");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     long var2 = var0.getFirstMillisecond();
//     java.lang.String var3 = var0.toString();
//     int var4 = var0.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var5 = var0.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "December 2014"+ "'", var3.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Sun Dec 21 02:58:27 PST 2014");

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    var4.setKey((java.lang.Comparable)"October");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var4.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     int var3 = var0.getDayOfMonth();
//     org.jfree.data.time.SerialDate var4 = var0.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var6 = var4.getPreviousDayOfWeek((-460));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("October");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 10);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     int var35 = var19.toSerial();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.String var41 = var39.getDescription();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths((-460), var39);
//     boolean var44 = var1.isInRange((org.jfree.data.time.SerialDate)var19, var39, 10);
//     org.jfree.data.time.FixedMillisecond var45 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var46 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var47 = var46.getYear();
//     int var48 = var45.compareTo((java.lang.Object)var46);
//     java.util.Calendar var49 = null;
//     long var50 = var45.getFirstMillisecond(var49);
//     int var52 = var45.compareTo((java.lang.Object)520764324);
//     long var53 = var45.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var54 = var19.compareTo((java.lang.Object)var53);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 1419159509887L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1419159509887L);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(520764324, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.SerialDate var16 = var9.getEndOfCurrentMonth(var14);
//     boolean var17 = var2.isAfter(var14);
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     boolean var35 = var2.isOnOrBefore((org.jfree.data.time.SerialDate)var19);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1900, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var3 = var1.equals((java.lang.Object)(-460));
//     int var4 = var1.getMaximumItemCount();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var6);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var12 = var11.getYear();
//     long var13 = var11.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var14 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var8, (org.jfree.data.time.RegularTimePeriod)var11);
//     java.util.Calendar var15 = null;
//     var11.peg(var15);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     int var2 = var0.getMonth();
//     int var3 = var0.getDayOfMonth();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.util.Date var16 = var12.getEnd();
//     java.util.Calendar var17 = null;
//     long var18 = var12.getFirstMillisecond(var17);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    java.util.Date var6 = var5.getStart();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var7);
    org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
    java.util.Date var11 = var10.getStart();
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
    java.util.Date var14 = var13.getStart();
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
    org.jfree.data.time.SerialDate var16 = var12.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var17 = var7.getEndOfCurrentMonth(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(2014, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getMiddleMillisecond(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419159510194L);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var18 = var14.getKey();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)10.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year(var24);
//     boolean var26 = var21.equals((java.lang.Object)var24);
//     int var27 = var7.compareTo((java.lang.Object)var24);
//     long var28 = var7.getLastMillisecond();
//     java.util.Calendar var29 = null;
//     var7.peg(var29);
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     long var19 = var18.getFirstMillisecond();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var21 = var20.getYear();
//     boolean var22 = var18.equals((java.lang.Object)var21);
//     int var23 = var18.getMonth();
//     org.jfree.data.time.SerialDate var24 = var18.getSerialDate();
//     org.jfree.data.time.SerialDate var25 = var18.getSerialDate();
//     boolean var26 = var1.isBefore(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var1, var3);
// 
//   }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.lang.String var1 = var0.toString();
//     java.util.Date var2 = var0.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2, var3);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    java.lang.Comparable var6 = var2.getKey();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
    java.lang.Object var10 = var2.clone();
    java.beans.PropertyChangeListener var11 = null;
    var2.removePropertyChangeListener(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("1-January-2014");

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var2 = var1.toSerial();
//     org.jfree.data.time.SerialDate var3 = null;
//     boolean var4 = var1.isOnOrBefore(var3);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    java.lang.String var13 = var4.getDescription();
    org.jfree.data.general.SeriesChangeListener var14 = null;
    var4.removeChangeListener(var14);
    var4.setKey((java.lang.Comparable)1419159506785L);
    org.jfree.data.time.TimeSeriesDataItem var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getMiddleMillisecond(var6);
//     int var9 = var0.compareTo((java.lang.Object)1L);
//     java.lang.String var10 = var0.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159510747L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419159510747L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Sun Dec 21 02:58:30 PST 2014"+ "'", var10.equals("Sun Dec 21 02:58:30 PST 2014"));
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
    java.util.Date var3 = var2.getStart();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    java.util.Date var6 = var5.getStart();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
    org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.addMonths(0, var7);
    org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
    java.util.Date var11 = var10.getStart();
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
    org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
    java.util.Date var14 = var13.getStart();
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
    org.jfree.data.time.SerialDate var16 = var12.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var17 = var7.getEndOfCurrentMonth(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("December", var1);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var18 = var14.getKey();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)10.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year(var24);
//     boolean var26 = var21.equals((java.lang.Object)var24);
//     int var27 = var7.compareTo((java.lang.Object)var24);
//     long var28 = var7.getLastMillisecond();
//     java.util.Calendar var29 = null;
//     long var30 = var7.getLastMillisecond(var29);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    java.lang.Object var6 = var4.clone();
    java.util.List var7 = var4.getItems();
    int var8 = var4.getItemCount();
    org.jfree.data.time.RegularTimePeriod var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var11 = var4.addOrUpdate(var9, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     java.util.Date var4 = var2.getEnd();
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var4, var5);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.util.List var8 = var4.getItems();
    int var9 = var4.getItemCount();
    var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    boolean var12 = var4.getNotify();
    java.lang.Class var14 = null;
    org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
    java.beans.PropertyChangeListener var16 = null;
    var15.removePropertyChangeListener(var16);
    java.lang.Comparable var18 = var15.getKey();
    java.lang.Object var19 = new java.lang.Object();
    boolean var20 = var15.equals(var19);
    var15.removeAgedItems(true);
    java.util.Collection var23 = var15.getTimePeriods();
    var15.fireSeriesChanged();
    org.jfree.data.time.TimeSeries var25 = var4.addAndOrUpdate(var15);
    java.beans.PropertyChangeListener var26 = null;
    var4.removePropertyChangeListener(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (short)(-1)+ "'", var18.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(31, (-41649), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.String var12 = var7.toString();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     java.util.Calendar var15 = null;
//     var7.peg(var15);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(31, var1);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//     java.lang.Throwable var2 = null;
//     var1.addSuppressed(var2);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setDomainDescription("");
//     var4.removeAgedItems(1419159506210L, true);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getLastMillisecond(var3);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-41619));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     var1.peg(var2);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: October");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    java.util.Date var1 = var0.getStart();
    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
    org.jfree.data.time.RegularTimePeriod var3 = var2.next();
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
    var4.setMaximumItemCount(0);
    java.lang.Class var8 = null;
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var8);
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var12 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(-1.0f));
    java.lang.Comparable var13 = var9.getKey();
    org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
    org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)10.0d);
    java.lang.Object var17 = var16.clone();
    java.lang.Number var18 = var16.getValue();
    org.jfree.data.time.RegularTimePeriod var19 = var16.getPeriod();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(var19, (java.lang.Number)0);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (short)(-1)+ "'", var13.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (-1.0f)+ "'", var18.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    var2.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var2.removeChangeListener(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("1-January-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    java.lang.Object var6 = var4.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var4.getTimePeriod((-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(520764324);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 126284888);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.util.Collection var6 = var2.getTimePeriods();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var7, 100.0d);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var12);
//     boolean var14 = var9.equals((java.lang.Object)var12);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var12);
//     long var16 = var15.getLastMillisecond();
//     java.util.Calendar var17 = null;
//     long var18 = var15.getFirstMillisecond(var17);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-41619));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.util.Collection var6 = var2.getTimePeriods();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var13 = var9.getKey();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)10.0d);
//     java.lang.Object var17 = var16.clone();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.util.Date var19 = var18.getStart();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(var19);
//     boolean var21 = var16.equals((java.lang.Object)var19);
//     org.jfree.data.time.RegularTimePeriod var22 = var16.getPeriod();
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     long var24 = var23.getFirstMillisecond();
//     int var25 = var23.getMonth();
//     int var26 = var16.compareTo((java.lang.Object)var25);
//     var2.add(var16);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-41619), (-460), 20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var4.removeChangeListener(var14);
//     java.lang.String var16 = var4.getDomainDescription();
//     java.lang.Comparable var17 = var4.getKey();
//     int var18 = var4.getMaximumItemCount();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var20);
//     java.beans.PropertyChangeListener var22 = null;
//     var21.removePropertyChangeListener(var22);
//     java.lang.Comparable var24 = var21.getKey();
//     java.lang.Object var25 = new java.lang.Object();
//     boolean var26 = var21.equals(var25);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var31);
//     java.beans.PropertyChangeListener var33 = null;
//     var32.removePropertyChangeListener(var33);
//     java.lang.Comparable var35 = var32.getKey();
//     java.lang.Object var36 = new java.lang.Object();
//     boolean var37 = var32.equals(var36);
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     int var40 = var29.compareTo((java.lang.Object)var38);
//     long var41 = var29.getFirstMillisecond();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var43 = var42.getYear();
//     long var44 = var42.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var45 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var29, (org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.data.time.TimeSeries var46 = var4.addAndOrUpdate(var21);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var48 = var4.getDataItem((-41619));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + '#'+ "'", var17.equals('#'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + (short)(-1)+ "'", var35.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     boolean var3 = var0.equals((java.lang.Object)'a');
//     java.lang.String var4 = var0.toString();
//     java.util.Calendar var5 = null;
//     long var6 = var0.getFirstMillisecond(var5);
// 
//   }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)false, "Sun Dec 21 02:58:30 PST 2014", "", var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond();
//     int var7 = var5.compareTo((java.lang.Object)1.0d);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var5, 0.0d);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-41649), 520764324, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.data.general.SeriesChangeEvent[source=2014]");

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=2014]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(20, 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.util.Collection var6 = var2.getTimePeriods();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     long var8 = var7.getFirstMillisecond();
//     boolean var10 = var7.equals((java.lang.Object)'a');
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var6, (java.lang.Object)var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var6 = var4.equals((java.lang.Object)(-460));
//     int var7 = var4.getMaximumItemCount();
//     var4.setRangeDescription("hi!");
//     org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var4);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     long var12 = var11.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var13 = var11.previous();
//     int var14 = var11.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var15 = var11.previous();
//     org.jfree.data.time.RegularTimePeriod var16 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var17 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var11, var16);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("October");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.lang.String var6 = var2.getRangeDescription();
//     var2.removeAgedItems(1419159506205L, false);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ERROR : Relative To String");

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "December"+ "'", var1.equals("December"));

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    var2.removeAgedItems(true);
    java.util.Collection var10 = var2.getTimePeriods();
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var12 = null;
    var2.addChangeListener(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     var4.clear();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var15 = var14.getYear();
//     int var16 = var13.compareTo((java.lang.Object)var14);
//     long var17 = var13.getFirstMillisecond();
//     java.util.Date var18 = var13.getEnd();
//     boolean var19 = var4.equals((java.lang.Object)var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setMaximumItemCount((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419159512985L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.SerialDate var16 = var9.getEndOfCurrentMonth(var14);
//     boolean var17 = var2.isAfter(var14);
//     int var18 = var2.toSerial();
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.util.Date var25 = var24.getStart();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = var23.getEndOfCurrentMonth(var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     long var29 = var28.getFirstMillisecond();
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.util.Date var31 = var30.getStart();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     boolean var33 = var28.equals((java.lang.Object)var32);
//     org.jfree.data.time.SerialDate var34 = var27.getEndOfCurrentMonth(var32);
//     boolean var35 = var20.isAfter(var32);
//     int var36 = var20.toSerial();
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     java.util.Date var39 = var38.getStart();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     java.lang.String var41 = var40.getDescription();
//     java.lang.String var42 = var40.getDescription();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths((-460), var40);
//     boolean var45 = var2.isInRange((org.jfree.data.time.SerialDate)var20, var40, 10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(20, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(20, 31, 4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var11 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)10.0d);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.getPeriod();
//     var4.add(var17, 10.0d, false);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     var1.setDescription("");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var37 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var1);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.util.Collection var11 = var4.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete((-1), 20);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var11 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-1.0f));
//     int var12 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (-1.0d));
//     org.jfree.data.time.RegularTimePeriod var15 = var9.next();
//     java.util.Calendar var16 = null;
//     var9.peg(var16);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     int var7 = var0.compareTo((java.lang.Object)520764324);
//     java.util.Calendar var8 = null;
//     long var9 = var0.getFirstMillisecond(var8);
//     org.jfree.data.general.SeriesException var11 = new org.jfree.data.general.SeriesException("");
//     java.lang.String var12 = var11.toString();
//     int var13 = var0.compareTo((java.lang.Object)var11);
//     java.lang.String var14 = var11.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159513540L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419159513540L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "org.jfree.data.general.SeriesException: "+ "'", var12.equals("org.jfree.data.general.SeriesException: "));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "org.jfree.data.general.SeriesException: "+ "'", var14.equals("org.jfree.data.general.SeriesException: "));
// 
//   }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.previous();
//     int var3 = var0.getDayOfMonth();
//     int var4 = var0.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     java.util.Date var5 = var4.getStart();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var6);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var6);
//     java.util.Calendar var10 = null;
//     long var11 = var9.getMiddleMillisecond(var10);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Sunday");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-435));

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     int var35 = var1.getYYYY();
//     int var36 = var1.toSerial();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var38 = var1.getFollowingDayOfWeek(21);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 21);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(520764324);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-41649));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var4.removeChangeListener(var14);
//     java.lang.String var16 = var4.getDomainDescription();
//     java.lang.Comparable var17 = var4.getKey();
//     int var18 = var4.getMaximumItemCount();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var20);
//     java.beans.PropertyChangeListener var22 = null;
//     var21.removePropertyChangeListener(var22);
//     java.lang.Comparable var24 = var21.getKey();
//     java.lang.Object var25 = new java.lang.Object();
//     boolean var26 = var21.equals(var25);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var31);
//     java.beans.PropertyChangeListener var33 = null;
//     var32.removePropertyChangeListener(var33);
//     java.lang.Comparable var35 = var32.getKey();
//     java.lang.Object var36 = new java.lang.Object();
//     boolean var37 = var32.equals(var36);
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     int var40 = var29.compareTo((java.lang.Object)var38);
//     long var41 = var29.getFirstMillisecond();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var43 = var42.getYear();
//     long var44 = var42.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var45 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var29, (org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.data.time.TimeSeries var46 = var4.addAndOrUpdate(var21);
//     org.jfree.data.time.Month var47 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var48 = var47.getYear();
//     java.lang.String var49 = var48.toString();
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     long var51 = var50.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var52 = var50.previous();
//     java.lang.Class var56 = null;
//     org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var56);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var60 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var61 = var60.getYear();
//     int var62 = var59.compareTo((java.lang.Object)var60);
//     java.util.Calendar var63 = null;
//     long var64 = var59.getFirstMillisecond(var63);
//     java.util.Calendar var65 = null;
//     long var66 = var59.getFirstMillisecond(var65);
//     org.jfree.data.time.TimeSeriesDataItem var67 = var57.getDataItem((org.jfree.data.time.RegularTimePeriod)var59);
//     boolean var68 = var50.equals((java.lang.Object)var57);
//     org.jfree.data.time.TimeSeries var69 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var48, (org.jfree.data.time.RegularTimePeriod)var50);
//     java.lang.Object var70 = var69.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + '#'+ "'", var17.equals('#'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + (short)(-1)+ "'", var35.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "2014"+ "'", var49.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419159514148L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1419159514148L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     int var35 = var19.toSerial();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.String var41 = var39.getDescription();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths((-460), var39);
//     boolean var44 = var1.isInRange((org.jfree.data.time.SerialDate)var19, var39, 10);
//     int var45 = var19.getMonth();
//     org.jfree.data.time.Month var46 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var47 = var46.getYear();
//     org.jfree.data.time.TimeSeries var48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var47);
//     java.lang.String var49 = var47.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var50 = var19.compareTo((java.lang.Object)var47);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "2014"+ "'", var49.equals("2014"));
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-41619));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("October", var1);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("First");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(126284888, 10, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     java.util.Date var41 = var40.getStart();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = var39.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     long var45 = var44.getFirstMillisecond();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     java.util.Date var47 = var46.getStart();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     boolean var49 = var44.equals((java.lang.Object)var48);
//     org.jfree.data.time.SerialDate var50 = var43.getEndOfCurrentMonth(var48);
//     boolean var51 = var36.isAfter(var48);
//     boolean var52 = var18.isAfter((org.jfree.data.time.SerialDate)var36);
//     int var53 = var36.getMonth();
//     java.util.Date var54 = var36.toDate();
//     java.util.TimeZone var55 = null;
//     org.jfree.data.time.Month var56 = new org.jfree.data.time.Month(var54, var55);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     var4.removeAgedItems(1419159510427L, true);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.previous();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     java.util.Calendar var4 = null;
//     var0.peg(var4);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    var4.setKey((java.lang.Comparable)"October");
    java.lang.Class var10 = null;
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var10);
    boolean var12 = var11.isEmpty();
    var11.removeAgedItems(true);
    java.util.Collection var15 = var11.getTimePeriods();
    var11.setNotify(true);
    org.jfree.data.general.SeriesChangeListener var18 = null;
    var11.addChangeListener(var18);
    java.util.Collection var20 = var4.getTimePeriodsUniqueToOtherSeries(var11);
    org.jfree.data.general.SeriesChangeListener var21 = null;
    var11.removeChangeListener(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(7, var1);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1);
//     java.lang.String var3 = var1.toString();
//     java.util.Calendar var4 = null;
//     long var5 = var1.getFirstMillisecond(var4);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     java.util.Date var5 = var4.getStart();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     long var9 = var8.getFirstMillisecond();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     java.util.Date var11 = var10.getStart();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     boolean var13 = var8.equals((java.lang.Object)var12);
//     org.jfree.data.time.SerialDate var14 = var7.getEndOfCurrentMonth(var12);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.SerialDate var23 = var19.getEndOfCurrentMonth(var22);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     long var25 = var24.getFirstMillisecond();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     java.util.Date var27 = var26.getStart();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
//     boolean var29 = var24.equals((java.lang.Object)var28);
//     org.jfree.data.time.SerialDate var30 = var23.getEndOfCurrentMonth(var28);
//     boolean var31 = var16.isAfter(var28);
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     java.util.Date var33 = var32.getStart();
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(var33);
//     org.jfree.data.time.SerialDate var35 = var16.getEndOfCurrentMonth(var34);
//     org.jfree.data.time.SerialDate var36 = var12.getEndOfCurrentMonth(var35);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-41649), var36);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var6 = var4.equals((java.lang.Object)(-460));
    int var7 = var4.getMaximumItemCount();
    var4.setRangeDescription("hi!");
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(31, 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var3 = var1.equals((java.lang.Object)(-460));
    var1.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(100, (java.lang.Number)1419159512118L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
//     java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var8.getFirstMillisecond(var9);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)1L, false);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     int var35 = var19.toSerial();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.String var41 = var39.getDescription();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths((-460), var39);
//     boolean var44 = var1.isInRange((org.jfree.data.time.SerialDate)var19, var39, 10);
//     java.util.Date var45 = var1.toDate();
//     java.util.TimeZone var46 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var47 = new org.jfree.data.time.Day(var45, var46);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"First", var1);
    var2.setDomainDescription("First");
    org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
    org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)1419159506159L);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.util.Collection var6 = var2.getTimePeriods();
    boolean var7 = var2.getNotify();
    java.beans.PropertyChangeListener var8 = null;
    var2.removePropertyChangeListener(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(20, 126284888);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
    org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
    java.util.Date var5 = var4.getStart();
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
    org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
    java.lang.Class var10 = null;
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "December 2014", "Sunday", var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addDays(520764324, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.util.Date var16 = var12.getEnd();
//     org.jfree.data.time.RegularTimePeriod var17 = var12.previous();
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var12);
//     java.util.Collection var19 = var18.getTimePeriods();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)"");
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var8 = var7.getYear();
//     int var9 = var6.compareTo((java.lang.Object)var7);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var6.getFirstMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     long var16 = var15.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var17 = var15.previous();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var21);
//     java.lang.Object var23 = var22.clone();
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var26 = var25.getYear();
//     int var27 = var24.compareTo((java.lang.Object)var25);
//     java.util.Calendar var28 = null;
//     long var29 = var24.getFirstMillisecond(var28);
//     java.util.Calendar var30 = null;
//     long var31 = var24.getFirstMillisecond(var30);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var22.getDataItem((org.jfree.data.time.RegularTimePeriod)var24);
//     boolean var33 = var15.equals((java.lang.Object)var22);
//     java.lang.Number var34 = var4.getValue((org.jfree.data.time.RegularTimePeriod)var15);
//     java.util.Calendar var35 = null;
//     var15.peg(var35);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("21-December-2014", var1);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     java.lang.String var2 = var0.toString();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("October");
    java.lang.String var2 = var1.toString();
    org.jfree.data.general.SeriesException var4 = new org.jfree.data.general.SeriesException("");
    var1.addSuppressed((java.lang.Throwable)var4);
    org.jfree.data.general.SeriesException var7 = new org.jfree.data.general.SeriesException("October");
    java.lang.String var8 = var7.toString();
    org.jfree.data.general.SeriesException var10 = new org.jfree.data.general.SeriesException("");
    var7.addSuppressed((java.lang.Throwable)var10);
    org.jfree.data.general.SeriesException var13 = new org.jfree.data.general.SeriesException("");
    var7.addSuppressed((java.lang.Throwable)var13);
    var4.addSuppressed((java.lang.Throwable)var7);
    java.lang.String var16 = var7.toString();
    java.lang.String var17 = var7.toString();
    java.lang.String var18 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var2.equals("org.jfree.data.general.SeriesException: October"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var8.equals("org.jfree.data.general.SeriesException: October"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var16.equals("org.jfree.data.general.SeriesException: October"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var17.equals("org.jfree.data.general.SeriesException: October"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "org.jfree.data.general.SeriesException: October"+ "'", var18.equals("org.jfree.data.general.SeriesException: October"));

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-41619));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "April"+ "'", var1.equals("April"));

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(12, 10);
//     long var13 = var12.getLastMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1419159513108L, false);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)2014L);
    java.lang.Object var2 = var1.getSource();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + 2014L+ "'", var2.equals(2014L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2014]"+ "'", var3.equals("org.jfree.data.general.SeriesChangeEvent[source=2014]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=2014]"+ "'", var4.equals("org.jfree.data.general.SeriesChangeEvent[source=2014]"));

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    var2.removeAgedItems(true);
    var2.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(0, (java.lang.Number)(short)0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     int var5 = var0.getMonth();
//     org.jfree.data.time.SerialDate var6 = var0.getSerialDate();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = var6.getNearestDayOfWeek(520764324);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Last"+ "'", var1.equals("Last"));

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"First", var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var4 = var2.getTimePeriod(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
//     int var5 = var2.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2014);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sun Dec 21 02:58:27 PST 2014", var1);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     int var2 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.previous();
//     int var4 = var0.getMonth();
//     long var5 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 41994L);
// 
//   }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getFirstMillisecond(var3);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.SerialDate var16 = var9.getEndOfCurrentMonth(var14);
//     boolean var17 = var2.isAfter(var14);
//     int var18 = var2.toSerial();
//     org.jfree.data.time.SpreadsheetDate var20 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.util.Date var25 = var24.getStart();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = var23.getEndOfCurrentMonth(var26);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     long var29 = var28.getFirstMillisecond();
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.util.Date var31 = var30.getStart();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     boolean var33 = var28.equals((java.lang.Object)var32);
//     org.jfree.data.time.SerialDate var34 = var27.getEndOfCurrentMonth(var32);
//     boolean var35 = var20.isAfter(var32);
//     int var36 = var20.toSerial();
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     java.util.Date var39 = var38.getStart();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     java.lang.String var41 = var40.getDescription();
//     java.lang.String var42 = var40.getDescription();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths((-460), var40);
//     boolean var45 = var2.isInRange((org.jfree.data.time.SerialDate)var20, var40, 10);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate)var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var48 = var46.getNearestDayOfWeek((-41649));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     int var2 = var0.compareTo((java.lang.Object)1.0d);
//     java.util.Date var3 = var0.getTime();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getLastMillisecond(var4);
//     long var6 = var0.getSerialIndex();
//     java.util.Calendar var7 = null;
//     var0.peg(var7);
//     long var9 = var0.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159516030L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419159516030L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419159516030L);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     boolean var11 = var4.getNotify();
//     var4.setDescription("org.jfree.data.general.SeriesException: ");
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var15);
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var16.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var20 = var16.getKey();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var23 = var16.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)10.0d);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     java.util.Date var25 = var24.getStart();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     java.util.Date var28 = var27.getStart();
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.createInstance(var28);
//     org.jfree.data.time.SerialDate var30 = var26.getEndOfCurrentMonth(var29);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     long var32 = var31.getFirstMillisecond();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     java.util.Date var34 = var33.getStart();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     boolean var36 = var31.equals((java.lang.Object)var35);
//     org.jfree.data.time.SerialDate var37 = var30.getEndOfCurrentMonth(var35);
//     int var38 = var21.compareTo((java.lang.Object)var37);
//     java.lang.Object var39 = null;
//     boolean var40 = var21.equals(var39);
//     long var41 = var21.getLastMillisecond();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var21, 100.0d, false);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var8 = var7.getYear();
//     int var9 = var6.compareTo((java.lang.Object)var7);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var6.getFirstMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var17 = var16.getYear();
//     int var18 = var15.compareTo((java.lang.Object)var16);
//     java.util.Calendar var19 = null;
//     long var20 = var15.getFirstMillisecond(var19);
//     long var21 = var15.getFirstMillisecond();
//     java.util.Calendar var22 = null;
//     long var23 = var15.getMiddleMillisecond(var22);
//     long var24 = var15.getMiddleMillisecond();
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(1419159506275L);
//     boolean var27 = var15.equals((java.lang.Object)1419159506275L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)1419159508172L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419159516305L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419159516305L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419159516306L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1419159516306L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419159516306L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1419159516306L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
    java.util.Date var1 = var0.getStart();
    org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
    org.jfree.data.time.RegularTimePeriod var3 = var2.next();
    java.util.Date var4 = var2.getEnd();
    java.util.TimeZone var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("21-December-2014", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.String var6 = var2.getRangeDescription();
    java.lang.String var7 = var2.getRangeDescription();
    java.util.List var8 = var2.getItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Value"+ "'", var6.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var5 = var4.getYear();
//     int var6 = var3.compareTo((java.lang.Object)var4);
//     long var7 = var4.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, (-1.0d));
//     long var10 = var4.getSerialIndex();
//     org.jfree.data.time.Year var11 = var4.getYear();
//     java.lang.String var12 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "December 2014"+ "'", var12.equals("December 2014"));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    boolean var9 = var4.equals((java.lang.Object)"Sunday");
    java.beans.PropertyChangeListener var10 = null;
    var4.addPropertyChangeListener(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesException: ", var1);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var3);
//     java.beans.PropertyChangeListener var5 = null;
//     var4.removePropertyChangeListener(var5);
//     java.lang.Comparable var7 = var4.getKey();
//     java.lang.Object var8 = new java.lang.Object();
//     boolean var9 = var4.equals(var8);
//     java.beans.PropertyChangeListener var10 = null;
//     var4.removePropertyChangeListener(var10);
//     int var12 = var1.compareTo((java.lang.Object)var10);
//     org.jfree.data.time.RegularTimePeriod var13 = var1.previous();
//     long var14 = var1.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var15 = new org.jfree.data.time.Month((-435), var1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 2014L);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.util.Date var16 = var12.getEnd();
//     org.jfree.data.time.RegularTimePeriod var17 = var12.previous();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem(var17, 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesException: October", var1);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var8 = var7.getYear();
//     int var9 = var6.compareTo((java.lang.Object)var7);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var6.getFirstMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     int var15 = var4.getItemCount();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     java.util.Date var17 = var16.getStart();
//     java.lang.String var18 = var16.toString();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     long var4 = var0.getFirstMillisecond();
//     java.util.Date var5 = var0.getEnd();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var7);
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var11 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var12 = var8.getKey();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)10.0d);
//     java.lang.Object var16 = var15.clone();
//     java.lang.Number var17 = var15.getValue();
//     org.jfree.data.time.RegularTimePeriod var18 = var15.getPeriod();
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     long var20 = var19.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var21 = var19.previous();
//     int var22 = var19.getDayOfMonth();
//     int var23 = var15.compareTo((java.lang.Object)var19);
//     boolean var24 = var0.equals((java.lang.Object)var19);
//     java.util.Calendar var25 = null;
//     long var26 = var0.getFirstMillisecond(var25);
//     org.jfree.data.time.RegularTimePeriod var27 = var0.next();
//     java.util.Calendar var28 = null;
//     long var29 = var0.getFirstMillisecond(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1419159516967L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + (short)(-1)+ "'", var12.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0f)+ "'", var17.equals((-1.0f)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1419159516967L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419159516967L);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     int var7 = var0.compareTo((java.lang.Object)520764324);
//     long var8 = var0.getMiddleMillisecond();
//     java.util.Calendar var9 = null;
//     long var10 = var0.getMiddleMillisecond(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159517009L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419159517009L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419159517009L);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Last", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var18 = var14.getKey();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)10.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year(var24);
//     boolean var26 = var21.equals((java.lang.Object)var24);
//     int var27 = var7.compareTo((java.lang.Object)var24);
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var24);
//     var28.setDescription("ERROR : Relative To String");
//     java.lang.String var31 = var28.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var33 = var28.getPreviousDayOfWeek(520764324);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + (short)(-1)+ "'", var18.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + "1-January-2014"+ "'", var31.equals("1-January-2014"));
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.util.Date var2 = var1.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.RegularTimePeriod var4 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var2, var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var2, var6);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("April", var1);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setDomainDescription("");
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var4.addChangeListener(var10);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     java.beans.PropertyChangeListener var15 = null;
//     var14.removePropertyChangeListener(var15);
//     java.lang.Comparable var17 = var14.getKey();
//     java.lang.String var18 = var14.getRangeDescription();
//     java.lang.String var19 = var14.getRangeDescription();
//     boolean var20 = var4.equals((java.lang.Object)var14);
//     var14.removeAgedItems(1419159506124L, false);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.lang.Object var6 = new java.lang.Object();
    boolean var7 = var2.equals(var6);
    var2.removeAgedItems(true);
    java.lang.Class var10 = var2.getTimePeriodClass();
    org.jfree.data.time.RegularTimePeriod var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var12 = var2.getDataItem(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-435), (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var10 = var2.createCopy(126284888, 520764324);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    boolean var9 = var4.equals((java.lang.Object)"Sunday");
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var4.addChangeListener(var10);
    var4.setDomainDescription("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     var1.setDescription("");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var38 = var1.getPreviousDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("Last");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)10.0f, "org.jfree.data.general.SeriesException: October", "org.jfree.data.general.SeriesException: October", var3);
    var4.setRangeDescription("hi!");
    var4.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(7, (java.lang.Number)1419159514014L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.util.Collection var11 = var4.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var13 = var4.getDataItem(31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var12);
//     boolean var14 = var9.equals((java.lang.Object)var12);
//     java.util.TimeZone var15 = null;
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(var12, var15);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var3 = var1.equals((java.lang.Object)(-460));
    int var4 = var1.getMaximumItemCount();
    var1.setRangeDescription("hi!");
    java.util.Collection var7 = var1.getTimePeriods();
    var1.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1900, (-41649), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.lang.Object var6 = new java.lang.Object();
//     boolean var7 = var2.equals(var6);
//     var2.removeAgedItems(true);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var12);
//     java.beans.PropertyChangeListener var14 = null;
//     var13.removePropertyChangeListener(var14);
//     java.lang.Comparable var16 = var13.getKey();
//     java.lang.Object var17 = new java.lang.Object();
//     boolean var18 = var13.equals(var17);
//     java.beans.PropertyChangeListener var19 = null;
//     var13.removePropertyChangeListener(var19);
//     int var21 = var10.compareTo((java.lang.Object)var19);
//     long var22 = var10.getFirstMillisecond();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var24 = var23.getYear();
//     long var25 = var23.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var26 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var10, (org.jfree.data.time.RegularTimePeriod)var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var29 = var26.createCopy(2014, 10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + (short)(-1)+ "'", var16.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     java.beans.PropertyChangeListener var3 = null;
//     var2.removePropertyChangeListener(var3);
//     java.lang.Comparable var5 = var2.getKey();
//     java.lang.String var6 = var2.getRangeDescription();
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var9 = var8.getDescription();
//     org.jfree.data.time.FixedMillisecond var10 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var12 = var11.getYear();
//     int var13 = var10.compareTo((java.lang.Object)var11);
//     long var14 = var11.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     long var17 = var11.getSerialIndex();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var2.getTimePeriod(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     java.beans.PropertyChangeListener var16 = null;
//     var4.removePropertyChangeListener(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
//     java.lang.Comparable var7 = var2.getKey();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var11);
//     boolean var13 = var12.isEmpty();
//     java.util.Collection var14 = var2.getTimePeriodsUniqueToOtherSeries(var12);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var16);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var21 = var17.getNextTimePeriod();
//     var17.fireSeriesChanged();
//     boolean var23 = var12.equals((java.lang.Object)var17);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var27);
//     var28.clear();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var31);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var35 = var32.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, (java.lang.Number)(-1.0f));
//     int var36 = var28.getIndex((org.jfree.data.time.RegularTimePeriod)var33);
//     org.jfree.data.time.TimeSeriesDataItem var38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, (-1.0d));
//     var12.add(var38, false);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.lang.Class var11 = var4.getTimePeriodClass();
    java.lang.Comparable var12 = var4.getKey();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var14 = var4.getTimePeriod(1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + '#'+ "'", var12.equals('#'));

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(31, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("20-January-1900", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var2.getLastMillisecond(var3);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.util.Date var2 = var1.getStart();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.RegularTimePeriod var4 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var2, var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(var2, var7);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    var4.clear();
    int var11 = var4.getMaximumItemCount();
    int var12 = var4.getMaximumItemCount();
    java.util.Collection var13 = var4.getTimePeriods();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     org.jfree.data.time.RegularTimePeriod var5 = var0.previous();
//     java.util.Calendar var6 = null;
//     long var7 = var0.getFirstMillisecond(var6);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var3);
    java.beans.PropertyChangeListener var5 = null;
    var4.removePropertyChangeListener(var5);
    java.lang.Comparable var7 = var4.getKey();
    java.lang.Object var8 = new java.lang.Object();
    boolean var9 = var4.equals(var8);
    java.beans.PropertyChangeListener var10 = null;
    var4.removePropertyChangeListener(var10);
    int var12 = var1.compareTo((java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var13 = new org.jfree.data.time.Month((-460), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)(-1)+ "'", var7.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    java.lang.String var13 = var4.getDescription();
    var4.clear();
    boolean var15 = var4.getNotify();
    var4.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var1);
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var1, var3);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.setDomainDescription("");
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    org.jfree.data.general.SeriesChangeListener var10 = null;
    var4.addChangeListener(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update(0, (java.lang.Number)1419159506785L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     boolean var11 = var4.getNotify();
//     var4.removeAgedItems(1419159517013L, false);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    java.util.Date var2 = var1.getStart();
    org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(0, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
    int var3 = var2.toSerial();
    int var4 = var2.getMonth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(21, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Year var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-572));

  }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesException: October", var1);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(31, 0, 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var4.removeChangeListener(var14);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var18 = var17.getYear();
//     int var19 = var16.compareTo((java.lang.Object)var17);
//     java.util.Calendar var20 = null;
//     long var21 = var16.getFirstMillisecond(var20);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var24 = var23.getYear();
//     int var25 = var22.compareTo((java.lang.Object)var23);
//     int var26 = var16.compareTo((java.lang.Object)var23);
//     java.util.Calendar var27 = null;
//     var16.peg(var27);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1419159519527L);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    java.lang.String var13 = var4.getDescription();
    org.jfree.data.general.SeriesChangeListener var14 = null;
    var4.removeChangeListener(var14);
    java.lang.String var16 = var4.getDomainDescription();
    java.lang.Comparable var17 = var4.getKey();
    java.beans.PropertyChangeListener var18 = null;
    var4.addPropertyChangeListener(var18);
    var4.removeAgedItems(true);
    java.lang.Object var22 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + '#'+ "'", var17.equals('#'));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    int var6 = var2.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     java.util.Date var36 = var35.getStart();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     java.util.Date var39 = var38.getStart();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var41 = var37.getEndOfCurrentMonth(var40);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     long var43 = var42.getFirstMillisecond();
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     java.util.Date var45 = var44.getStart();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     boolean var47 = var42.equals((java.lang.Object)var46);
//     org.jfree.data.time.SerialDate var48 = var41.getEndOfCurrentMonth(var46);
//     org.jfree.data.time.SpreadsheetDate var50 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     java.util.Date var52 = var51.getStart();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.Year var54 = new org.jfree.data.time.Year();
//     java.util.Date var55 = var54.getStart();
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(var55);
//     org.jfree.data.time.SerialDate var57 = var53.getEndOfCurrentMonth(var56);
//     org.jfree.data.time.Day var58 = new org.jfree.data.time.Day();
//     long var59 = var58.getFirstMillisecond();
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year();
//     java.util.Date var61 = var60.getStart();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var61);
//     boolean var63 = var58.equals((java.lang.Object)var62);
//     org.jfree.data.time.SerialDate var64 = var57.getEndOfCurrentMonth(var62);
//     boolean var65 = var50.isAfter(var62);
//     org.jfree.data.time.SpreadsheetDate var67 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var68 = new org.jfree.data.time.Year();
//     java.util.Date var69 = var68.getStart();
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.createInstance(var69);
//     org.jfree.data.time.Year var71 = new org.jfree.data.time.Year();
//     java.util.Date var72 = var71.getStart();
//     org.jfree.data.time.SerialDate var73 = org.jfree.data.time.SerialDate.createInstance(var72);
//     org.jfree.data.time.SerialDate var74 = var70.getEndOfCurrentMonth(var73);
//     org.jfree.data.time.Day var75 = new org.jfree.data.time.Day();
//     long var76 = var75.getFirstMillisecond();
//     org.jfree.data.time.Year var77 = new org.jfree.data.time.Year();
//     java.util.Date var78 = var77.getStart();
//     org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.createInstance(var78);
//     boolean var80 = var75.equals((java.lang.Object)var79);
//     org.jfree.data.time.SerialDate var81 = var74.getEndOfCurrentMonth(var79);
//     boolean var82 = var67.isAfter(var79);
//     boolean var83 = var50.isOnOrBefore((org.jfree.data.time.SerialDate)var67);
//     int var84 = var50.getYYYY();
//     int var85 = var50.toSerial();
//     boolean var87 = var18.isInRange(var48, (org.jfree.data.time.SerialDate)var50, 20);
//     java.lang.Object var88 = null;
//     int var89 = var18.compareTo(var88);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    var4.clear();
    int var11 = var4.getMaximumItemCount();
    int var12 = var4.getMaximumItemCount();
    java.lang.Class var14 = null;
    org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
    org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var18 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1.0f));
    org.jfree.data.time.RegularTimePeriod var19 = var15.getNextTimePeriod();
    var15.fireSeriesChanged();
    org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
    java.util.Date var22 = var21.getStart();
    org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(var22);
    org.jfree.data.time.RegularTimePeriod var24 = var23.next();
    java.util.Date var25 = var23.getEnd();
    var15.setKey((java.lang.Comparable)var25);
    org.jfree.data.time.Day var27 = new org.jfree.data.time.Day(var25);
    int var28 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.delete(20, 1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));

  }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
//     var2.fireSeriesChanged();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var11);
//     boolean var13 = var12.isEmpty();
//     var12.removeAgedItems(true);
//     java.beans.PropertyChangeListener var16 = null;
//     var12.removePropertyChangeListener(var16);
//     java.lang.Class var18 = var12.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var12.removeChangeListener(var19);
//     java.lang.String var21 = var12.getDescription();
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var12.removeChangeListener(var22);
//     java.lang.String var24 = var12.getDomainDescription();
//     java.lang.Comparable var25 = var12.getKey();
//     int var26 = var12.getMaximumItemCount();
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var28);
//     java.beans.PropertyChangeListener var30 = null;
//     var29.removePropertyChangeListener(var30);
//     java.lang.Comparable var32 = var29.getKey();
//     java.lang.Object var33 = new java.lang.Object();
//     boolean var34 = var29.equals(var33);
//     var29.removeAgedItems(true);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.lang.Class var39 = null;
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var39);
//     java.beans.PropertyChangeListener var41 = null;
//     var40.removePropertyChangeListener(var41);
//     java.lang.Comparable var43 = var40.getKey();
//     java.lang.Object var44 = new java.lang.Object();
//     boolean var45 = var40.equals(var44);
//     java.beans.PropertyChangeListener var46 = null;
//     var40.removePropertyChangeListener(var46);
//     int var48 = var37.compareTo((java.lang.Object)var46);
//     long var49 = var37.getFirstMillisecond();
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var51 = var50.getYear();
//     long var52 = var50.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var53 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var37, (org.jfree.data.time.RegularTimePeriod)var50);
//     org.jfree.data.time.TimeSeries var54 = var12.addAndOrUpdate(var29);
//     org.jfree.data.time.Month var55 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var56 = var55.getYear();
//     java.lang.String var57 = var56.toString();
//     org.jfree.data.time.Day var58 = new org.jfree.data.time.Day();
//     long var59 = var58.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var60 = var58.previous();
//     java.lang.Class var64 = null;
//     org.jfree.data.time.TimeSeries var65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var64);
//     java.lang.Object var66 = var65.clone();
//     org.jfree.data.time.FixedMillisecond var67 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var68 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var69 = var68.getYear();
//     int var70 = var67.compareTo((java.lang.Object)var68);
//     java.util.Calendar var71 = null;
//     long var72 = var67.getFirstMillisecond(var71);
//     java.util.Calendar var73 = null;
//     long var74 = var67.getFirstMillisecond(var73);
//     org.jfree.data.time.TimeSeriesDataItem var75 = var65.getDataItem((org.jfree.data.time.RegularTimePeriod)var67);
//     boolean var76 = var58.equals((java.lang.Object)var65);
//     org.jfree.data.time.TimeSeries var77 = var29.createCopy((org.jfree.data.time.RegularTimePeriod)var56, (org.jfree.data.time.RegularTimePeriod)var58);
//     org.jfree.data.time.TimeSeries var78 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var56);
//     org.jfree.data.time.FixedMillisecond var79 = new org.jfree.data.time.FixedMillisecond();
//     int var81 = var79.compareTo((java.lang.Object)1.0d);
//     java.util.Date var82 = var79.getTime();
//     java.util.Calendar var83 = null;
//     long var84 = var79.getLastMillisecond(var83);
//     long var85 = var79.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var86 = var79.next();
//     int var87 = var56.compareTo((java.lang.Object)var79);
//     org.jfree.data.time.TimeSeriesDataItem var89 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var56, 100.0d);
//     org.jfree.data.time.TimePeriodFormatException var91 = new org.jfree.data.time.TimePeriodFormatException("hi!");
//     boolean var92 = var56.equals((java.lang.Object)var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + ""+ "'", var24.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + '#'+ "'", var25.equals('#'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var32 + "' != '" + (short)(-1)+ "'", var32.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var43 + "' != '" + (short)(-1)+ "'", var43.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + "2014"+ "'", var57.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 1419159520394L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == 1419159520394L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1419159520395L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1419159520395L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var92 == false);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     var4.clear();
//     boolean var15 = var4.getNotify();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var17 = var16.getYear();
//     java.lang.String var18 = var16.toString();
//     org.jfree.data.time.RegularTimePeriod var19 = var16.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1419159514849L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "December 2014"+ "'", var18.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var1, var2);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
    boolean var5 = var4.isEmpty();
    var4.removeAgedItems(true);
    java.beans.PropertyChangeListener var8 = null;
    var4.removePropertyChangeListener(var8);
    java.lang.Class var10 = var4.getTimePeriodClass();
    java.util.Collection var11 = var4.getTimePeriods();
    var4.setRangeDescription("Preceding");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var4);
//     boolean var6 = var5.isEmpty();
//     var5.removeAgedItems(true);
//     java.beans.PropertyChangeListener var9 = null;
//     var5.removePropertyChangeListener(var9);
//     java.lang.Class var11 = var5.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var5.removeChangeListener(var12);
//     java.lang.String var14 = var5.getDescription();
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var5.removeChangeListener(var15);
//     java.lang.String var17 = var5.getDomainDescription();
//     java.lang.Comparable var18 = var5.getKey();
//     int var19 = var5.getMaximumItemCount();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var21);
//     java.beans.PropertyChangeListener var23 = null;
//     var22.removePropertyChangeListener(var23);
//     java.lang.Comparable var25 = var22.getKey();
//     java.lang.Object var26 = new java.lang.Object();
//     boolean var27 = var22.equals(var26);
//     var22.removeAgedItems(true);
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year();
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var32);
//     java.beans.PropertyChangeListener var34 = null;
//     var33.removePropertyChangeListener(var34);
//     java.lang.Comparable var36 = var33.getKey();
//     java.lang.Object var37 = new java.lang.Object();
//     boolean var38 = var33.equals(var37);
//     java.beans.PropertyChangeListener var39 = null;
//     var33.removePropertyChangeListener(var39);
//     int var41 = var30.compareTo((java.lang.Object)var39);
//     long var42 = var30.getFirstMillisecond();
//     org.jfree.data.time.Month var43 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var44 = var43.getYear();
//     long var45 = var43.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var46 = var22.createCopy((org.jfree.data.time.RegularTimePeriod)var30, (org.jfree.data.time.RegularTimePeriod)var43);
//     org.jfree.data.time.TimeSeries var47 = var5.addAndOrUpdate(var22);
//     org.jfree.data.time.Month var48 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var49 = var48.getYear();
//     java.lang.String var50 = var49.toString();
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     long var52 = var51.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var53 = var51.previous();
//     java.lang.Class var57 = null;
//     org.jfree.data.time.TimeSeries var58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var57);
//     java.lang.Object var59 = var58.clone();
//     org.jfree.data.time.FixedMillisecond var60 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var61 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var62 = var61.getYear();
//     int var63 = var60.compareTo((java.lang.Object)var61);
//     java.util.Calendar var64 = null;
//     long var65 = var60.getFirstMillisecond(var64);
//     java.util.Calendar var66 = null;
//     long var67 = var60.getFirstMillisecond(var66);
//     org.jfree.data.time.TimeSeriesDataItem var68 = var58.getDataItem((org.jfree.data.time.RegularTimePeriod)var60);
//     boolean var69 = var51.equals((java.lang.Object)var58);
//     org.jfree.data.time.TimeSeries var70 = var22.createCopy((org.jfree.data.time.RegularTimePeriod)var49, (org.jfree.data.time.RegularTimePeriod)var51);
//     org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var49);
//     int var72 = var49.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var73 = new org.jfree.data.time.Month(0, var49);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + '#'+ "'", var18.equals('#'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + (short)(-1)+ "'", var25.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + (short)(-1)+ "'", var36.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "2014"+ "'", var50.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1419159520809L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == 1419159520809L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 2014);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var13);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var18 = var14.getKey();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)10.0d);
//     java.lang.Object var22 = var21.clone();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year(var24);
//     boolean var26 = var21.equals((java.lang.Object)var24);
//     int var27 = var7.compareTo((java.lang.Object)var24);
//     long var28 = var7.getLastMillisecond();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     java.util.Date var34 = var33.getStart();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     java.util.Date var37 = var36.getStart();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var37);
//     org.jfree.data.time.SerialDate var39 = var35.getEndOfCurrentMonth(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.addMonths(0, var38);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     java.util.Date var42 = var41.getStart();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     java.util.Date var45 = var44.getStart();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.SerialDate var47 = var43.getEndOfCurrentMonth(var46);
//     org.jfree.data.time.SerialDate var48 = var38.getEndOfCurrentMonth(var47);
//     org.jfree.data.time.Year var49 = new org.jfree.data.time.Year();
//     java.util.Date var50 = var49.getStart();
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var50);
//     org.jfree.data.time.Year var52 = new org.jfree.data.time.Year();
//     java.util.Date var53 = var52.getStart();
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.createInstance(var53);
//     org.jfree.data.time.SerialDate var55 = var51.getEndOfCurrentMonth(var54);
//     java.lang.Class var58 = null;
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var54, "December 2014", "Sunday", var58);
//     boolean var61 = var31.isInRange(var48, var54, 2147483647);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addDays(1900, var54);
//     int var63 = var7.compareTo((java.lang.Object)1900);
//     java.util.Calendar var64 = null;
//     long var65 = var7.getFirstMillisecond(var64);
// 
//   }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("April", var1);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1419159520902L);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
    int var3 = var2.getDayOfMonth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 20);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("31-January-2014", var1);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.SerialDate var16 = var9.getEndOfCurrentMonth(var14);
//     boolean var17 = var2.isAfter(var14);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     long var19 = var18.getFirstMillisecond();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var21 = var20.getYear();
//     boolean var22 = var18.equals((java.lang.Object)var21);
//     int var23 = var18.getMonth();
//     org.jfree.data.time.SerialDate var24 = var18.getSerialDate();
//     boolean var25 = var2.isOnOrBefore(var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-572), var24);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == true);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.Collection var8 = var4.getTimePeriods();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.removeAgedItems(true);
//     java.util.List var17 = var13.getItems();
//     int var18 = var13.getItemCount();
//     var13.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var22 = var21.getYear();
//     long var23 = var21.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var13.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.TimeSeriesDataItem var26 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, 100.0d);
//     long var27 = var21.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1417420800000L);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     java.util.Date var5 = var4.getStart();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addMonths(0, var6);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day(var6);
//     java.util.Calendar var10 = null;
//     var9.peg(var10);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    java.lang.Comparable var6 = var2.getKey();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
    java.lang.Object var10 = var9.clone();
    java.lang.Number var11 = var9.getValue();
    org.jfree.data.time.RegularTimePeriod var12 = var9.getPeriod();
    java.lang.Object var13 = var9.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1.0f)+ "'", var11.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-435));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var4.removeChangeListener(var14);
//     java.lang.String var16 = var4.getDomainDescription();
//     java.lang.Comparable var17 = var4.getKey();
//     int var18 = var4.getMaximumItemCount();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var20);
//     java.beans.PropertyChangeListener var22 = null;
//     var21.removePropertyChangeListener(var22);
//     java.lang.Comparable var24 = var21.getKey();
//     java.lang.Object var25 = new java.lang.Object();
//     boolean var26 = var21.equals(var25);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var31);
//     java.beans.PropertyChangeListener var33 = null;
//     var32.removePropertyChangeListener(var33);
//     java.lang.Comparable var35 = var32.getKey();
//     java.lang.Object var36 = new java.lang.Object();
//     boolean var37 = var32.equals(var36);
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     int var40 = var29.compareTo((java.lang.Object)var38);
//     long var41 = var29.getFirstMillisecond();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var43 = var42.getYear();
//     long var44 = var42.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var45 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var29, (org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.data.time.TimeSeries var46 = var4.addAndOrUpdate(var21);
//     var46.clear();
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var49);
//     org.jfree.data.time.Month var51 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var53 = var50.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var51, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var54 = var50.getKey();
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var57 = var50.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var55, (java.lang.Number)10.0d);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year();
//     java.util.Date var60 = var59.getStart();
//     org.jfree.data.time.Year var61 = new org.jfree.data.time.Year(var60);
//     boolean var62 = var57.equals((java.lang.Object)var60);
//     org.jfree.data.time.Day var63 = new org.jfree.data.time.Day(var60);
//     org.jfree.data.time.TimeSeriesDataItem var65 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var63, 0.0d);
//     var46.add(var65);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     java.util.Date var41 = var40.getStart();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = var39.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     long var45 = var44.getFirstMillisecond();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     java.util.Date var47 = var46.getStart();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     boolean var49 = var44.equals((java.lang.Object)var48);
//     org.jfree.data.time.SerialDate var50 = var43.getEndOfCurrentMonth(var48);
//     boolean var51 = var36.isAfter(var48);
//     boolean var52 = var18.isAfter((org.jfree.data.time.SerialDate)var36);
//     int var53 = var36.getMonth();
//     java.util.Date var54 = var36.toDate();
//     java.util.Date var55 = var36.toDate();
//     org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(21);
//     int var58 = var57.toSerial();
//     org.jfree.data.time.Year var60 = new org.jfree.data.time.Year();
//     java.util.Date var61 = var60.getStart();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var61);
//     java.lang.String var63 = var62.getDescription();
//     java.lang.String var64 = var62.getDescription();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.addMonths((-460), var62);
//     boolean var66 = var57.isOnOrAfter(var65);
//     boolean var67 = var36.isOnOrBefore(var65);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var69 = var36.getPreviousDayOfWeek((-460));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == true);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)false, "Sun Dec 21 02:58:30 PST 2014", "", var3);
    java.util.List var5 = var4.getItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.String var12 = var7.toString();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     java.lang.Object var15 = var14.clone();
//     org.jfree.data.time.RegularTimePeriod var16 = var14.getPeriod();
//     java.lang.Number var17 = var14.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + (-1.0d)+ "'", var17.equals((-1.0d)));
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths((-435), var15);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(31, var15);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var2 = var1.getDescription();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var5 = var4.getYear();
//     int var6 = var3.compareTo((java.lang.Object)var4);
//     long var7 = var4.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var1.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, (-1.0d));
//     long var10 = var4.getSerialIndex();
//     org.jfree.data.time.Year var11 = var4.getYear();
//     boolean var13 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var4, (java.lang.Object)"First");
//     java.util.Date var14 = var4.getStart();
//     java.util.TimeZone var15 = null;
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(var14, var15);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.lang.String var2 = var1.toString();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getLastMillisecond(var3);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1);
//     java.util.Calendar var3 = null;
//     long var4 = var1.getFirstMillisecond(var3);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var3 = var1.equals((java.lang.Object)(-460));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var6 = var1.createCopy(7, (-572));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     int var17 = var1.toSerial();
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     int var35 = var19.toSerial();
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     java.lang.String var40 = var39.getDescription();
//     java.lang.String var41 = var39.getDescription();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.addMonths((-460), var39);
//     boolean var44 = var1.isInRange((org.jfree.data.time.SerialDate)var19, var39, 10);
//     java.util.Date var45 = var1.toDate();
//     java.util.TimeZone var46 = null;
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year(var45, var46);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)1419159520229L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419159506944L);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     long var10 = var7.getSerialIndex();
//     java.lang.String var11 = var7.toString();
//     java.lang.String var12 = var7.toString();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, (-1.0d));
//     long var15 = var7.getSerialIndex();
//     java.lang.String var16 = var7.toString();
//     org.jfree.data.time.RegularTimePeriod var17 = var7.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "2014"+ "'", var12.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "2014"+ "'", var16.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
    java.lang.Comparable var6 = var2.getKey();
    org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
    java.lang.Object var10 = var9.clone();
    org.jfree.data.time.RegularTimePeriod var11 = var9.getPeriod();
    org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var14 = var12.getDataItem(20);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    java.beans.PropertyChangeListener var3 = null;
    var2.removePropertyChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    java.util.Collection var6 = var2.getTimePeriods();
    boolean var7 = var2.getNotify();
    java.lang.Class var8 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(0, 2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)(-1)+ "'", var5.equals((short)(-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesException: ");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.SerialDate var16 = var9.getEndOfCurrentMonth(var14);
//     boolean var17 = var2.isAfter(var14);
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.util.Date var19 = var18.getStart();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.SerialDate var21 = var2.getEndOfCurrentMonth(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     java.util.Date var26 = var25.getStart();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(var26);
//     org.jfree.data.time.SerialDate var28 = var24.getEndOfCurrentMonth(var27);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     long var30 = var29.getFirstMillisecond();
//     org.jfree.data.time.Year var31 = new org.jfree.data.time.Year();
//     java.util.Date var32 = var31.getStart();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     boolean var34 = var29.equals((java.lang.Object)var33);
//     org.jfree.data.time.SerialDate var35 = var28.getEndOfCurrentMonth(var33);
//     org.jfree.data.time.SpreadsheetDate var37 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var38 = new org.jfree.data.time.Year();
//     java.util.Date var39 = var38.getStart();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     java.util.Date var42 = var41.getStart();
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var42);
//     org.jfree.data.time.SerialDate var44 = var40.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     long var46 = var45.getFirstMillisecond();
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year();
//     java.util.Date var48 = var47.getStart();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(var48);
//     boolean var50 = var45.equals((java.lang.Object)var49);
//     org.jfree.data.time.SerialDate var51 = var44.getEndOfCurrentMonth(var49);
//     boolean var52 = var37.isAfter(var49);
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year();
//     java.util.Date var54 = var53.getStart();
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(var54);
//     org.jfree.data.time.SerialDate var56 = var37.getEndOfCurrentMonth(var55);
//     org.jfree.data.time.SerialDate var57 = var33.getEndOfCurrentMonth(var56);
//     int var58 = var2.compareTo((java.lang.Object)var56);
//     org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(1, (org.jfree.data.time.SerialDate)var2);
//     org.jfree.data.time.Year var61 = new org.jfree.data.time.Year();
//     java.util.Date var62 = var61.getStart();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     org.jfree.data.time.Year var64 = new org.jfree.data.time.Year();
//     java.util.Date var65 = var64.getStart();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var65);
//     org.jfree.data.time.SerialDate var67 = var63.getEndOfCurrentMonth(var66);
//     boolean var68 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)(short)0, (java.lang.Object)var63);
//     int var69 = var2.compare(var63);
//     int var70 = var2.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == (-41649));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == (-41619));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 1);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var12);
//     boolean var14 = var9.equals((java.lang.Object)var12);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var12);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     long var17 = var16.getFirstMillisecond();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var19 = var18.getYear();
//     boolean var20 = var16.equals((java.lang.Object)var19);
//     int var21 = var16.getMonth();
//     boolean var22 = var15.equals((java.lang.Object)var16);
//     long var23 = var15.getLastMillisecond();
//     java.util.Calendar var24 = null;
//     var15.peg(var24);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     var4.setMaximumItemAge(10L);
//     int var8 = var4.getMaximumItemCount();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = var9.getYear();
//     long var12 = var9.getSerialIndex();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Value", var1);
// 
//   }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.Collection var8 = var4.getTimePeriods();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.removeAgedItems(true);
//     java.util.List var17 = var13.getItems();
//     int var18 = var13.getItemCount();
//     var13.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var22 = var21.getYear();
//     long var23 = var21.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var24 = var13.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     org.jfree.data.time.TimeSeriesDataItem var26 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, 100.0d);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     java.util.TimeZone var30 = null;
//     org.jfree.data.time.RegularTimePeriod var31 = org.jfree.data.time.RegularTimePeriod.createInstance(var27, var29, var30);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var29);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(var29);
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.lang.String var36 = var35.getDescription();
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var39 = var38.getYear();
//     int var40 = var37.compareTo((java.lang.Object)var38);
//     long var41 = var38.getLastMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var43 = var35.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var38, (-1.0d));
//     org.jfree.data.time.TimeSeries var44 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var33, (org.jfree.data.time.RegularTimePeriod)var38);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     int var2 = var0.getMonth();
//     long var3 = var0.getFirstMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var0 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var2 = var1.getYear();
//     int var3 = var0.compareTo((java.lang.Object)var1);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
//     int var7 = var0.compareTo((java.lang.Object)520764324);
//     java.util.Calendar var8 = null;
//     long var9 = var0.getFirstMillisecond(var8);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var11);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var16 = var12.getKey();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)10.0d);
//     long var20 = var17.getSerialIndex();
//     java.lang.String var21 = var17.toString();
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var23);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var27 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var28 = var24.getKey();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var31 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, (java.lang.Number)10.0d);
//     java.lang.Object var32 = var31.clone();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     java.util.Date var34 = var33.getStart();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year(var34);
//     boolean var36 = var31.equals((java.lang.Object)var34);
//     int var37 = var17.compareTo((java.lang.Object)var34);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var34);
//     var38.setDescription("ERROR : Relative To String");
//     java.lang.String var41 = var38.toString();
//     int var42 = var0.compareTo((java.lang.Object)var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419159521832L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419159521832L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + (short)(-1)+ "'", var16.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "2014"+ "'", var21.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var28 + "' != '" + (short)(-1)+ "'", var28.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + "1-January-2014"+ "'", var41.equals("1-January-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(21, 1900, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=0]", var1);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var3 = var1.equals((java.lang.Object)(-460));
//     int var4 = var1.getMaximumItemCount();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var6);
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var10 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var12 = var11.getYear();
//     long var13 = var11.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var14 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var8, (org.jfree.data.time.RegularTimePeriod)var11);
//     org.jfree.data.time.RegularTimePeriod var15 = var11.previous();
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var19);
//     boolean var21 = var20.isEmpty();
//     var20.removeAgedItems(true);
//     java.util.List var24 = var20.getItems();
//     int var25 = var20.getItemCount();
//     int var26 = var11.compareTo((java.lang.Object)var20);
//     int var27 = var11.getYearValue();
//     long var28 = var11.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 24180L);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     java.util.Date var7 = var6.getStart();
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.SerialDate var9 = var5.getEndOfCurrentMonth(var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     java.util.Date var13 = var12.getStart();
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(var13);
//     boolean var15 = var10.equals((java.lang.Object)var14);
//     org.jfree.data.time.SerialDate var16 = var9.getEndOfCurrentMonth(var14);
//     boolean var17 = var2.isAfter(var14);
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     java.util.Date var21 = var20.getStart();
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     java.util.Date var24 = var23.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var26 = var22.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     long var28 = var27.getFirstMillisecond();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     boolean var32 = var27.equals((java.lang.Object)var31);
//     org.jfree.data.time.SerialDate var33 = var26.getEndOfCurrentMonth(var31);
//     boolean var34 = var19.isAfter(var31);
//     boolean var35 = var2.isOnOrBefore((org.jfree.data.time.SerialDate)var19);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     java.util.Date var37 = var36.getStart();
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var37);
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     java.util.Date var40 = var39.getStart();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(var40);
//     org.jfree.data.time.SerialDate var42 = var38.getEndOfCurrentMonth(var41);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     long var44 = var43.getFirstMillisecond();
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     java.util.Date var46 = var45.getStart();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var46);
//     boolean var48 = var43.equals((java.lang.Object)var47);
//     org.jfree.data.time.SerialDate var49 = var42.getEndOfCurrentMonth(var47);
//     org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var52 = new org.jfree.data.time.Year();
//     java.util.Date var53 = var52.getStart();
//     org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.createInstance(var53);
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year();
//     java.util.Date var56 = var55.getStart();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.SerialDate var58 = var54.getEndOfCurrentMonth(var57);
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day();
//     long var60 = var59.getFirstMillisecond();
//     org.jfree.data.time.Year var61 = new org.jfree.data.time.Year();
//     java.util.Date var62 = var61.getStart();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     boolean var64 = var59.equals((java.lang.Object)var63);
//     org.jfree.data.time.SerialDate var65 = var58.getEndOfCurrentMonth(var63);
//     boolean var66 = var51.isAfter(var63);
//     org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var69 = new org.jfree.data.time.Year();
//     java.util.Date var70 = var69.getStart();
//     org.jfree.data.time.SerialDate var71 = org.jfree.data.time.SerialDate.createInstance(var70);
//     org.jfree.data.time.Year var72 = new org.jfree.data.time.Year();
//     java.util.Date var73 = var72.getStart();
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(var73);
//     org.jfree.data.time.SerialDate var75 = var71.getEndOfCurrentMonth(var74);
//     org.jfree.data.time.Day var76 = new org.jfree.data.time.Day();
//     long var77 = var76.getFirstMillisecond();
//     org.jfree.data.time.Year var78 = new org.jfree.data.time.Year();
//     java.util.Date var79 = var78.getStart();
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(var79);
//     boolean var81 = var76.equals((java.lang.Object)var80);
//     org.jfree.data.time.SerialDate var82 = var75.getEndOfCurrentMonth(var80);
//     boolean var83 = var68.isAfter(var80);
//     boolean var84 = var51.isOnOrBefore((org.jfree.data.time.SerialDate)var68);
//     int var85 = var51.getYYYY();
//     int var86 = var51.toSerial();
//     boolean var88 = var19.isInRange(var49, (org.jfree.data.time.SerialDate)var51, 20);
//     org.jfree.data.time.SerialDate var89 = org.jfree.data.time.SerialDate.addDays(0, (org.jfree.data.time.SerialDate)var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var89);
// 
//   }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Date var1 = var0.getStart();
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(var1);
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year();
//     java.util.Date var4 = var3.getStart();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = var2.getEndOfCurrentMonth(var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     java.util.Date var10 = var9.getStart();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var12 = var7.equals((java.lang.Object)var11);
//     org.jfree.data.time.SerialDate var13 = var6.getEndOfCurrentMonth(var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var15 = var11.getFollowingDayOfWeek((-435));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.util.List var8 = var4.getItems();
//     int var9 = var4.getItemCount();
//     var4.setDomainDescription("SerialDate.weekInMonthToString(): invalid code.");
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var13 = var12.getYear();
//     long var14 = var12.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var12);
//     long var16 = var4.getMaximumItemAge();
//     boolean var17 = var4.getNotify();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.util.Date var19 = var18.getStart();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.SerialDate var24 = var20.getEndOfCurrentMonth(var23);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var23, "December 2014", "Sunday", var27);
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var30 = var29.getYear();
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var30);
//     org.jfree.data.time.RegularTimePeriod var32 = var30.next();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     java.util.Date var34 = var33.getStart();
//     org.jfree.data.time.RegularTimePeriod var35 = var33.next();
//     org.jfree.data.time.TimeSeries var36 = var28.createCopy(var32, var35);
//     var4.add(var32, (java.lang.Number)1419159506279L, true);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
    boolean var6 = var4.equals((java.lang.Object)(-460));
    int var7 = var4.getMaximumItemCount();
    var4.setRangeDescription("hi!");
    org.jfree.data.time.TimeSeries var10 = var2.addAndOrUpdate(var4);
    int var11 = var10.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.update(2147483647, (java.lang.Number)1419159512213L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var11);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.RegularTimePeriod var16 = var12.getNextTimePeriod();
//     var12.fireSeriesChanged();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     java.util.Date var19 = var18.getStart();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year(var19);
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     java.util.Date var22 = var20.getEnd();
//     var12.setKey((java.lang.Comparable)var22);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var22);
//     long var25 = var24.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1419159514014L, true);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     java.util.Date var11 = var10.getStart();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     java.util.Date var14 = var13.getStart();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = var12.getEndOfCurrentMonth(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     long var18 = var17.getFirstMillisecond();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     boolean var22 = var17.equals((java.lang.Object)var21);
//     org.jfree.data.time.SerialDate var23 = var16.getEndOfCurrentMonth(var21);
//     int var24 = var7.compareTo((java.lang.Object)var23);
//     org.jfree.data.time.RegularTimePeriod var25 = var7.previous();
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     int var28 = var26.getMonth();
//     long var29 = var26.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var30 = var26.previous();
//     int var31 = var7.compareTo((java.lang.Object)var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0);
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     java.lang.Object var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     int var4 = var1.compareTo((java.lang.Object)var2);
//     java.util.Calendar var5 = null;
//     long var6 = var1.getFirstMillisecond(var5);
//     java.util.Calendar var7 = null;
//     long var8 = var1.getMiddleMillisecond(var7);
//     int var10 = var1.compareTo((java.lang.Object)1L);
//     boolean var11 = org.jfree.chart.util.ObjectUtilities.equal(var0, (java.lang.Object)1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1419159522929L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419159522929L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Preceding", var1);
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     java.util.Date var2 = var1.getStart();
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     java.util.Date var5 = var4.getStart();
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.SerialDate var7 = var3.getEndOfCurrentMonth(var6);
//     java.lang.String var8 = var3.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2014, var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1-January-2014"+ "'", var8.equals("1-January-2014"));
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var8 = var7.getYear();
//     int var9 = var6.compareTo((java.lang.Object)var7);
//     java.util.Calendar var10 = null;
//     long var11 = var6.getFirstMillisecond(var10);
//     java.util.Calendar var12 = null;
//     long var13 = var6.getFirstMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     var4.removeAgedItems(1419159516967L, false);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.clear();
//     var4.setMaximumItemAge(10L);
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"October");
//     boolean var11 = var9.equals((java.lang.Object)(-460));
//     int var12 = var9.getMaximumItemCount();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var14);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var18 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(-1.0f));
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var20 = var19.getYear();
//     long var21 = var19.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var22 = var9.createCopy((org.jfree.data.time.RegularTimePeriod)var16, (org.jfree.data.time.RegularTimePeriod)var19);
//     boolean var23 = var4.equals((java.lang.Object)var9);
//     var9.setDescription("December 2014");
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var9.update(1900, (java.lang.Number)1419159514089L);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.SpreadsheetDate var18 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     java.util.Date var23 = var22.getStart();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     org.jfree.data.time.SerialDate var25 = var21.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     java.util.Date var29 = var28.getStart();
//     org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(var29);
//     boolean var31 = var26.equals((java.lang.Object)var30);
//     org.jfree.data.time.SerialDate var32 = var25.getEndOfCurrentMonth(var30);
//     boolean var33 = var18.isAfter(var30);
//     boolean var34 = var1.isOnOrBefore((org.jfree.data.time.SerialDate)var18);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     java.util.Date var38 = var37.getStart();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.Year var40 = new org.jfree.data.time.Year();
//     java.util.Date var41 = var40.getStart();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.SerialDate var43 = var39.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     long var45 = var44.getFirstMillisecond();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     java.util.Date var47 = var46.getStart();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(var47);
//     boolean var49 = var44.equals((java.lang.Object)var48);
//     org.jfree.data.time.SerialDate var50 = var43.getEndOfCurrentMonth(var48);
//     boolean var51 = var36.isAfter(var48);
//     boolean var52 = var18.isAfter((org.jfree.data.time.SerialDate)var36);
//     int var53 = var36.toSerial();
//     java.lang.String var54 = var36.toString();
//     org.jfree.data.time.Year var56 = new org.jfree.data.time.Year();
//     java.util.Date var57 = var56.getStart();
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var57);
//     org.jfree.data.time.Year var59 = new org.jfree.data.time.Year();
//     java.util.Date var60 = var59.getStart();
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var60);
//     org.jfree.data.time.SerialDate var62 = var58.getEndOfCurrentMonth(var61);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.addMonths(0, var61);
//     org.jfree.data.time.Year var64 = new org.jfree.data.time.Year();
//     java.util.Date var65 = var64.getStart();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var65);
//     org.jfree.data.time.Year var67 = new org.jfree.data.time.Year();
//     java.util.Date var68 = var67.getStart();
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.createInstance(var68);
//     org.jfree.data.time.SerialDate var70 = var66.getEndOfCurrentMonth(var69);
//     org.jfree.data.time.SerialDate var71 = var61.getEndOfCurrentMonth(var70);
//     org.jfree.data.time.SerialDate var72 = null;
//     boolean var74 = var36.isInRange(var61, var72, (-11));
// 
//   }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.removeAgedItems(true);
//     java.beans.PropertyChangeListener var8 = null;
//     var4.removePropertyChangeListener(var8);
//     java.lang.Class var10 = var4.getTimePeriodClass();
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var4.removeChangeListener(var11);
//     java.lang.String var13 = var4.getDescription();
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var4.removeChangeListener(var14);
//     java.lang.String var16 = var4.getDomainDescription();
//     java.lang.Comparable var17 = var4.getKey();
//     int var18 = var4.getMaximumItemCount();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var20);
//     java.beans.PropertyChangeListener var22 = null;
//     var21.removePropertyChangeListener(var22);
//     java.lang.Comparable var24 = var21.getKey();
//     java.lang.Object var25 = new java.lang.Object();
//     boolean var26 = var21.equals(var25);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var31);
//     java.beans.PropertyChangeListener var33 = null;
//     var32.removePropertyChangeListener(var33);
//     java.lang.Comparable var35 = var32.getKey();
//     java.lang.Object var36 = new java.lang.Object();
//     boolean var37 = var32.equals(var36);
//     java.beans.PropertyChangeListener var38 = null;
//     var32.removePropertyChangeListener(var38);
//     int var40 = var29.compareTo((java.lang.Object)var38);
//     long var41 = var29.getFirstMillisecond();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var43 = var42.getYear();
//     long var44 = var42.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var45 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var29, (org.jfree.data.time.RegularTimePeriod)var42);
//     org.jfree.data.time.TimeSeries var46 = var4.addAndOrUpdate(var21);
//     org.jfree.data.time.Month var47 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var48 = var47.getYear();
//     java.lang.String var49 = var48.toString();
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     long var51 = var50.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var52 = var50.previous();
//     java.lang.Class var56 = null;
//     org.jfree.data.time.TimeSeries var57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var56);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.data.time.FixedMillisecond var59 = new org.jfree.data.time.FixedMillisecond();
//     org.jfree.data.time.Month var60 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var61 = var60.getYear();
//     int var62 = var59.compareTo((java.lang.Object)var60);
//     java.util.Calendar var63 = null;
//     long var64 = var59.getFirstMillisecond(var63);
//     java.util.Calendar var65 = null;
//     long var66 = var59.getFirstMillisecond(var65);
//     org.jfree.data.time.TimeSeriesDataItem var67 = var57.getDataItem((org.jfree.data.time.RegularTimePeriod)var59);
//     boolean var68 = var50.equals((java.lang.Object)var57);
//     org.jfree.data.time.TimeSeries var69 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var48, (org.jfree.data.time.RegularTimePeriod)var50);
//     org.jfree.data.time.TimeSeries var70 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var48);
//     int var71 = var48.getYear();
//     java.lang.String var72 = var48.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + '#'+ "'", var17.equals('#'));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2147483647);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + (short)(-1)+ "'", var24.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var35 + "' != '" + (short)(-1)+ "'", var35.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "2014"+ "'", var49.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1419159523408L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1419159523408L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var72 + "' != '" + "2014"+ "'", var72.equals("2014"));
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("Sunday");

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var3);
//     var4.setKey((java.lang.Comparable)"October");
//     org.jfree.data.time.TimeSeries var9 = var4.createCopy(0, 0);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var11);
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var16 = var12.getKey();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)10.0d);
//     java.lang.Object var20 = var19.clone();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     java.util.Date var22 = var21.getStart();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(var22);
//     boolean var24 = var19.equals((java.lang.Object)var22);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day(var22);
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 0.0d);
//     var4.add(var27, false);
// 
//   }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     int var5 = var0.getMonth();
//     org.jfree.data.time.SerialDate var6 = var0.getSerialDate();
//     long var7 = var0.getLastMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var0.getLastMillisecond(var8);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var1);
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var5 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var6 = var2.getKey();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10.0d);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     java.util.Date var11 = var10.getStart();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     java.util.Date var14 = var13.getStart();
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var14);
//     org.jfree.data.time.SerialDate var16 = var12.getEndOfCurrentMonth(var15);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     long var18 = var17.getFirstMillisecond();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     java.util.Date var20 = var19.getStart();
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var20);
//     boolean var22 = var17.equals((java.lang.Object)var21);
//     org.jfree.data.time.SerialDate var23 = var16.getEndOfCurrentMonth(var21);
//     int var24 = var7.compareTo((java.lang.Object)var23);
//     java.lang.Class var28 = null;
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)'#', "", "", var28);
//     boolean var30 = var29.isEmpty();
//     var29.removeAgedItems(true);
//     java.beans.PropertyChangeListener var33 = null;
//     var29.removePropertyChangeListener(var33);
//     java.lang.Class var35 = var29.getTimePeriodClass();
//     java.util.Collection var36 = var29.getTimePeriods();
//     java.util.Collection var37 = var29.getTimePeriods();
//     java.lang.Object var38 = var29.clone();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1), var40);
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeriesDataItem var44 = var41.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var42, (java.lang.Number)(-1.0f));
//     java.lang.Comparable var45 = var41.getKey();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     org.jfree.data.time.TimeSeriesDataItem var48 = var41.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var46, (java.lang.Number)10.0d);
//     long var49 = var46.getSerialIndex();
//     java.lang.String var50 = var46.toString();
//     java.lang.String var51 = var46.toString();
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var46, (-1.0d));
//     java.lang.Object var54 = var53.clone();
//     org.jfree.data.time.RegularTimePeriod var55 = var53.getPeriod();
//     java.lang.Number var56 = var29.getValue(var55);
//     boolean var57 = var7.equals((java.lang.Object)var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + (short)(-1)+ "'", var6.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var45 + "' != '" + (short)(-1)+ "'", var45.equals((short)(-1)));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "2014"+ "'", var50.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + "2014"+ "'", var51.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == true);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year();
//     java.util.Date var3 = var2.getStart();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     java.util.Date var6 = var5.getStart();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.SerialDate var8 = var4.getEndOfCurrentMonth(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     long var10 = var9.getFirstMillisecond();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     java.util.Date var12 = var11.getStart();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var14 = var9.equals((java.lang.Object)var13);
//     org.jfree.data.time.SerialDate var15 = var8.getEndOfCurrentMonth(var13);
//     boolean var16 = var1.isAfter(var13);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     java.util.Date var18 = var17.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.SerialDate var20 = var1.getEndOfCurrentMonth(var19);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate)var1);
//     org.jfree.data.time.SerialDate var22 = null;
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     java.util.Date var27 = var26.getStart();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     java.util.Date var30 = var29.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.SerialDate var32 = var28.getEndOfCurrentMonth(var31);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     long var34 = var33.getFirstMillisecond();
//     org.jfree.data.time.Year var35 = new org.jfree.data.time.Year();
//     java.util.Date var36 = var35.getStart();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     boolean var38 = var33.equals((java.lang.Object)var37);
//     org.jfree.data.time.SerialDate var39 = var32.getEndOfCurrentMonth(var37);
//     boolean var40 = var25.isAfter(var37);
//     int var41 = var25.toSerial();
//     org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(21);
//     org.jfree.data.time.Year var44 = new org.jfree.data.time.Year();
//     java.util.Date var45 = var44.getStart();
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year();
//     java.util.Date var48 = var47.getStart();
//     org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.createInstance(var48);
//     org.jfree.data.time.SerialDate var50 = var46.getEndOfCurrentMonth(var49);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     long var52 = var51.getFirstMillisecond();
//     org.jfree.data.time.Year var53 = new org.jfree.data.time.Year();
//     java.util.Date var54 = var53.getStart();
//     org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(var54);
//     boolean var56 = var51.equals((java.lang.Object)var55);
//     org.jfree.data.time.SerialDate var57 = var50.getEndOfCurrentMonth(var55);
//     boolean var58 = var43.isAfter(var55);
//     int var59 = var43.toSerial();
//     org.jfree.data.time.Year var61 = new org.jfree.data.time.Year();
//     java.util.Date var62 = var61.getStart();
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var62);
//     java.lang.String var64 = var63.getDescription();
//     java.lang.String var65 = var63.getDescription();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.addMonths((-460), var63);
//     boolean var68 = var25.isInRange((org.jfree.data.time.SerialDate)var43, var63, 10);
//     org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(7, (org.jfree.data.time.SerialDate)var43);
//     boolean var71 = var1.isInRange(var22, (org.jfree.data.time.SerialDate)var43, (-11));
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("21-December-2014", var1);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("21-December-2014");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

}
