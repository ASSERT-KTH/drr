
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    var50.clearRangeAxes();
    org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
    java.awt.Paint var55 = var50.getRangeCrosshairPaint();
    java.awt.Paint var56 = var50.getDomainGridlinePaint();
    org.jfree.chart.event.RendererChangeEvent var57 = null;
    var50.rendererChanged(var57);
    org.jfree.chart.plot.DatasetRenderingOrder var59 = var50.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = var50.getRenderer((-10));
    org.jfree.chart.axis.CategoryAxis var56 = var50.getDomainAxisForDataset(100);
    org.jfree.chart.annotations.CategoryAnnotation var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var58 = var50.removeAnnotation(var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "hi!", "hi!", "");
    java.lang.String var8 = var7.getLicenceText();
    java.awt.Image var9 = null;
    var7.setLogo(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + ""+ "'", var8.equals(""));

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var4.setDomainAxis(0, var6, true);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
//     var4.setRangeAxisLocation(0, var16);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.data.Range var24 = var23.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     org.jfree.chart.axis.AxisLocation var34 = var32.getDomainAxisLocation(100);
//     var32.setBackgroundAlpha(0.0f);
//     var32.setDomainCrosshairValue(100.0d, false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var40};
//     var32.setRenderers(var41);
//     var18.setSources((org.jfree.chart.LegendItemSource[])var41);
//     org.jfree.chart.util.RectangleInsets var44 = var18.getLegendItemGraphicPadding();
//     org.jfree.chart.util.VerticalAlignment var45 = var18.getVerticalAlignment();
//     org.jfree.chart.text.TextLine var47 = new org.jfree.chart.text.TextLine("");
//     org.jfree.data.xy.XYDataset var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
//     org.jfree.chart.axis.AxisLocation var54 = var52.getDomainAxisLocation(100);
//     int var55 = var52.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     var52.setRenderer(var56);
//     org.jfree.chart.util.RectangleInsets var62 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var64 = var62.calculateRightOutset(10.0d);
//     var52.setInsets(var62);
//     boolean var66 = var47.equals((java.lang.Object)var52);
//     org.jfree.chart.text.TextFragment var68 = new org.jfree.chart.text.TextFragment("hi!");
//     var47.addFragment(var68);
//     float var70 = var68.getBaselineOffset();
//     java.awt.Font var71 = var68.getFont();
//     java.awt.Paint var72 = var68.getPaint();
//     boolean var73 = var45.equals((java.lang.Object)var68);
//     java.awt.Graphics2D var74 = null;
//     org.jfree.chart.plot.ValueMarker var78 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var78.setLabel("");
//     org.jfree.chart.text.TextAnchor var81 = var78.getLabelTextAnchor();
//     java.lang.String var82 = var81.toString();
//     var68.draw(var74, (-1.0f), 100.0f, var81, 1.0f, (-1.0f), 0.0d);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
//     int var7 = var4.getDatasetCount();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.CrosshairState var12 = null;
//     boolean var13 = var4.render(var8, var9, 1, var11, var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     java.awt.Paint var19 = var18.getRangeCrosshairPaint();
//     var4.setRangeGridlinePaint(var19);
//     org.jfree.chart.axis.AxisSpace var21 = null;
//     var4.setFixedDomainAxisSpace(var21);
//     java.awt.Paint var23 = var4.getBackgroundPaint();
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var4.zoomDomainAxes(0.0d, var25, var26);
//     boolean var28 = var4.isRangeCrosshairLockedOnData();
//     org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var31.setLabel("");
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     var38.setDomainAxis(0, var40, true);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
//     org.jfree.chart.axis.AxisLocation var50 = var48.getDomainAxisLocation(100);
//     var38.setRangeAxisLocation(0, var50);
//     org.jfree.chart.JFreeChart var53 = null;
//     org.jfree.chart.event.ChartProgressEvent var56 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0.0d, var53, (-1), 1);
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var58, var59, var60, var61);
//     boolean var63 = var62.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     int var65 = var62.getDomainAxisIndex(var64);
//     var62.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var69 = null;
//     var62.setFixedRangeAxisSpace(var69, false);
//     org.jfree.chart.util.RectangleInsets var72 = var62.getInsets();
//     org.jfree.chart.JFreeChart var73 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var62);
//     org.jfree.chart.event.ChartChangeEventType var74 = null;
//     org.jfree.chart.event.ChartChangeEvent var75 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1, var73, var74);
//     org.jfree.chart.util.RectangleInsets var76 = var73.getPadding();
//     org.jfree.chart.event.ChartProgressListener var77 = null;
//     var73.removeProgressListener(var77);
//     java.awt.Paint var79 = var73.getBackgroundPaint();
//     var38.setRangeTickBandPaint(var79);
//     var31.setLabelPaint(var79);
//     java.awt.Font var82 = var31.getLabelFont();
//     org.jfree.chart.util.Layer var83 = null;
//     boolean var84 = var4.removeRangeMarker((-1), (org.jfree.chart.plot.Marker)var31, var83);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    float var6 = var4.getBackgroundAlpha();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var4.zoomRangeAxes((-1.0d), var8, var9);
    java.awt.Stroke var11 = var4.getDomainGridlineStroke();
    org.jfree.data.xy.XYDataset var13 = null;
    var4.setDataset(100, var13);
    org.jfree.chart.util.RectangleInsets var15 = var4.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var24 = var23.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.chart.axis.AxisLocation var34 = var32.getDomainAxisLocation(100);
    var32.setBackgroundAlpha(0.0f);
    var32.setDomainCrosshairValue(100.0d, false);
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var41 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var40};
    var32.setRenderers(var41);
    var18.setSources((org.jfree.chart.LegendItemSource[])var41);
    org.jfree.chart.util.RectangleInsets var44 = var18.getLegendItemGraphicPadding();
    org.jfree.chart.util.VerticalAlignment var45 = var18.getVerticalAlignment();
    double var46 = var18.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.0d);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var4.setDomainAxis(0, var6, true);
//     java.awt.Graphics2D var9 = null;
//     java.awt.Font var11 = null;
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var14 = var13.getPaint();
//     org.jfree.chart.text.TextMeasurer var17 = null;
//     org.jfree.chart.text.TextBlock var18 = org.jfree.chart.text.TextUtilities.createTextBlock("", var11, var14, 10.0f, 0, var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.util.Size2D var20 = var18.calculateDimensions(var19);
//     var20.setWidth(1.0d);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var25, var26, var27, var28);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     var29.setDomainAxis(0, var31, true);
//     org.jfree.data.xy.XYDataset var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
//     org.jfree.chart.axis.AxisLocation var41 = var39.getDomainAxisLocation(100);
//     var29.setRangeAxisLocation(0, var41);
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29);
//     java.awt.Paint var44 = var43.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var45 = var43.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, 100.0d, 10.0d, var45);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     org.jfree.chart.plot.CrosshairState var49 = null;
//     boolean var50 = var4.render(var9, var46, 0, var48, var49);
//     
//     // Checks the contract:  equals-hashcode on var4 and var39
//     assertTrue("Contract failed: equals-hashcode on var4 and var39", var4.equals(var39) ? var4.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var4
//     assertTrue("Contract failed: equals-hashcode on var39 and var4", var39.equals(var4) ? var39.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var3 = var2.getAxisLineStroke();
    java.awt.Font var4 = var2.getLabelFont();
    org.jfree.chart.axis.CategoryLabelPositions var5 = var2.getCategoryLabelPositions();
    java.awt.Font var6 = var2.getTickLabelFont();
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    org.jfree.chart.axis.AxisLocation var13 = var11.getDomainAxisLocation(100);
    var11.setBackgroundAlpha(0.0f);
    var11.setDomainCrosshairValue(100.0d, false);
    org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart("java.awt.Color[r=0,g=0,b=100]", var6, (org.jfree.chart.plot.Plot)var11, false);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.ValueAxis var27 = null;
    var25.setDomainAxis(0, var27, true);
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
    org.jfree.chart.axis.AxisLocation var37 = var35.getDomainAxisLocation(100);
    var25.setRangeAxisLocation(0, var37);
    org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
    java.awt.Paint var40 = var39.getBackgroundPaint();
    var39.setHeight(111.0d);
    double var43 = var39.getContentXOffset();
    var39.setID("");
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    boolean var52 = var51.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var53 = null;
    int var54 = var51.getDomainAxisIndex(var53);
    var51.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var58 = null;
    var51.setFixedRangeAxisSpace(var58, false);
    org.jfree.chart.util.RectangleInsets var61 = var51.getInsets();
    org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var51);
    java.awt.Stroke var63 = var62.getBorderStroke();
    org.jfree.chart.plot.Plot var64 = var62.getPlot();
    java.awt.RenderingHints var65 = var62.getRenderingHints();
    org.jfree.chart.title.LegendTitle var66 = var62.getLegend();
    var39.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var62);
    double var68 = var39.getHeight();
    var20.addSubtitle((org.jfree.chart.title.Title)var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 111.0d);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var7.setLabel("");
//     org.jfree.chart.text.TextAnchor var10 = var7.getLabelTextAnchor();
//     java.awt.Shape var11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=0,g=0,b=142]", var1, 100.0f, 0.0f, var4, 1.0d, var10);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var4 = var3.getPaint();
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.util.Size2D var10 = var8.calculateDimensions(var9);
//     double var11 = var10.getWidth();
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     int var17 = var16.getDatasetCount();
//     int var18 = var16.getSeriesCount();
//     boolean var19 = var10.equals((java.lang.Object)var16);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     org.jfree.chart.axis.AxisLocation var26 = var24.getDomainAxisLocation(100);
//     int var27 = var24.getDatasetCount();
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.chart.plot.CrosshairState var32 = null;
//     boolean var33 = var24.render(var28, var29, 1, var31, var32);
//     java.awt.Paint var35 = var24.getQuadrantPaint(0);
//     org.jfree.data.xy.XYDataset var36 = null;
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var36, var37, var38, var39);
//     org.jfree.chart.axis.AxisLocation var42 = var40.getDomainAxisLocation(100);
//     int var43 = var40.getDatasetCount();
//     java.awt.Graphics2D var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     org.jfree.chart.plot.CrosshairState var48 = null;
//     boolean var49 = var40.render(var44, var45, 1, var47, var48);
//     org.jfree.data.xy.XYDataset var50 = null;
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var50, var51, var52, var53);
//     java.awt.Paint var55 = var54.getRangeCrosshairPaint();
//     var40.setRangeGridlinePaint(var55);
//     org.jfree.chart.axis.AxisSpace var57 = null;
//     var40.setFixedDomainAxisSpace(var57);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     java.awt.geom.Point2D var61 = null;
//     var40.zoomDomainAxes((-1.0d), var60, var61, true);
//     java.awt.Color var66 = java.awt.Color.getColor("", 100);
//     var40.setDomainTickBandPaint((java.awt.Paint)var66);
//     int var68 = var66.getTransparency();
//     var24.setDomainGridlinePaint((java.awt.Paint)var66);
//     var16.setRangeCrosshairPaint((java.awt.Paint)var66);
//     org.jfree.data.xy.XYDataset var71 = null;
//     org.jfree.chart.axis.ValueAxis var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var74 = null;
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot(var71, var72, var73, var74);
//     org.jfree.chart.axis.AxisLocation var77 = var75.getDomainAxisLocation(100);
//     var75.setBackgroundAlpha(0.0f);
//     org.jfree.data.xy.XYDataset var80 = null;
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.axis.ValueAxis var82 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var83 = null;
//     org.jfree.chart.plot.XYPlot var84 = new org.jfree.chart.plot.XYPlot(var80, var81, var82, var83);
//     java.awt.Paint var85 = var84.getRangeCrosshairPaint();
//     java.awt.Stroke var86 = var84.getRangeCrosshairStroke();
//     var75.setDomainCrosshairStroke(var86);
//     var16.setDomainZeroBaselineStroke(var86);
//     
//     // Checks the contract:  equals-hashcode on var54 and var84
//     assertTrue("Contract failed: equals-hashcode on var54 and var84", var54.equals(var84) ? var54.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var54
//     assertTrue("Contract failed: equals-hashcode on var84 and var54", var84.equals(var54) ? var84.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    org.jfree.chart.axis.AxisSpace var6 = null;
    var4.setFixedRangeAxisSpace(var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    int var9 = var4.getRangeAxisIndex(var8);
    org.jfree.chart.util.RectangleInsets var10 = var4.getAxisOffset();
    org.jfree.chart.plot.DatasetRenderingOrder var11 = var4.getDatasetRenderingOrder();
    java.awt.Font var13 = null;
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var16 = var15.getPaint();
    org.jfree.chart.text.TextMeasurer var19 = null;
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, var16, 10.0f, 0, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    java.awt.Paint var26 = var25.getRangeCrosshairPaint();
    java.awt.Stroke var27 = var25.getRangeCrosshairStroke();
    boolean var28 = var20.equals((java.lang.Object)var25);
    org.jfree.chart.event.RendererChangeEvent var29 = null;
    var25.rendererChanged(var29);
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var37 = var36.getPaint();
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var37);
    var25.setDomainGridlinePaint(var37);
    var4.setRangeGridlinePaint(var37);
    org.jfree.data.general.DatasetGroup var41 = var4.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var1.setLabel("");
    java.awt.Font var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.chart.axis.AxisLocation var8 = var6.getDomainAxisLocation(100);
    int var9 = var6.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    var6.setRenderer(var10);
    org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var18 = var16.calculateRightOutset(10.0d);
    var6.setInsets(var16);
    boolean var20 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("hi!");
    var1.addFragment(var22);
    org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("hi!");
    var1.removeFragment(var25);
    float var27 = var25.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0f);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    java.awt.Paint var22 = var21.getRangeCrosshairPaint();
    java.awt.Stroke var23 = var21.getRangeCrosshairStroke();
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.chart.axis.ValueAxis var30 = null;
    var28.setDomainAxis(0, var30, true);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
    org.jfree.chart.axis.AxisLocation var40 = var38.getDomainAxisLocation(100);
    var28.setRangeAxisLocation(0, var40);
    var21.setDomainAxisLocation(var40);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    var21.setRenderer(var43);
    var21.setRangeCrosshairLockedOnData(true);
    org.jfree.data.general.DatasetGroup var47 = var21.getDatasetGroup();
    java.awt.Paint var48 = var21.getBackgroundPaint();
    var16.setBorderPaint(var48);
    int var50 = var16.getBackgroundImageAlignment();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var51 = var16.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 15);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var5.setDomainAxis(0, var7, true);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
//     var5.setRangeAxisLocation(0, var17);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     double var20 = var19.getContentYOffset();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Stroke var23 = var22.getAxisLineStroke();
//     java.awt.Font var24 = var22.getLabelFont();
//     var22.setVisible(false);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
//     int var34 = var31.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     var31.setRenderer(var35);
//     org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var43 = var41.calculateRightOutset(10.0d);
//     var31.setInsets(var41);
//     var22.setLabelInsets(var41);
//     boolean var46 = var19.equals((java.lang.Object)var22);
//     float var47 = var22.getTickMarkOutsideLength();
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
//     org.jfree.chart.axis.AxisSpace var51 = null;
//     var50.setFixedDomainAxisSpace(var51);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var54 = var50.getRenderer((-10));
//     org.jfree.chart.axis.CategoryAxis var56 = var50.getDomainAxisForDataset(100);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var57 = null;
//     var50.setRenderers(var57);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "hi!", "hi!", "");
    var7.setLicenceText("hi!");
    java.awt.Image var10 = var7.getLogo();
    var7.setVersion("RectangleAnchor.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("java.awt.Color[r=0,g=0,b=142]", var1);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setRangeCrosshairValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis3D var58 = new org.jfree.chart.axis.CategoryAxis3D("");
    var58.setTickMarkOutsideLength(10.0f);
    double var61 = var58.getCategoryMargin();
    var58.setUpperMargin((-1.0d));
    double var64 = var58.getCategoryMargin();
    var50.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var58);
    org.jfree.chart.axis.ValueAxis var67 = var50.getRangeAxis(100);
    var50.setRangeCrosshairVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.mapDatasetToDomainAxis((-10), (-10));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.text.TextBlockAnchor var20 = null;
    var8.draw(var17, 10.0f, 0.0f, var20);
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var24 = var23.getAxisLineStroke();
    java.awt.Font var25 = var23.getLabelFont();
    var23.setVisible(false);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    org.jfree.chart.axis.AxisLocation var34 = var32.getDomainAxisLocation(100);
    int var35 = var32.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    var32.setRenderer(var36);
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var44 = var42.calculateRightOutset(10.0d);
    var32.setInsets(var42);
    var23.setLabelInsets(var42);
    boolean var47 = var23.isAxisLineVisible();
    var23.clearCategoryLabelToolTips();
    boolean var49 = var8.equals((java.lang.Object)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var24 = var23.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var35 = null;
    int var36 = var33.getDomainAxisIndex(var35);
    var33.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var33.setFixedRangeAxisSpace(var40, false);
    org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
    java.awt.Stroke var45 = var44.getBorderStroke();
    boolean var46 = var18.equals((java.lang.Object)var44);
    java.awt.Image var47 = null;
    var44.setBackgroundImage(var47);
    org.jfree.chart.title.TextTitle var49 = var44.getTitle();
    var49.setText("java.awt.Color[r=0,g=0,b=100]");
    org.jfree.chart.text.TextLine var53 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.axis.ValueAxis var56 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
    org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var54, var55, var56, var57);
    org.jfree.chart.axis.AxisLocation var60 = var58.getDomainAxisLocation(100);
    int var61 = var58.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
    var58.setRenderer(var62);
    org.jfree.chart.util.RectangleInsets var68 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var70 = var68.calculateRightOutset(10.0d);
    var58.setInsets(var68);
    boolean var72 = var53.equals((java.lang.Object)var58);
    org.jfree.chart.text.TextFragment var74 = new org.jfree.chart.text.TextFragment("hi!");
    var53.addFragment(var74);
    float var76 = var74.getBaselineOffset();
    java.awt.Font var77 = var74.getFont();
    java.awt.Paint var78 = var74.getPaint();
    var49.setBackgroundPaint(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     int var7 = var4.getDomainAxisIndex(var6);
//     var4.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var11 = null;
//     var4.setFixedRangeAxisSpace(var11, false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = var4.getRenderer(0);
//     org.jfree.chart.plot.DrawingSupplier var16 = var4.getDrawingSupplier();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     int var18 = var4.getRangeAxisIndex(var17);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var4.handleClick(0, 10, var21);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var11 = var10.getPaint();
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var11);
    var4.setRangeCrosshairPaint(var11);
    org.jfree.chart.LegendItemCollection var14 = null;
    var4.setFixedLegendItems(var14);
    var4.setOutlineVisible(false);
    var4.setDomainCrosshairValue(100.0d, false);
    java.awt.Paint var21 = var4.getDomainCrosshairPaint();
    org.jfree.chart.util.Layer var22 = null;
    java.util.Collection var23 = var4.getRangeMarkers(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setRangeCrosshairValue(0.0d, false);
    java.awt.Stroke var56 = var50.getRangeGridlineStroke();
    java.awt.Stroke var57 = var50.getRangeGridlineStroke();
    org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var60.setLabel("");
    org.jfree.chart.text.TextAnchor var63 = var60.getLabelTextAnchor();
    org.jfree.chart.util.Layer var64 = null;
    var50.addRangeMarker((-16777116), (org.jfree.chart.plot.Marker)var60, var64);
    org.jfree.chart.axis.AxisSpace var66 = var50.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    double var19 = var18.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var22 = var21.getAxisLineStroke();
    java.awt.Font var23 = var21.getLabelFont();
    var21.setVisible(false);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.AxisLocation var32 = var30.getDomainAxisLocation(100);
    int var33 = var30.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    var30.setRenderer(var34);
    org.jfree.chart.util.RectangleInsets var40 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var42 = var40.calculateRightOutset(10.0d);
    var30.setInsets(var40);
    var21.setLabelInsets(var40);
    boolean var45 = var18.equals((java.lang.Object)var21);
    org.jfree.chart.LegendItemSource[] var46 = var18.getSources();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100L, var1, 0, 0);
    int var5 = var4.getPercent();
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    java.lang.Object var19 = var18.clone();
    java.lang.String var20 = var18.getURLText();
    java.awt.Font var22 = null;
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var25 = var24.getPaint();
    org.jfree.chart.text.TextMeasurer var28 = null;
    org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var25, 10.0f, 0, var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.text.TextBlockAnchor var33 = null;
    java.awt.Shape var37 = var29.calculateBounds(var30, 0.0f, 0.0f, var33, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var39 = new org.jfree.chart.entity.ChartEntity(var37, "");
    var18.setArea(var37);
    org.jfree.chart.entity.ChartEntity var41 = new org.jfree.chart.entity.ChartEntity(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
    java.awt.Font var5 = var1.getTickLabelFont();
    var1.setLabelURL("java.awt.Color[r=0,g=0,b=100]");
    var1.setTickMarkOutsideLength(10.0f);
    boolean var10 = var1.isTickLabelsVisible();
    var1.setMaximumCategoryLabelLines(0);
    var1.setCategoryMargin(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    boolean var7 = var4.isDomainCrosshairLockedOnData();
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var4.removeChangeListener(var8);
    int var10 = var4.getDomainAxisCount();
    org.jfree.chart.LegendItemCollection var11 = var4.getLegendItems();
    java.util.Iterator var12 = var11.iterator();
    int var13 = var11.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setRangeCrosshairValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis3D var58 = new org.jfree.chart.axis.CategoryAxis3D("");
    var58.setTickMarkOutsideLength(10.0f);
    double var61 = var58.getCategoryMargin();
    var58.setUpperMargin((-1.0d));
    double var64 = var58.getCategoryMargin();
    var50.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var58);
    org.jfree.chart.axis.ValueAxis var67 = var50.getRangeAxis(100);
    org.jfree.chart.util.RectangleEdge var69 = var50.getDomainAxisEdge(0);
    java.awt.Stroke var70 = var50.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.chart.axis.AxisLocation var8 = var6.getDomainAxisLocation(100);
    int var9 = var6.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    var6.setRenderer(var10);
    org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var18 = var16.calculateRightOutset(10.0d);
    var6.setInsets(var16);
    boolean var20 = var1.equals((java.lang.Object)var6);
    java.awt.Stroke var21 = var6.getDomainCrosshairStroke();
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var25 = var24.getAxisLineStroke();
    java.awt.Font var26 = var24.getLabelFont();
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var33 = var32.getPaint();
    org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var33);
    org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("", var26, var33);
    var6.setOutlinePaint(var33);
    var6.clearRangeMarkers(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    int var51 = var50.getWeight();
    boolean var52 = var50.getDrawSharedDomainAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    int var54 = var50.getIndexOf(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = var50.getRenderer((-10));
    org.jfree.chart.axis.ValueAxis var56 = null;
    var50.setRangeAxis(0, var56);
    double var58 = var50.getAnchorValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 118.0d, 116.0d, 116.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedRangeAxisSpace(var51);
    boolean var53 = var50.isRangeGridlinesVisible();
    var50.configureRangeAxes();
    java.awt.Stroke var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setRangeCrosshairStroke(var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var3, "hi!", "", "hi!");
    var7.setLicenceText("");
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var13, "hi!", "", "hi!");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var17);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    var50.clearRangeAxes();
    org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
    java.awt.Paint var55 = var50.getRangeCrosshairPaint();
    java.awt.Paint var56 = var50.getDomainGridlinePaint();
    org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
    var50.setRenderer(0, var58, false);
    org.jfree.chart.axis.CategoryAxis var62 = var50.getDomainAxisForDataset((-16777116));
    boolean var63 = var50.getDrawSharedDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    var4.drawBackgroundImage(var7, var8);
    java.awt.Paint var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainCrosshairPaint(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    java.util.List var51 = var50.getAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.mapDatasetToDomainAxis((-1), (-16777116));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    var18.setHeight(111.0d);
    double var22 = var18.getContentXOffset();
    var18.setID("");
    double var25 = var18.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 111.0d);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setTickMarkOutsideLength(10.0f);
    boolean var4 = var1.isTickMarksVisible();
    var1.addCategoryLabelToolTip((java.lang.Comparable)(short)1, "");
    double var8 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    var18.setHeight(111.0d);
    double var22 = var18.getContentXOffset();
    var18.setID("");
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    boolean var31 = var30.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var32 = null;
    int var33 = var30.getDomainAxisIndex(var32);
    var30.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var37 = null;
    var30.setFixedRangeAxisSpace(var37, false);
    org.jfree.chart.util.RectangleInsets var40 = var30.getInsets();
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var30);
    java.awt.Stroke var42 = var41.getBorderStroke();
    org.jfree.chart.plot.Plot var43 = var41.getPlot();
    java.awt.RenderingHints var44 = var41.getRenderingHints();
    org.jfree.chart.title.LegendTitle var45 = var41.getLegend();
    var18.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var41);
    org.jfree.chart.util.HorizontalAlignment var47 = null;
    org.jfree.chart.util.VerticalAlignment var48 = null;
    org.jfree.chart.block.ColumnArrangement var51 = new org.jfree.chart.block.ColumnArrangement(var47, var48, 0.0d, 100.0d);
    org.jfree.chart.block.BlockContainer var52 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var51);
    java.util.List var53 = var52.getBlocks();
    java.awt.Graphics2D var54 = null;
    org.jfree.chart.util.Size2D var55 = var52.arrange(var54);
    var18.setWrapper(var52);
    org.jfree.chart.block.BlockFrame var57 = var18.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    java.util.List var51 = var50.getAnnotations();
    var50.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    java.awt.geom.Point2D var56 = null;
    var50.zoomRangeAxes(12.0d, var55, var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    int var23 = var4.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var29 = var28.getLeft();
    double var31 = var28.calculateTopInset(10.0d);
    double var33 = var28.calculateLeftOutset((-1.0d));
    double var35 = var28.calculateTopInset((-1.0d));
    var4.setInsets(var28);
    java.lang.String var37 = var4.getNoDataMessage();
    org.jfree.chart.axis.ValueAxis var38 = var4.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var2 = var1.getPaint();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    org.jfree.chart.axis.ValueAxis var9 = null;
    var4.setDomainAxis(100, var9);
    var4.setDomainCrosshairValue(10.0d);
    java.awt.Paint var13 = var4.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    org.jfree.chart.axis.AxisSpace var53 = var50.getFixedDomainAxisSpace();
    java.lang.String var54 = var50.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var4.setDomainAxis(0, var6, true);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
//     var4.setRangeAxisLocation(0, var16);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.data.Range var24 = var23.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     boolean var34 = var33.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     int var36 = var33.getDomainAxisIndex(var35);
//     var33.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var40 = null;
//     var33.setFixedRangeAxisSpace(var40, false);
//     org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
//     java.awt.Stroke var45 = var44.getBorderStroke();
//     boolean var46 = var18.equals((java.lang.Object)var44);
//     java.awt.Image var47 = null;
//     var44.setBackgroundImage(var47);
//     org.jfree.chart.title.TextTitle var49 = var44.getTitle();
//     double var50 = var49.getContentYOffset();
//     java.awt.Graphics2D var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.data.xy.XYDataset var54 = null;
//     org.jfree.chart.axis.ValueAxis var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot(var54, var55, var56, var57);
//     boolean var59 = var58.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     int var61 = var58.getDomainAxisIndex(var60);
//     var58.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var65 = null;
//     var58.setFixedRangeAxisSpace(var65, false);
//     org.jfree.chart.util.RectangleInsets var68 = var58.getInsets();
//     org.jfree.chart.JFreeChart var69 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var58);
//     var69.fireChartChanged();
//     java.lang.Object var71 = var69.clone();
//     org.jfree.chart.util.RectangleInsets var72 = var69.getPadding();
//     java.lang.Object var73 = var49.draw(var51, var52, (java.lang.Object)var72);
//     
//     // Checks the contract:  equals-hashcode on var33 and var58
//     assertTrue("Contract failed: equals-hashcode on var33 and var58", var33.equals(var58) ? var33.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var33
//     assertTrue("Contract failed: equals-hashcode on var58 and var33", var58.equals(var33) ? var58.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var69
//     assertTrue("Contract failed: equals-hashcode on var44 and var69", var44.equals(var69) ? var44.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var44
//     assertTrue("Contract failed: equals-hashcode on var69 and var44", var69.equals(var44) ? var69.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var11 = var10.getPaint();
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var11);
    var4.setRangeCrosshairPaint(var11);
    org.jfree.chart.LegendItemCollection var14 = null;
    var4.setFixedLegendItems(var14);
    double var16 = var4.getDomainCrosshairValue();
    var4.clearDomainAxes();
    org.jfree.chart.util.RectangleInsets var18 = var4.getInsets();
    java.awt.Stroke var19 = var4.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }
// 
// 
//     org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("");
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
//     org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation(100);
//     int var10 = var7.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
//     var7.setRenderer(var11);
//     org.jfree.chart.util.RectangleInsets var17 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var19 = var17.calculateRightOutset(10.0d);
//     var7.setInsets(var17);
//     boolean var21 = var2.equals((java.lang.Object)var7);
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("hi!");
//     var2.addFragment(var23);
//     float var25 = var23.getBaselineOffset();
//     java.awt.Font var26 = var23.getFont();
//     org.jfree.chart.text.TextLine var27 = new org.jfree.chart.text.TextLine("hi!", var26);
//     org.jfree.chart.text.TextLine var29 = new org.jfree.chart.text.TextLine("");
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     org.jfree.chart.axis.AxisLocation var36 = var34.getDomainAxisLocation(100);
//     int var37 = var34.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     var34.setRenderer(var38);
//     org.jfree.chart.util.RectangleInsets var44 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var46 = var44.calculateRightOutset(10.0d);
//     var34.setInsets(var44);
//     boolean var48 = var29.equals((java.lang.Object)var34);
//     org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("hi!");
//     var29.addFragment(var50);
//     var27.removeFragment(var50);
//     
//     // Checks the contract:  equals-hashcode on var7 and var34
//     assertTrue("Contract failed: equals-hashcode on var7 and var34", var7.equals(var34) ? var7.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var7
//     assertTrue("Contract failed: equals-hashcode on var34 and var7", var34.equals(var7) ? var34.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
    org.jfree.chart.event.MarkerChangeListener var2 = null;
    var1.addChangeListener(var2);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
    java.awt.Stroke var2 = var1.getOutlineStroke();
    var1.setValue((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var4.setDomainAxis(0, var6, true);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
//     var4.setRangeAxisLocation(0, var16);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.data.Range var24 = var23.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var34 = var33.getPaint();
//     org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var34);
//     java.awt.Paint var36 = var35.getPaint();
//     var18.setBackgroundPaint(var36);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var38, var39, var40, var41);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     var42.setDomainAxis(0, var44, true);
//     org.jfree.chart.util.RectangleInsets var47 = var42.getInsets();
//     var18.setMargin(var47);
//     
//     // Checks the contract:  equals-hashcode on var14 and var42
//     assertTrue("Contract failed: equals-hashcode on var14 and var42", var14.equals(var42) ? var14.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var14
//     assertTrue("Contract failed: equals-hashcode on var42 and var14", var42.equals(var14) ? var42.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    org.jfree.chart.axis.AxisSpace var53 = var50.getFixedDomainAxisSpace();
    org.jfree.chart.util.RectangleInsets var58 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var59 = var58.getLeft();
    double var61 = var58.calculateTopInset(10.0d);
    double var63 = var58.calculateLeftOutset((-1.0d));
    double var65 = var58.calculateTopInset((-1.0d));
    var50.setAxisOffset(var58);
    java.lang.String var67 = var58.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=10.0]"+ "'", var67.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=10.0]"));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 118.0d, 0, (java.lang.Comparable)(-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    org.jfree.chart.axis.AxisSpace var6 = null;
    var4.setFixedRangeAxisSpace(var6);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    boolean var13 = var12.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var14 = null;
    int var15 = var12.getDomainAxisIndex(var14);
    var12.mapDatasetToDomainAxis(0, 10);
    var12.clearRangeMarkers();
    var12.configureRangeAxes();
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var12.zoomRangeAxes(0.0d, var22, var23, false);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    org.jfree.chart.axis.AxisLocation var36 = var34.getDomainAxisLocation(100);
    int var37 = var34.getDatasetCount();
    java.awt.Graphics2D var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.plot.PlotRenderingInfo var41 = null;
    org.jfree.chart.plot.CrosshairState var42 = null;
    boolean var43 = var34.render(var38, var39, 1, var41, var42);
    org.jfree.data.xy.XYDataset var44 = null;
    org.jfree.chart.axis.ValueAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
    java.awt.Paint var49 = var48.getRangeCrosshairPaint();
    var34.setRangeGridlinePaint(var49);
    org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder((-1.0d), (-1.0d), 10.0d, 10.0d, var49);
    var12.setOutlinePaint(var49);
    var4.setRangeZeroBaselinePaint(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.awt.Font var3 = null;
    org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var6 = var5.getPaint();
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, var6, 10.0f, 0, var9);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    java.awt.Paint var16 = var15.getRangeCrosshairPaint();
    java.awt.Stroke var17 = var15.getRangeCrosshairStroke();
    boolean var18 = var10.equals((java.lang.Object)var15);
    int var19 = var1.indexOf((java.lang.Object)var18);
    java.lang.Object var20 = var1.clone();
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var25 = var23.toFixedHeight(1.0d);
    org.jfree.chart.block.RectangleConstraint var26 = var23.toUnconstrainedHeight();
    int var27 = var1.indexOf((java.lang.Object)var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1));

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 100.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     var5.clear();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.RectangleInsets var12 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var13 = var12.getLeft();
//     double var14 = var12.getRight();
//     double var16 = var12.extendHeight(116.0d);
//     org.jfree.chart.util.Size2D var19 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     var26.setDomainAxis(0, var28, true);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     org.jfree.chart.axis.AxisLocation var38 = var36.getDomainAxisLocation(100);
//     var26.setRangeAxisLocation(0, var38);
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
//     org.jfree.chart.util.RectangleAnchor var41 = var40.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var42 = org.jfree.chart.util.RectangleAnchor.createRectangle(var19, 0.0d, 10.0d, var41);
//     java.awt.geom.Rectangle2D var45 = var12.createOutsetRectangle(var42, true, true);
//     java.awt.Font var47 = null;
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var50 = var49.getPaint();
//     org.jfree.chart.text.TextMeasurer var53 = null;
//     org.jfree.chart.text.TextBlock var54 = org.jfree.chart.text.TextUtilities.createTextBlock("", var47, var50, 10.0f, 0, var53);
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.text.TextBlockAnchor var58 = null;
//     java.awt.Shape var62 = var54.calculateBounds(var55, 0.0f, 0.0f, var58, 0.0f, (-1.0f), 100.0d);
//     java.awt.Graphics2D var63 = null;
//     org.jfree.chart.text.TextBlockAnchor var66 = null;
//     var54.draw(var63, 10.0f, 0.0f, var66);
//     java.awt.Graphics2D var68 = null;
//     org.jfree.chart.text.TextBlockAnchor var71 = null;
//     java.awt.Shape var75 = var54.calculateBounds(var68, (-1.0f), 100.0f, var71, 0.0f, 0.0f, (-1.0d));
//     java.lang.Object var76 = var5.draw(var7, var42, (java.lang.Object)100.0f);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setTickMarkOutsideLength(10.0f);
    boolean var4 = var1.isTickMarksVisible();
    java.lang.Object var5 = var1.clone();
    var1.setMaximumCategoryLabelWidthRatio((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var2 = var1.getPaint();
    java.awt.Paint var3 = var1.getPaint();
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartProgressEvent var8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0.0d, var5, (-1), 1);
    int var9 = var8.getType();
    boolean var10 = var1.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (-1.0d));
    double var3 = var2.getHeight();
    double var4 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.0d));

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    java.awt.geom.Point2D var25 = null;
    var4.zoomDomainAxes((-1.0d), var24, var25, true);
    java.awt.Color var30 = java.awt.Color.getColor("", 100);
    var4.setDomainTickBandPaint((java.awt.Paint)var30);
    int var32 = var30.getTransparency();
    java.awt.color.ColorSpace var33 = var30.getColorSpace();
    float[] var35 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var36 = var30.getColorComponents(var35);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    java.awt.Paint var23 = var4.getBackgroundPaint();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var26 = var25.getTickMarkInsideLength();
    java.lang.String var28 = var25.getCategoryLabelToolTip((java.lang.Comparable)'4');
    java.lang.Object var29 = var25.clone();
    org.jfree.chart.text.TextLine var33 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
    org.jfree.chart.axis.AxisLocation var40 = var38.getDomainAxisLocation(100);
    int var41 = var38.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    var38.setRenderer(var42);
    org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var50 = var48.calculateRightOutset(10.0d);
    var38.setInsets(var48);
    boolean var52 = var33.equals((java.lang.Object)var38);
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("hi!");
    var33.addFragment(var54);
    float var56 = var54.getBaselineOffset();
    java.awt.Font var57 = var54.getFont();
    org.jfree.chart.text.TextLine var58 = new org.jfree.chart.text.TextLine("hi!", var57);
    org.jfree.chart.text.TextLine var59 = new org.jfree.chart.text.TextLine("java.awt.Color[r=0,g=0,b=100]", var57);
    var25.setTickLabelFont(var57);
    var4.setNoDataMessageFont(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    int var51 = var50.getWeight();
    var50.clearDomainMarkers(10);
    org.jfree.chart.axis.ValueAxis var54 = var50.getRangeAxis();
    var50.setAnchorValue(10.0d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    java.lang.Object var19 = var18.clone();
    java.lang.String var20 = var18.getURLText();
    java.awt.Font var22 = null;
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var25 = var24.getPaint();
    org.jfree.chart.text.TextMeasurer var28 = null;
    org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var25, 10.0f, 0, var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.text.TextBlockAnchor var33 = null;
    java.awt.Shape var37 = var29.calculateBounds(var30, 0.0f, 0.0f, var33, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var39 = new org.jfree.chart.entity.ChartEntity(var37, "");
    var18.setArea(var37);
    org.jfree.chart.entity.ChartEntity var42 = new org.jfree.chart.entity.ChartEntity(var37, "");
    org.jfree.data.general.PieDataset var43 = null;
    org.jfree.chart.entity.PieSectionEntity var49 = new org.jfree.chart.entity.PieSectionEntity(var37, var43, 100, 1, (java.lang.Comparable)10, "java.awt.Color[r=0,g=0,b=100]", "hi!");
    java.lang.Comparable var50 = var49.getSectionKey();
    int var51 = var49.getSectionIndex();
    var49.setPieIndex(10);
    int var54 = var49.getPieIndex();
    var49.setURLText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + 10+ "'", var50.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 10);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
    org.jfree.chart.axis.AxisLocation var8 = var6.getDomainAxisLocation(100);
    int var9 = var6.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    var6.setRenderer(var10);
    org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var18 = var16.calculateRightOutset(10.0d);
    var6.setInsets(var16);
    boolean var20 = var1.equals((java.lang.Object)var6);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var25 = var24.getAxisLineStroke();
    java.awt.Font var26 = var24.getLabelFont();
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var33 = var32.getPaint();
    org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var33);
    org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("", var26, var33);
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("hi!", var26);
    var1.removeFragment(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    int var6 = var4.getSeriesCount();
    org.jfree.chart.axis.ValueAxis var7 = null;
    var4.setRangeAxis(var7);
    org.jfree.data.xy.XYDataset var9 = null;
    int var10 = var4.indexOf(var9);
    java.awt.Paint var12 = var4.getQuadrantPaint(1);
    org.jfree.chart.event.PlotChangeEvent var13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.plot.Plot var14 = var13.getPlot();
    org.jfree.chart.plot.Plot var15 = var13.getPlot();
    org.jfree.chart.plot.Plot var16 = var13.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    int var6 = var4.getSeriesCount();
    org.jfree.chart.axis.ValueAxis var7 = null;
    var4.setRangeAxis(var7);
    org.jfree.data.xy.XYDataset var9 = null;
    int var10 = var4.indexOf(var9);
    org.jfree.chart.axis.AxisLocation var12 = var4.getDomainAxisLocation(0);
    boolean var13 = var4.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedRangeAxisSpace(var51);
    boolean var53 = var50.isRangeGridlinesVisible();
    org.jfree.chart.util.Layer var55 = null;
    java.util.Collection var56 = var50.getDomainMarkers(1, var55);
    var50.configureRangeAxes();
    var50.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     boolean var6 = var5.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     int var8 = var5.getDomainAxisIndex(var7);
//     var5.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var5.setFixedRangeAxisSpace(var12, false);
//     org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
//     java.awt.Stroke var17 = var16.getBorderStroke();
//     org.jfree.chart.plot.Plot var18 = var16.getPlot();
//     java.awt.RenderingHints var19 = var16.getRenderingHints();
//     org.jfree.chart.title.LegendTitle var20 = var16.getLegend();
//     java.awt.RenderingHints var21 = var16.getRenderingHints();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     var26.setDomainAxis(0, var28, true);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     org.jfree.chart.axis.AxisLocation var38 = var36.getDomainAxisLocation(100);
//     var26.setRangeAxisLocation(0, var38);
//     org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var26);
//     org.jfree.chart.util.RectangleAnchor var41 = var40.getLegendItemGraphicLocation();
//     org.jfree.chart.util.RectangleInsets var42 = var40.getItemLabelPadding();
//     org.jfree.chart.util.HorizontalAlignment var43 = var40.getHorizontalAlignment();
//     var16.addLegend(var40);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.util.RectangleInsets var50 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var51 = var50.getLeft();
//     double var52 = var50.getRight();
//     double var54 = var50.extendHeight(116.0d);
//     org.jfree.chart.util.Size2D var57 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     var64.setDomainAxis(0, var66, true);
//     org.jfree.data.xy.XYDataset var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.axis.ValueAxis var72 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot(var70, var71, var72, var73);
//     org.jfree.chart.axis.AxisLocation var76 = var74.getDomainAxisLocation(100);
//     var64.setRangeAxisLocation(0, var76);
//     org.jfree.chart.title.LegendTitle var78 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var64);
//     org.jfree.chart.util.RectangleAnchor var79 = var78.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var80 = org.jfree.chart.util.RectangleAnchor.createRectangle(var57, 0.0d, 10.0d, var79);
//     java.awt.geom.Rectangle2D var83 = var50.createOutsetRectangle(var80, true, true);
//     var16.draw(var45, var80);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setNoDataMessage("java.awt.Color[r=0,g=0,b=100]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var5.setDomainAxis(0, var7, true);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
//     var5.setRangeAxisLocation(0, var17);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     double var20 = var19.getContentYOffset();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Stroke var23 = var22.getAxisLineStroke();
//     java.awt.Font var24 = var22.getLabelFont();
//     var22.setVisible(false);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
//     int var34 = var31.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     var31.setRenderer(var35);
//     org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var43 = var41.calculateRightOutset(10.0d);
//     var31.setInsets(var41);
//     var22.setLabelInsets(var41);
//     boolean var46 = var19.equals((java.lang.Object)var22);
//     float var47 = var22.getTickMarkOutsideLength();
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
//     org.jfree.chart.axis.AxisSpace var51 = null;
//     var50.setFixedDomainAxisSpace(var51);
//     var50.clearRangeAxes();
//     org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     var59.setDomainAxis(0, var61, true);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var65, var66, var67, var68);
//     org.jfree.chart.axis.AxisLocation var71 = var69.getDomainAxisLocation(100);
//     var59.setRangeAxisLocation(0, var71);
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
//     org.jfree.chart.util.RectangleInsets var74 = var73.getMargin();
//     java.awt.Graphics2D var75 = null;
//     org.jfree.chart.block.RectangleConstraint var78 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.data.Range var79 = var78.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var81 = var78.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var82 = var73.arrange(var75, var81);
//     org.jfree.chart.text.TextFragment var88 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var89 = var88.getPaint();
//     org.jfree.chart.block.BlockBorder var90 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var89);
//     java.awt.Paint var91 = var90.getPaint();
//     var73.setBackgroundPaint(var91);
//     var50.setRangeCrosshairPaint(var91);
//     
//     // Checks the contract:  equals-hashcode on var5 and var59
//     assertTrue("Contract failed: equals-hashcode on var5 and var59", var5.equals(var59) ? var5.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var69
//     assertTrue("Contract failed: equals-hashcode on var15 and var69", var15.equals(var69) ? var15.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var5
//     assertTrue("Contract failed: equals-hashcode on var59 and var5", var59.equals(var5) ? var59.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var15
//     assertTrue("Contract failed: equals-hashcode on var69 and var15", var69.equals(var15) ? var69.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 1.0d);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(10.0d, var7);
    org.jfree.chart.block.RectangleConstraint var9 = var2.toRangeHeight(var7);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    int var15 = var14.getDatasetCount();
    org.jfree.chart.axis.AxisSpace var16 = null;
    var14.setFixedRangeAxisSpace(var16);
    org.jfree.chart.axis.ValueAxis var18 = null;
    int var19 = var14.getRangeAxisIndex(var18);
    int var20 = var14.getSeriesCount();
    boolean var21 = var7.equals((java.lang.Object)var14);
    double var23 = var7.constrain(0.0d);
    java.lang.String var24 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "Range[1.0,1.0]"+ "'", var24.equals("Range[1.0,1.0]"));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 10);
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.chart.axis.ValueAxis var9 = null;
    var7.setDomainAxis(0, var9, true);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    org.jfree.chart.axis.AxisLocation var19 = var17.getDomainAxisLocation(100);
    var7.setRangeAxisLocation(0, var19);
    org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7);
    org.jfree.chart.util.RectangleInsets var22 = var21.getMargin();
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var27 = var26.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var29 = var26.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var30 = var21.arrange(var23, var29);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
    boolean var37 = var36.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var38 = null;
    int var39 = var36.getDomainAxisIndex(var38);
    var36.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var43 = null;
    var36.setFixedRangeAxisSpace(var43, false);
    org.jfree.chart.util.RectangleInsets var46 = var36.getInsets();
    org.jfree.chart.JFreeChart var47 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var36);
    java.awt.Stroke var48 = var47.getBorderStroke();
    boolean var49 = var21.equals((java.lang.Object)var47);
    boolean var50 = var2.equals((java.lang.Object)var49);
    java.awt.color.ColorSpace var51 = var2.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var5.setDomainAxis(0, var7, true);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
//     var5.setRangeAxisLocation(0, var17);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     double var20 = var19.getContentYOffset();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Stroke var23 = var22.getAxisLineStroke();
//     java.awt.Font var24 = var22.getLabelFont();
//     var22.setVisible(false);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
//     int var34 = var31.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     var31.setRenderer(var35);
//     org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var43 = var41.calculateRightOutset(10.0d);
//     var31.setInsets(var41);
//     var22.setLabelInsets(var41);
//     boolean var46 = var19.equals((java.lang.Object)var22);
//     float var47 = var22.getTickMarkOutsideLength();
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
//     int var51 = var50.getWeight();
//     var50.clearDomainMarkers(10);
//     org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     org.jfree.data.xy.XYDataset var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var59 = null;
//     org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot(var56, var57, var58, var59);
//     java.awt.Paint var61 = var60.getRangeCrosshairPaint();
//     java.awt.Stroke var62 = var60.getRangeCrosshairStroke();
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot(var63, var64, var65, var66);
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     var67.setDomainAxis(0, var69, true);
//     org.jfree.data.xy.XYDataset var73 = null;
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var76 = null;
//     org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot(var73, var74, var75, var76);
//     org.jfree.chart.axis.AxisLocation var79 = var77.getDomainAxisLocation(100);
//     var67.setRangeAxisLocation(0, var79);
//     var60.setDomainAxisLocation(var79);
//     org.jfree.chart.renderer.xy.XYItemRenderer var82 = null;
//     var60.setRenderer(var82);
//     var55.setPlot((org.jfree.chart.plot.Plot)var60);
//     java.util.List var85 = var50.getCategoriesForAxis(var55);
//     
//     // Checks the contract:  equals-hashcode on var5 and var67
//     assertTrue("Contract failed: equals-hashcode on var5 and var67", var5.equals(var67) ? var5.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var77
//     assertTrue("Contract failed: equals-hashcode on var15 and var77", var15.equals(var77) ? var15.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var5
//     assertTrue("Contract failed: equals-hashcode on var67 and var5", var67.equals(var5) ? var67.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var15
//     assertTrue("Contract failed: equals-hashcode on var77 and var15", var77.equals(var15) ? var77.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }


    org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var6 = var5.getPaint();
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var6);
    java.awt.Paint var8 = var7.getPaint();
    java.awt.Font var10 = null;
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var13 = var12.getPaint();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13, 10.0f, 0, var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    java.awt.Paint var23 = var22.getRangeCrosshairPaint();
    java.awt.Stroke var24 = var22.getRangeCrosshairStroke();
    boolean var25 = var17.equals((java.lang.Object)var22);
    org.jfree.data.general.DatasetChangeEvent var26 = null;
    var22.datasetChanged(var26);
    var22.setBackgroundImageAlignment(10);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis[] var31 = new org.jfree.chart.axis.ValueAxis[] { var30};
    var22.setDomainAxes(var31);
    boolean var33 = var7.equals((java.lang.Object)var22);
    org.jfree.chart.plot.DrawingSupplier var34 = var22.getDrawingSupplier();
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    java.awt.geom.Point2D var37 = null;
    var22.zoomDomainAxes(111.0d, var36, var37, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setTickMarkOutsideLength(10.0f);
    double var4 = var1.getCategoryMargin();
    var1.setUpperMargin((-1.0d));
    var1.setLabelURL("");
    java.awt.Font var9 = var1.getTickLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var5.setDomainAxis(0, var7, true);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
//     var5.setRangeAxisLocation(0, var17);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     double var20 = var19.getContentYOffset();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Stroke var23 = var22.getAxisLineStroke();
//     java.awt.Font var24 = var22.getLabelFont();
//     var22.setVisible(false);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
//     int var34 = var31.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     var31.setRenderer(var35);
//     org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var43 = var41.calculateRightOutset(10.0d);
//     var31.setInsets(var41);
//     var22.setLabelInsets(var41);
//     boolean var46 = var19.equals((java.lang.Object)var22);
//     float var47 = var22.getTickMarkOutsideLength();
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
//     var50.setAnchorValue(100.0d);
//     org.jfree.chart.LegendItemCollection var53 = var50.getFixedLegendItems();
//     java.awt.Graphics2D var54 = null;
//     org.jfree.chart.util.RectangleInsets var59 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var60 = var59.getLeft();
//     double var61 = var59.getRight();
//     double var63 = var59.extendHeight(116.0d);
//     org.jfree.chart.util.Size2D var66 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var69, var70, var71, var72);
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     var73.setDomainAxis(0, var75, true);
//     org.jfree.data.xy.XYDataset var79 = null;
//     org.jfree.chart.axis.ValueAxis var80 = null;
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var82 = null;
//     org.jfree.chart.plot.XYPlot var83 = new org.jfree.chart.plot.XYPlot(var79, var80, var81, var82);
//     org.jfree.chart.axis.AxisLocation var85 = var83.getDomainAxisLocation(100);
//     var73.setRangeAxisLocation(0, var85);
//     org.jfree.chart.title.LegendTitle var87 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var73);
//     org.jfree.chart.util.RectangleAnchor var88 = var87.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var89 = org.jfree.chart.util.RectangleAnchor.createRectangle(var66, 0.0d, 10.0d, var88);
//     java.awt.geom.Rectangle2D var92 = var59.createOutsetRectangle(var89, true, true);
//     var50.drawBackground(var54, var89);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    java.lang.Object var19 = var18.clone();
    java.lang.String var20 = var18.getURLText();
    java.awt.Font var22 = null;
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var25 = var24.getPaint();
    org.jfree.chart.text.TextMeasurer var28 = null;
    org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var25, 10.0f, 0, var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.text.TextBlockAnchor var33 = null;
    java.awt.Shape var37 = var29.calculateBounds(var30, 0.0f, 0.0f, var33, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var39 = new org.jfree.chart.entity.ChartEntity(var37, "");
    var18.setArea(var37);
    org.jfree.chart.entity.ChartEntity var42 = new org.jfree.chart.entity.ChartEntity(var37, "");
    org.jfree.data.general.PieDataset var43 = null;
    org.jfree.chart.entity.PieSectionEntity var49 = new org.jfree.chart.entity.PieSectionEntity(var37, var43, 100, 1, (java.lang.Comparable)10, "java.awt.Color[r=0,g=0,b=100]", "hi!");
    java.lang.Comparable var50 = var49.getSectionKey();
    int var51 = var49.getSectionIndex();
    var49.setPieIndex(10);
    var49.setPieIndex((-16777116));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + 10+ "'", var50.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedRangeAxisSpace(var51);
    boolean var53 = var50.isRangeGridlinesVisible();
    org.jfree.chart.util.Layer var55 = null;
    java.util.Collection var56 = var50.getDomainMarkers(1, var55);
    java.awt.Stroke var57 = var50.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    org.jfree.data.xy.XYDataset var7 = null;
    var4.setDataset(var7);
    int var9 = var4.getDomainAxisCount();
    boolean var10 = var4.isDomainCrosshairVisible();
    org.jfree.chart.plot.Plot var11 = var4.getRootPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var5.setLabel("");
//     org.jfree.chart.text.TextAnchor var8 = var5.getLabelTextAnchor();
//     org.jfree.chart.text.TextAnchor var10 = null;
//     java.awt.Shape var11 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("0,0,0,0,0,0,0,0,0,0,0,0", var1, 0.0f, 1.0f, var8, 0.0d, var10);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var6 = null;
    int var7 = var4.getDomainAxisIndex(var6);
    var4.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    int var12 = var4.getIndexOf(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var4.setDomainAxis(0, var6, true);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
//     var4.setRangeAxisLocation(0, var16);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.data.Range var24 = var23.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     boolean var34 = var33.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     int var36 = var33.getDomainAxisIndex(var35);
//     var33.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var40 = null;
//     var33.setFixedRangeAxisSpace(var40, false);
//     org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
//     java.awt.Stroke var45 = var44.getBorderStroke();
//     boolean var46 = var18.equals((java.lang.Object)var44);
//     java.awt.Stroke var47 = null;
//     var44.setBorderStroke(var47);
//     java.awt.Image var52 = null;
//     org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var52, "hi!", "hi!", "");
//     java.lang.String var57 = var56.getInfo();
//     var56.setLicenceName("");
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     java.awt.Paint var65 = var64.getRangeCrosshairPaint();
//     java.awt.Stroke var66 = var64.getRangeCrosshairStroke();
//     org.jfree.data.xy.XYDataset var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var70 = null;
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot(var67, var68, var69, var70);
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     var71.setDomainAxis(0, var73, true);
//     org.jfree.data.xy.XYDataset var77 = null;
//     org.jfree.chart.axis.ValueAxis var78 = null;
//     org.jfree.chart.axis.ValueAxis var79 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var80 = null;
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot(var77, var78, var79, var80);
//     org.jfree.chart.axis.AxisLocation var83 = var81.getDomainAxisLocation(100);
//     var71.setRangeAxisLocation(0, var83);
//     var64.setDomainAxisLocation(var83);
//     java.util.List var86 = var64.getAnnotations();
//     var56.setContributors(var86);
//     var44.setSubtitles(var86);
//     
//     // Checks the contract:  equals-hashcode on var4 and var71
//     assertTrue("Contract failed: equals-hashcode on var4 and var71", var4.equals(var71) ? var4.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var81
//     assertTrue("Contract failed: equals-hashcode on var14 and var81", var14.equals(var81) ? var14.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var4
//     assertTrue("Contract failed: equals-hashcode on var71 and var4", var71.equals(var4) ? var71.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var14
//     assertTrue("Contract failed: equals-hashcode on var81 and var14", var81.equals(var14) ? var81.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    var4.mapDatasetToDomainAxis(100, 1);
    var4.setDomainCrosshairValue(0.0d, false);
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    java.awt.Paint var18 = var17.getRangeCrosshairPaint();
    org.jfree.chart.plot.SeriesRenderingOrder var19 = var17.getSeriesRenderingOrder();
    var4.setSeriesRenderingOrder(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setRangeCrosshairValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis3D var58 = new org.jfree.chart.axis.CategoryAxis3D("");
    var58.setTickMarkOutsideLength(10.0f);
    double var61 = var58.getCategoryMargin();
    var58.setUpperMargin((-1.0d));
    double var64 = var58.getCategoryMargin();
    var50.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var58);
    org.jfree.chart.axis.ValueAxis var67 = var50.getRangeAxis(100);
    org.jfree.chart.util.RectangleEdge var69 = var50.getDomainAxisEdge(0);
    org.jfree.chart.util.Layer var71 = null;
    java.util.Collection var72 = var50.getRangeMarkers(0, var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    org.jfree.data.xy.XYDataset var7 = null;
    var4.setDataset(var7);
    org.jfree.chart.util.RectangleInsets var9 = var4.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]", var1, 1.0f, 1.0f, 1.0d, 1.0f, 100.0f);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
    org.jfree.chart.axis.CategoryAnchor var52 = var50.getDomainGridlinePosition();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var54 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var53};
    var50.setRenderers(var54);
    org.jfree.chart.axis.ValueAxis var56 = var50.getRangeAxis();
    var50.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    boolean var7 = var4.isDomainCrosshairLockedOnData();
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var4.removeChangeListener(var8);
    var4.setRangeCrosshairVisible(false);
    var4.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var1.setLabel("");
    java.awt.Paint var4 = var1.getPaint();
    float var5 = var1.getAlpha();
    java.awt.Font var6 = var1.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)1.0f);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    java.awt.Paint var22 = var21.getRangeCrosshairPaint();
    java.awt.Stroke var23 = var21.getRangeCrosshairStroke();
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var24, var25, var26, var27);
    org.jfree.chart.axis.ValueAxis var30 = null;
    var28.setDomainAxis(0, var30, true);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
    org.jfree.chart.axis.AxisLocation var40 = var38.getDomainAxisLocation(100);
    var28.setRangeAxisLocation(0, var40);
    var21.setDomainAxisLocation(var40);
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    var21.setRenderer(var43);
    var21.setRangeCrosshairLockedOnData(true);
    org.jfree.data.general.DatasetGroup var47 = var21.getDatasetGroup();
    java.awt.Paint var48 = var21.getBackgroundPaint();
    var16.setBorderPaint(var48);
    var16.setBackgroundImageAlpha(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var17 = var16.getBorderStroke();
    org.jfree.chart.plot.Plot var18 = var16.getPlot();
    java.awt.RenderingHints var19 = var16.getRenderingHints();
    org.jfree.chart.title.LegendTitle var20 = var16.getLegend();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.AxisLocation var27 = var25.getDomainAxisLocation(100);
    int var28 = var25.getDatasetCount();
    java.awt.Graphics2D var29 = null;
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    org.jfree.chart.plot.CrosshairState var33 = null;
    boolean var34 = var25.render(var29, var30, 1, var32, var33);
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
    java.awt.Paint var40 = var39.getRangeCrosshairPaint();
    var25.setRangeGridlinePaint(var40);
    org.jfree.chart.axis.AxisSpace var42 = null;
    var25.setFixedDomainAxisSpace(var42);
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var25.zoomDomainAxes((-1.0d), var45, var46, true);
    java.awt.Color var51 = java.awt.Color.getColor("", 100);
    var25.setDomainTickBandPaint((java.awt.Paint)var51);
    java.awt.image.ColorModel var53 = null;
    java.awt.Rectangle var54 = null;
    java.awt.geom.Rectangle2D var55 = null;
    java.awt.geom.AffineTransform var56 = null;
    java.awt.RenderingHints var57 = null;
    java.awt.PaintContext var58 = var51.createContext(var53, var54, var55, var56, var57);
    var16.setBackgroundPaint((java.awt.Paint)var51);
    java.awt.RenderingHints var60 = var16.getRenderingHints();
    boolean var61 = var16.getAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.text.TextBlockAnchor var20 = null;
    var8.draw(var17, 10.0f, 0.0f, var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.text.TextBlockAnchor var25 = null;
    java.awt.Shape var29 = var8.calculateBounds(var22, (-1.0f), 100.0f, var25, 0.0f, 0.0f, (-1.0d));
    org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleAnchor var19 = var18.getLegendItemGraphicLocation();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 0.0d);
    org.jfree.data.Range var24 = var23.getWidthRange();
    org.jfree.chart.util.Size2D var25 = var18.arrange(var20, var23);
    double var26 = var25.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 1.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16646144));

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var2 = var1.clone();
    java.awt.Stroke var3 = var1.getAxisLineStroke();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    org.jfree.chart.axis.AxisLocation var10 = var8.getDomainAxisLocation(100);
    int var11 = var8.getDatasetCount();
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.plot.CrosshairState var16 = null;
    boolean var17 = var8.render(var12, var13, 1, var15, var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    java.awt.Paint var23 = var22.getRangeCrosshairPaint();
    var8.setRangeGridlinePaint(var23);
    org.jfree.chart.axis.AxisSpace var25 = null;
    var8.setFixedDomainAxisSpace(var25);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var8.zoomDomainAxes((-1.0d), var28, var29, true);
    java.awt.Color var34 = java.awt.Color.getColor("", 100);
    var8.setDomainTickBandPaint((java.awt.Paint)var34);
    double var36 = var8.getDomainCrosshairValue();
    boolean var37 = var1.hasListener((java.util.EventListener)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "hi!", "hi!", "");
    var7.setLicenceText("hi!");
    java.lang.String var10 = var7.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "hi!"+ "'", var10.equals("hi!"));

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    double var19 = var18.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var22 = var21.getAxisLineStroke();
    java.awt.Font var23 = var21.getLabelFont();
    var21.setVisible(false);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.AxisLocation var32 = var30.getDomainAxisLocation(100);
    int var33 = var30.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    var30.setRenderer(var34);
    org.jfree.chart.util.RectangleInsets var40 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var42 = var40.calculateRightOutset(10.0d);
    var30.setInsets(var40);
    var21.setLabelInsets(var40);
    boolean var45 = var18.equals((java.lang.Object)var21);
    float var46 = var21.getTickMarkOutsideLength();
    java.awt.Stroke var47 = var21.getTickMarkStroke();
    var21.setUpperMargin(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }


    org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var3, var4, var5, var6);
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation(100);
    int var10 = var7.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    var7.setRenderer(var11);
    org.jfree.chart.util.RectangleInsets var17 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var19 = var17.calculateRightOutset(10.0d);
    var7.setInsets(var17);
    boolean var21 = var2.equals((java.lang.Object)var7);
    org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("hi!");
    var2.addFragment(var23);
    float var25 = var23.getBaselineOffset();
    java.awt.Font var26 = var23.getFont();
    java.awt.Paint var27 = null;
    org.jfree.chart.text.TextMeasurer var30 = null;
    org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("", var26, var27, 10.0f, 1, var30);
    org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var35 = var34.clone();
    java.awt.Font var36 = var34.getTickLabelFont();
    org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var39 = var38.getPaint();
    org.jfree.chart.text.TextMeasurer var42 = null;
    org.jfree.chart.text.TextBlock var43 = org.jfree.chart.text.TextUtilities.createTextBlock("", var36, var39, 0.0f, 100, var42);
    java.awt.Font var45 = null;
    org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var48 = var47.getPaint();
    org.jfree.chart.text.TextMeasurer var51 = null;
    org.jfree.chart.text.TextBlock var52 = org.jfree.chart.text.TextUtilities.createTextBlock("", var45, var48, 10.0f, 0, var51);
    java.awt.Graphics2D var53 = null;
    org.jfree.chart.text.TextBlockAnchor var56 = null;
    java.awt.Shape var60 = var52.calculateBounds(var53, 0.0f, 0.0f, var56, 0.0f, (-1.0f), 100.0d);
    java.awt.Graphics2D var61 = null;
    org.jfree.chart.text.TextBlockAnchor var64 = null;
    var52.draw(var61, 0.0f, 10.0f, var64, 10.0f, 1.0f, 1.0d);
    java.awt.Font var70 = null;
    org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var73 = var72.getPaint();
    org.jfree.chart.text.TextMeasurer var76 = null;
    org.jfree.chart.text.TextBlock var77 = org.jfree.chart.text.TextUtilities.createTextBlock("", var70, var73, 10.0f, 0, var76);
    java.awt.Graphics2D var78 = null;
    org.jfree.chart.util.Size2D var79 = var77.calculateDimensions(var78);
    org.jfree.chart.util.HorizontalAlignment var80 = var77.getLineAlignment();
    var52.setLineAlignment(var80);
    var43.setLineAlignment(var80);
    var31.setLineAlignment(var80);
    org.jfree.data.xy.XYDataset var84 = null;
    org.jfree.chart.axis.ValueAxis var85 = null;
    org.jfree.chart.axis.ValueAxis var86 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var87 = null;
    org.jfree.chart.plot.XYPlot var88 = new org.jfree.chart.plot.XYPlot(var84, var85, var86, var87);
    int var89 = var88.getDatasetCount();
    org.jfree.chart.axis.AxisSpace var90 = null;
    var88.setFixedRangeAxisSpace(var90);
    org.jfree.chart.axis.ValueAxis var92 = null;
    int var93 = var88.getRangeAxisIndex(var92);
    boolean var94 = var80.equals((java.lang.Object)var88);
    org.jfree.chart.plot.PlotRenderingInfo var96 = null;
    java.awt.geom.Point2D var97 = null;
    var88.zoomDomainAxes(12.0d, var96, var97, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var17 = var16.getBorderStroke();
    org.jfree.chart.plot.Plot var18 = var16.getPlot();
    java.awt.RenderingHints var19 = var16.getRenderingHints();
    org.jfree.chart.title.LegendTitle var20 = var16.getLegend();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var22 = var16.getSubtitle(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setRangeCrosshairValue(0.0d, false);
    java.awt.Stroke var56 = var50.getRangeGridlineStroke();
    java.awt.Stroke var57 = var50.getRangeGridlineStroke();
    org.jfree.chart.plot.ValueMarker var60 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var60.setLabel("");
    org.jfree.chart.text.TextAnchor var63 = var60.getLabelTextAnchor();
    org.jfree.chart.util.Layer var64 = null;
    var50.addRangeMarker((-16777116), (org.jfree.chart.plot.Marker)var60, var64);
    float var66 = var60.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.8f);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    var50.clearRangeAxes();
    org.jfree.chart.util.RectangleEdge var55 = var50.getDomainAxisEdge(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
    var50.setRenderer(0, var57);
    org.jfree.chart.util.RectangleInsets var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setInsets(var59, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    int var6 = var4.getSeriesCount();
    org.jfree.chart.axis.ValueAxis var8 = null;
    var4.setDomainAxis(0, var8);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var4.zoomRangeAxes(10.0d, var11, var12, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var24 = var23.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var35 = null;
    int var36 = var33.getDomainAxisIndex(var35);
    var33.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var33.setFixedRangeAxisSpace(var40, false);
    org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
    java.awt.Stroke var45 = var44.getBorderStroke();
    boolean var46 = var18.equals((java.lang.Object)var44);
    java.awt.Image var47 = null;
    var44.setBackgroundImage(var47);
    org.jfree.chart.title.TextTitle var49 = var44.getTitle();
    var49.setText("java.awt.Color[r=0,g=0,b=100]");
    java.awt.Graphics2D var52 = null;
    org.jfree.data.Range var53 = null;
    org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(var53, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var56 = var49.arrange(var52, var55);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var1.setLabel("");
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.ValueAxis var5 = null;
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     var8.setDomainAxis(0, var10, true);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     org.jfree.chart.axis.AxisLocation var20 = var18.getDomainAxisLocation(100);
//     var8.setRangeAxisLocation(0, var20);
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0.0d, var23, (-1), 1);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
//     boolean var33 = var32.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     int var35 = var32.getDomainAxisIndex(var34);
//     var32.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var32.setFixedRangeAxisSpace(var39, false);
//     org.jfree.chart.util.RectangleInsets var42 = var32.getInsets();
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var32);
//     org.jfree.chart.event.ChartChangeEventType var44 = null;
//     org.jfree.chart.event.ChartChangeEvent var45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1, var43, var44);
//     org.jfree.chart.util.RectangleInsets var46 = var43.getPadding();
//     org.jfree.chart.event.ChartProgressListener var47 = null;
//     var43.removeProgressListener(var47);
//     java.awt.Paint var49 = var43.getBackgroundPaint();
//     var8.setRangeTickBandPaint(var49);
//     var1.setLabelPaint(var49);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var52, var53, var54, var55);
//     java.awt.Paint var57 = var56.getRangeCrosshairPaint();
//     java.awt.Stroke var58 = var56.getRangeCrosshairStroke();
//     org.jfree.data.xy.XYDataset var59 = null;
//     var56.setDataset(var59);
//     java.awt.Stroke var61 = var56.getRangeZeroBaselineStroke();
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
//     org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot(var62, var63, var64, var65);
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     var66.setDomainAxis(0, var68, true);
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var75 = null;
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot(var72, var73, var74, var75);
//     org.jfree.chart.axis.AxisLocation var78 = var76.getDomainAxisLocation(100);
//     var66.setRangeAxisLocation(0, var78);
//     org.jfree.chart.title.LegendTitle var80 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66);
//     java.awt.Paint var81 = var80.getBackgroundPaint();
//     org.jfree.chart.axis.CategoryAxis var83 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.lang.Object var84 = var83.clone();
//     org.jfree.chart.util.RectangleInsets var85 = var83.getLabelInsets();
//     var80.setPadding(var85);
//     org.jfree.chart.block.LineBorder var87 = new org.jfree.chart.block.LineBorder(var49, var61, var85);
//     
//     // Checks the contract:  equals-hashcode on var18 and var56
//     assertTrue("Contract failed: equals-hashcode on var18 and var56", var18.equals(var56) ? var18.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var76
//     assertTrue("Contract failed: equals-hashcode on var18 and var76", var18.equals(var76) ? var18.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var18
//     assertTrue("Contract failed: equals-hashcode on var56 and var18", var56.equals(var18) ? var56.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var76
//     assertTrue("Contract failed: equals-hashcode on var56 and var76", var56.equals(var76) ? var56.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var18
//     assertTrue("Contract failed: equals-hashcode on var76 and var18", var76.equals(var18) ? var76.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var56
//     assertTrue("Contract failed: equals-hashcode on var76 and var56", var76.equals(var56) ? var76.hashCode() == var56.hashCode() : true);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
    org.jfree.chart.axis.CategoryAnchor var52 = var50.getDomainGridlinePosition();
    var50.configureRangeAxes();
    var50.setRangeCrosshairValue(0.0d, false);
    boolean var57 = var50.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    int var18 = var4.getRangeAxisCount();
    var4.setDomainGridlinesVisible(false);
    var4.setDomainGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Paint var2 = var1.getTickLabelPaint();
    java.awt.Paint var3 = var1.getLabelPaint();
    boolean var4 = var1.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }


    java.awt.Font var1 = null;
    java.awt.Font var3 = null;
    org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var6 = var5.getPaint();
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, var6, 10.0f, 0, var9);
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var6, 0.0f, 10, var13);
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setLineAlignment(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var24 = var23.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var35 = null;
    int var36 = var33.getDomainAxisIndex(var35);
    var33.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var33.setFixedRangeAxisSpace(var40, false);
    org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
    java.awt.Stroke var45 = var44.getBorderStroke();
    boolean var46 = var18.equals((java.lang.Object)var44);
    java.awt.Image var47 = null;
    var44.setBackgroundImage(var47);
    org.jfree.chart.title.TextTitle var49 = var44.getTitle();
    org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D("");
    var51.setTickMarkOutsideLength(10.0f);
    double var54 = var51.getCategoryMargin();
    var51.setUpperMargin((-1.0d));
    java.awt.Paint var57 = var51.getTickLabelPaint();
    var49.setPaint(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "hi!", "hi!", "");
    java.lang.String var8 = var7.getInfo();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var12, "hi!", "hi!", "");
    java.lang.String var17 = var16.getLicenceText();
    java.lang.String var18 = var16.getVersion();
    var16.addOptionalLibrary("");
    boolean var21 = var7.equals((java.lang.Object)"");
    java.util.List var22 = var7.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var4 = var3.getPaint();
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
//     java.awt.Paint var14 = var13.getRangeCrosshairPaint();
//     java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
//     boolean var16 = var8.equals((java.lang.Object)var13);
//     org.jfree.chart.event.RendererChangeEvent var17 = null;
//     var13.rendererChanged(var17);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     org.jfree.chart.util.RectangleInsets var20 = var19.getPadding();
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     boolean var26 = var25.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     int var28 = var25.getDomainAxisIndex(var27);
//     var25.mapDatasetToDomainAxis(0, 10);
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var25.drawBackgroundImage(var32, var33);
//     org.jfree.chart.axis.AxisSpace var35 = null;
//     var25.setFixedDomainAxisSpace(var35, true);
//     var25.setRangeCrosshairVisible(false);
//     java.awt.Graphics2D var40 = null;
//     org.jfree.chart.util.RectangleInsets var45 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var46 = var45.getLeft();
//     double var47 = var45.getRight();
//     double var49 = var45.extendHeight(116.0d);
//     org.jfree.chart.util.Size2D var52 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var55, var56, var57, var58);
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     var59.setDomainAxis(0, var61, true);
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var65, var66, var67, var68);
//     org.jfree.chart.axis.AxisLocation var71 = var69.getDomainAxisLocation(100);
//     var59.setRangeAxisLocation(0, var71);
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var59);
//     org.jfree.chart.util.RectangleAnchor var74 = var73.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var75 = org.jfree.chart.util.RectangleAnchor.createRectangle(var52, 0.0d, 10.0d, var74);
//     java.awt.geom.Rectangle2D var78 = var45.createOutsetRectangle(var75, true, true);
//     java.awt.geom.Point2D var79 = null;
//     org.jfree.chart.plot.PlotState var80 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var81 = null;
//     var25.draw(var40, var75, var79, var80, var81);
//     var20.trim(var75);
//     
//     // Checks the contract:  equals-hashcode on var13 and var69
//     assertTrue("Contract failed: equals-hashcode on var13 and var69", var13.equals(var69) ? var13.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var13
//     assertTrue("Contract failed: equals-hashcode on var69 and var13", var69.equals(var13) ? var69.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(1.0d);
    org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var6 = var4.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var8 = var4.toFixedHeight(0.0d);
    java.awt.Font var10 = null;
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var13 = var12.getPaint();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13, 10.0f, 0, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.util.Size2D var19 = var17.calculateDimensions(var18);
    org.jfree.chart.util.Size2D var20 = var4.calculateConstrainedSize(var19);
    org.jfree.data.Range var21 = var4.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var3, "hi!", "", "hi!");
    org.jfree.chart.ui.Library[] var8 = var7.getOptionalLibraries();
    var7.setCopyright("RectangleInsets[t=1.0,l=1.0,b=1.0,r=10.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(1.0d);
    org.jfree.chart.block.LengthConstraintType var5 = var4.getHeightConstraintType();
    org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot(var8, var9, var10, var11);
    org.jfree.chart.axis.AxisLocation var14 = var12.getDomainAxisLocation(100);
    int var15 = var12.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    var12.setRenderer(var16);
    org.jfree.chart.util.RectangleInsets var22 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var24 = var22.calculateRightOutset(10.0d);
    var12.setInsets(var22);
    boolean var26 = var7.equals((java.lang.Object)var12);
    java.awt.Stroke var27 = var12.getDomainCrosshairStroke();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var31 = var30.getAxisLineStroke();
    java.awt.Font var32 = var30.getLabelFont();
    org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var39 = var38.getPaint();
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var39);
    org.jfree.chart.text.TextLine var41 = new org.jfree.chart.text.TextLine("", var32, var39);
    var12.setOutlinePaint(var39);
    boolean var43 = var5.equals((java.lang.Object)var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    java.awt.Color var13 = java.awt.Color.getColor("", 100);
    java.awt.color.ColorSpace var14 = var13.getColorSpace();
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 111.0d, 10.0d, (java.awt.Paint)var13);
    var4.setBackgroundPaint((java.awt.Paint)var13);
    java.awt.Color var17 = var13.darker();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    var18.setURLText("hi!");
    java.lang.String var21 = var18.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "poly"+ "'", var21.equals("poly"));

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var3 = var1.getPieLabelRecord((-16777116));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "RectangleAnchor.CENTER", "", var3, "hi!", "", "");
    org.jfree.chart.ui.Library[] var8 = var7.getOptionalLibraries();
    var7.setName("java.awt.Color[r=0,g=0,b=100]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var3 = var1.getPieLabelRecord(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    org.jfree.chart.axis.ValueAxis var8 = var4.getDomainAxis(100);
    java.awt.Paint var9 = var4.getDomainTickBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setRangeCrosshairValue(0.0d, false);
    java.awt.Stroke var56 = var50.getRangeGridlineStroke();
    org.jfree.chart.annotations.CategoryAnnotation var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var58 = var50.removeAnnotation(var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    org.jfree.chart.LegendItemCollection var53 = var50.getFixedLegendItems();
    var50.setWeight(0);
    org.jfree.data.category.CategoryDataset var56 = null;
    var50.setDataset(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 0.0d, 100.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    java.util.List var6 = var5.getBlocks();
    java.lang.Object var7 = var5.clone();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.util.Size2D var9 = var5.arrange(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    org.jfree.chart.text.TextLine var3 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    org.jfree.chart.axis.AxisLocation var10 = var8.getDomainAxisLocation(100);
    int var11 = var8.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    var8.setRenderer(var12);
    org.jfree.chart.util.RectangleInsets var18 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var20 = var18.calculateRightOutset(10.0d);
    var8.setInsets(var18);
    boolean var22 = var3.equals((java.lang.Object)var8);
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("hi!");
    var3.addFragment(var24);
    float var26 = var24.getBaselineOffset();
    java.awt.Font var27 = var24.getFont();
    org.jfree.chart.text.TextLine var28 = new org.jfree.chart.text.TextLine("hi!", var27);
    org.jfree.chart.text.TextLine var29 = new org.jfree.chart.text.TextLine("java.awt.Color[r=0,g=0,b=100]", var27);
    org.jfree.chart.text.TextFragment var30 = var29.getFirstTextFragment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.lang.Object var2 = var1.clone();
    java.text.NumberFormat var3 = var1.getNumberFormat();
    java.text.AttributedString var5 = var1.getAttributedLabel(0);
    java.text.AttributedString var7 = null;
    var1.setAttributedLabel(1, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setTickMarkOutsideLength(10.0f);
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    org.jfree.chart.axis.AxisLocation var10 = var8.getDomainAxisLocation(100);
    int var11 = var8.getDatasetCount();
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.plot.CrosshairState var16 = null;
    boolean var17 = var8.render(var12, var13, 1, var15, var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    java.awt.Paint var23 = var22.getRangeCrosshairPaint();
    var8.setRangeGridlinePaint(var23);
    org.jfree.chart.axis.AxisSpace var25 = null;
    var8.setFixedDomainAxisSpace(var25);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var8.zoomDomainAxes((-1.0d), var28, var29, true);
    java.awt.Color var34 = java.awt.Color.getColor("", 100);
    var8.setDomainTickBandPaint((java.awt.Paint)var34);
    var1.setTickLabelPaint((java.awt.Paint)var34);
    java.lang.Object var37 = var1.clone();
    var1.setMaximumCategoryLabelLines(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    int var23 = var4.getBackgroundImageAlignment();
    org.jfree.chart.event.MarkerChangeEvent var24 = null;
    var4.markerChanged(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 15);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    int var51 = var50.getWeight();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    var50.setRenderer(100, var53, false);
    var50.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.text.TextBlockAnchor var20 = null;
    var8.draw(var17, 0.0f, 10.0f, var20, 10.0f, 1.0f, 1.0d);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.text.TextBlockAnchor var28 = null;
    var8.draw(var25, (-1.0f), 100.0f, var28, 0.0f, 100.0f, 244.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.AxisLocation var7 = var5.getDomainAxisLocation(100);
    int var8 = var5.getDatasetCount();
    var5.clearDomainMarkers();
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    var5.drawAnnotations(var10, var11, var12);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("java.awt.Color[r=0,g=0,b=100]", (org.jfree.chart.plot.Plot)var5);
    java.awt.RenderingHints var15 = var14.getRenderingHints();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var6 = var5.getPaint();
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var6);
    java.awt.Paint var8 = var7.getPaint();
    java.awt.Font var10 = null;
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var13 = var12.getPaint();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13, 10.0f, 0, var16);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
    java.awt.Paint var23 = var22.getRangeCrosshairPaint();
    java.awt.Stroke var24 = var22.getRangeCrosshairStroke();
    boolean var25 = var17.equals((java.lang.Object)var22);
    org.jfree.data.general.DatasetChangeEvent var26 = null;
    var22.datasetChanged(var26);
    var22.setBackgroundImageAlignment(10);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis[] var31 = new org.jfree.chart.axis.ValueAxis[] { var30};
    var22.setDomainAxes(var31);
    boolean var33 = var7.equals((java.lang.Object)var22);
    boolean var34 = var22.isRangeGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "org.jfree.chart.event.ChartProgressEvent[source=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=10.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=10.0]");

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    org.jfree.data.general.DatasetChangeEvent var53 = null;
    var50.datasetChanged(var53);
    var50.setAnchorValue((-1.0d));
    float var57 = var50.getForegroundAlpha();
    boolean var58 = var50.isRangeCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    var50.clearRangeAxes();
    org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
    java.awt.Paint var55 = var50.getRangeCrosshairPaint();
    java.awt.Paint var56 = var50.getDomainGridlinePaint();
    org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
    var50.setRenderer(0, var58, false);
    org.jfree.chart.util.SortOrder var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setColumnRenderingOrder(var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 244.0d, 10.0d, 118.0d);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var1.setLabel("");
    org.jfree.chart.text.TextAnchor var4 = var1.getLabelTextAnchor();
    java.lang.String var5 = var4.toString();
    java.lang.String var6 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "TextAnchor.CENTER"+ "'", var5.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "TextAnchor.CENTER"+ "'", var6.equals("TextAnchor.CENTER"));

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var5.setLabel("");
//     org.jfree.chart.text.TextAnchor var8 = var5.getLabelTextAnchor();
//     java.lang.String var9 = var8.toString();
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var12.setLabel("");
//     org.jfree.chart.text.TextAnchor var15 = var12.getLabelTextAnchor();
//     java.awt.Shape var16 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("org.jfree.chart.event.ChartProgressEvent[source=0.0]", var1, 100.0f, 0.0f, var8, 12.0d, var15);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    java.awt.Paint var14 = var13.getRangeCrosshairPaint();
    java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
    boolean var16 = var8.equals((java.lang.Object)var13);
    org.jfree.data.xy.XYDataset var18 = var13.getDataset((-16646144));
    boolean var19 = var13.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Stroke var2 = var1.getAxisLineStroke();
//     java.awt.Font var3 = var1.getLabelFont();
//     org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
//     java.awt.Font var5 = var1.getTickLabelFont();
//     var1.setLabelURL("java.awt.Color[r=0,g=0,b=100]");
//     var1.setTickMarkOutsideLength(10.0f);
//     boolean var10 = var1.isTickLabelsVisible();
//     var1.setMaximumCategoryLabelLines(0);
//     var1.setAxisLineVisible(true);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.AxisState var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
//     boolean var22 = var21.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     int var24 = var21.getDomainAxisIndex(var23);
//     var21.mapDatasetToDomainAxis(0, 10);
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     var21.drawBackgroundImage(var28, var29);
//     java.awt.Color var37 = java.awt.Color.getColor("", 100);
//     java.awt.color.ColorSpace var38 = var37.getColorSpace();
//     org.jfree.chart.block.BlockBorder var39 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 111.0d, 10.0d, (java.awt.Paint)var37);
//     var21.setRangeGridlinePaint((java.awt.Paint)var37);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.util.Size2D var44 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     var51.setDomainAxis(0, var53, true);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var57, var58, var59, var60);
//     org.jfree.chart.axis.AxisLocation var63 = var61.getDomainAxisLocation(100);
//     var51.setRangeAxisLocation(0, var63);
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var51);
//     org.jfree.chart.util.RectangleAnchor var66 = var65.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var67 = org.jfree.chart.util.RectangleAnchor.createRectangle(var44, 0.0d, 10.0d, var66);
//     var21.drawBackgroundImage(var41, var67);
//     org.jfree.data.xy.XYDataset var69 = null;
//     org.jfree.chart.axis.ValueAxis var70 = null;
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var69, var70, var71, var72);
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     var73.setDomainAxis(0, var75, true);
//     org.jfree.data.xy.XYDataset var79 = null;
//     org.jfree.chart.axis.ValueAxis var80 = null;
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var82 = null;
//     org.jfree.chart.plot.XYPlot var83 = new org.jfree.chart.plot.XYPlot(var79, var80, var81, var82);
//     org.jfree.chart.axis.AxisLocation var85 = var83.getDomainAxisLocation(100);
//     var73.setRangeAxisLocation(0, var85);
//     org.jfree.chart.title.LegendTitle var87 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var73);
//     java.awt.Paint var88 = var87.getBackgroundPaint();
//     var87.setHeight(111.0d);
//     double var91 = var87.getContentXOffset();
//     org.jfree.chart.block.BlockFrame var92 = var87.getFrame();
//     java.lang.String var93 = var87.getID();
//     org.jfree.chart.util.RectangleEdge var94 = var87.getPosition();
//     java.util.List var95 = var1.refreshTicks(var15, var16, var67, var94);
//     
//     // Checks the contract:  equals-hashcode on var51 and var73
//     assertTrue("Contract failed: equals-hashcode on var51 and var73", var51.equals(var73) ? var51.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var83
//     assertTrue("Contract failed: equals-hashcode on var61 and var83", var61.equals(var83) ? var61.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var51
//     assertTrue("Contract failed: equals-hashcode on var73 and var51", var73.equals(var51) ? var73.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var61
//     assertTrue("Contract failed: equals-hashcode on var83 and var61", var83.equals(var61) ? var83.hashCode() == var61.hashCode() : true);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
//     int var7 = var4.getDatasetCount();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.CrosshairState var12 = null;
//     boolean var13 = var4.render(var8, var9, 1, var11, var12);
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
//     java.awt.Paint var19 = var18.getRangeCrosshairPaint();
//     var4.setRangeGridlinePaint(var19);
//     org.jfree.chart.event.PlotChangeEvent var21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var4);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var22, var23, var24, var25);
//     int var27 = var26.getDatasetCount();
//     int var28 = var26.getSeriesCount();
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     var26.setRangeAxis(var29);
//     org.jfree.data.xy.XYDataset var31 = null;
//     int var32 = var26.indexOf(var31);
//     java.awt.Paint var34 = var26.getQuadrantPaint(1);
//     org.jfree.chart.event.PlotChangeEvent var35 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.event.ChartChangeEventType var36 = var35.getType();
//     var21.setType(var36);
//     
//     // Checks the contract:  equals-hashcode on var18 and var26
//     assertTrue("Contract failed: equals-hashcode on var18 and var26", var18.equals(var26) ? var18.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var18
//     assertTrue("Contract failed: equals-hashcode on var26 and var18", var26.equals(var18) ? var26.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var4.addChangeListener(var8);
    org.jfree.data.xy.XYDataset var11 = var4.getDataset((-1));
    org.jfree.chart.axis.AxisSpace var12 = null;
    var4.setFixedRangeAxisSpace(var12, false);
    java.awt.Stroke var15 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.JFreeChart var17 = null;
    org.jfree.chart.event.ChartProgressEvent var20 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0.0d, var17, (-1), 1);
    var20.setPercent(10);
    var20.setType(10);
    var20.setType((-1));
    java.lang.Object var27 = var20.getSource();
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var35 = null;
    int var36 = var33.getDomainAxisIndex(var35);
    var33.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var33.setFixedRangeAxisSpace(var40, false);
    org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
    java.awt.Stroke var45 = var44.getBorderStroke();
    var20.setChart(var44);
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    java.awt.Paint var52 = var51.getRangeCrosshairPaint();
    var44.setBorderPaint(var52);
    var4.setRangeZeroBaselinePaint(var52);
    java.awt.Paint var55 = var4.getDomainCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + 0.0d+ "'", var27.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     int var7 = var4.getDomainAxisIndex(var6);
//     var4.mapDatasetToDomainAxis(0, 10);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var4.drawBackgroundImage(var11, var12);
//     java.awt.Color var20 = java.awt.Color.getColor("", 100);
//     java.awt.color.ColorSpace var21 = var20.getColorSpace();
//     org.jfree.chart.block.BlockBorder var22 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 111.0d, 10.0d, (java.awt.Paint)var20);
//     var4.setRangeGridlinePaint((java.awt.Paint)var20);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.util.Size2D var27 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     var34.setDomainAxis(0, var36, true);
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var40, var41, var42, var43);
//     org.jfree.chart.axis.AxisLocation var46 = var44.getDomainAxisLocation(100);
//     var34.setRangeAxisLocation(0, var46);
//     org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.util.RectangleAnchor var49 = var48.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var50 = org.jfree.chart.util.RectangleAnchor.createRectangle(var27, 0.0d, 10.0d, var49);
//     var4.drawBackgroundImage(var24, var50);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var52, var53, var54, var55);
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     var56.setDomainAxis(0, var58, true);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var65 = null;
//     org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot(var62, var63, var64, var65);
//     org.jfree.chart.axis.AxisLocation var68 = var66.getDomainAxisLocation(100);
//     var56.setRangeAxisLocation(0, var68);
//     org.jfree.chart.title.LegendTitle var70 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56);
//     org.jfree.chart.util.RectangleInsets var71 = var70.getMargin();
//     java.awt.Graphics2D var72 = null;
//     org.jfree.chart.block.RectangleConstraint var75 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.data.Range var76 = var75.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var78 = var75.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var79 = var70.arrange(var72, var78);
//     org.jfree.chart.util.RectangleAnchor var80 = var70.getLegendItemGraphicLocation();
//     java.awt.geom.Point2D var81 = org.jfree.chart.util.RectangleAnchor.coordinates(var50, var80);
//     
//     // Checks the contract:  equals-hashcode on var34 and var56
//     assertTrue("Contract failed: equals-hashcode on var34 and var56", var34.equals(var56) ? var34.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var66
//     assertTrue("Contract failed: equals-hashcode on var44 and var66", var44.equals(var66) ? var44.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var34
//     assertTrue("Contract failed: equals-hashcode on var56 and var34", var56.equals(var34) ? var56.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var44
//     assertTrue("Contract failed: equals-hashcode on var66 and var44", var66.equals(var44) ? var66.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "RectangleAnchor.CENTER", "hi!", "hi!");
    var4.setCopyright("hi!");
    java.lang.String var7 = var4.getName();
    org.jfree.chart.ui.Library[] var8 = var4.getLibraries();
    java.lang.String var9 = var4.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + ""+ "'", var7.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "hi!"+ "'", var9.equals("hi!"));

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var4.addChangeListener(var8);
    java.util.List var10 = var4.getAnnotations();
    org.jfree.data.xy.XYDataset var11 = null;
    int var12 = var4.indexOf(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    int var24 = var23.getDatasetCount();
    float var25 = var23.getBackgroundAlpha();
    org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var32 = var30.calculateRightOutset(10.0d);
    var23.setInsets(var30);
    var18.setPadding(var30);
    org.jfree.chart.util.RectangleAnchor var35 = var18.getLegendItemGraphicAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    java.awt.Paint var14 = var13.getRangeCrosshairPaint();
    java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
    boolean var16 = var8.equals((java.lang.Object)var13);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var13.rendererChanged(var17);
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var25 = var24.getPaint();
    org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var25);
    var13.setDomainGridlinePaint(var25);
    org.jfree.chart.title.LegendTitle var28 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     java.awt.Paint var5 = var4.getRangeCrosshairPaint();
//     org.jfree.chart.util.Layer var6 = null;
//     java.util.Collection var7 = var4.getRangeMarkers(var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var4.addChangeListener(var8);
//     java.util.List var10 = var4.getAnnotations();
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     var15.setDomainAxis(0, var17, true);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
//     org.jfree.chart.axis.AxisLocation var27 = var25.getDomainAxisLocation(100);
//     var15.setRangeAxisLocation(0, var27);
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
//     java.awt.Paint var30 = var29.getBackgroundPaint();
//     var29.setHeight(111.0d);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     boolean var39 = var38.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     int var41 = var38.getDomainAxisIndex(var40);
//     var38.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var45 = null;
//     var38.setFixedRangeAxisSpace(var45, false);
//     org.jfree.chart.util.RectangleInsets var48 = var38.getInsets();
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var38);
//     var29.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var49);
//     var4.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var49);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    java.awt.Paint var15 = var4.getQuadrantPaint(0);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var20.getDomainAxisLocation(100);
    int var23 = var20.getDatasetCount();
    java.awt.Graphics2D var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    org.jfree.chart.plot.CrosshairState var28 = null;
    boolean var29 = var20.render(var24, var25, 1, var27, var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    java.awt.Paint var35 = var34.getRangeCrosshairPaint();
    var20.setRangeGridlinePaint(var35);
    org.jfree.chart.axis.AxisSpace var37 = null;
    var20.setFixedDomainAxisSpace(var37);
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    java.awt.geom.Point2D var41 = null;
    var20.zoomDomainAxes((-1.0d), var40, var41, true);
    java.awt.Color var46 = java.awt.Color.getColor("", 100);
    var20.setDomainTickBandPaint((java.awt.Paint)var46);
    int var48 = var46.getTransparency();
    var4.setDomainGridlinePaint((java.awt.Paint)var46);
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var53 = var52.getAxisLineStroke();
    java.awt.Font var54 = var52.getLabelFont();
    org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var61 = var60.getPaint();
    org.jfree.chart.block.BlockBorder var62 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var61);
    org.jfree.chart.text.TextLine var63 = new org.jfree.chart.text.TextLine("", var54, var61);
    var4.setDomainZeroBaselinePaint(var61);
    org.jfree.chart.annotations.XYAnnotation var65 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
    org.jfree.chart.axis.CategoryAnchor var52 = var50.getDomainGridlinePosition();
    var50.configureRangeAxes();
    boolean var54 = var50.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }


    int var3 = java.awt.Color.HSBtoRGB(10.0f, 1.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-65536));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = var50.getRenderer((-10));
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var56 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var55};
    var50.setRenderers(var56);
    int var58 = var50.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    org.jfree.chart.plot.Plot var7 = var4.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    java.awt.Paint var15 = var4.getQuadrantPaint(0);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var20.getDomainAxisLocation(100);
    int var23 = var20.getDatasetCount();
    java.awt.Graphics2D var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    org.jfree.chart.plot.CrosshairState var28 = null;
    boolean var29 = var20.render(var24, var25, 1, var27, var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    java.awt.Paint var35 = var34.getRangeCrosshairPaint();
    var20.setRangeGridlinePaint(var35);
    org.jfree.chart.axis.AxisSpace var37 = null;
    var20.setFixedDomainAxisSpace(var37);
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    java.awt.geom.Point2D var41 = null;
    var20.zoomDomainAxes((-1.0d), var40, var41, true);
    java.awt.Color var46 = java.awt.Color.getColor("", 100);
    var20.setDomainTickBandPaint((java.awt.Paint)var46);
    int var48 = var46.getTransparency();
    var4.setDomainGridlinePaint((java.awt.Paint)var46);
    org.jfree.chart.axis.AxisSpace var50 = null;
    var4.setFixedDomainAxisSpace(var50, false);
    var4.setRangeCrosshairVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    boolean var5 = var4.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var6 = null;
    int var7 = var4.getDomainAxisIndex(var6);
    var4.mapDatasetToDomainAxis(0, 10);
    var4.clearRangeMarkers();
    var4.configureRangeAxes();
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    boolean var19 = var18.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var20 = null;
    int var21 = var18.getDomainAxisIndex(var20);
    var18.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var25 = null;
    var18.setFixedRangeAxisSpace(var25, false);
    org.jfree.chart.util.RectangleInsets var28 = var18.getInsets();
    org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var18);
    var29.setTextAntiAlias(true);
    java.awt.Color var35 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var36 = var35.darker();
    java.awt.Color var37 = java.awt.Color.getColor("0,0,0,0,0,0,0,0,0,0,0,0", var35);
    var29.setBorderPaint((java.awt.Paint)var37);
    var4.setNoDataMessagePaint((java.awt.Paint)var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleAnchor.CENTER");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var4 = var3.getPaint();
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.util.Size2D var10 = var8.calculateDimensions(var9);
//     double var11 = var10.getWidth();
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var12, var13, var14, var15);
//     int var17 = var16.getDatasetCount();
//     int var18 = var16.getSeriesCount();
//     boolean var19 = var10.equals((java.lang.Object)var16);
//     org.jfree.chart.event.MarkerChangeEvent var20 = null;
//     var16.markerChanged(var20);
//     var16.setNoDataMessage("java.awt.Color[r=0,g=0,b=100]");
//     boolean var24 = var16.isRangeGridlinesVisible();
//     org.jfree.chart.plot.Marker var25 = null;
//     org.jfree.chart.util.Layer var26 = null;
//     var16.addRangeMarker(var25, var26);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0.0d, var1, (-1), 1);
    var4.setPercent(10);
    var4.setType(10);
    var4.setType((-1));
    java.lang.Object var11 = var4.getSource();
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var16 = null;
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot(var13, var14, var15, var16);
    boolean var18 = var17.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var19 = null;
    int var20 = var17.getDomainAxisIndex(var19);
    var17.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var17.setFixedRangeAxisSpace(var24, false);
    org.jfree.chart.util.RectangleInsets var27 = var17.getInsets();
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var17);
    java.awt.Stroke var29 = var28.getBorderStroke();
    var4.setChart(var28);
    org.jfree.data.xy.XYDataset var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var31, var32, var33, var34);
    org.jfree.chart.axis.ValueAxis var37 = null;
    var35.setDomainAxis(0, var37, true);
    org.jfree.data.xy.XYDataset var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var41, var42, var43, var44);
    org.jfree.chart.axis.AxisLocation var47 = var45.getDomainAxisLocation(100);
    var35.setRangeAxisLocation(0, var47);
    org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var35);
    org.jfree.chart.util.RectangleInsets var50 = var49.getMargin();
    java.awt.Graphics2D var51 = null;
    org.jfree.chart.block.RectangleConstraint var54 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var55 = var54.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var57 = var54.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var58 = var49.arrange(var51, var57);
    org.jfree.data.xy.XYDataset var59 = null;
    org.jfree.chart.axis.ValueAxis var60 = null;
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
    org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot(var59, var60, var61, var62);
    org.jfree.chart.axis.AxisLocation var65 = var63.getDomainAxisLocation(100);
    var63.setBackgroundAlpha(0.0f);
    var63.setDomainCrosshairValue(100.0d, false);
    org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var72 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var71};
    var63.setRenderers(var72);
    var49.setSources((org.jfree.chart.LegendItemSource[])var72);
    var28.addSubtitle((org.jfree.chart.title.Title)var49);
    java.awt.Font var77 = null;
    org.jfree.chart.text.TextFragment var79 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var80 = var79.getPaint();
    org.jfree.chart.text.TextMeasurer var83 = null;
    org.jfree.chart.text.TextBlock var84 = org.jfree.chart.text.TextUtilities.createTextBlock("", var77, var80, 10.0f, 0, var83);
    java.awt.Graphics2D var85 = null;
    org.jfree.chart.text.TextBlockAnchor var88 = null;
    java.awt.Shape var92 = var84.calculateBounds(var85, 0.0f, 0.0f, var88, 0.0f, (-1.0f), 100.0d);
    java.awt.Graphics2D var93 = null;
    org.jfree.chart.text.TextBlockAnchor var96 = null;
    var84.draw(var93, 10.0f, 0.0f, var96);
    java.util.List var98 = var84.getLines();
    var28.setSubtitles(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0.0d+ "'", var11.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }


    java.awt.Font var1 = null;
    java.awt.Font var3 = null;
    org.jfree.chart.text.TextFragment var5 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var6 = var5.getPaint();
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, var6, 10.0f, 0, var9);
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var6, 0.0f, 10, var13);
    org.jfree.chart.util.HorizontalAlignment var15 = var14.getLineAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    var18.setHeight(111.0d);
    double var22 = var18.getContentXOffset();
    var18.setID("");
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var26, var27, var28, var29);
    boolean var31 = var30.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var32 = null;
    int var33 = var30.getDomainAxisIndex(var32);
    var30.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var37 = null;
    var30.setFixedRangeAxisSpace(var37, false);
    org.jfree.chart.util.RectangleInsets var40 = var30.getInsets();
    org.jfree.chart.JFreeChart var41 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var30);
    java.awt.Stroke var42 = var41.getBorderStroke();
    org.jfree.chart.plot.Plot var43 = var41.getPlot();
    java.awt.RenderingHints var44 = var41.getRenderingHints();
    org.jfree.chart.title.LegendTitle var45 = var41.getLegend();
    var18.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var41);
    java.awt.Image var47 = null;
    var41.setBackgroundImage(var47);
    org.jfree.chart.event.ChartProgressListener var49 = null;
    var41.addProgressListener(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.chart.axis.AxisLocation var7 = var5.getDomainAxisLocation(100);
//     int var8 = var5.getDatasetCount();
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.plot.CrosshairState var13 = null;
//     boolean var14 = var5.render(var9, var10, 1, var12, var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
//     java.awt.Paint var20 = var19.getRangeCrosshairPaint();
//     var5.setRangeGridlinePaint(var20);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     var5.setFixedDomainAxisSpace(var22);
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     java.awt.geom.Point2D var26 = null;
//     var5.zoomDomainAxes((-1.0d), var25, var26, true);
//     org.jfree.chart.event.RendererChangeEvent var29 = null;
//     var5.rendererChanged(var29);
//     java.awt.Font var31 = var5.getNoDataMessageFont();
//     java.awt.Font var33 = null;
//     java.awt.Font var35 = null;
//     org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var38 = var37.getPaint();
//     org.jfree.chart.text.TextMeasurer var41 = null;
//     org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("", var35, var38, 10.0f, 0, var41);
//     org.jfree.chart.text.TextMeasurer var45 = null;
//     org.jfree.chart.text.TextBlock var46 = org.jfree.chart.text.TextUtilities.createTextBlock("", var33, var38, 0.0f, 10, var45);
//     org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=0,g=0,b=100]", var31, var38);
//     java.awt.Graphics2D var48 = null;
//     org.jfree.chart.text.TextBlockAnchor var51 = null;
//     var47.draw(var48, (-1.0f), 10.0f, var51, 10.0f, 1.0f, 118.0d);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    var50.clearRangeAxes();
    org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
    java.awt.Paint var55 = var50.getRangeCrosshairPaint();
    java.awt.Paint var56 = var50.getDomainGridlinePaint();
    boolean var57 = var50.isRangeZoomable();
    var50.setWeight(100);
    org.jfree.chart.plot.PlotRenderingInfo var62 = null;
    java.awt.geom.Point2D var63 = null;
    var50.zoomRangeAxes((-1.0d), (-1.0d), var62, var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var4.setDomainAxis(0, var6, true);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
//     var4.setRangeAxisLocation(0, var16);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
//     org.jfree.data.Range var24 = var23.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
//     org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.ValueAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
//     boolean var34 = var33.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     int var36 = var33.getDomainAxisIndex(var35);
//     var33.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var40 = null;
//     var33.setFixedRangeAxisSpace(var40, false);
//     org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
//     org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
//     java.awt.Stroke var45 = var44.getBorderStroke();
//     boolean var46 = var18.equals((java.lang.Object)var44);
//     java.awt.Image var47 = null;
//     var44.setBackgroundImage(var47);
//     org.jfree.chart.title.TextTitle var49 = var44.getTitle();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.util.RectangleInsets var55 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var56 = var55.getLeft();
//     double var57 = var55.getRight();
//     double var59 = var55.extendHeight(116.0d);
//     org.jfree.chart.util.Size2D var62 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot(var65, var66, var67, var68);
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     var69.setDomainAxis(0, var71, true);
//     org.jfree.data.xy.XYDataset var75 = null;
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var78 = null;
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot(var75, var76, var77, var78);
//     org.jfree.chart.axis.AxisLocation var81 = var79.getDomainAxisLocation(100);
//     var69.setRangeAxisLocation(0, var81);
//     org.jfree.chart.title.LegendTitle var83 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var69);
//     org.jfree.chart.util.RectangleAnchor var84 = var83.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var85 = org.jfree.chart.util.RectangleAnchor.createRectangle(var62, 0.0d, 10.0d, var84);
//     java.awt.geom.Rectangle2D var88 = var55.createOutsetRectangle(var85, true, true);
//     var49.draw(var50, var85);
//     
//     // Checks the contract:  equals-hashcode on var4 and var69
//     assertTrue("Contract failed: equals-hashcode on var4 and var69", var4.equals(var69) ? var4.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var79
//     assertTrue("Contract failed: equals-hashcode on var14 and var79", var14.equals(var79) ? var14.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var4
//     assertTrue("Contract failed: equals-hashcode on var69 and var4", var69.equals(var4) ? var69.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var14
//     assertTrue("Contract failed: equals-hashcode on var79 and var14", var79.equals(var14) ? var79.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    int var51 = var50.getWeight();
    org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis("hi!");
    float var54 = var53.getTickMarkInsideLength();
    java.lang.String var56 = var53.getCategoryLabelToolTip((java.lang.Comparable)'4');
    java.lang.Object var57 = var53.clone();
    java.util.List var58 = var50.getCategoriesForAxis(var53);
    org.jfree.chart.plot.CategoryMarker var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.addDomainMarker(var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    int var51 = var50.getWeight();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    var50.setRenderer(100, var53, false);
    org.jfree.chart.axis.AxisLocation var56 = var50.getRangeAxisLocation();
    boolean var57 = var50.isDomainZoomable();
    org.jfree.data.category.CategoryDataset var59 = null;
    var50.setDataset(0, var59);
    org.jfree.chart.event.MarkerChangeEvent var61 = null;
    var50.markerChanged(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleConstraint[LengthConstraintType.FIXED: width=-1.0, height=0.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=10.0]", "", "0,0,0,0,0,0,0,0,0,0,0,0", "Range[1.0,1.0]");

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
    java.awt.Font var5 = var1.getTickLabelFont();
    org.jfree.chart.util.RectangleInsets var6 = var1.getTickLabelInsets();
    double var7 = var1.getLowerMargin();
    var1.setLabel("java.awt.Color[r=0,g=0,b=100]");
    float var10 = var1.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0f);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("");
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot(var2, var3, var4, var5);
//     org.jfree.chart.axis.AxisLocation var8 = var6.getDomainAxisLocation(100);
//     int var9 = var6.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     var6.setRenderer(var10);
//     org.jfree.chart.util.RectangleInsets var16 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var18 = var16.calculateRightOutset(10.0d);
//     var6.setInsets(var16);
//     boolean var20 = var1.equals((java.lang.Object)var6);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.util.Size2D var22 = var1.calculateDimensions(var21);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var1.setLabel("");
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    org.jfree.chart.axis.ValueAxis var10 = null;
    var8.setDomainAxis(0, var10, true);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    org.jfree.chart.axis.AxisLocation var20 = var18.getDomainAxisLocation(100);
    var8.setRangeAxisLocation(0, var20);
    org.jfree.chart.JFreeChart var23 = null;
    org.jfree.chart.event.ChartProgressEvent var26 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0.0d, var23, (-1), 1);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, var31);
    boolean var33 = var32.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var34 = null;
    int var35 = var32.getDomainAxisIndex(var34);
    var32.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var39 = null;
    var32.setFixedRangeAxisSpace(var39, false);
    org.jfree.chart.util.RectangleInsets var42 = var32.getInsets();
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var32);
    org.jfree.chart.event.ChartChangeEventType var44 = null;
    org.jfree.chart.event.ChartChangeEvent var45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)1, var43, var44);
    org.jfree.chart.util.RectangleInsets var46 = var43.getPadding();
    org.jfree.chart.event.ChartProgressListener var47 = null;
    var43.removeProgressListener(var47);
    java.awt.Paint var49 = var43.getBackgroundPaint();
    var8.setRangeTickBandPaint(var49);
    var1.setLabelPaint(var49);
    java.awt.Stroke var52 = var1.getStroke();
    org.jfree.chart.util.RectangleAnchor var53 = var1.getLabelAnchor();
    org.jfree.chart.util.RectangleInsets var54 = var1.getLabelOffset();
    double var55 = var1.getValue();
    org.jfree.chart.text.TextAnchor var56 = var1.getLabelTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 116.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    int var18 = var4.getRangeAxisCount();
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    org.jfree.chart.axis.AxisLocation var26 = var24.getDomainAxisLocation(100);
    boolean var27 = var24.isDomainCrosshairLockedOnData();
    org.jfree.chart.axis.AxisLocation var28 = var24.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation((-1), var28, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var24 = var23.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var35 = null;
    int var36 = var33.getDomainAxisIndex(var35);
    var33.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var33.setFixedRangeAxisSpace(var40, false);
    org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
    java.awt.Stroke var45 = var44.getBorderStroke();
    boolean var46 = var18.equals((java.lang.Object)var44);
    java.awt.Image var47 = null;
    var44.setBackgroundImage(var47);
    org.jfree.chart.title.TextTitle var49 = var44.getTitle();
    var49.setToolTipText("java.awt.Color[r=0,g=0,b=142]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=0,b=142]");

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var1.setLabel("");
//     org.jfree.chart.text.TextAnchor var4 = var1.getLabelTextAnchor();
//     java.lang.Class var5 = null;
//     java.util.EventListener[] var6 = var1.getListeners(var5);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     int var5 = var4.getDatasetCount();
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
//     org.jfree.chart.axis.AxisLocation var12 = var10.getDomainAxisLocation(100);
//     int var13 = var10.getDatasetCount();
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.plot.CrosshairState var18 = null;
//     boolean var19 = var10.render(var14, var15, 1, var17, var18);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
//     java.awt.Paint var25 = var24.getRangeCrosshairPaint();
//     var10.setRangeGridlinePaint(var25);
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var10.setFixedDomainAxisSpace(var27);
//     java.awt.Paint var29 = var10.getBackgroundPaint();
//     var4.setOutlinePaint(var29);
//     var4.setDomainZeroBaselineVisible(false);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, var37);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     var38.setDomainAxis(0, var40, true);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var44, var45, var46, var47);
//     org.jfree.chart.axis.AxisLocation var50 = var48.getDomainAxisLocation(100);
//     var38.setRangeAxisLocation(0, var50);
//     org.jfree.chart.title.LegendTitle var52 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var38);
//     double var53 = var52.getContentYOffset();
//     org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Stroke var56 = var55.getAxisLineStroke();
//     java.awt.Font var57 = var55.getLabelFont();
//     var55.setVisible(false);
//     org.jfree.data.xy.XYDataset var60 = null;
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
//     org.jfree.chart.axis.AxisLocation var66 = var64.getDomainAxisLocation(100);
//     int var67 = var64.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var68 = null;
//     var64.setRenderer(var68);
//     org.jfree.chart.util.RectangleInsets var74 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var76 = var74.calculateRightOutset(10.0d);
//     var64.setInsets(var74);
//     var55.setLabelInsets(var74);
//     boolean var79 = var52.equals((java.lang.Object)var55);
//     float var80 = var55.getTickMarkOutsideLength();
//     org.jfree.chart.axis.ValueAxis var81 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var82 = null;
//     org.jfree.chart.plot.CategoryPlot var83 = new org.jfree.chart.plot.CategoryPlot(var33, var55, var81, var82);
//     var83.setAnchorValue(100.0d);
//     var83.setRangeCrosshairValue(0.0d, false);
//     java.awt.Stroke var89 = var83.getRangeGridlineStroke();
//     java.awt.Stroke var90 = var83.getRangeGridlineStroke();
//     org.jfree.chart.plot.ValueMarker var93 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var93.setLabel("");
//     org.jfree.chart.text.TextAnchor var96 = var93.getLabelTextAnchor();
//     org.jfree.chart.util.Layer var97 = null;
//     var83.addRangeMarker((-16777116), (org.jfree.chart.plot.Marker)var93, var97);
//     boolean var99 = var4.removeDomainMarker((org.jfree.chart.plot.Marker)var93);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var7, var8, var9, var10);
    org.jfree.chart.axis.ValueAxis var13 = null;
    var11.setDomainAxis(0, var13, true);
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var17, var18, var19, var20);
    org.jfree.chart.axis.AxisLocation var23 = var21.getDomainAxisLocation(100);
    var11.setRangeAxisLocation(0, var23);
    var4.setDomainAxisLocation(var23);
    java.awt.Graphics2D var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    var4.drawAnnotations(var26, var27, var28);
    var4.zoom(10.0d);
    org.jfree.chart.util.RectangleEdge var32 = var4.getDomainAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(12.0d, 100.0d, 116.0d, 116.0d);
    org.jfree.chart.util.UnitType var5 = var4.getUnitType();
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    org.jfree.chart.axis.AxisLocation var12 = var10.getDomainAxisLocation(100);
    int var13 = var10.getDatasetCount();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.CrosshairState var18 = null;
    boolean var19 = var10.render(var14, var15, 1, var17, var18);
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    java.awt.Paint var25 = var24.getRangeCrosshairPaint();
    var10.setRangeGridlinePaint(var25);
    org.jfree.chart.axis.AxisSpace var27 = null;
    var10.setFixedDomainAxisSpace(var27);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    java.awt.geom.Point2D var31 = null;
    var10.zoomDomainAxes((-1.0d), var30, var31, true);
    java.awt.Color var36 = java.awt.Color.getColor("", 100);
    var10.setDomainTickBandPaint((java.awt.Paint)var36);
    java.awt.Paint var38 = var10.getBackgroundPaint();
    boolean var39 = var5.equals((java.lang.Object)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     var5.setDomainAxis(0, var7, true);
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
//     org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
//     var5.setRangeAxisLocation(0, var17);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
//     double var20 = var19.getContentYOffset();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     java.awt.Stroke var23 = var22.getAxisLineStroke();
//     java.awt.Font var24 = var22.getLabelFont();
//     var22.setVisible(false);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
//     org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
//     int var34 = var31.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     var31.setRenderer(var35);
//     org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var43 = var41.calculateRightOutset(10.0d);
//     var31.setInsets(var41);
//     var22.setLabelInsets(var41);
//     boolean var46 = var19.equals((java.lang.Object)var22);
//     float var47 = var22.getTickMarkOutsideLength();
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
//     org.jfree.chart.axis.AxisSpace var51 = null;
//     var50.setFixedDomainAxisSpace(var51);
//     var50.clearRangeAxes();
//     org.jfree.chart.plot.PlotOrientation var54 = var50.getOrientation();
//     var50.setRangeCrosshairValue(1.0d, true);
//     org.jfree.data.xy.XYDataset var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var58, var59, var60, var61);
//     org.jfree.chart.axis.AxisLocation var64 = var62.getDomainAxisLocation(100);
//     var62.setBackgroundAlpha(0.0f);
//     org.jfree.data.xy.XYDataset var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.axis.ValueAxis var69 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var70 = null;
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot(var67, var68, var69, var70);
//     java.awt.Paint var72 = var71.getRangeCrosshairPaint();
//     java.awt.Stroke var73 = var71.getRangeCrosshairStroke();
//     var62.setDomainCrosshairStroke(var73);
//     var50.setDomainGridlineStroke(var73);
//     
//     // Checks the contract:  equals-hashcode on var15 and var71
//     assertTrue("Contract failed: equals-hashcode on var15 and var71", var15.equals(var71) ? var15.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var15
//     assertTrue("Contract failed: equals-hashcode on var71 and var15", var71.equals(var15) ? var71.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleAnchor var19 = var18.getLegendItemGraphicLocation();
    org.jfree.chart.util.RectangleInsets var20 = var18.getItemLabelPadding();
    org.jfree.chart.util.HorizontalAlignment var21 = var18.getHorizontalAlignment();
    org.jfree.data.xy.XYDataset var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var23, var24, var25, var26);
    boolean var28 = var27.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var29 = null;
    int var30 = var27.getDomainAxisIndex(var29);
    var27.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var34 = null;
    var27.setFixedRangeAxisSpace(var34, false);
    org.jfree.chart.util.RectangleInsets var37 = var27.getInsets();
    org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var27);
    java.awt.Stroke var39 = var38.getBorderStroke();
    var18.addChangeListener((org.jfree.chart.event.TitleChangeListener)var38);
    var38.removeLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    java.awt.geom.Point2D var25 = null;
    var4.zoomDomainAxes((-1.0d), var24, var25, true);
    java.awt.Color var30 = java.awt.Color.getColor("", 100);
    var4.setDomainTickBandPaint((java.awt.Paint)var30);
    java.awt.Paint var32 = var4.getBackgroundPaint();
    var4.setBackgroundAlpha(1.0f);
    boolean var35 = var4.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    var50.setRangeCrosshairValue(0.0d, false);
    java.awt.Stroke var56 = var50.getRangeGridlineStroke();
    java.awt.Stroke var57 = var50.getRangeGridlineStroke();
    org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
    var50.setRenderer(0, var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var11 = var10.getPaint();
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var11);
    var4.setRangeCrosshairPaint(var11);
    org.jfree.chart.LegendItemCollection var14 = null;
    var4.setFixedLegendItems(var14);
    double var16 = var4.getDomainCrosshairValue();
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("");
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.AxisLocation var27 = var25.getDomainAxisLocation(100);
    int var28 = var25.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
    var25.setRenderer(var29);
    org.jfree.chart.util.RectangleInsets var35 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var37 = var35.calculateRightOutset(10.0d);
    var25.setInsets(var35);
    boolean var39 = var20.equals((java.lang.Object)var25);
    org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("hi!");
    var20.addFragment(var41);
    float var43 = var41.getBaselineOffset();
    java.awt.Font var44 = var41.getFont();
    org.jfree.chart.text.TextLine var45 = new org.jfree.chart.text.TextLine("hi!", var44);
    org.jfree.data.xy.XYDataset var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var46, var47, var48, var49);
    org.jfree.chart.axis.AxisLocation var52 = var50.getDomainAxisLocation(100);
    int var53 = var50.getDatasetCount();
    java.awt.Graphics2D var54 = null;
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.plot.PlotRenderingInfo var57 = null;
    org.jfree.chart.plot.CrosshairState var58 = null;
    boolean var59 = var50.render(var54, var55, 1, var57, var58);
    org.jfree.data.xy.XYDataset var60 = null;
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var63 = null;
    org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot(var60, var61, var62, var63);
    java.awt.Paint var65 = var64.getRangeCrosshairPaint();
    var50.setRangeGridlinePaint(var65);
    org.jfree.chart.axis.AxisSpace var67 = null;
    var50.setFixedDomainAxisSpace(var67);
    org.jfree.chart.plot.PlotRenderingInfo var70 = null;
    java.awt.geom.Point2D var71 = null;
    var50.zoomDomainAxes((-1.0d), var70, var71, true);
    java.awt.Color var76 = java.awt.Color.getColor("", 100);
    var50.setDomainTickBandPaint((java.awt.Paint)var76);
    java.awt.Paint var78 = var50.getBackgroundPaint();
    org.jfree.chart.text.TextFragment var80 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=0,g=0,b=100]", var44, var78, 1.0f);
    var4.setRangeZeroBaselinePaint(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    java.awt.Stroke var6 = var4.getDomainZeroBaselineStroke();
    var4.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "RectangleAnchor.CENTER", "", var3, "hi!", "", "");
    var7.addOptionalLibrary("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    java.awt.Font var3 = var1.getLabelFont();
    var1.setVisible(false);
    org.jfree.chart.axis.CategoryLabelPositions var6 = var1.getCategoryLabelPositions();
    var1.setMaximumCategoryLabelWidthRatio(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var11 = var10.getPaint();
//     org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var11);
//     var4.setRangeCrosshairPaint(var11);
//     org.jfree.chart.LegendItemCollection var14 = null;
//     var4.setFixedLegendItems(var14);
//     var4.setOutlineVisible(false);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var18, var19, var20, var21);
//     org.jfree.chart.axis.AxisLocation var24 = var22.getDomainAxisLocation(100);
//     int var25 = var22.getDatasetCount();
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var29 = null;
//     org.jfree.chart.plot.CrosshairState var30 = null;
//     boolean var31 = var22.render(var26, var27, 1, var29, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
//     java.awt.Paint var37 = var36.getRangeCrosshairPaint();
//     var22.setRangeGridlinePaint(var37);
//     org.jfree.chart.axis.AxisSpace var39 = null;
//     var22.setFixedDomainAxisSpace(var39);
//     java.awt.Paint var41 = var22.getBackgroundPaint();
//     var4.setRangeZeroBaselinePaint(var41);
//     java.awt.Stroke var43 = var4.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
//     double var49 = var48.getLeft();
//     double var51 = var48.calculateTopInset(10.0d);
//     org.jfree.data.xy.XYDataset var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var52, var53, var54, var55);
//     java.awt.Paint var57 = var56.getRangeCrosshairPaint();
//     java.awt.Stroke var58 = var56.getRangeCrosshairStroke();
//     boolean var59 = var48.equals((java.lang.Object)var58);
//     double var61 = var48.calculateRightOutset(10.0d);
//     double var63 = var48.extendHeight(10.0d);
//     var4.setInsets(var48, true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var56
//     assertTrue("Contract failed: equals-hashcode on var36 and var56", var36.equals(var56) ? var36.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var36
//     assertTrue("Contract failed: equals-hashcode on var56 and var36", var56.equals(var36) ? var56.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var1.setLabel("");
    java.awt.Paint var4 = var1.getPaint();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.data.xy.XYDataset var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var6, var7, var8, var9);
    org.jfree.chart.axis.ValueAxis var12 = null;
    var10.setDomainAxis(0, var12, true);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var20.getDomainAxisLocation(100);
    var10.setRangeAxisLocation(0, var22);
    org.jfree.chart.title.LegendTitle var24 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10);
    double var25 = var24.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var28 = var27.getAxisLineStroke();
    java.awt.Font var29 = var27.getLabelFont();
    var27.setVisible(false);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var32, var33, var34, var35);
    org.jfree.chart.axis.AxisLocation var38 = var36.getDomainAxisLocation(100);
    int var39 = var36.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    var36.setRenderer(var40);
    org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var48 = var46.calculateRightOutset(10.0d);
    var36.setInsets(var46);
    var27.setLabelInsets(var46);
    boolean var51 = var24.equals((java.lang.Object)var27);
    float var52 = var27.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var53 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = null;
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot(var5, var27, var53, var54);
    org.jfree.chart.axis.AxisSpace var56 = null;
    var55.setFixedDomainAxisSpace(var56);
    var55.clearRangeAxes();
    org.jfree.chart.plot.PlotOrientation var59 = var55.getOrientation();
    java.awt.Paint var60 = var55.getRangeCrosshairPaint();
    int var61 = var55.getDatasetCount();
    org.jfree.chart.util.RectangleInsets var66 = new org.jfree.chart.util.RectangleInsets(12.0d, 0.0d, 12.0d, 10.0d);
    double var68 = var66.calculateRightInset(118.0d);
    var55.setAxisOffset(var66);
    var1.setLabelOffset(var66);
    double var72 = var66.extendWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 10.0d);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var3, "hi!", "hi!", "");
    java.lang.String var8 = var7.getInfo();
    java.awt.Image var12 = null;
    org.jfree.chart.ui.ProjectInfo var16 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var12, "hi!", "hi!", "");
    java.lang.String var17 = var16.getLicenceText();
    java.lang.String var18 = var16.getVersion();
    var16.addOptionalLibrary("");
    boolean var21 = var7.equals((java.lang.Object)"");
    java.awt.Image var25 = null;
    org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo("hi!", "", "hi!", var25, "hi!", "hi!", "");
    java.lang.String var30 = var29.getInfo();
    java.util.List var31 = var29.getContributors();
    var7.addLibrary((org.jfree.chart.ui.Library)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + ""+ "'", var18.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "hi!"+ "'", var30.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var17 = var16.getBorderStroke();
    java.lang.Object var18 = var16.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.plot.XYPlot var17 = var16.getXYPlot();
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    org.jfree.chart.axis.ValueAxis var25 = null;
    var23.setDomainAxis(0, var25, true);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    org.jfree.chart.axis.AxisLocation var35 = var33.getDomainAxisLocation(100);
    var23.setRangeAxisLocation(0, var35);
    org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23);
    double var38 = var37.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var41 = var40.getAxisLineStroke();
    java.awt.Font var42 = var40.getLabelFont();
    var40.setVisible(false);
    org.jfree.data.xy.XYDataset var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var45, var46, var47, var48);
    org.jfree.chart.axis.AxisLocation var51 = var49.getDomainAxisLocation(100);
    int var52 = var49.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
    var49.setRenderer(var53);
    org.jfree.chart.util.RectangleInsets var59 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var61 = var59.calculateRightOutset(10.0d);
    var49.setInsets(var59);
    var40.setLabelInsets(var59);
    boolean var64 = var37.equals((java.lang.Object)var40);
    float var65 = var40.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var66 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var67 = null;
    org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot(var18, var40, var66, var67);
    var68.setAnchorValue(100.0d);
    var68.setRangeCrosshairValue(0.0d, false);
    java.awt.Stroke var74 = var68.getRangeGridlineStroke();
    java.awt.Stroke var75 = var68.getRangeGridlineStroke();
    org.jfree.chart.plot.ValueMarker var78 = new org.jfree.chart.plot.ValueMarker(116.0d);
    var78.setLabel("");
    org.jfree.chart.text.TextAnchor var81 = var78.getLabelTextAnchor();
    org.jfree.chart.util.Layer var82 = null;
    var68.addRangeMarker((-16777116), (org.jfree.chart.plot.Marker)var78, var82);
    org.jfree.chart.util.Layer var84 = null;
    var17.addRangeMarker((org.jfree.chart.plot.Marker)var78, var84);
    org.jfree.chart.util.LengthAdjustmentType var86 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var78.setLabelOffsetType(var86);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test193"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var19 = var18.getMargin();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var24 = var23.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var26 = var23.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var27 = var18.arrange(var20, var26);
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var29, var30, var31, var32);
    boolean var34 = var33.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var35 = null;
    int var36 = var33.getDomainAxisIndex(var35);
    var33.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var40 = null;
    var33.setFixedRangeAxisSpace(var40, false);
    org.jfree.chart.util.RectangleInsets var43 = var33.getInsets();
    org.jfree.chart.JFreeChart var44 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var33);
    java.awt.Stroke var45 = var44.getBorderStroke();
    boolean var46 = var18.equals((java.lang.Object)var44);
    org.jfree.chart.title.LegendTitle var47 = var44.getLegend();
    org.jfree.chart.title.LegendTitle var49 = var44.getLegend(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test194"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    boolean var23 = var4.isDomainCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test195"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     int var5 = var4.getDatasetCount();
//     org.jfree.chart.axis.AxisSpace var6 = null;
//     var4.setFixedRangeAxisSpace(var6);
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     int var9 = var4.getRangeAxisIndex(var8);
//     int var10 = var4.getSeriesCount();
//     var4.zoom(100.0d);
//     org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var14.setLabel("");
//     java.awt.Paint var17 = var14.getPaint();
//     java.awt.Font var18 = var14.getLabelFont();
//     org.jfree.chart.util.Layer var19 = null;
//     boolean var20 = var4.removeDomainMarker((org.jfree.chart.plot.Marker)var14, var19);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test196"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    org.jfree.chart.axis.ValueAxis var8 = var4.getDomainAxis(100);
    java.awt.Image var9 = var4.getBackgroundImage();
    org.jfree.chart.axis.AxisLocation var10 = var4.getDomainAxisLocation();
    boolean var11 = var4.isRangeCrosshairVisible();
    java.awt.Stroke var12 = var4.getOutlineStroke();
    org.jfree.chart.util.RectangleEdge var13 = var4.getDomainAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test197"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(1.0d);
    org.jfree.data.Range var5 = var2.getWidthRange();
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    java.awt.Font var10 = null;
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var13 = var12.getPaint();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13, 10.0f, 0, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    java.awt.Shape var25 = var17.calculateBounds(var18, 0.0f, 0.0f, var21, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity(var25, "");
    java.lang.Object var28 = var27.clone();
    java.awt.Font var30 = null;
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var33 = var32.getPaint();
    org.jfree.chart.text.TextMeasurer var36 = null;
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, var33, 10.0f, 0, var36);
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.text.TextBlockAnchor var41 = null;
    java.awt.Shape var45 = var37.calculateBounds(var38, 0.0f, 0.0f, var41, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var47 = new org.jfree.chart.entity.ChartEntity(var45, "");
    var27.setArea(var45);
    org.jfree.chart.block.RectangleConstraint var51 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var53 = var51.toFixedHeight(1.0d);
    org.jfree.chart.block.RectangleConstraint var54 = var51.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var57 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var58 = var57.getHeightRange();
    org.jfree.data.Range var60 = null;
    org.jfree.data.Range var62 = org.jfree.data.Range.expandToInclude(var60, 1.0d);
    org.jfree.chart.block.RectangleConstraint var63 = new org.jfree.chart.block.RectangleConstraint(10.0d, var62);
    org.jfree.chart.block.RectangleConstraint var64 = var57.toRangeHeight(var62);
    boolean var67 = var62.intersects(10.0d, 1.0d);
    boolean var69 = var62.contains(111.0d);
    org.jfree.chart.block.RectangleConstraint var70 = var54.toRangeWidth(var62);
    org.jfree.chart.block.RectangleConstraint var72 = new org.jfree.chart.block.RectangleConstraint(var62, 0.0d);
    boolean var73 = var27.equals((java.lang.Object)var62);
    org.jfree.data.Range var76 = org.jfree.data.Range.expand(var62, 0.0d, 0.0d);
    org.jfree.data.Range var79 = org.jfree.data.Range.expand(var62, 0.0d, 0.0d);
    org.jfree.chart.block.RectangleConstraint var80 = var8.toRangeHeight(var79);
    org.jfree.chart.block.RectangleConstraint var81 = var2.toRangeHeight(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test198"); }


    java.awt.Color var2 = java.awt.Color.getColor("org.jfree.chart.event.ChartProgressEvent[source=0.0]", 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test199"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var17 = var16.getBorderStroke();
    org.jfree.chart.plot.Plot var18 = var16.getPlot();
    java.awt.RenderingHints var19 = var16.getRenderingHints();
    org.jfree.chart.title.LegendTitle var20 = var16.getLegend();
    java.awt.RenderingHints var21 = var16.getRenderingHints();
    var16.removeLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test200"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    java.awt.Paint var14 = var13.getRangeCrosshairPaint();
    java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
    boolean var16 = var8.equals((java.lang.Object)var13);
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var13.rendererChanged(var17);
    org.jfree.chart.axis.ValueAxis var20 = null;
    var13.setDomainAxis(0, var20, false);
    boolean var23 = var13.isRangeZoomable();
    var13.clearDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test201"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 1.0d);
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(10.0d, var3);
    org.jfree.data.Range var5 = var4.getHeightRange();
    double var6 = var5.getCentralValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test202"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var16, "java.awt.Color[r=0,g=0,b=100]", "RectangleAnchor.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test203"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     boolean var5 = var4.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     int var7 = var4.getDomainAxisIndex(var6);
//     var4.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var11 = null;
//     var4.setFixedRangeAxisSpace(var11, false);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
//     boolean var21 = var20.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     int var23 = var20.getDomainAxisIndex(var22);
//     var20.mapDatasetToDomainAxis(0, 10);
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var20.setFixedRangeAxisSpace(var27, false);
//     org.jfree.chart.util.RectangleInsets var30 = var20.getInsets();
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.plot.XYPlot var32 = var31.getXYPlot();
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.data.Range var34 = var32.getDataRange(var33);
//     java.awt.Graphics2D var35 = null;
//     java.awt.Font var37 = null;
//     org.jfree.chart.text.TextFragment var39 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var40 = var39.getPaint();
//     org.jfree.chart.text.TextMeasurer var43 = null;
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var37, var40, 10.0f, 0, var43);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.util.Size2D var46 = var44.calculateDimensions(var45);
//     var46.setWidth(1.0d);
//     org.jfree.data.xy.XYDataset var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var51, var52, var53, var54);
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     var55.setDomainAxis(0, var57, true);
//     org.jfree.data.xy.XYDataset var61 = null;
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var61, var62, var63, var64);
//     org.jfree.chart.axis.AxisLocation var67 = var65.getDomainAxisLocation(100);
//     var55.setRangeAxisLocation(0, var67);
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var55);
//     java.awt.Paint var70 = var69.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var71 = var69.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var72 = org.jfree.chart.util.RectangleAnchor.createRectangle(var46, 100.0d, 10.0d, var71);
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     var32.drawAnnotations(var35, var72, var73);
//     var4.drawOutline(var14, var72);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test204"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.LegendItemCollection var51 = var50.getLegendItems();
    org.jfree.chart.axis.CategoryAnchor var52 = var50.getDomainGridlinePosition();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var54 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var53};
    var50.setRenderers(var54);
    org.jfree.chart.axis.ValueAxis var56 = var50.getRangeAxis();
    org.jfree.data.xy.XYDataset var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.axis.ValueAxis var60 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var61 = null;
    org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot(var58, var59, var60, var61);
    java.awt.Paint var63 = var62.getRangeCrosshairPaint();
    java.awt.Stroke var64 = var62.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisLocation var65 = var62.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var50.setRangeAxisLocation((-10), var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test205"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
    java.awt.Shape var2 = var1.getUpArrow();
    boolean var3 = var1.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test206"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisLocation var7 = var4.getRangeAxisLocation();
    org.jfree.chart.JFreeChart var8 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var4);
    java.lang.Object var9 = var8.getTextAntiAlias();
    java.awt.Image var10 = null;
    var8.setBackgroundImage(var10);
    org.jfree.chart.plot.Plot var12 = var8.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test207"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    java.lang.Object var19 = var18.clone();
    java.lang.String var20 = var18.getURLText();
    java.lang.String var21 = var18.getToolTipText();
    java.lang.String var22 = var18.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + ""+ "'", var21.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "ChartEntity: tooltip = "+ "'", var22.equals("ChartEntity: tooltip = "));

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test208"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setTickMarkOutsideLength(10.0f);
    double var4 = var1.getCategoryMargin();
    var1.setUpperMargin((-1.0d));
    var1.setLabelURL("");
    java.awt.Font var10 = null;
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var13 = var12.getPaint();
    org.jfree.chart.text.TextMeasurer var16 = null;
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, var13, 10.0f, 0, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.util.Size2D var19 = var17.calculateDimensions(var18);
    double var20 = var19.getWidth();
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    int var26 = var25.getDatasetCount();
    int var27 = var25.getSeriesCount();
    boolean var28 = var19.equals((java.lang.Object)var25);
    org.jfree.chart.event.MarkerChangeEvent var29 = null;
    var25.markerChanged(var29);
    var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var25);
    boolean var32 = var1.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test209"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    boolean var6 = var5.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var7 = null;
    int var8 = var5.getDomainAxisIndex(var7);
    var5.mapDatasetToDomainAxis(0, 10);
    org.jfree.chart.axis.AxisSpace var12 = null;
    var5.setFixedRangeAxisSpace(var12, false);
    org.jfree.chart.util.RectangleInsets var15 = var5.getInsets();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleAnchor.CENTER", (org.jfree.chart.plot.Plot)var5);
    java.awt.Stroke var17 = var16.getBorderStroke();
    org.jfree.chart.plot.Plot var18 = var16.getPlot();
    java.awt.RenderingHints var19 = var16.getRenderingHints();
    org.jfree.chart.title.LegendTitle var20 = var16.getLegend();
    org.jfree.chart.util.RectangleInsets var21 = var16.getPadding();
    java.awt.Font var23 = null;
    org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var26 = var25.getPaint();
    org.jfree.chart.text.TextMeasurer var29 = null;
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, var26, 10.0f, 0, var29);
    java.awt.Graphics2D var31 = null;
    org.jfree.chart.util.Size2D var32 = var30.calculateDimensions(var31);
    var32.setWidth(1.0d);
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
    org.jfree.chart.axis.ValueAxis var43 = null;
    var41.setDomainAxis(0, var43, true);
    org.jfree.data.xy.XYDataset var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
    org.jfree.chart.axis.AxisLocation var53 = var51.getDomainAxisLocation(100);
    var41.setRangeAxisLocation(0, var53);
    org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
    java.awt.Paint var56 = var55.getBackgroundPaint();
    org.jfree.chart.util.RectangleAnchor var57 = var55.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var58 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 100.0d, 10.0d, var57);
    org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var58);
    org.jfree.chart.util.LengthAdjustmentType var60 = null;
    org.jfree.chart.util.LengthAdjustmentType var61 = null;
    java.awt.geom.Rectangle2D var62 = var21.createAdjustedRectangle(var58, var60, var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test210"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    java.lang.Object var19 = var18.clone();
    java.lang.String var20 = var18.getURLText();
    java.awt.Font var22 = null;
    org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var25 = var24.getPaint();
    org.jfree.chart.text.TextMeasurer var28 = null;
    org.jfree.chart.text.TextBlock var29 = org.jfree.chart.text.TextUtilities.createTextBlock("", var22, var25, 10.0f, 0, var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.text.TextBlockAnchor var33 = null;
    java.awt.Shape var37 = var29.calculateBounds(var30, 0.0f, 0.0f, var33, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var39 = new org.jfree.chart.entity.ChartEntity(var37, "");
    var18.setArea(var37);
    org.jfree.chart.entity.ChartEntity var42 = new org.jfree.chart.entity.ChartEntity(var37, "");
    org.jfree.data.general.PieDataset var43 = null;
    org.jfree.chart.entity.PieSectionEntity var49 = new org.jfree.chart.entity.PieSectionEntity(var37, var43, 100, 1, (java.lang.Comparable)10, "java.awt.Color[r=0,g=0,b=100]", "hi!");
    java.lang.Comparable var50 = var49.getSectionKey();
    var49.setSectionKey((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=100]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + 10+ "'", var50.equals(10));

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    var50.setAnchorValue(100.0d);
    org.jfree.chart.LegendItemCollection var53 = var50.getFixedLegendItems();
    var50.clearAnnotations();
    var50.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test212"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var5 = var4.getLeft();
    org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D(100.0d, (-1.0d));
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.ValueAxis var17 = null;
    var15.setDomainAxis(0, var17, true);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    org.jfree.chart.axis.AxisLocation var27 = var25.getDomainAxisLocation(100);
    var15.setRangeAxisLocation(0, var27);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var15);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var31 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, 0.0d, 10.0d, var30);
    java.awt.geom.Rectangle2D var32 = var4.createInsetRectangle(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test213"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    org.jfree.chart.axis.ValueAxis var24 = null;
    var4.setDomainAxis(100, var24, false);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
    java.awt.Shape var29 = var28.getUpArrow();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    boolean var31 = var28.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test214"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    int var6 = var4.getSeriesCount();
    org.jfree.chart.axis.ValueAxis var7 = null;
    var4.setRangeAxis(var7);
    boolean var9 = var4.isRangeGridlinesVisible();
    java.awt.Paint var10 = var4.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test215"); }


    java.awt.Font var1 = null;
    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var4 = var3.getPaint();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var4, 10.0f, 0, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    java.awt.Shape var16 = var8.calculateBounds(var9, 0.0f, 0.0f, var12, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
    java.lang.Object var19 = var18.clone();
    java.awt.Font var21 = null;
    org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var24 = var23.getPaint();
    org.jfree.chart.text.TextMeasurer var27 = null;
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, var24, 10.0f, 0, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.text.TextBlockAnchor var32 = null;
    java.awt.Shape var36 = var28.calculateBounds(var29, 0.0f, 0.0f, var32, 0.0f, (-1.0f), 100.0d);
    org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity(var36, "");
    var18.setArea(var36);
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var40 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var41 = null;
    java.lang.String var42 = var18.getImageMapAreaTag(var40, var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + ""+ "'", var42.equals(""));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test216"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    org.jfree.chart.util.Layer var6 = null;
    java.util.Collection var7 = var4.getRangeMarkers(var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var4.addChangeListener(var8);
    java.util.List var10 = var4.getAnnotations();
    java.util.Collection var11 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var10);
    java.util.Collection var12 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test217"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    var18.setHeight(111.0d);
    org.jfree.chart.block.BlockFrame var22 = var18.getFrame();
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 0.0d, 100.0d);
    org.jfree.chart.block.BlockContainer var28 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var27);
    var18.setWrapper(var28);
    java.util.List var30 = var28.getBlocks();
    var28.setID("");
    var28.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test218"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var2 = var1.getPaint();
//     float var3 = var1.getBaselineOffset();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(116.0d);
//     var8.setLabel("");
//     org.jfree.chart.text.TextAnchor var11 = var8.getLabelTextAnchor();
//     java.lang.String var12 = var11.toString();
//     var1.draw(var4, 0.0f, 0.0f, var11, 1.0f, 1.0f, 244.0d);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test219"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
    var1.setTickMarkInsideLength(0.0f);
    var1.setFixedDimension(244.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test220"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    var18.setHeight(111.0d);
    org.jfree.chart.block.BlockFrame var22 = var18.getFrame();
    org.jfree.chart.util.HorizontalAlignment var23 = null;
    org.jfree.chart.util.VerticalAlignment var24 = null;
    org.jfree.chart.block.ColumnArrangement var27 = new org.jfree.chart.block.ColumnArrangement(var23, var24, 0.0d, 100.0d);
    org.jfree.chart.block.BlockContainer var28 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var27);
    var18.setWrapper(var28);
    java.util.List var30 = var28.getBlocks();
    org.jfree.chart.block.Arrangement var31 = var28.getArrangement();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test221"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     var4.setDomainAxis(0, var6, true);
//     org.jfree.data.xy.XYDataset var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
//     org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
//     var4.setRangeAxisLocation(0, var16);
//     int var18 = var4.getRangeAxisCount();
//     org.jfree.chart.axis.ValueAxis var20 = var4.getRangeAxis((-1));
//     java.awt.Graphics2D var21 = null;
//     java.awt.Font var23 = null;
//     org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("hi!");
//     java.awt.Paint var26 = var25.getPaint();
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, var26, 10.0f, 0, var29);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.util.Size2D var32 = var30.calculateDimensions(var31);
//     var32.setWidth(1.0d);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var37, var38, var39, var40);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     var41.setDomainAxis(0, var43, true);
//     org.jfree.data.xy.XYDataset var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var47, var48, var49, var50);
//     org.jfree.chart.axis.AxisLocation var53 = var51.getDomainAxisLocation(100);
//     var41.setRangeAxisLocation(0, var53);
//     org.jfree.chart.title.LegendTitle var55 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
//     java.awt.Paint var56 = var55.getBackgroundPaint();
//     org.jfree.chart.util.RectangleAnchor var57 = var55.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var58 = org.jfree.chart.util.RectangleAnchor.createRectangle(var32, 100.0d, 10.0d, var57);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.chart.plot.CrosshairState var61 = null;
//     boolean var62 = var4.render(var21, var58, (-16777116), var60, var61);
//     
//     // Checks the contract:  equals-hashcode on var4 and var41
//     assertTrue("Contract failed: equals-hashcode on var4 and var41", var4.equals(var41) ? var4.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var51
//     assertTrue("Contract failed: equals-hashcode on var14 and var51", var14.equals(var51) ? var14.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var4
//     assertTrue("Contract failed: equals-hashcode on var41 and var4", var41.equals(var4) ? var41.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var14
//     assertTrue("Contract failed: equals-hashcode on var51 and var14", var51.equals(var14) ? var51.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test222"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    org.jfree.chart.event.MarkerChangeEvent var7 = null;
    var4.markerChanged(var7);
    var4.setDomainCrosshairValue(1.0d);
    var4.setDomainZeroBaselineVisible(true);
    org.jfree.chart.util.RectangleEdge var14 = var4.getDomainAxisEdge((-16646144));
    boolean var15 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test223"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    int var5 = var4.getDatasetCount();
    org.jfree.chart.axis.AxisSpace var6 = null;
    var4.setFixedRangeAxisSpace(var6);
    org.jfree.chart.axis.ValueAxis var8 = null;
    int var9 = var4.getRangeAxisIndex(var8);
    org.jfree.chart.util.RectangleInsets var10 = var4.getAxisOffset();
    org.jfree.chart.plot.DatasetRenderingOrder var11 = var4.getDatasetRenderingOrder();
    java.awt.Font var13 = null;
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var16 = var15.getPaint();
    org.jfree.chart.text.TextMeasurer var19 = null;
    org.jfree.chart.text.TextBlock var20 = org.jfree.chart.text.TextUtilities.createTextBlock("", var13, var16, 10.0f, 0, var19);
    org.jfree.data.xy.XYDataset var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var21, var22, var23, var24);
    java.awt.Paint var26 = var25.getRangeCrosshairPaint();
    java.awt.Stroke var27 = var25.getRangeCrosshairStroke();
    boolean var28 = var20.equals((java.lang.Object)var25);
    org.jfree.chart.event.RendererChangeEvent var29 = null;
    var25.rendererChanged(var29);
    org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var37 = var36.getPaint();
    org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var37);
    var25.setDomainGridlinePaint(var37);
    var4.setRangeGridlinePaint(var37);
    java.awt.Stroke var41 = var4.getRangeGridlineStroke();
    java.awt.Paint var42 = var4.getDomainZeroBaselinePaint();
    var4.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test224"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)0);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test225"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    var1.setTickMarkOutsideLength(10.0f);
    boolean var4 = var1.isTickMarksVisible();
    var1.addCategoryLabelToolTip((java.lang.Comparable)(short)1, "");
    double var8 = var1.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test226"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    org.jfree.chart.axis.ValueAxis var9 = null;
    var4.setDomainAxis(100, var9);
    var4.setDomainCrosshairValue(10.0d);
    var4.clearRangeAxes();
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var15, var16, var17, var18);
    int var20 = var19.getDatasetCount();
    int var21 = var19.getSeriesCount();
    org.jfree.chart.axis.ValueAxis var22 = null;
    var19.setRangeAxis(var22);
    org.jfree.data.xy.XYDataset var24 = null;
    int var25 = var19.indexOf(var24);
    java.awt.Paint var27 = var19.getQuadrantPaint(1);
    org.jfree.chart.event.PlotChangeEvent var28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var19);
    var4.notifyListeners(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test227"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    var4.setBackgroundAlpha(0.0f);
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    java.awt.Paint var14 = var13.getRangeCrosshairPaint();
    java.awt.Stroke var15 = var13.getRangeCrosshairStroke();
    var4.setDomainCrosshairStroke(var15);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var4.zoomDomainAxes(11.0d, 244.0d, var19, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test228"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    java.awt.Font var3 = var1.getLabelFont();
    var1.setVisible(false);
    org.jfree.chart.axis.CategoryLabelPositions var6 = var1.getCategoryLabelPositions();
    boolean var7 = var1.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test229"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var2 = var1.getAxisLineStroke();
    java.awt.Font var3 = var1.getLabelFont();
    org.jfree.chart.axis.CategoryLabelPositions var4 = var1.getCategoryLabelPositions();
    java.awt.Font var5 = var1.getTickLabelFont();
    var1.setLabelURL("java.awt.Color[r=0,g=0,b=100]");
    var1.setTickMarkOutsideLength(10.0f);
    boolean var10 = var1.isTickLabelsVisible();
    var1.setMaximumCategoryLabelLines(0);
    var1.setCategoryLabelPositionOffset(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test230"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    java.awt.Paint var15 = var4.getQuadrantPaint(0);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var16, var17, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var20.getDomainAxisLocation(100);
    int var23 = var20.getDatasetCount();
    java.awt.Graphics2D var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    org.jfree.chart.plot.CrosshairState var28 = null;
    boolean var29 = var20.render(var24, var25, 1, var27, var28);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    java.awt.Paint var35 = var34.getRangeCrosshairPaint();
    var20.setRangeGridlinePaint(var35);
    org.jfree.chart.axis.AxisSpace var37 = null;
    var20.setFixedDomainAxisSpace(var37);
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    java.awt.geom.Point2D var41 = null;
    var20.zoomDomainAxes((-1.0d), var40, var41, true);
    java.awt.Color var46 = java.awt.Color.getColor("", 100);
    var20.setDomainTickBandPaint((java.awt.Paint)var46);
    int var48 = var46.getTransparency();
    var4.setDomainGridlinePaint((java.awt.Paint)var46);
    java.awt.Color var50 = var46.darker();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test231"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = null;
    var4.setDomainAxis(0, var6, true);
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var10, var11, var12, var13);
    org.jfree.chart.axis.AxisLocation var16 = var14.getDomainAxisLocation(100);
    var4.setRangeAxisLocation(0, var16);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Paint var19 = var18.getBackgroundPaint();
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var22 = var21.clone();
    org.jfree.chart.util.RectangleInsets var23 = var21.getLabelInsets();
    var18.setPadding(var23);
    boolean var25 = var18.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test232"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    java.awt.Paint var5 = var4.getRangeCrosshairPaint();
    java.awt.Stroke var6 = var4.getRangeCrosshairStroke();
    int var7 = var4.getSeriesCount();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = null;
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot(var9, var10, var11, var12);
    org.jfree.chart.axis.ValueAxis var15 = null;
    var13.setDomainAxis(0, var15, true);
    org.jfree.data.xy.XYDataset var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var19, var20, var21, var22);
    org.jfree.chart.axis.AxisLocation var25 = var23.getDomainAxisLocation(100);
    var13.setRangeAxisLocation(0, var25);
    org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    double var28 = var27.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var31 = var30.getAxisLineStroke();
    java.awt.Font var32 = var30.getLabelFont();
    var30.setVisible(false);
    org.jfree.data.xy.XYDataset var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var35, var36, var37, var38);
    org.jfree.chart.axis.AxisLocation var41 = var39.getDomainAxisLocation(100);
    int var42 = var39.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
    var39.setRenderer(var43);
    org.jfree.chart.util.RectangleInsets var49 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var51 = var49.calculateRightOutset(10.0d);
    var39.setInsets(var49);
    var30.setLabelInsets(var49);
    boolean var54 = var27.equals((java.lang.Object)var30);
    float var55 = var30.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var56 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot(var8, var30, var56, var57);
    var58.setAnchorValue(100.0d);
    var58.setRangeCrosshairValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis3D var66 = new org.jfree.chart.axis.CategoryAxis3D("");
    var66.setTickMarkOutsideLength(10.0f);
    double var69 = var66.getCategoryMargin();
    var66.setUpperMargin((-1.0d));
    double var72 = var66.getCategoryMargin();
    var58.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var66);
    org.jfree.chart.axis.ValueAxis var75 = var58.getRangeAxis(100);
    org.jfree.chart.axis.AxisLocation var77 = var58.getRangeAxisLocation(100);
    var4.setRangeAxisLocation(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test233"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = null;
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var1, var2, var3, var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var5.setDomainAxis(0, var7, true);
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var11, var12, var13, var14);
    org.jfree.chart.axis.AxisLocation var17 = var15.getDomainAxisLocation(100);
    var5.setRangeAxisLocation(0, var17);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var5);
    double var20 = var19.getContentYOffset();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.awt.Stroke var23 = var22.getAxisLineStroke();
    java.awt.Font var24 = var22.getLabelFont();
    var22.setVisible(false);
    org.jfree.data.xy.XYDataset var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var27, var28, var29, var30);
    org.jfree.chart.axis.AxisLocation var33 = var31.getDomainAxisLocation(100);
    int var34 = var31.getDatasetCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
    var31.setRenderer(var35);
    org.jfree.chart.util.RectangleInsets var41 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 1.0d, 10.0d);
    double var43 = var41.calculateRightOutset(10.0d);
    var31.setInsets(var41);
    var22.setLabelInsets(var41);
    boolean var46 = var19.equals((java.lang.Object)var22);
    float var47 = var22.getTickMarkOutsideLength();
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var0, var22, var48, var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var50.setFixedDomainAxisSpace(var51);
    org.jfree.chart.renderer.category.CategoryItemRenderer var54 = var50.getRenderer((-10));
    var50.setAnchorValue(0.0d, false);
    org.jfree.data.category.CategoryDataset var59 = var50.getDataset(1);
    org.jfree.chart.plot.PlotRenderingInfo var62 = null;
    java.awt.geom.Point2D var63 = null;
    var50.zoomDomainAxes(244.0d, 116.0d, var62, var63);
    org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var68 = var67.clone();
    java.awt.Stroke var69 = var67.getAxisLineStroke();
    var67.setLabelURL("java.awt.Color[r=0,g=0,b=100]");
    var50.setDomainAxis(100, var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test234"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
    java.awt.Shape var2 = var1.getUpArrow();
    org.jfree.chart.axis.TickUnitSource var3 = null;
    var1.setStandardTickUnits(var3);
    java.awt.Shape var5 = var1.getDownArrow();
    var1.setAutoRangeStickyZero(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test235"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.text.TextFragment var10 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var11 = var10.getPaint();
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var11);
    var4.setRangeCrosshairPaint(var11);
    org.jfree.chart.LegendItemCollection var14 = null;
    var4.setFixedLegendItems(var14);
    var4.setOutlineVisible(false);
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var4.drawBackgroundImage(var18, var19);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var23 = var22.clone();
    java.awt.Stroke var24 = var22.getAxisLineStroke();
    var4.setDomainZeroBaselineStroke(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test236"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.AxisLocation var6 = var4.getDomainAxisLocation(100);
    int var7 = var4.getDatasetCount();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CrosshairState var12 = null;
    boolean var13 = var4.render(var8, var9, 1, var11, var12);
    org.jfree.data.xy.XYDataset var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var14, var15, var16, var17);
    java.awt.Paint var19 = var18.getRangeCrosshairPaint();
    var4.setRangeGridlinePaint(var19);
    org.jfree.chart.axis.AxisSpace var21 = null;
    var4.setFixedDomainAxisSpace(var21);
    org.jfree.chart.axis.ValueAxis var24 = null;
    var4.setDomainAxis(100, var24, false);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.CENTER");
    java.awt.Shape var29 = var28.getUpArrow();
    var4.setRangeAxis((org.jfree.chart.axis.ValueAxis)var28);
    java.awt.Paint var31 = var28.getTickLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test237"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    java.lang.Object var2 = var1.clone();
    java.awt.Font var3 = var1.getTickLabelFont();
    org.jfree.data.xy.XYDataset var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var4, var5, var6, var7);
    org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("hi!");
    java.awt.Paint var15 = var14.getPaint();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(0.0d, 10.0d, 0.0d, 100.0d, var15);
    var8.setRangeCrosshairPaint(var15);
    var1.setTickMarkPaint(var15);
    java.lang.Object var19 = var1.clone();
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var20, var21, var22, var23);
    org.jfree.chart.axis.ValueAxis var26 = null;
    var24.setDomainAxis(0, var26, true);
    org.jfree.data.xy.XYDataset var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var30, var31, var32, var33);
    org.jfree.chart.axis.AxisLocation var36 = var34.getDomainAxisLocation(100);
    var24.setRangeAxisLocation(0, var36);
    org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var24);
    org.jfree.chart.util.RectangleInsets var39 = var38.getMargin();
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.block.RectangleConstraint var43 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var44 = var43.getHeightRange();
    org.jfree.chart.block.RectangleConstraint var46 = var43.toFixedWidth(1.0d);
    org.jfree.chart.util.Size2D var47 = var38.arrange(var40, var46);
    org.jfree.data.xy.XYDataset var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
    org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var48, var49, var50, var51);
    org.jfree.chart.axis.AxisLocation var54 = var52.getDomainAxisLocation(100);
    var52.setBackgroundAlpha(0.0f);
    var52.setDomainCrosshairValue(100.0d, false);
    org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var61 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var60};
    var52.setRenderers(var61);
    var38.setSources((org.jfree.chart.LegendItemSource[])var61);
    org.jfree.chart.util.RectangleInsets var64 = var38.getLegendItemGraphicPadding();
    var1.setTickLabelInsets(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test238"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 1.0d);
    org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(10.0d, var7);
    org.jfree.chart.block.RectangleConstraint var9 = var2.toRangeHeight(var7);
    boolean var12 = var7.intersects(10.0d, 1.0d);
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var16 = org.jfree.data.Range.expandToInclude(var14, 1.0d);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(10.0d, var16);
    org.jfree.data.Range var18 = org.jfree.data.Range.combine(var7, var16);
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.chart.block.RectangleConstraint var23 = var21.toFixedHeight(1.0d);
    org.jfree.chart.block.RectangleConstraint var24 = var21.toUnconstrainedHeight();
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var28 = var27.getHeightRange();
    org.jfree.data.Range var30 = null;
    org.jfree.data.Range var32 = org.jfree.data.Range.expandToInclude(var30, 1.0d);
    org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(10.0d, var32);
    org.jfree.chart.block.RectangleConstraint var34 = var27.toRangeHeight(var32);
    boolean var37 = var32.intersects(10.0d, 1.0d);
    boolean var39 = var32.contains(111.0d);
    org.jfree.chart.block.RectangleConstraint var40 = var24.toRangeWidth(var32);
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(var32, 0.0d);
    double var43 = var32.getCentralValue();
    org.jfree.data.Range var44 = org.jfree.data.Range.combine(var7, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

}
