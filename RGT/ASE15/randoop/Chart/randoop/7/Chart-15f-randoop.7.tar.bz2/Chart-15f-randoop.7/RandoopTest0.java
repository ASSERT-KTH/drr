
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, (-1.0f), 1.0f, var4, 1.0d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, (-1.0f), var4, (-1.0d), 100.0f, 0.0f);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("", var1, var2, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("ThreadContext", var1);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)10L);
// 
//   }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)'a', (java.lang.Object)"");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.0d, (java.lang.Object)(byte)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", var1);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDownArrow(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var5 = var2.getPlot();
//     java.lang.String var6 = var2.getLabel();
//     java.awt.Paint var7 = var2.getLabelPaint();
//     org.jfree.chart.text.TextMeasurer var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("ThreadContext", var1, var7, 10.0f, var9);
// 
//   }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "", var3);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 1);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0d, (-1.0f), 10.0f);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeWidth(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    boolean var2 = var0.isVisible();
    var0.setFixedDimension(1.0d);
    org.jfree.data.Range var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var5, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
//     java.lang.Comparable var1 = null;
//     boolean var2 = var0.containsKey(var1);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)true);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.chart.util.UnitType var1 = var0.getUnitType();
    double var3 = var0.extendWidth(0.0d);
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var7 = var0.createInsetRectangle(var4, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0d);

  }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ThreadContext", var1);
// 
//   }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.awt.Color var1 = java.awt.Color.getColor("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    java.awt.Font var3 = var2.getNoDataMessageFont();
    var2.setBackgroundAlpha((-1.0f));
    java.awt.Font var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setNoDataMessageFont(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var4.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var7 = var4.getPlot();
//     java.lang.String var8 = var4.getLabel();
//     java.awt.Paint var9 = var4.getLabelPaint();
//     var0.setTickLabelPaint((java.lang.Comparable)(byte)0, var9);
//     java.awt.Paint[] var11 = new java.awt.Paint[] { var9};
//     java.awt.Paint[] var12 = null;
//     java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
//     java.awt.Stroke var22 = null;
//     java.awt.Stroke[] var23 = new java.awt.Stroke[] { var22};
//     java.awt.Paint[] var24 = null;
//     java.awt.Paint[] var25 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var26 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     java.awt.Shape var31 = null;
//     java.awt.Shape[] var32 = new java.awt.Shape[] { var31};
//     org.jfree.chart.plot.DefaultDrawingSupplier var33 = new org.jfree.chart.plot.DefaultDrawingSupplier(var24, var25, var26, var28, var30, var32);
//     java.awt.Paint[] var34 = null;
//     java.awt.Paint[] var35 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var36 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Shape var41 = null;
//     java.awt.Shape[] var42 = new java.awt.Shape[] { var41};
//     org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var35, var36, var38, var40, var42);
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var11, var12, var23, var30, var42);
//     
//     // Checks the contract:  equals-hashcode on var21 and var33
//     assertTrue("Contract failed: equals-hashcode on var21 and var33", var21.equals(var33) ? var21.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var43
//     assertTrue("Contract failed: equals-hashcode on var21 and var43", var21.equals(var43) ? var21.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var21
//     assertTrue("Contract failed: equals-hashcode on var33 and var21", var33.equals(var21) ? var33.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var43
//     assertTrue("Contract failed: equals-hashcode on var33 and var43", var33.equals(var43) ? var33.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var21
//     assertTrue("Contract failed: equals-hashcode on var43 and var21", var43.equals(var21) ? var43.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var33
//     assertTrue("Contract failed: equals-hashcode on var43 and var33", var43.equals(var33) ? var43.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 100);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendLabelGenerator(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    java.awt.Shape var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLegendItemShape(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLineAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 0);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.axis.AxisState var8 = var0.draw(var2, 10.0d, var4, var5, var6, var7);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     org.jfree.chart.axis.Timeline var3 = null;
//     var1.setTimeline(var3);
//     var1.setAutoTickUnitSelection(false, false);
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     double var9 = var8.getLowerMargin();
//     boolean var10 = var8.isVisible();
//     var8.centerRange(100.0d);
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var8, var13);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var2 = var0.arrange(var1);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBackgroundImageAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    boolean var2 = var0.isTickMarksVisible();
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(var3, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, true);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    java.awt.Paint var1 = null;
    org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    var2.add(var3, (java.lang.Object)var4);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var4.getLegendLabelToolTipGenerator();
    org.jfree.chart.util.RectangleInsets var7 = var4.getLabelPadding();
    java.awt.Stroke var8 = var4.getLabelOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(0.05d, var1, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     org.jfree.chart.axis.Timeline var2 = null;
//     var0.setTimeline(var2);
//     var0.setVisible(false);
//     boolean var7 = var0.isHiddenValue(0L);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     boolean var2 = var0.isTickMarksVisible();
//     org.jfree.chart.axis.DateTickUnit var3 = null;
//     java.util.Date var4 = var0.calculateLowestVisibleTickValue(var3);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     var2.setForegroundAlpha(100.0f);
//     org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     var6.add(var7, (java.lang.Object)var8);
//     org.jfree.chart.labels.PieSectionLabelGenerator var10 = var8.getLegendLabelGenerator();
//     var2.setLabelGenerator(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.awt.Color var1 = java.awt.Color.getColor("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     double var3 = var2.getLowerMargin();
//     java.util.Date var4 = var2.getMinimumDate();
//     var0.setAggregatedItemsKey((java.lang.Comparable)var4);
//     java.awt.Image var6 = null;
//     var0.setBackgroundImage(var6);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     org.jfree.chart.plot.PlotState var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var0.draw(var8, var9, var10, var11, var12);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(var0, false);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    java.util.Date var2 = var0.getMinimumDate();
    double var3 = var0.getFixedDimension();
    org.jfree.chart.axis.DateTickMarkPosition var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickMarkPosition(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 4);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var3 = var0.getPlot();
    var0.setMaximumCategoryLabelLines(10);
    org.jfree.data.general.WaferMapDataset var7 = null;
    org.jfree.chart.renderer.WaferMapRenderer var8 = null;
    org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var7, var8);
    java.awt.Font var10 = var9.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    var11.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var14 = var11.getPlot();
    java.lang.String var15 = var11.getLabel();
    java.awt.Paint var16 = var11.getLabelPaint();
    org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var10, var16);
    var0.setTickLabelFont(var10);
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var0.getCategoryStart(100, 100, var21, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.lang.Object var2 = var1.clone();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeparatorPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("ThreadContext", var1, var2, var3);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 10.0d);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     int var2 = var1.getCategoryLabelPositionOffset();
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var1.getCategoryJava2DCoordinate(var3, 0, 4, var6, var7);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var1 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var1, var2);
//     java.awt.Font var4 = var3.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var8 = var5.getPlot();
//     java.lang.String var9 = var5.getLabel();
//     java.awt.Paint var10 = var5.getLabelPaint();
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var4, var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.util.Size2D var13 = var11.calculateDimensions(var12);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    var1.distributeLabels(0.05d, 0.0d);
    int var5 = var1.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     boolean var2 = var0.isVisible();
//     org.jfree.chart.axis.Timeline var3 = var0.getTimeline();
//     org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
//     var4.setToolTipText("");
//     boolean var7 = var0.equals((java.lang.Object)var4);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var0.lengthToJava2D((-1.0d), var9, var10);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.axis.AxisState var18 = var0.draw(var12, 0.0d, var14, var15, var16, var17);
// 
//   }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Font var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var3.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    var3.setTickLabelPaint((java.lang.Comparable)(byte)0, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addLine("ThreadContext", var2, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("", var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var15 = null;
//     org.jfree.chart.plot.WaferMapPlot var16 = new org.jfree.chart.plot.WaferMapPlot(var14, var15);
//     java.awt.Font var17 = var16.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var21 = var18.getPlot();
//     java.lang.String var22 = var18.getLabel();
//     java.awt.Paint var23 = var18.getLabelPaint();
//     org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("", var17, var23);
//     org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var5, var23, 1.0f);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setPadding(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    double var1 = var0.getContentYOffset();
    org.jfree.chart.util.HorizontalAlignment var2 = var0.getTextAlignment();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
    org.jfree.chart.block.RectangleConstraint var7 = var6.toUnconstrainedHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var0.arrange(var3, var6);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)10.0f, 10.0d, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var3 = var0.getPlot();
//     java.lang.String var4 = var0.getLabel();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var7 = null;
//     org.jfree.chart.plot.WaferMapPlot var8 = new org.jfree.chart.plot.WaferMapPlot(var6, var7);
//     java.awt.Font var9 = var8.getNoDataMessageFont();
//     var8.setBackgroundAlpha((-1.0f));
//     java.awt.Stroke var12 = null;
//     var8.setOutlineStroke(var12);
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     org.jfree.chart.axis.AxisSpace var16 = null;
//     org.jfree.chart.axis.AxisSpace var17 = var0.reserveSpace(var5, (org.jfree.chart.plot.Plot)var8, var14, var15, var16);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(1, 0, 0);
    java.awt.image.ColorModel var4 = null;
    java.awt.Rectangle var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    java.awt.geom.AffineTransform var7 = null;
    java.awt.RenderingHints var8 = null;
    java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
    float[] var12 = new float[] { 100.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var13 = var3.getRGBColorComponents(var12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var1 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var1, var2);
//     java.awt.Font var4 = var3.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var8 = var5.getPlot();
//     java.lang.String var9 = var5.getLabel();
//     java.awt.Paint var10 = var5.getLabelPaint();
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var4, var10);
//     java.awt.Font var12 = var11.getFont();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.text.TextAnchor var14 = null;
//     float var15 = var11.calculateBaselineOffset(var13, var14);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    float[] var4 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(10, 100, 0, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setToolTipText("");
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    java.lang.Object var6 = var0.draw(var3, var4, (java.lang.Object)0.0d);
    org.jfree.chart.util.RectangleEdge var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPosition(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 100.0f, 100.0f, var4, 0.05d, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     org.jfree.chart.axis.Timeline var2 = null;
//     var0.setTimeline(var2);
//     java.awt.Shape var4 = var0.getLeftArrow();
//     boolean var6 = var0.isHiddenValue(1L);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setToolTipText("");
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    java.lang.Object var6 = var0.draw(var3, var4, (java.lang.Object)0.0d);
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTextAlignment(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, 0.05d, 10.0f, 0.0f);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, 10.0f, 0.0f, 0.0d, 100.0f, 10.0f);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.RectangleAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, (-1.0f), (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-253));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("ThreadContext");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setToolTipText("");
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    java.lang.Object var6 = var0.draw(var3, var4, (java.lang.Object)0.0d);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.zoomDomainAxes(10.0d, 0.0d, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(0, var4, true);
    org.jfree.chart.plot.CategoryMarker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelGenerator();
//     var2.setMinimumArcAngleToDraw(0.05d);
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     var7.add(var8, (java.lang.Object)var9);
//     org.jfree.chart.labels.PieSectionLabelGenerator var11 = var9.getLegendLabelToolTipGenerator();
//     org.jfree.chart.util.RectangleInsets var12 = var9.getLabelPadding();
//     java.awt.Stroke var13 = var9.getLabelOutlineStroke();
//     var2.setLabelLinkStroke(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    java.util.TimeZone var2 = var0.getTimeZone();
    java.util.Date var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setMinimumDate(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     boolean var3 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var2);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("ThreadContext", var1, 10.0f, 1.0f, 0.0d, 10.0f, 0.0f);
// 
//   }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.data.xy.XYDataset var14 = null;
    var11.setDataset(10, var14);
    org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRenderer((-1), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    java.lang.Comparable var5 = null;
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSectionOutlinePaint(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.chart.plot.SeriesRenderingOrder var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSeriesRenderingOrder(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var3 = var0.getPlot();
//     boolean var4 = var0.isAxisLineVisible();
//     java.lang.Comparable var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var0.getCategorySeriesMiddle((java.lang.Comparable)(short)(-1), var6, var7, 101.0d, var9, var10);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.plot.DatasetRenderingOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    var1.distributeLabels(0.05d, 0.0d);
    var1.clear();
    org.jfree.chart.plot.PieLabelRecord var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    boolean var2 = var0.isVisible();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    double var4 = var3.getLowerMargin();
    org.jfree.chart.axis.Timeline var5 = null;
    var3.setTimeline(var5);
    java.awt.Shape var7 = var3.getLeftArrow();
    var0.setLeftArrow(var7);
    org.jfree.chart.axis.DateTickMarkPosition var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickMarkPosition(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, var1);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeHeight(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     org.jfree.chart.axis.CategoryAnchor var2 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var1.getCategoryJava2DCoordinate(var2, 4, 0, var5, var6);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     double var11 = var10.getLowerMargin();
//     java.util.Date var12 = var10.getMinimumDate();
//     var8.setAggregatedItemsKey((java.lang.Comparable)var12);
//     java.lang.Object var14 = var5.draw(var6, var7, (java.lang.Object)var8);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var3 = var0.getPlot();
//     boolean var4 = var0.isAxisLineVisible();
//     java.lang.String var5 = var0.getLabelToolTip();
//     java.lang.Comparable var6 = null;
//     org.jfree.data.category.CategoryDataset var8 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     double var12 = var11.getLowerMargin();
//     boolean var13 = var11.isVisible();
//     org.jfree.chart.axis.Timeline var14 = var11.getTimeline();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
//     var15.setToolTipText("");
//     boolean var18 = var11.equals((java.lang.Object)var15);
//     org.jfree.chart.util.RectangleEdge var19 = var15.getPosition();
//     double var20 = var0.getCategorySeriesMiddle(var6, (java.lang.Comparable)(byte)0, var8, 101.0d, var10, var19);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    var0.setWeight(1);
    org.jfree.chart.axis.AxisLocation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var8, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
//     org.jfree.data.general.WaferMapDataset var16 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     var18.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.event.PlotChangeEvent var25 = null;
//     var23.plotChanged(var25);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
//     org.jfree.chart.util.RectangleInsets var5 = var2.getLabelPadding();
//     boolean var6 = var2.isCircular();
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     var7.add(var8, (java.lang.Object)var9);
//     org.jfree.chart.labels.PieSectionLabelGenerator var11 = var9.getLegendLabelGenerator();
//     var2.setLegendLabelGenerator(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var9
//     assertTrue("Contract failed: equals-hashcode on var2 and var9", var2.equals(var9) ? var2.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var2
//     assertTrue("Contract failed: equals-hashcode on var9 and var2", var9.equals(var2) ? var9.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    org.jfree.chart.title.Title var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.addSubtitle(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomRangeAxes(0.0d, var4, var5);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     double var9 = var8.getLowerMargin();
//     boolean var10 = var8.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var12.setAutoRangeIncludesZero(true);
//     var12.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var12, var17);
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var21 = var20.getLabel();
//     var18.addDomainMarker((org.jfree.chart.plot.Marker)var20);
//     boolean var23 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var20);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     java.awt.Font var13 = var12.getFont();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("", var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.text.TextAnchor var18 = null;
//     var14.draw(var15, 1.0f, 100.0f, var18, 1.0f, (-1.0f), 1.0d);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    float[] var5 = new float[] { 0.0f, 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(100, 0, 4, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var2 = var1.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
//     boolean var4 = var1.isAutoTickUnitSelection();
//     var1.setAutoRangeIncludesZero(true);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     double var11 = var10.getLowerMargin();
//     boolean var12 = var10.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var14.setAutoRangeIncludesZero(true);
//     var14.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var19);
//     var20.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var22 = var20.getDomainAxisEdge();
//     double var23 = var1.java2DToValue(10.0d, var8, var22);
// 
//   }

//  public void test144() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
//
//
//    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue(var0 == false);
//
//  }
//
  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.Timeline var2 = null;
    var0.setTimeline(var2);
    var0.setVisible(false);
    org.jfree.chart.axis.DateTickMarkPosition var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickMarkPosition(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     int var2 = var1.getCategoryLabelPositionOffset();
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     double var7 = var6.getLowerMargin();
//     boolean var8 = var6.isVisible();
//     org.jfree.chart.axis.Timeline var9 = var6.getTimeline();
//     org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
//     var10.setToolTipText("");
//     boolean var13 = var6.equals((java.lang.Object)var10);
//     org.jfree.chart.util.RectangleEdge var14 = var10.getPosition();
//     double var15 = var1.getCategoryStart((-253), 0, var5, var14);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(0, var4, true);
    java.awt.Paint var7 = var0.getRangeCrosshairPaint();
    boolean var8 = var0.isDomainZoomable();
    org.jfree.chart.axis.AxisLocation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-1), var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("ThreadContext", var1, var2);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var18 = var17.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
//     boolean var20 = var17.isAutoTickUnitSelection();
//     var17.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var11.setRangeAxes(var23);
//     java.lang.String var25 = var11.getPlotType();
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     double var28 = var27.getLowerMargin();
//     boolean var29 = var27.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var31.setAutoRangeIncludesZero(true);
//     var31.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var31, var36);
//     boolean var38 = var37.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var39.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var42 = var39.getPlot();
//     java.lang.String var43 = var39.getLabel();
//     java.awt.Paint var44 = var39.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var45 = new org.jfree.chart.block.BlockBorder(var44);
//     var37.setDomainTickBandPaint(var44);
//     var11.setRangeZeroBaselinePaint(var44);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.util.Layer var50 = null;
//     boolean var51 = var11.removeRangeMarker((org.jfree.chart.plot.Marker)var49, var50);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     double var4 = var3.getLowerMargin();
//     org.jfree.chart.axis.Timeline var5 = null;
//     var3.setTimeline(var5);
//     var3.setVisible(false);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var3, var9);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
//     double var14 = var13.getTop();
//     org.jfree.data.general.WaferMapDataset var16 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     var20.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var23 = var20.getPlot();
//     java.lang.String var24 = var20.getLabel();
//     java.awt.Paint var25 = var20.getLabelPaint();
//     org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("", var19, var25);
//     org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(var13, var25);
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n", var5, var25, 1.0f, var29);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     var11.configureDomainAxes();
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var19 = var18.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var18);
//     
//     // Checks the contract:  equals-hashcode on var13 and var18
//     assertTrue("Contract failed: equals-hashcode on var13 and var18", var13.equals(var18) ? var13.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var13
//     assertTrue("Contract failed: equals-hashcode on var18 and var13", var18.equals(var13) ? var18.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getText();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    java.awt.Font var8 = var7.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var9.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    java.lang.String var13 = var9.getLabel();
    java.awt.Paint var14 = var9.getLabelPaint();
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
    java.awt.Font var16 = var15.getFont();
    org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
    org.jfree.data.general.WaferMapDataset var18 = null;
    org.jfree.chart.renderer.WaferMapRenderer var19 = null;
    org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
    java.awt.Font var21 = var20.getNoDataMessageFont();
    var20.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
    java.lang.Object var26 = var25.clone();
    var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
    java.awt.Stroke var28 = var25.getBorderStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var29 = var25.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setToolTipText("");
    java.lang.String var3 = var0.getID();
    org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var5 = var4.getLineAlignment();
    var0.setTextAlignment(var5);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, 0.0f, 0.0f, var4);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(4, var2, false);
//     java.awt.Paint var5 = var0.getDomainGridlinePaint();
//     var0.setWeight(1);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var0.handleClick(4, 1, var10);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     double var1 = var0.getTop();
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var0, var12);
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var19 = null;
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
//     java.awt.Font var21 = var20.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var22.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var25 = var22.getPlot();
//     java.lang.String var26 = var22.getLabel();
//     java.awt.Paint var27 = var22.getLabelPaint();
//     org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("", var21, var27);
//     java.awt.Font var29 = var28.getFont();
//     org.jfree.chart.text.TextLine var30 = new org.jfree.chart.text.TextLine("", var29);
//     org.jfree.data.general.WaferMapDataset var31 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var32 = null;
//     org.jfree.chart.plot.WaferMapPlot var33 = new org.jfree.chart.plot.WaferMapPlot(var31, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     var33.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var38 = new org.jfree.chart.JFreeChart("ThreadContext", var29, (org.jfree.chart.plot.Plot)var33, false);
//     boolean var39 = var14.equals((java.lang.Object)"ThreadContext");
//     
//     // Checks the contract:  equals-hashcode on var5 and var20
//     assertTrue("Contract failed: equals-hashcode on var5 and var20", var5.equals(var20) ? var5.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var5
//     assertTrue("Contract failed: equals-hashcode on var20 and var5", var20.equals(var5) ? var20.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    boolean var3 = var0.isRangeCrosshairVisible();
    org.jfree.chart.axis.CategoryAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePosition(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getText();
    var0.setToolTipText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getText();
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var19 = null;
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
//     java.awt.Font var21 = var20.getNoDataMessageFont();
//     var20.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
//     java.lang.Object var26 = var25.clone();
//     var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
//     java.awt.Stroke var28 = var25.getBorderStroke();
//     java.awt.RenderingHints var29 = null;
//     var25.setRenderingHints(var29);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
//     java.awt.Paint var2 = var0.getPaint((java.lang.Comparable)2.0d);
//     java.awt.Paint var4 = var0.getPaint((java.lang.Comparable)1);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     var5.setTickLabelPaint((java.lang.Comparable)(byte)0, var14);
//     var5.setFixedDimension(10.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var18 = var5.getCategoryLabelPositions();
//     boolean var19 = var0.equals((java.lang.Object)var5);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var22 = var21.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var23 = var21.getTickUnit();
//     boolean var24 = var21.isAutoTickUnitSelection();
//     var21.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.NumberTickUnit var27 = var21.getTickUnit();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
//     double var34 = var33.getLowerMargin();
//     boolean var35 = var33.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var37.setAutoRangeIncludesZero(true);
//     var37.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var32, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var37, var42);
//     var43.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var45 = var43.getDomainAxisEdge();
//     double var46 = var5.getCategorySeriesMiddle((java.lang.Comparable)var27, (java.lang.Comparable)true, var29, 100.0d, var31, var45);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var13 = var11.getDomainAxisEdge();
    java.lang.String var14 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleEdge.BOTTOM"+ "'", var14.equals("RectangleEdge.BOTTOM"));

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "ThreadContext", var3, "", "", "");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.lang.String var10 = var7.toString();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    var11.add(var12, (java.lang.Object)var13);
    boolean var15 = var7.equals((java.lang.Object)var13);
    var7.setCopyright("RectangleEdge.BOTTOM");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var10.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, 0.0f, 10.0f, var4, 0.0d, var6);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-253), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     var1.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAnchor var4 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var1.getCategoryJava2DCoordinate(var4, 100, 1, var7, var8);
//     var1.clearCategoryLabelToolTips();
//     java.awt.Font var12 = var1.getTickLabelFont((java.lang.Comparable)15);
//     org.jfree.chart.text.TextBlock var13 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var14 = var13.getLineAlignment();
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
//     var15.add(var16, (java.lang.Object)var17);
//     org.jfree.chart.labels.PieSectionLabelGenerator var19 = var17.getLegendLabelToolTipGenerator();
//     boolean var20 = var14.equals((java.lang.Object)var17);
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var24 = var21.getPlot();
//     java.lang.String var25 = var21.getLabel();
//     java.awt.Paint var26 = var21.getLabelPaint();
//     var17.setLabelPaint(var26);
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var12, var26, 100.0f, var29);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var4 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var5 = null;
//     org.jfree.chart.plot.WaferMapPlot var6 = new org.jfree.chart.plot.WaferMapPlot(var4, var5);
//     java.awt.Font var7 = var6.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var11 = var8.getPlot();
//     java.lang.String var12 = var8.getLabel();
//     java.awt.Paint var13 = var8.getLabelPaint();
//     org.jfree.chart.text.TextFragment var14 = new org.jfree.chart.text.TextFragment("", var7, var13);
//     java.awt.Font var15 = var14.getFont();
//     org.jfree.chart.text.TextLine var16 = new org.jfree.chart.text.TextLine("", var15);
//     var1.setLabelFont(var15);
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     double var20 = var19.getLowerMargin();
//     boolean var21 = var19.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var23.setAutoRangeIncludesZero(true);
//     var23.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     boolean var30 = var29.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
//     var31.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var34 = var31.getPlot();
//     java.lang.String var35 = var31.getLabel();
//     java.awt.Paint var36 = var31.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(var36);
//     var29.setDomainTickBandPaint(var36);
//     var1.setPaint(var36);
//     java.lang.Class var40 = null;
//     java.util.EventListener[] var41 = var1.getListeners(var40);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var1.setAutoRangeIncludesZero(true);
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkStroke(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var18 = var17.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
//     boolean var20 = var17.isAutoTickUnitSelection();
//     var17.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var11.setRangeAxes(var23);
//     java.lang.String var25 = var11.getPlotType();
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     double var28 = var27.getLowerMargin();
//     boolean var29 = var27.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var31.setAutoRangeIncludesZero(true);
//     var31.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var31, var36);
//     boolean var38 = var37.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var39.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var42 = var39.getPlot();
//     java.lang.String var43 = var39.getLabel();
//     java.awt.Paint var44 = var39.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var45 = new org.jfree.chart.block.BlockBorder(var44);
//     var37.setDomainTickBandPaint(var44);
//     var11.setRangeZeroBaselinePaint(var44);
//     org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var51 = var50.getLabel();
//     java.awt.Stroke var52 = var50.getStroke();
//     org.jfree.chart.util.Layer var53 = null;
//     var11.addRangeMarker(100, (org.jfree.chart.plot.Marker)var50, var53);
//     
//     // Checks the contract:  equals-hashcode on var13 and var50
//     assertTrue("Contract failed: equals-hashcode on var13 and var50", var13.equals(var50) ? var13.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var13
//     assertTrue("Contract failed: equals-hashcode on var50 and var13", var50.equals(var13) ? var50.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var3 = var0.getPlot();
    java.lang.String var4 = var0.getLabel();
    java.lang.Comparable var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeCategoryLabelToolTip(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("XY Plot", var1);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    boolean var12 = var11.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    var13.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var16 = var13.getPlot();
    java.lang.String var17 = var13.getLabel();
    java.awt.Paint var18 = var13.getLabelPaint();
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var18);
    var11.setDomainTickBandPaint(var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
    double var23 = var22.getLowerMargin();
    boolean var24 = var22.isVisible();
    org.jfree.chart.axis.Timeline var25 = var22.getTimeline();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle();
    var26.setToolTipText("");
    boolean var29 = var22.equals((java.lang.Object)var26);
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    double var33 = var22.lengthToJava2D((-1.0d), var31, var32);
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var22.valueToJava2D(0.0d, var35, var36);
    var22.resizeRange((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeAxis((-253), (org.jfree.chart.axis.ValueAxis)var22, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var1 = var0.getTop();
    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var0, var12);
    double var16 = var0.extendWidth(0.05d);
    double var18 = var0.extendHeight(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4.0d);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var18 = var17.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
//     boolean var20 = var17.isAutoTickUnitSelection();
//     var17.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var11.setRangeAxes(var23);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.text.TextBlock var27 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.util.Size2D var29 = var27.calculateDimensions(var28);
//     java.util.List var30 = var27.getLines();
//     var11.drawDomainTickBands(var25, var26, var30);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var11.zoomDomainAxes(0.025d, var33, var34, true);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ThreadContext", "XY Plot", var3);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    java.util.TimeZone var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(0.0d);
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    var3.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    var3.setTickLabelPaint((java.lang.Comparable)(byte)0, var12);
    var0.setLabelPaint(var12);
    java.lang.String var15 = var0.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     java.awt.Font var3 = var2.getNoDataMessageFont();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     org.jfree.chart.plot.PlotState var7 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     var2.draw(var4, var5, var6, var7, var8);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    double var14 = var13.getLowerMargin();
    boolean var15 = var13.isTickMarksVisible();
    var11.setRangeAxis((org.jfree.chart.axis.ValueAxis)var13);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRenderer((-1), var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getText();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    java.awt.Font var8 = var7.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var9.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    java.lang.String var13 = var9.getLabel();
    java.awt.Paint var14 = var9.getLabelPaint();
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
    java.awt.Font var16 = var15.getFont();
    org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
    org.jfree.data.general.WaferMapDataset var18 = null;
    org.jfree.chart.renderer.WaferMapRenderer var19 = null;
    org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
    java.awt.Font var21 = var20.getNoDataMessageFont();
    var20.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
    java.lang.Object var26 = var25.clone();
    var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
    java.awt.Stroke var28 = var25.getBorderStroke();
    var25.removeLegend();
    org.jfree.chart.ChartRenderingInfo var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var33 = var25.createBufferedImage((-1), 4, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.chart.axis.AxisSpace var13 = null;
    var11.setFixedDomainAxisSpace(var13);
    org.jfree.chart.axis.AxisLocation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeAxisLocation(var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var18 = var17.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
//     boolean var20 = var17.isAutoTickUnitSelection();
//     var17.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var11.setRangeAxes(var23);
//     java.lang.String var25 = var11.getPlotType();
//     org.jfree.data.xy.XYDataset var26 = null;
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     double var28 = var27.getLowerMargin();
//     boolean var29 = var27.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var31.setAutoRangeIncludesZero(true);
//     var31.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var31, var36);
//     boolean var38 = var37.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var39.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var42 = var39.getPlot();
//     java.lang.String var43 = var39.getLabel();
//     java.awt.Paint var44 = var39.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var45 = new org.jfree.chart.block.BlockBorder(var44);
//     var37.setDomainTickBandPaint(var44);
//     var11.setRangeZeroBaselinePaint(var44);
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.FlowArrangement var52 = new org.jfree.chart.block.FlowArrangement(var48, var49, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var53 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var52);
//     var52.clear();
//     org.jfree.chart.util.HorizontalAlignment var55 = null;
//     org.jfree.chart.util.VerticalAlignment var56 = null;
//     org.jfree.chart.block.FlowArrangement var59 = new org.jfree.chart.block.FlowArrangement(var55, var56, 0.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle();
//     double var61 = var60.getContentYOffset();
//     var59.add((org.jfree.chart.block.Block)var60, (java.lang.Object)(-1));
//     org.jfree.chart.title.LegendTitle var64 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var11, (org.jfree.chart.block.Arrangement)var52, (org.jfree.chart.block.Arrangement)var59);
//     
//     // Checks the contract:  equals-hashcode on var52 and var59
//     assertTrue("Contract failed: equals-hashcode on var52 and var59", var52.equals(var59) ? var52.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var52
//     assertTrue("Contract failed: equals-hashcode on var59 and var52", var59.equals(var52) ? var59.hashCode() == var52.hashCode() : true);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
    org.jfree.chart.util.Size2D var3 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
    double var5 = var2.getHeight();
    org.jfree.chart.block.RectangleConstraint var7 = var2.toFixedWidth((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(-1.0d));
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

//  public void test187() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     java.util.TimeZone var2 = var0.getTimeZone();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     double var7 = var6.getLowerMargin();
//     boolean var8 = var6.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var10.setAutoRangeIncludesZero(true);
//     var10.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var10, var15);
//     var16.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var18 = var16.getDomainAxisEdge();
//     double var19 = var0.java2DToValue(10.0d, var4, var18);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getText();
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var19 = null;
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
//     java.awt.Font var21 = var20.getNoDataMessageFont();
//     var20.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
//     java.lang.Object var26 = var25.clone();
//     var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
//     org.jfree.chart.event.PlotChangeEvent var28 = null;
//     var25.plotChanged(var28);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.ChartColor var4 = new org.jfree.chart.ChartColor(1, 0, 0);
    java.awt.image.ColorModel var5 = null;
    java.awt.Rectangle var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    java.awt.geom.AffineTransform var8 = null;
    java.awt.RenderingHints var9 = null;
    java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
    java.awt.Color var11 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var4);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    double var13 = var12.getLowerMargin();
    java.util.Date var14 = var12.getMinimumDate();
    double var15 = var12.getFixedDimension();
    org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var17 = var16.getLineAlignment();
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    java.awt.Shape var25 = var16.calculateBounds(var18, (-1.0f), 100.0f, var21, (-1.0f), 1.0f, 0.0d);
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity(var25);
    var12.setRightArrow(var25);
    boolean var28 = var11.equals((java.lang.Object)var25);
    org.jfree.data.general.PieDataset var29 = null;
    org.jfree.chart.entity.PieSectionEntity var35 = new org.jfree.chart.entity.PieSectionEntity(var25, var29, (-1), (-1), (java.lang.Comparable)1.0f, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!");
    org.jfree.chart.entity.ChartEntity var37 = new org.jfree.chart.entity.ChartEntity(var25, "");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    var0.setWeight(1);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var9.setAutoRangeIncludesZero(true);
    var9.setAutoRangeStickyZero(true);
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var0.setRangeAxes(var14);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var0.getDomainMarkers(var16);
    org.jfree.chart.util.SortOrder var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(4.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var13 = var11.getDomainAxisEdge();
    var11.setRangeCrosshairValue(101.0d, true);
    org.jfree.chart.annotations.XYAnnotation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addAnnotation(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(4, var2, false);
//     java.awt.Paint var5 = var0.getDomainGridlinePaint();
//     var0.setWeight(1);
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var9.setAutoRangeIncludesZero(true);
//     var9.setAutoRangeStickyZero(true);
//     org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var9};
//     var0.setRangeAxes(var14);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     var0.handleClick(100, 1, var18);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    boolean var2 = var0.isTickMarksVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(4.0d, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     var11.configureRangeAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     var11.zoomRangeAxes(1.0d, var14, var15, true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var6 = var1.arrange(var2, var5);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     boolean var2 = var0.isVisible();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     double var4 = var3.getLowerMargin();
//     org.jfree.chart.axis.Timeline var5 = null;
//     var3.setTimeline(var5);
//     java.awt.Shape var7 = var3.getLeftArrow();
//     var0.setLeftArrow(var7);
//     java.util.Date var9 = var0.getMaximumDate();
//     org.jfree.chart.axis.DateTickUnit var10 = null;
//     java.util.Date var11 = var0.calculateHighestVisibleTickValue(var10);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    double var1 = var0.getContentYOffset();
    org.jfree.chart.util.VerticalAlignment var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setVerticalAlignment(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelGenerator();
//     boolean var5 = var2.getIgnoreZeroValues();
//     java.awt.Paint var6 = var2.getBaseSectionOutlinePaint();
//     var2.setCircular(false);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     org.jfree.chart.plot.PiePlotState var14 = var2.initialise(var9, var10, var11, (java.lang.Integer)(-1), var13);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     double var1 = var0.getTop();
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var0, var12);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(var12);
//     
//     // Checks the contract:  equals-hashcode on var14 and var15
//     assertTrue("Contract failed: equals-hashcode on var14 and var15", var14.equals(var15) ? var14.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var14
//     assertTrue("Contract failed: equals-hashcode on var15 and var14", var15.equals(var14) ? var15.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var5 = var2.getDataset();
    org.jfree.chart.labels.PieToolTipGenerator var6 = var2.getToolTipGenerator();
    var2.setShadowYOffset(2.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(4, var2, false);
//     java.awt.Paint var5 = var0.getDomainGridlinePaint();
//     var0.setWeight(1);
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     var8.add(var9, (java.lang.Object)var10);
//     org.jfree.chart.labels.PieSectionLabelGenerator var12 = var10.getLegendLabelGenerator();
//     var10.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var15 = var10.getBaseSectionOutlineStroke();
//     var0.setRangeGridlineStroke(var15);
//     org.jfree.data.category.CategoryDataset var17 = null;
//     var0.setDataset(var17);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var24 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var25 = null;
//     org.jfree.chart.plot.WaferMapPlot var26 = new org.jfree.chart.plot.WaferMapPlot(var24, var25);
//     java.awt.Font var27 = var26.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis();
//     var28.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var31 = var28.getPlot();
//     java.lang.String var32 = var28.getLabel();
//     java.awt.Paint var33 = var28.getLabelPaint();
//     org.jfree.chart.text.TextFragment var34 = new org.jfree.chart.text.TextFragment("", var27, var33);
//     java.awt.Font var35 = var34.getFont();
//     org.jfree.chart.text.TextLine var36 = new org.jfree.chart.text.TextLine("", var35);
//     var21.setLabelFont(var35);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     double var40 = var39.getLowerMargin();
//     boolean var41 = var39.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var43.setAutoRangeIncludesZero(true);
//     var43.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var43, var48);
//     boolean var50 = var49.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
//     var51.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var54 = var51.getPlot();
//     java.lang.String var55 = var51.getLabel();
//     java.awt.Paint var56 = var51.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var57 = new org.jfree.chart.block.BlockBorder(var56);
//     var49.setDomainTickBandPaint(var56);
//     var21.setPaint(var56);
//     org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var61 = null;
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot();
//     var60.add(var61, (java.lang.Object)var62);
//     org.jfree.chart.labels.PieSectionLabelGenerator var64 = var62.getLegendLabelGenerator();
//     var62.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var67 = var62.getBaseSectionOutlineStroke();
//     var21.setStroke(var67);
//     org.jfree.chart.util.Layer var69 = null;
//     boolean var70 = var0.removeDomainMarker(0, (org.jfree.chart.plot.Marker)var21, var69);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(0, var4, true);
    java.awt.Paint var7 = var0.getRangeCrosshairPaint();
    boolean var8 = var0.isDomainZoomable();
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    var0.setRenderer(15, var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.lang.Object var24 = var23.getTextAntiAlias();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var27 = var23.createBufferedImage((-1), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getText();
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var19 = null;
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
//     java.awt.Font var21 = var20.getNoDataMessageFont();
//     var20.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
//     java.lang.Object var26 = var25.clone();
//     var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
//     java.awt.Stroke var28 = var25.getBorderStroke();
//     var25.removeLegend();
//     java.awt.Graphics2D var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     java.awt.geom.Point2D var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = null;
//     var25.draw(var30, var31, var32, var33);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((-13.95d), 101.0d, (-1.0d), 2.0d);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var5 = var2.getPlot();
//     java.lang.String var6 = var2.getLabel();
//     java.awt.Paint var7 = var2.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(var7);
//     boolean var9 = var0.equals((java.lang.Object)var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var8.draw(var10, var11);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    double var4 = var3.getLowerMargin();
    java.util.Date var5 = var3.getMinimumDate();
    org.jfree.chart.axis.DateTickUnit var6 = null;
    var3.setTickUnit(var6, false, true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var13 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var12};
    var11.setRenderers(var13);
    org.jfree.chart.annotations.CategoryAnnotation var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var16 = var11.removeAnnotation(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("ThreadContext");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     var2.setLabelFont(var16);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     double var21 = var20.getLowerMargin();
//     boolean var22 = var20.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var24.setAutoRangeIncludesZero(true);
//     var24.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     boolean var31 = var30.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var35 = var32.getPlot();
//     java.lang.String var36 = var32.getLabel();
//     java.awt.Paint var37 = var32.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var37);
//     var30.setDomainTickBandPaint(var37);
//     var2.setPaint(var37);
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot();
//     var41.add(var42, (java.lang.Object)var43);
//     org.jfree.chart.labels.PieSectionLabelGenerator var45 = var43.getLegendLabelGenerator();
//     var43.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var48 = var43.getBaseSectionOutlineStroke();
//     var2.setStroke(var48);
//     var0.setRadiusGridlineStroke(var48);
//     org.jfree.data.xy.XYDataset var51 = null;
//     var0.setDataset(var51);
//     double var53 = var0.getMaxRadius();
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 15);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 100.0d);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var2 = var1.isInverted();
//     var1.setAutoRangeMinimumSize(1.0d);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     double var9 = var8.getLowerMargin();
//     boolean var10 = var8.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var12.setAutoRangeIncludesZero(true);
//     var12.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = null;
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var12, var17);
//     boolean var19 = var18.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     var20.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var23 = var20.getPlot();
//     java.lang.String var24 = var20.getLabel();
//     java.awt.Paint var25 = var20.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(var25);
//     var18.setDomainTickBandPaint(var25);
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var18.drawAnnotations(var28, var29, var30);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Point2D var35 = null;
//     var18.zoomDomainAxes(0.0d, 0.0d, var34, var35);
//     org.jfree.chart.util.RectangleEdge var38 = var18.getDomainAxisEdge(4);
//     double var39 = var1.valueToJava2D(0.0d, var6, var38);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.data.general.WaferMapDataset var2 = null;
    org.jfree.chart.renderer.WaferMapRenderer var3 = null;
    org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
    java.awt.Font var5 = var4.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    var6.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var9 = var6.getPlot();
    java.lang.String var10 = var6.getLabel();
    java.awt.Paint var11 = var6.getLabelPaint();
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
    java.awt.Stroke var13 = null;
    org.jfree.chart.ChartColor var18 = new org.jfree.chart.ChartColor(1, 0, 0);
    java.awt.image.ColorModel var19 = null;
    java.awt.Rectangle var20 = null;
    java.awt.geom.Rectangle2D var21 = null;
    java.awt.geom.AffineTransform var22 = null;
    java.awt.RenderingHints var23 = null;
    java.awt.PaintContext var24 = var18.createContext(var19, var20, var21, var22, var23);
    java.awt.Color var25 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var18);
    org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.general.WaferMapDataset var30 = null;
    org.jfree.chart.renderer.WaferMapRenderer var31 = null;
    org.jfree.chart.plot.WaferMapPlot var32 = new org.jfree.chart.plot.WaferMapPlot(var30, var31);
    java.awt.Font var33 = var32.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis();
    var34.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var37 = var34.getPlot();
    java.lang.String var38 = var34.getLabel();
    java.awt.Paint var39 = var34.getLabelPaint();
    org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var33, var39);
    java.awt.Font var41 = var40.getFont();
    org.jfree.chart.text.TextLine var42 = new org.jfree.chart.text.TextLine("", var41);
    var27.setLabelFont(var41);
    org.jfree.data.xy.XYDataset var44 = null;
    org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
    double var46 = var45.getLowerMargin();
    boolean var47 = var45.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var49.setAutoRangeIncludesZero(true);
    var49.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
    org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var44, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.axis.ValueAxis)var49, var54);
    boolean var56 = var55.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis();
    var57.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var60 = var57.getPlot();
    java.lang.String var61 = var57.getLabel();
    java.awt.Paint var62 = var57.getLabelPaint();
    org.jfree.chart.block.BlockBorder var63 = new org.jfree.chart.block.BlockBorder(var62);
    var55.setDomainTickBandPaint(var62);
    var27.setPaint(var62);
    org.jfree.chart.block.ColumnArrangement var66 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var67 = null;
    org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot();
    var66.add(var67, (java.lang.Object)var68);
    org.jfree.chart.labels.PieSectionLabelGenerator var70 = var68.getLegendLabelGenerator();
    var68.setMinimumArcAngleToDraw(0.05d);
    java.awt.Stroke var73 = var68.getBaseSectionOutlineStroke();
    var27.setStroke(var73);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var76 = new org.jfree.chart.plot.ValueMarker(0.0d, var11, var13, (java.awt.Paint)var25, var73, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.text.TextBlockAnchor var5 = null;
    java.awt.Shape var9 = var0.calculateBounds(var2, (-1.0f), 100.0f, var5, (-1.0f), 1.0f, 0.0d);
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var9);
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    double var12 = var11.getLowerMargin();
    boolean var13 = var11.isVisible();
    org.jfree.chart.axis.Timeline var14 = var11.getTimeline();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
    var15.setToolTipText("");
    boolean var18 = var11.equals((java.lang.Object)var15);
    org.jfree.chart.util.RectangleEdge var19 = var15.getPosition();
    boolean var20 = var10.equals((java.lang.Object)var19);
    var10.setURLText("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var3 = var0.getPlot();
    java.lang.String var4 = var0.getLabel();
    var0.configure();
    var0.setTickMarkOutsideLength(0.0f);
    org.jfree.chart.plot.Plot var8 = var0.getPlot();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.CategoryLabelPositions var10 = var9.getCategoryLabelPositions();
    var0.setCategoryLabelPositions(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    java.awt.Shape var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PieSectionEntity var7 = new org.jfree.chart.entity.PieSectionEntity(var0, var1, 100, (-253), (java.lang.Comparable)(byte)1, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
//     org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     var2.add(var3, (java.lang.Object)var4);
//     org.jfree.chart.labels.PieSectionLabelGenerator var6 = var4.getLegendLabelToolTipGenerator();
//     boolean var7 = var1.equals((java.lang.Object)var4);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     java.lang.Object var10 = var9.clone();
//     var9.setSectionDepth(0.0d);
//     var9.setInnerSeparatorExtension(100.0d);
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot();
//     double var16 = var15.getLabelLinkMargin();
//     java.awt.Paint var17 = var15.getLabelBackgroundPaint();
//     var9.setNoDataMessagePaint(var17);
//     org.jfree.chart.labels.PieSectionLabelGenerator var19 = var9.getLegendLabelGenerator();
//     var4.setLegendLabelGenerator(var19);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(4, var2, false);
//     java.awt.Paint var5 = var0.getDomainGridlinePaint();
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     double var7 = var6.getLowerMargin();
//     org.jfree.chart.axis.Timeline var8 = null;
//     var6.setTimeline(var8);
//     var6.setAutoTickUnitSelection(false, false);
//     var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var6);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     java.awt.Font var13 = var12.getFont();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("", var13);
//     org.jfree.chart.text.TextFragment var15 = var14.getFirstTextFragment();
//     org.jfree.data.general.WaferMapDataset var17 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var18 = null;
//     org.jfree.chart.plot.WaferMapPlot var19 = new org.jfree.chart.plot.WaferMapPlot(var17, var18);
//     java.awt.Font var20 = var19.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var24 = var21.getPlot();
//     java.lang.String var25 = var21.getLabel();
//     java.awt.Paint var26 = var21.getLabelPaint();
//     org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("", var20, var26);
//     java.lang.String var28 = var27.getText();
//     java.awt.Font var29 = var27.getFont();
//     var14.addFragment(var27);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, var1);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    org.jfree.data.Range var4 = var3.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     var11.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var13 = var11.getDomainAxisEdge();
//     var11.setRangeCrosshairValue(101.0d, true);
//     org.jfree.data.general.DatasetChangeEvent var17 = null;
//     var11.datasetChanged(var17);
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var23 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var24 = null;
//     org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
//     java.awt.Font var26 = var25.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     var27.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var30 = var27.getPlot();
//     java.lang.String var31 = var27.getLabel();
//     java.awt.Paint var32 = var27.getLabelPaint();
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var26, var32);
//     java.awt.Font var34 = var33.getFont();
//     org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("", var34);
//     var20.setLabelFont(var34);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
//     double var39 = var38.getLowerMargin();
//     boolean var40 = var38.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var42.setAutoRangeIncludesZero(true);
//     var42.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var42, var47);
//     boolean var49 = var48.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis();
//     var50.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var53 = var50.getPlot();
//     java.lang.String var54 = var50.getLabel();
//     java.awt.Paint var55 = var50.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(var55);
//     var48.setDomainTickBandPaint(var55);
//     var20.setPaint(var55);
//     boolean var59 = var11.removeRangeMarker((org.jfree.chart.plot.Marker)var20);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, 10.0f, (-1.0f), var4, 2.05d, var6);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     java.awt.Paint var16 = var13.getOutlinePaint();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     double var19 = var18.getLowerMargin();
//     boolean var20 = var18.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var22.setAutoRangeIncludesZero(true);
//     var22.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var31 = var30.getLabel();
//     var28.addDomainMarker((org.jfree.chart.plot.Marker)var30);
//     java.awt.Paint var33 = var30.getOutlinePaint();
//     org.jfree.chart.util.RectangleAnchor var34 = var30.getLabelAnchor();
//     var13.setLabelAnchor(var34);
//     
//     // Checks the contract:  equals-hashcode on var11 and var28
//     assertTrue("Contract failed: equals-hashcode on var11 and var28", var11.equals(var28) ? var11.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var11
//     assertTrue("Contract failed: equals-hashcode on var28 and var11", var28.equals(var11) ? var28.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var5 = var2.getPlot();
//     java.lang.String var6 = var2.getLabel();
//     java.awt.Paint var7 = var2.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(var7);
//     boolean var9 = var0.equals((java.lang.Object)var8);
//     org.jfree.chart.LegendItemCollection var10 = var0.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    java.awt.Paint[] var0 = null;
    java.awt.Paint[] var1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var3 = null;
    java.awt.Stroke[] var4 = new java.awt.Stroke[] { var3};
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Shape var7 = null;
    java.awt.Shape[] var8 = new java.awt.Shape[] { var7};
    org.jfree.chart.plot.DefaultDrawingSupplier var9 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var2, var4, var6, var8);
    java.awt.Shape var10 = var9.getNextShape();
    java.lang.Object var11 = var9.clone();
    boolean var13 = var9.equals((java.lang.Object)"XY Plot");
    java.awt.Shape var14 = var9.getNextShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    var0.setWeight(1);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var9.setAutoRangeIncludesZero(true);
    var9.setAutoRangeStickyZero(true);
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var0.setRangeAxes(var14);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var0.getDomainMarkers(var16);
    org.jfree.chart.plot.DatasetRenderingOrder var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    java.awt.Image var4 = null;
    org.jfree.chart.ui.ProjectInfo var8 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "ThreadContext", var4, "", "", "");
    java.util.List var9 = null;
    var8.setContributors(var9);
    java.lang.String var11 = var8.toString();
    org.jfree.chart.block.ColumnArrangement var12 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var13 = null;
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot();
    var12.add(var13, (java.lang.Object)var14);
    boolean var16 = var8.equals((java.lang.Object)var14);
    org.jfree.data.general.WaferMapDataset var19 = null;
    org.jfree.chart.renderer.WaferMapRenderer var20 = null;
    org.jfree.chart.plot.WaferMapPlot var21 = new org.jfree.chart.plot.WaferMapPlot(var19, var20);
    java.awt.Font var22 = var21.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
    var23.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var26 = var23.getPlot();
    java.lang.String var27 = var23.getLabel();
    java.awt.Paint var28 = var23.getLabelPaint();
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("", var22, var28);
    java.awt.Font var30 = var29.getFont();
    org.jfree.chart.text.TextLine var31 = new org.jfree.chart.text.TextLine("", var30);
    var14.setLabelFont(var30);
    org.jfree.chart.ChartColor var36 = new org.jfree.chart.ChartColor(1, 0, 0);
    java.awt.color.ColorSpace var37 = var36.getColorSpace();
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
    double var40 = var39.getLowerMargin();
    boolean var41 = var39.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var43.setAutoRangeIncludesZero(true);
    var43.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var43, var48);
    var49.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var51 = var49.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var52 = org.jfree.chart.util.RectangleEdge.opposite(var51);
    org.jfree.chart.text.TextBlock var53 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var54 = var53.getLineAlignment();
    org.jfree.chart.block.ColumnArrangement var55 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var56 = null;
    org.jfree.chart.plot.PiePlot var57 = new org.jfree.chart.plot.PiePlot();
    var55.add(var56, (java.lang.Object)var57);
    org.jfree.chart.labels.PieSectionLabelGenerator var59 = var57.getLegendLabelToolTipGenerator();
    boolean var60 = var54.equals((java.lang.Object)var57);
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.util.RectangleInsets var62 = new org.jfree.chart.util.RectangleInsets();
    java.lang.String var63 = var62.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle("ThreadContext", var30, (java.awt.Paint)var36, var52, var54, var61, var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var11.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var63 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var63.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var4.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var7 = var4.getPlot();
    java.lang.String var8 = var4.getLabel();
    java.awt.Paint var9 = var4.getLabelPaint();
    var0.setTickLabelPaint((java.lang.Comparable)(byte)0, var9);
    var0.setFixedDimension(10.0d);
    var0.setMaximumCategoryLabelWidthRatio(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Pie Plot", var1, 1.0f, 0.0f, var4, 1.0E-5d, var6);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var1 = var0.getTop();
    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var0, var12);
    double var16 = var0.extendWidth(0.05d);
    java.awt.geom.Rectangle2D var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var18 = var0.createInsetRectangle(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2.05d);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    int var2 = var1.size();
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(1, 0, 0);
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
    java.awt.Color var17 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var10);
    var4.setOutlinePaint((java.awt.Paint)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set(15, (java.lang.Object)var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.chart.util.RectangleInsets var5 = var2.getLabelPadding();
    var2.setLabelLinkMargin(0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     var0.setRenderer(0, var4, true);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var0.handleClick(4, 15, var9);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(4, var2, false);
//     java.awt.Paint var5 = var0.getDomainGridlinePaint();
//     var0.setWeight(1);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     double var10 = var9.getLowerMargin();
//     boolean var11 = var9.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var13.setAutoRangeIncludesZero(true);
//     var13.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     boolean var20 = var19.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var24 = var21.getPlot();
//     java.lang.String var25 = var21.getLabel();
//     java.awt.Paint var26 = var21.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(var26);
//     var19.setDomainTickBandPaint(var26);
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     var19.drawAnnotations(var29, var30, var31);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var35 = null;
//     var34.setFixedLegendItems(var35);
//     boolean var37 = var34.isRangeCrosshairVisible();
//     boolean var38 = var34.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var40 = var34.getDomainAxisLocation(10);
//     var19.setRangeAxisLocation(10, var40);
//     org.jfree.chart.plot.ValueMarker var44 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var47 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var48 = null;
//     org.jfree.chart.plot.WaferMapPlot var49 = new org.jfree.chart.plot.WaferMapPlot(var47, var48);
//     java.awt.Font var50 = var49.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
//     var51.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var54 = var51.getPlot();
//     java.lang.String var55 = var51.getLabel();
//     java.awt.Paint var56 = var51.getLabelPaint();
//     org.jfree.chart.text.TextFragment var57 = new org.jfree.chart.text.TextFragment("", var50, var56);
//     java.awt.Font var58 = var57.getFont();
//     org.jfree.chart.text.TextLine var59 = new org.jfree.chart.text.TextLine("", var58);
//     var44.setLabelFont(var58);
//     org.jfree.chart.util.Layer var61 = null;
//     var19.addRangeMarker((-253), (org.jfree.chart.plot.Marker)var44, var61);
//     org.jfree.chart.util.Layer var63 = null;
//     boolean var64 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var44, var63);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     java.awt.Font var3 = var2.getNoDataMessageFont();
//     org.jfree.chart.LegendItemCollection var4 = var2.getLegendItems();
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.plot.CrosshairState var17 = null;
    boolean var18 = var11.render(var13, var14, 0, var16, var17);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    var11.setRenderer(var19);
    var11.clearAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     var0.setRenderer(0, var4, true);
//     boolean var7 = var0.getDrawSharedDomainAxis();
//     org.jfree.data.category.CategoryDataset var8 = var0.getDataset();
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var10.setAutoRangeIncludesZero(true);
//     var10.setAutoRangeStickyZero(true);
//     var10.setRange(1.0d, 100.0d);
//     org.jfree.data.Range var18 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawBackground(var19, var20);
// 
//   }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     boolean var2 = var0.isVisible();
//     var0.setFixedDimension(1.0d);
//     java.util.Date var5 = var0.getMinimumDate();
//     double var6 = var0.getFixedDimension();
//     org.jfree.chart.axis.DateTickUnit var7 = null;
//     java.util.Date var8 = var0.calculateLowestVisibleTickValue(var7);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (-253));
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    java.awt.geom.Point2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.zoomDomainAxes(10.0d, 4.0d, var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.lang.Object var2 = var1.clone();
    var1.setSectionDepth(0.0d);
    var1.setInnerSeparatorExtension(100.0d);
    double var7 = var1.getSectionDepth();
    org.jfree.chart.urls.PieURLGenerator var8 = var1.getURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
    org.jfree.chart.util.Size2D var6 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.util.Size2D var7 = var5.calculateConstrainedSize(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set(15, (java.lang.Object)var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     java.util.Date var2 = var0.getMinimumDate();
//     double var3 = var0.getFixedDimension();
//     org.jfree.chart.axis.DateTickUnit var4 = null;
//     java.util.Date var5 = var0.calculateHighestVisibleTickValue(var4);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "ThreadContext", var3, "", "", "");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.lang.String var10 = var7.toString();
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot();
    var11.add(var12, (java.lang.Object)var13);
    boolean var15 = var7.equals((java.lang.Object)var13);
    org.jfree.data.general.WaferMapDataset var18 = null;
    org.jfree.chart.renderer.WaferMapRenderer var19 = null;
    org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
    java.awt.Font var21 = var20.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    var22.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var25 = var22.getPlot();
    java.lang.String var26 = var22.getLabel();
    java.awt.Paint var27 = var22.getLabelPaint();
    org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("", var21, var27);
    java.awt.Font var29 = var28.getFont();
    org.jfree.chart.text.TextLine var30 = new org.jfree.chart.text.TextLine("", var29);
    var13.setLabelFont(var29);
    java.awt.Color var34 = java.awt.Color.getColor("XY Plot", (-1));
    java.awt.color.ColorSpace var35 = var34.getColorSpace();
    int var36 = var34.getRed();
    int var37 = var34.getTransparency();
    var13.setBaseSectionOutlinePaint((java.awt.Paint)var34);
    java.awt.Paint var39 = var13.getShadowPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + " version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"+ "'", var10.equals(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    org.jfree.chart.LegendItemCollection var6 = var0.getLegendItems();
    var0.clearAnnotations();
    org.jfree.data.category.CategoryDataset var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDataset((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    java.awt.Color var1 = java.awt.Color.getColor("Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "ThreadContext", var3);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var0.getCategoryJava2DCoordinate(var3, 100, 1, var6, var7);
//     var0.setMaximumCategoryLabelWidthRatio(100.0f);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.AxisState var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.data.xy.XYDataset var14 = null;
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
//     double var16 = var15.getLowerMargin();
//     boolean var17 = var15.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var19.setAutoRangeIncludesZero(true);
//     var19.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var14, (org.jfree.chart.axis.ValueAxis)var15, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     var25.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var27 = var25.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var28 = org.jfree.chart.util.RectangleEdge.opposite(var27);
//     java.util.List var29 = var0.refreshTicks(var11, var12, var13, var28);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "XY Plot", "", "hi!", "hi!");
    var5.addOptionalLibrary("ThreadContext");

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.awt.Image var24 = var23.getBackgroundImage();
    int var25 = var23.getBackgroundImageAlignment();
    org.jfree.chart.title.TextTitle var26 = var23.getTitle();
    org.jfree.chart.title.LegendTitle var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.addLegend(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     double var3 = var2.getLowerMargin();
//     org.jfree.chart.axis.Timeline var4 = null;
//     var2.setTimeline(var4);
//     java.awt.Shape var6 = var2.getLeftArrow();
//     org.jfree.data.general.WaferMapDataset var8 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var9 = null;
//     org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
//     java.awt.Font var11 = var10.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var15 = var12.getPlot();
//     java.lang.String var16 = var12.getLabel();
//     java.awt.Paint var17 = var12.getLabelPaint();
//     org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("", var11, var17);
//     var2.setAxisLinePaint(var17);
//     org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var22 = var21.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var23 = var21.getTickUnit();
//     boolean var24 = var21.isAutoTickUnitSelection();
//     var21.setAutoRangeIncludesZero(true);
//     org.jfree.data.Range var27 = var21.getDefaultAutoRange();
//     var2.setDefaultAutoRange(var27);
//     var0.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var2);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.lang.Object var2 = var1.clone();
    var1.setSectionDepth(0.0d);
    var1.setInnerSeparatorExtension(100.0d);
    double var7 = var1.getSectionDepth();
    java.lang.Object var8 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("RectangleEdge.BOTTOM", var1);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     var0.setRenderer(0, var4, true);
//     java.awt.Paint var7 = var0.getRangeCrosshairPaint();
//     boolean var8 = var0.isDomainZoomable();
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     double var11 = var10.getLowerMargin();
//     boolean var12 = var10.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var14.setAutoRangeIncludesZero(true);
//     var14.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var19);
//     boolean var21 = var20.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var22.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var25 = var22.getPlot();
//     java.lang.String var26 = var22.getLabel();
//     java.awt.Paint var27 = var22.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(var27);
//     var20.setDomainTickBandPaint(var27);
//     java.awt.Graphics2D var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     var20.drawAnnotations(var30, var31, var32);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var36 = null;
//     var35.setFixedLegendItems(var36);
//     boolean var38 = var35.isRangeCrosshairVisible();
//     boolean var39 = var35.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var41 = var35.getDomainAxisLocation(10);
//     var20.setRangeAxisLocation(10, var41);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var48 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var49 = null;
//     org.jfree.chart.plot.WaferMapPlot var50 = new org.jfree.chart.plot.WaferMapPlot(var48, var49);
//     java.awt.Font var51 = var50.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
//     var52.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var55 = var52.getPlot();
//     java.lang.String var56 = var52.getLabel();
//     java.awt.Paint var57 = var52.getLabelPaint();
//     org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var51, var57);
//     java.awt.Font var59 = var58.getFont();
//     org.jfree.chart.text.TextLine var60 = new org.jfree.chart.text.TextLine("", var59);
//     var45.setLabelFont(var59);
//     org.jfree.chart.util.Layer var62 = null;
//     var20.addRangeMarker((-253), (org.jfree.chart.plot.Marker)var45, var62);
//     org.jfree.chart.util.Layer var64 = null;
//     boolean var65 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var45, var64);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var2 = var1.getLabel();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = null;
    var3.setFixedLegendItems(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var3.setRenderer(0, var7, true);
    boolean var10 = var3.getDrawSharedDomainAxis();
    org.jfree.data.category.CategoryDataset var11 = var3.getDataset();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var13.setAutoRangeIncludesZero(true);
    var13.setAutoRangeStickyZero(true);
    var13.setRange(1.0d, 100.0d);
    org.jfree.data.Range var21 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var13);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var3);
    org.jfree.chart.util.SortOrder var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setColumnRenderingOrder(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var5 = var2.getDataset();
    org.jfree.chart.labels.PieToolTipGenerator var6 = var2.getToolTipGenerator();
    org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var9 = var7.get(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     var0.removeFragment(var12);
//     org.jfree.data.general.WaferMapDataset var17 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var18 = null;
//     org.jfree.chart.plot.WaferMapPlot var19 = new org.jfree.chart.plot.WaferMapPlot(var17, var18);
//     java.awt.Font var20 = var19.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var24 = var21.getPlot();
//     java.lang.String var25 = var21.getLabel();
//     java.awt.Paint var26 = var21.getLabelPaint();
//     org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("", var20, var26);
//     java.awt.Font var28 = var27.getFont();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("ThreadContext", var28);
//     org.jfree.chart.ChartColor var34 = new org.jfree.chart.ChartColor(1, 0, 0);
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
//     java.awt.Color var41 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var34);
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("", var28, (java.awt.Paint)var34);
//     var0.addFragment(var42);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var2 = var1.getLabel();
//     java.awt.Stroke var3 = var1.getStroke();
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
//     double var6 = var5.getLowerMargin();
//     boolean var7 = var5.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var9.setAutoRangeIncludesZero(true);
//     var9.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = null;
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var18 = var17.getLabel();
//     var15.addDomainMarker((org.jfree.chart.plot.Marker)var17);
//     java.awt.Paint var20 = var17.getOutlinePaint();
//     org.jfree.chart.util.RectangleAnchor var21 = var17.getLabelAnchor();
//     var1.setLabelAnchor(var21);
//     
//     // Checks the contract:  equals-hashcode on var1 and var17
//     assertTrue("Contract failed: equals-hashcode on var1 and var17", var1.equals(var17) ? var1.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var1
//     assertTrue("Contract failed: equals-hashcode on var17 and var1", var17.equals(var1) ? var17.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
//     org.jfree.chart.plot.PolarPlot var6 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var8 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var11 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var12 = null;
//     org.jfree.chart.plot.WaferMapPlot var13 = new org.jfree.chart.plot.WaferMapPlot(var11, var12);
//     java.awt.Font var14 = var13.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var18 = var15.getPlot();
//     java.lang.String var19 = var15.getLabel();
//     java.awt.Paint var20 = var15.getLabelPaint();
//     org.jfree.chart.text.TextFragment var21 = new org.jfree.chart.text.TextFragment("", var14, var20);
//     java.awt.Font var22 = var21.getFont();
//     org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine("", var22);
//     var8.setLabelFont(var22);
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
//     double var27 = var26.getLowerMargin();
//     boolean var28 = var26.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var30.setAutoRangeIncludesZero(true);
//     var30.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     boolean var37 = var36.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
//     var38.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var41 = var38.getPlot();
//     java.lang.String var42 = var38.getLabel();
//     java.awt.Paint var43 = var38.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder(var43);
//     var36.setDomainTickBandPaint(var43);
//     var8.setPaint(var43);
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot();
//     var47.add(var48, (java.lang.Object)var49);
//     org.jfree.chart.labels.PieSectionLabelGenerator var51 = var49.getLegendLabelGenerator();
//     var49.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var54 = var49.getBaseSectionOutlineStroke();
//     var8.setStroke(var54);
//     var6.setRadiusGridlineStroke(var54);
//     java.awt.Paint var57 = var6.getAngleLabelPaint();
//     var2.setSectionOutlinePaint((java.lang.Comparable)4, var57);
//     
//     // Checks the contract:  equals-hashcode on var0 and var47
//     assertTrue("Contract failed: equals-hashcode on var0 and var47", var0.equals(var47) ? var0.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var0
//     assertTrue("Contract failed: equals-hashcode on var47 and var0", var47.equals(var0) ? var47.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     java.awt.Paint var16 = var13.getOutlinePaint();
//     java.lang.Class var17 = null;
//     java.util.EventListener[] var18 = var13.getListeners(var17);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    var1.setCategoryMargin(0.0d);
    java.lang.Object var4 = var1.clone();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    double var6 = var5.getLowerMargin();
    boolean var7 = var5.isVisible();
    var5.setFixedDimension(1.0d);
    java.util.Date var10 = var5.getMinimumDate();
    java.awt.Font var11 = var1.getTickLabelFont((java.lang.Comparable)var10);
    org.jfree.chart.ChartColor var16 = new org.jfree.chart.ChartColor(1, 0, 0);
    java.awt.image.ColorModel var17 = null;
    java.awt.Rectangle var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    java.awt.geom.AffineTransform var20 = null;
    java.awt.RenderingHints var21 = null;
    java.awt.PaintContext var22 = var16.createContext(var17, var18, var19, var20, var21);
    java.awt.Color var23 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var16);
    org.jfree.chart.text.TextBlock var24 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var25 = var24.getLineAlignment();
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.text.TextBlockAnchor var29 = null;
    java.awt.Shape var33 = var24.calculateBounds(var26, (-1.0f), 100.0f, var29, (-1.0f), 1.0f, 0.0d);
    org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity(var33);
    org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
    double var36 = var35.getLowerMargin();
    boolean var37 = var35.isVisible();
    org.jfree.chart.axis.Timeline var38 = var35.getTimeline();
    org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle();
    var39.setToolTipText("");
    boolean var42 = var35.equals((java.lang.Object)var39);
    org.jfree.chart.util.RectangleEdge var43 = var39.getPosition();
    boolean var44 = var34.equals((java.lang.Object)var43);
    org.jfree.chart.text.TextBlock var45 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var46 = var45.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var47 = null;
    org.jfree.chart.util.RectangleInsets var52 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, 1.0d, 1.0d);
    double var54 = var52.extendWidth(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("Other", var11, (java.awt.Paint)var23, var43, var46, var47, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 101.0d);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var2 = var1.isInverted();
    var1.setAutoRangeMinimumSize(1.0d);
    org.jfree.chart.axis.TickUnitSource var5 = var1.getStandardTickUnits();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    org.jfree.chart.LegendItemCollection var8 = var7.getLegendItems();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    double var10 = var9.getLowerMargin();
    java.util.Date var11 = var9.getMinimumDate();
    double var12 = var9.getFixedDimension();
    org.jfree.chart.text.TextBlock var13 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var14 = var13.getLineAlignment();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    java.awt.Shape var22 = var13.calculateBounds(var15, (-1.0f), 100.0f, var18, (-1.0f), 1.0f, 0.0d);
    org.jfree.chart.entity.ChartEntity var23 = new org.jfree.chart.entity.ChartEntity(var22);
    var9.setRightArrow(var22);
    var7.setLegendItemShape(var22);
    var1.setDownArrow(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var1.setAutoRangeIncludesZero(true);
    var1.setLabelAngle(0.2d);
    java.lang.Object var6 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var14 = var13.getLabel();
    var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var18 = var17.isInverted();
    org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
    boolean var20 = var17.isAutoTickUnitSelection();
    var17.setAutoRangeIncludesZero(true);
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
    var11.setRangeAxes(var23);
    org.jfree.chart.axis.ValueAxis var26 = var11.getDomainAxis(1);
    org.jfree.chart.plot.PlotOrientation var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setOrientation(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     org.jfree.chart.axis.Timeline var2 = null;
//     var0.setTimeline(var2);
//     var0.setAutoTickUnitSelection(false, false);
//     var0.setRangeAboutValue(2.0d, 101.0d);
//     var0.setNegativeArrowVisible(true);
//     boolean var13 = var0.isHiddenValue(10L);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var13 = var11.getDomainAxisEdge();
    org.jfree.chart.axis.ValueAxis var14 = var11.getDomainAxis();
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var11.getDomainMarkers((-1), var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)1.0E-5d);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     var0.setRenderer(0, var4, true);
//     org.jfree.chart.axis.CategoryAxis var8 = var0.getDomainAxis(15);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawBackground(var9, var10);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleEdge.BOTTOM", var1, 2.0d, 0.0f, (-1.0f));
// 
//   }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    java.lang.String var1 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var1.equals("Size2D[width=0.0, height=0.0]"));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.lang.Comparable var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var3 = var1.getSectionPaint(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    var23.setBackgroundImageAlpha(0.0f);
    java.lang.Object var26 = var23.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    double var1 = var0.getContentYOffset();
    var0.setText("");
    java.lang.Object var4 = var0.clone();
    org.jfree.chart.util.RectangleEdge var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPosition(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.awt.Image var24 = var23.getBackgroundImage();
    int var25 = var23.getBackgroundImageAlignment();
    org.jfree.chart.title.TextTitle var26 = var23.getTitle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var28 = var23.getSubtitle(15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     java.util.Date var2 = var0.getMinimumDate();
//     double var3 = var0.getLowerBound();
//     double var4 = var0.getLowerBound();
//     org.jfree.chart.axis.DateTickUnit var5 = null;
//     java.util.Date var6 = var0.calculateHighestVisibleTickValue(var5);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("Size2D[width=0.0, height=0.0]");

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Category Plot", var1);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     org.jfree.chart.axis.CategoryAnchor var2 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var1.getCategoryJava2DCoordinate(var2, (-1), 4, var5, var6);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.lang.Object var2 = var1.clone();
    var1.setSectionDepth(0.0d);
    var1.setPieIndex((-253));
    java.awt.Font var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
//     java.awt.Paint var16 = null;
//     org.jfree.chart.text.TextMeasurer var18 = null;
//     org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("Other", var14, var16, 2.0f, var18);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.data.general.DatasetGroup var12 = var11.getDatasetGroup();
    java.awt.Stroke var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setRangeZeroBaselineStroke(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var6 = null;
//     var4.setRangeAxisLocation(4, var6, false);
//     java.awt.Paint var9 = var4.getDomainGridlinePaint();
//     org.jfree.chart.LegendItemCollection var10 = var4.getLegendItems();
//     org.jfree.chart.util.RectangleEdge var11 = var4.getDomainAxisEdge();
//     double var12 = var1.lengthToJava2D(1.0E-8d, var3, var11);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    double var4 = var3.getLowerMargin();
    java.util.Date var5 = var3.getMinimumDate();
    org.jfree.chart.axis.DateTickUnit var6 = null;
    var3.setTickUnit(var6, false, true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
    boolean var12 = var11.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     var4.zoomRangeAxes(0.0d, var8, var9);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
//     double var15 = var14.getLowerMargin();
//     boolean var16 = var14.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var18.setAutoRangeIncludesZero(true);
//     var18.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var18, var23);
//     var24.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var26 = var24.getDomainAxisEdge();
//     var24.setRangeCrosshairValue(101.0d, true);
//     var24.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var32 = var24.getQuadrantOrigin();
//     var4.zoomRangeAxes(4.0d, var12, var32, false);
//     org.jfree.chart.plot.PlotState var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var1.draw(var2, var3, var32, var35, var36);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(2.0d, var1);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeWidth(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(0.0d);
//     java.lang.Object var3 = var0.clone();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     double var10 = var9.getLowerMargin();
//     boolean var11 = var9.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var13.setAutoRangeIncludesZero(true);
//     var13.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     boolean var20 = var19.isDomainZeroBaselineVisible();
//     java.awt.Paint var21 = var19.getRangeZeroBaselinePaint();
//     var19.clearDomainMarkers(255);
//     org.jfree.chart.util.RectangleEdge var25 = var19.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.chart.axis.AxisState var27 = var0.draw(var4, 0.5d, var6, var7, var25, var26);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    float[] var4 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(255, 1, 1, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     var11.configureRangeAxes();
//     org.jfree.chart.axis.AxisSpace var13 = null;
//     var11.setFixedDomainAxisSpace(var13);
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
//     var15.add(var16, (java.lang.Object)var17);
//     org.jfree.chart.labels.PieSectionLabelGenerator var19 = var17.getLegendLabelToolTipGenerator();
//     org.jfree.chart.util.RectangleInsets var20 = var17.getLabelPadding();
//     java.awt.Stroke var21 = var17.getLabelOutlineStroke();
//     var11.setRangeGridlineStroke(var21);
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     double var25 = var24.getLowerMargin();
//     org.jfree.chart.axis.Timeline var26 = null;
//     var24.setTimeline(var26);
//     double var28 = var24.getFixedAutoRange();
//     org.jfree.chart.util.RectangleInsets var29 = var24.getTickLabelInsets();
//     var11.setRangeAxis((-253), (org.jfree.chart.axis.ValueAxis)var24);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-13.95d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.awt.Image var24 = var23.getBackgroundImage();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var25 = var23.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.Timeline var2 = null;
    var0.setTimeline(var2);
    java.awt.Shape var4 = var0.getLeftArrow();
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis();
    double var6 = var5.getLowerMargin();
    java.util.Date var7 = var5.getMinimumDate();
    org.jfree.chart.axis.DateTickUnit var8 = null;
    var5.setTickUnit(var8, false, true);
    org.jfree.chart.axis.DateTickUnit var12 = var5.getTickUnit();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var15 = var14.isInverted();
    org.jfree.chart.axis.NumberTickUnit var16 = var14.getTickUnit();
    boolean var17 = var14.isAutoTickUnitSelection();
    var14.setAutoRangeIncludesZero(true);
    org.jfree.data.Range var20 = var14.getDefaultAutoRange();
    var5.setRange(var20);
    double var22 = var20.getUpperBound();
    double var24 = var20.constrain((-1.0d));
    var0.setDefaultAutoRange(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var1 = var0.getTop();
    double var3 = var0.calculateTopInset((-1.0d));
    double var5 = var0.calculateTopInset(0.0d);
    org.jfree.chart.util.UnitType var6 = var0.getUnitType();
    double var7 = var0.getTop();
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var0.createInsetRectangle(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "Size2D[width=0.0, height=0.0]", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var5 = var2.getDataset();
    org.jfree.chart.labels.PieToolTipGenerator var6 = var2.getToolTipGenerator();
    org.jfree.chart.text.TextBlock var7 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.text.TextBlockAnchor var11 = null;
    java.awt.Shape var15 = var7.calculateBounds(var8, 10.0f, 1.0f, var11, 100.0f, (-1.0f), 1.0d);
    var2.setLegendItemShape(var15);
    int var17 = var2.getBackgroundImageAlignment();
    double var18 = var2.getInteriorGap();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.08d);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getText();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    java.awt.Font var8 = var7.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var9.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    java.lang.String var13 = var9.getLabel();
    java.awt.Paint var14 = var9.getLabelPaint();
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
    java.awt.Font var16 = var15.getFont();
    org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
    org.jfree.data.general.WaferMapDataset var18 = null;
    org.jfree.chart.renderer.WaferMapRenderer var19 = null;
    org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
    java.awt.Font var21 = var20.getNoDataMessageFont();
    var20.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
    java.lang.Object var26 = var25.clone();
    var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var28 = var25.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelGenerator();
//     boolean var5 = var2.getIgnoreZeroValues();
//     boolean var6 = var2.isSubplot();
//     java.awt.Shape var7 = var2.getLegendItemShape();
//     org.jfree.data.general.DatasetGroup var8 = var2.getDatasetGroup();
//     var2.setIgnoreNullValues(false);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
//     java.lang.Object var13 = var12.clone();
//     var12.setSectionDepth(0.0d);
//     var12.setInnerSeparatorExtension(100.0d);
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot();
//     double var19 = var18.getLabelLinkMargin();
//     java.awt.Paint var20 = var18.getLabelBackgroundPaint();
//     var12.setNoDataMessagePaint(var20);
//     org.jfree.chart.labels.PieSectionLabelGenerator var22 = var12.getLegendLabelGenerator();
//     var2.setLegendLabelGenerator(var22);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var4
//     assertTrue("Contract failed: equals-hashcode on var22 and var4", var22.equals(var4) ? var22.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
//     org.jfree.data.general.WaferMapDataset var16 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     var18.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
//     java.awt.Image var24 = var23.getBackgroundImage();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     var23.setTitle(var26);
//     org.jfree.data.general.WaferMapDataset var31 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var32 = null;
//     org.jfree.chart.plot.WaferMapPlot var33 = new org.jfree.chart.plot.WaferMapPlot(var31, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
//     var35.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var38 = var35.getPlot();
//     java.lang.String var39 = var35.getLabel();
//     java.awt.Paint var40 = var35.getLabelPaint();
//     org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("", var34, var40);
//     java.awt.Font var42 = var41.getFont();
//     org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("", var42);
//     org.jfree.data.general.WaferMapDataset var44 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var45 = null;
//     org.jfree.chart.plot.WaferMapPlot var46 = new org.jfree.chart.plot.WaferMapPlot(var44, var45);
//     java.awt.Font var47 = var46.getNoDataMessageFont();
//     var46.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart("ThreadContext", var42, (org.jfree.chart.plot.Plot)var46, false);
//     var51.setBackgroundImageAlpha(0.0f);
//     org.jfree.chart.title.TextTitle var54 = var51.getTitle();
//     var26.addChangeListener((org.jfree.chart.event.TitleChangeListener)var51);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var46
//     assertTrue("Contract failed: equals-hashcode on var18 and var46", var18.equals(var46) ? var18.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var18
//     assertTrue("Contract failed: equals-hashcode on var46 and var18", var46.equals(var18) ? var46.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Range[0.0,1.0]");

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var4.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var7 = var4.getPlot();
//     java.lang.String var8 = var4.getLabel();
//     java.awt.Paint var9 = var4.getLabelPaint();
//     var0.setTickLabelPaint((java.lang.Comparable)(byte)0, var9);
//     var0.addCategoryLabelToolTip((java.lang.Comparable)(-1.0f), "");
//     boolean var14 = var0.isAxisLineVisible();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.axis.AxisState var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     double var20 = var19.getLowerMargin();
//     boolean var21 = var19.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var23.setAutoRangeIncludesZero(true);
//     var23.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     var29.configureRangeAxes();
//     org.jfree.chart.axis.AxisSpace var31 = null;
//     var29.setFixedDomainAxisSpace(var31);
//     org.jfree.data.general.DatasetChangeEvent var33 = null;
//     var29.datasetChanged(var33);
//     org.jfree.chart.util.RectangleEdge var36 = var29.getRangeAxisEdge(0);
//     java.util.List var37 = var0.refreshTicks(var15, var16, var17, var36);
// 
//   }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var5);
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     var7.add(var8, (java.lang.Object)var9);
//     var6.setArrangement((org.jfree.chart.block.Arrangement)var7);
//     var6.clear();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     double var14 = var13.getLowerMargin();
//     org.jfree.chart.axis.Timeline var15 = null;
//     var13.setTimeline(var15);
//     java.awt.Shape var17 = var13.getLeftArrow();
//     org.jfree.data.general.WaferMapDataset var19 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var20 = null;
//     org.jfree.chart.plot.WaferMapPlot var21 = new org.jfree.chart.plot.WaferMapPlot(var19, var20);
//     java.awt.Font var22 = var21.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
//     var23.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var26 = var23.getPlot();
//     java.lang.String var27 = var23.getLabel();
//     java.awt.Paint var28 = var23.getLabelPaint();
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("", var22, var28);
//     var13.setAxisLinePaint(var28);
//     var0.add((org.jfree.chart.block.Block)var6, (java.lang.Object)var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     var6.add(var7, (java.lang.Object)var8);
//     var5.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("ThreadContext");
//     boolean var13 = var5.equals((java.lang.Object)var12);
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var19 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var18);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var21 = var20.getText();
//     var20.setID("ThreadContext");
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     var25.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var28 = var25.getPlot();
//     java.lang.String var29 = var25.getLabel();
//     java.awt.Paint var30 = var25.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(var30);
//     var24.setTickMarkPaint(var30);
//     var20.setBackgroundPaint(var30);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
//     double var36 = var35.getLowerMargin();
//     boolean var37 = var35.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var39.setAutoRangeIncludesZero(true);
//     var39.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var44);
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var48 = var47.getLabel();
//     var45.addDomainMarker((org.jfree.chart.plot.Marker)var47);
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var52 = var51.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var53 = var51.getTickUnit();
//     boolean var54 = var51.isAutoTickUnitSelection();
//     var51.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var57 = new org.jfree.chart.axis.ValueAxis[] { var51};
//     var45.setRangeAxes(var57);
//     java.lang.String var59 = var45.getPlotType();
//     var18.add((org.jfree.chart.block.Block)var20, (java.lang.Object)var59);
//     var5.setArrangement((org.jfree.chart.block.Arrangement)var18);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     boolean var3 = var0.isRangeCrosshairVisible();
//     org.jfree.data.general.WaferMapDataset var7 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var8 = null;
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var7, var8);
//     java.awt.Font var10 = var9.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     var11.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var14 = var11.getPlot();
//     java.lang.String var15 = var11.getLabel();
//     java.awt.Paint var16 = var11.getLabelPaint();
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var10, var16);
//     java.awt.Font var18 = var17.getFont();
//     org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("", var18);
//     org.jfree.data.general.WaferMapDataset var20 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var21 = null;
//     org.jfree.chart.plot.WaferMapPlot var22 = new org.jfree.chart.plot.WaferMapPlot(var20, var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     var22.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("ThreadContext", var18, (org.jfree.chart.plot.Plot)var22, false);
//     java.awt.Image var28 = var27.getBackgroundImage();
//     int var29 = var27.getBackgroundImageAlignment();
//     org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var27);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     double var32 = var31.getLowerMargin();
//     boolean var33 = var31.isVisible();
//     var31.setFixedDimension(1.0d);
//     org.jfree.data.Range var36 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var31);
//     org.jfree.chart.axis.DateTickUnit var37 = null;
//     java.util.Date var38 = var31.calculateHighestVisibleTickValue(var37);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.lang.Object var2 = var1.clone();
//     var1.setSectionDepth(0.0d);
//     org.jfree.chart.labels.PieSectionLabelGenerator var5 = var1.getLabelGenerator();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var13 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var14 = null;
//     org.jfree.chart.plot.WaferMapPlot var15 = new org.jfree.chart.plot.WaferMapPlot(var13, var14);
//     java.awt.Font var16 = var15.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     var17.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var20 = var17.getPlot();
//     java.lang.String var21 = var17.getLabel();
//     java.awt.Paint var22 = var17.getLabelPaint();
//     org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("", var16, var22);
//     java.awt.Font var24 = var23.getFont();
//     org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("", var24);
//     var10.setLabelFont(var24);
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
//     double var29 = var28.getLowerMargin();
//     boolean var30 = var28.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var32.setAutoRangeIncludesZero(true);
//     var32.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var32, var37);
//     boolean var39 = var38.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
//     var40.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var43 = var40.getPlot();
//     java.lang.String var44 = var40.getLabel();
//     java.awt.Paint var45 = var40.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var45);
//     var38.setDomainTickBandPaint(var45);
//     var10.setPaint(var45);
//     org.jfree.chart.block.ColumnArrangement var49 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var50 = null;
//     org.jfree.chart.plot.PiePlot var51 = new org.jfree.chart.plot.PiePlot();
//     var49.add(var50, (java.lang.Object)var51);
//     org.jfree.chart.labels.PieSectionLabelGenerator var53 = var51.getLegendLabelGenerator();
//     var51.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var56 = var51.getBaseSectionOutlineStroke();
//     var10.setStroke(var56);
//     var8.setRadiusGridlineStroke(var56);
//     java.awt.Paint var59 = var8.getAngleLabelPaint();
//     boolean var60 = var8.isAngleLabelsVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis();
//     double var65 = var64.getLowerMargin();
//     boolean var66 = var64.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var68 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var68.setAutoRangeIncludesZero(true);
//     var68.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot(var63, (org.jfree.chart.axis.ValueAxis)var64, (org.jfree.chart.axis.ValueAxis)var68, var73);
//     var74.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var76 = var74.getDomainAxisEdge();
//     var74.setRangeCrosshairValue(101.0d, true);
//     var74.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var82 = var74.getQuadrantOrigin();
//     var8.zoomDomainAxes(100.0d, var62, var82);
//     org.jfree.chart.plot.PlotState var84 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     var1.draw(var6, var7, var82, var84, var85);
// 
//   }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(10, 4, 100);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "Range[0.0,1.0]", "Category Plot", "Multiple Pie Plot");

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var0.getCategoryJava2DCoordinate(var3, 100, 1, var6, var7);
//     org.jfree.chart.plot.MultiplePiePlot var9 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var10 = var9.getLegendItems();
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     double var12 = var11.getLowerMargin();
//     java.util.Date var13 = var11.getMinimumDate();
//     var9.setAggregatedItemsKey((java.lang.Comparable)var13);
//     boolean var15 = var0.hasListener((java.util.EventListener)var9);
//     org.jfree.chart.LegendItemCollection var16 = var9.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var10 and var16
//     assertTrue("Contract failed: equals-hashcode on var10 and var16", var10.equals(var16) ? var10.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var10
//     assertTrue("Contract failed: equals-hashcode on var16 and var10", var16.equals(var10) ? var16.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     org.jfree.chart.axis.Timeline var2 = null;
//     var0.setTimeline(var2);
//     double var4 = var0.getFixedAutoRange();
//     java.util.TimeZone var5 = var0.getTimeZone();
//     var0.setAutoRange(true);
//     var0.setFixedAutoRange(1.0E-8d);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     double var13 = var12.getLowerMargin();
//     boolean var14 = var12.isVisible();
//     org.jfree.chart.axis.Timeline var15 = var12.getTimeline();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle();
//     var16.setToolTipText("");
//     boolean var19 = var12.equals((java.lang.Object)var16);
//     org.jfree.chart.util.RectangleEdge var20 = var16.getPosition();
//     double var21 = var0.valueToJava2D(0.14d, var11, var20);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
//     org.jfree.data.general.PieDataset var5 = var2.getDataset();
//     org.jfree.chart.labels.PieToolTipGenerator var6 = var2.getToolTipGenerator();
//     org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
//     org.jfree.chart.LegendItemCollection var8 = new org.jfree.chart.LegendItemCollection();
//     var7.addAll(var8);
//     
//     // Checks the contract:  equals-hashcode on var7 and var8
//     assertTrue("Contract failed: equals-hashcode on var7 and var8", var7.equals(var8) ? var7.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var7
//     assertTrue("Contract failed: equals-hashcode on var8 and var7", var8.equals(var7) ? var8.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getLabelLinkMargin();
    java.awt.Paint var2 = var0.getLabelBackgroundPaint();
    boolean var3 = var0.isSubplot();
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var0.setURLGenerator(var4);
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var0.setLegendLabelURLGenerator(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     double var6 = var5.getContentYOffset();
//     var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)(-1));
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     org.jfree.chart.block.BlockFrame var10 = var9.getFrame();
//     var9.clear();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
//     java.util.List var15 = var14.getLines();
//     java.lang.Object var16 = var9.draw(var12, var13, (java.lang.Object)var15);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var4.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var8.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var11 = var8.getPlot();
    java.lang.String var12 = var8.getLabel();
    java.awt.Paint var13 = var8.getLabelPaint();
    var4.setTickLabelPaint((java.lang.Comparable)(byte)0, var13);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder(2.0d, 2.0d, (-13.95d), 1.0E-8d, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var5 = var2.getDataset();
    double var6 = var2.getMaximumLabelWidth();
    var2.setLabelLinksVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.14d);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("ThreadContext", var1, var2);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var2 = var1.isInverted();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    boolean var4 = var1.isAutoTickUnitSelection();
    boolean var5 = var1.getAutoRangeStickyZero();
    org.jfree.data.RangeType var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeType(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
//     org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
//     var2.add(var3, (java.lang.Object)var4);
//     org.jfree.chart.labels.PieSectionLabelGenerator var6 = var4.getLegendLabelToolTipGenerator();
//     boolean var7 = var1.equals((java.lang.Object)var4);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var11 = var8.getPlot();
//     java.lang.String var12 = var8.getLabel();
//     java.awt.Paint var13 = var8.getLabelPaint();
//     var4.setLabelPaint(var13);
//     org.jfree.chart.text.TextBlock var15 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var16 = var15.getLineAlignment();
//     org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot();
//     var17.add(var18, (java.lang.Object)var19);
//     org.jfree.chart.labels.PieSectionLabelGenerator var21 = var19.getLegendLabelToolTipGenerator();
//     boolean var22 = var16.equals((java.lang.Object)var19);
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
//     var23.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var26 = var23.getPlot();
//     java.lang.String var27 = var23.getLabel();
//     java.awt.Paint var28 = var23.getLabelPaint();
//     var19.setLabelPaint(var28);
//     var4.setLabelShadowPaint(var28);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var1 = null;
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
//     java.awt.Font var3 = var2.getNoDataMessageFont();
//     var2.setBackgroundAlpha((-1.0f));
//     java.lang.Object var6 = var2.clone();
//     java.awt.Image var7 = var2.getBackgroundImage();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     org.jfree.chart.plot.PlotState var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var2.draw(var8, var9, var10, var11, var12);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     java.awt.Font var13 = var12.getFont();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("", var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var19 = null;
//     var18.setFixedLegendItems(var19);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     var18.setRenderer(0, var22, true);
//     var18.setRangeCrosshairVisible(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var18.setRenderer(1, var28, true);
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var33.setMaximumCategoryLabelLines(15);
//     var18.setDomainAxis(15, (org.jfree.chart.axis.CategoryAxis)var33);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     double var40 = var39.getLowerMargin();
//     boolean var41 = var39.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var43.setAutoRangeIncludesZero(true);
//     var43.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var43, var48);
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var52 = var51.getLabel();
//     var49.addDomainMarker((org.jfree.chart.plot.Marker)var51);
//     java.awt.Paint var54 = var51.getOutlinePaint();
//     org.jfree.chart.util.Layer var55 = null;
//     var18.addRangeMarker(0, (org.jfree.chart.plot.Marker)var51, var55);
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var58 = var57.getText();
//     org.jfree.data.general.WaferMapDataset var62 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var63 = null;
//     org.jfree.chart.plot.WaferMapPlot var64 = new org.jfree.chart.plot.WaferMapPlot(var62, var63);
//     java.awt.Font var65 = var64.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var66 = new org.jfree.chart.axis.CategoryAxis();
//     var66.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var69 = var66.getPlot();
//     java.lang.String var70 = var66.getLabel();
//     java.awt.Paint var71 = var66.getLabelPaint();
//     org.jfree.chart.text.TextFragment var72 = new org.jfree.chart.text.TextFragment("", var65, var71);
//     java.awt.Font var73 = var72.getFont();
//     org.jfree.chart.text.TextLine var74 = new org.jfree.chart.text.TextLine("", var73);
//     org.jfree.data.general.WaferMapDataset var75 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var76 = null;
//     org.jfree.chart.plot.WaferMapPlot var77 = new org.jfree.chart.plot.WaferMapPlot(var75, var76);
//     java.awt.Font var78 = var77.getNoDataMessageFont();
//     var77.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var82 = new org.jfree.chart.JFreeChart("ThreadContext", var73, (org.jfree.chart.plot.Plot)var77, false);
//     java.lang.Object var83 = var82.clone();
//     var57.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var82);
//     java.awt.Stroke var85 = var82.getBorderStroke();
//     var82.removeLegend();
//     boolean var87 = var51.equals((java.lang.Object)var82);
//     org.jfree.chart.text.TextAnchor var88 = var51.getLabelTextAnchor();
//     var14.draw(var15, 100.0f, 0.0f, var88, 10.0f, 2.0f, 0.5d);
// 
//   }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var2 = var1.getLabel();
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var4 = null;
    var3.setFixedLegendItems(var4);
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    var3.setRenderer(0, var7, true);
    boolean var10 = var3.getDrawSharedDomainAxis();
    org.jfree.data.category.CategoryDataset var11 = var3.getDataset();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var13.setAutoRangeIncludesZero(true);
    var13.setAutoRangeStickyZero(true);
    var13.setRange(1.0d, 100.0d);
    org.jfree.data.Range var21 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var13);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var3);
    var1.setLabel("RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=10.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAlpha(10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.plot.CrosshairState var17 = null;
    boolean var18 = var11.render(var13, var14, 0, var16, var17);
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.general.WaferMapDataset var23 = null;
    org.jfree.chart.renderer.WaferMapRenderer var24 = null;
    org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
    java.awt.Font var26 = var25.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
    var27.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var30 = var27.getPlot();
    java.lang.String var31 = var27.getLabel();
    java.awt.Paint var32 = var27.getLabelPaint();
    org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var26, var32);
    java.awt.Font var34 = var33.getFont();
    org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("", var34);
    var20.setLabelFont(var34);
    org.jfree.data.xy.XYDataset var37 = null;
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    double var39 = var38.getLowerMargin();
    boolean var40 = var38.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var42.setAutoRangeIncludesZero(true);
    var42.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var42, var47);
    boolean var49 = var48.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis();
    var50.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var53 = var50.getPlot();
    java.lang.String var54 = var50.getLabel();
    java.awt.Paint var55 = var50.getLabelPaint();
    org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(var55);
    var48.setDomainTickBandPaint(var55);
    var20.setPaint(var55);
    var11.addRangeMarker((org.jfree.chart.plot.Marker)var20);
    org.jfree.chart.plot.PlotRenderingInfo var62 = null;
    org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var64 = null;
    org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis();
    double var66 = var65.getLowerMargin();
    boolean var67 = var65.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var69.setAutoRangeIncludesZero(true);
    var69.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var74 = null;
    org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot(var64, (org.jfree.chart.axis.ValueAxis)var65, (org.jfree.chart.axis.ValueAxis)var69, var74);
    var75.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var77 = var75.getDomainAxisEdge();
    var75.setRangeCrosshairValue(101.0d, true);
    var75.setForegroundAlpha(0.0f);
    java.awt.geom.Point2D var83 = var75.getQuadrantOrigin();
    var63.setQuadrantOrigin(var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.zoomRangeAxes(0.08d, 0.025d, var62, var83);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var5 = var2.getDataset();
    org.jfree.chart.labels.PieToolTipGenerator var6 = var2.getToolTipGenerator();
    org.jfree.chart.text.TextBlock var7 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.text.TextBlockAnchor var11 = null;
    java.awt.Shape var15 = var7.calculateBounds(var8, 10.0f, 1.0f, var11, 100.0f, (-1.0f), 1.0d);
    var2.setLegendItemShape(var15);
    double var17 = var2.getShadowYOffset();
    org.jfree.chart.labels.PieToolTipGenerator var18 = null;
    var2.setToolTipGenerator(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4.0d);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getText();
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var19 = null;
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
//     java.awt.Font var21 = var20.getNoDataMessageFont();
//     var20.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
//     java.lang.Object var26 = var25.clone();
//     var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
//     java.awt.Stroke var28 = var25.getBorderStroke();
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     var25.draw(var29, var30);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    double var2 = var1.getLatestAngle();
    java.awt.geom.Rectangle2D var3 = var1.getLinkArea();
    java.awt.geom.Rectangle2D var4 = var1.getExplodedPieArea();
    java.awt.geom.Rectangle2D var5 = null;
    var1.setLinkArea(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     org.jfree.chart.axis.Timeline var2 = null;
//     var0.setTimeline(var2);
//     var0.setAutoTickUnitSelection(false, false);
//     var0.zoomRange(2.05d, 101.0d);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleEdge.BOTTOM");

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var13 = var11.getDomainAxisEdge();
    var11.setRangeCrosshairValue(101.0d, true);
    org.jfree.data.general.DatasetChangeEvent var17 = null;
    var11.datasetChanged(var17);
    org.jfree.chart.axis.AxisLocation var20 = var11.getRangeAxisLocation(100);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.general.WaferMapDataset var28 = null;
    org.jfree.chart.renderer.WaferMapRenderer var29 = null;
    org.jfree.chart.plot.WaferMapPlot var30 = new org.jfree.chart.plot.WaferMapPlot(var28, var29);
    java.awt.Font var31 = var30.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
    var32.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var35 = var32.getPlot();
    java.lang.String var36 = var32.getLabel();
    java.awt.Paint var37 = var32.getLabelPaint();
    org.jfree.chart.text.TextFragment var38 = new org.jfree.chart.text.TextFragment("", var31, var37);
    java.awt.Font var39 = var38.getFont();
    org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("", var39);
    var25.setLabelFont(var39);
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
    double var44 = var43.getLowerMargin();
    boolean var45 = var43.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var47.setAutoRangeIncludesZero(true);
    var47.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var52 = null;
    org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot(var42, (org.jfree.chart.axis.ValueAxis)var43, (org.jfree.chart.axis.ValueAxis)var47, var52);
    boolean var54 = var53.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis();
    var55.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var58 = var55.getPlot();
    java.lang.String var59 = var55.getLabel();
    java.awt.Paint var60 = var55.getLabelPaint();
    org.jfree.chart.block.BlockBorder var61 = new org.jfree.chart.block.BlockBorder(var60);
    var53.setDomainTickBandPaint(var60);
    var25.setPaint(var60);
    org.jfree.chart.block.ColumnArrangement var64 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var65 = null;
    org.jfree.chart.plot.PiePlot var66 = new org.jfree.chart.plot.PiePlot();
    var64.add(var65, (java.lang.Object)var66);
    org.jfree.chart.labels.PieSectionLabelGenerator var68 = var66.getLegendLabelGenerator();
    var66.setMinimumArcAngleToDraw(0.05d);
    java.awt.Stroke var71 = var66.getBaseSectionOutlineStroke();
    var25.setStroke(var71);
    var23.setRadiusGridlineStroke(var71);
    java.awt.Paint var74 = var23.getAngleLabelPaint();
    boolean var75 = var23.isAngleLabelsVisible();
    org.jfree.chart.plot.PlotRenderingInfo var77 = null;
    org.jfree.data.xy.XYDataset var78 = null;
    org.jfree.chart.axis.DateAxis var79 = new org.jfree.chart.axis.DateAxis();
    double var80 = var79.getLowerMargin();
    boolean var81 = var79.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var83.setAutoRangeIncludesZero(true);
    var83.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var88 = null;
    org.jfree.chart.plot.XYPlot var89 = new org.jfree.chart.plot.XYPlot(var78, (org.jfree.chart.axis.ValueAxis)var79, (org.jfree.chart.axis.ValueAxis)var83, var88);
    var89.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var91 = var89.getDomainAxisEdge();
    var89.setRangeCrosshairValue(101.0d, true);
    var89.setForegroundAlpha(0.0f);
    java.awt.geom.Point2D var97 = var89.getQuadrantOrigin();
    var23.zoomDomainAxes(100.0d, var77, var97);
    var11.zoomDomainAxes(4.0d, var22, var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 0.08d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var18 = var17.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
//     boolean var20 = var17.isAutoTickUnitSelection();
//     var17.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var11.setRangeAxes(var23);
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis();
//     int var26 = var11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var11.drawBackground(var27, var28);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.Timeline var2 = null;
    var0.setTimeline(var2);
    var0.setVisible(false);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    double var7 = var6.getLowerMargin();
    java.util.Date var8 = var6.getMinimumDate();
    double var9 = var6.getFixedDimension();
    org.jfree.chart.text.TextBlock var10 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var11 = var10.getLineAlignment();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    java.awt.Shape var19 = var10.calculateBounds(var12, (-1.0f), 100.0f, var15, (-1.0f), 1.0f, 0.0d);
    org.jfree.chart.entity.ChartEntity var20 = new org.jfree.chart.entity.ChartEntity(var19);
    var6.setRightArrow(var19);
    org.jfree.data.general.PieDataset var22 = null;
    java.lang.Comparable var25 = null;
    org.jfree.chart.entity.PieSectionEntity var28 = new org.jfree.chart.entity.PieSectionEntity(var19, var22, 255, 4, var25, "RectangleConstraint[LengthConstraintType.FIXED: width=0.0, height=10.0]", "PieSection: -1, -1(1.0)");
    var0.setRightArrow(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = null;
    var1.setFixedLegendItems(var2);
    boolean var4 = var1.isRangeCrosshairVisible();
    org.jfree.data.general.WaferMapDataset var8 = null;
    org.jfree.chart.renderer.WaferMapRenderer var9 = null;
    org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
    java.awt.Font var11 = var10.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    var12.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var15 = var12.getPlot();
    java.lang.String var16 = var12.getLabel();
    java.awt.Paint var17 = var12.getLabelPaint();
    org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("", var11, var17);
    java.awt.Font var19 = var18.getFont();
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("", var19);
    org.jfree.data.general.WaferMapDataset var21 = null;
    org.jfree.chart.renderer.WaferMapRenderer var22 = null;
    org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot(var21, var22);
    java.awt.Font var24 = var23.getNoDataMessageFont();
    var23.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("ThreadContext", var19, (org.jfree.chart.plot.Plot)var23, false);
    java.awt.Image var29 = var28.getBackgroundImage();
    int var30 = var28.getBackgroundImageAlignment();
    org.jfree.chart.event.ChartChangeEvent var31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var28);
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ChartRenderingInfo var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var37 = var32.createBufferedImage(255, 0, 1, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 15);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(4, var2, false);
//     java.awt.Paint var5 = var0.getDomainGridlinePaint();
//     var0.setWeight(1);
//     org.jfree.chart.block.ColumnArrangement var8 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot();
//     var8.add(var9, (java.lang.Object)var10);
//     org.jfree.chart.labels.PieSectionLabelGenerator var12 = var10.getLegendLabelGenerator();
//     var10.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var15 = var10.getBaseSectionOutlineStroke();
//     var0.setRangeGridlineStroke(var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     org.jfree.chart.plot.PlotState var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     var0.draw(var17, var18, var19, var20, var21);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    java.util.Date var2 = var0.getMinimumDate();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var0.setTickUnit(var3, false, true);
    org.jfree.chart.axis.DateTickUnit var7 = var0.getTickUnit();
    var0.setLowerMargin(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.lang.Object var24 = var23.clone();
    org.jfree.chart.event.ChartProgressListener var25 = null;
    var23.removeProgressListener(var25);
    boolean var27 = var23.isBorderVisible();
    var23.clearSubtitles();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var31 = var23.createBufferedImage(0, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     double var6 = var5.getContentYOffset();
//     var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)(-1));
//     org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     org.jfree.chart.block.BlockFrame var10 = var9.getFrame();
//     var9.clear();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var9.draw(var12, var13);
// 
//   }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    boolean var3 = var0.isRangeCrosshairVisible();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.zoomDomainAxes((-13.95d), (-1.0d), var6, var7);
    var0.clearDomainMarkers();
    org.jfree.chart.axis.CategoryAxis var11 = var0.getDomainAxisForDataset(15);
    org.jfree.chart.annotations.CategoryAnnotation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    org.jfree.chart.axis.NumberTickUnit var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var2, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     double var3 = var2.getLowerMargin();
//     java.util.Date var4 = var2.getMinimumDate();
//     var0.setAggregatedItemsKey((java.lang.Comparable)var4);
//     java.awt.Image var6 = null;
//     var0.setBackgroundImage(var6);
//     org.jfree.chart.event.PlotChangeEvent var8 = null;
//     var0.notifyListeners(var8);
//     org.jfree.data.general.DatasetGroup var10 = var0.getDatasetGroup();
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var14 = null;
//     var13.setFixedLegendItems(var14);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var13.zoomRangeAxes(0.0d, var17, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     double var24 = var23.getLowerMargin();
//     boolean var25 = var23.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var27.setAutoRangeIncludesZero(true);
//     var27.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var32);
//     var33.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var35 = var33.getDomainAxisEdge();
//     var33.setRangeCrosshairValue(101.0d, true);
//     var33.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var41 = var33.getQuadrantOrigin();
//     var13.zoomRangeAxes(4.0d, var21, var41, false);
//     org.jfree.chart.plot.PlotState var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     var0.draw(var11, var12, var41, var44, var45);
// 
//   }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var0.getCategoryJava2DCoordinate(var3, 100, 1, var6, var7);
//     var0.clearCategoryLabelToolTips();
//     java.awt.Font var11 = var0.getTickLabelFont((java.lang.Comparable)15);
//     java.awt.Color var14 = java.awt.Color.getColor("XY Plot", (-1));
//     java.awt.color.ColorSpace var15 = var14.getColorSpace();
//     float[] var22 = new float[] { 100.0f, 10.0f, 10.0f};
//     float[] var23 = java.awt.Color.RGBtoHSB((-253), (-1), 100, var22);
//     float[] var24 = var14.getColorComponents(var22);
//     var0.setTickLabelPaint((java.awt.Paint)var14);
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var31 = var30.getText();
//     var30.setID("ThreadContext");
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
//     double var36 = var35.getLowerMargin();
//     boolean var37 = var35.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var39.setAutoRangeIncludesZero(true);
//     var39.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var44 = null;
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var39, var44);
//     var45.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var47 = var45.getDomainAxisEdge();
//     boolean var48 = var30.equals((java.lang.Object)var47);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     org.jfree.chart.axis.AxisState var50 = var0.draw(var26, 0.0d, var28, var29, var47, var49);
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("LengthConstraintType.FIXED", var1, 10.0d, 100.0f, 10.0f);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var4 = null;
//     var3.setFixedLegendItems(var4);
//     boolean var6 = var3.isRangeCrosshairVisible();
//     boolean var7 = var3.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var9 = var3.getDomainAxisLocation(10);
//     var0.setRangeAxisLocation(var9);
//     java.lang.String var11 = var0.getPlotType();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var13 = null;
//     var12.setFixedLegendItems(var13);
//     boolean var15 = var12.isRangeCrosshairVisible();
//     org.jfree.data.general.WaferMapDataset var19 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var20 = null;
//     org.jfree.chart.plot.WaferMapPlot var21 = new org.jfree.chart.plot.WaferMapPlot(var19, var20);
//     java.awt.Font var22 = var21.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
//     var23.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var26 = var23.getPlot();
//     java.lang.String var27 = var23.getLabel();
//     java.awt.Paint var28 = var23.getLabelPaint();
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("", var22, var28);
//     java.awt.Font var30 = var29.getFont();
//     org.jfree.chart.text.TextLine var31 = new org.jfree.chart.text.TextLine("", var30);
//     org.jfree.data.general.WaferMapDataset var32 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var33 = null;
//     org.jfree.chart.plot.WaferMapPlot var34 = new org.jfree.chart.plot.WaferMapPlot(var32, var33);
//     java.awt.Font var35 = var34.getNoDataMessageFont();
//     var34.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart("ThreadContext", var30, (org.jfree.chart.plot.Plot)var34, false);
//     java.awt.Image var40 = var39.getBackgroundImage();
//     int var41 = var39.getBackgroundImageAlignment();
//     org.jfree.chart.event.ChartChangeEvent var42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var12, var39);
//     org.jfree.chart.util.SortOrder var43 = var12.getRowRenderingOrder();
//     var0.setRowRenderingOrder(var43);
//     
//     // Checks the contract:  equals-hashcode on var3 and var12
//     assertTrue("Contract failed: equals-hashcode on var3 and var12", var3.equals(var12) ? var3.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var3
//     assertTrue("Contract failed: equals-hashcode on var12 and var3", var12.equals(var3) ? var12.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("WMAP_Plot", var1);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     boolean var2 = var0.isVisible();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     double var4 = var3.getLowerMargin();
//     org.jfree.chart.axis.Timeline var5 = null;
//     var3.setTimeline(var5);
//     java.awt.Shape var7 = var3.getLeftArrow();
//     var0.setLeftArrow(var7);
//     org.jfree.data.general.WaferMapDataset var12 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var13 = null;
//     org.jfree.chart.plot.WaferMapPlot var14 = new org.jfree.chart.plot.WaferMapPlot(var12, var13);
//     java.awt.Font var15 = var14.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var16.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var19 = var16.getPlot();
//     java.lang.String var20 = var16.getLabel();
//     java.awt.Paint var21 = var16.getLabelPaint();
//     org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("", var15, var21);
//     java.awt.Font var23 = var22.getFont();
//     org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("", var23);
//     org.jfree.data.general.WaferMapDataset var25 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var26 = null;
//     org.jfree.chart.plot.WaferMapPlot var27 = new org.jfree.chart.plot.WaferMapPlot(var25, var26);
//     java.awt.Font var28 = var27.getNoDataMessageFont();
//     var27.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("ThreadContext", var23, (org.jfree.chart.plot.Plot)var27, false);
//     java.awt.Image var33 = var32.getBackgroundImage();
//     var32.setNotify(true);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var37 = null;
//     var36.setFixedLegendItems(var37);
//     boolean var39 = var36.isRangeCrosshairVisible();
//     org.jfree.data.general.WaferMapDataset var43 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var44 = null;
//     org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
//     java.awt.Font var46 = var45.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
//     var47.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var50 = var47.getPlot();
//     java.lang.String var51 = var47.getLabel();
//     java.awt.Paint var52 = var47.getLabelPaint();
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var46, var52);
//     java.awt.Font var54 = var53.getFont();
//     org.jfree.chart.text.TextLine var55 = new org.jfree.chart.text.TextLine("", var54);
//     org.jfree.data.general.WaferMapDataset var56 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var57 = null;
//     org.jfree.chart.plot.WaferMapPlot var58 = new org.jfree.chart.plot.WaferMapPlot(var56, var57);
//     java.awt.Font var59 = var58.getNoDataMessageFont();
//     var58.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var63 = new org.jfree.chart.JFreeChart("ThreadContext", var54, (org.jfree.chart.plot.Plot)var58, false);
//     java.awt.Image var64 = var63.getBackgroundImage();
//     int var65 = var63.getBackgroundImageAlignment();
//     org.jfree.chart.event.ChartChangeEvent var66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var36, var63);
//     org.jfree.chart.event.ChartChangeEventType var67 = var66.getType();
//     org.jfree.chart.event.ChartChangeEvent var68 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var32, var67);
//     
//     // Checks the contract:  equals-hashcode on var14 and var45
//     assertTrue("Contract failed: equals-hashcode on var14 and var45", var14.equals(var45) ? var14.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var58
//     assertTrue("Contract failed: equals-hashcode on var27 and var58", var27.equals(var58) ? var27.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var14
//     assertTrue("Contract failed: equals-hashcode on var45 and var14", var45.equals(var14) ? var45.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var27
//     assertTrue("Contract failed: equals-hashcode on var58 and var27", var58.equals(var27) ? var58.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var63
//     assertTrue("Contract failed: equals-hashcode on var32 and var63", var32.equals(var63) ? var32.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var32
//     assertTrue("Contract failed: equals-hashcode on var63 and var32", var63.equals(var32) ? var63.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    boolean var2 = var0.isVisible();
    org.jfree.chart.axis.Timeline var3 = var0.getTimeline();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    var4.setToolTipText("");
    boolean var7 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.util.RectangleEdge var8 = var4.getPosition();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var10.setAutoRangeIncludesZero(true);
    org.jfree.chart.util.RectangleInsets var13 = var10.getLabelInsets();
    var4.setMargin(var13);
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.block.RectangleConstraint var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var17 = var4.arrange(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setToolTipText("");
    java.lang.String var3 = var0.getID();
    java.lang.Object var4 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     var2.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var5 = var2.getPlot();
//     java.lang.String var6 = var2.getLabel();
//     java.awt.Paint var7 = var2.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(var7);
//     boolean var9 = var0.equals((java.lang.Object)var8);
//     var0.setAggregatedItemsKey((java.lang.Comparable)"WMAP_Plot");
//     java.awt.Paint var12 = var0.getAggregatedItemsPaint();
//     org.jfree.chart.LegendItemCollection var13 = var0.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
    org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    var2.add(var3, (java.lang.Object)var4);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var4.getLegendLabelToolTipGenerator();
    boolean var7 = var1.equals((java.lang.Object)var4);
    java.awt.Paint var8 = var4.getLabelPaint();
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var4.getLabelGenerator();
    java.awt.Stroke var11 = var4.getSectionOutlineStroke((java.lang.Comparable)4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    double var2 = var1.getPieCenterY();
    double var3 = var1.getLatestAngle();
    var1.setLatestAngle(0.08d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    var23.setBackgroundImageAlpha(0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var27 = var23.getSubtitle(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
//     org.jfree.data.general.WaferMapDataset var16 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     var18.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
//     java.awt.Image var24 = var23.getBackgroundImage();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     var23.setTitle(var26);
//     org.jfree.data.general.WaferMapDataset var31 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var32 = null;
//     org.jfree.chart.plot.WaferMapPlot var33 = new org.jfree.chart.plot.WaferMapPlot(var31, var32);
//     java.awt.Font var34 = var33.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
//     var35.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var38 = var35.getPlot();
//     java.lang.String var39 = var35.getLabel();
//     java.awt.Paint var40 = var35.getLabelPaint();
//     org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("", var34, var40);
//     java.awt.Font var42 = var41.getFont();
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle("ThreadContext", var42);
//     org.jfree.chart.ChartColor var48 = new org.jfree.chart.ChartColor(1, 0, 0);
//     java.awt.image.ColorModel var49 = null;
//     java.awt.Rectangle var50 = null;
//     java.awt.geom.Rectangle2D var51 = null;
//     java.awt.geom.AffineTransform var52 = null;
//     java.awt.RenderingHints var53 = null;
//     java.awt.PaintContext var54 = var48.createContext(var49, var50, var51, var52, var53);
//     java.awt.Color var55 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var48);
//     org.jfree.chart.text.TextFragment var56 = new org.jfree.chart.text.TextFragment("", var42, (java.awt.Paint)var48);
//     var26.setFont(var42);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
    org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    var2.add(var3, (java.lang.Object)var4);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var4.getLegendLabelToolTipGenerator();
    boolean var7 = var1.equals((java.lang.Object)var4);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    var8.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var11 = var8.getPlot();
    java.lang.String var12 = var8.getLabel();
    java.awt.Paint var13 = var8.getLabelPaint();
    var4.setLabelPaint(var13);
    boolean var15 = var4.getIgnoreZeroValues();
    org.jfree.chart.labels.PieSectionLabelGenerator var16 = var4.getLabelGenerator();
    boolean var17 = var4.isCircular();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.PaintMap var0 = new org.jfree.chart.PaintMap();
    java.awt.Paint var2 = var0.getPaint((java.lang.Comparable)2.0d);
    java.awt.Paint var4 = var0.getPaint((java.lang.Comparable)1);
    boolean var6 = var0.equals((java.lang.Object)0.0f);
    boolean var8 = var0.containsKey((java.lang.Comparable)"Range[0.0,1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     java.awt.Font var13 = var12.getFont();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("", var13);
//     org.jfree.chart.text.TextFragment var15 = var14.getFirstTextFragment();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.util.Size2D var17 = var14.calculateDimensions(var16);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getText();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    java.awt.Font var8 = var7.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var9.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    java.lang.String var13 = var9.getLabel();
    java.awt.Paint var14 = var9.getLabelPaint();
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
    java.awt.Font var16 = var15.getFont();
    org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
    org.jfree.data.general.WaferMapDataset var18 = null;
    org.jfree.chart.renderer.WaferMapRenderer var19 = null;
    org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
    java.awt.Font var21 = var20.getNoDataMessageFont();
    var20.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
    java.lang.Object var26 = var25.clone();
    var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    var28.setRenderer(0, var32, true);
    var28.setRangeCrosshairVisible(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var38 = null;
    var28.setRenderer(1, var38, true);
    org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
    var43.setMaximumCategoryLabelLines(15);
    var28.setDomainAxis(15, (org.jfree.chart.axis.CategoryAxis)var43);
    org.jfree.data.xy.XYDataset var48 = null;
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis();
    double var50 = var49.getLowerMargin();
    boolean var51 = var49.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var53 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var53.setAutoRangeIncludesZero(true);
    var53.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var58 = null;
    org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot(var48, (org.jfree.chart.axis.ValueAxis)var49, (org.jfree.chart.axis.ValueAxis)var53, var58);
    org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var62 = var61.getLabel();
    var59.addDomainMarker((org.jfree.chart.plot.Marker)var61);
    java.awt.Paint var64 = var61.getOutlinePaint();
    org.jfree.chart.util.Layer var65 = null;
    var28.addRangeMarker(0, (org.jfree.chart.plot.Marker)var61, var65);
    org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle();
    java.lang.String var68 = var67.getText();
    org.jfree.data.general.WaferMapDataset var72 = null;
    org.jfree.chart.renderer.WaferMapRenderer var73 = null;
    org.jfree.chart.plot.WaferMapPlot var74 = new org.jfree.chart.plot.WaferMapPlot(var72, var73);
    java.awt.Font var75 = var74.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var76 = new org.jfree.chart.axis.CategoryAxis();
    var76.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var79 = var76.getPlot();
    java.lang.String var80 = var76.getLabel();
    java.awt.Paint var81 = var76.getLabelPaint();
    org.jfree.chart.text.TextFragment var82 = new org.jfree.chart.text.TextFragment("", var75, var81);
    java.awt.Font var83 = var82.getFont();
    org.jfree.chart.text.TextLine var84 = new org.jfree.chart.text.TextLine("", var83);
    org.jfree.data.general.WaferMapDataset var85 = null;
    org.jfree.chart.renderer.WaferMapRenderer var86 = null;
    org.jfree.chart.plot.WaferMapPlot var87 = new org.jfree.chart.plot.WaferMapPlot(var85, var86);
    java.awt.Font var88 = var87.getNoDataMessageFont();
    var87.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var92 = new org.jfree.chart.JFreeChart("ThreadContext", var83, (org.jfree.chart.plot.Plot)var87, false);
    java.lang.Object var93 = var92.clone();
    var67.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var92);
    java.awt.Stroke var95 = var92.getBorderStroke();
    var92.removeLegend();
    boolean var97 = var61.equals((java.lang.Object)var92);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var25.setTextAntiAlias((java.lang.Object)var97);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + ""+ "'", var68.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     var11.configureRangeAxes();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     double var14 = var13.getLowerMargin();
//     boolean var15 = var13.isTickMarksVisible();
//     var11.setRangeAxis((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.data.general.WaferMapDataset var20 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var21 = null;
//     org.jfree.chart.plot.WaferMapPlot var22 = new org.jfree.chart.plot.WaferMapPlot(var20, var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     var24.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var27 = var24.getPlot();
//     java.lang.String var28 = var24.getLabel();
//     java.awt.Paint var29 = var24.getLabelPaint();
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("", var23, var29);
//     java.awt.Font var31 = var30.getFont();
//     org.jfree.chart.text.TextLine var32 = new org.jfree.chart.text.TextLine("", var31);
//     org.jfree.data.general.WaferMapDataset var33 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var34 = null;
//     org.jfree.chart.plot.WaferMapPlot var35 = new org.jfree.chart.plot.WaferMapPlot(var33, var34);
//     java.awt.Font var36 = var35.getNoDataMessageFont();
//     var35.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("ThreadContext", var31, (org.jfree.chart.plot.Plot)var35, false);
//     java.lang.Object var41 = var40.clone();
//     org.jfree.chart.event.ChartProgressListener var42 = null;
//     var40.removeProgressListener(var42);
//     var40.clearSubtitles();
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
//     org.jfree.chart.event.PlotChangeEvent var46 = null;
//     var40.plotChanged(var46);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    boolean var12 = var11.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    var13.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var16 = var13.getPlot();
    java.lang.String var17 = var13.getLabel();
    java.awt.Paint var18 = var13.getLabelPaint();
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var18);
    var11.setDomainTickBandPaint(var18);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    var11.drawAnnotations(var21, var22, var23);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var27 = null;
    var26.setFixedLegendItems(var27);
    boolean var29 = var26.isRangeCrosshairVisible();
    boolean var30 = var26.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var32 = var26.getDomainAxisLocation(10);
    var11.setRangeAxisLocation(10, var32);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.general.WaferMapDataset var39 = null;
    org.jfree.chart.renderer.WaferMapRenderer var40 = null;
    org.jfree.chart.plot.WaferMapPlot var41 = new org.jfree.chart.plot.WaferMapPlot(var39, var40);
    java.awt.Font var42 = var41.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis();
    var43.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var46 = var43.getPlot();
    java.lang.String var47 = var43.getLabel();
    java.awt.Paint var48 = var43.getLabelPaint();
    org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("", var42, var48);
    java.awt.Font var50 = var49.getFont();
    org.jfree.chart.text.TextLine var51 = new org.jfree.chart.text.TextLine("", var50);
    var36.setLabelFont(var50);
    org.jfree.chart.util.Layer var53 = null;
    var11.addRangeMarker((-253), (org.jfree.chart.plot.Marker)var36, var53);
    org.jfree.chart.util.Layer var55 = null;
    java.util.Collection var56 = var11.getRangeMarkers(var55);
    org.jfree.data.xy.XYDataset var57 = null;
    var11.setDataset(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    boolean var3 = var0.isRangeCrosshairVisible();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.zoomDomainAxes((-13.95d), (-1.0d), var6, var7);
    var0.clearDomainMarkers();
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.plot.ValueMarker var15 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.general.WaferMapDataset var18 = null;
    org.jfree.chart.renderer.WaferMapRenderer var19 = null;
    org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
    java.awt.Font var21 = var20.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    var22.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var25 = var22.getPlot();
    java.lang.String var26 = var22.getLabel();
    java.awt.Paint var27 = var22.getLabelPaint();
    org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("", var21, var27);
    java.awt.Font var29 = var28.getFont();
    org.jfree.chart.text.TextLine var30 = new org.jfree.chart.text.TextLine("", var29);
    var15.setLabelFont(var29);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
    double var34 = var33.getLowerMargin();
    boolean var35 = var33.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var37.setAutoRangeIncludesZero(true);
    var37.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var32, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var37, var42);
    boolean var44 = var43.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
    var45.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var48 = var45.getPlot();
    java.lang.String var49 = var45.getLabel();
    java.awt.Paint var50 = var45.getLabelPaint();
    org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder(var50);
    var43.setDomainTickBandPaint(var50);
    var15.setPaint(var50);
    org.jfree.chart.block.ColumnArrangement var54 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var55 = null;
    org.jfree.chart.plot.PiePlot var56 = new org.jfree.chart.plot.PiePlot();
    var54.add(var55, (java.lang.Object)var56);
    org.jfree.chart.labels.PieSectionLabelGenerator var58 = var56.getLegendLabelGenerator();
    var56.setMinimumArcAngleToDraw(0.05d);
    java.awt.Stroke var61 = var56.getBaseSectionOutlineStroke();
    var15.setStroke(var61);
    var13.setRadiusGridlineStroke(var61);
    org.jfree.data.xy.XYDataset var64 = null;
    var13.setDataset(var64);
    org.jfree.data.xy.XYDataset var66 = null;
    org.jfree.chart.axis.DateAxis var67 = new org.jfree.chart.axis.DateAxis();
    double var68 = var67.getLowerMargin();
    boolean var69 = var67.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var71 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var71.setAutoRangeIncludesZero(true);
    var71.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var76 = null;
    org.jfree.chart.plot.XYPlot var77 = new org.jfree.chart.plot.XYPlot(var66, (org.jfree.chart.axis.ValueAxis)var67, (org.jfree.chart.axis.ValueAxis)var71, var76);
    org.jfree.chart.plot.ValueMarker var79 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var80 = var79.getLabel();
    var77.addDomainMarker((org.jfree.chart.plot.Marker)var79);
    java.awt.Paint var82 = var79.getOutlinePaint();
    var79.setLabel("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    boolean var85 = var13.equals((java.lang.Object)var79);
    org.jfree.chart.util.Layer var86 = null;
    var0.addRangeMarker(100, (org.jfree.chart.plot.Marker)var79, var86);
    org.jfree.chart.annotations.CategoryAnnotation var88 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var88);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     var6.add(var7, (java.lang.Object)var8);
//     var5.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     var5.clear();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     var16.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var19 = var16.getPlot();
//     java.lang.String var20 = var16.getLabel();
//     java.awt.Paint var21 = var16.getLabelPaint();
//     var12.setTickLabelPaint((java.lang.Comparable)(byte)0, var21);
//     var12.setFixedDimension(10.0d);
//     org.jfree.chart.axis.CategoryLabelPositions var25 = var12.getCategoryLabelPositions();
//     boolean var26 = var5.equals((java.lang.Object)var12);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var5.draw(var27, var28);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.renderer.WaferMapRenderer var1 = null;
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot(var0, var1);
    java.awt.Font var3 = var2.getNoDataMessageFont();
    var2.setBackgroundAlpha((-1.0f));
    java.awt.Stroke var6 = null;
    var2.setOutlineStroke(var6);
    java.lang.String var8 = var2.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "WMAP_Plot"+ "'", var8.equals("WMAP_Plot"));

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var2 = null;
//     var0.setRangeAxisLocation(4, var2, false);
//     java.awt.Paint var5 = var0.getDomainGridlinePaint();
//     org.jfree.chart.LegendItemCollection var6 = var0.getLegendItems();
//     var0.clearAnnotations();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     double var10 = var9.getLowerMargin();
//     boolean var11 = var9.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var13.setAutoRangeIncludesZero(true);
//     var13.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var22 = var21.getLabel();
//     var19.addDomainMarker((org.jfree.chart.plot.Marker)var21);
//     java.awt.Paint var24 = var21.getOutlinePaint();
//     java.awt.Stroke var25 = var21.getStroke();
//     boolean var26 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var21);
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(0);
    org.jfree.chart.ui.Licences var2 = new org.jfree.chart.ui.Licences();
    int var3 = var1.indexOf((java.lang.Object)var2);
    java.lang.String var4 = var2.getGPL();
    java.lang.String var5 = var2.getGPL();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     var11.setDomainCrosshairValue(0.0d, true);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     double var19 = var18.getLowerMargin();
//     boolean var20 = var18.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var22.setAutoRangeIncludesZero(true);
//     var22.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     var28.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var30 = var28.getDomainAxisEdge();
//     var28.setRangeCrosshairValue(101.0d, true);
//     var28.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var36 = var28.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var37 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     var11.draw(var15, var16, var36, var37, var38);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     double var6 = var5.getContentYOffset();
//     var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)(-1));
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement(var9, var10, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var14 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var13);
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot();
//     var15.add(var16, (java.lang.Object)var17);
//     var14.setArrangement((org.jfree.chart.block.Arrangement)var15);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.block.RectangleConstraint var23 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
//     org.jfree.chart.block.RectangleConstraint var24 = var23.toUnconstrainedHeight();
//     org.jfree.data.Range var25 = var24.getHeightRange();
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
//     double var27 = var26.getLowerMargin();
//     org.jfree.chart.axis.Timeline var28 = null;
//     var26.setTimeline(var28);
//     java.awt.Shape var30 = var26.getLeftArrow();
//     org.jfree.data.general.WaferMapDataset var32 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var33 = null;
//     org.jfree.chart.plot.WaferMapPlot var34 = new org.jfree.chart.plot.WaferMapPlot(var32, var33);
//     java.awt.Font var35 = var34.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis();
//     var36.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var39 = var36.getPlot();
//     java.lang.String var40 = var36.getLabel();
//     java.awt.Paint var41 = var36.getLabelPaint();
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("", var35, var41);
//     var26.setAxisLinePaint(var41);
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var46 = var45.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var47 = var45.getTickUnit();
//     boolean var48 = var45.isAutoTickUnitSelection();
//     var45.setAutoRangeIncludesZero(true);
//     org.jfree.data.Range var51 = var45.getDefaultAutoRange();
//     var26.setDefaultAutoRange(var51);
//     org.jfree.data.Range var55 = org.jfree.data.Range.shift(var51, 4.0d, false);
//     org.jfree.chart.block.RectangleConstraint var56 = var24.toRangeWidth(var55);
//     org.jfree.chart.util.Size2D var57 = var4.arrange(var14, var20, var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var5 = var2.getDataset();
    org.jfree.chart.labels.PieToolTipGenerator var6 = var2.getToolTipGenerator();
    org.jfree.chart.LegendItemCollection var7 = var2.getLegendItems();
    org.jfree.data.general.WaferMapDataset var10 = null;
    org.jfree.chart.renderer.WaferMapRenderer var11 = null;
    org.jfree.chart.plot.WaferMapPlot var12 = new org.jfree.chart.plot.WaferMapPlot(var10, var11);
    java.awt.Font var13 = var12.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
    var14.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var17 = var14.getPlot();
    java.lang.String var18 = var14.getLabel();
    java.awt.Paint var19 = var14.getLabelPaint();
    org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("", var13, var19);
    java.awt.Font var21 = var20.getFont();
    org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("", var21);
    var2.setLabelFont(var21);
    boolean var24 = var2.getSimpleLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.plot.MultiplePiePlot var0 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    var2.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var5 = var2.getPlot();
    java.lang.String var6 = var2.getLabel();
    java.awt.Paint var7 = var2.getLabelPaint();
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(var7);
    boolean var9 = var0.equals((java.lang.Object)var8);
    org.jfree.chart.util.RectangleInsets var10 = var8.getInsets();
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.text.TextBlock var12 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getLineAlignment();
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var15 = null;
    org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot();
    var14.add(var15, (java.lang.Object)var16);
    org.jfree.chart.labels.PieSectionLabelGenerator var18 = var16.getLegendLabelToolTipGenerator();
    boolean var19 = var13.equals((java.lang.Object)var16);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    var20.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var23 = var20.getPlot();
    java.lang.String var24 = var20.getLabel();
    java.awt.Paint var25 = var20.getLabelPaint();
    var16.setLabelPaint(var25);
    org.jfree.chart.util.Rotation var27 = var16.getDirection();
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
    double var30 = var29.getLowerMargin();
    boolean var31 = var29.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var33.setAutoRangeIncludesZero(true);
    var33.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var33, var38);
    org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var42 = var41.getLabel();
    var39.addDomainMarker((org.jfree.chart.plot.Marker)var41);
    java.awt.Paint var44 = var41.getOutlinePaint();
    java.awt.Stroke var45 = var41.getStroke();
    boolean var46 = var27.equals((java.lang.Object)var41);
    org.jfree.chart.util.LengthAdjustmentType var47 = var41.getLabelOffsetType();
    org.jfree.chart.text.TextBlock var48 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var49 = var48.getLineAlignment();
    org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var51 = null;
    org.jfree.chart.plot.PiePlot var52 = new org.jfree.chart.plot.PiePlot();
    var50.add(var51, (java.lang.Object)var52);
    org.jfree.chart.labels.PieSectionLabelGenerator var54 = var52.getLegendLabelToolTipGenerator();
    boolean var55 = var49.equals((java.lang.Object)var52);
    org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis();
    var56.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var59 = var56.getPlot();
    java.lang.String var60 = var56.getLabel();
    java.awt.Paint var61 = var56.getLabelPaint();
    var52.setLabelPaint(var61);
    org.jfree.chart.util.Rotation var63 = var52.getDirection();
    org.jfree.data.xy.XYDataset var64 = null;
    org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis();
    double var66 = var65.getLowerMargin();
    boolean var67 = var65.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var69.setAutoRangeIncludesZero(true);
    var69.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var74 = null;
    org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot(var64, (org.jfree.chart.axis.ValueAxis)var65, (org.jfree.chart.axis.ValueAxis)var69, var74);
    org.jfree.chart.plot.ValueMarker var77 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var78 = var77.getLabel();
    var75.addDomainMarker((org.jfree.chart.plot.Marker)var77);
    java.awt.Paint var80 = var77.getOutlinePaint();
    java.awt.Stroke var81 = var77.getStroke();
    boolean var82 = var63.equals((java.lang.Object)var77);
    org.jfree.chart.util.LengthAdjustmentType var83 = var77.getLabelOffsetType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var84 = var10.createAdjustedRectangle(var11, var47, var83);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var0.calculateDimensions(var3);
//     
//     // Checks the contract:  equals-hashcode on var2 and var4
//     assertTrue("Contract failed: equals-hashcode on var2 and var4", var2.equals(var4) ? var2.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var2
//     assertTrue("Contract failed: equals-hashcode on var4 and var2", var4.equals(var2) ? var4.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    boolean var2 = var0.isVisible();
    var0.setFixedDimension(1.0d);
    java.util.Date var5 = var0.getMinimumDate();
    double var6 = var0.getFixedDimension();
    org.jfree.chart.StrokeMap var7 = new org.jfree.chart.StrokeMap();
    var7.clear();
    java.awt.Stroke var10 = var7.getStroke((java.lang.Comparable)10L);
    org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getLegendItems();
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    double var14 = var13.getLowerMargin();
    java.util.Date var15 = var13.getMinimumDate();
    var11.setAggregatedItemsKey((java.lang.Comparable)var15);
    java.awt.Stroke var17 = var7.getStroke((java.lang.Comparable)var15);
    var0.setMinimumDate(var15);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    double var20 = var19.getLowerMargin();
    boolean var21 = var19.isVisible();
    org.jfree.chart.axis.Timeline var22 = var19.getTimeline();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
    var23.setToolTipText("");
    boolean var26 = var19.equals((java.lang.Object)var23);
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var19.lengthToJava2D((-1.0d), var28, var29);
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    double var34 = var19.valueToJava2D(0.0d, var32, var33);
    var19.resizeRange((-1.0d));
    org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var38 = null;
    org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot();
    var37.add(var38, (java.lang.Object)var39);
    org.jfree.chart.labels.PieSectionLabelGenerator var41 = var39.getLegendLabelToolTipGenerator();
    org.jfree.data.general.PieDataset var42 = var39.getDataset();
    org.jfree.chart.labels.PieToolTipGenerator var43 = var39.getToolTipGenerator();
    org.jfree.chart.text.TextBlock var44 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.text.TextBlockAnchor var48 = null;
    java.awt.Shape var52 = var44.calculateBounds(var45, 10.0f, 1.0f, var48, 100.0f, (-1.0f), 1.0d);
    var39.setLegendItemShape(var52);
    var19.setRightArrow(var52);
    var0.setRightArrow(var52);
    double var56 = var0.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1.0d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.Timeline var2 = null;
    var0.setTimeline(var2);
    double var4 = var0.getFixedAutoRange();
    java.util.TimeZone var5 = var0.getTimeZone();
    var0.setAutoRange(true);
    var0.setFixedAutoRange(1.0E-8d);
    var0.setAutoTickUnitSelection(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.lang.Object var2 = var1.clone();
//     boolean var3 = var1.getSimpleLabels();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     var6.add(var7, (java.lang.Object)var8);
//     var8.setForegroundAlpha(100.0f);
//     boolean var12 = var8.getIgnoreNullValues();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     org.jfree.chart.plot.PiePlotState var15 = var1.initialise(var4, var5, var8, (java.lang.Integer)255, var14);
//     double var16 = var8.getInteriorGap();
//     org.jfree.chart.StrokeMap var17 = new org.jfree.chart.StrokeMap();
//     var17.clear();
//     java.awt.Stroke var20 = var17.getStroke((java.lang.Comparable)10L);
//     org.jfree.chart.plot.MultiplePiePlot var21 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var22 = var21.getLegendItems();
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     double var24 = var23.getLowerMargin();
//     java.util.Date var25 = var23.getMinimumDate();
//     var21.setAggregatedItemsKey((java.lang.Comparable)var25);
//     java.awt.Stroke var27 = var17.getStroke((java.lang.Comparable)var25);
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var30 = var29.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var31 = var29.getTickUnit();
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
//     double var34 = var33.getLowerMargin();
//     boolean var35 = var33.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var37.setAutoRangeIncludesZero(true);
//     var37.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var32, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var37, var42);
//     org.jfree.data.general.DatasetGroup var44 = var43.getDatasetGroup();
//     var43.setRangeGridlinesVisible(false);
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var48 = null;
//     org.jfree.chart.plot.PiePlot var49 = new org.jfree.chart.plot.PiePlot();
//     var47.add(var48, (java.lang.Object)var49);
//     org.jfree.chart.labels.PieSectionLabelGenerator var51 = var49.getLegendLabelGenerator();
//     var49.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var54 = var49.getBaseSectionOutlineStroke();
//     var43.setDomainCrosshairStroke(var54);
//     var17.put((java.lang.Comparable)var31, var54);
//     var8.setBaseSectionOutlineStroke(var54);
//     
//     // Checks the contract:  equals-hashcode on var6 and var47
//     assertTrue("Contract failed: equals-hashcode on var6 and var47", var6.equals(var47) ? var6.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var6
//     assertTrue("Contract failed: equals-hashcode on var47 and var6", var47.equals(var6) ? var47.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(1.0d);
    double var3 = var0.getCategoryMargin();
    int var4 = var0.getCategoryLabelPositionOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var3 = var2.isInverted();
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     double var5 = var4.getLowerMargin();
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = null;
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var6);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.data.xy.XYDataset var11 = null;
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     double var13 = var12.getLowerMargin();
//     boolean var14 = var12.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var16.setAutoRangeIncludesZero(true);
//     var16.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var11, (org.jfree.chart.axis.ValueAxis)var12, (org.jfree.chart.axis.ValueAxis)var16, var21);
//     var22.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var24 = var22.getDomainAxisEdge();
//     var22.setRangeCrosshairValue(101.0d, true);
//     var22.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var30 = var22.getQuadrantOrigin();
//     var10.setQuadrantOrigin(var30);
//     var7.zoomRangeAxes(10.0d, var9, var30, true);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var2 = var1.isInverted();
    org.jfree.chart.axis.NumberTickUnit var3 = var1.getTickUnit();
    boolean var4 = var1.isAutoTickUnitSelection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(101.0d, 1.0E-5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    java.awt.Color var1 = java.awt.Color.getColor(" version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY :None\n LICENCE TERMS:\n");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAnchor var3 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var0.getCategoryJava2DCoordinate(var3, 100, 1, var6, var7);
    var0.setVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var2 = var1.getLabel();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var4 = null;
//     var3.setFixedLegendItems(var4);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
//     var3.setRenderer(0, var7, true);
//     boolean var10 = var3.getDrawSharedDomainAxis();
//     org.jfree.data.category.CategoryDataset var11 = var3.getDataset();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var13.setAutoRangeIncludesZero(true);
//     var13.setAutoRangeStickyZero(true);
//     var13.setRange(1.0d, 100.0d);
//     org.jfree.data.Range var21 = var3.getDataRange((org.jfree.chart.axis.ValueAxis)var13);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var3);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var24 = null;
//     var23.setFixedLegendItems(var24);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var23.setRenderer(0, var27, true);
//     var23.setRangeCrosshairVisible(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     var23.setRenderer(1, var33, true);
//     org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var38.setMaximumCategoryLabelLines(15);
//     var23.setDomainAxis(15, (org.jfree.chart.axis.CategoryAxis)var38);
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     double var45 = var44.getLowerMargin();
//     boolean var46 = var44.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var48.setAutoRangeIncludesZero(true);
//     var48.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var43, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.axis.ValueAxis)var48, var53);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var57 = var56.getLabel();
//     var54.addDomainMarker((org.jfree.chart.plot.Marker)var56);
//     java.awt.Paint var59 = var56.getOutlinePaint();
//     org.jfree.chart.util.Layer var60 = null;
//     var23.addRangeMarker(0, (org.jfree.chart.plot.Marker)var56, var60);
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var63 = var62.getText();
//     org.jfree.data.general.WaferMapDataset var67 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var68 = null;
//     org.jfree.chart.plot.WaferMapPlot var69 = new org.jfree.chart.plot.WaferMapPlot(var67, var68);
//     java.awt.Font var70 = var69.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis();
//     var71.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var74 = var71.getPlot();
//     java.lang.String var75 = var71.getLabel();
//     java.awt.Paint var76 = var71.getLabelPaint();
//     org.jfree.chart.text.TextFragment var77 = new org.jfree.chart.text.TextFragment("", var70, var76);
//     java.awt.Font var78 = var77.getFont();
//     org.jfree.chart.text.TextLine var79 = new org.jfree.chart.text.TextLine("", var78);
//     org.jfree.data.general.WaferMapDataset var80 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var81 = null;
//     org.jfree.chart.plot.WaferMapPlot var82 = new org.jfree.chart.plot.WaferMapPlot(var80, var81);
//     java.awt.Font var83 = var82.getNoDataMessageFont();
//     var82.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var87 = new org.jfree.chart.JFreeChart("ThreadContext", var78, (org.jfree.chart.plot.Plot)var82, false);
//     java.lang.Object var88 = var87.clone();
//     var62.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var87);
//     java.awt.Stroke var90 = var87.getBorderStroke();
//     var87.removeLegend();
//     boolean var92 = var56.equals((java.lang.Object)var87);
//     org.jfree.chart.text.TextAnchor var93 = var56.getLabelTextAnchor();
//     var1.setLabelTextAnchor(var93);
//     
//     // Checks the contract:  equals-hashcode on var1 and var56
//     assertTrue("Contract failed: equals-hashcode on var1 and var56", var1.equals(var56) ? var1.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var1
//     assertTrue("Contract failed: equals-hashcode on var56 and var1", var56.equals(var1) ? var56.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var23
//     assertTrue("Contract failed: equals-hashcode on var3 and var23", var3.equals(var23) ? var3.hashCode() == var23.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var23.", var3.equals(var23) == var23.equals(var3));
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     double var1 = var0.getContentYOffset();
//     org.jfree.chart.util.HorizontalAlignment var2 = var0.getTextAlignment();
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var4 = var3.getText();
//     org.jfree.data.general.WaferMapDataset var8 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var9 = null;
//     org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
//     java.awt.Font var11 = var10.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var15 = var12.getPlot();
//     java.lang.String var16 = var12.getLabel();
//     java.awt.Paint var17 = var12.getLabelPaint();
//     org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("", var11, var17);
//     java.awt.Font var19 = var18.getFont();
//     org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("", var19);
//     org.jfree.data.general.WaferMapDataset var21 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var22 = null;
//     org.jfree.chart.plot.WaferMapPlot var23 = new org.jfree.chart.plot.WaferMapPlot(var21, var22);
//     java.awt.Font var24 = var23.getNoDataMessageFont();
//     var23.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var28 = new org.jfree.chart.JFreeChart("ThreadContext", var19, (org.jfree.chart.plot.Plot)var23, false);
//     java.lang.Object var29 = var28.clone();
//     var3.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var28);
//     java.awt.Stroke var31 = var28.getBorderStroke();
//     var28.removeLegend();
//     java.lang.Object var33 = null;
//     boolean var34 = var28.equals(var33);
//     boolean var35 = var0.equals((java.lang.Object)var34);
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var43 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var44 = null;
//     org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
//     java.awt.Font var46 = var45.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
//     var47.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var50 = var47.getPlot();
//     java.lang.String var51 = var47.getLabel();
//     java.awt.Paint var52 = var47.getLabelPaint();
//     org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var46, var52);
//     java.awt.Font var54 = var53.getFont();
//     org.jfree.chart.text.TextLine var55 = new org.jfree.chart.text.TextLine("", var54);
//     var40.setLabelFont(var54);
//     org.jfree.data.xy.XYDataset var57 = null;
//     org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
//     double var59 = var58.getLowerMargin();
//     boolean var60 = var58.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var62.setAutoRangeIncludesZero(true);
//     var62.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var67 = null;
//     org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot(var57, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var62, var67);
//     boolean var69 = var68.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis();
//     var70.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var73 = var70.getPlot();
//     java.lang.String var74 = var70.getLabel();
//     java.awt.Paint var75 = var70.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var76 = new org.jfree.chart.block.BlockBorder(var75);
//     var68.setDomainTickBandPaint(var75);
//     var40.setPaint(var75);
//     org.jfree.chart.block.ColumnArrangement var79 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var80 = null;
//     org.jfree.chart.plot.PiePlot var81 = new org.jfree.chart.plot.PiePlot();
//     var79.add(var80, (java.lang.Object)var81);
//     org.jfree.chart.labels.PieSectionLabelGenerator var83 = var81.getLegendLabelGenerator();
//     var81.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var86 = var81.getBaseSectionOutlineStroke();
//     var40.setStroke(var86);
//     var38.setRadiusGridlineStroke(var86);
//     org.jfree.data.xy.XYDataset var89 = null;
//     var38.setDataset(var89);
//     boolean var91 = var38.isAngleGridlinesVisible();
//     org.jfree.chart.axis.DateAxis var92 = new org.jfree.chart.axis.DateAxis();
//     double var93 = var92.getLowerMargin();
//     java.util.Date var94 = var92.getMinimumDate();
//     double var95 = var92.getFixedDimension();
//     org.jfree.data.Range var96 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var92);
//     java.awt.Stroke var97 = var38.getRadiusGridlineStroke();
//     java.lang.Object var98 = var0.draw(var36, var37, (java.lang.Object)var97);
//     
//     // Checks the contract:  equals-hashcode on var10 and var45
//     assertTrue("Contract failed: equals-hashcode on var10 and var45", var10.equals(var45) ? var10.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var10
//     assertTrue("Contract failed: equals-hashcode on var45 and var10", var45.equals(var10) ? var45.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.CategoryLabelPositions var2 = var1.getCategoryLabelPositions();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    double var4 = var3.getLowerMargin();
    java.util.Date var5 = var3.getMinimumDate();
    org.jfree.chart.axis.DateTickUnit var6 = null;
    var3.setTickUnit(var6, false, true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var10);
    var3.setAxisLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    var23.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.title.TextTitle var26 = var23.getTitle();
    org.jfree.chart.util.RectangleInsets var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.setPadding(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     var2.setLabelFont(var16);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     double var21 = var20.getLowerMargin();
//     boolean var22 = var20.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var24.setAutoRangeIncludesZero(true);
//     var24.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     boolean var31 = var30.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var35 = var32.getPlot();
//     java.lang.String var36 = var32.getLabel();
//     java.awt.Paint var37 = var32.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var37);
//     var30.setDomainTickBandPaint(var37);
//     var2.setPaint(var37);
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot();
//     var41.add(var42, (java.lang.Object)var43);
//     org.jfree.chart.labels.PieSectionLabelGenerator var45 = var43.getLegendLabelGenerator();
//     var43.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var48 = var43.getBaseSectionOutlineStroke();
//     var2.setStroke(var48);
//     var0.setRadiusGridlineStroke(var48);
//     org.jfree.data.xy.XYDataset var51 = null;
//     var0.setDataset(var51);
//     boolean var53 = var0.isAngleGridlinesVisible();
//     org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis();
//     double var55 = var54.getLowerMargin();
//     java.util.Date var56 = var54.getMinimumDate();
//     double var57 = var54.getFixedDimension();
//     org.jfree.data.Range var58 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var54);
//     org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis();
//     double var60 = var59.getLowerMargin();
//     boolean var61 = var59.isVisible();
//     org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
//     double var63 = var62.getLowerMargin();
//     org.jfree.chart.axis.Timeline var64 = null;
//     var62.setTimeline(var64);
//     java.awt.Shape var66 = var62.getLeftArrow();
//     var59.setLeftArrow(var66);
//     java.util.Date var68 = var59.getMaximumDate();
//     java.awt.geom.Rectangle2D var69 = null;
//     org.jfree.data.xy.XYDataset var70 = null;
//     org.jfree.chart.axis.DateAxis var71 = new org.jfree.chart.axis.DateAxis();
//     double var72 = var71.getLowerMargin();
//     boolean var73 = var71.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var75.setAutoRangeIncludesZero(true);
//     var75.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var80 = null;
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot(var70, (org.jfree.chart.axis.ValueAxis)var71, (org.jfree.chart.axis.ValueAxis)var75, var80);
//     var81.configureRangeAxes();
//     org.jfree.chart.axis.AxisSpace var83 = null;
//     var81.setFixedDomainAxisSpace(var83);
//     org.jfree.data.general.DatasetChangeEvent var85 = null;
//     var81.datasetChanged(var85);
//     org.jfree.chart.util.RectangleEdge var88 = var81.getRangeAxisEdge(0);
//     double var89 = var54.dateToJava2D(var68, var69, var88);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);
    double var2 = var1.getLatestAngle();
    java.awt.geom.Rectangle2D var3 = var1.getLinkArea();
    double var4 = var1.getPieCenterX();
    java.awt.geom.Rectangle2D var5 = var1.getExplodedPieArea();
    double var6 = var1.getTotal();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var18 = var17.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
//     boolean var20 = var17.isAutoTickUnitSelection();
//     var17.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
//     var11.setRangeAxes(var23);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.text.TextBlock var27 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.util.Size2D var29 = var27.calculateDimensions(var28);
//     java.util.List var30 = var27.getLines();
//     var11.drawDomainTickBands(var25, var26, var30);
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = var11.getRendererForDataset(var32);
//     var11.setDomainCrosshairVisible(false);
//     java.awt.Graphics2D var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     double var40 = var39.getLowerMargin();
//     boolean var41 = var39.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var43.setAutoRangeIncludesZero(true);
//     var43.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var43, var48);
//     var49.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var51 = var49.getDomainAxisEdge();
//     var49.setRangeCrosshairValue(101.0d, true);
//     var49.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var57 = var49.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var58 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     var11.draw(var36, var37, var57, var58, var59);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.lang.String var1 = var0.getText();
    org.jfree.data.general.WaferMapDataset var5 = null;
    org.jfree.chart.renderer.WaferMapRenderer var6 = null;
    org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
    java.awt.Font var8 = var7.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var9.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var12 = var9.getPlot();
    java.lang.String var13 = var9.getLabel();
    java.awt.Paint var14 = var9.getLabelPaint();
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
    java.awt.Font var16 = var15.getFont();
    org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
    org.jfree.data.general.WaferMapDataset var18 = null;
    org.jfree.chart.renderer.WaferMapRenderer var19 = null;
    org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
    java.awt.Font var21 = var20.getNoDataMessageFont();
    var20.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
    java.lang.Object var26 = var25.clone();
    var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
    java.awt.Stroke var28 = var25.getBorderStroke();
    var25.removeLegend();
    var25.setBorderVisible(false);
    java.awt.RenderingHints var32 = var25.getRenderingHints();
    org.jfree.chart.title.LegendTitle var34 = var25.getLegend(0);
    org.jfree.chart.plot.Plot var35 = var25.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var36 = var25.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var2 = var1.getLabel();
//     java.awt.Stroke var3 = var1.getStroke();
//     org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var5 = var4.getLineAlignment();
//     org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot();
//     var6.add(var7, (java.lang.Object)var8);
//     org.jfree.chart.labels.PieSectionLabelGenerator var10 = var8.getLegendLabelToolTipGenerator();
//     boolean var11 = var5.equals((java.lang.Object)var8);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var15 = var12.getPlot();
//     java.lang.String var16 = var12.getLabel();
//     java.awt.Paint var17 = var12.getLabelPaint();
//     var8.setLabelPaint(var17);
//     org.jfree.chart.util.Rotation var19 = var8.getDirection();
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
//     double var22 = var21.getLowerMargin();
//     boolean var23 = var21.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var25.setAutoRangeIncludesZero(true);
//     var25.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var34 = var33.getLabel();
//     var31.addDomainMarker((org.jfree.chart.plot.Marker)var33);
//     java.awt.Paint var36 = var33.getOutlinePaint();
//     java.awt.Stroke var37 = var33.getStroke();
//     boolean var38 = var19.equals((java.lang.Object)var33);
//     org.jfree.chart.util.LengthAdjustmentType var39 = var33.getLabelOffsetType();
//     var1.setLabelOffsetType(var39);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.StrokeMap var0 = new org.jfree.chart.StrokeMap();
    var0.clear();
    java.awt.Stroke var3 = var0.getStroke((java.lang.Comparable)10L);
    org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    double var7 = var6.getLowerMargin();
    java.util.Date var8 = var6.getMinimumDate();
    var4.setAggregatedItemsKey((java.lang.Comparable)var8);
    java.awt.Stroke var10 = var0.getStroke((java.lang.Comparable)var8);
    java.awt.Stroke var12 = var0.getStroke((java.lang.Comparable)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, 1.0d, 1.0d);
    double var6 = var4.extendWidth(100.0d);
    double var8 = var4.calculateTopOutset(101.0d);
    double var10 = var4.calculateLeftInset(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 101.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    var0.setAngleLabelsVisible(false);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var4.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var7 = var4.getPlot();
//     java.lang.String var8 = var4.getLabel();
//     java.awt.Paint var9 = var4.getLabelPaint();
//     var0.setTickLabelPaint((java.lang.Comparable)(byte)0, var9);
//     var0.addCategoryLabelToolTip((java.lang.Comparable)(-1.0f), "");
//     boolean var14 = var0.isAxisLineVisible();
//     float var15 = var0.getMaximumCategoryLabelWidthRatio();
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     double var21 = var20.getLowerMargin();
//     boolean var22 = var20.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var24.setAutoRangeIncludesZero(true);
//     var24.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     boolean var31 = var30.isDomainZeroBaselineVisible();
//     java.awt.Paint var32 = var30.getRangeZeroBaselinePaint();
//     var30.clearDomainMarkers(255);
//     int var35 = var30.getWeight();
//     org.jfree.chart.util.RectangleEdge var37 = var30.getRangeAxisEdge(100);
//     double var38 = var0.getCategoryMiddle(15, 255, var18, var37);
// 
//   }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     var4.setRenderer(0, var8, true);
//     var4.setRangeCrosshairVisible(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var4.setRenderer(1, var14, true);
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var19.setMaximumCategoryLabelLines(15);
//     var4.setDomainAxis(15, (org.jfree.chart.axis.CategoryAxis)var19);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     double var26 = var25.getLowerMargin();
//     boolean var27 = var25.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var29.setAutoRangeIncludesZero(true);
//     var29.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var34);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var38 = var37.getLabel();
//     var35.addDomainMarker((org.jfree.chart.plot.Marker)var37);
//     java.awt.Paint var40 = var37.getOutlinePaint();
//     org.jfree.chart.util.Layer var41 = null;
//     var4.addRangeMarker(0, (org.jfree.chart.plot.Marker)var37, var41);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var44 = var43.getText();
//     org.jfree.data.general.WaferMapDataset var48 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var49 = null;
//     org.jfree.chart.plot.WaferMapPlot var50 = new org.jfree.chart.plot.WaferMapPlot(var48, var49);
//     java.awt.Font var51 = var50.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
//     var52.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var55 = var52.getPlot();
//     java.lang.String var56 = var52.getLabel();
//     java.awt.Paint var57 = var52.getLabelPaint();
//     org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var51, var57);
//     java.awt.Font var59 = var58.getFont();
//     org.jfree.chart.text.TextLine var60 = new org.jfree.chart.text.TextLine("", var59);
//     org.jfree.data.general.WaferMapDataset var61 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var62 = null;
//     org.jfree.chart.plot.WaferMapPlot var63 = new org.jfree.chart.plot.WaferMapPlot(var61, var62);
//     java.awt.Font var64 = var63.getNoDataMessageFont();
//     var63.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart("ThreadContext", var59, (org.jfree.chart.plot.Plot)var63, false);
//     java.lang.Object var69 = var68.clone();
//     var43.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var68);
//     java.awt.Stroke var71 = var68.getBorderStroke();
//     var68.removeLegend();
//     boolean var73 = var37.equals((java.lang.Object)var68);
//     org.jfree.chart.text.TextAnchor var74 = var37.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var75 = org.jfree.chart.text.TextUtilities.drawAlignedString("WMAP_Plot", var1, 2.0f, 0.8f, var74);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.ui.Contributor var3 = new org.jfree.chart.ui.Contributor("", "");
    java.lang.String var4 = var3.getName();
    boolean var5 = var0.equals((java.lang.Object)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     var0.setRenderer(0, var4, true);
//     boolean var7 = var0.getDrawSharedDomainAxis();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     double var10 = var9.getLowerMargin();
//     boolean var11 = var9.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var13.setAutoRangeIncludesZero(true);
//     var13.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     var19.configureRangeAxes();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
//     java.lang.Object var23 = var22.clone();
//     var22.setSectionDepth(0.0d);
//     var22.setInnerSeparatorExtension(100.0d);
//     double var28 = var22.getSectionDepth();
//     org.jfree.data.general.WaferMapDataset var30 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var31 = null;
//     org.jfree.chart.plot.WaferMapPlot var32 = new org.jfree.chart.plot.WaferMapPlot(var30, var31);
//     java.awt.Font var33 = var32.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis();
//     var34.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var37 = var34.getPlot();
//     java.lang.String var38 = var34.getLabel();
//     java.awt.Paint var39 = var34.getLabelPaint();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var33, var39);
//     var22.setLabelShadowPaint(var39);
//     var19.setRangeZeroBaselinePaint(var39);
//     var0.setDomainGridlinePaint(var39);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var0.handleClick(100, 4, var46);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.ChartColor var4 = new org.jfree.chart.ChartColor(1, 0, 0);
//     java.awt.image.ColorModel var5 = null;
//     java.awt.Rectangle var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.AffineTransform var8 = null;
//     java.awt.RenderingHints var9 = null;
//     java.awt.PaintContext var10 = var4.createContext(var5, var6, var7, var8, var9);
//     java.awt.Color var11 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var4);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     double var13 = var12.getLowerMargin();
//     java.util.Date var14 = var12.getMinimumDate();
//     double var15 = var12.getFixedDimension();
//     org.jfree.chart.text.TextBlock var16 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getLineAlignment();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.text.TextBlockAnchor var21 = null;
//     java.awt.Shape var25 = var16.calculateBounds(var18, (-1.0f), 100.0f, var21, (-1.0f), 1.0f, 0.0d);
//     org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity(var25);
//     var12.setRightArrow(var25);
//     boolean var28 = var11.equals((java.lang.Object)var25);
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.entity.PieSectionEntity var35 = new org.jfree.chart.entity.PieSectionEntity(var25, var29, (-1), (-1), (java.lang.Comparable)1.0f, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!");
//     var35.setPieIndex(10);
//     int var38 = var35.getPieIndex();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var39 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var40 = null;
//     java.lang.String var41 = var35.getImageMapAreaTag(var39, var40);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, 100.0d);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelGenerator();
//     boolean var5 = var2.getIgnoreZeroValues();
//     boolean var6 = var2.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     double var9 = var8.getLowerMargin();
//     org.jfree.chart.axis.Timeline var10 = null;
//     var8.setTimeline(var10);
//     java.awt.Shape var12 = var8.getLeftArrow();
//     org.jfree.data.general.WaferMapDataset var14 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var15 = null;
//     org.jfree.chart.plot.WaferMapPlot var16 = new org.jfree.chart.plot.WaferMapPlot(var14, var15);
//     java.awt.Font var17 = var16.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     var18.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var21 = var18.getPlot();
//     java.lang.String var22 = var18.getLabel();
//     java.awt.Paint var23 = var18.getLabelPaint();
//     org.jfree.chart.text.TextFragment var24 = new org.jfree.chart.text.TextFragment("", var17, var23);
//     var8.setAxisLinePaint(var23);
//     var2.setSectionOutlinePaint((java.lang.Comparable)'#', var23);
//     org.jfree.chart.event.MarkerChangeEvent var27 = null;
//     var2.markerChanged(var27);
//     java.awt.Color var32 = java.awt.Color.getColor("XY Plot", (-1));
//     org.jfree.data.general.WaferMapDataset var35 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var36 = null;
//     org.jfree.chart.plot.WaferMapPlot var37 = new org.jfree.chart.plot.WaferMapPlot(var35, var36);
//     java.awt.Font var38 = var37.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     var39.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var42 = var39.getPlot();
//     java.lang.String var43 = var39.getLabel();
//     java.awt.Paint var44 = var39.getLabelPaint();
//     org.jfree.chart.text.TextFragment var45 = new org.jfree.chart.text.TextFragment("", var38, var44);
//     java.awt.Font var46 = var45.getFont();
//     org.jfree.chart.text.TextLine var47 = new org.jfree.chart.text.TextLine("", var46);
//     org.jfree.chart.text.TextFragment var48 = var47.getFirstTextFragment();
//     org.jfree.chart.text.TextFragment var49 = var47.getFirstTextFragment();
//     boolean var50 = var32.equals((java.lang.Object)var49);
//     java.awt.Color var53 = java.awt.Color.getColor("XY Plot", (-1));
//     java.awt.color.ColorSpace var54 = var53.getColorSpace();
//     float[] var61 = new float[] { 100.0f, 10.0f, 10.0f};
//     float[] var62 = java.awt.Color.RGBtoHSB((-253), (-1), 100, var61);
//     float[] var63 = var32.getColorComponents(var54, var61);
//     var2.setSectionPaint((java.lang.Comparable)1L, (java.awt.Paint)var32);
//     
//     // Checks the contract:  equals-hashcode on var16 and var37
//     assertTrue("Contract failed: equals-hashcode on var16 and var37", var16.equals(var37) ? var16.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var16
//     assertTrue("Contract failed: equals-hashcode on var37 and var16", var37.equals(var16) ? var37.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    boolean var2 = var0.isVisible();
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    double var4 = var3.getLowerMargin();
    org.jfree.chart.axis.Timeline var5 = null;
    var3.setTimeline(var5);
    java.awt.Shape var7 = var3.getLeftArrow();
    var0.setLeftArrow(var7);
    java.util.Date var9 = var0.getMaximumDate();
    boolean var10 = var0.isAutoRange();
    java.awt.Font var11 = var0.getTickLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    org.jfree.chart.LegendItemCollection var6 = var0.getLegendItems();
    var0.clearRangeMarkers();
    org.jfree.chart.plot.CategoryMarker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var3 = var2.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var4 = var2.getTickUnit();
//     boolean var5 = var2.isAutoTickUnitSelection();
//     var2.setAutoRangeIncludesZero(true);
//     org.jfree.data.Range var8 = var2.getDefaultAutoRange();
//     double var9 = var8.getCentralValue();
//     java.lang.String var10 = var8.toString();
//     org.jfree.chart.block.RectangleConstraint var13 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
//     org.jfree.chart.util.Size2D var14 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var15 = var13.calculateConstrainedSize(var14);
//     double var16 = var13.getHeight();
//     org.jfree.chart.block.LengthConstraintType var17 = var13.getWidthConstraintType();
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     double var20 = var19.getLowerMargin();
//     org.jfree.chart.axis.Timeline var21 = null;
//     var19.setTimeline(var21);
//     java.awt.Shape var23 = var19.getLeftArrow();
//     org.jfree.data.general.WaferMapDataset var25 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var26 = null;
//     org.jfree.chart.plot.WaferMapPlot var27 = new org.jfree.chart.plot.WaferMapPlot(var25, var26);
//     java.awt.Font var28 = var27.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
//     var29.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var32 = var29.getPlot();
//     java.lang.String var33 = var29.getLabel();
//     java.awt.Paint var34 = var29.getLabelPaint();
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("", var28, var34);
//     var19.setAxisLinePaint(var34);
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var39 = var38.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var40 = var38.getTickUnit();
//     boolean var41 = var38.isAutoTickUnitSelection();
//     var38.setAutoRangeIncludesZero(true);
//     org.jfree.data.Range var44 = var38.getDefaultAutoRange();
//     var19.setDefaultAutoRange(var44);
//     org.jfree.data.Range var48 = org.jfree.data.Range.shift(var44, 4.0d, false);
//     org.jfree.data.Range var50 = org.jfree.data.Range.expandToInclude(var44, 2.0d);
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
//     org.jfree.chart.util.Size2D var54 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var55 = var53.calculateConstrainedSize(var54);
//     double var56 = var53.getHeight();
//     org.jfree.chart.block.LengthConstraintType var57 = var53.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var58 = new org.jfree.chart.block.RectangleConstraint(2.05d, var8, var17, 0.2d, var44, var57);
//     
//     // Checks the contract:  equals-hashcode on var14 and var54
//     assertTrue("Contract failed: equals-hashcode on var14 and var54", var14.equals(var54) ? var14.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var55
//     assertTrue("Contract failed: equals-hashcode on var15 and var55", var15.equals(var55) ? var15.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var14
//     assertTrue("Contract failed: equals-hashcode on var54 and var14", var54.equals(var14) ? var54.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var15
//     assertTrue("Contract failed: equals-hashcode on var55 and var15", var55.equals(var15) ? var55.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var1 = var0.getText();
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     org.jfree.data.general.WaferMapDataset var18 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var19 = null;
//     org.jfree.chart.plot.WaferMapPlot var20 = new org.jfree.chart.plot.WaferMapPlot(var18, var19);
//     java.awt.Font var21 = var20.getNoDataMessageFont();
//     var20.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var25 = new org.jfree.chart.JFreeChart("ThreadContext", var16, (org.jfree.chart.plot.Plot)var20, false);
//     java.lang.Object var26 = var25.clone();
//     var0.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var25);
//     java.awt.Stroke var28 = var25.getBorderStroke();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var30 = var29.getText();
//     org.jfree.data.general.WaferMapDataset var34 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var35 = null;
//     org.jfree.chart.plot.WaferMapPlot var36 = new org.jfree.chart.plot.WaferMapPlot(var34, var35);
//     java.awt.Font var37 = var36.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
//     var38.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var41 = var38.getPlot();
//     java.lang.String var42 = var38.getLabel();
//     java.awt.Paint var43 = var38.getLabelPaint();
//     org.jfree.chart.text.TextFragment var44 = new org.jfree.chart.text.TextFragment("", var37, var43);
//     java.awt.Font var45 = var44.getFont();
//     org.jfree.chart.text.TextLine var46 = new org.jfree.chart.text.TextLine("", var45);
//     org.jfree.data.general.WaferMapDataset var47 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var48 = null;
//     org.jfree.chart.plot.WaferMapPlot var49 = new org.jfree.chart.plot.WaferMapPlot(var47, var48);
//     java.awt.Font var50 = var49.getNoDataMessageFont();
//     var49.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("ThreadContext", var45, (org.jfree.chart.plot.Plot)var49, false);
//     java.lang.Object var55 = var54.clone();
//     var29.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var54);
//     java.awt.Stroke var57 = var54.getBorderStroke();
//     var54.removeLegend();
//     var54.setBorderVisible(false);
//     java.awt.RenderingHints var61 = var54.getRenderingHints();
//     var25.setRenderingHints(var61);
//     
//     // Checks the contract:  equals-hashcode on var7 and var36
//     assertTrue("Contract failed: equals-hashcode on var7 and var36", var7.equals(var36) ? var7.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var49
//     assertTrue("Contract failed: equals-hashcode on var20 and var49", var20.equals(var49) ? var20.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var7
//     assertTrue("Contract failed: equals-hashcode on var36 and var7", var36.equals(var7) ? var36.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var20
//     assertTrue("Contract failed: equals-hashcode on var49 and var20", var49.equals(var20) ? var49.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var54
//     assertTrue("Contract failed: equals-hashcode on var25 and var54", var25.equals(var54) ? var25.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var25
//     assertTrue("Contract failed: equals-hashcode on var54 and var25", var54.equals(var25) ? var54.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var55
//     assertTrue("Contract failed: equals-hashcode on var26 and var55", var26.equals(var55) ? var26.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var26
//     assertTrue("Contract failed: equals-hashcode on var55 and var26", var55.equals(var26) ? var55.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     org.jfree.chart.axis.Timeline var3 = null;
//     var1.setTimeline(var3);
//     double var5 = var1.getFixedAutoRange();
//     java.util.TimeZone var6 = var1.getTimeZone();
//     var1.setAutoRange(true);
//     org.jfree.data.Range var9 = var1.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
//     org.jfree.chart.util.Size2D var13 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var14 = var12.calculateConstrainedSize(var13);
//     double var15 = var12.getHeight();
//     org.jfree.chart.block.LengthConstraintType var16 = var12.getWidthConstraintType();
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     double var19 = var18.getLowerMargin();
//     org.jfree.chart.axis.Timeline var20 = null;
//     var18.setTimeline(var20);
//     java.awt.Shape var22 = var18.getLeftArrow();
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     double var24 = var23.getLowerMargin();
//     java.util.Date var25 = var23.getMinimumDate();
//     double var26 = var23.getLowerBound();
//     double var27 = var23.getLowerBound();
//     org.jfree.data.Range var28 = var23.getRange();
//     var18.setRange(var28);
//     org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(0.0d, 10.0d);
//     org.jfree.chart.util.Size2D var33 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var34 = var32.calculateConstrainedSize(var33);
//     double var35 = var32.getHeight();
//     org.jfree.chart.block.LengthConstraintType var36 = var32.getWidthConstraintType();
//     java.lang.String var37 = var36.toString();
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(2.05d, var9, var16, 0.2d, var28, var36);
//     
//     // Checks the contract:  equals-hashcode on var13 and var33
//     assertTrue("Contract failed: equals-hashcode on var13 and var33", var13.equals(var33) ? var13.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var34
//     assertTrue("Contract failed: equals-hashcode on var14 and var34", var14.equals(var34) ? var14.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var13
//     assertTrue("Contract failed: equals-hashcode on var33 and var13", var33.equals(var13) ? var33.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var14
//     assertTrue("Contract failed: equals-hashcode on var34 and var14", var34.equals(var14) ? var34.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    var1.distributeLabels(2.0d, 1.0d);
    org.jfree.chart.plot.PieLabelRecord var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(0, var4, true);
    org.jfree.chart.axis.CategoryAxis var8 = var0.getDomainAxis(15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var10, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(0.0d, var4, var5);
    org.jfree.data.category.CategoryDataset var8 = null;
    var0.setDataset(100, var8);
    org.jfree.chart.util.Layer var11 = null;
    java.util.Collection var12 = var0.getDomainMarkers(0, var11);
    boolean var13 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)"RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     var0.setToolTipText("");
//     var0.setWidth(0.05d);
//     double var5 = var0.getWidth();
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     var8.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var11 = var8.getPlot();
//     java.lang.String var12 = var8.getLabel();
//     java.awt.Paint var13 = var8.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder(var13);
//     boolean var15 = var6.equals((java.lang.Object)var14);
//     var0.setFrame((org.jfree.chart.block.BlockFrame)var14);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var14.draw(var17, var18);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "", var3, "", "ThreadContext", "");
    var7.setVersion("hi!");

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     boolean var3 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     var0.zoomDomainAxes((-13.95d), (-1.0d), var6, var7);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var10 = null;
//     var9.setFixedLegendItems(var10);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     var9.setRenderer(0, var13, true);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     double var19 = var18.getLowerMargin();
//     boolean var20 = var18.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var22.setAutoRangeIncludesZero(true);
//     var22.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     var28.configureRangeAxes();
//     java.awt.Graphics2D var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     org.jfree.chart.plot.CrosshairState var34 = null;
//     boolean var35 = var28.render(var30, var31, 0, var33, var34);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var40 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var41 = null;
//     org.jfree.chart.plot.WaferMapPlot var42 = new org.jfree.chart.plot.WaferMapPlot(var40, var41);
//     java.awt.Font var43 = var42.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
//     var44.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var47 = var44.getPlot();
//     java.lang.String var48 = var44.getLabel();
//     java.awt.Paint var49 = var44.getLabelPaint();
//     org.jfree.chart.text.TextFragment var50 = new org.jfree.chart.text.TextFragment("", var43, var49);
//     java.awt.Font var51 = var50.getFont();
//     org.jfree.chart.text.TextLine var52 = new org.jfree.chart.text.TextLine("", var51);
//     var37.setLabelFont(var51);
//     org.jfree.data.xy.XYDataset var54 = null;
//     org.jfree.chart.axis.DateAxis var55 = new org.jfree.chart.axis.DateAxis();
//     double var56 = var55.getLowerMargin();
//     boolean var57 = var55.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var59 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var59.setAutoRangeIncludesZero(true);
//     var59.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var64 = null;
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot(var54, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.chart.axis.ValueAxis)var59, var64);
//     boolean var66 = var65.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis();
//     var67.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var70 = var67.getPlot();
//     java.lang.String var71 = var67.getLabel();
//     java.awt.Paint var72 = var67.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var73 = new org.jfree.chart.block.BlockBorder(var72);
//     var65.setDomainTickBandPaint(var72);
//     var37.setPaint(var72);
//     var28.addRangeMarker((org.jfree.chart.plot.Marker)var37);
//     org.jfree.chart.util.Layer var77 = null;
//     var9.addRangeMarker(0, (org.jfree.chart.plot.Marker)var37, var77);
//     org.jfree.chart.util.RectangleEdge var80 = var9.getDomainAxisEdge((-1));
//     java.awt.Stroke var81 = var9.getRangeCrosshairStroke();
//     org.jfree.chart.plot.CategoryPlot var82 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisLocation var84 = null;
//     var82.setRangeAxisLocation(4, var84, false);
//     java.awt.Paint var87 = var82.getDomainGridlinePaint();
//     var82.setWeight(1);
//     org.jfree.chart.axis.NumberAxis var91 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var91.setAutoRangeIncludesZero(true);
//     var91.setAutoRangeStickyZero(true);
//     org.jfree.chart.axis.ValueAxis[] var96 = new org.jfree.chart.axis.ValueAxis[] { var91};
//     var82.setRangeAxes(var96);
//     var9.setRangeAxes(var96);
//     var0.setRangeAxes(var96);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(0, var4, true);
    org.jfree.chart.axis.CategoryAxis var8 = var0.getDomainAxis(15);
    org.jfree.chart.plot.CategoryMarker var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var3 = var0.getPlot();
//     java.lang.String var4 = var0.getLabel();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
//     double var11 = var10.getLowerMargin();
//     boolean var12 = var10.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var14.setAutoRangeIncludesZero(true);
//     var14.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var19);
//     var20.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var22 = var20.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var23 = org.jfree.chart.util.RectangleEdge.opposite(var22);
//     org.jfree.chart.util.RectangleEdge var24 = org.jfree.chart.util.RectangleEdge.opposite(var23);
//     org.jfree.chart.util.RectangleEdge var25 = org.jfree.chart.util.RectangleEdge.opposite(var23);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.chart.axis.AxisState var27 = var0.draw(var5, 0.05d, var7, var8, var23, var26);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    var0.zoomRangeAxes(0.0d, var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    double var11 = var10.getLowerMargin();
    boolean var12 = var10.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var14.setAutoRangeIncludesZero(true);
    var14.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var14, var19);
    var20.configureRangeAxes();
    org.jfree.chart.util.RectangleEdge var22 = var20.getDomainAxisEdge();
    var20.setRangeCrosshairValue(101.0d, true);
    var20.setForegroundAlpha(0.0f);
    java.awt.geom.Point2D var28 = var20.getQuadrantOrigin();
    var0.zoomRangeAxes(4.0d, var8, var28, false);
    org.jfree.chart.LegendItemCollection var31 = var0.getLegendItems();
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var0.getRangeMarkers(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     boolean var3 = var0.isRangeCrosshairVisible();
//     org.jfree.data.general.WaferMapDataset var7 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var8 = null;
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var7, var8);
//     java.awt.Font var10 = var9.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     var11.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var14 = var11.getPlot();
//     java.lang.String var15 = var11.getLabel();
//     java.awt.Paint var16 = var11.getLabelPaint();
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var10, var16);
//     java.awt.Font var18 = var17.getFont();
//     org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("", var18);
//     org.jfree.data.general.WaferMapDataset var20 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var21 = null;
//     org.jfree.chart.plot.WaferMapPlot var22 = new org.jfree.chart.plot.WaferMapPlot(var20, var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     var22.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("ThreadContext", var18, (org.jfree.chart.plot.Plot)var22, false);
//     java.awt.Image var28 = var27.getBackgroundImage();
//     int var29 = var27.getBackgroundImageAlignment();
//     org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var27);
//     java.lang.String var31 = var30.toString();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var33 = var32.getText();
//     org.jfree.data.general.WaferMapDataset var37 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var38 = null;
//     org.jfree.chart.plot.WaferMapPlot var39 = new org.jfree.chart.plot.WaferMapPlot(var37, var38);
//     java.awt.Font var40 = var39.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     var41.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var44 = var41.getPlot();
//     java.lang.String var45 = var41.getLabel();
//     java.awt.Paint var46 = var41.getLabelPaint();
//     org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("", var40, var46);
//     java.awt.Font var48 = var47.getFont();
//     org.jfree.chart.text.TextLine var49 = new org.jfree.chart.text.TextLine("", var48);
//     org.jfree.data.general.WaferMapDataset var50 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var51 = null;
//     org.jfree.chart.plot.WaferMapPlot var52 = new org.jfree.chart.plot.WaferMapPlot(var50, var51);
//     java.awt.Font var53 = var52.getNoDataMessageFont();
//     var52.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart("ThreadContext", var48, (org.jfree.chart.plot.Plot)var52, false);
//     java.lang.Object var58 = var57.clone();
//     var32.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var57);
//     java.awt.Stroke var60 = var57.getBorderStroke();
//     var57.removeLegend();
//     var30.setChart(var57);
//     
//     // Checks the contract:  equals-hashcode on var9 and var39
//     assertTrue("Contract failed: equals-hashcode on var9 and var39", var9.equals(var39) ? var9.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var52
//     assertTrue("Contract failed: equals-hashcode on var22 and var52", var22.equals(var52) ? var22.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var9
//     assertTrue("Contract failed: equals-hashcode on var39 and var9", var39.equals(var9) ? var39.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var22
//     assertTrue("Contract failed: equals-hashcode on var52 and var22", var52.equals(var22) ? var52.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var57
//     assertTrue("Contract failed: equals-hashcode on var27 and var57", var27.equals(var57) ? var27.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var27
//     assertTrue("Contract failed: equals-hashcode on var57 and var27", var57.equals(var27) ? var57.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 0, 255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     boolean var2 = var0.isVisible();
//     var0.setFixedDimension(1.0d);
//     java.util.Date var5 = var0.getMinimumDate();
//     boolean var6 = var0.isNegativeArrowVisible();
//     org.jfree.chart.axis.DateTickUnit var7 = null;
//     java.util.Date var8 = var0.calculateHighestVisibleTickValue(var7);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.lang.Object var24 = var23.clone();
    org.jfree.chart.event.ChartProgressListener var25 = null;
    var23.removeProgressListener(var25);
    boolean var27 = var23.isBorderVisible();
    var23.clearSubtitles();
    org.jfree.chart.title.LegendTitle var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.addLegend(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAnchor var3 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var0.getCategoryJava2DCoordinate(var3, 100, 1, var6, var7);
    var0.clearCategoryLabelToolTips();
    java.awt.Font var11 = var0.getTickLabelFont((java.lang.Comparable)15);
    var0.removeCategoryLabelToolTip((java.lang.Comparable)"WMAP_Plot");
    org.jfree.chart.axis.CategoryLabelPositions var14 = var0.getCategoryLabelPositions();
    var0.setLowerMargin(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    var2.setHeight(2.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.Timeline var2 = null;
    var0.setTimeline(var2);
    var0.setAutoTickUnitSelection(false, false);
    var0.setRangeAboutValue(2.0d, 101.0d);
    var0.setNegativeArrowVisible(true);
    var0.setAxisLineVisible(false);
    double var14 = var0.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var8 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var9 = null;
//     org.jfree.chart.plot.WaferMapPlot var10 = new org.jfree.chart.plot.WaferMapPlot(var8, var9);
//     java.awt.Font var11 = var10.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     var12.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var15 = var12.getPlot();
//     java.lang.String var16 = var12.getLabel();
//     java.awt.Paint var17 = var12.getLabelPaint();
//     org.jfree.chart.text.TextFragment var18 = new org.jfree.chart.text.TextFragment("", var11, var17);
//     java.awt.Font var19 = var18.getFont();
//     org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("", var19);
//     var5.setLabelFont(var19);
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     double var24 = var23.getLowerMargin();
//     boolean var25 = var23.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var27.setAutoRangeIncludesZero(true);
//     var27.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var32 = null;
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var27, var32);
//     boolean var34 = var33.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
//     var35.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var38 = var35.getPlot();
//     java.lang.String var39 = var35.getLabel();
//     java.awt.Paint var40 = var35.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder(var40);
//     var33.setDomainTickBandPaint(var40);
//     var5.setPaint(var40);
//     org.jfree.chart.text.TextAnchor var44 = var5.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", var1, 0.0f, 0.0f, var44, 1.0E-5d, 0.8f, 10.0f);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    java.lang.String var1 = var0.getVersion();
    var0.setVersion("XY Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     var11.configureRangeAxes();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     java.lang.Object var15 = var14.clone();
//     var14.setSectionDepth(0.0d);
//     var14.setInnerSeparatorExtension(100.0d);
//     double var20 = var14.getSectionDepth();
//     org.jfree.data.general.WaferMapDataset var22 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var23 = null;
//     org.jfree.chart.plot.WaferMapPlot var24 = new org.jfree.chart.plot.WaferMapPlot(var22, var23);
//     java.awt.Font var25 = var24.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     var26.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var29 = var26.getPlot();
//     java.lang.String var30 = var26.getLabel();
//     java.awt.Paint var31 = var26.getLabelPaint();
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var25, var31);
//     var14.setLabelShadowPaint(var31);
//     var11.setRangeZeroBaselinePaint(var31);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var37 = null;
//     var36.setFixedLegendItems(var37);
//     boolean var39 = var36.isRangeCrosshairVisible();
//     boolean var40 = var36.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var42 = var36.getDomainAxisLocation(10);
//     var11.setDomainAxisLocation(4, var42);
//     org.jfree.chart.plot.ValueMarker var45 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var48 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var49 = null;
//     org.jfree.chart.plot.WaferMapPlot var50 = new org.jfree.chart.plot.WaferMapPlot(var48, var49);
//     java.awt.Font var51 = var50.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
//     var52.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var55 = var52.getPlot();
//     java.lang.String var56 = var52.getLabel();
//     java.awt.Paint var57 = var52.getLabelPaint();
//     org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var51, var57);
//     java.awt.Font var59 = var58.getFont();
//     org.jfree.chart.text.TextLine var60 = new org.jfree.chart.text.TextLine("", var59);
//     var45.setLabelFont(var59);
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis();
//     double var64 = var63.getLowerMargin();
//     boolean var65 = var63.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var67.setAutoRangeIncludesZero(true);
//     var67.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var62, (org.jfree.chart.axis.ValueAxis)var63, (org.jfree.chart.axis.ValueAxis)var67, var72);
//     boolean var74 = var73.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var75 = new org.jfree.chart.axis.CategoryAxis();
//     var75.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var78 = var75.getPlot();
//     java.lang.String var79 = var75.getLabel();
//     java.awt.Paint var80 = var75.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var81 = new org.jfree.chart.block.BlockBorder(var80);
//     var73.setDomainTickBandPaint(var80);
//     var45.setPaint(var80);
//     boolean var84 = var11.removeRangeMarker((org.jfree.chart.plot.Marker)var45);
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    var1.distributeLabels(0.05d, 0.0d);
    var1.clear();
    int var6 = var1.getItemCount();
    var1.distributeLabels(0.0d, 2.0d);
    org.jfree.chart.plot.PieLabelRecord var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"RectangleEdge.BOTTOM", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    double var1 = var0.getContentYOffset();
    var0.setHeight(101.0d);
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var7 = var6.getText();
//     var6.setID("ThreadContext");
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     var11.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var14 = var11.getPlot();
//     java.lang.String var15 = var11.getLabel();
//     java.awt.Paint var16 = var11.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder(var16);
//     var10.setTickMarkPaint(var16);
//     var6.setBackgroundPaint(var16);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
//     double var22 = var21.getLowerMargin();
//     boolean var23 = var21.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var25.setAutoRangeIncludesZero(true);
//     var25.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var34 = var33.getLabel();
//     var31.addDomainMarker((org.jfree.chart.plot.Marker)var33);
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     boolean var38 = var37.isInverted();
//     org.jfree.chart.axis.NumberTickUnit var39 = var37.getTickUnit();
//     boolean var40 = var37.isAutoTickUnitSelection();
//     var37.setAutoRangeIncludesZero(true);
//     org.jfree.chart.axis.ValueAxis[] var43 = new org.jfree.chart.axis.ValueAxis[] { var37};
//     var31.setRangeAxes(var43);
//     java.lang.String var45 = var31.getPlotType();
//     var4.add((org.jfree.chart.block.Block)var6, (java.lang.Object)var45);
//     org.jfree.chart.plot.MultiplePiePlot var47 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var48 = var47.getLegendItems();
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis();
//     var49.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var52 = var49.getPlot();
//     java.lang.String var53 = var49.getLabel();
//     java.awt.Paint var54 = var49.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder(var54);
//     boolean var56 = var47.equals((java.lang.Object)var55);
//     org.jfree.chart.util.RectangleInsets var57 = var55.getInsets();
//     double var58 = var57.getRight();
//     var6.setPadding(var57);
//     
//     // Checks the contract:  equals-hashcode on var17 and var55
//     assertTrue("Contract failed: equals-hashcode on var17 and var55", var17.equals(var55) ? var17.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var17
//     assertTrue("Contract failed: equals-hashcode on var55 and var17", var55.equals(var17) ? var55.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.lang.Object var2 = var1.clone();
//     var1.setLabelGap(10.0d);
//     boolean var5 = var1.getSectionOutlinesVisible();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
//     java.lang.Object var8 = var7.clone();
//     var7.setSectionDepth(0.0d);
//     var7.setInnerSeparatorExtension(100.0d);
//     double var13 = var7.getSectionDepth();
//     org.jfree.data.general.WaferMapDataset var17 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var18 = null;
//     org.jfree.chart.plot.WaferMapPlot var19 = new org.jfree.chart.plot.WaferMapPlot(var17, var18);
//     java.awt.Font var20 = var19.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     var21.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var24 = var21.getPlot();
//     java.lang.String var25 = var21.getLabel();
//     java.awt.Paint var26 = var21.getLabelPaint();
//     org.jfree.chart.text.TextFragment var27 = new org.jfree.chart.text.TextFragment("", var20, var26);
//     java.awt.Font var28 = var27.getFont();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("ThreadContext", var28);
//     org.jfree.chart.ChartColor var34 = new org.jfree.chart.ChartColor(1, 0, 0);
//     java.awt.image.ColorModel var35 = null;
//     java.awt.Rectangle var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var34.createContext(var35, var36, var37, var38, var39);
//     java.awt.Color var41 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var34);
//     org.jfree.chart.text.TextFragment var42 = new org.jfree.chart.text.TextFragment("", var28, (java.awt.Paint)var34);
//     var7.setLabelBackgroundPaint((java.awt.Paint)var34);
//     var1.setSeparatorPaint((java.awt.Paint)var34);
//     
//     // Checks the contract:  equals-hashcode on var2 and var8
//     assertTrue("Contract failed: equals-hashcode on var2 and var8", var2.equals(var8) ? var2.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var2
//     assertTrue("Contract failed: equals-hashcode on var8 and var2", var8.equals(var2) ? var8.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     boolean var2 = var0.isVisible();
//     var0.setFixedDimension(1.0d);
//     java.util.Date var5 = var0.getMinimumDate();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     double var10 = var9.getLowerMargin();
//     boolean var11 = var9.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var13.setAutoRangeIncludesZero(true);
//     var13.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     var19.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var21 = var19.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var22 = org.jfree.chart.util.RectangleEdge.opposite(var21);
//     org.jfree.chart.util.RectangleEdge var23 = org.jfree.chart.util.RectangleEdge.opposite(var22);
//     double var24 = var0.lengthToJava2D(0.025d, var7, var22);
// 
//   }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     boolean var3 = var0.isRangeCrosshairVisible();
//     org.jfree.data.general.WaferMapDataset var7 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var8 = null;
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var7, var8);
//     java.awt.Font var10 = var9.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     var11.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var14 = var11.getPlot();
//     java.lang.String var15 = var11.getLabel();
//     java.awt.Paint var16 = var11.getLabelPaint();
//     org.jfree.chart.text.TextFragment var17 = new org.jfree.chart.text.TextFragment("", var10, var16);
//     java.awt.Font var18 = var17.getFont();
//     org.jfree.chart.text.TextLine var19 = new org.jfree.chart.text.TextLine("", var18);
//     org.jfree.data.general.WaferMapDataset var20 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var21 = null;
//     org.jfree.chart.plot.WaferMapPlot var22 = new org.jfree.chart.plot.WaferMapPlot(var20, var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     var22.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("ThreadContext", var18, (org.jfree.chart.plot.Plot)var22, false);
//     java.awt.Image var28 = var27.getBackgroundImage();
//     int var29 = var27.getBackgroundImageAlignment();
//     org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var27);
//     org.jfree.chart.util.SortOrder var31 = var0.getRowRenderingOrder();
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var35 = null;
//     var34.setFixedLegendItems(var35);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     var34.zoomRangeAxes(0.0d, var38, var39);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     org.jfree.data.xy.XYDataset var43 = null;
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     double var45 = var44.getLowerMargin();
//     boolean var46 = var44.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var48.setAutoRangeIncludesZero(true);
//     var48.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var53 = null;
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot(var43, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.axis.ValueAxis)var48, var53);
//     var54.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var56 = var54.getDomainAxisEdge();
//     var54.setRangeCrosshairValue(101.0d, true);
//     var54.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var62 = var54.getQuadrantOrigin();
//     var34.zoomRangeAxes(4.0d, var42, var62, false);
//     var0.zoomRangeAxes(101.0d, var33, var62);
//     
//     // Checks the contract:  equals-hashcode on var0 and var34
//     assertTrue("Contract failed: equals-hashcode on var0 and var34", var0.equals(var34) ? var0.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var0
//     assertTrue("Contract failed: equals-hashcode on var34 and var0", var34.equals(var0) ? var34.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setToolTipText("");
    java.lang.String var3 = var0.getID();
    org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var5 = var4.getLineAlignment();
    var0.setTextAlignment(var5);
    java.lang.String var7 = var0.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + ""+ "'", var7.equals(""));

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("ThreadContext", var14);
    org.jfree.chart.ChartColor var20 = new org.jfree.chart.ChartColor(1, 0, 0);
    java.awt.image.ColorModel var21 = null;
    java.awt.Rectangle var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    java.awt.geom.AffineTransform var24 = null;
    java.awt.RenderingHints var25 = null;
    java.awt.PaintContext var26 = var20.createContext(var21, var22, var23, var24, var25);
    java.awt.Color var27 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", (java.awt.Color)var20);
    org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("", var14, (java.awt.Paint)var20);
    java.awt.Paint var29 = var28.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "XY Plot", "", "hi!", "hi!");
    java.lang.String var6 = var5.getName();
    java.lang.String var7 = var5.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var6.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "hi!"+ "'", var7.equals("hi!"));

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     var0.setRenderer(0, var4, true);
//     var0.setRangeCrosshairVisible(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     var0.setRenderer(1, var10, true);
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var15.setMaximumCategoryLabelLines(15);
//     var0.setDomainAxis(15, (org.jfree.chart.axis.CategoryAxis)var15);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
//     double var22 = var21.getLowerMargin();
//     boolean var23 = var21.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var25.setAutoRangeIncludesZero(true);
//     var25.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var34 = var33.getLabel();
//     var31.addDomainMarker((org.jfree.chart.plot.Marker)var33);
//     java.awt.Paint var36 = var33.getOutlinePaint();
//     org.jfree.chart.util.Layer var37 = null;
//     var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var33, var37);
//     java.awt.Graphics2D var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     var0.drawBackground(var39, var40);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     var2.setLabelFont(var16);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     double var21 = var20.getLowerMargin();
//     boolean var22 = var20.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var24.setAutoRangeIncludesZero(true);
//     var24.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     boolean var31 = var30.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var35 = var32.getPlot();
//     java.lang.String var36 = var32.getLabel();
//     java.awt.Paint var37 = var32.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var37);
//     var30.setDomainTickBandPaint(var37);
//     var2.setPaint(var37);
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot();
//     var41.add(var42, (java.lang.Object)var43);
//     org.jfree.chart.labels.PieSectionLabelGenerator var45 = var43.getLegendLabelGenerator();
//     var43.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var48 = var43.getBaseSectionOutlineStroke();
//     var2.setStroke(var48);
//     var0.setRadiusGridlineStroke(var48);
//     org.jfree.data.xy.XYDataset var51 = null;
//     var0.setDataset(var51);
//     float var53 = var0.getBackgroundAlpha();
//     org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var58 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var59 = null;
//     org.jfree.chart.plot.WaferMapPlot var60 = new org.jfree.chart.plot.WaferMapPlot(var58, var59);
//     java.awt.Font var61 = var60.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis();
//     var62.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var65 = var62.getPlot();
//     java.lang.String var66 = var62.getLabel();
//     java.awt.Paint var67 = var62.getLabelPaint();
//     org.jfree.chart.text.TextFragment var68 = new org.jfree.chart.text.TextFragment("", var61, var67);
//     java.awt.Font var69 = var68.getFont();
//     org.jfree.chart.text.TextLine var70 = new org.jfree.chart.text.TextLine("", var69);
//     var55.setLabelFont(var69);
//     org.jfree.data.xy.XYDataset var72 = null;
//     org.jfree.chart.axis.DateAxis var73 = new org.jfree.chart.axis.DateAxis();
//     double var74 = var73.getLowerMargin();
//     boolean var75 = var73.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var77 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var77.setAutoRangeIncludesZero(true);
//     var77.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var82 = null;
//     org.jfree.chart.plot.XYPlot var83 = new org.jfree.chart.plot.XYPlot(var72, (org.jfree.chart.axis.ValueAxis)var73, (org.jfree.chart.axis.ValueAxis)var77, var82);
//     boolean var84 = var83.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var85 = new org.jfree.chart.axis.CategoryAxis();
//     var85.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var88 = var85.getPlot();
//     java.lang.String var89 = var85.getLabel();
//     java.awt.Paint var90 = var85.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var91 = new org.jfree.chart.block.BlockBorder(var90);
//     var83.setDomainTickBandPaint(var90);
//     var55.setPaint(var90);
//     org.jfree.chart.text.TextAnchor var94 = var55.getLabelTextAnchor();
//     java.awt.Font var95 = var55.getLabelFont();
//     var0.setAngleLabelFont(var95);
//     
//     // Checks the contract:  equals-hashcode on var2 and var55
//     assertTrue("Contract failed: equals-hashcode on var2 and var55", var2.equals(var55) ? var2.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var2
//     assertTrue("Contract failed: equals-hashcode on var55 and var2", var55.equals(var2) ? var55.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var60
//     assertTrue("Contract failed: equals-hashcode on var7 and var60", var7.equals(var60) ? var7.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var7
//     assertTrue("Contract failed: equals-hashcode on var60 and var7", var60.equals(var7) ? var60.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var83
//     assertTrue("Contract failed: equals-hashcode on var30 and var83", var30.equals(var83) ? var30.hashCode() == var83.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var83 and var30
//     assertTrue("Contract failed: equals-hashcode on var83 and var30", var83.equals(var30) ? var83.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var91
//     assertTrue("Contract failed: equals-hashcode on var38 and var91", var38.equals(var91) ? var38.hashCode() == var91.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var91 and var38
//     assertTrue("Contract failed: equals-hashcode on var91 and var38", var91.equals(var38) ? var91.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
//     org.jfree.data.general.WaferMapDataset var16 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     var18.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.event.ChartProgressListener var25 = null;
//     var23.removeProgressListener(var25);
//     org.jfree.chart.ChartColor var30 = new org.jfree.chart.ChartColor(1, 0, 0);
//     java.awt.color.ColorSpace var31 = var30.getColorSpace();
//     java.awt.image.ColorModel var32 = null;
//     java.awt.Rectangle var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     java.awt.geom.AffineTransform var35 = null;
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var37 = var36.getText();
//     org.jfree.data.general.WaferMapDataset var41 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var42 = null;
//     org.jfree.chart.plot.WaferMapPlot var43 = new org.jfree.chart.plot.WaferMapPlot(var41, var42);
//     java.awt.Font var44 = var43.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
//     var45.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var48 = var45.getPlot();
//     java.lang.String var49 = var45.getLabel();
//     java.awt.Paint var50 = var45.getLabelPaint();
//     org.jfree.chart.text.TextFragment var51 = new org.jfree.chart.text.TextFragment("", var44, var50);
//     java.awt.Font var52 = var51.getFont();
//     org.jfree.chart.text.TextLine var53 = new org.jfree.chart.text.TextLine("", var52);
//     org.jfree.data.general.WaferMapDataset var54 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var55 = null;
//     org.jfree.chart.plot.WaferMapPlot var56 = new org.jfree.chart.plot.WaferMapPlot(var54, var55);
//     java.awt.Font var57 = var56.getNoDataMessageFont();
//     var56.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("ThreadContext", var52, (org.jfree.chart.plot.Plot)var56, false);
//     java.lang.Object var62 = var61.clone();
//     var36.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var61);
//     java.awt.Stroke var64 = var61.getBorderStroke();
//     var61.removeLegend();
//     var61.setBorderVisible(false);
//     java.awt.RenderingHints var68 = var61.getRenderingHints();
//     java.awt.PaintContext var69 = var30.createContext(var32, var33, var34, var35, var68);
//     var23.setRenderingHints(var68);
//     
//     // Checks the contract:  equals-hashcode on var5 and var43
//     assertTrue("Contract failed: equals-hashcode on var5 and var43", var5.equals(var43) ? var5.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var56
//     assertTrue("Contract failed: equals-hashcode on var18 and var56", var18.equals(var56) ? var18.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var5
//     assertTrue("Contract failed: equals-hashcode on var43 and var5", var43.equals(var5) ? var43.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var18
//     assertTrue("Contract failed: equals-hashcode on var56 and var18", var56.equals(var18) ? var56.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var61
//     assertTrue("Contract failed: equals-hashcode on var23 and var61", var23.equals(var61) ? var23.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var23
//     assertTrue("Contract failed: equals-hashcode on var61 and var23", var61.equals(var23) ? var61.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var62
//     assertTrue("Contract failed: equals-hashcode on var24 and var62", var24.equals(var62) ? var24.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var24
//     assertTrue("Contract failed: equals-hashcode on var62 and var24", var62.equals(var24) ? var62.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var5 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var6 = null;
//     org.jfree.chart.plot.WaferMapPlot var7 = new org.jfree.chart.plot.WaferMapPlot(var5, var6);
//     java.awt.Font var8 = var7.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
//     var9.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var12 = var9.getPlot();
//     java.lang.String var13 = var9.getLabel();
//     java.awt.Paint var14 = var9.getLabelPaint();
//     org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var8, var14);
//     java.awt.Font var16 = var15.getFont();
//     org.jfree.chart.text.TextLine var17 = new org.jfree.chart.text.TextLine("", var16);
//     var2.setLabelFont(var16);
//     org.jfree.data.xy.XYDataset var19 = null;
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     double var21 = var20.getLowerMargin();
//     boolean var22 = var20.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var24.setAutoRangeIncludesZero(true);
//     var24.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var29 = null;
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot(var19, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.axis.ValueAxis)var24, var29);
//     boolean var31 = var30.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     var32.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var35 = var32.getPlot();
//     java.lang.String var36 = var32.getLabel();
//     java.awt.Paint var37 = var32.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var38 = new org.jfree.chart.block.BlockBorder(var37);
//     var30.setDomainTickBandPaint(var37);
//     var2.setPaint(var37);
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot();
//     var41.add(var42, (java.lang.Object)var43);
//     org.jfree.chart.labels.PieSectionLabelGenerator var45 = var43.getLegendLabelGenerator();
//     var43.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var48 = var43.getBaseSectionOutlineStroke();
//     var2.setStroke(var48);
//     var0.setRadiusGridlineStroke(var48);
//     java.awt.Paint var51 = var0.getAngleLabelPaint();
//     java.awt.Stroke var52 = var0.getRadiusGridlineStroke();
//     org.jfree.chart.event.RendererChangeEvent var53 = null;
//     var0.rendererChanged(var53);
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var59 = null;
//     var58.setFixedLegendItems(var59);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     java.awt.geom.Point2D var63 = null;
//     var58.zoomRangeAxes(0.0d, var62, var63);
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     org.jfree.data.xy.XYDataset var67 = null;
//     org.jfree.chart.axis.DateAxis var68 = new org.jfree.chart.axis.DateAxis();
//     double var69 = var68.getLowerMargin();
//     boolean var70 = var68.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var72.setAutoRangeIncludesZero(true);
//     var72.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var77 = null;
//     org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot(var67, (org.jfree.chart.axis.ValueAxis)var68, (org.jfree.chart.axis.ValueAxis)var72, var77);
//     var78.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var80 = var78.getDomainAxisEdge();
//     var78.setRangeCrosshairValue(101.0d, true);
//     var78.setForegroundAlpha(0.0f);
//     java.awt.geom.Point2D var86 = var78.getQuadrantOrigin();
//     var58.zoomRangeAxes(4.0d, var66, var86, false);
//     var0.zoomRangeAxes((-1.0d), 1.0E-5d, var57, var86);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = null;
//     var0.setFixedLegendItems(var1);
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     var0.zoomRangeAxes(0.0d, var4, var5);
//     org.jfree.data.category.CategoryDataset var8 = null;
//     var0.setDataset(100, var8);
//     org.jfree.chart.util.RectangleEdge var11 = var0.getRangeAxisEdge(15);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var13 = null;
//     var12.setFixedLegendItems(var13);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     var12.setRenderer(0, var16, true);
//     boolean var19 = var12.getDrawSharedDomainAxis();
//     boolean var20 = var12.isRangeCrosshairVisible();
//     org.jfree.chart.LegendItemCollection var21 = var12.getLegendItems();
//     var0.setFixedLegendItems(var21);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    var0.setWeight(1);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var9.setAutoRangeIncludesZero(true);
    var9.setAutoRangeStickyZero(true);
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var0.setRangeAxes(var14);
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var19 = null;
    var18.setFixedLegendItems(var19);
    boolean var21 = var18.isRangeCrosshairVisible();
    org.jfree.data.general.WaferMapDataset var25 = null;
    org.jfree.chart.renderer.WaferMapRenderer var26 = null;
    org.jfree.chart.plot.WaferMapPlot var27 = new org.jfree.chart.plot.WaferMapPlot(var25, var26);
    java.awt.Font var28 = var27.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
    var29.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var32 = var29.getPlot();
    java.lang.String var33 = var29.getLabel();
    java.awt.Paint var34 = var29.getLabelPaint();
    org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("", var28, var34);
    java.awt.Font var36 = var35.getFont();
    org.jfree.chart.text.TextLine var37 = new org.jfree.chart.text.TextLine("", var36);
    org.jfree.data.general.WaferMapDataset var38 = null;
    org.jfree.chart.renderer.WaferMapRenderer var39 = null;
    org.jfree.chart.plot.WaferMapPlot var40 = new org.jfree.chart.plot.WaferMapPlot(var38, var39);
    java.awt.Font var41 = var40.getNoDataMessageFont();
    var40.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("ThreadContext", var36, (org.jfree.chart.plot.Plot)var40, false);
    java.awt.Image var46 = var45.getBackgroundImage();
    int var47 = var45.getBackgroundImageAlignment();
    org.jfree.chart.event.ChartChangeEvent var48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var18, var45);
    org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.plot.PlotRenderingInfo var51 = null;
    java.awt.geom.Point2D var52 = null;
    var18.zoomRangeAxes(0.025d, var51, var52);
    org.jfree.chart.axis.AxisLocation var55 = var18.getRangeAxisLocation(255);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-253), var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    var1.distributeLabels(0.05d, 0.0d);
    var1.clear();
    int var6 = var1.getItemCount();
    var1.distributeLabels(0.0d, 2.0d);
    int var10 = var1.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var12 = var1.getPieLabelRecord(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     java.lang.String var13 = var12.getText();
//     java.awt.Font var14 = var12.getFont();
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
//     double var17 = var16.getLowerMargin();
//     boolean var18 = var16.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var20.setAutoRangeIncludesZero(true);
//     var20.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var20, var25);
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var29 = var28.getLabel();
//     var26.addDomainMarker((org.jfree.chart.plot.Marker)var28);
//     java.awt.Color var33 = java.awt.Color.getColor("XY Plot", (-1));
//     java.awt.color.ColorSpace var34 = var33.getColorSpace();
//     int var35 = var33.getRed();
//     int var36 = var33.getTransparency();
//     int var37 = var33.getTransparency();
//     var28.setPaint((java.awt.Paint)var33);
//     org.jfree.chart.text.TextMeasurer var41 = null;
//     org.jfree.chart.text.TextBlock var42 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.BOTTOM", var14, (java.awt.Paint)var33, 0.8f, 4, var41);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    double var1 = var0.getLabelLinkMargin();
    org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    var2.add(var3, (java.lang.Object)var4);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var4.getLegendLabelGenerator();
    var0.setLegendLabelToolTipGenerator(var6);
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var0.setURLGenerator(var8);
    var0.setMinimumArcAngleToDraw(0.025d);
    java.awt.Paint[] var12 = null;
    java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke var15 = null;
    java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
    java.awt.Stroke var17 = null;
    java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var14, var16, var18, var20);
    java.awt.Shape var22 = var21.getNextShape();
    java.awt.Stroke var23 = var21.getNextStroke();
    java.awt.Shape var24 = var21.getNextShape();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    var4.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var7 = var4.getPlot();
    java.lang.String var8 = var4.getLabel();
    java.awt.Paint var9 = var4.getLabelPaint();
    var0.setTickLabelPaint((java.lang.Comparable)(byte)0, var9);
    var0.addCategoryLabelToolTip((java.lang.Comparable)(-1.0f), "");
    float var14 = var0.getMaximumCategoryLabelWidthRatio();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0f);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0.0d};
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var0, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    boolean var12 = var11.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    var13.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var16 = var13.getPlot();
    java.lang.String var17 = var13.getLabel();
    java.awt.Paint var18 = var13.getLabelPaint();
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var18);
    var11.setDomainTickBandPaint(var18);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    var11.drawAnnotations(var21, var22, var23);
    var11.configureRangeAxes();
    org.jfree.chart.axis.AxisLocation var27 = var11.getRangeAxisLocation(0);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    boolean var31 = var28.isRangeCrosshairVisible();
    boolean var32 = var28.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var34 = var28.getDomainAxisLocation(10);
    var11.setDomainAxisLocation(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.general.WaferMapDataset var1 = null;
    org.jfree.chart.renderer.WaferMapRenderer var2 = null;
    org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var1, var2);
    java.awt.Font var4 = var3.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    var5.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var8 = var5.getPlot();
    java.lang.String var9 = var5.getLabel();
    java.awt.Paint var10 = var5.getLabelPaint();
    org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var4, var10);
    java.lang.String var12 = var11.getText();
    java.lang.String var13 = var11.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + ""+ "'", var13.equals(""));

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    java.awt.Graphics2D var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.plot.CrosshairState var17 = null;
    boolean var18 = var11.render(var13, var14, 0, var16, var17);
    org.jfree.chart.plot.SeriesRenderingOrder var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setSeriesRenderingOrder(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.08d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     org.jfree.chart.axis.Timeline var3 = null;
//     var1.setTimeline(var3);
//     double var5 = var1.getFixedAutoRange();
//     org.jfree.chart.util.RectangleInsets var6 = var1.getTickLabelInsets();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
//     double var8 = var7.getLowerMargin();
//     java.util.Date var9 = var7.getMinimumDate();
//     double var10 = var7.getFixedDimension();
//     org.jfree.chart.text.TextBlock var11 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var12 = var11.getLineAlignment();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.text.TextBlockAnchor var16 = null;
//     java.awt.Shape var20 = var11.calculateBounds(var13, (-1.0f), 100.0f, var16, (-1.0f), 1.0f, 0.0d);
//     org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var20);
//     var7.setRightArrow(var20);
//     boolean var24 = var7.isHiddenValue(100L);
//     var7.resizeRange(0.0d, 1.0E-8d);
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var7, var28);
// 
//   }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    boolean var3 = var0.isRangeCrosshairVisible();
    boolean var4 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis var5 = null;
    var0.setDomainAxis(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    java.util.List var3 = var0.getLines();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var4 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var3);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    boolean var12 = var11.isDomainZeroBaselineVisible();
    var11.setDomainCrosshairLockedOnData(true);
    org.jfree.data.xy.XYDataset var16 = null;
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
    double var18 = var17.getLowerMargin();
    boolean var19 = var17.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var21.setAutoRangeIncludesZero(true);
    var21.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var16, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var21, var26);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var30 = var29.getLabel();
    var27.addDomainMarker((org.jfree.chart.plot.Marker)var29);
    java.awt.Paint var32 = var29.getOutlinePaint();
    org.jfree.chart.util.Layer var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addDomainMarker(100, (org.jfree.chart.plot.Marker)var29, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    java.util.Date var2 = var0.getMinimumDate();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var0.setTickUnit(var3, false, true);
    org.jfree.chart.axis.DateTickUnit var7 = var0.getTickUnit();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var10 = var9.isInverted();
    org.jfree.chart.axis.NumberTickUnit var11 = var9.getTickUnit();
    boolean var12 = var9.isAutoTickUnitSelection();
    var9.setAutoRangeIncludesZero(true);
    org.jfree.data.Range var15 = var9.getDefaultAutoRange();
    var0.setRange(var15);
    java.util.Date var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setMaximumDate(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var1 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var2 = null;
//     org.jfree.chart.plot.WaferMapPlot var3 = new org.jfree.chart.plot.WaferMapPlot(var1, var2);
//     java.awt.Font var4 = var3.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var8 = var5.getPlot();
//     java.lang.String var9 = var5.getLabel();
//     java.awt.Paint var10 = var5.getLabelPaint();
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var4, var10);
//     java.lang.String var12 = var11.getText();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.util.Size2D var14 = var11.calculateDimensions(var13);
// 
//   }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.lang.Object var24 = var23.clone();
    org.jfree.chart.event.ChartProgressListener var25 = null;
    var23.removeProgressListener(var25);
    var23.clearSubtitles();
    org.jfree.chart.event.ChartChangeListener var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.addChangeListener(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(0);
    var1.distributeLabels(0.05d, 0.0d);
    var1.clear();
    int var6 = var1.getItemCount();
    var1.distributeLabels(0.0d, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PieLabelRecord var11 = var1.getPieLabelRecord((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     var11.configureRangeAxes();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     double var14 = var13.getLowerMargin();
//     boolean var15 = var13.isTickMarksVisible();
//     var11.setRangeAxis((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.data.general.WaferMapDataset var20 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var21 = null;
//     org.jfree.chart.plot.WaferMapPlot var22 = new org.jfree.chart.plot.WaferMapPlot(var20, var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     var24.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var27 = var24.getPlot();
//     java.lang.String var28 = var24.getLabel();
//     java.awt.Paint var29 = var24.getLabelPaint();
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("", var23, var29);
//     java.awt.Font var31 = var30.getFont();
//     org.jfree.chart.text.TextLine var32 = new org.jfree.chart.text.TextLine("", var31);
//     org.jfree.data.general.WaferMapDataset var33 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var34 = null;
//     org.jfree.chart.plot.WaferMapPlot var35 = new org.jfree.chart.plot.WaferMapPlot(var33, var34);
//     java.awt.Font var36 = var35.getNoDataMessageFont();
//     var35.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart("ThreadContext", var31, (org.jfree.chart.plot.Plot)var35, false);
//     java.lang.Object var41 = var40.clone();
//     org.jfree.chart.event.ChartProgressListener var42 = null;
//     var40.removeProgressListener(var42);
//     var40.clearSubtitles();
//     var11.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
//     org.jfree.data.general.WaferMapDataset var48 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var49 = null;
//     org.jfree.chart.plot.WaferMapPlot var50 = new org.jfree.chart.plot.WaferMapPlot(var48, var49);
//     java.awt.Font var51 = var50.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
//     var52.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var55 = var52.getPlot();
//     java.lang.String var56 = var52.getLabel();
//     java.awt.Paint var57 = var52.getLabelPaint();
//     org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var51, var57);
//     java.awt.Font var59 = var58.getFont();
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("ThreadContext", var59);
//     java.lang.String var61 = var60.getToolTipText();
//     var40.addSubtitle((org.jfree.chart.title.Title)var60);
//     
//     // Checks the contract:  equals-hashcode on var22 and var50
//     assertTrue("Contract failed: equals-hashcode on var22 and var50", var22.equals(var50) ? var22.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var22
//     assertTrue("Contract failed: equals-hashcode on var50 and var22", var50.equals(var22) ? var50.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100.0f};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 0.2d};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 0.5d, 10.0d);
    org.jfree.chart.util.VerticalAlignment var6 = null;
    org.jfree.chart.block.FlowArrangement var9 = new org.jfree.chart.block.FlowArrangement(var1, var6, 10.0d, (-13.95d));
    org.jfree.data.general.WaferMapDataset var12 = null;
    org.jfree.chart.renderer.WaferMapRenderer var13 = null;
    org.jfree.chart.plot.WaferMapPlot var14 = new org.jfree.chart.plot.WaferMapPlot(var12, var13);
    java.awt.Font var15 = var14.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
    var16.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var19 = var16.getPlot();
    java.lang.String var20 = var16.getLabel();
    java.awt.Paint var21 = var16.getLabelPaint();
    org.jfree.chart.text.TextFragment var22 = new org.jfree.chart.text.TextFragment("", var15, var21);
    java.awt.Font var23 = var22.getFont();
    org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("", var23);
    org.jfree.chart.text.TextFragment var25 = var24.getFirstTextFragment();
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
    double var28 = var27.getLowerMargin();
    boolean var29 = var27.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var31.setAutoRangeIncludesZero(true);
    var31.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var26, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.axis.ValueAxis)var31, var36);
    org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var40 = var39.getLabel();
    var37.addDomainMarker((org.jfree.chart.plot.Marker)var39);
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var44 = var43.isInverted();
    org.jfree.chart.axis.NumberTickUnit var45 = var43.getTickUnit();
    boolean var46 = var43.isAutoTickUnitSelection();
    var43.setAutoRangeIncludesZero(true);
    org.jfree.chart.axis.ValueAxis[] var49 = new org.jfree.chart.axis.ValueAxis[] { var43};
    var37.setRangeAxes(var49);
    java.lang.String var51 = var37.getPlotType();
    org.jfree.data.xy.XYDataset var52 = null;
    org.jfree.chart.axis.DateAxis var53 = new org.jfree.chart.axis.DateAxis();
    double var54 = var53.getLowerMargin();
    boolean var55 = var53.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var57.setAutoRangeIncludesZero(true);
    var57.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var62 = null;
    org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot(var52, (org.jfree.chart.axis.ValueAxis)var53, (org.jfree.chart.axis.ValueAxis)var57, var62);
    boolean var64 = var63.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis();
    var65.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var68 = var65.getPlot();
    java.lang.String var69 = var65.getLabel();
    java.awt.Paint var70 = var65.getLabelPaint();
    org.jfree.chart.block.BlockBorder var71 = new org.jfree.chart.block.BlockBorder(var70);
    var63.setDomainTickBandPaint(var70);
    var37.setRangeZeroBaselinePaint(var70);
    boolean var74 = var25.equals((java.lang.Object)var37);
    boolean var75 = var1.equals((java.lang.Object)var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var51 + "' != '" + "XY Plot"+ "'", var51.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 0.0d);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    double var6 = var5.getContentYOffset();
    var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)(-1));
    org.jfree.chart.block.BlockContainer var9 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    org.jfree.chart.block.BlockFrame var10 = var9.getFrame();
    org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(0.0d, 0.0d, 1.0d, 1.0d);
    double var17 = var15.extendWidth(100.0d);
    var9.setPadding(var15);
    double var19 = var15.getTop();
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
    double var22 = var21.getLowerMargin();
    boolean var23 = var21.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var25 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var25.setAutoRangeIncludesZero(true);
    var25.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var25, var30);
    var31.configureRangeAxes();
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.CrosshairState var37 = null;
    boolean var38 = var31.render(var33, var34, 0, var36, var37);
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.general.WaferMapDataset var43 = null;
    org.jfree.chart.renderer.WaferMapRenderer var44 = null;
    org.jfree.chart.plot.WaferMapPlot var45 = new org.jfree.chart.plot.WaferMapPlot(var43, var44);
    java.awt.Font var46 = var45.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
    var47.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var50 = var47.getPlot();
    java.lang.String var51 = var47.getLabel();
    java.awt.Paint var52 = var47.getLabelPaint();
    org.jfree.chart.text.TextFragment var53 = new org.jfree.chart.text.TextFragment("", var46, var52);
    java.awt.Font var54 = var53.getFont();
    org.jfree.chart.text.TextLine var55 = new org.jfree.chart.text.TextLine("", var54);
    var40.setLabelFont(var54);
    org.jfree.data.xy.XYDataset var57 = null;
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
    double var59 = var58.getLowerMargin();
    boolean var60 = var58.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var62 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var62.setAutoRangeIncludesZero(true);
    var62.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var67 = null;
    org.jfree.chart.plot.XYPlot var68 = new org.jfree.chart.plot.XYPlot(var57, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.axis.ValueAxis)var62, var67);
    boolean var69 = var68.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var70 = new org.jfree.chart.axis.CategoryAxis();
    var70.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var73 = var70.getPlot();
    java.lang.String var74 = var70.getLabel();
    java.awt.Paint var75 = var70.getLabelPaint();
    org.jfree.chart.block.BlockBorder var76 = new org.jfree.chart.block.BlockBorder(var75);
    var68.setDomainTickBandPaint(var75);
    var40.setPaint(var75);
    var31.addRangeMarker((org.jfree.chart.plot.Marker)var40);
    java.awt.Paint var80 = var31.getRangeGridlinePaint();
    org.jfree.chart.block.BlockBorder var81 = new org.jfree.chart.block.BlockBorder(var15, var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 101.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(0, var4, true);
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    double var10 = var9.getLowerMargin();
    boolean var11 = var9.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var13.setAutoRangeIncludesZero(true);
    var13.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var13, var18);
    var19.configureRangeAxes();
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.PlotRenderingInfo var24 = null;
    org.jfree.chart.plot.CrosshairState var25 = null;
    boolean var26 = var19.render(var21, var22, 0, var24, var25);
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.data.general.WaferMapDataset var31 = null;
    org.jfree.chart.renderer.WaferMapRenderer var32 = null;
    org.jfree.chart.plot.WaferMapPlot var33 = new org.jfree.chart.plot.WaferMapPlot(var31, var32);
    java.awt.Font var34 = var33.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
    var35.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var38 = var35.getPlot();
    java.lang.String var39 = var35.getLabel();
    java.awt.Paint var40 = var35.getLabelPaint();
    org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("", var34, var40);
    java.awt.Font var42 = var41.getFont();
    org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("", var42);
    var28.setLabelFont(var42);
    org.jfree.data.xy.XYDataset var45 = null;
    org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis();
    double var47 = var46.getLowerMargin();
    boolean var48 = var46.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var50.setAutoRangeIncludesZero(true);
    var50.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
    org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var45, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.axis.ValueAxis)var50, var55);
    boolean var57 = var56.isDomainZeroBaselineVisible();
    org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis();
    var58.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var61 = var58.getPlot();
    java.lang.String var62 = var58.getLabel();
    java.awt.Paint var63 = var58.getLabelPaint();
    org.jfree.chart.block.BlockBorder var64 = new org.jfree.chart.block.BlockBorder(var63);
    var56.setDomainTickBandPaint(var63);
    var28.setPaint(var63);
    var19.addRangeMarker((org.jfree.chart.plot.Marker)var28);
    org.jfree.chart.util.Layer var68 = null;
    var0.addRangeMarker(0, (org.jfree.chart.plot.Marker)var28, var68);
    org.jfree.chart.util.RectangleEdge var71 = var0.getDomainAxisEdge((-1));
    java.awt.Stroke var72 = var0.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisLocation var74 = null;
    var0.setRangeAxisLocation(10, var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    var0.setWeight(1);
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var9.setAutoRangeIncludesZero(true);
    var9.setAutoRangeStickyZero(true);
    org.jfree.chart.axis.ValueAxis[] var14 = new org.jfree.chart.axis.ValueAxis[] { var9};
    var0.setRangeAxes(var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    var0.setRenderer(var16, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var2 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var3 = null;
//     org.jfree.chart.plot.WaferMapPlot var4 = new org.jfree.chart.plot.WaferMapPlot(var2, var3);
//     java.awt.Font var5 = var4.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     var6.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var9 = var6.getPlot();
//     java.lang.String var10 = var6.getLabel();
//     java.awt.Paint var11 = var6.getLabelPaint();
//     org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var5, var11);
//     java.awt.Font var13 = var12.getFont();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("", var13);
//     org.jfree.chart.text.TextFragment var15 = var14.getFirstTextFragment();
//     org.jfree.chart.text.TextLine var16 = new org.jfree.chart.text.TextLine();
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.util.Size2D var18 = var16.calculateDimensions(var17);
//     org.jfree.data.general.WaferMapDataset var20 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var21 = null;
//     org.jfree.chart.plot.WaferMapPlot var22 = new org.jfree.chart.plot.WaferMapPlot(var20, var21);
//     java.awt.Font var23 = var22.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     var24.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var27 = var24.getPlot();
//     java.lang.String var28 = var24.getLabel();
//     java.awt.Paint var29 = var24.getLabelPaint();
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("", var23, var29);
//     java.lang.String var31 = var30.getText();
//     java.awt.Font var32 = var30.getFont();
//     var16.addFragment(var30);
//     var14.addFragment(var30);
//     
//     // Checks the contract:  equals-hashcode on var4 and var22
//     assertTrue("Contract failed: equals-hashcode on var4 and var22", var4.equals(var22) ? var4.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var4
//     assertTrue("Contract failed: equals-hashcode on var22 and var4", var22.equals(var4) ? var22.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
//     org.jfree.data.general.WaferMapDataset var16 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     var18.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
//     java.awt.Image var24 = var23.getBackgroundImage();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     var23.setTitle(var26);
//     java.awt.Stroke var28 = var23.getBorderStroke();
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     var23.handleClick((-1), 0, var31);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-246));

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var3 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var4 = null;
//     org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
//     java.awt.Font var6 = var5.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     var7.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var10 = var7.getPlot();
//     java.lang.String var11 = var7.getLabel();
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
//     java.awt.Font var14 = var13.getFont();
//     org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
//     org.jfree.data.general.WaferMapDataset var16 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var17 = null;
//     org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
//     java.awt.Font var19 = var18.getNoDataMessageFont();
//     var18.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
//     org.jfree.chart.plot.Plot var24 = var23.getPlot();
//     org.jfree.chart.plot.PolarPlot var25 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var30 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var31 = null;
//     org.jfree.chart.plot.WaferMapPlot var32 = new org.jfree.chart.plot.WaferMapPlot(var30, var31);
//     java.awt.Font var33 = var32.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var34 = new org.jfree.chart.axis.CategoryAxis();
//     var34.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var37 = var34.getPlot();
//     java.lang.String var38 = var34.getLabel();
//     java.awt.Paint var39 = var34.getLabelPaint();
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("", var33, var39);
//     java.awt.Font var41 = var40.getFont();
//     org.jfree.chart.text.TextLine var42 = new org.jfree.chart.text.TextLine("", var41);
//     var27.setLabelFont(var41);
//     org.jfree.data.xy.XYDataset var44 = null;
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis();
//     double var46 = var45.getLowerMargin();
//     boolean var47 = var45.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var49 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var49.setAutoRangeIncludesZero(true);
//     var49.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var54 = null;
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot(var44, (org.jfree.chart.axis.ValueAxis)var45, (org.jfree.chart.axis.ValueAxis)var49, var54);
//     boolean var56 = var55.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis();
//     var57.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var60 = var57.getPlot();
//     java.lang.String var61 = var57.getLabel();
//     java.awt.Paint var62 = var57.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var63 = new org.jfree.chart.block.BlockBorder(var62);
//     var55.setDomainTickBandPaint(var62);
//     var27.setPaint(var62);
//     org.jfree.chart.block.ColumnArrangement var66 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var67 = null;
//     org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot();
//     var66.add(var67, (java.lang.Object)var68);
//     org.jfree.chart.labels.PieSectionLabelGenerator var70 = var68.getLegendLabelGenerator();
//     var68.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var73 = var68.getBaseSectionOutlineStroke();
//     var27.setStroke(var73);
//     var25.setRadiusGridlineStroke(var73);
//     java.awt.Paint var76 = var25.getAngleLabelPaint();
//     java.awt.Stroke var77 = var25.getRadiusGridlineStroke();
//     var24.setOutlineStroke(var77);
//     
//     // Checks the contract:  equals-hashcode on var5 and var32
//     assertTrue("Contract failed: equals-hashcode on var5 and var32", var5.equals(var32) ? var5.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var5
//     assertTrue("Contract failed: equals-hashcode on var32 and var5", var32.equals(var5) ? var32.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
    var0.add(var1, (java.lang.Object)var2);
    org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelGenerator();
    boolean var5 = var2.getIgnoreZeroValues();
    boolean var6 = var2.isSubplot();
    java.awt.Shape var7 = var2.getLegendItemShape();
    org.jfree.data.general.DatasetGroup var8 = var2.getDatasetGroup();
    org.jfree.chart.urls.PieURLGenerator var9 = null;
    var2.setLegendLabelURLGenerator(var9);
    boolean var11 = var2.getSectionOutlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Size2D[width=0.0, height=10.0]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.data.general.DatasetGroup var12 = var11.getDatasetGroup();
//     var11.setRangeGridlinesVisible(false);
//     boolean var15 = var11.isSubplot();
//     org.jfree.data.xy.XYDataset var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRenderer var17 = var11.getRendererForDataset(var16);
//     boolean var18 = var11.isDomainZeroBaselineVisible();
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var23 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var24 = null;
//     org.jfree.chart.plot.WaferMapPlot var25 = new org.jfree.chart.plot.WaferMapPlot(var23, var24);
//     java.awt.Font var26 = var25.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     var27.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var30 = var27.getPlot();
//     java.lang.String var31 = var27.getLabel();
//     java.awt.Paint var32 = var27.getLabelPaint();
//     org.jfree.chart.text.TextFragment var33 = new org.jfree.chart.text.TextFragment("", var26, var32);
//     java.awt.Font var34 = var33.getFont();
//     org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("", var34);
//     var20.setLabelFont(var34);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
//     double var39 = var38.getLowerMargin();
//     boolean var40 = var38.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var42.setAutoRangeIncludesZero(true);
//     var42.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var42, var47);
//     boolean var49 = var48.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis();
//     var50.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var53 = var50.getPlot();
//     java.lang.String var54 = var50.getLabel();
//     java.awt.Paint var55 = var50.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(var55);
//     var48.setDomainTickBandPaint(var55);
//     var20.setPaint(var55);
//     org.jfree.chart.block.ColumnArrangement var59 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var60 = null;
//     org.jfree.chart.plot.PiePlot var61 = new org.jfree.chart.plot.PiePlot();
//     var59.add(var60, (java.lang.Object)var61);
//     org.jfree.chart.labels.PieSectionLabelGenerator var63 = var61.getLegendLabelGenerator();
//     var61.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var66 = var61.getBaseSectionOutlineStroke();
//     var20.setStroke(var66);
//     boolean var68 = var11.removeDomainMarker((org.jfree.chart.plot.Marker)var20);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getLineAlignment();
    org.jfree.chart.block.ColumnArrangement var2 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.Block var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot();
    var2.add(var3, (java.lang.Object)var4);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var4.getLegendLabelToolTipGenerator();
    boolean var7 = var1.equals((java.lang.Object)var4);
    org.jfree.chart.util.RectangleInsets var8 = var4.getInsets();
    var4.setMaximumLabelWidth(1.0E-5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     var4.setRenderer(0, var8, true);
//     var4.setRangeCrosshairVisible(false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var4.setRenderer(1, var14, true);
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
//     var19.setMaximumCategoryLabelLines(15);
//     var4.setDomainAxis(15, (org.jfree.chart.axis.CategoryAxis)var19);
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     double var26 = var25.getLowerMargin();
//     boolean var27 = var25.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var29 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var29.setAutoRangeIncludesZero(true);
//     var29.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var29, var34);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var38 = var37.getLabel();
//     var35.addDomainMarker((org.jfree.chart.plot.Marker)var37);
//     java.awt.Paint var40 = var37.getOutlinePaint();
//     org.jfree.chart.util.Layer var41 = null;
//     var4.addRangeMarker(0, (org.jfree.chart.plot.Marker)var37, var41);
//     org.jfree.chart.title.TextTitle var43 = new org.jfree.chart.title.TextTitle();
//     java.lang.String var44 = var43.getText();
//     org.jfree.data.general.WaferMapDataset var48 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var49 = null;
//     org.jfree.chart.plot.WaferMapPlot var50 = new org.jfree.chart.plot.WaferMapPlot(var48, var49);
//     java.awt.Font var51 = var50.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
//     var52.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var55 = var52.getPlot();
//     java.lang.String var56 = var52.getLabel();
//     java.awt.Paint var57 = var52.getLabelPaint();
//     org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("", var51, var57);
//     java.awt.Font var59 = var58.getFont();
//     org.jfree.chart.text.TextLine var60 = new org.jfree.chart.text.TextLine("", var59);
//     org.jfree.data.general.WaferMapDataset var61 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var62 = null;
//     org.jfree.chart.plot.WaferMapPlot var63 = new org.jfree.chart.plot.WaferMapPlot(var61, var62);
//     java.awt.Font var64 = var63.getNoDataMessageFont();
//     var63.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart("ThreadContext", var59, (org.jfree.chart.plot.Plot)var63, false);
//     java.lang.Object var69 = var68.clone();
//     var43.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var68);
//     java.awt.Stroke var71 = var68.getBorderStroke();
//     var68.removeLegend();
//     boolean var73 = var37.equals((java.lang.Object)var68);
//     org.jfree.chart.text.TextAnchor var74 = var37.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var75 = org.jfree.chart.text.TextUtilities.drawAlignedString("PieSection: -1, -1(1.0)", var1, 0.0f, 1.0f, var74);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.lang.Object var2 = var1.clone();
//     boolean var3 = var1.getSimpleLabels();
//     org.jfree.chart.plot.DrawingSupplier var4 = var1.getDrawingSupplier();
//     org.jfree.chart.plot.DrawingSupplier var5 = var1.getDrawingSupplier();
//     boolean var6 = var1.getSimpleLabels();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     double var11 = var10.getMaximumExplodePercent();
//     int var12 = var10.getPieIndex();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     double var14 = var13.getLowerMargin();
//     java.util.Date var15 = var13.getMinimumDate();
//     double var16 = var13.getLowerBound();
//     org.jfree.chart.text.TextBlock var17 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var18 = var17.getLineAlignment();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var17.calculateBounds(var19, (-1.0f), 100.0f, var22, (-1.0f), 1.0f, 0.0d);
//     var13.setRightArrow(var26);
//     boolean var28 = var10.equals((java.lang.Object)var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.chart.plot.PiePlotState var31 = var1.initialise(var7, var8, (org.jfree.chart.plot.PiePlot)var10, (java.lang.Integer)10, var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.String var14 = var13.getLabel();
//     var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
//     org.jfree.chart.text.TextAnchor var16 = var13.getLabelTextAnchor();
//     java.lang.Class var17 = null;
//     java.util.EventListener[] var18 = var13.getListeners(var17);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    boolean var3 = var0.isRangeCrosshairVisible();
    boolean var4 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(10);
    org.jfree.data.category.CategoryDataset var7 = null;
    var0.setDataset(var7);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    var9.setCategoryMargin(0.0d);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    var12.setCategoryMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
    var16.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var19 = var16.getPlot();
    java.lang.String var20 = var16.getLabel();
    java.awt.Paint var21 = var16.getLabelPaint();
    var12.setTickLabelPaint((java.lang.Comparable)(byte)0, var21);
    var9.setLabelPaint(var21);
    var0.setDomainAxis(var9);
    var0.mapDatasetToDomainAxis(255, 100);
    org.jfree.chart.annotations.CategoryAnnotation var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     double var1 = var0.getLowerMargin();
//     org.jfree.chart.axis.Timeline var2 = null;
//     var0.setTimeline(var2);
//     java.awt.Shape var4 = var0.getLeftArrow();
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var7 = null;
//     org.jfree.chart.plot.WaferMapPlot var8 = new org.jfree.chart.plot.WaferMapPlot(var6, var7);
//     java.awt.Font var9 = var8.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     var10.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var13 = var10.getPlot();
//     java.lang.String var14 = var10.getLabel();
//     java.awt.Paint var15 = var10.getLabelPaint();
//     org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var9, var15);
//     var0.setAxisLinePaint(var15);
//     java.util.Date var18 = var0.getMinimumDate();
//     org.jfree.chart.axis.DateTickUnit var19 = null;
//     java.util.Date var20 = var0.calculateHighestVisibleTickValue(var19);
// 
//   }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "hi!", "ThreadContext", var3, "", "", "");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.lang.String var10 = var7.getLicenceText();
    var7.setName("");
    java.util.List var13 = var7.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + ""+ "'", var10.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.general.WaferMapDataset var3 = null;
    org.jfree.chart.renderer.WaferMapRenderer var4 = null;
    org.jfree.chart.plot.WaferMapPlot var5 = new org.jfree.chart.plot.WaferMapPlot(var3, var4);
    java.awt.Font var6 = var5.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    var7.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var10 = var7.getPlot();
    java.lang.String var11 = var7.getLabel();
    java.awt.Paint var12 = var7.getLabelPaint();
    org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var6, var12);
    java.awt.Font var14 = var13.getFont();
    org.jfree.chart.text.TextLine var15 = new org.jfree.chart.text.TextLine("", var14);
    org.jfree.data.general.WaferMapDataset var16 = null;
    org.jfree.chart.renderer.WaferMapRenderer var17 = null;
    org.jfree.chart.plot.WaferMapPlot var18 = new org.jfree.chart.plot.WaferMapPlot(var16, var17);
    java.awt.Font var19 = var18.getNoDataMessageFont();
    var18.setBackgroundAlpha((-1.0f));
    org.jfree.chart.JFreeChart var23 = new org.jfree.chart.JFreeChart("ThreadContext", var14, (org.jfree.chart.plot.Plot)var18, false);
    java.lang.Object var24 = var23.getTextAntiAlias();
    org.jfree.chart.event.ChartProgressListener var25 = null;
    var23.removeProgressListener(var25);
    org.jfree.chart.event.ChartProgressListener var27 = null;
    var23.removeProgressListener(var27);
    org.jfree.chart.title.Title var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.addSubtitle(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var14 = var13.getLabel();
    var11.addDomainMarker((org.jfree.chart.plot.Marker)var13);
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    boolean var18 = var17.isInverted();
    org.jfree.chart.axis.NumberTickUnit var19 = var17.getTickUnit();
    boolean var20 = var17.isAutoTickUnitSelection();
    var17.setAutoRangeIncludesZero(true);
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var17};
    var11.setRangeAxes(var23);
    java.awt.Graphics2D var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.text.TextBlock var27 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var28 = null;
    org.jfree.chart.util.Size2D var29 = var27.calculateDimensions(var28);
    java.util.List var30 = var27.getLines();
    var11.drawDomainTickBands(var25, var26, var30);
    org.jfree.data.xy.XYDataset var32 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = var11.getRendererForDataset(var32);
    var11.setDomainCrosshairVisible(false);
    java.awt.Color var38 = java.awt.Color.getColor("XY Plot", (-1));
    java.awt.color.ColorSpace var39 = var38.getColorSpace();
    float[] var46 = new float[] { 100.0f, 10.0f, 10.0f};
    float[] var47 = java.awt.Color.RGBtoHSB((-253), (-1), 100, var46);
    float[] var48 = var38.getColorComponents(var46);
    var11.setDomainTickBandPaint((java.awt.Paint)var38);
    boolean var50 = var11.isDomainZeroBaselineVisible();
    org.jfree.chart.util.RectangleInsets var51 = new org.jfree.chart.util.RectangleInsets();
    double var52 = var51.getTop();
    org.jfree.data.general.WaferMapDataset var54 = null;
    org.jfree.chart.renderer.WaferMapRenderer var55 = null;
    org.jfree.chart.plot.WaferMapPlot var56 = new org.jfree.chart.plot.WaferMapPlot(var54, var55);
    java.awt.Font var57 = var56.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var58 = new org.jfree.chart.axis.CategoryAxis();
    var58.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var61 = var58.getPlot();
    java.lang.String var62 = var58.getLabel();
    java.awt.Paint var63 = var58.getLabelPaint();
    org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("", var57, var63);
    org.jfree.chart.block.BlockBorder var65 = new org.jfree.chart.block.BlockBorder(var51, var63);
    double var67 = var51.calculateLeftInset((-1.0d));
    double var68 = var51.getRight();
    var11.setAxisOffset(var51);
    org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.String var72 = var71.getLabel();
    org.jfree.chart.util.RectangleAnchor var73 = var71.getLabelAnchor();
    org.jfree.chart.util.Layer var74 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addDomainMarker((org.jfree.chart.plot.Marker)var71, var74);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisLocation var2 = null;
    var0.setRangeAxisLocation(4, var2, false);
    java.awt.Paint var5 = var0.getDomainGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxis((-253), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = null;
    var0.setFixedLegendItems(var1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    var0.setRenderer(0, var4, true);
    boolean var7 = var0.getDrawSharedDomainAxis();
    org.jfree.data.category.CategoryDataset var8 = var0.getDataset();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var10.setAutoRangeIncludesZero(true);
    var10.setAutoRangeStickyZero(true);
    var10.setRange(1.0d, 100.0d);
    org.jfree.data.Range var18 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var0.setDrawSharedDomainAxis(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAnchor var3 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var0.getCategoryJava2DCoordinate(var3, 100, 1, var6, var7);
//     var0.setMaximumCategoryLabelWidthRatio(100.0f);
//     java.awt.Paint var11 = var0.getTickMarkPaint();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D(var13);
//     double var15 = var14.getDepthFactor();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.text.TextBlock var17 = new org.jfree.chart.text.TextBlock();
//     org.jfree.chart.util.HorizontalAlignment var18 = var17.getLineAlignment();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var17.calculateBounds(var19, (-1.0f), 100.0f, var22, (-1.0f), 1.0f, 0.0d);
//     org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity(var26);
//     org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis();
//     double var29 = var28.getLowerMargin();
//     boolean var30 = var28.isVisible();
//     org.jfree.chart.axis.Timeline var31 = var28.getTimeline();
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
//     var32.setToolTipText("");
//     boolean var35 = var28.equals((java.lang.Object)var32);
//     org.jfree.chart.util.RectangleEdge var36 = var32.getPosition();
//     boolean var37 = var27.equals((java.lang.Object)var36);
//     org.jfree.chart.axis.AxisSpace var38 = null;
//     org.jfree.chart.axis.AxisSpace var39 = var0.reserveSpace(var12, (org.jfree.chart.plot.Plot)var14, var16, var36, var38);
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    double var2 = var1.getLowerMargin();
    boolean var3 = var1.isTickMarksVisible();
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
    var5.setAutoRangeIncludesZero(true);
    var5.setAutoRangeStickyZero(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
    var11.configureRangeAxes();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    java.lang.Object var15 = var14.clone();
    var14.setSectionDepth(0.0d);
    var14.setInnerSeparatorExtension(100.0d);
    double var20 = var14.getSectionDepth();
    org.jfree.data.general.WaferMapDataset var22 = null;
    org.jfree.chart.renderer.WaferMapRenderer var23 = null;
    org.jfree.chart.plot.WaferMapPlot var24 = new org.jfree.chart.plot.WaferMapPlot(var22, var23);
    java.awt.Font var25 = var24.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
    var26.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var29 = var26.getPlot();
    java.lang.String var30 = var26.getLabel();
    java.awt.Paint var31 = var26.getLabelPaint();
    org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("", var25, var31);
    var14.setLabelShadowPaint(var31);
    var11.setRangeZeroBaselinePaint(var31);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var37 = null;
    var36.setFixedLegendItems(var37);
    boolean var39 = var36.isRangeCrosshairVisible();
    boolean var40 = var36.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var42 = var36.getDomainAxisLocation(10);
    var11.setDomainAxisLocation(4, var42);
    var11.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    double var1 = var0.getLowerMargin();
    org.jfree.chart.axis.Timeline var2 = null;
    var0.setTimeline(var2);
    java.awt.Shape var4 = var0.getLeftArrow();
    org.jfree.data.general.WaferMapDataset var6 = null;
    org.jfree.chart.renderer.WaferMapRenderer var7 = null;
    org.jfree.chart.plot.WaferMapPlot var8 = new org.jfree.chart.plot.WaferMapPlot(var6, var7);
    java.awt.Font var9 = var8.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    var10.setCategoryMargin(0.0d);
    org.jfree.chart.plot.Plot var13 = var10.getPlot();
    java.lang.String var14 = var10.getLabel();
    java.awt.Paint var15 = var10.getLabelPaint();
    org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var9, var15);
    var0.setAxisLinePaint(var15);
    java.awt.Shape var18 = var0.getUpArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot();
//     var0.add(var1, (java.lang.Object)var2);
//     org.jfree.chart.labels.PieSectionLabelGenerator var4 = var2.getLegendLabelGenerator();
//     boolean var5 = var2.getIgnoreZeroValues();
//     org.jfree.chart.LegendItemCollection var6 = var2.getLegendItems();
//     org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot();
//     org.jfree.chart.LegendItemCollection var8 = var7.getLegendItems();
//     var6.addAll(var8);
//     
//     // Checks the contract:  equals-hashcode on var6 and var8
//     assertTrue("Contract failed: equals-hashcode on var6 and var8", var6.equals(var8) ? var6.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var6
//     assertTrue("Contract failed: equals-hashcode on var8 and var6", var8.equals(var6) ? var8.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     var0.setCategoryMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
//     var4.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var7 = var4.getPlot();
//     java.lang.String var8 = var4.getLabel();
//     java.awt.Paint var9 = var4.getLabelPaint();
//     var0.setTickLabelPaint((java.lang.Comparable)(byte)0, var9);
//     var0.addCategoryLabelToolTip((java.lang.Comparable)(-1.0f), "");
//     boolean var14 = var0.isAxisLineVisible();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     double var20 = var19.getLowerMargin();
//     boolean var21 = var19.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var23.setAutoRangeIncludesZero(true);
//     var23.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     var29.configureRangeAxes();
//     org.jfree.chart.util.RectangleEdge var31 = var29.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var32 = org.jfree.chart.util.RectangleEdge.opposite(var31);
//     double var33 = var0.getCategoryEnd((-253), 10, var17, var31);
// 
//   }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     double var2 = var1.getLowerMargin();
//     boolean var3 = var1.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var5.setAutoRangeIncludesZero(true);
//     var5.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var5, var10);
//     boolean var12 = var11.isDomainZeroBaselineVisible();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     var13.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var16 = var13.getPlot();
//     java.lang.String var17 = var13.getLabel();
//     java.awt.Paint var18 = var13.getLabelPaint();
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(var18);
//     var11.setDomainTickBandPaint(var18);
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     var11.drawAnnotations(var21, var22, var23);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var26.setFixedLegendItems(var27);
//     boolean var29 = var26.isRangeCrosshairVisible();
//     boolean var30 = var26.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var32 = var26.getDomainAxisLocation(10);
//     var11.setRangeAxisLocation(10, var32);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.data.general.WaferMapDataset var39 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var40 = null;
//     org.jfree.chart.plot.WaferMapPlot var41 = new org.jfree.chart.plot.WaferMapPlot(var39, var40);
//     java.awt.Font var42 = var41.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis();
//     var43.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var46 = var43.getPlot();
//     java.lang.String var47 = var43.getLabel();
//     java.awt.Paint var48 = var43.getLabelPaint();
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("", var42, var48);
//     java.awt.Font var50 = var49.getFont();
//     org.jfree.chart.text.TextLine var51 = new org.jfree.chart.text.TextLine("", var50);
//     var36.setLabelFont(var50);
//     org.jfree.chart.util.Layer var53 = null;
//     var11.addRangeMarker((-253), (org.jfree.chart.plot.Marker)var36, var53);
//     org.jfree.data.general.WaferMapDataset var58 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var59 = null;
//     org.jfree.chart.plot.WaferMapPlot var60 = new org.jfree.chart.plot.WaferMapPlot(var58, var59);
//     java.awt.Font var61 = var60.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis();
//     var62.setCategoryMargin(0.0d);
//     org.jfree.chart.plot.Plot var65 = var62.getPlot();
//     java.lang.String var66 = var62.getLabel();
//     java.awt.Paint var67 = var62.getLabelPaint();
//     org.jfree.chart.text.TextFragment var68 = new org.jfree.chart.text.TextFragment("", var61, var67);
//     java.awt.Font var69 = var68.getFont();
//     org.jfree.chart.text.TextLine var70 = new org.jfree.chart.text.TextLine("", var69);
//     org.jfree.data.general.WaferMapDataset var71 = null;
//     org.jfree.chart.renderer.WaferMapRenderer var72 = null;
//     org.jfree.chart.plot.WaferMapPlot var73 = new org.jfree.chart.plot.WaferMapPlot(var71, var72);
//     java.awt.Font var74 = var73.getNoDataMessageFont();
//     var73.setBackgroundAlpha((-1.0f));
//     org.jfree.chart.JFreeChart var78 = new org.jfree.chart.JFreeChart("ThreadContext", var69, (org.jfree.chart.plot.Plot)var73, false);
//     java.awt.Image var79 = var78.getBackgroundImage();
//     org.jfree.chart.title.TextTitle var81 = new org.jfree.chart.title.TextTitle("");
//     var78.setTitle(var81);
//     java.awt.Stroke var83 = var78.getBorderStroke();
//     org.jfree.chart.ChartRenderingInfo var88 = null;
//     java.awt.image.BufferedImage var89 = var78.createBufferedImage(255, 10, (-13.95d), 101.0d, var88);
//     var11.setBackgroundImage((java.awt.Image)var89);
//     
//     // Checks the contract:  equals-hashcode on var41 and var60
//     assertTrue("Contract failed: equals-hashcode on var41 and var60", var41.equals(var60) ? var41.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var41
//     assertTrue("Contract failed: equals-hashcode on var60 and var41", var60.equals(var41) ? var60.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var1 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot();
//     var1.add(var2, (java.lang.Object)var3);
//     org.jfree.chart.labels.PieSectionLabelGenerator var5 = var3.getLegendLabelToolTipGenerator();
//     org.jfree.data.general.PieDataset var6 = var3.getDataset();
//     org.jfree.chart.labels.PieToolTipGenerator var7 = var3.getToolTipGenerator();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.RingPlot var9 = new org.jfree.chart.plot.RingPlot(var8);
//     java.lang.Object var10 = var9.clone();
//     var9.setLabelGap(10.0d);
//     java.awt.Paint var13 = var9.getLabelOutlinePaint();
//     var3.setLabelOutlinePaint(var13);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
//     double var17 = var16.getLowerMargin();
//     boolean var18 = var16.isTickMarksVisible();
//     org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//     var20.setAutoRangeIncludesZero(true);
//     var20.setAutoRangeStickyZero(true);
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var20, var25);
//     org.jfree.data.general.DatasetGroup var27 = var26.getDatasetGroup();
//     var26.setRangeGridlinesVisible(false);
//     org.jfree.chart.block.ColumnArrangement var30 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.Block var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot();
//     var30.add(var31, (java.lang.Object)var32);
//     org.jfree.chart.labels.PieSectionLabelGenerator var34 = var32.getLegendLabelGenerator();
//     var32.setMinimumArcAngleToDraw(0.05d);
//     java.awt.Stroke var37 = var32.getBaseSectionOutlineStroke();
//     var26.setDomainCrosshairStroke(var37);
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(0.2d, var13, var37);
//     
//     // Checks the contract:  equals-hashcode on var1 and var30
//     assertTrue("Contract failed: equals-hashcode on var1 and var30", var1.equals(var30) ? var1.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var1
//     assertTrue("Contract failed: equals-hashcode on var30 and var1", var30.equals(var1) ? var30.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.chart.util.UnitType var1 = var0.getUnitType();
    double var3 = var0.extendWidth(0.0d);
    double var5 = var0.calculateLeftInset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

}
