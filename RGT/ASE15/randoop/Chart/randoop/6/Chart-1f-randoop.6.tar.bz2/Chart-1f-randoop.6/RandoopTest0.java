
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    java.awt.Stroke var6 = null;
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("", "", "", "hi!", var4, var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    java.awt.Stroke var6 = null;
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("", "", "hi!", "", var4, var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.chart.event.DatasetChangeInfo var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.event.DatasetChangeEvent var3 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)1, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem(var0, "hi!", "", "hi!", var4, (java.awt.Paint)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(0, 10, 1);
    float[] var6 = new float[] { 100.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var7 = var3.getColorComponents(var6);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.Plot var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var4 = new org.jfree.chart.entity.PlotEntity(var0, var1, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var9 = var8.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem(var0, "", "", "", var4, (java.awt.Paint)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var9.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", var1, var2);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getRowKey((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", var1);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var6 = new org.jfree.chart.entity.CategoryItemEntity(var0, "", "hi!", var3, (java.lang.Comparable)(short)100, (java.lang.Comparable)0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    float[] var5 = new float[] { 0.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(1, 1, 0, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.data.category.CategoryDataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var3 = var0.generateLabel(var1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     var0.addAll(var2);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBoolean((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    java.awt.Shape var5 = null;
    org.jfree.chart.util.DefaultShadowGenerator var7 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var8 = var7.getShadowColor();
    int var9 = var8.getAlpha();
    java.awt.Color var10 = var8.darker();
    org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.awt.Stroke var16 = null;
    java.awt.Shape var18 = null;
    java.awt.Stroke var19 = null;
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var22 = var21.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "", true, var5, true, (java.awt.Paint)var10, true, (java.awt.Paint)var15, var16, false, var18, var19, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)10.0d, var6);
    boolean var8 = var0.equals((java.lang.Object)10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)1);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    java.util.List var3 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject(10, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var2
//     assertTrue("Contract failed: equals-hashcode on var1 and var2", var1.equals(var2) ? var1.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var1
//     assertTrue("Contract failed: equals-hashcode on var2 and var1", var2.equals(var1) ? var2.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    java.util.List var3 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var7 = var6.getShape();
    org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var10 = var9.getShadowColor();
    int var11 = var10.getAlpha();
    java.awt.Color var12 = var10.darker();
    org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(255, 255, 1);
    java.awt.Stroke var18 = null;
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var22 = null;
    var21.setOutlineStroke(var22);
    int var24 = var21.getSeriesIndex();
    java.awt.Stroke var25 = var21.getOutlineStroke();
    java.awt.Shape var26 = var21.getShape();
    java.awt.Stroke var27 = null;
    org.jfree.chart.util.DefaultShadowGenerator var28 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var29 = var28.getShadowColor();
    int var30 = var29.getAlpha();
    java.awt.Color var31 = var29.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem(var0, "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", false, var7, false, (java.awt.Paint)var12, true, (java.awt.Paint)var17, var18, true, var26, var27, (java.awt.Paint)var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    java.awt.Stroke var5 = var1.getOutlineStroke();
    java.awt.Shape var6 = var1.getShape();
    org.jfree.data.category.CategoryDataset var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var12 = new org.jfree.chart.entity.CategoryItemEntity(var6, "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "", var9, (java.lang.Comparable)1L, (java.lang.Comparable)(-1L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var7 = var6.getShape();
    org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var10 = var9.getShadowColor();
    int var11 = var10.getAlpha();
    java.awt.Color var12 = var10.darker();
    int var13 = var12.getGreen();
    org.jfree.chart.ChartColor var18 = new org.jfree.chart.ChartColor(255, 255, 1);
    java.awt.Stroke var19 = null;
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var23 = var22.getShape();
    java.awt.Stroke var24 = null;
    org.jfree.chart.util.DefaultShadowGenerator var25 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var26 = var25.getShadowColor();
    int var27 = var26.getAlpha();
    java.awt.Color var28 = var26.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("hi!", "hi!", "", "hi!", false, var7, false, (java.awt.Paint)var12, false, (java.awt.Paint)var18, var19, false, var23, var24, (java.awt.Paint)var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    java.awt.Paint var7 = null;
    java.awt.Stroke var8 = null;
    org.jfree.chart.ChartColor var12 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var13 = var12.toString();
    java.awt.Color var14 = var12.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "hi!", "hi!", var6, var7, var8, (java.awt.Paint)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var13.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    int var6 = var0.getRowCount();
    java.util.List var7 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.util.GradientPaintTransformer var4 = var1.getFillPaintTransformer();
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4, var5, var6);
    java.lang.Object var8 = var7.getSource();
    org.jfree.chart.JFreeChart var9 = var7.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(0, 10, 1);
//     java.lang.String var4 = var3.toString();
//     java.awt.Color var5 = var3.darker();
//     java.awt.color.ColorSpace var6 = null;
//     org.jfree.chart.util.DefaultShadowGenerator var8 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var9 = var8.getShadowColor();
//     int var10 = var9.getAlpha();
//     java.awt.Color var11 = var9.darker();
//     int var12 = var11.getGreen();
//     java.awt.Color var13 = java.awt.Color.getColor("", var11);
//     float[] var14 = null;
//     float[] var15 = var13.getComponents(var14);
//     float[] var16 = var5.getColorComponents(var6, var15);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var7 = null;
    var6.setOutlineStroke(var7);
    int var9 = var6.getSeriesIndex();
    java.awt.Stroke var10 = var6.getOutlineStroke();
    java.awt.Shape var11 = var6.getShape();
    org.jfree.chart.util.DefaultShadowGenerator var13 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var14 = var13.getShadowColor();
    int var15 = var14.getAlpha();
    java.awt.Color var16 = var14.darker();
    org.jfree.chart.ChartColor var21 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.awt.image.ColorModel var22 = null;
    java.awt.Rectangle var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    java.awt.geom.AffineTransform var25 = null;
    java.awt.RenderingHints var26 = null;
    java.awt.PaintContext var27 = var21.createContext(var22, var23, var24, var25, var26);
    java.awt.Stroke var28 = null;
    java.awt.Shape var30 = null;
    java.awt.Stroke var31 = null;
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var34 = var33.getShape();
    java.awt.Paint var35 = var33.getLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", true, var11, false, (java.awt.Paint)var16, false, (java.awt.Paint)var21, var28, false, var30, var31, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var6 = new org.jfree.chart.entity.CategoryItemEntity(var0, "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var3, (java.lang.Comparable)0, (java.lang.Comparable)(byte)1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("org.jfree.chart.ChartColor[r=0,g=10,b=1]", var1, var2);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", var1);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    java.awt.Shape[] var0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.SelectableValue var2 = new org.jfree.data.SelectableValue((java.lang.Number)(short)(-1), false);
    boolean var3 = var2.isSelected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)10.0d, var6);
    boolean var8 = var0.equals((java.lang.Object)10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var11 = var0.getObject(1, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     java.awt.geom.Rectangle2D var5 = null;
//     var4.trim(var5);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.LengthAdjustmentType var8 = null;
    org.jfree.chart.util.LengthAdjustmentType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var4.createAdjustedRectangle(var7, var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 0.5f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-127));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, (-9.21460183660255d), (-0.7853981633974483d), (-9.21460183660255d), 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var1 = var0.getShadowColor();
    int var2 = var1.getAlpha();
    float[] var4 = new float[] { 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = var1.getColorComponents(var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var1 = var0.getDistance();
//     java.awt.image.BufferedImage var2 = null;
//     java.awt.image.BufferedImage var3 = var0.createDropShadow(var2);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(0, (-2), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(255);
    java.awt.Shape var8 = null;
    org.jfree.chart.ChartColor var12 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var13 = var12.toString();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "", "", "", var8, (java.awt.Paint)var12);
    int var15 = var12.getAlpha();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-127), (java.awt.Paint)var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var13.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 255);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.calculateTopInset(0.0d);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.LengthAdjustmentType var10 = null;
    org.jfree.chart.util.LengthAdjustmentType var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var4.createAdjustedRectangle(var9, var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.7853981633974483d));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    java.util.List var3 = var0.getRowKeys();
    int var4 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var0.getColumnKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    int var15 = var12.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    var12.setLinePaint((java.awt.Paint)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesOutlinePaint((-2), (java.awt.Paint)var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.util.DefaultShadowGenerator var4 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var5 = var4.getShadowColor();
    int var6 = var5.getAlpha();
    java.awt.Color var7 = var5.darker();
    int var8 = var7.getGreen();
    java.awt.Color var9 = java.awt.Color.getColor("", var7);
    java.awt.Paint[] var10 = new java.awt.Paint[] { var7};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var12 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var15 = var14.getOutlinePaint();
    boolean var16 = var12.equals((java.lang.Object)var15);
    java.awt.Paint[] var17 = new java.awt.Paint[] { var15};
    org.jfree.chart.util.DefaultShadowGenerator var19 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var20 = var19.getShadowColor();
    int var21 = var20.getAlpha();
    java.awt.Color var22 = var20.darker();
    int var23 = var22.getGreen();
    java.awt.Color var24 = java.awt.Color.getColor("", var22);
    float[] var25 = null;
    float[] var26 = var24.getComponents(var25);
    java.awt.Paint[] var27 = new java.awt.Paint[] { var24};
    java.awt.Stroke var28 = null;
    java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
    java.awt.Stroke var30 = null;
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var34 = null;
    var33.setOutlineStroke(var34);
    int var36 = var33.getSeriesIndex();
    java.awt.Stroke var37 = var33.getOutlineStroke();
    java.awt.Shape var38 = var33.getShape();
    java.awt.Shape[] var39 = new java.awt.Shape[] { var38};
    org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var17, var27, var29, var31, var39);
    java.awt.Paint var41 = var40.getNextOutlinePaint();
    java.awt.Paint var42 = var40.getNextOutlinePaint();
    java.lang.Comparable var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addObject((java.lang.Object)var40, (java.lang.Comparable)(-2), var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var2 = var1.clone();
    org.jfree.chart.util.PaintList var4 = new org.jfree.chart.util.PaintList();
    var1.set(0, (java.lang.Object)var4);
    org.jfree.chart.util.DefaultShadowGenerator var6 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var7 = var1.indexOf((java.lang.Object)var6);
    float var8 = var6.getShadowOpacity();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.5f);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    java.util.List var3 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject((java.lang.Comparable)"org.jfree.chart.ChartColor[r=0,g=10,b=1]", (java.lang.Comparable)100L);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.calculateTopInset(0.0d);
    double var10 = var4.extendWidth((-1.0d));
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var4.createInsetRectangle(var11, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 8.21460183660255d);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     java.awt.Paint var12 = var1.getItemLabelPaint((-2), 0);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Shape var4 = var1.getShape();
    org.jfree.chart.plot.Plot var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var6 = new org.jfree.chart.entity.PlotEntity(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), 0, (-2));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4, var5, var6);
    org.jfree.chart.event.ChartChangeEventType var8 = null;
    var7.setType(var8);
    java.lang.String var10 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=-1]"+ "'", var10.equals("org.jfree.chart.event.ChartChangeEvent[source=-1]"));

  }

  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     double var1 = var0.getAngle();
//     float var2 = var0.getShadowOpacity();
//     java.awt.image.BufferedImage var3 = null;
//     java.awt.image.BufferedImage var4 = var0.createDropShadow(var3);
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     var1.setDatasetIndex(0);
//     var1.setSeriesIndex(0);
//     org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var8 = null;
//     var7.setOutlineStroke(var8);
//     var7.setURLText("");
//     java.awt.Paint var12 = var7.getLabelPaint();
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var15 = var14.getShape();
//     var7.setShape(var15);
//     var1.setShape(var15);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("");
    var2.setDatasetIndex(0);
    java.awt.Paint var5 = var2.getFillPaint();
    org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var5);
    org.jfree.chart.JFreeChart var8 = null;
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)100.0d, var8, var9);
    boolean var11 = var6.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("org.jfree.chart.event.ChartChangeEvent[source=-1]", var1, var2);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
    var1.setDefaultFillPaint((java.awt.Paint)var13);
    java.awt.Paint var17 = var1.getItemFillPaint(0, 0);
    org.jfree.chart.ChartColor var24 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var25 = var24.toString();
    java.awt.Color var26 = var24.darker();
    java.awt.Color var27 = java.awt.Color.getColor("org.jfree.chart.ChartColor[r=0,g=10,b=1]", var26);
    java.awt.Color var28 = java.awt.Color.getColor("hi!", var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesOutlinePaint((-1), (java.awt.Paint)var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var25.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Shape var4 = var1.getShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var4, "");
    var6.setToolTipText("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    int var6 = var0.getRowCount();
    java.util.List var7 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var10 = var0.getObject(0, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    java.awt.Paint var4 = var1.getItemOutlinePaint((-1), 10);
    java.awt.Paint var7 = var1.getItemOutlinePaint(0, (-127));
    java.awt.Paint var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDefaultFillPaint(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     var1.setURLText("");
//     java.awt.Paint var6 = var1.getLabelPaint();
//     java.awt.Shape var11 = null;
//     org.jfree.chart.ChartColor var15 = new org.jfree.chart.ChartColor(0, 10, 1);
//     java.lang.String var16 = var15.toString();
//     org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("", "", "", "", var11, (java.awt.Paint)var15);
//     int var18 = var15.getAlpha();
//     var1.setFillPaint((java.awt.Paint)var15);
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     java.awt.geom.AffineTransform var23 = null;
//     java.awt.RenderingHints var24 = null;
//     java.awt.PaintContext var25 = var15.createContext(var20, var21, var22, var23, var24);
//     java.awt.color.ColorSpace var26 = null;
//     float[] var29 = new float[] { 100.0f, (-1.0f)};
//     float[] var30 = var15.getComponents(var26, var29);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     java.awt.Font var11 = var1.getSeriesLabelFont((-127));
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     var5.setDatasetIndex(0);
//     java.awt.Shape var8 = var5.getShape();
//     org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var8, "");
//     org.jfree.chart.renderer.RenderAttributes var12 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("");
//     var15.setDatasetIndex(0);
//     java.awt.Paint var18 = var15.getFillPaint();
//     org.jfree.data.KeyedObject var19 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var18);
//     var12.setDefaultLabelPaint(var18);
//     org.jfree.chart.ChartColor var24 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var12.setDefaultFillPaint((java.awt.Paint)var24);
//     java.awt.Paint var28 = var12.getItemFillPaint(0, 0);
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     int var33 = var30.getSeriesIndex();
//     java.awt.Stroke var34 = var30.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var36 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var37 = var36.getShadowColor();
//     int var38 = var37.getAlpha();
//     java.awt.Color var39 = var37.darker();
//     int var40 = var39.getGreen();
//     java.awt.Color var41 = java.awt.Color.getColor("", var39);
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "hi!", var8, var28, var34, (java.awt.Paint)var41);
//     
//     // Checks the contract:  equals-hashcode on var5 and var15
//     assertTrue("Contract failed: equals-hashcode on var5 and var15", var5.equals(var15) ? var5.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var5
//     assertTrue("Contract failed: equals-hashcode on var15 and var5", var15.equals(var5) ? var15.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    java.awt.Stroke var5 = var1.getLineStroke();
    java.lang.Object var6 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var17 = var1.getItemFillPaint(0, 0);
//     java.awt.Font var18 = var1.getDefaultLabelFont();
//     var1.setSeriesCreateEntity(255, (java.lang.Boolean)true);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     java.awt.Paint var10 = var1.getDefaultLabelPaint();
//     java.lang.Boolean var12 = var1.getSeriesCreateEntity(1);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Shape var4 = var1.getShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var4, "");
    java.awt.Shape var7 = var6.getArea();
    org.jfree.chart.plot.Plot var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var9 = new org.jfree.chart.entity.PlotEntity(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    var0.clear();
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("");
    var9.setDatasetIndex(0);
    java.awt.Paint var12 = var9.getFillPaint();
    org.jfree.data.KeyedObject var13 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var12);
    java.lang.Object var14 = var13.getObject();
    java.lang.Object var15 = var13.clone();
    java.lang.Comparable var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addObject((java.lang.Object)var13, (java.lang.Comparable)(-127), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var17 = var1.getItemFillPaint(0, 0);
//     org.jfree.chart.util.PaintList var19 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.renderer.RenderAttributes var22 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("");
//     var25.setDatasetIndex(0);
//     java.awt.Paint var28 = var25.getFillPaint();
//     org.jfree.data.KeyedObject var29 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var28);
//     var22.setDefaultLabelPaint(var28);
//     org.jfree.chart.ChartColor var34 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var22.setDefaultFillPaint((java.awt.Paint)var34);
//     var19.setPaint(1, (java.awt.Paint)var34);
//     var1.setSeriesOutlinePaint(100, (java.awt.Paint)var34);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var29
//     assertTrue("Contract failed: equals-hashcode on var8 and var29", var8.equals(var29) ? var8.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var8
//     assertTrue("Contract failed: equals-hashcode on var29 and var8", var29.equals(var8) ? var29.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    java.lang.Object var0 = null;
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    java.util.List var3 = var0.getRowKeys();
    var0.setObject((java.lang.Object)"org.jfree.chart.event.ChartChangeEvent[source=-1]", (java.lang.Comparable)(-9.21460183660255d), (java.lang.Comparable)1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.LegendItemCollection var1 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var2 = var1.clone();
//     var0.addAll(var1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.labels.ItemLabelPosition var1 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var2 = var1.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var3 = new org.jfree.chart.labels.ItemLabelPosition(var0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(5, (-2), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var3 = var2.getShadowColor();
    int var4 = var3.getAlpha();
    java.awt.Color var5 = var3.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-127), (java.awt.Paint)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(10, 1, 0);
//     java.awt.color.ColorSpace var4 = null;
//     float[] var7 = new float[] { 0.0f, 100.0f};
//     float[] var8 = var3.getColorComponents(var4, var7);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var3 = var0.get(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.trimHeight((-9.21460183660255d));
    double var10 = var4.calculateBottomInset(8.21460183660255d);
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var4.createInsetRectangle(var11, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.0d);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var7 = var4.getRight();
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var11 = var4.createOutsetRectangle(var8, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.7853981633974483d));

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, (-108.42920367320511d), (-9.21460183660255d), 8.21460183660255d, (-9.21460183660255d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     java.awt.Paint var10 = var1.getDefaultLabelPaint();
//     java.awt.Stroke var12 = var1.getSeriesOutlineStroke(0);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.util.DefaultShadowGenerator var10 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var11 = var10.getShadowColor();
    int var12 = var11.getAlpha();
    java.awt.Color var13 = var11.darker();
    int var14 = var13.getGreen();
    java.awt.Color var15 = java.awt.Color.getColor("", var13);
    java.awt.Paint[] var16 = new java.awt.Paint[] { var13};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var21 = var20.getOutlinePaint();
    boolean var22 = var18.equals((java.lang.Object)var21);
    java.awt.Paint[] var23 = new java.awt.Paint[] { var21};
    org.jfree.chart.util.DefaultShadowGenerator var25 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var26 = var25.getShadowColor();
    int var27 = var26.getAlpha();
    java.awt.Color var28 = var26.darker();
    int var29 = var28.getGreen();
    java.awt.Color var30 = java.awt.Color.getColor("", var28);
    float[] var31 = null;
    float[] var32 = var30.getComponents(var31);
    java.awt.Paint[] var33 = new java.awt.Paint[] { var30};
    java.awt.Stroke var34 = null;
    java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
    java.awt.Stroke var36 = null;
    java.awt.Stroke[] var37 = new java.awt.Stroke[] { var36};
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var40 = null;
    var39.setOutlineStroke(var40);
    int var42 = var39.getSeriesIndex();
    java.awt.Stroke var43 = var39.getOutlineStroke();
    java.awt.Shape var44 = var39.getShape();
    java.awt.Shape[] var45 = new java.awt.Shape[] { var44};
    org.jfree.chart.plot.DefaultDrawingSupplier var46 = new org.jfree.chart.plot.DefaultDrawingSupplier(var16, var23, var33, var35, var37, var45);
    java.awt.Stroke var47 = var46.getNextOutlineStroke();
    java.awt.Paint var48 = var46.getNextPaint();
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var55 = var54.getShape();
    org.jfree.chart.JFreeChart var56 = null;
    org.jfree.chart.event.ChartChangeEvent var57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var55, var56);
    org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var60 = null;
    var59.setOutlineStroke(var60);
    int var62 = var59.getSeriesIndex();
    java.awt.Stroke var63 = var59.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var65 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var66 = var65.getShadowColor();
    int var67 = var66.getAlpha();
    java.awt.Color var68 = var66.darker();
    int var69 = var68.getGreen();
    java.awt.Color var70 = java.awt.Color.getColor("", var68);
    org.jfree.chart.LegendItem var71 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var55, var63, (java.awt.Paint)var68);
    org.jfree.chart.LegendItem var74 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var75 = var74.getOutlinePaint();
    org.jfree.chart.LegendItem var76 = new org.jfree.chart.LegendItem("hi!", var75);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem(var0, "", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=-1]", var6, var48, var63, var75);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getColumnCount();
    int var7 = var0.getRowIndex((java.lang.Comparable)100.0d);
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var10 = null;
    var9.setOutlineStroke(var10);
    int var12 = var9.getSeriesIndex();
    java.awt.Stroke var13 = var9.getOutlineStroke();
    java.awt.Shape var14 = var9.getShape();
    java.awt.Paint var15 = var9.getLinePaint();
    java.lang.Comparable var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setObject((java.lang.Object)var9, (java.lang.Comparable)10, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     var1.setDefaultLabelVisible((java.lang.Boolean)true);
//     org.jfree.chart.util.StrokeList var12 = new org.jfree.chart.util.StrokeList();
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var20 = var19.getShape();
//     org.jfree.chart.JFreeChart var21 = null;
//     org.jfree.chart.event.ChartChangeEvent var22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var20, var21);
//     org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var25 = null;
//     var24.setOutlineStroke(var25);
//     int var27 = var24.getSeriesIndex();
//     java.awt.Stroke var28 = var24.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var30 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var31 = var30.getShadowColor();
//     int var32 = var31.getAlpha();
//     java.awt.Color var33 = var31.darker();
//     int var34 = var33.getGreen();
//     java.awt.Color var35 = java.awt.Color.getColor("", var33);
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var20, var28, (java.awt.Paint)var33);
//     var12.setStroke(100, var28);
//     var1.setDefaultOutlineStroke(var28);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var2 = var1.getShadowColor();
//     int var3 = var2.getAlpha();
//     java.awt.Color var4 = var2.darker();
//     int var5 = var4.getGreen();
//     java.awt.Color var6 = java.awt.Color.getColor("", var4);
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var4};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var12 = var11.getOutlinePaint();
//     boolean var13 = var9.equals((java.lang.Object)var12);
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     float[] var22 = null;
//     float[] var23 = var21.getComponents(var22);
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var21};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     int var33 = var30.getSeriesIndex();
//     java.awt.Stroke var34 = var30.getOutlineStroke();
//     java.awt.Shape var35 = var30.getShape();
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var14, var24, var26, var28, var36);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var39 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var42 = var41.getOutlinePaint();
//     boolean var43 = var39.equals((java.lang.Object)var42);
//     boolean var44 = var37.equals((java.lang.Object)var42);
//     
//     // Checks the contract:  equals-hashcode on var11 and var41
//     assertTrue("Contract failed: equals-hashcode on var11 and var41", var11.equals(var41) ? var11.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var11
//     assertTrue("Contract failed: equals-hashcode on var41 and var11", var41.equals(var11) ? var41.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.trimWidth(109.21460183660255d);
    java.awt.geom.Rectangle2D var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var4.createOutsetRectangle(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0d);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var17 = null;
//     var16.setOutlineStroke(var17);
//     var16.setURLText("");
//     java.awt.Paint var21 = var16.getLabelPaint();
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var24 = var23.getShape();
//     var16.setShape(var24);
//     var1.setDefaultShape(var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var23
//     assertTrue("Contract failed: equals-hashcode on var4 and var23", var4.equals(var23) ? var4.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var4
//     assertTrue("Contract failed: equals-hashcode on var23 and var4", var23.equals(var4) ? var23.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    float[] var5 = new float[] { 100.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB((-2), 1, 0, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    int var2 = var1.getDatasetIndex();
    java.awt.Shape var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setShape(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var17 = var1.getItemFillPaint(0, 0);
//     java.awt.Font var18 = var1.getDefaultLabelFont();
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var26 = var25.getShape();
//     org.jfree.chart.JFreeChart var27 = null;
//     org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     int var33 = var30.getSeriesIndex();
//     java.awt.Stroke var34 = var30.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var36 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var37 = var36.getShadowColor();
//     int var38 = var37.getAlpha();
//     java.awt.Color var39 = var37.darker();
//     int var40 = var39.getGreen();
//     java.awt.Color var41 = java.awt.Color.getColor("", var39);
//     org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var26, var34, (java.awt.Paint)var39);
//     var1.setSeriesOutlineStroke(5, var34);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(10, 1, 0);
//     java.awt.color.ColorSpace var4 = null;
//     float[] var7 = new float[] { (-1.0f), 1.0f};
//     float[] var8 = var3.getColorComponents(var4, var7);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-16777216), (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var2 = null;
//     var1.setOutlineStroke(var2);
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var10 = var9.getShape();
//     org.jfree.chart.JFreeChart var11 = null;
//     org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var11);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var15 = null;
//     var14.setOutlineStroke(var15);
//     int var17 = var14.getSeriesIndex();
//     java.awt.Stroke var18 = var14.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var20 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var21 = var20.getShadowColor();
//     int var22 = var21.getAlpha();
//     java.awt.Color var23 = var21.darker();
//     int var24 = var23.getGreen();
//     java.awt.Color var25 = java.awt.Color.getColor("", var23);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var10, var18, (java.awt.Paint)var23);
//     var1.setOutlineStroke(var18);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Paint var17 = var1.getSeriesOutlinePaint((-2));
//     java.lang.Boolean var19 = var1.getSeriesLabelVisible(5);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     java.awt.Paint[] var1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.util.DefaultShadowGenerator var3 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var4 = var3.getShadowColor();
//     int var5 = var4.getAlpha();
//     java.awt.Color var6 = var4.darker();
//     int var7 = var6.getGreen();
//     java.awt.Color var8 = java.awt.Color.getColor("", var6);
//     java.awt.Paint[] var9 = new java.awt.Paint[] { var6};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var14 = var13.getOutlinePaint();
//     boolean var15 = var11.equals((java.lang.Object)var14);
//     java.awt.Paint[] var16 = new java.awt.Paint[] { var14};
//     org.jfree.chart.util.DefaultShadowGenerator var18 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var19 = var18.getShadowColor();
//     int var20 = var19.getAlpha();
//     java.awt.Color var21 = var19.darker();
//     int var22 = var21.getGreen();
//     java.awt.Color var23 = java.awt.Color.getColor("", var21);
//     float[] var24 = null;
//     float[] var25 = var23.getComponents(var24);
//     java.awt.Paint[] var26 = new java.awt.Paint[] { var23};
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var33 = null;
//     var32.setOutlineStroke(var33);
//     int var35 = var32.getSeriesIndex();
//     java.awt.Stroke var36 = var32.getOutlineStroke();
//     java.awt.Shape var37 = var32.getShape();
//     java.awt.Shape[] var38 = new java.awt.Shape[] { var37};
//     org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var16, var26, var28, var30, var38);
//     org.jfree.chart.util.DefaultShadowGenerator var41 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var42 = var41.getShadowColor();
//     int var43 = var42.getAlpha();
//     java.awt.Color var44 = var42.darker();
//     int var45 = var44.getGreen();
//     java.awt.Color var46 = java.awt.Color.getColor("", var44);
//     java.awt.Paint[] var47 = new java.awt.Paint[] { var44};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var49 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var52 = var51.getOutlinePaint();
//     boolean var53 = var49.equals((java.lang.Object)var52);
//     java.awt.Paint[] var54 = new java.awt.Paint[] { var52};
//     org.jfree.chart.util.DefaultShadowGenerator var56 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var57 = var56.getShadowColor();
//     int var58 = var57.getAlpha();
//     java.awt.Color var59 = var57.darker();
//     int var60 = var59.getGreen();
//     java.awt.Color var61 = java.awt.Color.getColor("", var59);
//     float[] var62 = null;
//     float[] var63 = var61.getComponents(var62);
//     java.awt.Paint[] var64 = new java.awt.Paint[] { var61};
//     java.awt.Stroke var65 = null;
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
//     java.awt.Stroke var67 = null;
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
//     org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var71 = null;
//     var70.setOutlineStroke(var71);
//     int var73 = var70.getSeriesIndex();
//     java.awt.Stroke var74 = var70.getOutlineStroke();
//     java.awt.Shape var75 = var70.getShape();
//     java.awt.Shape[] var76 = new java.awt.Shape[] { var75};
//     org.jfree.chart.plot.DefaultDrawingSupplier var77 = new org.jfree.chart.plot.DefaultDrawingSupplier(var47, var54, var64, var66, var68, var76);
//     org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem("");
//     var79.setDatasetIndex(0);
//     java.awt.Shape var82 = var79.getShape();
//     java.awt.Shape[] var83 = new java.awt.Shape[] { var82};
//     org.jfree.chart.plot.DefaultDrawingSupplier var84 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var28, var68, var83);
//     
//     // Checks the contract:  equals-hashcode on var13 and var51
//     assertTrue("Contract failed: equals-hashcode on var13 and var51", var13.equals(var51) ? var13.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var79
//     assertTrue("Contract failed: equals-hashcode on var13 and var79", var13.equals(var79) ? var13.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var13
//     assertTrue("Contract failed: equals-hashcode on var51 and var13", var51.equals(var13) ? var51.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var79
//     assertTrue("Contract failed: equals-hashcode on var51 and var79", var51.equals(var79) ? var51.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var13
//     assertTrue("Contract failed: equals-hashcode on var79 and var13", var79.equals(var13) ? var79.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var51
//     assertTrue("Contract failed: equals-hashcode on var79 and var51", var79.equals(var51) ? var79.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var77
//     assertTrue("Contract failed: equals-hashcode on var39 and var77", var39.equals(var77) ? var39.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var39
//     assertTrue("Contract failed: equals-hashcode on var77 and var39", var77.equals(var39) ? var77.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.util.GradientPaintTransformer var4 = var1.getFillPaintTransformer();
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4, var5, var6);
    org.jfree.chart.event.ChartChangeEventType var8 = var7.getType();
    org.jfree.chart.JFreeChart var9 = var7.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(0, 10, 1);
//     java.lang.String var4 = var3.toString();
//     java.awt.Color var5 = var3.darker();
//     int var6 = var5.getTransparency();
//     java.awt.color.ColorSpace var7 = null;
//     org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var10 = var9.getShadowColor();
//     int var11 = var10.getAlpha();
//     java.awt.Color var12 = var10.darker();
//     int var13 = var12.getGreen();
//     java.awt.Color var14 = java.awt.Color.getColor("", var12);
//     float[] var15 = null;
//     float[] var16 = var14.getComponents(var15);
//     float[] var17 = var5.getColorComponents(var7, var16);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var4 = var3.getOutlinePaint();
    boolean var5 = var1.equals((java.lang.Object)var4);
    org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var8 = null;
    var7.setOutlineStroke(var8);
    org.jfree.chart.util.GradientPaintTransformer var10 = var7.getFillPaintTransformer();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartChangeEventType var12 = null;
    org.jfree.chart.event.ChartChangeEvent var13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var11, var12);
    boolean var14 = var1.equals((java.lang.Object)var10);
    org.jfree.data.category.CategoryDataset var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var17 = var1.generateLabel(var15, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var6 = var5.getShape();
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     int var13 = var10.getSeriesIndex();
//     java.awt.Stroke var14 = var10.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var30 = var28.trimWidth(0.0d);
//     double var32 = var28.trimWidth(109.21460183660255d);
//     boolean var34 = var28.equals((java.lang.Object)"hi!");
//     var23.setInsets(var28, true);
//     org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
//     org.jfree.chart.util.DefaultShadowGenerator var40 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var41 = var40.getShadowColor();
//     int var42 = var41.getAlpha();
//     java.awt.Color var43 = var41.darker();
//     int var44 = var43.getGreen();
//     java.awt.Color var45 = java.awt.Color.getColor("", var43);
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var43};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var48 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var51 = var50.getOutlinePaint();
//     boolean var52 = var48.equals((java.lang.Object)var51);
//     java.awt.Paint[] var53 = new java.awt.Paint[] { var51};
//     org.jfree.chart.util.DefaultShadowGenerator var55 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var56 = var55.getShadowColor();
//     int var57 = var56.getAlpha();
//     java.awt.Color var58 = var56.darker();
//     int var59 = var58.getGreen();
//     java.awt.Color var60 = java.awt.Color.getColor("", var58);
//     float[] var61 = null;
//     float[] var62 = var60.getComponents(var61);
//     java.awt.Paint[] var63 = new java.awt.Paint[] { var60};
//     java.awt.Stroke var64 = null;
//     java.awt.Stroke[] var65 = new java.awt.Stroke[] { var64};
//     java.awt.Stroke var66 = null;
//     java.awt.Stroke[] var67 = new java.awt.Stroke[] { var66};
//     org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var70 = null;
//     var69.setOutlineStroke(var70);
//     int var72 = var69.getSeriesIndex();
//     java.awt.Stroke var73 = var69.getOutlineStroke();
//     java.awt.Shape var74 = var69.getShape();
//     java.awt.Shape[] var75 = new java.awt.Shape[] { var74};
//     org.jfree.chart.plot.DefaultDrawingSupplier var76 = new org.jfree.chart.plot.DefaultDrawingSupplier(var46, var53, var63, var65, var67, var75);
//     java.awt.Stroke var77 = var76.getNextOutlineStroke();
//     var23.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var76, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var50
//     assertTrue("Contract failed: equals-hashcode on var5 and var50", var5.equals(var50) ? var5.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var5
//     assertTrue("Contract failed: equals-hashcode on var50 and var5", var50.equals(var5) ? var50.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var21 = var20.getShape();
//     org.jfree.chart.JFreeChart var22 = null;
//     org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var21, var22);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var26 = null;
//     var25.setOutlineStroke(var26);
//     int var28 = var25.getSeriesIndex();
//     java.awt.Stroke var29 = var25.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var31 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var32 = var31.getShadowColor();
//     int var33 = var32.getAlpha();
//     java.awt.Color var34 = var32.darker();
//     int var35 = var34.getGreen();
//     java.awt.Color var36 = java.awt.Color.getColor("", var34);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var21, var29, (java.awt.Paint)var34);
//     var0.setDomainGridlineStroke(var29);
//     org.jfree.chart.renderer.RenderAttributes var40 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("");
//     var43.setDatasetIndex(0);
//     java.awt.Paint var46 = var43.getFillPaint();
//     org.jfree.data.KeyedObject var47 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var46);
//     var40.setDefaultLabelPaint(var46);
//     java.awt.Paint var49 = var40.getDefaultLabelPaint();
//     var0.setRangeGridlinePaint(var49);
//     
//     // Checks the contract:  equals-hashcode on var20 and var43
//     assertTrue("Contract failed: equals-hashcode on var20 and var43", var20.equals(var43) ? var20.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var20
//     assertTrue("Contract failed: equals-hashcode on var43 and var20", var43.equals(var20) ? var43.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     java.awt.Paint var10 = var1.getDefaultLabelPaint();
//     java.awt.Shape var12 = var1.getSeriesShape(255);
//     java.lang.Boolean var14 = var1.getSeriesLabelVisible(0);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.axis.CategoryAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePosition(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation((-1));
    org.jfree.chart.plot.PlotOrientation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = null;
    var0.setBoolean(0, var2);
    java.lang.Boolean var5 = var0.getBoolean((-127));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var6 = var5.getShape();
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var10 = var9.getDistance();
//     int var11 = var9.getDistance();
//     var7.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var9);
//     float var13 = var7.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var7.setDomainAxisLocation(10, var15, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     var7.setRenderer(255, var19, false);
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var28 = var27.getShape();
//     org.jfree.chart.JFreeChart var29 = null;
//     org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var28, var29);
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var33 = null;
//     var32.setOutlineStroke(var33);
//     int var35 = var32.getSeriesIndex();
//     java.awt.Stroke var36 = var32.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var38 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var39 = var38.getShadowColor();
//     int var40 = var39.getAlpha();
//     java.awt.Color var41 = var39.darker();
//     int var42 = var41.getGreen();
//     java.awt.Color var43 = java.awt.Color.getColor("", var41);
//     org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var28, var36, (java.awt.Paint)var41);
//     var7.setDomainGridlineStroke(var36);
//     java.awt.Color var49 = java.awt.Color.getColor("", 1);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", var49);
//     org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("org.jfree.chart.ChartColor[r=0,g=10,b=1]", "ItemLabelAnchor.OUTSIDE12", "ItemLabelAnchor.OUTSIDE12", "-4,-4,4,4", var6, var36, (java.awt.Paint)var50);
//     
//     // Checks the contract:  equals-hashcode on var5 and var27
//     assertTrue("Contract failed: equals-hashcode on var5 and var27", var5.equals(var27) ? var5.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var5
//     assertTrue("Contract failed: equals-hashcode on var27 and var5", var27.equals(var5) ? var27.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    boolean var6 = var0.isRangeZoomable();
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var0.removeRangeMarker(15, var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    int var8 = var5.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var10 = var9.getShadowColor();
    var5.setLinePaint((java.awt.Paint)var10);
    java.awt.Paint var12 = var5.getLabelPaint();
    java.awt.Shape var13 = var5.getShape();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var17 = var16.getDistance();
    int var18 = var16.getDistance();
    var14.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var16);
    float var20 = var14.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var22 = null;
    var14.setDomainAxisLocation(10, var22, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    var14.setRenderer(255, var26, false);
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var35 = var34.getShape();
    org.jfree.chart.JFreeChart var36 = null;
    org.jfree.chart.event.ChartChangeEvent var37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var35, var36);
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var40 = null;
    var39.setOutlineStroke(var40);
    int var42 = var39.getSeriesIndex();
    java.awt.Stroke var43 = var39.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var45 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var46 = var45.getShadowColor();
    int var47 = var46.getAlpha();
    java.awt.Color var48 = var46.darker();
    int var49 = var48.getGreen();
    java.awt.Color var50 = java.awt.Color.getColor("", var48);
    org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var35, var43, (java.awt.Paint)var48);
    var14.setDomainGridlineStroke(var43);
    java.awt.Color var55 = java.awt.Color.getColor("", 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem(var0, "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "org.jfree.chart.event.ChartChangeEvent[source=-1]", "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", var13, var43, (java.awt.Paint)var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.clearSelection();
    org.jfree.chart.plot.Marker var4 = null;
    org.jfree.chart.util.Layer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var0.removeRangeMarker(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.setRangeCrosshairVisible(false);
    var5.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var12 = var5.getRangeAxisLocation((-1));
    var0.setDomainAxisLocation(1, var12);
    org.jfree.chart.plot.PlotOrientation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var12, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.setRangeCrosshairVisible(false);
//     var16.setCrosshairDatasetIndex(255, false);
//     org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation((-1));
//     var0.setDomainAxisLocation(100, var23, true);
//     var0.configureDomainAxes();
//     var0.zoom(10.0d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var8 = var7.getShape();
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    int var15 = var12.getSeriesIndex();
    java.awt.Stroke var16 = var12.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var18 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var19 = var18.getShadowColor();
    int var20 = var19.getAlpha();
    java.awt.Color var21 = var19.darker();
    int var22 = var21.getGreen();
    java.awt.Color var23 = java.awt.Color.getColor("", var21);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var8, var16, (java.awt.Paint)var21);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var32 = var30.trimWidth(0.0d);
    double var34 = var30.trimWidth(109.21460183660255d);
    boolean var36 = var30.equals((java.lang.Object)"hi!");
    var25.setInsets(var30, true);
    org.jfree.chart.entity.PlotEntity var40 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var25, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.util.SortOrder var41 = var25.getColumnRenderingOrder();
    var0.setRowRenderingOrder(var41);
    org.jfree.chart.axis.ValueAxis var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-16777216), var44, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Stroke var18 = var1.getItemOutlineStroke(5, 0);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getColumnCount();
    int var7 = var0.getRowIndex((java.lang.Comparable)100.0d);
    int var9 = var0.getColumnIndex((java.lang.Comparable)100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var12 = var0.getObject((java.lang.Comparable)100.0f, (java.lang.Comparable)(-127));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxis((-16777216), (-127));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var4 = null;
    var3.setOutlineStroke(var4);
    var3.setURLText("");
    java.awt.Paint var8 = var3.getLabelPaint();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var11 = var10.getShape();
    var3.setShape(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-2), var11, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var6 = var5.getShape();
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     int var13 = var10.getSeriesIndex();
//     java.awt.Stroke var14 = var10.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var30 = var28.trimWidth(0.0d);
//     double var32 = var28.trimWidth(109.21460183660255d);
//     boolean var34 = var28.equals((java.lang.Object)"hi!");
//     var23.setInsets(var28, true);
//     org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("");
//     var40.setDatasetIndex(0);
//     java.awt.Shape var43 = var40.getShape();
//     org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var43, "");
//     var38.setArea(var43);
//     
//     // Checks the contract:  equals-hashcode on var5 and var40
//     assertTrue("Contract failed: equals-hashcode on var5 and var40", var5.equals(var40) ? var5.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var5
//     assertTrue("Contract failed: equals-hashcode on var40 and var5", var40.equals(var5) ? var40.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-2), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.renderer.category.BarPainter var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var0);
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)10.0d, var1);
    org.jfree.chart.JFreeChart var3 = var2.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var8 = var7.getShape();
    org.jfree.chart.JFreeChart var9 = null;
    org.jfree.chart.event.ChartChangeEvent var10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var9);
    org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var13 = null;
    var12.setOutlineStroke(var13);
    int var15 = var12.getSeriesIndex();
    java.awt.Stroke var16 = var12.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var18 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var19 = var18.getShadowColor();
    int var20 = var19.getAlpha();
    java.awt.Color var21 = var19.darker();
    int var22 = var21.getGreen();
    java.awt.Color var23 = java.awt.Color.getColor("", var21);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var8, var16, (java.awt.Paint)var21);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var32 = var30.trimWidth(0.0d);
    double var34 = var30.trimWidth(109.21460183660255d);
    boolean var36 = var30.equals((java.lang.Object)"hi!");
    var25.setInsets(var30, true);
    org.jfree.chart.entity.PlotEntity var40 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var25, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.util.SortOrder var41 = var25.getColumnRenderingOrder();
    var0.setRowRenderingOrder(var41);
    org.jfree.chart.annotations.CategoryAnnotation var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     var0.setShadowVisible(false);
//     org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
//     java.lang.String var9 = var8.toString();
//     int var10 = var8.getAlpha();
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var8.createContext(var11, var12, var13, var14, var15);
//     var0.setShadowPaint((java.awt.Paint)var8);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.configureDomainAxes();
//     org.jfree.chart.plot.Marker var21 = null;
//     org.jfree.chart.util.Layer var22 = null;
//     boolean var23 = var19.removeDomainMarker(var21, var22);
//     java.awt.geom.Rectangle2D var24 = null;
//     var0.drawBackground(var18, var19, var24);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Paint var16 = var1.getDefaultPaint();
//     java.lang.Boolean var18 = var1.getSeriesLabelVisible(100);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
//     org.jfree.chart.plot.Marker var8 = null;
//     var0.addRangeMarker(var8);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-16777216));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Stroke var16 = var1.getSeriesStroke((-1));
//     java.lang.Boolean var18 = null;
//     var1.setSeriesLabelVisible((-127), var18);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    var5.setURLText("");
    var5.setToolTipText("hi!");
    org.jfree.chart.util.GradientPaintTransformer var12 = var5.getFillPaintTransformer();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var15 = var14.getShape();
    org.jfree.chart.JFreeChart var16 = null;
    org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var16);
    var5.setLine(var15);
    java.awt.Paint var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("-4,-4,4,4", "ItemLabelAnchor.OUTSIDE12", "-4,-4,4,4", "org.jfree.chart.event.ChartChangeEvent[source=-1]", var15, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    var0.clearSeriesStrokes(false);
    double var10 = var0.getShadowXOffset();
    java.awt.Paint var11 = var0.getBasePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-16777216), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
//     java.lang.Object var3 = var1.get(1);
//     int var4 = var1.size();
//     org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var7 = null;
//     var6.setOutlineStroke(var7);
//     int var9 = var6.getSeriesIndex();
//     org.jfree.chart.util.DefaultShadowGenerator var10 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var11 = var10.getShadowColor();
//     var6.setLinePaint((java.awt.Paint)var11);
//     org.jfree.data.category.AbstractCategoryDataset var13 = new org.jfree.data.category.AbstractCategoryDataset();
//     var6.setDataset((org.jfree.data.general.Dataset)var13);
//     org.jfree.chart.event.DatasetChangeInfo var15 = new org.jfree.chart.event.DatasetChangeInfo();
//     org.jfree.data.event.DatasetChangeEvent var16 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var1, (org.jfree.data.general.Dataset)var13, var15);
//     java.lang.Object var18 = var1.get(5);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var24 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var26 = var24.trimWidth(0.0d);
//     double var28 = var24.trimWidth(109.21460183660255d);
//     boolean var30 = var24.equals((java.lang.Object)"hi!");
//     var19.setInsets(var24, true);
//     int var33 = var1.indexOf((java.lang.Object)var19);
//     org.jfree.chart.plot.Marker var34 = null;
//     var19.addRangeMarker(var34);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     java.awt.Paint var2 = var0.getPaint(255);
//     org.jfree.chart.util.DefaultShadowGenerator var3 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var4 = var3.getShadowColor();
//     org.jfree.chart.LegendItemCollection var5 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var6 = var5.clone();
//     boolean var7 = var3.equals((java.lang.Object)var5);
//     boolean var9 = var3.equals((java.lang.Object)(short)10);
//     java.awt.Color var10 = var3.getShadowColor();
//     boolean var12 = var3.equals((java.lang.Object)(-1L));
//     boolean var13 = var0.equals((java.lang.Object)var3);
//     org.jfree.chart.LegendItemCollection var14 = new org.jfree.chart.LegendItemCollection();
//     boolean var15 = var0.equals((java.lang.Object)var14);
//     
//     // Checks the contract:  equals-hashcode on var5 and var14
//     assertTrue("Contract failed: equals-hashcode on var5 and var14", var5.equals(var14) ? var5.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var5
//     assertTrue("Contract failed: equals-hashcode on var14 and var5", var14.equals(var5) ? var14.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    var0.setAnchorValue(10.0d, true);
    org.jfree.chart.plot.Marker var6 = null;
    org.jfree.chart.util.Layer var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var0.removeRangeMarker(5, var6, var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
    var1.setDefaultFillPaint((java.awt.Paint)var13);
    java.awt.Paint var15 = var1.getDefaultPaint();
    java.awt.Paint var17 = var1.getSeriesPaint(255);
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var21 = null;
    var20.setOutlineStroke(var21);
    var20.setURLText("");
    var20.setToolTipText("hi!");
    org.jfree.chart.util.GradientPaintTransformer var27 = var20.getFillPaintTransformer();
    java.awt.Paint var28 = var20.getFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesFillPaint((-2), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.trimHeight((-9.21460183660255d));
    double var10 = var4.calculateTopInset(1.0d);
    double var12 = var4.calculateRightOutset((-0.7853981633974483d));
    double var13 = var4.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10.0d);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Shape var17 = var1.getSeriesShape(10);
//     java.awt.Paint var19 = var1.getSeriesOutlinePaint(5);
//     org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("");
//     var21.setDatasetIndex(0);
//     java.awt.Shape var24 = var21.getShape();
//     var1.setDefaultShape(var24);
//     
//     // Checks the contract:  equals-hashcode on var4 and var21
//     assertTrue("Contract failed: equals-hashcode on var4 and var21", var4.equals(var21) ? var4.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var4
//     assertTrue("Contract failed: equals-hashcode on var21 and var4", var21.equals(var4) ? var21.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.annotations.CategoryAnnotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var0.removeAnnotation(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var4 = null;
//     var0.setLegendTextFont(5, var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var12 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var13 = var12.getDistance();
//     int var14 = var12.getDistance();
//     var10.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var12);
//     float var16 = var10.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var10.setDomainAxisLocation(10, var18, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     var10.setRenderer(255, var22, false);
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var31 = var30.getShape();
//     org.jfree.chart.JFreeChart var32 = null;
//     org.jfree.chart.event.ChartChangeEvent var33 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var31, var32);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var36 = null;
//     var35.setOutlineStroke(var36);
//     int var38 = var35.getSeriesIndex();
//     java.awt.Stroke var39 = var35.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var41 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var42 = var41.getShadowColor();
//     int var43 = var42.getAlpha();
//     java.awt.Color var44 = var42.darker();
//     int var45 = var44.getGreen();
//     java.awt.Color var46 = java.awt.Color.getColor("", var44);
//     org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var31, var39, (java.awt.Paint)var44);
//     var10.setDomainGridlineStroke(var39);
//     var9.setTickMarkStroke(var39);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.util.Layer var51 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     var0.drawAnnotations(var6, var7, var9, var50, var51, var52);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
//     org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(0);
//     var0.setNegativeItemLabelPositionFallback(var6);
//     
//     // Checks the contract:  equals-hashcode on var2 and var6
//     assertTrue("Contract failed: equals-hashcode on var2 and var6", var2.equals(var6) ? var2.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var2
//     assertTrue("Contract failed: equals-hashcode on var6 and var2", var6.equals(var2) ? var6.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-2));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     var1.setDatasetIndex(0);
//     java.awt.Shape var4 = var1.getShape();
//     org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var4, "");
//     var6.setToolTipText("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     java.lang.Object var9 = var6.clone();
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var16 = var15.getShape();
//     org.jfree.chart.JFreeChart var17 = null;
//     org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16, var17);
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var21 = null;
//     var20.setOutlineStroke(var21);
//     int var23 = var20.getSeriesIndex();
//     java.awt.Stroke var24 = var20.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var26 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var27 = var26.getShadowColor();
//     int var28 = var27.getAlpha();
//     java.awt.Color var29 = var27.darker();
//     int var30 = var29.getGreen();
//     java.awt.Color var31 = java.awt.Color.getColor("", var29);
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var16, var24, (java.awt.Paint)var29);
//     var6.setArea(var16);
//     
//     // Checks the contract:  equals-hashcode on var1 and var15
//     assertTrue("Contract failed: equals-hashcode on var1 and var15", var1.equals(var15) ? var1.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var1
//     assertTrue("Contract failed: equals-hashcode on var15 and var1", var15.equals(var1) ? var15.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    boolean var6 = var0.canSelectByRegion();
    org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
    var0.setAnchorValue(8.21460183660255d, true);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var14 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var15 = var14.getDistance();
    int var16 = var14.getDistance();
    var12.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var14);
    float var18 = var12.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var20 = null;
    var12.setDomainAxisLocation(10, var20, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    var12.setRenderer(255, var24, false);
    java.awt.Paint var27 = var12.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var30 = var28.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var32 = null;
    var28.setLegendTextFont(5, var32);
    java.awt.Font var34 = null;
    var28.setBaseLegendTextFont(var34);
    var28.clearSeriesStrokes(false);
    int var38 = var12.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-127), (org.jfree.chart.renderer.category.CategoryItemRenderer)var28, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1));

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var4 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var5 = var4.getDistance();
    int var6 = var4.getDistance();
    var2.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var4);
    float var8 = var2.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var10 = null;
    var2.setDomainAxisLocation(10, var10, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var2.setRenderer(255, var14, false);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var23 = var22.getShape();
    org.jfree.chart.JFreeChart var24 = null;
    org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var23, var24);
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var28 = null;
    var27.setOutlineStroke(var28);
    int var30 = var27.getSeriesIndex();
    java.awt.Stroke var31 = var27.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var33 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var34 = var33.getShadowColor();
    int var35 = var34.getAlpha();
    java.awt.Color var36 = var34.darker();
    int var37 = var36.getGreen();
    java.awt.Color var38 = java.awt.Color.getColor("", var36);
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var23, var31, (java.awt.Paint)var36);
    var2.setDomainGridlineStroke(var31);
    var1.setTickMarkStroke(var31);
    int var42 = var1.getMaximumCategoryLabelLines();
    java.awt.Paint var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkPaint(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var1 = var0.getShadowColor();
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var0.equals((java.lang.Object)var2);
//     boolean var6 = var0.equals((java.lang.Object)(short)10);
//     java.awt.Color var7 = var0.getShadowColor();
//     java.awt.image.BufferedImage var8 = null;
//     java.awt.image.BufferedImage var9 = var0.createDropShadow(var8);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     java.awt.geom.Rectangle2D var1 = null;
//     var0.trim(var1);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    var0.setMaximumBarWidth(100.0d);
    java.awt.Font var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseItemLabelFont(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    java.awt.Paint var15 = var0.getDomainCrosshairPaint();
    java.awt.Paint var16 = var0.getRangeCrosshairPaint();
    var0.configureRangeAxes();
    boolean var18 = var0.isNotify();
    org.jfree.chart.annotations.CategoryAnnotation var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var1 = var0.getShadowColor();
//     int var2 = var1.getAlpha();
//     java.awt.color.ColorSpace var3 = null;
//     float[] var4 = new float[] { };
//     float[] var5 = var1.getColorComponents(var3, var4);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     var0.setShadowVisible(false);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var0.setBaseItemLabelGenerator(var5);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var13 = var12.getOutlinePaint();
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("hi!", var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var18 = var17.getDistance();
//     int var19 = var17.getDistance();
//     var15.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var17);
//     float var21 = var15.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var15.setDomainAxisLocation(10, var23, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     var15.setRenderer(255, var27, false);
//     java.awt.Paint var30 = var15.getDomainCrosshairPaint();
//     boolean var31 = var14.equals((java.lang.Object)var15);
//     org.jfree.chart.axis.CategoryAxis var32 = new org.jfree.chart.axis.CategoryAxis();
//     var15.setDomainAxis(var32);
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var0.getItemMiddle((java.lang.Comparable)0.0d, (java.lang.Comparable)"-4,-4,4,4", var9, var32, var34, var35);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.axis.CategoryLabelPositions var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     var1.setDefaultLabelVisible((java.lang.Boolean)true);
//     java.awt.Shape var14 = var1.getItemShape(5, (-2));
//     java.lang.Boolean var16 = var1.getSeriesCreateEntity((-1));
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setWeight(10);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var0.getRendererForDataset(var4);
    org.jfree.chart.axis.AxisLocation var7 = var0.getDomainAxisLocation(100);
    org.jfree.chart.plot.CategoryMarker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.setRangeCrosshairVisible(false);
    var5.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var12 = var5.getRangeAxisLocation((-1));
    var0.setDomainAxisLocation(1, var12);
    org.jfree.chart.annotations.CategoryAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var15 = var0.removeAnnotation(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var11 = var0.removeRangeMarker(100, var8, var9, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    java.awt.Stroke var7 = null;
    org.jfree.chart.ChartColor var11 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var12 = var11.toString();
    int var13 = var11.getAlpha();
    java.awt.image.ColorModel var14 = null;
    java.awt.Rectangle var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    java.awt.geom.AffineTransform var17 = null;
    java.awt.RenderingHints var18 = null;
    java.awt.PaintContext var19 = var11.createContext(var14, var15, var16, var17, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "UnitType.ABSOLUTE", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", var6, var7, (java.awt.Paint)var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var12.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setRangeCrosshairVisible(false);
//     boolean var11 = var8.isDomainPannable();
//     var8.setForegroundAlpha(100.0f);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var18 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var19 = var18.getDistance();
//     int var20 = var18.getDistance();
//     var16.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var18);
//     float var22 = var16.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var16.setDomainAxisLocation(10, var24, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var16.setRenderer(255, var28, false);
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var37 = var36.getShape();
//     org.jfree.chart.JFreeChart var38 = null;
//     org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var37, var38);
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var42 = null;
//     var41.setOutlineStroke(var42);
//     int var44 = var41.getSeriesIndex();
//     java.awt.Stroke var45 = var41.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var47 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var48 = var47.getShadowColor();
//     int var49 = var48.getAlpha();
//     java.awt.Color var50 = var48.darker();
//     int var51 = var50.getGreen();
//     java.awt.Color var52 = java.awt.Color.getColor("", var50);
//     org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var37, var45, (java.awt.Paint)var50);
//     var16.setDomainGridlineStroke(var45);
//     var15.setTickMarkStroke(var45);
//     int var56 = var15.getMaximumCategoryLabelLines();
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var62 = null;
//     boolean var63 = var0.hitTest((-0.7853981633974483d), (-0.7853981633974483d), var6, var7, var8, var15, var57, var58, 10, 0, true, var62);
// 
//   }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(255);
    org.jfree.chart.util.DefaultShadowGenerator var3 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var4 = var3.getShadowColor();
    org.jfree.chart.LegendItemCollection var5 = new org.jfree.chart.LegendItemCollection();
    java.lang.Object var6 = var5.clone();
    boolean var7 = var3.equals((java.lang.Object)var5);
    boolean var9 = var3.equals((java.lang.Object)(short)10);
    java.awt.Color var10 = var3.getShadowColor();
    boolean var12 = var3.equals((java.lang.Object)(-1L));
    boolean var13 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.renderer.RenderAttributes var16 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("");
    var19.setDatasetIndex(0);
    java.awt.Paint var22 = var19.getFillPaint();
    org.jfree.data.KeyedObject var23 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var22);
    var16.setDefaultLabelPaint(var22);
    java.awt.Paint var25 = var16.getDefaultLabelPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-2), var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    var0.setMaximumBarWidth(100.0d);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var14 = null;
    var13.setOutlineStroke(var14);
    int var16 = var13.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var18 = var17.getShadowColor();
    int var19 = var18.getAlpha();
    var13.setLinePaint((java.awt.Paint)var18);
    org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var22 = var21.getShadowColor();
    int var23 = var22.getAlpha();
    java.awt.Color var24 = var22.darker();
    java.awt.image.ColorModel var25 = null;
    java.awt.Rectangle var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    java.awt.geom.AffineTransform var28 = null;
    java.awt.RenderingHints var29 = null;
    java.awt.PaintContext var30 = var24.createContext(var25, var26, var27, var28, var29);
    var13.setFillPaint((java.awt.Paint)var24);
    var0.setBaseFillPaint((java.awt.Paint)var24, true);
    org.jfree.chart.urls.CategoryURLGenerator var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-127), var35, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.lang.Number var0 = null;
    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue(var0);
    boolean var2 = var1.isSelected();
    boolean var3 = var1.isSelected();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     java.awt.Paint var4 = var1.getItemOutlinePaint((-1), 10);
//     java.awt.Paint var7 = var1.getItemOutlinePaint(0, (-127));
//     java.awt.Shape var8 = var1.getDefaultShape();
//     java.lang.Boolean var10 = var1.getSeriesLabelVisible(100);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    int var14 = var0.getDomainAxisCount();
    int var15 = var0.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var16 = var0.getAxisOffset();
    org.jfree.chart.plot.Marker var17 = null;
    boolean var18 = var0.removeDomainMarker(var17);
    org.jfree.chart.plot.CategoryMarker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, var20, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var5 = var4.getUnitType();
    java.awt.geom.Rectangle2D var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var4.createOutsetRectangle(var6, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.awt.Color var4 = java.awt.Color.getColor("", 1);
    java.awt.Color var5 = java.awt.Color.getColor("hi!", var4);
    org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator(15, var5, 10.0f, 255, (-9.21460183660255d));
    int var10 = var9.calculateOffsetX();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-264));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var4 = null;
    var3.setOutlineStroke(var4);
    int var6 = var3.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var7 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var8 = var7.getShadowColor();
    var3.setLinePaint((java.awt.Paint)var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-264), (java.awt.Paint)var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     var0.setShadowVisible(false);
//     org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var6 = var5.getShadowColor();
//     int var7 = var6.getAlpha();
//     var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
//     boolean var13 = var10.equals((java.lang.Object)var12);
//     var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var10);
//     org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var15.getBaseItemLabelGenerator();
//     java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
//     var15.setSeriesItemLabelPaint(1, (java.awt.Paint)var23, false);
//     var0.setBaseItemLabelPaint((java.awt.Paint)var23, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    var0.clearSeriesStrokes(false);
    double var10 = var0.getShadowXOffset();
    var0.setDefaultEntityRadius(0);
    java.lang.Boolean var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-264), var14, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4.0d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getColumnCount();
    int var7 = var0.getRowIndex((java.lang.Comparable)100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)(short)10, (java.lang.Comparable)100.0f);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.lang.Object var2 = var0.clone();
    java.awt.Stroke var3 = var0.getRangeGridlineStroke();
    var0.setRangeCrosshairLockedOnData(false);
    java.lang.Comparable var6 = var0.getDomainCrosshairColumnKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getKey(5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var7 = var0.getRowKey((-2));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setWeight(10);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var5 = var0.getRendererForDataset(var4);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var7.getBaseItemLabelGenerator();
    var7.setMaximumBarWidth(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-16777215), (org.jfree.chart.renderer.category.CategoryItemRenderer)var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.setRangeCrosshairVisible(false);
//     boolean var18 = var15.isRangeGridlinesVisible();
//     java.awt.Stroke var19 = var15.getDomainGridlineStroke();
//     var0.setRangeGridlineStroke(var19);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var17 = var1.getItemFillPaint(0, 0);
//     java.awt.Font var18 = var1.getDefaultLabelFont();
//     java.awt.Font var19 = var1.getDefaultLabelFont();
//     org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var22 = var21.getShadowColor();
//     int var23 = var22.getAlpha();
//     java.awt.Color var24 = var22.darker();
//     int var25 = var24.getGreen();
//     java.awt.Color var26 = java.awt.Color.getColor("", var24);
//     java.awt.Paint[] var27 = new java.awt.Paint[] { var24};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var29 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var32 = var31.getOutlinePaint();
//     boolean var33 = var29.equals((java.lang.Object)var32);
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var32};
//     org.jfree.chart.util.DefaultShadowGenerator var36 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var37 = var36.getShadowColor();
//     int var38 = var37.getAlpha();
//     java.awt.Color var39 = var37.darker();
//     int var40 = var39.getGreen();
//     java.awt.Color var41 = java.awt.Color.getColor("", var39);
//     float[] var42 = null;
//     float[] var43 = var41.getComponents(var42);
//     java.awt.Paint[] var44 = new java.awt.Paint[] { var41};
//     java.awt.Stroke var45 = null;
//     java.awt.Stroke[] var46 = new java.awt.Stroke[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var51 = null;
//     var50.setOutlineStroke(var51);
//     int var53 = var50.getSeriesIndex();
//     java.awt.Stroke var54 = var50.getOutlineStroke();
//     java.awt.Shape var55 = var50.getShape();
//     java.awt.Shape[] var56 = new java.awt.Shape[] { var55};
//     org.jfree.chart.plot.DefaultDrawingSupplier var57 = new org.jfree.chart.plot.DefaultDrawingSupplier(var27, var34, var44, var46, var48, var56);
//     java.awt.Shape var58 = var57.getNextShape();
//     var1.setDefaultShape(var58);
//     
//     // Checks the contract:  equals-hashcode on var4 and var31
//     assertTrue("Contract failed: equals-hashcode on var4 and var31", var4.equals(var31) ? var4.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var4
//     assertTrue("Contract failed: equals-hashcode on var31 and var4", var31.equals(var4) ? var31.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Shape var17 = var1.getSeriesShape(10);
//     var1.setSeriesLabelVisible((-16777215), (java.lang.Boolean)true);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setItemMargin(0.0d);
    var0.setUseOutlinePaint(true);
    org.jfree.chart.renderer.RenderAttributes var8 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var10 = var9.getFixedRangeAxisSpace();
    var9.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    var9.setDomainAxis(var13);
    java.awt.Paint var15 = var9.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.CategoryAxis var17 = var9.getDomainAxis(1);
    java.awt.Font var18 = var9.getNoDataMessageFont();
    var8.setDefaultLabelFont(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelFont((-16777216), var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var0.drawOutline(var15, var16);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     java.awt.Paint var15 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var20 = null;
//     var16.setLegendTextFont(5, var20);
//     java.awt.Font var22 = null;
//     var16.setBaseLegendTextFont(var22);
//     var16.clearSeriesStrokes(false);
//     int var26 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
//     var16.setIncludeBaseInRange(false);
//     var16.setItemMargin((-1.0d));
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var35 = var33.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var40 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var41 = var40.getUnitType();
//     var33.setTickLabelInsets(var40);
//     org.jfree.chart.util.RectangleInsets var47 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var49 = var47.trimWidth(0.0d);
//     double var51 = var47.calculateTopInset(0.0d);
//     double var53 = var47.extendWidth(100.0d);
//     java.lang.String var54 = var47.toString();
//     var33.setLabelInsets(var47);
//     org.jfree.chart.plot.Plot var56 = var33.getPlot();
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.util.Layer var58 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     var16.drawAnnotations(var31, var32, var33, var57, var58, var59);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setRangeZeroBaselineVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var0.zoomRangeAxes((-108.42920367320511d), var5, var6, false);
    org.jfree.chart.axis.ValueAxis var9 = null;
    var0.setRangeAxis(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var2 = var1.getShape();
//     org.jfree.chart.util.GradientPaintTransformer var3 = var1.getFillPaintTransformer();
//     java.lang.String var4 = var1.getDescription();
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var11 = var10.getShape();
//     org.jfree.chart.JFreeChart var12 = null;
//     org.jfree.chart.event.ChartChangeEvent var13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var11, var12);
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var16 = null;
//     var15.setOutlineStroke(var16);
//     int var18 = var15.getSeriesIndex();
//     java.awt.Stroke var19 = var15.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var22 = var21.getShadowColor();
//     int var23 = var22.getAlpha();
//     java.awt.Color var24 = var22.darker();
//     int var25 = var24.getGreen();
//     java.awt.Color var26 = java.awt.Color.getColor("", var24);
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var11, var19, (java.awt.Paint)var24);
//     var1.setOutlineStroke(var19);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("Category Plot", var1);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.plot.Marker var2 = null;
//     org.jfree.chart.util.Layer var3 = null;
//     boolean var4 = var0.removeDomainMarker(var2, var3);
//     org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis(255);
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var12 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var14 = var12.trimWidth(0.0d);
//     double var16 = var12.trimWidth(109.21460183660255d);
//     boolean var18 = var12.equals((java.lang.Object)"hi!");
//     var7.setInsets(var12, true);
//     var0.setInsets(var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var17 = var1.getItemFillPaint(0, 0);
//     var1.setSeriesLabelVisible(10, (java.lang.Boolean)true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var2 = var1.getShape();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var9 = var8.getShape();
    org.jfree.chart.JFreeChart var10 = null;
    org.jfree.chart.event.ChartChangeEvent var11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var10);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var14 = null;
    var13.setOutlineStroke(var14);
    int var16 = var13.getSeriesIndex();
    java.awt.Stroke var17 = var13.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var19 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var20 = var19.getShadowColor();
    int var21 = var20.getAlpha();
    java.awt.Color var22 = var20.darker();
    int var23 = var22.getGreen();
    java.awt.Color var24 = java.awt.Color.getColor("", var22);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var9, var17, (java.awt.Paint)var22);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var31 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var33 = var31.trimWidth(0.0d);
    double var35 = var31.trimWidth(109.21460183660255d);
    boolean var37 = var31.equals((java.lang.Object)"hi!");
    var26.setInsets(var31, true);
    org.jfree.chart.entity.PlotEntity var41 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var26, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    var1.setLine(var9);
    java.awt.Font var43 = var1.getLabelFont();
    org.jfree.chart.util.DefaultShadowGenerator var44 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var45 = var44.getShadowColor();
    int var46 = var45.getAlpha();
    java.awt.Color var47 = var45.darker();
    int var48 = var47.getGreen();
    org.jfree.chart.util.DefaultShadowGenerator var50 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var51 = var50.getShadowColor();
    int var52 = var51.getAlpha();
    java.awt.Color var53 = var51.darker();
    int var54 = var53.getGreen();
    java.awt.Color var55 = java.awt.Color.getColor("", var53);
    float[] var56 = null;
    float[] var57 = var55.getComponents(var56);
    float[] var58 = var47.getComponents(var56);
    int var59 = var47.getRGB();
    var1.setFillPaint((java.awt.Paint)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-16777216));

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var6 = var4.trimWidth(0.0d);
//     double var8 = var4.calculateTopInset(0.0d);
//     double var10 = var4.extendWidth(100.0d);
//     java.lang.String var11 = var4.toString();
//     java.awt.geom.Rectangle2D var12 = null;
//     var4.trim(var12);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    var1.setSeriesIndex(0);
    java.lang.String var6 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     java.awt.Paint var4 = var1.getItemPaint(255, 100);
//     java.awt.Color var7 = java.awt.Color.getColor("", 1);
//     var1.setDefaultLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var16 = var15.getShape();
//     org.jfree.chart.JFreeChart var17 = null;
//     org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var16, var17);
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var21 = null;
//     var20.setOutlineStroke(var21);
//     int var23 = var20.getSeriesIndex();
//     java.awt.Stroke var24 = var20.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var26 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var27 = var26.getShadowColor();
//     int var28 = var27.getAlpha();
//     java.awt.Color var29 = var27.darker();
//     int var30 = var29.getGreen();
//     java.awt.Color var31 = java.awt.Color.getColor("", var29);
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var16, var24, (java.awt.Paint)var29);
//     var1.setSeriesShape(0, var16);
//     java.awt.Font var36 = var1.getItemLabelFont((-127), (-1));
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Shape var4 = var1.getShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var4, "");
    var6.setToolTipText("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var10 = var9.getUseOutlinePaint();
    var9.setItemMargin(0.0d);
    java.awt.Shape var16 = var9.getItemShape(5, (-264), false);
    var6.setArea(var16);
    org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    java.awt.Stroke var9 = var0.getSeriesOutlineStroke((-2));
    java.awt.Paint var13 = var0.getItemPaint((-16777216), (-16777215), true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-264), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     org.jfree.chart.util.DefaultShadowGenerator var8 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var9 = var8.getShadowColor();
//     int var10 = var9.getAlpha();
//     java.awt.Color var11 = var9.darker();
//     int var12 = var11.getGreen();
//     java.awt.Color var13 = java.awt.Color.getColor("", var11);
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var11};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var19 = var18.getOutlinePaint();
//     boolean var20 = var16.equals((java.lang.Object)var19);
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var19};
//     org.jfree.chart.util.DefaultShadowGenerator var23 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var24 = var23.getShadowColor();
//     int var25 = var24.getAlpha();
//     java.awt.Color var26 = var24.darker();
//     int var27 = var26.getGreen();
//     java.awt.Color var28 = java.awt.Color.getColor("", var26);
//     float[] var29 = null;
//     float[] var30 = var28.getComponents(var29);
//     java.awt.Paint[] var31 = new java.awt.Paint[] { var28};
//     java.awt.Stroke var32 = null;
//     java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
//     java.awt.Stroke var34 = null;
//     java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var38 = null;
//     var37.setOutlineStroke(var38);
//     int var40 = var37.getSeriesIndex();
//     java.awt.Stroke var41 = var37.getOutlineStroke();
//     java.awt.Shape var42 = var37.getShape();
//     java.awt.Shape[] var43 = new java.awt.Shape[] { var42};
//     org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var21, var31, var33, var35, var43);
//     java.awt.Stroke var45 = var44.getNextOutlineStroke();
//     java.awt.Paint var46 = var44.getNextPaint();
//     var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var44, true);
//     boolean var49 = var0.canSelectByRegion();
//     org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var51 = var50.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.util.StrokeList var52 = new org.jfree.chart.util.StrokeList();
//     org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var60 = var59.getShape();
//     org.jfree.chart.JFreeChart var61 = null;
//     org.jfree.chart.event.ChartChangeEvent var62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var60, var61);
//     org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var65 = null;
//     var64.setOutlineStroke(var65);
//     int var67 = var64.getSeriesIndex();
//     java.awt.Stroke var68 = var64.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var70 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var71 = var70.getShadowColor();
//     int var72 = var71.getAlpha();
//     java.awt.Color var73 = var71.darker();
//     int var74 = var73.getGreen();
//     java.awt.Color var75 = java.awt.Color.getColor("", var73);
//     org.jfree.chart.LegendItem var76 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var60, var68, (java.awt.Paint)var73);
//     var52.setStroke(100, var68);
//     var50.setBaseStroke(var68, true);
//     var0.setDomainCrosshairStroke(var68);
//     
//     // Checks the contract:  equals-hashcode on var18 and var59
//     assertTrue("Contract failed: equals-hashcode on var18 and var59", var18.equals(var59) ? var18.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var18
//     assertTrue("Contract failed: equals-hashcode on var59 and var18", var59.equals(var18) ? var59.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isDomainPannable();
    var0.setForegroundAlpha(100.0f);
    org.jfree.data.KeyedObjects2D var7 = new org.jfree.data.KeyedObjects2D();
    int var9 = var7.getRowIndex((java.lang.Comparable)0L);
    int var11 = var7.getRowIndex((java.lang.Comparable)10.0f);
    int var12 = var7.getRowCount();
    int var13 = var7.getRowCount();
    java.util.List var14 = var7.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes(1, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    boolean var6 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var15 = var14.getShape();
    org.jfree.chart.JFreeChart var16 = null;
    org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var16);
    org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var20 = null;
    var19.setOutlineStroke(var20);
    int var22 = var19.getSeriesIndex();
    java.awt.Stroke var23 = var19.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var25 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var26 = var25.getShadowColor();
    int var27 = var26.getAlpha();
    java.awt.Color var28 = var26.darker();
    int var29 = var28.getGreen();
    java.awt.Color var30 = java.awt.Color.getColor("", var28);
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var15, var23, (java.awt.Paint)var28);
    var8.setBaseFillPaint((java.awt.Paint)var28, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-127), (java.awt.Paint)var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    java.awt.Stroke var14 = var10.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var30 = var28.trimWidth(0.0d);
    double var32 = var28.trimWidth(109.21460183660255d);
    boolean var34 = var28.equals((java.lang.Object)"hi!");
    var23.setInsets(var28, true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    var39.setRangeCrosshairVisible(false);
    boolean var42 = var39.isRangeGridlinesVisible();
    java.lang.String var43 = var39.getNoDataMessage();
    org.jfree.chart.entity.PlotEntity var46 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var39, "", "");
    boolean var47 = var39.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)10.0d, var6);
    boolean var8 = var0.equals((java.lang.Object)10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var11 = var0.getObject(255, (-127));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    java.lang.Number var0 = null;
    org.jfree.data.SelectableValue var2 = new org.jfree.data.SelectableValue(var0, false);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setBaseItemLabelGenerator(var5);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = var0.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.ChartColor var5 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var6 = var5.toString();
    java.awt.Color var7 = var5.darker();
    java.awt.Color var8 = java.awt.Color.getColor("org.jfree.chart.ChartColor[r=0,g=10,b=1]", var7);
    java.awt.Color var9 = java.awt.Color.getColor("Category Plot", var7);
    int var10 = var7.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var6.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var4 = null;
//     var0.setLegendTextFont(5, var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var8 = var7.getFixedRangeAxisSpace();
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var15 = var14.getShape();
//     org.jfree.chart.JFreeChart var16 = null;
//     org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var15, var16);
//     org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var20 = null;
//     var19.setOutlineStroke(var20);
//     int var22 = var19.getSeriesIndex();
//     java.awt.Stroke var23 = var19.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var25 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var26 = var25.getShadowColor();
//     int var27 = var26.getAlpha();
//     java.awt.Color var28 = var26.darker();
//     int var29 = var28.getGreen();
//     java.awt.Color var30 = java.awt.Color.getColor("", var28);
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var15, var23, (java.awt.Paint)var28);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var37 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var39 = var37.trimWidth(0.0d);
//     double var41 = var37.trimWidth(109.21460183660255d);
//     boolean var43 = var37.equals((java.lang.Object)"hi!");
//     var32.setInsets(var37, true);
//     org.jfree.chart.entity.PlotEntity var47 = new org.jfree.chart.entity.PlotEntity(var15, (org.jfree.chart.plot.Plot)var32, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
//     org.jfree.chart.util.SortOrder var48 = var32.getColumnRenderingOrder();
//     var7.setRowRenderingOrder(var48);
//     java.awt.geom.Rectangle2D var50 = null;
//     var0.drawOutline(var6, var7, var50);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.urls.CategoryURLGenerator var3 = var0.getBaseURLGenerator();
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    java.awt.Color var8 = var6.darker();
    int var9 = var8.getGreen();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-127), (java.awt.Paint)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    boolean var6 = var0.canSelectByRegion();
    boolean var7 = var0.isRangePannable();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setRangeCrosshairVisible(false);
    var8.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation((-1));
    var0.setRangeAxisLocation(var15);
    org.jfree.chart.plot.PlotOrientation var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var15, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.ValueAxis var5 = var4.getRangeAxis();
    var4.setDomainCrosshairRowKey((java.lang.Comparable)"org.jfree.chart.ChartColor[r=0,g=10,b=1]", true);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.setRangeCrosshairVisible(false);
    var10.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var17 = var10.getRangeAxisLocation((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setRangeAxisLocation((-2), var17, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     org.jfree.chart.plot.DrawingSupplier var15 = var0.getDrawingSupplier();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     var0.drawOutline(var16, var17);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     var0.clearDomainMarkers(255);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var10 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var11 = var10.getDistance();
//     int var12 = var10.getDistance();
//     var8.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var10);
//     java.awt.Shape var18 = null;
//     org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(0, 10, 1);
//     java.lang.String var23 = var22.toString();
//     org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "", "", "", var18, (java.awt.Paint)var22);
//     java.awt.Paint var25 = var24.getOutlinePaint();
//     var8.setRangeGridlinePaint(var25);
//     var0.setRangeGridlinePaint(var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var9 = var8.toString();
    int var10 = var8.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var8.createContext(var11, var12, var13, var14, var15);
    var0.setShadowPaint((java.awt.Paint)var8);
    double var18 = var0.getItemMargin();
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("");
    var23.setDatasetIndex(0);
    java.awt.Shape var26 = var23.getShape();
    org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var26, "");
    var28.setToolTipText("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var32 = var31.getUseOutlinePaint();
    var31.setItemMargin(0.0d);
    java.awt.Shape var38 = var31.getItemShape(5, (-264), false);
    var28.setArea(var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-127), var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var9.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
//     org.jfree.chart.LegendItemCollection var8 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var9 = var8.clone();
//     org.jfree.chart.util.BooleanList var10 = new org.jfree.chart.util.BooleanList();
//     var10.clear();
//     java.lang.Boolean var13 = var10.getBoolean(100);
//     boolean var14 = var8.equals((java.lang.Object)100);
//     java.util.Iterator var15 = var8.iterator();
//     var7.addAll(var8);
//     
//     // Checks the contract:  equals-hashcode on var7 and var8
//     assertTrue("Contract failed: equals-hashcode on var7 and var8", var7.equals(var8) ? var7.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var7
//     assertTrue("Contract failed: equals-hashcode on var8 and var7", var8.equals(var7) ? var8.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var1 = var0.getShadowColor();
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var0.equals((java.lang.Object)var2);
//     boolean var6 = var0.equals((java.lang.Object)(short)10);
//     int var7 = var0.calculateOffsetX();
//     double var8 = var0.getAngle();
//     java.awt.image.BufferedImage var9 = null;
//     java.awt.image.BufferedImage var10 = var0.createDropShadow(var9);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue((java.lang.Number)5, (java.lang.Comparable)(byte)10, (java.lang.Comparable)"RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.getValue(0, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    var0.clearRangeAxes();
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var0.panRangeAxes(0.05d, var16, var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var4 = var3.getOutlinePaint();
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("hi!", var4);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var8 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var9 = var8.getDistance();
//     int var10 = var8.getDistance();
//     var6.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var8);
//     float var12 = var6.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var14 = null;
//     var6.setDomainAxisLocation(10, var14, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     var6.setRenderer(255, var18, false);
//     java.awt.Paint var21 = var6.getDomainCrosshairPaint();
//     boolean var22 = var5.equals((java.lang.Object)var6);
//     boolean var23 = var0.hasListener((java.util.EventListener)var6);
//     java.awt.Paint var24 = var6.getDomainGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.setRangeCrosshairVisible(false);
//     var25.setCrosshairDatasetIndex(255, false);
//     boolean var31 = var25.canSelectByRegion();
//     boolean var32 = var25.isRangePannable();
//     java.awt.Graphics2D var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.chart.plot.CategoryCrosshairState var37 = null;
//     boolean var38 = var25.render(var33, var34, 10, var36, var37);
//     java.lang.Comparable var39 = var25.getDomainCrosshairRowKey();
//     org.jfree.data.category.CategoryDataset var40 = null;
//     var25.setDataset(var40);
//     org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var46 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var47 = var46.getDistance();
//     int var48 = var46.getDistance();
//     var44.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var46);
//     float var50 = var44.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var52 = null;
//     var44.setDomainAxisLocation(10, var52, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = null;
//     var44.setRenderer(255, var56, false);
//     org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var65 = var64.getShape();
//     org.jfree.chart.JFreeChart var66 = null;
//     org.jfree.chart.event.ChartChangeEvent var67 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var65, var66);
//     org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var70 = null;
//     var69.setOutlineStroke(var70);
//     int var72 = var69.getSeriesIndex();
//     java.awt.Stroke var73 = var69.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var75 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var76 = var75.getShadowColor();
//     int var77 = var76.getAlpha();
//     java.awt.Color var78 = var76.darker();
//     int var79 = var78.getGreen();
//     java.awt.Color var80 = java.awt.Color.getColor("", var78);
//     org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var65, var73, (java.awt.Paint)var78);
//     var44.setDomainGridlineStroke(var73);
//     var43.setTickMarkStroke(var73);
//     var25.setRangeMinorGridlineStroke(var73);
//     var6.setDomainGridlineStroke(var73);
//     
//     // Checks the contract:  equals-hashcode on var3 and var64
//     assertTrue("Contract failed: equals-hashcode on var3 and var64", var3.equals(var64) ? var3.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var3
//     assertTrue("Contract failed: equals-hashcode on var64 and var3", var64.equals(var3) ? var64.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var44
//     assertTrue("Contract failed: equals-hashcode on var6 and var44", var6.equals(var44) ? var6.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var6
//     assertTrue("Contract failed: equals-hashcode on var44 and var6", var44.equals(var6) ? var44.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getColumnCount();
    java.util.List var6 = var0.getRowKeys();
    int var7 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var10 = var0.getObject((java.lang.Comparable)(-9.21460183660255d), (java.lang.Comparable)(-16777216));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var2 = var1.getShadowColor();
    int var3 = var2.getAlpha();
    java.awt.Color var4 = var2.darker();
    int var5 = var4.getGreen();
    java.awt.Color var6 = java.awt.Color.getColor("", var4);
    java.awt.Paint[] var7 = new java.awt.Paint[] { var4};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var12 = var11.getOutlinePaint();
    boolean var13 = var9.equals((java.lang.Object)var12);
    java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    float[] var22 = null;
    float[] var23 = var21.getComponents(var22);
    java.awt.Paint[] var24 = new java.awt.Paint[] { var21};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var31 = null;
    var30.setOutlineStroke(var31);
    int var33 = var30.getSeriesIndex();
    java.awt.Stroke var34 = var30.getOutlineStroke();
    java.awt.Shape var35 = var30.getShape();
    java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
    org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var14, var24, var26, var28, var36);
    org.jfree.data.category.AbstractCategoryDataset var38 = new org.jfree.data.category.AbstractCategoryDataset();
    java.util.EventListener var39 = null;
    boolean var40 = var38.hasListener(var39);
    org.jfree.data.category.CategoryDatasetSelectionState var41 = var38.getSelectionState();
    org.jfree.data.category.CategoryDatasetSelectionState var42 = null;
    var38.setSelectionState(var42);
    org.jfree.chart.util.ObjectList var45 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var47 = var45.get(1);
    int var48 = var45.size();
    org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var51 = null;
    var50.setOutlineStroke(var51);
    int var53 = var50.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var54 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var55 = var54.getShadowColor();
    var50.setLinePaint((java.awt.Paint)var55);
    org.jfree.data.category.AbstractCategoryDataset var57 = new org.jfree.data.category.AbstractCategoryDataset();
    var50.setDataset((org.jfree.data.general.Dataset)var57);
    org.jfree.chart.event.DatasetChangeInfo var59 = new org.jfree.chart.event.DatasetChangeInfo();
    org.jfree.data.event.DatasetChangeEvent var60 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var45, (org.jfree.data.general.Dataset)var57, var59);
    org.jfree.chart.event.DatasetChangeInfo var61 = var60.getInfo();
    org.jfree.data.event.DatasetChangeEvent var62 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var28, (org.jfree.data.general.Dataset)var38, var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var7 = var4.getRight();
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var11 = var4.createOutsetRectangle(var8, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-0.7853981633974483d));

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var4 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var5 = var4.getDistance();
    int var6 = var4.getDistance();
    var2.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var4);
    float var8 = var2.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var10 = null;
    var2.setDomainAxisLocation(10, var10, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var2.setRenderer(255, var14, false);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var23 = var22.getShape();
    org.jfree.chart.JFreeChart var24 = null;
    org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var23, var24);
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var28 = null;
    var27.setOutlineStroke(var28);
    int var30 = var27.getSeriesIndex();
    java.awt.Stroke var31 = var27.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var33 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var34 = var33.getShadowColor();
    int var35 = var34.getAlpha();
    java.awt.Color var36 = var34.darker();
    int var37 = var36.getGreen();
    java.awt.Color var38 = java.awt.Color.getColor("", var36);
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var23, var31, (java.awt.Paint)var36);
    var2.setDomainGridlineStroke(var31);
    var1.setTickMarkStroke(var31);
    org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var48 = var46.trimWidth(0.0d);
    double var49 = var46.getRight();
    var1.setLabelInsets(var46, false);
    java.awt.geom.Rectangle2D var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var53 = var46.createOutsetRectangle(var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-0.7853981633974483d));

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var4 = null;
//     var0.setLegendTextFont(5, var4);
//     boolean var6 = var0.getAutoPopulateSeriesFillPaint();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.setRangeCrosshairVisible(false);
//     boolean var14 = var11.isRangeMinorGridlinesVisible();
//     org.jfree.chart.LegendItem var16 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var17 = null;
//     var16.setOutlineStroke(var17);
//     int var19 = var16.getSeriesIndex();
//     org.jfree.chart.util.DefaultShadowGenerator var20 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var21 = var20.getShadowColor();
//     var16.setLinePaint((java.awt.Paint)var21);
//     var11.setOutlinePaint((java.awt.Paint)var21);
//     org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var30 = var29.getShape();
//     org.jfree.chart.JFreeChart var31 = null;
//     org.jfree.chart.event.ChartChangeEvent var32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var30, var31);
//     org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var35 = null;
//     var34.setOutlineStroke(var35);
//     int var37 = var34.getSeriesIndex();
//     java.awt.Stroke var38 = var34.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var40 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var41 = var40.getShadowColor();
//     int var42 = var41.getAlpha();
//     java.awt.Color var43 = var41.darker();
//     int var44 = var43.getGreen();
//     java.awt.Color var45 = java.awt.Color.getColor("", var43);
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var30, var38, (java.awt.Paint)var43);
//     var0.drawDomainLine(var7, var8, var9, 0.2d, (java.awt.Paint)var21, var38);
// 
//   }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var6 = var5.getShape();
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     int var13 = var10.getSeriesIndex();
//     java.awt.Stroke var14 = var10.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var30 = var28.trimWidth(0.0d);
//     double var32 = var28.trimWidth(109.21460183660255d);
//     boolean var34 = var28.equals((java.lang.Object)"hi!");
//     var23.setInsets(var28, true);
//     org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
//     org.jfree.chart.util.SortOrder var39 = var23.getColumnRenderingOrder();
//     org.jfree.chart.plot.Marker var41 = null;
//     org.jfree.chart.util.Layer var42 = null;
//     var23.addRangeMarker(0, var41, var42, false);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    var0.setMaximumBarWidth(100.0d);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var14 = null;
    var13.setOutlineStroke(var14);
    int var16 = var13.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var18 = var17.getShadowColor();
    int var19 = var18.getAlpha();
    var13.setLinePaint((java.awt.Paint)var18);
    org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var22 = var21.getShadowColor();
    int var23 = var22.getAlpha();
    java.awt.Color var24 = var22.darker();
    java.awt.image.ColorModel var25 = null;
    java.awt.Rectangle var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    java.awt.geom.AffineTransform var28 = null;
    java.awt.RenderingHints var29 = null;
    java.awt.PaintContext var30 = var24.createContext(var25, var26, var27, var28, var29);
    var13.setFillPaint((java.awt.Paint)var24);
    var0.setBaseFillPaint((java.awt.Paint)var24, true);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.configureDomainAxes();
    java.lang.Object var36 = var34.clone();
    java.awt.Stroke var37 = var34.getRangeGridlineStroke();
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-2), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var2 = var1.clone();
    java.lang.Object var4 = var1.get(1);
    org.jfree.chart.renderer.category.BarPainter var5 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var5);
    int var7 = var1.indexOf((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var2 = var1.getShape();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var9 = var8.getShape();
    org.jfree.chart.JFreeChart var10 = null;
    org.jfree.chart.event.ChartChangeEvent var11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var10);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var14 = null;
    var13.setOutlineStroke(var14);
    int var16 = var13.getSeriesIndex();
    java.awt.Stroke var17 = var13.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var19 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var20 = var19.getShadowColor();
    int var21 = var20.getAlpha();
    java.awt.Color var22 = var20.darker();
    int var23 = var22.getGreen();
    java.awt.Color var24 = java.awt.Color.getColor("", var22);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var9, var17, (java.awt.Paint)var22);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var31 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var33 = var31.trimWidth(0.0d);
    double var35 = var31.trimWidth(109.21460183660255d);
    boolean var37 = var31.equals((java.lang.Object)"hi!");
    var26.setInsets(var31, true);
    org.jfree.chart.entity.PlotEntity var41 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var26, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    var1.setLine(var9);
    java.awt.Font var43 = var1.getLabelFont();
    java.awt.Font var44 = var1.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var6 = var5.getShape();
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     int var13 = var10.getSeriesIndex();
//     java.awt.Stroke var14 = var10.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var30 = var28.trimWidth(0.0d);
//     double var32 = var28.trimWidth(109.21460183660255d);
//     boolean var34 = var28.equals((java.lang.Object)"hi!");
//     var23.setInsets(var28, true);
//     org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.setRangeCrosshairVisible(false);
//     boolean var42 = var39.isRangeGridlinesVisible();
//     java.lang.String var43 = var39.getNoDataMessage();
//     org.jfree.chart.entity.PlotEntity var46 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var39, "", "");
//     var39.zoom(0.0d);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    int var8 = var5.getSeriesIndex();
    java.awt.Stroke var9 = var5.getOutlineStroke();
    java.awt.Shape var10 = var5.getShape();
    org.jfree.chart.util.DefaultShadowGenerator var11 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var12 = var11.getShadowColor();
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var15 = null;
    var14.setOutlineStroke(var15);
    int var17 = var14.getSeriesIndex();
    java.awt.Stroke var18 = var14.getLineStroke();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var22 = var21.getDistance();
    int var23 = var21.getDistance();
    var19.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var21);
    float var25 = var19.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var27 = null;
    var19.setDomainAxisLocation(10, var27, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    var19.setRenderer(255, var31, false);
    java.awt.Paint var34 = var19.getDomainCrosshairPaint();
    java.awt.Paint var35 = var19.getRangeCrosshairPaint();
    java.awt.Color var38 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", (-1));
    var19.setOutlinePaint((java.awt.Paint)var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem(var0, "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "Category Plot", var10, (java.awt.Paint)var12, var18, (java.awt.Paint)var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
    var1.setDefaultFillPaint((java.awt.Paint)var13);
    java.awt.Paint var15 = var1.getDefaultPaint();
    java.awt.Paint var16 = var1.getDefaultPaint();
    org.jfree.chart.util.StrokeList var18 = new org.jfree.chart.util.StrokeList();
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var26 = var25.getShape();
    org.jfree.chart.JFreeChart var27 = null;
    org.jfree.chart.event.ChartChangeEvent var28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var26, var27);
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var31 = null;
    var30.setOutlineStroke(var31);
    int var33 = var30.getSeriesIndex();
    java.awt.Stroke var34 = var30.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var36 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var37 = var36.getShadowColor();
    int var38 = var37.getAlpha();
    java.awt.Color var39 = var37.darker();
    int var40 = var39.getGreen();
    java.awt.Color var41 = java.awt.Color.getColor("", var39);
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var26, var34, (java.awt.Paint)var39);
    var18.setStroke(100, var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesStroke((-264), var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected(1, (-16777216), false);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var4 = null;
//     var0.setLegendTextFont(5, var4);
//     java.awt.Font var6 = null;
//     var0.setBaseLegendTextFont(var6);
//     var0.clearSeriesStrokes(false);
//     double var10 = var0.getShadowXOffset();
//     org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
//     var0.setBaseToolTipGenerator(var11);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.configureDomainAxes();
//     java.lang.Object var19 = var17.clone();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var22 = var20.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.data.category.DefaultCategoryDataset var24 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var25 = var24.getRowCount();
//     var24.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var32 = var30.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var37 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var38 = var37.getUnitType();
//     var30.setTickLabelInsets(var37);
//     var30.setMinorTickMarkInsideLength(0.5f);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var43.setBaseShapesVisible(false);
//     java.awt.Paint var46 = var43.getBaseItemLabelPaint();
//     java.lang.Boolean var48 = var43.getSeriesShapesFilled(1);
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, var30, var42, (org.jfree.chart.renderer.category.CategoryItemRenderer)var43);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var53 = null;
//     boolean var54 = var0.hitTest(8.21460183660255d, (-0.7853981633974483d), var15, var16, var17, var20, var23, (org.jfree.data.category.CategoryDataset)var24, 0, (-16777216), false, var53);
// 
//   }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation((-1));
    org.jfree.chart.plot.PlotOrientation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var9 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.clearSelection();
    org.jfree.chart.util.SortOrder var4 = var0.getColumnRenderingOrder();
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.panRangeAxes(4.0d, var6, var7);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    java.util.List var10 = var0.getCategoriesForAxis(var9);
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.configureDomainAxes();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var14.removeDomainMarker(var16, var17);
    org.jfree.chart.axis.ValueAxis var20 = var14.getRangeAxis(255);
    org.jfree.chart.util.RectangleEdge var22 = var14.getDomainAxisEdge(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var9.getCategoryMiddle(5, (-1), var13, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(0);
    var2.setShadowVisible(false);
    org.jfree.chart.ChartColor var10 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var11 = var10.toString();
    int var12 = var10.getAlpha();
    java.awt.image.ColorModel var13 = null;
    java.awt.Rectangle var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    java.awt.geom.AffineTransform var16 = null;
    java.awt.RenderingHints var17 = null;
    java.awt.PaintContext var18 = var10.createContext(var13, var14, var15, var16, var17);
    var2.setShadowPaint((java.awt.Paint)var10);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var23 = null;
    var22.setOutlineStroke(var23);
    var22.setURLText("");
    var22.setToolTipText("hi!");
    org.jfree.chart.util.GradientPaintTransformer var29 = var22.getFillPaintTransformer();
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var32 = var31.getShape();
    org.jfree.chart.JFreeChart var33 = null;
    org.jfree.chart.event.ChartChangeEvent var34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var32, var33);
    var22.setLine(var32);
    var2.setLegendShape(100, var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-264), var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var11.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-4,-4,4,4", var1);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     float var1 = var0.getShadowOpacity();
//     float var2 = var0.getShadowOpacity();
//     java.awt.image.BufferedImage var3 = null;
//     java.awt.image.BufferedImage var4 = var0.createDropShadow(var3);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var8 = var7.getUnitType();
//     var0.setTickLabelInsets(var7);
//     org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var16 = var14.trimWidth(0.0d);
//     double var18 = var14.calculateTopInset(0.0d);
//     double var20 = var14.extendWidth(100.0d);
//     java.lang.String var21 = var14.toString();
//     var0.setLabelInsets(var14);
//     org.jfree.chart.plot.Plot var23 = var0.getPlot();
//     var0.setVisible(true);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.axis.AxisState var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.ObjectList var30 = new org.jfree.chart.util.ObjectList(10);
//     java.lang.Object var32 = var30.get(1);
//     int var33 = var30.size();
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var36 = null;
//     var35.setOutlineStroke(var36);
//     int var38 = var35.getSeriesIndex();
//     org.jfree.chart.util.DefaultShadowGenerator var39 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var40 = var39.getShadowColor();
//     var35.setLinePaint((java.awt.Paint)var40);
//     org.jfree.data.category.AbstractCategoryDataset var42 = new org.jfree.data.category.AbstractCategoryDataset();
//     var35.setDataset((org.jfree.data.general.Dataset)var42);
//     org.jfree.chart.event.DatasetChangeInfo var44 = new org.jfree.chart.event.DatasetChangeInfo();
//     org.jfree.data.event.DatasetChangeEvent var45 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var30, (org.jfree.data.general.Dataset)var42, var44);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
//     var46.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var48 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var49 = var48.getDistance();
//     int var50 = var48.getDistance();
//     var46.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var48);
//     var42.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var46);
//     org.jfree.chart.util.RectangleEdge var53 = var46.getRangeAxisEdge();
//     java.util.List var54 = var0.refreshTicks(var26, var27, var28, var53);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    int var14 = var0.getDomainAxisCount();
    int var15 = var0.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var16 = var0.getAxisOffset();
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var18, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.SelectableValue var2 = new org.jfree.data.SelectableValue((java.lang.Number)(short)1, true);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.clearSelection();
    org.jfree.chart.util.SortOrder var4 = var0.getColumnRenderingOrder();
    org.jfree.chart.axis.AxisSpace var5 = null;
    var0.setFixedDomainAxisSpace(var5, false);
    java.lang.Object var8 = var0.clone();
    boolean var9 = var0.isRangeGridlinesVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxis((-264), (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    var0.clearSeriesStrokes(false);
    double var10 = var0.getShadowXOffset();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var0.setBaseToolTipGenerator(var11);
    var0.setBaseSeriesVisible(false);
    org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var18 = null;
    var17.setOutlineStroke(var18);
    int var20 = var17.getSeriesIndex();
    java.awt.Stroke var21 = var17.getOutlineStroke();
    java.awt.Shape var22 = var17.getShape();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-16777216), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    org.jfree.chart.plot.DrawingSupplier var15 = var0.getDrawingSupplier();
    float var16 = var0.getBackgroundImageAlpha();
    java.awt.Paint var17 = var0.getRangeGridlinePaint();
    var0.setAnchorValue(0.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
    var0.setSeriesItemLabelPaint(1, (java.awt.Paint)var8, false);
    var0.setDefaultEntityRadius(0);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var17 = var16.getDistance();
    int var18 = var16.getDistance();
    var14.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var16);
    float var20 = var14.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var22 = null;
    var14.setDomainAxisLocation(10, var22, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    var14.setRenderer(255, var26, false);
    org.jfree.chart.plot.DrawingSupplier var29 = var14.getDrawingSupplier();
    float var30 = var14.getBackgroundImageAlpha();
    java.awt.geom.Rectangle2D var31 = null;
    java.awt.Paint var33 = null;
    java.awt.Stroke var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawDomainLine(var13, var14, var31, (-9.21460183660255d), var33, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.5f);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    int var14 = var0.getDomainAxisCount();
    org.jfree.chart.plot.Plot var15 = var0.getParent();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var19 = var17.getRangeAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-264), var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    java.lang.String var2 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var2.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
//     var6.setDatasetIndex(0);
//     java.awt.Shape var9 = var6.getShape();
//     org.jfree.chart.ChartColor var14 = new org.jfree.chart.ChartColor(10, 1, 0);
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     org.jfree.chart.LegendItemCollection var18 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var19 = var18.clone();
//     boolean var20 = var16.equals((java.lang.Object)var18);
//     boolean var22 = var16.equals((java.lang.Object)(short)10);
//     java.awt.Color var23 = var16.getShadowColor();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var26 = var24.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var31 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var32 = var31.getUnitType();
//     var24.setTickLabelInsets(var31);
//     org.jfree.chart.util.RectangleInsets var38 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var40 = var38.trimWidth(0.0d);
//     double var42 = var38.calculateTopInset(0.0d);
//     double var44 = var38.extendWidth(100.0d);
//     java.lang.String var45 = var38.toString();
//     var24.setLabelInsets(var38);
//     java.awt.Paint var47 = var24.getTickLabelPaint();
//     org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var50 = var48.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var51 = var48.getBaseItemLabelGenerator();
//     java.awt.Stroke var53 = var48.lookupSeriesOutlineStroke(15);
//     var24.setAxisLineStroke(var53);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var57 = var56.getUseOutlinePaint();
//     var56.setItemMargin(0.0d);
//     java.awt.Shape var63 = var56.getItemShape(5, (-264), false);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.configureDomainAxes();
//     java.lang.Object var66 = var64.clone();
//     java.awt.Stroke var67 = var64.getRangeGridlineStroke();
//     org.jfree.chart.renderer.RenderAttributes var69 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("");
//     var72.setDatasetIndex(0);
//     java.awt.Paint var75 = var72.getFillPaint();
//     org.jfree.data.KeyedObject var76 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var75);
//     var69.setDefaultLabelPaint(var75);
//     java.awt.Paint var78 = var69.getDefaultLabelPaint();
//     org.jfree.chart.LegendItem var79 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=-1]", "ChartEntity: tooltip = ", "PlotEntity: tooltip = ", "hi!", false, var9, true, (java.awt.Paint)var14, true, (java.awt.Paint)var23, var53, true, var63, var67, var78);
//     
//     // Checks the contract:  equals-hashcode on var6 and var72
//     assertTrue("Contract failed: equals-hashcode on var6 and var72", var6.equals(var72) ? var6.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var6
//     assertTrue("Contract failed: equals-hashcode on var72 and var6", var72.equals(var6) ? var72.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    int var7 = var0.getRowIndex((java.lang.Comparable)(short)10);
    java.util.List var8 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)"TextAnchor.CENTER", (java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=-1]");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     var0.setShadowVisible(false);
//     org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var6 = var5.getShadowColor();
//     int var7 = var6.getAlpha();
//     var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
//     var0.setMaximumBarWidth(100.0d);
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var14 = null;
//     var13.setOutlineStroke(var14);
//     int var16 = var13.getSeriesIndex();
//     org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var18 = var17.getShadowColor();
//     int var19 = var18.getAlpha();
//     var13.setLinePaint((java.awt.Paint)var18);
//     org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var22 = var21.getShadowColor();
//     int var23 = var22.getAlpha();
//     java.awt.Color var24 = var22.darker();
//     java.awt.image.ColorModel var25 = null;
//     java.awt.Rectangle var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     java.awt.geom.AffineTransform var28 = null;
//     java.awt.RenderingHints var29 = null;
//     java.awt.PaintContext var30 = var24.createContext(var25, var26, var27, var28, var29);
//     var13.setFillPaint((java.awt.Paint)var24);
//     var0.setBaseFillPaint((java.awt.Paint)var24, true);
//     org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var36 = var34.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var37 = var34.getBaseItemLabelGenerator();
//     java.awt.Stroke var39 = var34.lookupSeriesOutlineStroke(15);
//     org.jfree.chart.labels.ItemLabelPosition var43 = var34.getNegativeItemLabelPosition(1, 5, true);
//     var0.setPositiveItemLabelPositionFallback(var43);
//     
//     // Checks the contract:  equals-hashcode on var2 and var36
//     assertTrue("Contract failed: equals-hashcode on var2 and var36", var2.equals(var36) ? var2.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var43
//     assertTrue("Contract failed: equals-hashcode on var2 and var43", var2.equals(var43) ? var2.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var2
//     assertTrue("Contract failed: equals-hashcode on var36 and var2", var36.equals(var2) ? var36.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var2
//     assertTrue("Contract failed: equals-hashcode on var43 and var2", var43.equals(var2) ? var43.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var6 = var5.getShape();
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     int var13 = var10.getSeriesIndex();
//     java.awt.Stroke var14 = var10.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var30 = var28.trimWidth(0.0d);
//     double var32 = var28.trimWidth(109.21460183660255d);
//     boolean var34 = var28.equals((java.lang.Object)"hi!");
//     var23.setInsets(var28, true);
//     org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
//     org.jfree.chart.util.SortOrder var39 = var23.getColumnRenderingOrder();
//     org.jfree.chart.util.RectangleInsets var40 = var23.getAxisOffset();
//     var23.setDrawSharedDomainAxis(false);
//     boolean var43 = var23.isOutlineVisible();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.setRangeCrosshairVisible(false);
//     var44.setCrosshairDatasetIndex(255, false);
//     boolean var50 = var44.canSelectByRegion();
//     var44.clearDomainMarkers();
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.setRangeCrosshairVisible(false);
//     var52.setCrosshairDatasetIndex(255, false);
//     boolean var58 = var52.canSelectByRegion();
//     boolean var59 = var52.isRangePannable();
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     var60.setRangeCrosshairVisible(false);
//     var60.setCrosshairDatasetIndex(255, false);
//     org.jfree.chart.axis.AxisLocation var67 = var60.getRangeAxisLocation((-1));
//     var52.setRangeAxisLocation(var67);
//     var44.setDomainAxisLocation(var67, false);
//     var23.setDomainAxisLocation(var67);
//     org.jfree.data.category.AbstractCategoryDataset var72 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.LegendItem var75 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var76 = var75.getOutlinePaint();
//     org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem("hi!", var76);
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
//     var78.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var80 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var81 = var80.getDistance();
//     int var82 = var80.getDistance();
//     var78.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var80);
//     float var84 = var78.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var86 = null;
//     var78.setDomainAxisLocation(10, var86, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var90 = null;
//     var78.setRenderer(255, var90, false);
//     java.awt.Paint var93 = var78.getDomainCrosshairPaint();
//     boolean var94 = var77.equals((java.lang.Object)var78);
//     boolean var95 = var72.hasListener((java.util.EventListener)var78);
//     java.awt.Paint var96 = var78.getDomainGridlinePaint();
//     var23.setDomainGridlinePaint(var96);
//     
//     // Checks the contract:  equals-hashcode on var5 and var75
//     assertTrue("Contract failed: equals-hashcode on var5 and var75", var5.equals(var75) ? var5.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var5
//     assertTrue("Contract failed: equals-hashcode on var75 and var5", var75.equals(var5) ? var75.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     java.awt.Paint var2 = var1.getDefaultLabelPaint();
//     java.lang.Boolean var4 = var1.getSeriesCreateEntity((-2));
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setRangeCrosshairVisible(false);
    var16.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation((-1));
    var0.setDomainAxisLocation(100, var23, true);
    org.jfree.chart.plot.PlotOrientation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var23, var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    int var14 = var0.getDomainAxisCount();
    int var15 = var0.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var16 = var0.getAxisOffset();
    double var18 = var16.extendHeight(100.0d);
    double var20 = var16.trimWidth(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 108.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0d);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    java.util.List var2 = var0.getKeys();
    java.lang.Object var3 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(7);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var2 = var1.getShadowColor();
    int var3 = var2.getAlpha();
    java.awt.Color var4 = var2.darker();
    int var5 = var4.getGreen();
    java.awt.Color var6 = java.awt.Color.getColor("", var4);
    float[] var7 = null;
    float[] var8 = var6.getComponents(var7);
    java.awt.Shape var13 = null;
    org.jfree.chart.ChartColor var17 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var18 = var17.toString();
    org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("", "", "", "", var13, (java.awt.Paint)var17);
    int var20 = var17.getAlpha();
    org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var22 = var21.getShadowColor();
    int var23 = var22.getAlpha();
    java.awt.Color var24 = var22.darker();
    int var25 = var24.getGreen();
    org.jfree.chart.util.DefaultShadowGenerator var27 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var28 = var27.getShadowColor();
    int var29 = var28.getAlpha();
    java.awt.Color var30 = var28.darker();
    int var31 = var30.getGreen();
    java.awt.Color var32 = java.awt.Color.getColor("", var30);
    float[] var33 = null;
    float[] var34 = var32.getComponents(var33);
    float[] var35 = var24.getComponents(var33);
    float[] var36 = var17.getColorComponents(var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var37 = var6.getRGBComponents(var36);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var18.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     org.jfree.chart.plot.DrawingSupplier var15 = var0.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var16 = null;
//     var0.addRangeMarker(var16);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Shape var17 = var1.getSeriesShape(100);
//     java.awt.Paint var20 = var1.getItemPaint((-16777216), (-127));
//     java.awt.Stroke var23 = var1.getItemOutlineStroke(1, 0);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var2 = var1.clone();
    java.lang.Object var3 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     var0.setShadowVisible(false);
//     org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var6 = var5.getShadowColor();
//     int var7 = var6.getAlpha();
//     var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
//     var0.setMaximumBarWidth(100.0d);
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var14 = null;
//     var13.setOutlineStroke(var14);
//     int var16 = var13.getSeriesIndex();
//     org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var18 = var17.getShadowColor();
//     int var19 = var18.getAlpha();
//     var13.setLinePaint((java.awt.Paint)var18);
//     org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var22 = var21.getShadowColor();
//     int var23 = var22.getAlpha();
//     java.awt.Color var24 = var22.darker();
//     java.awt.image.ColorModel var25 = null;
//     java.awt.Rectangle var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     java.awt.geom.AffineTransform var28 = null;
//     java.awt.RenderingHints var29 = null;
//     java.awt.PaintContext var30 = var24.createContext(var25, var26, var27, var28, var29);
//     var13.setFillPaint((java.awt.Paint)var24);
//     var0.setBaseFillPaint((java.awt.Paint)var24, true);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.configureDomainAxes();
//     java.lang.Object var36 = var34.clone();
//     java.awt.Stroke var37 = var34.getRangeGridlineStroke();
//     boolean var38 = var0.hasListener((java.util.EventListener)var34);
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var41 = var39.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var42 = var39.getBaseItemLabelGenerator();
//     java.awt.Stroke var44 = var39.lookupSeriesOutlineStroke(15);
//     var0.setBaseOutlineStroke(var44, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var41
//     assertTrue("Contract failed: equals-hashcode on var2 and var41", var2.equals(var41) ? var2.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var2
//     assertTrue("Contract failed: equals-hashcode on var41 and var2", var41.equals(var2) ? var41.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.util.GradientPaintTransformer var4 = var1.getFillPaintTransformer();
    var1.setLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
//     java.lang.Boolean var5 = var0.getSeriesVisible((-127));
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var16 = var14.trimWidth(0.0d);
//     double var18 = var14.trimWidth(109.21460183660255d);
//     boolean var20 = var14.equals((java.lang.Object)"hi!");
//     var9.setInsets(var14, true);
//     int var23 = var9.getDomainAxisCount();
//     org.jfree.chart.plot.Plot var24 = var9.getParent();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var27 = var25.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var32 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var33 = var32.getUnitType();
//     var25.setTickLabelInsets(var32);
//     org.jfree.chart.util.RectangleInsets var39 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var41 = var39.trimWidth(0.0d);
//     double var43 = var39.calculateTopInset(0.0d);
//     double var45 = var39.extendWidth(100.0d);
//     java.lang.String var46 = var39.toString();
//     var25.setLabelInsets(var39);
//     org.jfree.chart.plot.Plot var48 = var25.getPlot();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.setRangeCrosshairVisible(false);
//     var49.clearSelection();
//     org.jfree.chart.util.SortOrder var53 = var49.getColumnRenderingOrder();
//     var25.addChangeListener((org.jfree.chart.event.AxisChangeListener)var49);
//     org.jfree.chart.axis.CategoryLabelPositions var55 = var25.getCategoryLabelPositions();
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.data.category.DefaultCategoryDataset var57 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var58 = var57.getRowCount();
//     var57.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
//     org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var65 = var63.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var70 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var71 = var70.getUnitType();
//     var63.setTickLabelInsets(var70);
//     var63.setMinorTickMarkInsideLength(0.5f);
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var76 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var76.setBaseShapesVisible(false);
//     java.awt.Paint var79 = var76.getBaseItemLabelPaint();
//     java.lang.Boolean var81 = var76.getSeriesShapesFilled(1);
//     org.jfree.chart.plot.CategoryPlot var82 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var57, var63, var75, (org.jfree.chart.renderer.category.CategoryItemRenderer)var76);
//     var0.drawItem(var6, var7, var8, var9, var25, var56, (org.jfree.data.category.CategoryDataset)var57, 15, 4, true, 10);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4, var5, var6);
    org.jfree.chart.event.ChartChangeEventType var8 = var7.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    java.util.List var2 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((java.lang.Comparable)(byte)100);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.lang.Boolean var7 = null;
    var0.setSeriesVisibleInLegend(0, var7);
    double var9 = var0.getMinimumBarLength();
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var0.notifyListeners(var10);
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-16777215), var13, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
    var1.setDefaultFillPaint((java.awt.Paint)var13);
    java.awt.Paint var15 = var1.getDefaultPaint();
    java.awt.Paint var17 = var1.getSeriesPaint(255);
    java.awt.Paint var19 = var1.getSeriesPaint((-1));
    org.jfree.data.category.DefaultCategoryDataset var21 = new org.jfree.data.category.DefaultCategoryDataset();
    int var22 = var21.getRowCount();
    var21.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var29 = var27.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var34 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var35 = var34.getUnitType();
    var27.setTickLabelInsets(var34);
    var27.setMinorTickMarkInsideLength(0.5f);
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var40.setBaseShapesVisible(false);
    java.awt.Paint var43 = var40.getBaseItemLabelPaint();
    java.lang.Boolean var45 = var40.getSeriesShapesFilled(1);
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var21, var27, var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
    java.awt.Paint var48 = var40.lookupSeriesFillPaint(1);
    var1.setSeriesOutlinePaint(1, var48);
    java.awt.Stroke var51 = var1.getSeriesStroke(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis();
    org.jfree.chart.util.RectangleInsets var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var8 = var7.getUnitType();
    var0.setTickLabelInsets(var7);
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var16 = var14.trimWidth(0.0d);
    double var18 = var14.calculateTopInset(0.0d);
    double var20 = var14.extendWidth(100.0d);
    java.lang.String var21 = var14.toString();
    var0.setLabelInsets(var14);
    org.jfree.chart.plot.Plot var23 = var0.getPlot();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.setRangeCrosshairVisible(false);
    var24.clearSelection();
    org.jfree.chart.util.SortOrder var28 = var24.getColumnRenderingOrder();
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var24);
    var0.setFixedDimension(1.0d);
    org.jfree.chart.util.RectangleInsets var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelInsets(var32, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 109.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"+ "'", var21.equals("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setItemMargin(0.0d);
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = var0.getToolTipGenerator(5, 15, true);
    var0.removeAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.lang.Object var1 = var0.clone();
    int var2 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var4 = var0.get(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    var0.setAnchorValue(10.0d, true);
    org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxisForDataset(5);
    var0.setRangeCrosshairLockedOnData(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    int var6 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var1 = var0.getShadowColor();
//     org.jfree.chart.LegendItemCollection var2 = new org.jfree.chart.LegendItemCollection();
//     java.lang.Object var3 = var2.clone();
//     boolean var4 = var0.equals((java.lang.Object)var2);
//     boolean var6 = var0.equals((java.lang.Object)(short)10);
//     java.awt.Color var7 = var0.getShadowColor();
//     boolean var9 = var0.equals((java.lang.Object)(-1L));
//     java.awt.image.BufferedImage var10 = null;
//     java.awt.image.BufferedImage var11 = var0.createDropShadow(var10);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     boolean var3 = var0.isDomainPannable();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var11 = var9.trimWidth(0.0d);
//     double var13 = var9.trimWidth(109.21460183660255d);
//     boolean var15 = var9.equals((java.lang.Object)"hi!");
//     var4.setInsets(var9, true);
//     var4.clearRangeAxes();
//     var0.setParent((org.jfree.chart.plot.Plot)var4);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     var4.drawBackground(var20, var21);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.LegendItem var7 = var0.getLegendItem(100, (-264));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.chart.util.GradientPaintTransformer var4 = var1.getFillPaintTransformer();
    java.awt.Paint var5 = var1.getOutlinePaint();
    java.lang.String var6 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    boolean var6 = var0.canSelectByRegion();
    var0.setDomainCrosshairRowKey((java.lang.Comparable)(-1), false);
    int var10 = var0.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 15);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.clearSelection();
//     org.jfree.chart.util.SortOrder var4 = var0.getColumnRenderingOrder();
//     org.jfree.chart.axis.AxisSpace var5 = null;
//     var0.setFixedDomainAxisSpace(var5, false);
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setRangeCrosshairVisible(false);
//     var8.setCrosshairDatasetIndex(255, false);
//     boolean var14 = var8.canSelectByRegion();
//     boolean var15 = var8.isRangePannable();
//     java.awt.Graphics2D var16 = null;
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     org.jfree.chart.plot.CategoryCrosshairState var20 = null;
//     boolean var21 = var8.render(var16, var17, 10, var19, var20);
//     java.lang.Comparable var22 = var8.getDomainCrosshairRowKey();
//     org.jfree.data.category.CategoryDataset var23 = null;
//     var8.setDataset(var23);
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var29 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var30 = var29.getDistance();
//     int var31 = var29.getDistance();
//     var27.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var29);
//     float var33 = var27.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var27.setDomainAxisLocation(10, var35, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     var27.setRenderer(255, var39, false);
//     org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var48 = var47.getShape();
//     org.jfree.chart.JFreeChart var49 = null;
//     org.jfree.chart.event.ChartChangeEvent var50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var48, var49);
//     org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var53 = null;
//     var52.setOutlineStroke(var53);
//     int var55 = var52.getSeriesIndex();
//     java.awt.Stroke var56 = var52.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var58 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var59 = var58.getShadowColor();
//     int var60 = var59.getAlpha();
//     java.awt.Color var61 = var59.darker();
//     int var62 = var61.getGreen();
//     java.awt.Color var63 = java.awt.Color.getColor("", var61);
//     org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var48, var56, (java.awt.Paint)var61);
//     var27.setDomainGridlineStroke(var56);
//     var26.setTickMarkStroke(var56);
//     var8.setRangeMinorGridlineStroke(var56);
//     var0.setDomainGridlineStroke(var56);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue((java.lang.Number)5, (java.lang.Comparable)(byte)10, (java.lang.Comparable)"RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected((-264), 255, true, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var3 = var1.get(1);
    int var4 = var1.size();
    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var7 = null;
    var6.setOutlineStroke(var7);
    int var9 = var6.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var10 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var11 = var10.getShadowColor();
    var6.setLinePaint((java.awt.Paint)var11);
    org.jfree.data.category.AbstractCategoryDataset var13 = new org.jfree.data.category.AbstractCategoryDataset();
    var6.setDataset((org.jfree.data.general.Dataset)var13);
    org.jfree.chart.event.DatasetChangeInfo var15 = new org.jfree.chart.event.DatasetChangeInfo();
    org.jfree.data.event.DatasetChangeEvent var16 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var1, (org.jfree.data.general.Dataset)var13, var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var19 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var20 = var19.getDistance();
    int var21 = var19.getDistance();
    var17.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var19);
    var13.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var17);
    org.jfree.chart.util.RectangleEdge var24 = var17.getRangeAxisEdge();
    var17.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.CategoryAnchor var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setDomainGridlinePosition(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var2.setBaseShapesVisible(false);
    var2.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var8 = var2.getSeriesItemLabelPaint((-1));
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.setRangeCrosshairVisible(false);
    boolean var14 = var11.isDomainPannable();
    org.jfree.chart.axis.CategoryAxis var16 = var11.getDomainAxisForDataset(5);
    org.jfree.data.category.DefaultCategoryDataset var17 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var17.getRowCount();
    var17.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var17.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var28 = var2.initialise(var9, var10, var11, (org.jfree.data.category.CategoryDataset)var17, var27);
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
    var30.setRangeCrosshairVisible(false);
    boolean var33 = var30.isRangeMinorGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    var35.setTickMarkInsideLength(1.0f);
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.data.category.DefaultCategoryDataset var39 = new org.jfree.data.category.DefaultCategoryDataset();
    int var40 = var39.getRowCount();
    var39.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var39.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    int var50 = var39.getRowIndex((java.lang.Comparable)(short)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var28, var29, var30, var35, var38, (org.jfree.data.category.CategoryDataset)var39, 10, 1, true, (-264));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.lang.Object var2 = var0.clone();
    java.awt.Stroke var3 = var0.getRangeGridlineStroke();
    var0.setRangeCrosshairLockedOnData(false);
    var0.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     var1.setDefaultLabelVisible((java.lang.Boolean)true);
//     java.awt.Shape var14 = var1.getItemShape(5, (-2));
//     java.awt.Stroke var16 = var1.getSeriesStroke((-127));
//     java.awt.Paint var18 = var1.getSeriesFillPaint((-127));
//     java.awt.Paint var21 = var1.getItemOutlinePaint((-127), 15);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("");
//     var23.setDatasetIndex(0);
//     java.awt.Shape var26 = var23.getShape();
//     org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var26, "");
//     var1.setDefaultShape(var26);
//     
//     // Checks the contract:  equals-hashcode on var4 and var23
//     assertTrue("Contract failed: equals-hashcode on var4 and var23", var4.equals(var23) ? var4.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var4
//     assertTrue("Contract failed: equals-hashcode on var23 and var4", var23.equals(var4) ? var23.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var1 = null;
    boolean var2 = var0.equals(var1);
    java.lang.Object var3 = null;
    boolean var4 = var0.equals(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var8 = var7.getUnitType();
    var0.setTickLabelInsets(var7);
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var16 = var14.trimWidth(0.0d);
    double var18 = var14.calculateTopInset(0.0d);
    double var20 = var14.extendWidth(100.0d);
    java.lang.String var21 = var14.toString();
    var0.setLabelInsets(var14);
    org.jfree.chart.plot.Plot var23 = var0.getPlot();
    org.jfree.data.KeyedObjects var25 = new org.jfree.data.KeyedObjects();
    java.util.List var26 = var25.getKeys();
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
    var28.configureDomainAxes();
    org.jfree.chart.plot.Marker var30 = null;
    org.jfree.chart.util.Layer var31 = null;
    boolean var32 = var28.removeDomainMarker(var30, var31);
    org.jfree.chart.axis.ValueAxis var34 = var28.getRangeAxis(255);
    org.jfree.chart.util.RectangleEdge var36 = var28.getDomainAxisEdge(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var37 = var0.getCategoryMiddle((java.lang.Comparable)0.0f, var26, var27, var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 109.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"+ "'", var21.equals("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
    float var1 = var0.getShadowOpacity();
    float var2 = var0.getShadowOpacity();
    int var3 = var0.calculateOffsetY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    var0.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var8 = var6.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var14 = var13.getUnitType();
    var6.setTickLabelInsets(var13);
    var6.setMinorTickMarkInsideLength(0.5f);
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var19.setBaseShapesVisible(false);
    java.awt.Paint var22 = var19.getBaseItemLabelPaint();
    java.lang.Boolean var24 = var19.getSeriesShapesFilled(1);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var6, var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    java.awt.Paint var27 = var19.lookupSeriesFillPaint(1);
    org.jfree.chart.labels.ItemLabelPosition var28 = var19.getBaseNegativeItemLabelPosition();
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    var29.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var31 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var32 = var31.getDistance();
    int var33 = var31.getDistance();
    var29.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var31);
    boolean var35 = var29.isDomainZoomable();
    boolean var36 = var28.equals((java.lang.Object)var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setBaseShapesVisible(false);
//     var0.setAutoPopulateSeriesStroke(false);
//     java.awt.Paint var6 = var0.getSeriesItemLabelPaint((-1));
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var8 = var7.getFixedRangeAxisSpace();
//     var7.setWeight(10);
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     var7.setDomainAxis(var11);
//     java.awt.Paint var13 = var7.getRangeMinorGridlinePaint();
//     org.jfree.chart.axis.CategoryAxis var15 = var7.getDomainAxis(1);
//     java.awt.Font var16 = var7.getNoDataMessageFont();
//     var0.setBaseItemLabelFont(var16, false);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var22 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var23 = var22.getDistance();
//     int var24 = var22.getDistance();
//     var20.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var22);
//     float var26 = var20.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var28 = null;
//     var20.setDomainAxisLocation(10, var28, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     var20.setRenderer(255, var32, false);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
//     var36.setRangeCrosshairVisible(false);
//     var36.setCrosshairDatasetIndex(255, false);
//     org.jfree.chart.axis.AxisLocation var43 = var36.getRangeAxisLocation((-1));
//     var20.setDomainAxisLocation(100, var43, true);
//     java.awt.geom.Rectangle2D var46 = null;
//     var0.drawOutline(var19, var20, var46);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    java.awt.Stroke var14 = var10.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var30 = var28.trimWidth(0.0d);
    double var32 = var28.trimWidth(109.21460183660255d);
    boolean var34 = var28.equals((java.lang.Object)"hi!");
    var23.setInsets(var28, true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    java.awt.geom.Point2D var41 = null;
    var23.zoomDomainAxes((-9.21460183660255d), var40, var41);
    org.jfree.chart.plot.CategoryMarker var44 = null;
    org.jfree.chart.util.Layer var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.addDomainMarker((-16777215), var44, var45, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     var1.setDefaultLabelVisible((java.lang.Boolean)true);
//     java.awt.Shape var14 = var1.getItemShape(5, (-2));
//     var1.setSeriesCreateEntity((-1), (java.lang.Boolean)true);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var4, var5, var6);
    java.lang.Object var8 = var7.getSource();
    java.lang.String var9 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1)+ "'", var8.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=-1]"+ "'", var9.equals("org.jfree.chart.event.ChartChangeEvent[source=-1]"));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-264), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.setRangeCrosshairVisible(false);
    var5.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var12 = var5.getRangeAxisLocation((-1));
    var0.setDomainAxisLocation(1, var12);
    org.jfree.chart.annotations.CategoryAnnotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var16 = var0.removeAnnotation(var14, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    int var2 = var1.getDatasetIndex();
    var1.setDescription("TextAnchor.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.trimHeight((-9.21460183660255d));
    double var10 = var4.calculateBottomInset(8.21460183660255d);
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var4.createInsetRectangle(var11, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.0d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var9 = var8.toString();
    int var10 = var8.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var8.createContext(var11, var12, var13, var14, var15);
    var0.setShadowPaint((java.awt.Paint)var8);
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var0.setBaseItemLabelGenerator(var18, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-264), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var9.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getColumnCount();
    java.util.List var6 = var0.getRowKeys();
    int var8 = var0.getColumnIndex((java.lang.Comparable)10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)"RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", (java.lang.Comparable)(short)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    var0.setShadowXOffset(109.21460183660255d);
    var0.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.addValue((java.lang.Number)5, (java.lang.Comparable)(byte)10, (java.lang.Comparable)"RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]");
    org.jfree.data.category.DefaultCategoryDataset var5 = new org.jfree.data.category.DefaultCategoryDataset();
    int var6 = var5.getRowCount();
    var5.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var5.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    var0.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var5);
    var0.removeRow((java.lang.Comparable)(byte)10);
    var0.addValue((java.lang.Number)0.0d, (java.lang.Comparable)"SortOrder.ASCENDING", (java.lang.Comparable)'#');
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    java.awt.Paint var3 = var0.getBaseItemLabelPaint();
    java.lang.Boolean var5 = var0.getSeriesShapesFilled(1);
    java.lang.Boolean var7 = null;
    var0.setSeriesShapesVisible(0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    java.awt.Stroke var14 = var10.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var30 = var28.trimWidth(0.0d);
    double var32 = var28.trimWidth(109.21460183660255d);
    boolean var34 = var28.equals((java.lang.Object)"hi!");
    var23.setInsets(var28, true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    var39.setRangeCrosshairVisible(false);
    boolean var42 = var39.isRangeGridlinesVisible();
    java.lang.String var43 = var39.getNoDataMessage();
    org.jfree.chart.entity.PlotEntity var46 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var39, "", "");
    org.jfree.chart.util.RectangleInsets var47 = var39.getInsets();
    org.jfree.chart.plot.CategoryMarker var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var39.addDomainMarker(var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var1 = null;
    int var2 = var0.indexOf(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var4 = var0.getDomainAxis();
    java.util.List var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxes((-16777215), var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var2 = var1.getShadowColor();
    int var3 = var2.getAlpha();
    java.awt.Color var4 = var2.darker();
    int var5 = var4.getGreen();
    java.awt.Color var6 = java.awt.Color.getColor("", var4);
    java.awt.Paint[] var7 = new java.awt.Paint[] { var4};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var12 = var11.getOutlinePaint();
    boolean var13 = var9.equals((java.lang.Object)var12);
    java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    float[] var22 = null;
    float[] var23 = var21.getComponents(var22);
    java.awt.Paint[] var24 = new java.awt.Paint[] { var21};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var31 = null;
    var30.setOutlineStroke(var31);
    int var33 = var30.getSeriesIndex();
    java.awt.Stroke var34 = var30.getOutlineStroke();
    java.awt.Shape var35 = var30.getShape();
    java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
    org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var14, var24, var26, var28, var36);
    java.awt.Paint var38 = var37.getNextOutlinePaint();
    java.awt.Paint var39 = var37.getNextOutlinePaint();
    java.lang.Object var40 = var37.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     java.awt.Paint var4 = var1.getItemPaint(255, 100);
//     java.awt.Color var7 = java.awt.Color.getColor("", 1);
//     var1.setDefaultLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var12 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var13 = var12.getDistance();
//     int var14 = var12.getDistance();
//     var10.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var12);
//     float var16 = var10.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var18 = null;
//     var10.setDomainAxisLocation(10, var18, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     var10.setRenderer(255, var22, false);
//     java.awt.Paint var25 = var10.getDomainCrosshairPaint();
//     var1.setSeriesLabelPaint((-264), var25);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     java.awt.Paint var10 = var1.getDefaultLabelPaint();
//     java.awt.Shape var12 = var1.getSeriesShape(255);
//     java.awt.Stroke var14 = var1.getSeriesStroke((-16777215));
//     java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
//     var1.setSeriesLabelPaint(15, (java.awt.Paint)var19);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     java.awt.Paint var10 = var1.getDefaultLabelPaint();
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
//     var13.setDatasetIndex(0);
//     java.awt.Shape var16 = var13.getShape();
//     org.jfree.chart.entity.ChartEntity var18 = new org.jfree.chart.entity.ChartEntity(var16, "");
//     var1.setSeriesShape(0, var16);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     boolean var7 = var0.isRangePannable();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setRangeCrosshairVisible(false);
//     var8.setCrosshairDatasetIndex(255, false);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation((-1));
//     var0.setRangeAxisLocation(var15);
//     java.awt.Stroke var17 = var0.getRangeMinorGridlineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     var0.handleClick(4, (-264), var20);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var4 = null;
    var0.setDomainAxis(var4);
    java.awt.Paint var6 = var0.getRangeMinorGridlinePaint();
    var0.setOutlineVisible(true);
    org.jfree.chart.plot.Marker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var12 = var0.removeRangeMarker(255, var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Shape var2 = var0.getSeriesShape(100);
//     java.awt.Shape var3 = var0.getDefaultShape();
//     var0.setSeriesLabelVisible((-127), (java.lang.Boolean)false);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    int var3 = var0.getRowCount();
    java.awt.Font var5 = null;
    var0.setLegendTextFont(15, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesFilled((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var1 = var0.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var2 = var0.getItemLabelAnchor();
//     java.lang.String var3 = var2.toString();
//     boolean var5 = var2.equals((java.lang.Object)"org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     org.jfree.chart.labels.ItemLabelPosition var6 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var8 = var6.getItemLabelAnchor();
//     org.jfree.chart.text.TextAnchor var9 = var6.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition(var2, var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var10
//     assertTrue("Contract failed: equals-hashcode on var6 and var10", var6.equals(var10) ? var6.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var6
//     assertTrue("Contract failed: equals-hashcode on var10 and var6", var10.equals(var6) ? var10.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation();
    var0.setRangeCrosshairLockedOnData(true);
    org.jfree.chart.plot.Marker var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var0.removeRangeMarker(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     var1.setTickMarkInsideLength(1.0f);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.ObjectList var8 = new org.jfree.chart.util.ObjectList(10);
//     java.lang.Object var10 = var8.get(1);
//     int var11 = var8.size();
//     org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var14 = null;
//     var13.setOutlineStroke(var14);
//     int var16 = var13.getSeriesIndex();
//     org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var18 = var17.getShadowColor();
//     var13.setLinePaint((java.awt.Paint)var18);
//     org.jfree.data.category.AbstractCategoryDataset var20 = new org.jfree.data.category.AbstractCategoryDataset();
//     var13.setDataset((org.jfree.data.general.Dataset)var20);
//     org.jfree.chart.event.DatasetChangeInfo var22 = new org.jfree.chart.event.DatasetChangeInfo();
//     org.jfree.data.event.DatasetChangeEvent var23 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var8, (org.jfree.data.general.Dataset)var20, var22);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var26 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var27 = var26.getDistance();
//     int var28 = var26.getDistance();
//     var24.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var26);
//     var20.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var24);
//     org.jfree.chart.util.RectangleEdge var31 = var24.getRangeAxisEdge();
//     double var32 = var1.getCategoryStart((-127), 10, var6, var31);
// 
//   }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
//     var1.setShadowVisible(false);
//     var1.setBaseCreateEntities(true, true);
//     org.jfree.chart.LegendItemCollection var9 = var1.getLegendItems();
//     var0.addAll(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.trimHeight((-9.21460183660255d));
    double var10 = var4.calculateTopInset(1.0d);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.LengthAdjustmentType var12 = null;
    org.jfree.chart.util.LengthAdjustmentType var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var4.createAdjustedRectangle(var11, var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.7853981633974483d));

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Font var4 = var1.getLabelFont();
    var1.setLineVisible(false);
    java.awt.Shape var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLine(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getRowKey((-127));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var9 = var8.toString();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("", "", "", "", var4, (java.awt.Paint)var8);
    var10.setSeriesIndex((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var9.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    var0.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var0.getValue(7, 255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    boolean var6 = var0.canSelectByRegion();
    org.jfree.chart.util.DefaultShadowGenerator var8 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var9 = var8.getShadowColor();
    int var10 = var9.getAlpha();
    java.awt.Color var11 = var9.darker();
    int var12 = var11.getGreen();
    java.awt.Color var13 = java.awt.Color.getColor("", var11);
    java.awt.Paint[] var14 = new java.awt.Paint[] { var11};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var19 = var18.getOutlinePaint();
    boolean var20 = var16.equals((java.lang.Object)var19);
    java.awt.Paint[] var21 = new java.awt.Paint[] { var19};
    org.jfree.chart.util.DefaultShadowGenerator var23 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var24 = var23.getShadowColor();
    int var25 = var24.getAlpha();
    java.awt.Color var26 = var24.darker();
    int var27 = var26.getGreen();
    java.awt.Color var28 = java.awt.Color.getColor("", var26);
    float[] var29 = null;
    float[] var30 = var28.getComponents(var29);
    java.awt.Paint[] var31 = new java.awt.Paint[] { var28};
    java.awt.Stroke var32 = null;
    java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
    java.awt.Stroke var34 = null;
    java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var38 = null;
    var37.setOutlineStroke(var38);
    int var40 = var37.getSeriesIndex();
    java.awt.Stroke var41 = var37.getOutlineStroke();
    java.awt.Shape var42 = var37.getShape();
    java.awt.Shape[] var43 = new java.awt.Shape[] { var42};
    org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var21, var31, var33, var35, var43);
    java.awt.Stroke var45 = var44.getNextOutlineStroke();
    java.awt.Paint var46 = var44.getNextPaint();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var44, true);
    org.jfree.chart.util.Layer var49 = null;
    java.util.Collection var50 = var0.getRangeMarkers(var49);
    org.jfree.chart.annotations.CategoryAnnotation var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var51, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     var1.setSeriesCreateEntity((-127), (java.lang.Boolean)true);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setRangeZeroBaselineVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var0.zoomRangeAxes((-108.42920367320511d), var5, var6, false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var12 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var13 = var12.getDistance();
    int var14 = var12.getDistance();
    var10.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var12);
    float var16 = var10.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var18 = null;
    var10.setDomainAxisLocation(10, var18, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    var10.setRenderer(255, var22, false);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.setRangeCrosshairVisible(false);
    var26.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var33 = var26.getRangeAxisLocation((-1));
    var10.setDomainAxisLocation(100, var33, true);
    var0.setDomainAxisLocation(0, var33);
    org.jfree.chart.plot.PlotOrientation var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var38 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var33, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     var0.clearDomainMarkers();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer(0);
//     java.awt.Stroke var10 = var0.getRangeCrosshairStroke();
//     float var11 = var0.getForegroundAlpha();
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     var0.handleClick((-127), 5, var14);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    java.awt.Paint var15 = var0.getDomainCrosshairPaint();
    var0.setWeight((-1));
    java.awt.Paint var18 = var0.getRangeZeroBaselinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     var0.clearDomainMarkers(255);
//     boolean var8 = var0.isRangeMinorGridlinesVisible();
//     var0.zoom(109.21460183660255d);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var7 = var6.getShape();
    org.jfree.chart.JFreeChart var8 = null;
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var8);
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var12 = null;
    var11.setOutlineStroke(var12);
    int var14 = var11.getSeriesIndex();
    java.awt.Stroke var15 = var11.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var18 = var17.getShadowColor();
    int var19 = var18.getAlpha();
    java.awt.Color var20 = var18.darker();
    int var21 = var20.getGreen();
    java.awt.Color var22 = java.awt.Color.getColor("", var20);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var7, var15, (java.awt.Paint)var20);
    var0.setBaseFillPaint((java.awt.Paint)var20, true);
    var0.setDrawOutlines(false);
    org.jfree.chart.labels.ItemLabelPosition var28 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
    var32.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var34 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var35 = var34.getDistance();
    int var36 = var34.getDistance();
    var32.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var34);
    float var38 = var32.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var40 = null;
    var32.setDomainAxisLocation(10, var40, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    var32.setRenderer(255, var44, false);
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var53 = var52.getShape();
    org.jfree.chart.JFreeChart var54 = null;
    org.jfree.chart.event.ChartChangeEvent var55 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var53, var54);
    org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var58 = null;
    var57.setOutlineStroke(var58);
    int var60 = var57.getSeriesIndex();
    java.awt.Stroke var61 = var57.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var63 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var64 = var63.getShadowColor();
    int var65 = var64.getAlpha();
    java.awt.Color var66 = var64.darker();
    int var67 = var66.getGreen();
    java.awt.Color var68 = java.awt.Color.getColor("", var66);
    org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var53, var61, (java.awt.Paint)var66);
    var32.setDomainGridlineStroke(var61);
    var31.setTickMarkStroke(var61);
    int var72 = var31.getMaximumCategoryLabelLines();
    java.awt.Color var77 = java.awt.Color.getColor("", 1);
    java.awt.Color var78 = java.awt.Color.getColor("hi!", var77);
    org.jfree.chart.util.DefaultShadowGenerator var82 = new org.jfree.chart.util.DefaultShadowGenerator(15, var78, 10.0f, 255, (-9.21460183660255d));
    var31.setAxisLinePaint((java.awt.Paint)var78);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlinePaint((-16777215), (java.awt.Paint)var78);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    var0.clearDomainMarkers(255);
    boolean var8 = var0.isRangeMinorGridlinesVisible();
    java.util.List var9 = var0.getCategories();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    var1.setLinePaint((java.awt.Paint)var6);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var14 = var13.getShape();
    org.jfree.chart.JFreeChart var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var14, var15);
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var19 = null;
    var18.setOutlineStroke(var19);
    int var21 = var18.getSeriesIndex();
    java.awt.Stroke var22 = var18.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var24 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var25 = var24.getShadowColor();
    int var26 = var25.getAlpha();
    java.awt.Color var27 = var25.darker();
    int var28 = var27.getGreen();
    java.awt.Color var29 = java.awt.Color.getColor("", var27);
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var14, var22, (java.awt.Paint)var27);
    var1.setOutlinePaint((java.awt.Paint)var27);
    float[] var33 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var34 = var27.getRGBColorComponents(var33);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isDomainPannable();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var11 = var9.trimWidth(0.0d);
    double var13 = var9.trimWidth(109.21460183660255d);
    boolean var15 = var9.equals((java.lang.Object)"hi!");
    var4.setInsets(var9, true);
    var4.clearRangeAxes();
    var0.setParent((org.jfree.chart.plot.Plot)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryAxis var21 = var0.getDomainAxisForDataset((-2));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Shape var4 = var1.getShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var4, "");
    java.lang.Object var7 = var6.clone();
    java.lang.String var8 = var6.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "rect"+ "'", var8.equals("rect"));

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    java.awt.Paint var3 = var0.getBaseItemLabelPaint();
    java.lang.Boolean var5 = var0.getSeriesShapesFilled(1);
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.setRangeCrosshairVisible(false);
    var10.setCrosshairDatasetIndex(255, false);
    boolean var16 = var10.canSelectByRegion();
    org.jfree.chart.LegendItemCollection var17 = var10.getLegendItems();
    var10.setAnchorValue(8.21460183660255d, true);
    java.awt.Paint var21 = var10.getDomainGridlinePaint();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var24 = var22.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var30 = var29.getUnitType();
    var22.setTickLabelInsets(var29);
    var22.setCategoryLabelPositionOffset((-264));
    var22.setMinorTickMarkOutsideLength(0.5f);
    double var36 = var22.getLabelAngle();
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.data.category.DefaultCategoryDataset var38 = new org.jfree.data.category.DefaultCategoryDataset();
    int var39 = var38.getRowCount();
    var38.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var46 = var44.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var51 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var52 = var51.getUnitType();
    var44.setTickLabelInsets(var51);
    var44.setMinorTickMarkInsideLength(0.5f);
    org.jfree.chart.axis.ValueAxis var56 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var57.setBaseShapesVisible(false);
    java.awt.Paint var60 = var57.getBaseItemLabelPaint();
    java.lang.Boolean var62 = var57.getSeriesShapesFilled(1);
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var38, var44, var56, (org.jfree.chart.renderer.category.CategoryItemRenderer)var57);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var67.setBaseShapesVisible(false);
    var67.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var73 = var67.getSeriesItemLabelPaint((-1));
    java.awt.Graphics2D var74 = null;
    java.awt.geom.Rectangle2D var75 = null;
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
    var76.setRangeCrosshairVisible(false);
    boolean var79 = var76.isDomainPannable();
    org.jfree.chart.axis.CategoryAxis var81 = var76.getDomainAxisForDataset(5);
    org.jfree.data.category.DefaultCategoryDataset var82 = new org.jfree.data.category.DefaultCategoryDataset();
    int var83 = var82.getRowCount();
    var82.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var82.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.PlotRenderingInfo var92 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var93 = var67.initialise(var74, var75, var76, (org.jfree.data.category.CategoryDataset)var82, var92);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var94 = var0.hitTest(100.0d, 1.0d, var8, var9, var10, var22, var37, (org.jfree.data.category.CategoryDataset)var38, (-264), (-2), true, var93);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     boolean var3 = var0.isDomainPannable();
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var6 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var7 = var6.getDistance();
//     int var8 = var6.getDistance();
//     var4.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var6);
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.CategoryAxis[] var11 = new org.jfree.chart.axis.CategoryAxis[] { var10};
//     var4.setDomainAxes(var11);
//     var0.setDomainAxes(var11);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Shape var2 = var0.getSeriesShape(100);
    java.awt.Shape var3 = var0.getDefaultShape();
    java.lang.Boolean var4 = var0.getDefaultLabelVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    int var3 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setItemMargin(2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue((java.lang.Number)(-1.0f));

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject((java.lang.Comparable)(-16777215), var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    var0.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var8 = var6.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var14 = var13.getUnitType();
    var6.setTickLabelInsets(var13);
    var6.setMinorTickMarkInsideLength(0.5f);
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var19.setBaseShapesVisible(false);
    java.awt.Paint var22 = var19.getBaseItemLabelPaint();
    java.lang.Boolean var24 = var19.getSeriesShapesFilled(1);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var6, var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    java.awt.Paint var27 = var19.lookupSeriesFillPaint(1);
    org.jfree.chart.labels.ItemLabelPosition var28 = var19.getBaseNegativeItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setSeriesVisible((-127), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var1 = var0.getAutoPopulateSeriesFillPaint();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.ObjectList var5 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var7 = var5.get(1);
    int var8 = var5.size();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var14 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var15 = var14.getShadowColor();
    var10.setLinePaint((java.awt.Paint)var15);
    org.jfree.data.category.AbstractCategoryDataset var17 = new org.jfree.data.category.AbstractCategoryDataset();
    var10.setDataset((org.jfree.data.general.Dataset)var17);
    org.jfree.chart.event.DatasetChangeInfo var19 = new org.jfree.chart.event.DatasetChangeInfo();
    org.jfree.data.event.DatasetChangeEvent var20 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var5, (org.jfree.data.general.Dataset)var17, var19);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var23 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var24 = var23.getDistance();
    int var25 = var23.getDistance();
    var21.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var23);
    var17.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var21);
    org.jfree.chart.util.RectangleEdge var28 = var21.getRangeAxisEdge();
    var21.setDomainCrosshairVisible(false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var31.setBaseShapesVisible(false);
    var31.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var37 = var31.getSeriesItemLabelPaint((-1));
    java.awt.Graphics2D var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    var40.setRangeCrosshairVisible(false);
    boolean var43 = var40.isDomainPannable();
    org.jfree.chart.axis.CategoryAxis var45 = var40.getDomainAxisForDataset(5);
    org.jfree.data.category.DefaultCategoryDataset var46 = new org.jfree.data.category.DefaultCategoryDataset();
    int var47 = var46.getRowCount();
    var46.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var46.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.PlotRenderingInfo var56 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var57 = var31.initialise(var38, var39, var40, (org.jfree.data.category.CategoryDataset)var46, var56);
    org.jfree.chart.plot.PlotRenderingInfo var58 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var59 = var0.initialise(var2, var3, var21, (org.jfree.data.category.CategoryDataset)var46, var58);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.lang.Boolean var7 = null;
    var0.setSeriesVisibleInLegend(0, var7);
    org.jfree.chart.labels.ItemLabelPosition var9 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-264), var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    int var3 = var0.getIndex((java.lang.Comparable)"PlotEntity: tooltip = ");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var8 = var7.getUnitType();
    var0.setTickLabelInsets(var7);
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var16 = var14.trimWidth(0.0d);
    double var18 = var14.calculateTopInset(0.0d);
    double var20 = var14.extendWidth(100.0d);
    java.lang.String var21 = var14.toString();
    var0.setLabelInsets(var14);
    org.jfree.chart.plot.Plot var23 = var0.getPlot();
    var0.setVisible(true);
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.ObjectList var30 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var32 = var30.get(1);
    int var33 = var30.size();
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var36 = null;
    var35.setOutlineStroke(var36);
    int var38 = var35.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var39 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var40 = var39.getShadowColor();
    var35.setLinePaint((java.awt.Paint)var40);
    org.jfree.data.category.AbstractCategoryDataset var42 = new org.jfree.data.category.AbstractCategoryDataset();
    var35.setDataset((org.jfree.data.general.Dataset)var42);
    org.jfree.chart.event.DatasetChangeInfo var44 = new org.jfree.chart.event.DatasetChangeInfo();
    org.jfree.data.event.DatasetChangeEvent var45 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var30, (org.jfree.data.general.Dataset)var42, var44);
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    var46.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var48 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var49 = var48.getDistance();
    int var50 = var48.getDistance();
    var46.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var48);
    var42.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var46);
    org.jfree.chart.util.RectangleEdge var53 = var46.getRangeAxisEdge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var54 = var0.getCategoryMiddle((-1), (-2), var28, var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 109.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"+ "'", var21.equals("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedRangeAxisSpace();
    var0.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var4 = null;
    var0.setDomainAxis(var4);
    java.awt.Paint var6 = var0.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.CategoryAxis var8 = var0.getDomainAxis(1);
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = var0.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.trimHeight((-9.21460183660255d));
    double var10 = var4.calculateTopInset(1.0d);
    double var12 = var4.calculateTopOutset(0.0d);
    java.awt.geom.Rectangle2D var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var16 = var4.createOutsetRectangle(var13, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-0.7853981633974483d));

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setItemMargin(0.0d);
    var0.setBaseShapesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var11 = null;
    var7.setLegendTextFont(5, var11);
    java.awt.Font var13 = null;
    var7.setBaseLegendTextFont(var13);
    var7.clearSeriesStrokes(false);
    java.awt.Paint var17 = var7.getBaseItemLabelPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var18 = null;
    var7.setBaseToolTipGenerator(var18, false);
    java.awt.Stroke var21 = var7.getBaseOutlineStroke();
    java.awt.Font var25 = var7.getItemLabelFont(0, (-264), false);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.setRangeCrosshairVisible(false);
    var26.setCrosshairDatasetIndex(255, false);
    boolean var32 = var26.canSelectByRegion();
    var26.clearDomainMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var26.getRenderer(0);
    java.awt.Stroke var36 = var26.getRangeCrosshairStroke();
    java.awt.Paint var37 = var26.getBackgroundPaint();
    boolean var38 = var7.equals((java.lang.Object)var37);
    var0.setLegendTextPaint(1, var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-127), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    java.awt.Paint var15 = var0.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var20 = null;
    var16.setLegendTextFont(5, var20);
    java.awt.Font var22 = null;
    var16.setBaseLegendTextFont(var22);
    var16.clearSeriesStrokes(false);
    int var26 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    java.lang.Boolean var28 = var16.getSeriesVisible(0);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    var29.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var31 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var32 = var31.getDistance();
    int var33 = var31.getDistance();
    var29.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var31);
    float var35 = var29.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var37 = null;
    var29.setDomainAxisLocation(10, var37, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    var29.setRenderer(255, var41, false);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var50 = var49.getShape();
    org.jfree.chart.JFreeChart var51 = null;
    org.jfree.chart.event.ChartChangeEvent var52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var50, var51);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var55 = null;
    var54.setOutlineStroke(var55);
    int var57 = var54.getSeriesIndex();
    java.awt.Stroke var58 = var54.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var60 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var61 = var60.getShadowColor();
    int var62 = var61.getAlpha();
    java.awt.Color var63 = var61.darker();
    int var64 = var63.getGreen();
    java.awt.Color var65 = java.awt.Color.getColor("", var63);
    org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var50, var58, (java.awt.Paint)var63);
    var29.setDomainGridlineStroke(var58);
    var16.setBaseStroke(var58, false);
    var16.setSeriesItemLabelsVisible(1, (java.lang.Boolean)true);
    java.awt.Stroke var74 = var16.lookupSeriesOutlineStroke(0);
    java.awt.Paint var75 = var16.getBaseItemLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    java.awt.Stroke var14 = var10.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var30 = var28.trimWidth(0.0d);
    double var32 = var28.trimWidth(109.21460183660255d);
    boolean var34 = var28.equals((java.lang.Object)"hi!");
    var23.setInsets(var28, true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    var39.setRangeCrosshairVisible(false);
    boolean var42 = var39.isRangeGridlinesVisible();
    java.lang.String var43 = var39.getNoDataMessage();
    org.jfree.chart.entity.PlotEntity var46 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var39, "", "");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var49 = var48.getUseOutlinePaint();
    var48.setItemMargin(0.0d);
    var48.setBaseShapesVisible(true);
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var57 = var55.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var59 = null;
    var55.setLegendTextFont(5, var59);
    java.awt.Font var61 = null;
    var55.setBaseLegendTextFont(var61);
    var55.clearSeriesStrokes(false);
    java.awt.Paint var65 = var55.getBaseItemLabelPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var66 = null;
    var55.setBaseToolTipGenerator(var66, false);
    java.awt.Stroke var69 = var55.getBaseOutlineStroke();
    java.awt.Font var73 = var55.getItemLabelFont(0, (-264), false);
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot();
    var74.setRangeCrosshairVisible(false);
    var74.setCrosshairDatasetIndex(255, false);
    boolean var80 = var74.canSelectByRegion();
    var74.clearDomainMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var83 = var74.getRenderer(0);
    java.awt.Stroke var84 = var74.getRangeCrosshairStroke();
    java.awt.Paint var85 = var74.getBackgroundPaint();
    boolean var86 = var55.equals((java.lang.Object)var85);
    var48.setLegendTextPaint(1, var85);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var39.setRenderer((-2), (org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var3 = var2.getFixedRangeAxisSpace();
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var10 = var9.getShape();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var11);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var15 = null;
    var14.setOutlineStroke(var15);
    int var17 = var14.getSeriesIndex();
    java.awt.Stroke var18 = var14.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var20 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var21 = var20.getShadowColor();
    int var22 = var21.getAlpha();
    java.awt.Color var23 = var21.darker();
    int var24 = var23.getGreen();
    java.awt.Color var25 = java.awt.Color.getColor("", var23);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var10, var18, (java.awt.Paint)var23);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var32 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var34 = var32.trimWidth(0.0d);
    double var36 = var32.trimWidth(109.21460183660255d);
    boolean var38 = var32.equals((java.lang.Object)"hi!");
    var27.setInsets(var32, true);
    org.jfree.chart.entity.PlotEntity var42 = new org.jfree.chart.entity.PlotEntity(var10, (org.jfree.chart.plot.Plot)var27, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.util.SortOrder var43 = var27.getColumnRenderingOrder();
    var2.setRowRenderingOrder(var43);
    var0.sortByKeys(var43);
    org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var48 = var46.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var50 = null;
    var46.setLegendTextFont(5, var50);
    java.awt.Font var52 = null;
    var46.setBaseLegendTextFont(var52);
    var46.clearSeriesStrokes(false);
    org.jfree.chart.renderer.RenderAttributes var57 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var59 = var58.getFixedRangeAxisSpace();
    var58.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var62 = null;
    var58.setDomainAxis(var62);
    java.awt.Paint var64 = var58.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.CategoryAxis var66 = var58.getDomainAxis(1);
    java.awt.Font var67 = var58.getNoDataMessageFont();
    var57.setDefaultLabelFont(var67);
    var46.setBaseLegendTextFont(var67);
    boolean var70 = var43.equals((java.lang.Object)var46);
    org.jfree.chart.event.RendererChangeEvent var71 = null;
    var46.notifyListeners(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
    var1.setDefaultFillPaint((java.awt.Paint)var13);
    java.awt.Paint var15 = var1.getDefaultPaint();
    java.awt.Paint var17 = var1.getSeriesFillPaint(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setItemMargin(0.0d);
    var0.setUseOutlinePaint(true);
    java.lang.Boolean var7 = null;
    var0.setSeriesVisible(0, var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var6 = var4.trimWidth(0.0d);
    double var8 = var4.trimHeight((-9.21460183660255d));
    double var10 = var4.calculateBottomInset(8.21460183660255d);
    double var11 = var4.getTop();
    java.awt.geom.Rectangle2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var15 = var4.createOutsetRectangle(var12, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.7853981633974483d));

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     boolean var7 = var0.isRangePannable();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setRangeCrosshairVisible(false);
//     var8.setCrosshairDatasetIndex(255, false);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation((-1));
//     var0.setRangeAxisLocation(var15);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var0.drawOutline(var17, var18);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     java.awt.GradientPaint var1 = null;
//     org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var4 = null;
//     var3.setOutlineStroke(var4);
//     var3.setURLText("");
//     var3.setToolTipText("hi!");
//     org.jfree.chart.util.GradientPaintTransformer var10 = var3.getFillPaintTransformer();
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var13 = var12.getShape();
//     org.jfree.chart.JFreeChart var14 = null;
//     org.jfree.chart.event.ChartChangeEvent var15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var13, var14);
//     var3.setLine(var13);
//     java.awt.GradientPaint var17 = var0.transform(var1, var13);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Paint var17 = var1.getSeriesPaint(255);
//     java.awt.Font var19 = null;
//     var1.setSeriesLabelFont(0, var19);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    int var14 = var0.getDomainAxisCount();
    int var15 = var0.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var16 = var0.getAxisOffset();
    double var18 = var16.extendHeight(100.0d);
    double var20 = var16.extendHeight((-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 108.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-100.42920367320511d));

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    org.jfree.data.category.CategoryDatasetSelectionState var3 = var0.getSelectionState();
    org.jfree.data.category.CategoryDatasetSelectionState var4 = null;
    var0.setSelectionState(var4);
    org.jfree.data.category.AbstractCategoryDataset var6 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.data.general.DatasetGroup var7 = var6.getGroup();
    var0.setGroup(var7);
    java.lang.Object var9 = null;
    boolean var10 = var7.equals(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    boolean var6 = var0.canSelectByRegion();
    boolean var7 = var0.isRangePannable();
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.plot.CategoryCrosshairState var12 = null;
    boolean var13 = var0.render(var8, var9, 10, var11, var12);
    java.lang.Comparable var14 = var0.getDomainCrosshairRowKey();
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
    var18.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var20 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var21 = var20.getDistance();
    int var22 = var20.getDistance();
    var18.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var20);
    float var24 = var18.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var26 = null;
    var18.setDomainAxisLocation(10, var26, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    var18.setRenderer(255, var30, false);
    org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var39 = var38.getShape();
    org.jfree.chart.JFreeChart var40 = null;
    org.jfree.chart.event.ChartChangeEvent var41 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var39, var40);
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var44 = null;
    var43.setOutlineStroke(var44);
    int var46 = var43.getSeriesIndex();
    java.awt.Stroke var47 = var43.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var49 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var50 = var49.getShadowColor();
    int var51 = var50.getAlpha();
    java.awt.Color var52 = var50.darker();
    int var53 = var52.getGreen();
    java.awt.Color var54 = java.awt.Color.getColor("", var52);
    org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var39, var47, (java.awt.Paint)var52);
    var18.setDomainGridlineStroke(var47);
    var17.setTickMarkStroke(var47);
    int var58 = var17.getMaximumCategoryLabelLines();
    var17.setUpperMargin(100.0d);
    boolean var61 = var17.isTickMarksVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxis((-127), var17, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setBaseItemLabelGenerator(var5);
    var0.setItemMargin((-108.42920367320511d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var10 = var9.getShape();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var10, var11);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var15 = null;
    var14.setOutlineStroke(var15);
    int var17 = var14.getSeriesIndex();
    java.awt.Stroke var18 = var14.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var20 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var21 = var20.getShadowColor();
    int var22 = var21.getAlpha();
    java.awt.Color var23 = var21.darker();
    int var24 = var23.getGreen();
    java.awt.Color var25 = java.awt.Color.getColor("", var23);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var10, var18, (java.awt.Paint)var23);
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.setRangeCrosshairVisible(false);
    var27.setCrosshairDatasetIndex(255, false);
    boolean var33 = var27.canSelectByRegion();
    var27.clearDomainMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = var27.getRenderer(0);
    java.awt.Stroke var37 = var27.getRangeCrosshairStroke();
    java.awt.Paint var38 = var27.getBackgroundPaint();
    java.awt.Paint var39 = var27.getRangeZeroBaselinePaint();
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    var40.setRangeCrosshairVisible(false);
    boolean var43 = var40.isRangeGridlinesVisible();
    java.awt.Stroke var44 = var40.getDomainGridlineStroke();
    java.awt.Paint var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = ", "SortOrder.ASCENDING", "rect", "Category Plot", var10, var39, var44, var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    var0.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected((-127), 5, true, true);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-16777215), var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     org.jfree.chart.plot.DrawingSupplier var15 = var0.getDrawingSupplier();
//     float var16 = var0.getBackgroundImageAlpha();
//     java.awt.Paint var17 = var0.getRangeGridlinePaint();
//     boolean var18 = var0.isOutlineVisible();
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawBackground(var19, var20);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var9 = var8.toString();
    int var10 = var8.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var8.createContext(var11, var12, var13, var14, var15);
    var0.setShadowPaint((java.awt.Paint)var8);
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var0.setBaseItemLabelGenerator(var18, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var0.getSeriesItemLabelGenerator(4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var9.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.setRangeCrosshairVisible(false);
    var16.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var23 = var16.getRangeAxisLocation((-1));
    var0.setDomainAxisLocation(100, var23, true);
    var0.configureDomainAxes();
    org.jfree.chart.annotations.CategoryAnnotation var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var27, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    var0.setAutoPopulateSeriesStroke(true);
    var0.setBaseCreateEntities(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    var0.setBaseLinesVisible(false);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     java.awt.Shape var17 = var1.getSeriesShape(100);
//     var1.setSeriesLabelVisible(100, (java.lang.Boolean)true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var5 = var4.getUnitType();
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets(var5, 109.21460183660255d, 2.0d, (-0.7853981633974483d), (-108.42920367320511d));
    java.awt.geom.Rectangle2D var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var10.createOutsetRectangle(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var6 = var5.getShape();
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
//     org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var11 = null;
//     var10.setOutlineStroke(var11);
//     int var13 = var10.getSeriesIndex();
//     java.awt.Stroke var14 = var10.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var30 = var28.trimWidth(0.0d);
//     double var32 = var28.trimWidth(109.21460183660255d);
//     boolean var34 = var28.equals((java.lang.Object)"hi!");
//     var23.setInsets(var28, true);
//     org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var40 = var39.getFixedRangeAxisSpace();
//     var39.setWeight(10);
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     var39.setDomainAxis(var43);
//     boolean var45 = var38.equals((java.lang.Object)var39);
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var46 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var47 = null;
//     java.lang.String var48 = var38.getImageMapAreaTag(var46, var47);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.event.AnnotationChangeEvent var1 = null;
    var0.annotationChanged(var1);
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeCrosshairPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    java.awt.Paint var15 = var0.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var20 = null;
    var16.setLegendTextFont(5, var20);
    java.awt.Font var22 = null;
    var16.setBaseLegendTextFont(var22);
    var16.clearSeriesStrokes(false);
    int var26 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    java.lang.Boolean var28 = var16.getSeriesVisible(0);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
    var29.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var31 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var32 = var31.getDistance();
    int var33 = var31.getDistance();
    var29.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var31);
    float var35 = var29.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var37 = null;
    var29.setDomainAxisLocation(10, var37, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
    var29.setRenderer(255, var41, false);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var50 = var49.getShape();
    org.jfree.chart.JFreeChart var51 = null;
    org.jfree.chart.event.ChartChangeEvent var52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var50, var51);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var55 = null;
    var54.setOutlineStroke(var55);
    int var57 = var54.getSeriesIndex();
    java.awt.Stroke var58 = var54.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var60 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var61 = var60.getShadowColor();
    int var62 = var61.getAlpha();
    java.awt.Color var63 = var61.darker();
    int var64 = var63.getGreen();
    java.awt.Color var65 = java.awt.Color.getColor("", var63);
    org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var50, var58, (java.awt.Paint)var63);
    var29.setDomainGridlineStroke(var58);
    var16.setBaseStroke(var58, false);
    var16.setSeriesItemLabelsVisible(1, (java.lang.Boolean)true);
    boolean var73 = var16.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    java.awt.Stroke var14 = var10.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var30 = var28.trimWidth(0.0d);
    double var32 = var28.trimWidth(109.21460183660255d);
    boolean var34 = var28.equals((java.lang.Object)"hi!");
    var23.setInsets(var28, true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var40 = var39.getFixedRangeAxisSpace();
    var39.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var43 = null;
    var39.setDomainAxis(var43);
    boolean var45 = var38.equals((java.lang.Object)var39);
    java.lang.String var46 = var38.toString();
    var38.setToolTipText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=-1]"+ "'", var46.equals("PlotEntity: tooltip = org.jfree.chart.event.ChartChangeEvent[source=-1]"));

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("UnitType.ABSOLUTE", var1);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    boolean var5 = var1.isShapeVisible();
    var1.setURLText("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var4 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var5 = var4.getDistance();
    int var6 = var4.getDistance();
    var2.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var4);
    float var8 = var2.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var10 = null;
    var2.setDomainAxisLocation(10, var10, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var2.setRenderer(255, var14, false);
    java.awt.Paint var17 = var2.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var22 = null;
    var18.setLegendTextFont(5, var22);
    java.awt.Font var24 = null;
    var18.setBaseLegendTextFont(var24);
    var18.clearSeriesStrokes(false);
    int var28 = var2.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    java.lang.Boolean var30 = var18.getSeriesVisible(0);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var33 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var34 = var33.getDistance();
    int var35 = var33.getDistance();
    var31.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var33);
    float var37 = var31.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var39 = null;
    var31.setDomainAxisLocation(10, var39, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    var31.setRenderer(255, var43, false);
    org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var52 = var51.getShape();
    org.jfree.chart.JFreeChart var53 = null;
    org.jfree.chart.event.ChartChangeEvent var54 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var52, var53);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var57 = null;
    var56.setOutlineStroke(var57);
    int var59 = var56.getSeriesIndex();
    java.awt.Stroke var60 = var56.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var62 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var63 = var62.getShadowColor();
    int var64 = var63.getAlpha();
    java.awt.Color var65 = var63.darker();
    int var66 = var65.getGreen();
    java.awt.Color var67 = java.awt.Color.getColor("", var65);
    org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var52, var60, (java.awt.Paint)var65);
    var31.setDomainGridlineStroke(var60);
    var18.setBaseStroke(var60, false);
    var18.setSeriesItemLabelsVisible(1, (java.lang.Boolean)true);
    java.awt.Stroke var76 = var18.lookupSeriesOutlineStroke(0);
    boolean var77 = var1.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 1);
    int var3 = var2.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777215));

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isDomainPannable();
    var0.setWeight((-1));
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var0.removeRangeMarker(0, var7, var8, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    var0.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var6 = var0.getSeriesItemLabelPaint((-1));
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.setRangeCrosshairVisible(false);
    boolean var12 = var9.isDomainPannable();
    org.jfree.chart.axis.CategoryAxis var14 = var9.getDomainAxisForDataset(5);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    int var16 = var15.getRowCount();
    var15.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var15.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var26 = var0.initialise(var7, var8, var9, (org.jfree.data.category.CategoryDataset)var15, var25);
    var0.setSeriesShapesFilled(10, true);
    boolean var30 = var0.getAutoPopulateSeriesPaint();
    org.jfree.chart.util.DefaultShadowGenerator var33 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var34 = var33.getShadowColor();
    int var35 = var34.getAlpha();
    java.awt.Color var36 = var34.darker();
    int var37 = var36.getGreen();
    java.awt.Color var38 = java.awt.Color.getColor("", var36);
    java.awt.Paint[] var39 = new java.awt.Paint[] { var36};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var41 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var44 = var43.getOutlinePaint();
    boolean var45 = var41.equals((java.lang.Object)var44);
    java.awt.Paint[] var46 = new java.awt.Paint[] { var44};
    org.jfree.chart.util.DefaultShadowGenerator var48 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var49 = var48.getShadowColor();
    int var50 = var49.getAlpha();
    java.awt.Color var51 = var49.darker();
    int var52 = var51.getGreen();
    java.awt.Color var53 = java.awt.Color.getColor("", var51);
    float[] var54 = null;
    float[] var55 = var53.getComponents(var54);
    java.awt.Paint[] var56 = new java.awt.Paint[] { var53};
    java.awt.Stroke var57 = null;
    java.awt.Stroke[] var58 = new java.awt.Stroke[] { var57};
    java.awt.Stroke var59 = null;
    java.awt.Stroke[] var60 = new java.awt.Stroke[] { var59};
    org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var63 = null;
    var62.setOutlineStroke(var63);
    int var65 = var62.getSeriesIndex();
    java.awt.Stroke var66 = var62.getOutlineStroke();
    java.awt.Shape var67 = var62.getShape();
    java.awt.Shape[] var68 = new java.awt.Shape[] { var67};
    org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier(var39, var46, var56, var58, var60, var68);
    java.awt.Paint var70 = var69.getNextOutlinePaint();
    java.awt.Paint var71 = var69.getNextOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-16777216), var71, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var4 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var5 = var4.getDistance();
//     int var6 = var4.getDistance();
//     var2.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var4);
//     float var8 = var2.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var10 = null;
//     var2.setDomainAxisLocation(10, var10, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var2.setRenderer(255, var14, false);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var23 = var22.getShape();
//     org.jfree.chart.JFreeChart var24 = null;
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var23, var24);
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var28 = null;
//     var27.setOutlineStroke(var28);
//     int var30 = var27.getSeriesIndex();
//     java.awt.Stroke var31 = var27.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var33 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var34 = var33.getShadowColor();
//     int var35 = var34.getAlpha();
//     java.awt.Color var36 = var34.darker();
//     int var37 = var36.getGreen();
//     java.awt.Color var38 = java.awt.Color.getColor("", var36);
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var23, var31, (java.awt.Paint)var36);
//     var2.setDomainGridlineStroke(var31);
//     var1.setTickMarkStroke(var31);
//     int var42 = var1.getMaximumCategoryLabelLines();
//     var1.setUpperMargin(100.0d);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.configureDomainAxes();
//     java.lang.Object var47 = var45.clone();
//     java.awt.Paint var48 = var45.getDomainCrosshairPaint();
//     var1.setTickLabelPaint(var48);
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot();
//     var53.configureDomainAxes();
//     org.jfree.chart.plot.Marker var55 = null;
//     org.jfree.chart.util.Layer var56 = null;
//     boolean var57 = var53.removeDomainMarker(var55, var56);
//     org.jfree.chart.axis.ValueAxis var59 = var53.getRangeAxis(255);
//     org.jfree.chart.util.RectangleEdge var61 = var53.getDomainAxisEdge(100);
//     double var62 = var1.getCategoryEnd(1, 0, var52, var61);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    java.awt.Stroke var9 = var0.getSeriesOutlineStroke((-2));
    org.jfree.chart.urls.CategoryURLGenerator var11 = var0.getSeriesURLGenerator((-127));
    org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var23 = var21.trimWidth(0.0d);
    double var25 = var21.trimWidth(109.21460183660255d);
    boolean var27 = var21.equals((java.lang.Object)"hi!");
    var16.setInsets(var21, true);
    int var30 = var16.getDomainAxisCount();
    int var31 = var16.getBackgroundImageAlignment();
    org.jfree.data.category.DefaultCategoryDataset var32 = new org.jfree.data.category.DefaultCategoryDataset();
    int var33 = var32.getRowCount();
    var32.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var39 = var0.initialise(var14, var15, var16, (org.jfree.data.category.CategoryDataset)var32, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var3 = var2.getOutlinePaint();
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("hi!", var3);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var7 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var8 = var7.getDistance();
//     int var9 = var7.getDistance();
//     var5.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var7);
//     float var11 = var5.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var13 = null;
//     var5.setDomainAxisLocation(10, var13, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     var5.setRenderer(255, var17, false);
//     java.awt.Paint var20 = var5.getDomainCrosshairPaint();
//     boolean var21 = var4.equals((java.lang.Object)var5);
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     var5.setDomainAxis(var22);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.configureDomainAxes();
//     org.jfree.chart.plot.Marker var30 = null;
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var32 = var28.removeDomainMarker(var30, var31);
//     org.jfree.chart.axis.ValueAxis var34 = var28.getRangeAxis(255);
//     org.jfree.chart.util.RectangleEdge var36 = var28.getDomainAxisEdge(100);
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     org.jfree.chart.axis.AxisState var38 = var22.draw(var24, 4.0d, var26, var27, var36, var37);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.category.AbstractCategoryDataset var0 = new org.jfree.data.category.AbstractCategoryDataset();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    org.jfree.data.category.CategoryDatasetSelectionState var3 = var0.getSelectionState();
    org.jfree.data.category.CategoryDatasetSelectionState var4 = null;
    var0.setSelectionState(var4);
    org.jfree.data.category.AbstractCategoryDataset var6 = new org.jfree.data.category.AbstractCategoryDataset();
    org.jfree.data.general.DatasetGroup var7 = var6.getGroup();
    var0.setGroup(var7);
    org.jfree.chart.renderer.RenderAttributes var10 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    var13.setDatasetIndex(0);
    java.awt.Paint var16 = var13.getFillPaint();
    org.jfree.data.KeyedObject var17 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var16);
    var10.setDefaultLabelPaint(var16);
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(10, 1, 0);
    var10.setDefaultFillPaint((java.awt.Paint)var22);
    java.awt.Paint var24 = var10.getDefaultPaint();
    java.awt.Shape var26 = var10.getSeriesShape(100);
    java.awt.Paint var29 = var10.getItemPaint((-16777216), (-127));
    java.awt.Stroke var30 = var10.getDefaultStroke();
    java.awt.Font var31 = var10.getDefaultLabelFont();
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    var33.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var35 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var36 = var35.getDistance();
    int var37 = var35.getDistance();
    var33.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var35);
    float var39 = var33.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var41 = null;
    var33.setDomainAxisLocation(10, var41, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    var33.setRenderer(255, var45, false);
    org.jfree.chart.plot.DrawingSupplier var48 = var33.getDrawingSupplier();
    float var49 = var33.getBackgroundImageAlpha();
    java.awt.Paint var50 = var33.getRangeGridlinePaint();
    var10.setSeriesPaint(5, var50);
    boolean var52 = var7.equals((java.lang.Object)var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Stroke var16 = var1.getSeriesStroke((-1));
//     java.awt.Paint var19 = var1.getItemOutlinePaint(15, 0);
//     org.jfree.chart.ChartColor var24 = new org.jfree.chart.ChartColor(5, 7, 255);
//     var1.setSeriesLabelPaint(5, (java.awt.Paint)var24);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Stroke var3 = var0.getRangeGridlineStroke();
//     var0.setRangeCrosshairLockedOnData(false);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     org.jfree.chart.plot.PlotState var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var0.draw(var6, var7, var8, var9, var10);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    var1.setURLText("");
    java.lang.Comparable var6 = var1.getSeriesKey();
    java.awt.Stroke var7 = var1.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    java.awt.Stroke var14 = var10.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var30 = var28.trimWidth(0.0d);
    double var32 = var28.trimWidth(109.21460183660255d);
    boolean var34 = var28.equals((java.lang.Object)"hi!");
    var23.setInsets(var28, true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var40 = var39.getFixedRangeAxisSpace();
    var39.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var43 = null;
    var39.setDomainAxis(var43);
    boolean var45 = var38.equals((java.lang.Object)var39);
    org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var48 = null;
    var47.setOutlineStroke(var48);
    int var50 = var47.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var51 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var52 = var51.getShadowColor();
    int var53 = var52.getAlpha();
    var47.setLinePaint((java.awt.Paint)var52);
    org.jfree.chart.util.GradientPaintTransformer var55 = var47.getFillPaintTransformer();
    boolean var56 = var38.equals((java.lang.Object)var47);
    java.awt.Shape var57 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var38.setArea(var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     java.awt.Paint var15 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var20 = null;
//     var16.setLegendTextFont(5, var20);
//     java.awt.Font var22 = null;
//     var16.setBaseLegendTextFont(var22);
//     var16.clearSeriesStrokes(false);
//     int var26 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
//     java.lang.Boolean var28 = var16.getSeriesVisible(0);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var31 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var32 = var31.getDistance();
//     int var33 = var31.getDistance();
//     var29.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var31);
//     float var35 = var29.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var37 = null;
//     var29.setDomainAxisLocation(10, var37, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     var29.setRenderer(255, var41, false);
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var50 = var49.getShape();
//     org.jfree.chart.JFreeChart var51 = null;
//     org.jfree.chart.event.ChartChangeEvent var52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var50, var51);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var55 = null;
//     var54.setOutlineStroke(var55);
//     int var57 = var54.getSeriesIndex();
//     java.awt.Stroke var58 = var54.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var60 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var61 = var60.getShadowColor();
//     int var62 = var61.getAlpha();
//     java.awt.Color var63 = var61.darker();
//     int var64 = var63.getGreen();
//     java.awt.Color var65 = java.awt.Color.getColor("", var63);
//     org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var50, var58, (java.awt.Paint)var63);
//     var29.setDomainGridlineStroke(var58);
//     var16.setBaseStroke(var58, false);
//     var16.setSeriesItemLabelsVisible(1, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItem var75 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var76 = var75.getOutlinePaint();
//     org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem("hi!", var76);
//     org.jfree.chart.plot.CategoryPlot var78 = new org.jfree.chart.plot.CategoryPlot();
//     var78.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var80 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var81 = var80.getDistance();
//     int var82 = var80.getDistance();
//     var78.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var80);
//     float var84 = var78.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var86 = null;
//     var78.setDomainAxisLocation(10, var86, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var90 = null;
//     var78.setRenderer(255, var90, false);
//     java.awt.Paint var93 = var78.getDomainCrosshairPaint();
//     boolean var94 = var77.equals((java.lang.Object)var78);
//     boolean var95 = var16.equals((java.lang.Object)var78);
//     
//     // Checks the contract:  equals-hashcode on var0 and var78
//     assertTrue("Contract failed: equals-hashcode on var0 and var78", var0.equals(var78) ? var0.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var0
//     assertTrue("Contract failed: equals-hashcode on var78 and var0", var78.equals(var0) ? var78.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var75
//     assertTrue("Contract failed: equals-hashcode on var49 and var75", var49.equals(var75) ? var49.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var49
//     assertTrue("Contract failed: equals-hashcode on var75 and var49", var75.equals(var49) ? var75.hashCode() == var49.hashCode() : true);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    int var7 = var0.getRowIndex((java.lang.Comparable)(short)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("UnitType.ABSOLUTE");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-2));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    org.jfree.chart.plot.DrawingSupplier var15 = var0.getDrawingSupplier();
    float var16 = var0.getBackgroundImageAlpha();
    boolean var17 = var0.isDomainZoomable();
    org.jfree.chart.axis.AxisLocation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var9 = var8.toString();
    int var10 = var8.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var8.createContext(var11, var12, var13, var14, var15);
    var0.setShadowPaint((java.awt.Paint)var8);
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
    var0.setBaseItemLabelGenerator(var18, true);
    org.jfree.chart.event.RendererChangeListener var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeChangeListener(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var9.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     var0.setShadowVisible(false);
//     org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var6 = var5.getShadowColor();
//     int var7 = var6.getAlpha();
//     var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var10.getBaseItemLabelGenerator();
//     var10.setMaximumBarWidth(100.0d);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.setRangeCrosshairVisible(false);
//     var17.setCrosshairDatasetIndex(255, false);
//     boolean var23 = var17.canSelectByRegion();
//     var17.clearDomainMarkers();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = var17.getRenderer(0);
//     java.awt.Stroke var27 = var17.getRangeCrosshairStroke();
//     var10.setSeriesOutlineStroke(0, var27, true);
//     boolean var30 = var10.getAutoPopulateSeriesStroke();
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("");
//     var32.setDatasetIndex(0);
//     java.awt.Shape var35 = var32.getShape();
//     org.jfree.chart.entity.ChartEntity var37 = new org.jfree.chart.entity.ChartEntity(var35, "");
//     java.awt.Shape var38 = var37.getArea();
//     org.jfree.chart.labels.ItemLabelPosition var39 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var40 = var39.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var41 = var39.getItemLabelAnchor();
//     boolean var42 = var37.equals((java.lang.Object)var39);
//     var10.setNegativeItemLabelPositionFallback(var39);
//     var0.setNegativeItemLabelPositionFallback(var39);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var3 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var4 = var3.getDistance();
    int var5 = var3.getDistance();
    var1.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var3);
    float var7 = var1.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var9 = null;
    var1.setDomainAxisLocation(10, var9, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    var1.setRenderer(255, var13, false);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.setRangeCrosshairVisible(false);
    var17.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var24 = var17.getRangeAxisLocation((-1));
    var1.setDomainAxisLocation(100, var24, true);
    var1.clearAnnotations();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var30 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var1, "java.awt.Color[r=0,g=0,b=1]", "SortOrder.ASCENDING");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    int var8 = var5.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var10 = var9.getShadowColor();
    var5.setLinePaint((java.awt.Paint)var10);
    var0.setOutlinePaint((java.awt.Paint)var10);
    boolean var13 = var0.isOutlineVisible();
    java.awt.Stroke var14 = var0.getDomainCrosshairStroke();
    boolean var15 = var0.getDrawSharedDomainAxis();
    org.jfree.chart.plot.CategoryMarker var17 = null;
    org.jfree.chart.util.Layer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-264), var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Stroke var3 = var0.getItemStroke(0, 0);
//     java.awt.Stroke var5 = var0.getSeriesOutlineStroke((-1));
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var6 = var0.getNegativeItemLabelPosition(255, (-127), true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var4 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var5 = var4.getDistance();
    int var6 = var4.getDistance();
    var2.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var4);
    float var8 = var2.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var10 = null;
    var2.setDomainAxisLocation(10, var10, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var2.setRenderer(255, var14, false);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var23 = var22.getShape();
    org.jfree.chart.JFreeChart var24 = null;
    org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var23, var24);
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var28 = null;
    var27.setOutlineStroke(var28);
    int var30 = var27.getSeriesIndex();
    java.awt.Stroke var31 = var27.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var33 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var34 = var33.getShadowColor();
    int var35 = var34.getAlpha();
    java.awt.Color var36 = var34.darker();
    int var37 = var36.getGreen();
    java.awt.Color var38 = java.awt.Color.getColor("", var36);
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var23, var31, (java.awt.Paint)var36);
    var2.setDomainGridlineStroke(var31);
    var1.setTickMarkStroke(var31);
    int var42 = var1.getMaximumCategoryLabelLines();
    java.awt.Color var47 = java.awt.Color.getColor("", 1);
    java.awt.Color var48 = java.awt.Color.getColor("hi!", var47);
    org.jfree.chart.util.DefaultShadowGenerator var52 = new org.jfree.chart.util.DefaultShadowGenerator(15, var48, 10.0f, 255, (-9.21460183660255d));
    var1.setAxisLinePaint((java.awt.Paint)var48);
    org.jfree.chart.util.RectangleInsets var54 = var1.getLabelInsets();
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
    var55.setRangeCrosshairVisible(false);
    var55.setCrosshairDatasetIndex(255, false);
    boolean var61 = var55.canSelectByRegion();
    boolean var62 = var55.isRangePannable();
    java.awt.Graphics2D var63 = null;
    java.awt.geom.Rectangle2D var64 = null;
    org.jfree.chart.plot.PlotRenderingInfo var66 = null;
    org.jfree.chart.plot.CategoryCrosshairState var67 = null;
    boolean var68 = var55.render(var63, var64, 10, var66, var67);
    java.lang.Comparable var69 = var55.getDomainCrosshairRowKey();
    org.jfree.data.category.CategoryDataset var70 = null;
    var55.setDataset(var70);
    org.jfree.chart.axis.CategoryAnchor var72 = var55.getDomainGridlinePosition();
    java.awt.geom.Rectangle2D var75 = null;
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
    var76.setRangeCrosshairVisible(false);
    boolean var79 = var76.isRangeMinorGridlinesVisible();
    org.jfree.chart.util.RectangleEdge var80 = var76.getRangeAxisEdge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var81 = var1.getCategoryJava2DCoordinate(var72, 15, (-264), var75, var80);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var1 = var0.getShadowColor();
    int var2 = var0.getDistance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var1 = var0.getRowCount();
//     var0.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var8 = var6.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var14 = var13.getUnitType();
//     var6.setTickLabelInsets(var13);
//     var6.setMinorTickMarkInsideLength(0.5f);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var19.setBaseShapesVisible(false);
//     java.awt.Paint var22 = var19.getBaseItemLabelPaint();
//     java.lang.Boolean var24 = var19.getSeriesShapesFilled(1);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var6, var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.setRangeCrosshairVisible(false);
//     boolean var32 = var29.isRangeMinorGridlinesVisible();
//     org.jfree.chart.util.RectangleEdge var33 = var29.getRangeAxisEdge();
//     double var34 = var6.getCategoryEnd((-1), (-264), var28, var33);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "", "org.jfree.chart.event.ChartChangeEvent[source=100.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
    var1.setDefaultFillPaint((java.awt.Paint)var13);
    java.awt.Paint var17 = var1.getItemFillPaint(0, 0);
    org.jfree.chart.ChartColor var22 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var23 = var22.toString();
    java.awt.Color var24 = var22.darker();
    int var25 = var24.getTransparency();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesOutlinePaint((-1), (java.awt.Paint)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var23.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((java.lang.Comparable)100.0d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    java.awt.Stroke var5 = var0.lookupSeriesOutlineStroke(15);
    org.jfree.chart.labels.ItemLabelPosition var9 = var0.getNegativeItemLabelPosition(1, 5, true);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var10 = var0.getLegendItemLabelGenerator();
    var0.setShadowVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isDomainPannable();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var11 = var9.trimWidth(0.0d);
    double var13 = var9.trimWidth(109.21460183660255d);
    boolean var15 = var9.equals((java.lang.Object)"hi!");
    var4.setInsets(var9, true);
    var4.clearRangeAxes();
    var0.setParent((org.jfree.chart.plot.Plot)var4);
    java.util.List var20 = var0.getCategories();
    int var21 = var0.getDomainAxisCount();
    boolean var22 = var0.isDomainGridlinesVisible();
    boolean var23 = var0.canSelectByPoint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    java.awt.Paint var15 = var0.getDomainCrosshairPaint();
    org.jfree.chart.axis.AxisSpace var16 = var0.getFixedRangeAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    int var4 = var0.getRowIndex((java.lang.Comparable)10.0f);
    int var5 = var0.getRowCount();
    int var7 = var0.getRowIndex((java.lang.Comparable)(short)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var0.getColumnKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Shape var7 = var4.getShape();
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var7, "");
    java.lang.Object var10 = var9.clone();
    java.lang.String var11 = var9.getURLText();
    boolean var12 = var0.equals((java.lang.Object)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var15 = var0.getObject((java.lang.Comparable)5, (java.lang.Comparable)0.0d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("");
    var2.setDatasetIndex(0);
    java.awt.Paint var5 = var2.getFillPaint();
    org.jfree.data.KeyedObject var6 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var5);
    java.lang.Object var7 = var6.getObject();
    java.lang.Object var8 = var6.getObject();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.data.SelectableValue var1 = new org.jfree.data.SelectableValue((java.lang.Number)10L);

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     boolean var3 = var0.isDomainPannable();
//     var0.setWeight((-1));
//     var0.zoom(0.0d);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.axis.AxisLocation var2 = var0.getRangeAxisLocation();
    var0.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.event.PlotChangeEvent var5 = null;
    var0.notifyListeners(var5);
    java.awt.Paint var7 = var0.getNoDataMessagePaint();
    org.jfree.chart.annotations.CategoryAnnotation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var8, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     boolean var7 = var0.isRangePannable();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.setRangeCrosshairVisible(false);
//     var8.setCrosshairDatasetIndex(255, false);
//     org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation((-1));
//     var0.setRangeAxisLocation(var15);
//     java.awt.Stroke var17 = var0.getRangeMinorGridlineStroke();
//     org.jfree.chart.plot.Marker var19 = null;
//     org.jfree.chart.util.Layer var20 = null;
//     var0.addRangeMarker(15, var19, var20, false);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setBaseShapesVisible(false);
    var0.setAutoPopulateSeriesStroke(false);
    java.awt.Paint var6 = var0.getSeriesItemLabelPaint((-1));
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelGenerator((-1), var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    java.awt.Stroke var5 = var1.getLineStroke();
    var1.setDescription("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    var0.clearSeriesStrokes(false);
    double var10 = var0.getShadowXOffset();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var0.setBaseToolTipGenerator(var11);
    boolean var14 = var0.isSeriesVisible(15);
    java.awt.Stroke var15 = var0.getBaseOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisibleInLegend((-264), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    var0.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var0.getValue(7, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(255, 255, 1);
    java.awt.Color var4 = var3.brighter();
    int var5 = var3.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Shape var4 = var1.getShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var4, "");
    var6.setToolTipText("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var10 = var9.getUseOutlinePaint();
    var9.setItemMargin(0.0d);
    java.awt.Shape var16 = var9.getItemShape(5, (-264), false);
    var6.setArea(var16);
    java.lang.String var18 = var6.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var18.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getRowIndex((java.lang.Comparable)0L);
    java.util.List var3 = var0.getRowKeys();
    int var4 = var0.getColumnCount();
    int var5 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeObject((java.lang.Comparable)10, (java.lang.Comparable)109.21460183660255d);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     var0.setShadowVisible(false);
//     org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var6 = var5.getShadowColor();
//     int var7 = var6.getAlpha();
//     var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var13 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var14 = var13.getDistance();
//     int var15 = var13.getDistance();
//     var11.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var13);
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.CategoryAxis[] var18 = new org.jfree.chart.axis.CategoryAxis[] { var17};
//     var11.setDomainAxes(var18);
//     org.jfree.chart.plot.PlotOrientation var20 = var11.getOrientation();
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var27 = var24.getBaseItemLabelGenerator();
//     java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
//     var24.setSeriesItemLabelPaint(1, (java.awt.Paint)var32, false);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.data.Range var36 = var24.findRangeBounds(var35);
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("");
//     var39.setDatasetIndex(0);
//     java.awt.Paint var42 = var39.getFillPaint();
//     org.jfree.data.KeyedObject var43 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var42);
//     var24.setBaseItemLabelPaint(var42);
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var47 = var45.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.urls.CategoryURLGenerator var48 = var45.getBaseURLGenerator();
//     java.awt.Paint var50 = var45.lookupSeriesFillPaint(0);
//     java.awt.Stroke var52 = var45.lookupSeriesStroke((-264));
//     var0.drawRangeLine(var10, var11, var21, var22, (-91.21460183660255d), var42, var52);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var2 = var0.calculateRightInset(100.0d);
    double var4 = var0.calculateLeftInset(8.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    org.jfree.data.KeyedObjects var2 = new org.jfree.data.KeyedObjects();
    java.lang.Object var3 = var2.clone();
    boolean var4 = var0.equals((java.lang.Object)var2);
    int var5 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = var0.getObject((java.lang.Comparable)1L);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
//     var0.setMaximumBarWidth(100.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var7 = var6.getUseOutlinePaint();
//     var6.setItemMargin(0.0d);
//     var6.setBaseShapesVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var17 = null;
//     var13.setLegendTextFont(5, var17);
//     java.awt.Font var19 = null;
//     var13.setBaseLegendTextFont(var19);
//     var13.clearSeriesStrokes(false);
//     java.awt.Paint var23 = var13.getBaseItemLabelPaint();
//     org.jfree.chart.labels.CategoryToolTipGenerator var24 = null;
//     var13.setBaseToolTipGenerator(var24, false);
//     java.awt.Stroke var27 = var13.getBaseOutlineStroke();
//     java.awt.Font var31 = var13.getItemLabelFont(0, (-264), false);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.setRangeCrosshairVisible(false);
//     var32.setCrosshairDatasetIndex(255, false);
//     boolean var38 = var32.canSelectByRegion();
//     var32.clearDomainMarkers();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = var32.getRenderer(0);
//     java.awt.Stroke var42 = var32.getRangeCrosshairStroke();
//     java.awt.Paint var43 = var32.getBackgroundPaint();
//     boolean var44 = var13.equals((java.lang.Object)var43);
//     var6.setLegendTextPaint(1, var43);
//     var0.setBaseLegendTextPaint(var43);
//     
//     // Checks the contract:  equals-hashcode on var2 and var15
//     assertTrue("Contract failed: equals-hashcode on var2 and var15", var2.equals(var15) ? var2.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var2
//     assertTrue("Contract failed: equals-hashcode on var15 and var2", var15.equals(var2) ? var15.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var4 = null;
//     var0.setLegendTextFont(5, var4);
//     java.awt.Font var6 = null;
//     var0.setBaseLegendTextFont(var6);
//     var0.clearSeriesStrokes(false);
//     java.awt.Paint var10 = var0.getBaseItemLabelPaint();
//     org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
//     var0.setBaseToolTipGenerator(var11, false);
//     java.awt.Stroke var14 = var0.getBaseOutlineStroke();
//     java.awt.Font var18 = var0.getItemLabelFont(0, (-264), false);
//     java.awt.Shape var19 = var0.getBaseShape();
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var20.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var20.getBaseItemLabelGenerator();
//     java.awt.Stroke var25 = var20.lookupSeriesOutlineStroke(15);
//     org.jfree.chart.labels.ItemLabelPosition var29 = var20.getNegativeItemLabelPosition(1, 5, true);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = var20.getLegendItemLabelGenerator();
//     double var31 = var20.getShadowXOffset();
//     org.jfree.chart.renderer.category.BarPainter var32 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
//     var20.setBarPainter(var32);
//     var0.setBarPainter(var32);
//     
//     // Checks the contract:  equals-hashcode on var2 and var22
//     assertTrue("Contract failed: equals-hashcode on var2 and var22", var2.equals(var22) ? var2.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var29
//     assertTrue("Contract failed: equals-hashcode on var2 and var29", var2.equals(var29) ? var2.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var2
//     assertTrue("Contract failed: equals-hashcode on var22 and var2", var22.equals(var2) ? var22.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var2
//     assertTrue("Contract failed: equals-hashcode on var29 and var2", var29.equals(var2) ? var29.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var7 = var5.trimWidth(0.0d);
    double var9 = var5.trimWidth(109.21460183660255d);
    boolean var11 = var5.equals((java.lang.Object)"hi!");
    var0.setInsets(var5, true);
    var0.clearRangeAxes();
    org.jfree.chart.axis.AxisSpace var15 = null;
    var0.setFixedRangeAxisSpace(var15, true);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var22 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var23 = var22.getDistance();
    int var24 = var22.getDistance();
    var20.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var22);
    float var26 = var20.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var28 = null;
    var20.setDomainAxisLocation(10, var28, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    var20.setRenderer(255, var32, false);
    org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var41 = var40.getShape();
    org.jfree.chart.JFreeChart var42 = null;
    org.jfree.chart.event.ChartChangeEvent var43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var41, var42);
    org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var46 = null;
    var45.setOutlineStroke(var46);
    int var48 = var45.getSeriesIndex();
    java.awt.Stroke var49 = var45.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var51 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var52 = var51.getShadowColor();
    int var53 = var52.getAlpha();
    java.awt.Color var54 = var52.darker();
    int var55 = var54.getGreen();
    java.awt.Color var56 = java.awt.Color.getColor("", var54);
    org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var41, var49, (java.awt.Paint)var54);
    var20.setDomainGridlineStroke(var49);
    var19.setTickMarkStroke(var49);
    int var60 = var19.getMaximumCategoryLabelLines();
    var19.setUpperMargin(100.0d);
    var0.setDomainAxis(var19);
    var19.setVisible(true);
    java.awt.Paint var66 = var19.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var67 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setLabelInsets(var67, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
    var4.setDatasetIndex(0);
    java.awt.Paint var7 = var4.getFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
    var1.setDefaultLabelPaint(var7);
    org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
    var1.setDefaultFillPaint((java.awt.Paint)var13);
    java.awt.Paint var15 = var1.getDefaultPaint();
    java.awt.Shape var17 = var1.getSeriesShape(10);
    java.lang.Boolean var18 = var1.getDefaultLabelVisible();
    java.awt.Stroke var20 = var1.getSeriesStroke(0);
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var24 = var22.getSeriesNegativeItemLabelPosition(0);
    var22.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var27 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var28 = var27.getShadowColor();
    int var29 = var28.getAlpha();
    var22.setBaseItemLabelPaint((java.awt.Paint)var28, true);
    var22.setMaximumBarWidth(100.0d);
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var36 = null;
    var35.setOutlineStroke(var36);
    int var38 = var35.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var39 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var40 = var39.getShadowColor();
    int var41 = var40.getAlpha();
    var35.setLinePaint((java.awt.Paint)var40);
    org.jfree.chart.util.DefaultShadowGenerator var43 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var44 = var43.getShadowColor();
    int var45 = var44.getAlpha();
    java.awt.Color var46 = var44.darker();
    java.awt.image.ColorModel var47 = null;
    java.awt.Rectangle var48 = null;
    java.awt.geom.Rectangle2D var49 = null;
    java.awt.geom.AffineTransform var50 = null;
    java.awt.RenderingHints var51 = null;
    java.awt.PaintContext var52 = var46.createContext(var47, var48, var49, var50, var51);
    var35.setFillPaint((java.awt.Paint)var46);
    var22.setBaseFillPaint((java.awt.Paint)var46, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesOutlinePaint((-264), (java.awt.Paint)var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var3 = var1.get(1);
    int var4 = var1.size();
    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var7 = null;
    var6.setOutlineStroke(var7);
    int var9 = var6.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var10 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var11 = var10.getShadowColor();
    var6.setLinePaint((java.awt.Paint)var11);
    org.jfree.data.category.AbstractCategoryDataset var13 = new org.jfree.data.category.AbstractCategoryDataset();
    var6.setDataset((org.jfree.data.general.Dataset)var13);
    org.jfree.chart.event.DatasetChangeInfo var15 = new org.jfree.chart.event.DatasetChangeInfo();
    org.jfree.data.event.DatasetChangeEvent var16 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var1, (org.jfree.data.general.Dataset)var13, var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var19 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var20 = var19.getDistance();
    int var21 = var19.getDistance();
    var17.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var19);
    var13.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var17);
    org.jfree.chart.util.RectangleEdge var24 = var17.getRangeAxisEdge();
    var17.setDomainCrosshairVisible(false);
    org.jfree.chart.axis.AxisSpace var27 = var17.getFixedDomainAxisSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    boolean var1 = var0.getBaseSeriesVisible();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var3.setBaseShapesVisible(false);
    java.awt.Paint var6 = var3.getBaseItemLabelPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var7.setBaseLinesVisible(false);
    org.jfree.chart.renderer.RenderAttributes var12 = new org.jfree.chart.renderer.RenderAttributes(true);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.AxisSpace var14 = var13.getFixedRangeAxisSpace();
    var13.setWeight(10);
    org.jfree.chart.axis.CategoryAxis var17 = null;
    var13.setDomainAxis(var17);
    java.awt.Paint var19 = var13.getRangeMinorGridlinePaint();
    org.jfree.chart.axis.CategoryAxis var21 = var13.getDomainAxis(1);
    java.awt.Font var22 = var13.getNoDataMessageFont();
    var12.setDefaultLabelFont(var22);
    var7.setSeriesItemLabelFont(0, var22, false);
    var3.setBaseItemLabelFont(var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendTextFont((-16777216), var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var4 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var5 = var4.getDistance();
//     int var6 = var4.getDistance();
//     var2.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var4);
//     float var8 = var2.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var10 = null;
//     var2.setDomainAxisLocation(10, var10, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     var2.setRenderer(255, var14, false);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var23 = var22.getShape();
//     org.jfree.chart.JFreeChart var24 = null;
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var23, var24);
//     org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var28 = null;
//     var27.setOutlineStroke(var28);
//     int var30 = var27.getSeriesIndex();
//     java.awt.Stroke var31 = var27.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var33 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var34 = var33.getShadowColor();
//     int var35 = var34.getAlpha();
//     java.awt.Color var36 = var34.darker();
//     int var37 = var36.getGreen();
//     java.awt.Color var38 = java.awt.Color.getColor("", var36);
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var23, var31, (java.awt.Paint)var36);
//     var2.setDomainGridlineStroke(var31);
//     var1.setTickMarkStroke(var31);
//     org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var48 = var46.trimWidth(0.0d);
//     double var49 = var46.getRight();
//     var1.setLabelInsets(var46, false);
//     var1.setLabelURL("PlotOrientation.VERTICAL");
//     org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var60 = var59.getShape();
//     org.jfree.chart.JFreeChart var61 = null;
//     org.jfree.chart.event.ChartChangeEvent var62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var60, var61);
//     org.jfree.chart.LegendItem var64 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var65 = null;
//     var64.setOutlineStroke(var65);
//     int var67 = var64.getSeriesIndex();
//     java.awt.Stroke var68 = var64.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var70 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var71 = var70.getShadowColor();
//     int var72 = var71.getAlpha();
//     java.awt.Color var73 = var71.darker();
//     int var74 = var73.getGreen();
//     java.awt.Color var75 = java.awt.Color.getColor("", var73);
//     org.jfree.chart.LegendItem var76 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var60, var68, (java.awt.Paint)var73);
//     var1.setAxisLineStroke(var68);
//     
//     // Checks the contract:  equals-hashcode on var22 and var59
//     assertTrue("Contract failed: equals-hashcode on var22 and var59", var22.equals(var59) ? var22.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var76
//     assertTrue("Contract failed: equals-hashcode on var39 and var76", var39.equals(var76) ? var39.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var22
//     assertTrue("Contract failed: equals-hashcode on var59 and var22", var59.equals(var22) ? var59.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var39
//     assertTrue("Contract failed: equals-hashcode on var76 and var39", var76.equals(var39) ? var76.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    var1.setSeriesIndex(1);
    java.awt.Stroke var6 = var1.getOutlineStroke();
    java.awt.Paint var7 = var1.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.plot.Marker var2 = null;
    org.jfree.chart.util.Layer var3 = null;
    boolean var4 = var0.removeDomainMarker(var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis(255);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.setRangeCrosshairVisible(false);
    var8.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var15 = var8.getRangeAxisLocation((-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-16777215), var15, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var2 = var1.getShadowColor();
//     int var3 = var2.getAlpha();
//     java.awt.Color var4 = var2.darker();
//     int var5 = var4.getGreen();
//     java.awt.Color var6 = java.awt.Color.getColor("", var4);
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var4};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var12 = var11.getOutlinePaint();
//     boolean var13 = var9.equals((java.lang.Object)var12);
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     float[] var22 = null;
//     float[] var23 = var21.getComponents(var22);
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var21};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     int var33 = var30.getSeriesIndex();
//     java.awt.Stroke var34 = var30.getOutlineStroke();
//     java.awt.Shape var35 = var30.getShape();
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var14, var24, var26, var28, var36);
//     java.awt.Paint var38 = var37.getNextOutlinePaint();
//     boolean var40 = var37.equals((java.lang.Object)10);
//     java.awt.Stroke var41 = var37.getNextOutlineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var43 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var44 = var43.getShadowColor();
//     int var45 = var44.getAlpha();
//     java.awt.Color var46 = var44.darker();
//     int var47 = var46.getGreen();
//     java.awt.Color var48 = java.awt.Color.getColor("", var46);
//     java.awt.Paint[] var49 = new java.awt.Paint[] { var46};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var51 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var54 = var53.getOutlinePaint();
//     boolean var55 = var51.equals((java.lang.Object)var54);
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var54};
//     org.jfree.chart.util.DefaultShadowGenerator var58 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var59 = var58.getShadowColor();
//     int var60 = var59.getAlpha();
//     java.awt.Color var61 = var59.darker();
//     int var62 = var61.getGreen();
//     java.awt.Color var63 = java.awt.Color.getColor("", var61);
//     float[] var64 = null;
//     float[] var65 = var63.getComponents(var64);
//     java.awt.Paint[] var66 = new java.awt.Paint[] { var63};
//     java.awt.Stroke var67 = null;
//     java.awt.Stroke[] var68 = new java.awt.Stroke[] { var67};
//     java.awt.Stroke var69 = null;
//     java.awt.Stroke[] var70 = new java.awt.Stroke[] { var69};
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var73 = null;
//     var72.setOutlineStroke(var73);
//     int var75 = var72.getSeriesIndex();
//     java.awt.Stroke var76 = var72.getOutlineStroke();
//     java.awt.Shape var77 = var72.getShape();
//     java.awt.Shape[] var78 = new java.awt.Shape[] { var77};
//     org.jfree.chart.plot.DefaultDrawingSupplier var79 = new org.jfree.chart.plot.DefaultDrawingSupplier(var49, var56, var66, var68, var70, var78);
//     java.awt.Paint var80 = var79.getNextOutlinePaint();
//     java.awt.Paint var81 = var79.getNextOutlinePaint();
//     boolean var82 = var37.equals((java.lang.Object)var79);
//     
//     // Checks the contract:  equals-hashcode on var11 and var53
//     assertTrue("Contract failed: equals-hashcode on var11 and var53", var11.equals(var53) ? var11.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var11
//     assertTrue("Contract failed: equals-hashcode on var53 and var11", var53.equals(var11) ? var53.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var2 = var1.getShadowColor();
    int var3 = var2.getAlpha();
    java.awt.Color var4 = var2.darker();
    int var5 = var4.getGreen();
    java.awt.Color var6 = java.awt.Color.getColor("", var4);
    java.awt.Paint[] var7 = new java.awt.Paint[] { var4};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var12 = var11.getOutlinePaint();
    boolean var13 = var9.equals((java.lang.Object)var12);
    java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    float[] var22 = null;
    float[] var23 = var21.getComponents(var22);
    java.awt.Paint[] var24 = new java.awt.Paint[] { var21};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var31 = null;
    var30.setOutlineStroke(var31);
    int var33 = var30.getSeriesIndex();
    java.awt.Stroke var34 = var30.getOutlineStroke();
    java.awt.Shape var35 = var30.getShape();
    java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
    org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var14, var24, var26, var28, var36);
    java.awt.Paint var38 = var37.getNextOutlinePaint();
    java.awt.Paint var39 = var37.getNextOutlinePaint();
    java.awt.Paint var40 = var37.getNextOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var43 = var41.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var49 = var48.getUnitType();
    var41.setTickLabelInsets(var48);
    org.jfree.chart.util.RectangleInsets var55 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var57 = var55.trimWidth(0.0d);
    double var59 = var55.calculateTopInset(0.0d);
    double var61 = var55.extendWidth(100.0d);
    java.lang.String var62 = var55.toString();
    var41.setLabelInsets(var55);
    org.jfree.chart.plot.Plot var64 = var41.getPlot();
    org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
    var65.setRangeCrosshairVisible(false);
    var65.clearSelection();
    org.jfree.chart.util.SortOrder var69 = var65.getColumnRenderingOrder();
    var41.addChangeListener((org.jfree.chart.event.AxisChangeListener)var65);
    var41.setFixedDimension(1.0d);
    org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
    var73.setRangeCrosshairVisible(false);
    var73.setCrosshairDatasetIndex(255, false);
    boolean var79 = var73.canSelectByRegion();
    var73.clearDomainMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var82 = var73.getRenderer(0);
    java.awt.Stroke var83 = var73.getRangeCrosshairStroke();
    boolean var84 = var41.hasListener((java.util.EventListener)var73);
    org.jfree.chart.util.Layer var85 = null;
    java.util.Collection var86 = var73.getDomainMarkers(var85);
    org.jfree.chart.axis.AxisSpace var87 = var73.getFixedDomainAxisSpace();
    boolean var88 = var37.equals((java.lang.Object)var73);
    org.jfree.chart.ChartColor var92 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var93 = var92.toString();
    java.awt.Color var94 = var92.darker();
    int var95 = var94.getTransparency();
    var73.setBackgroundPaint((java.awt.Paint)var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 109.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"+ "'", var62.equals("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var93 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var93.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == 1);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    java.awt.Stroke var5 = var1.getLineStroke();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var10 = null;
    var6.setLegendTextFont(5, var10);
    java.awt.Font var12 = null;
    var6.setBaseLegendTextFont(var12);
    java.awt.Stroke var15 = var6.getSeriesOutlineStroke((-2));
    java.awt.Paint var19 = var6.getItemPaint((-16777216), (-16777215), true);
    var1.setFillPaint(var19);
    var1.setSeriesIndex(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
//     var0.setSeriesItemLabelPaint(1, (java.awt.Paint)var8, false);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var14 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var15 = var14.getDistance();
//     int var16 = var14.getDistance();
//     var12.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var14);
//     float var18 = var12.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var20 = null;
//     var12.setDomainAxisLocation(10, var20, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     var12.setRenderer(255, var24, false);
//     java.awt.Paint var27 = var12.getDomainCrosshairPaint();
//     java.lang.String var28 = var12.getPlotType();
//     org.jfree.chart.axis.AxisSpace var29 = null;
//     var12.setFixedDomainAxisSpace(var29, false);
//     org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var34 = var32.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var36 = null;
//     var32.setLegendTextFont(5, var36);
//     java.awt.Font var38 = null;
//     var32.setBaseLegendTextFont(var38);
//     var32.clearSeriesStrokes(false);
//     double var42 = var32.getShadowXOffset();
//     var32.setDefaultEntityRadius(0);
//     org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
//     boolean var47 = var46.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.util.StrokeList var48 = new org.jfree.chart.util.StrokeList();
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var56 = var55.getShape();
//     org.jfree.chart.JFreeChart var57 = null;
//     org.jfree.chart.event.ChartChangeEvent var58 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var56, var57);
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var61 = null;
//     var60.setOutlineStroke(var61);
//     int var63 = var60.getSeriesIndex();
//     java.awt.Stroke var64 = var60.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var66 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var67 = var66.getShadowColor();
//     int var68 = var67.getAlpha();
//     java.awt.Color var69 = var67.darker();
//     int var70 = var69.getGreen();
//     java.awt.Color var71 = java.awt.Color.getColor("", var69);
//     org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var56, var64, (java.awt.Paint)var69);
//     var48.setStroke(100, var64);
//     var46.setBaseStroke(var64, true);
//     var32.setSeriesOutlineStroke(10, var64, false);
//     var12.setRangeZeroBaselineStroke(var64);
//     var0.setSeriesOutlineStroke(0, var64, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var34
//     assertTrue("Contract failed: equals-hashcode on var2 and var34", var2.equals(var34) ? var2.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var2
//     assertTrue("Contract failed: equals-hashcode on var34 and var2", var34.equals(var2) ? var34.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Paint var15 = var1.getDefaultPaint();
//     org.jfree.chart.renderer.RenderAttributes var17 = new org.jfree.chart.renderer.RenderAttributes(true);
//     java.awt.Paint var20 = var17.getItemPaint(255, 100);
//     java.awt.Color var23 = java.awt.Color.getColor("", 1);
//     var17.setDefaultLabelPaint((java.awt.Paint)var23);
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("");
//     java.awt.Shape var32 = var31.getShape();
//     org.jfree.chart.JFreeChart var33 = null;
//     org.jfree.chart.event.ChartChangeEvent var34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var32, var33);
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var37 = null;
//     var36.setOutlineStroke(var37);
//     int var39 = var36.getSeriesIndex();
//     java.awt.Stroke var40 = var36.getLineStroke();
//     org.jfree.chart.util.DefaultShadowGenerator var42 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var43 = var42.getShadowColor();
//     int var44 = var43.getAlpha();
//     java.awt.Color var45 = var43.darker();
//     int var46 = var45.getGreen();
//     java.awt.Color var47 = java.awt.Color.getColor("", var45);
//     org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var32, var40, (java.awt.Paint)var45);
//     var17.setSeriesShape(0, var32);
//     var1.setDefaultShape(var32);
//     
//     // Checks the contract:  equals-hashcode on var4 and var31
//     assertTrue("Contract failed: equals-hashcode on var4 and var31", var4.equals(var31) ? var4.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var4
//     assertTrue("Contract failed: equals-hashcode on var31 and var4", var31.equals(var4) ? var31.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setItemMargin(0.0d);
    java.awt.Shape var7 = var0.getItemShape(5, (-264), false);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var10 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var11 = var10.getDistance();
    int var12 = var10.getDistance();
    var8.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var10);
    float var14 = var8.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var16 = null;
    var8.setDomainAxisLocation(10, var16, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    var8.setRenderer(255, var20, false);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    var24.setRangeCrosshairVisible(false);
    var24.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var31 = var24.getRangeAxisLocation((-1));
    var8.setDomainAxisLocation(100, var31, true);
    var8.clearAnnotations();
    org.jfree.chart.entity.PlotEntity var36 = new org.jfree.chart.entity.PlotEntity(var7, (org.jfree.chart.plot.Plot)var8, "ItemLabelAnchor.OUTSIDE12");
    java.lang.Object var37 = null;
    boolean var38 = var36.equals(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.plot.Marker var2 = null;
    org.jfree.chart.util.Layer var3 = null;
    boolean var4 = var0.removeDomainMarker(var2, var3);
    org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis(255);
    org.jfree.chart.util.RectangleEdge var8 = var0.getDomainAxisEdge(100);
    org.jfree.chart.plot.Marker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var12 = var0.removeRangeMarker(255, var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var4 = var0.createOutsetRectangle(var1, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(255);
    java.awt.Paint var4 = var0.getPaint((-16777216));
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    var1.setDatasetIndex(0);
    java.awt.Font var4 = var1.getLabelFont();
    int var5 = var1.getSeriesIndex();
    java.lang.String var6 = var1.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    int var3 = var0.getIndex((java.lang.Comparable)(short)100);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var0.getKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var8 = var7.getUnitType();
    var0.setTickLabelInsets(var7);
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var16 = var14.trimWidth(0.0d);
    double var18 = var14.calculateTopInset(0.0d);
    double var20 = var14.extendWidth(100.0d);
    java.lang.String var21 = var14.toString();
    var0.setLabelInsets(var14);
    org.jfree.chart.plot.Plot var23 = var0.getPlot();
    org.jfree.data.category.DefaultCategoryDataset var25 = new org.jfree.data.category.DefaultCategoryDataset();
    int var26 = var25.getRowCount();
    var25.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var25.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    int var36 = var25.getRowIndex((java.lang.Comparable)(short)10);
    var25.setValue((java.lang.Number)(-91.21460183660255d), (java.lang.Comparable)0L, (java.lang.Comparable)'#');
    java.util.List var41 = var25.getColumnKeys();
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
    var43.configureDomainAxes();
    org.jfree.chart.plot.Marker var45 = null;
    org.jfree.chart.util.Layer var46 = null;
    boolean var47 = var43.removeDomainMarker(var45, var46);
    org.jfree.chart.axis.ValueAxis var49 = var43.getRangeAxis(255);
    org.jfree.chart.util.RectangleEdge var51 = var43.getDomainAxisEdge(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var52 = var0.getCategoryMiddle((java.lang.Comparable)2.0d, var41, var42, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 109.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"+ "'", var21.equals("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    var0.clearSeriesStrokes(false);
    java.awt.Paint var10 = var0.getBaseItemLabelPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var0.setBaseToolTipGenerator(var11, false);
    java.awt.Stroke var14 = var0.getBaseOutlineStroke();
    java.awt.Font var18 = var0.getItemLabelFont(0, (-264), false);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
    var19.setRangeCrosshairVisible(false);
    var19.setCrosshairDatasetIndex(255, false);
    boolean var25 = var19.canSelectByRegion();
    var19.clearDomainMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = var19.getRenderer(0);
    java.awt.Stroke var29 = var19.getRangeCrosshairStroke();
    java.awt.Paint var30 = var19.getBackgroundPaint();
    boolean var31 = var0.equals((java.lang.Object)var30);
    java.awt.Stroke var32 = var0.getBaseStroke();
    java.awt.Stroke var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseOutlineStroke(var33, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var4 = null;
//     var0.setLegendTextFont(5, var4);
//     java.awt.Font var6 = null;
//     var0.setBaseLegendTextFont(var6);
//     java.awt.Stroke var9 = var0.getSeriesOutlineStroke((-2));
//     org.jfree.chart.urls.CategoryURLGenerator var11 = var0.getSeriesURLGenerator((-127));
//     org.jfree.chart.labels.ItemLabelPosition var13 = var0.getSeriesNegativeItemLabelPosition((-1));
//     org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var17 = var14.getBaseItemLabelGenerator();
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
//     var14.setSeriesItemLabelPaint(1, (java.awt.Paint)var22, false);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.data.Range var26 = var14.findRangeBounds(var25);
//     boolean var28 = var14.isSeriesVisibleInLegend((-264));
//     java.awt.Paint var32 = var14.getItemLabelPaint(255, 1, true);
//     org.jfree.chart.labels.ItemLabelPosition var33 = new org.jfree.chart.labels.ItemLabelPosition();
//     double var34 = var33.getAngle();
//     var14.setPositiveItemLabelPositionFallback(var33);
//     var0.setPositiveItemLabelPositionFallback(var33);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var0 and var14.", var0.equals(var14) == var14.equals(var0));
//     
//     // Checks the contract:  equals-hashcode on var2 and var16
//     assertTrue("Contract failed: equals-hashcode on var2 and var16", var2.equals(var16) ? var2.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var16
//     assertTrue("Contract failed: equals-hashcode on var13 and var16", var13.equals(var16) ? var13.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var2
//     assertTrue("Contract failed: equals-hashcode on var16 and var2", var16.equals(var2) ? var16.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var13
//     assertTrue("Contract failed: equals-hashcode on var16 and var13", var16.equals(var13) ? var16.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var1 = var0.getRowCount();
    var0.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    var0.setValue((java.lang.Number)5, (java.lang.Comparable)(-127), (java.lang.Comparable)"ItemLabelAnchor.OUTSIDE12");
    int var11 = var0.getRowIndex((java.lang.Comparable)(short)10);
    var0.setValue((java.lang.Number)(-91.21460183660255d), (java.lang.Comparable)0L, (java.lang.Comparable)'#');
    var0.fireSelectionEvent();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var0.getValue(255, (-16777216));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    boolean var13 = var10.equals((java.lang.Object)var12);
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var10);
    java.awt.Paint var16 = var0.getSeriesItemLabelPaint((-1));
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var19 = null;
    var18.setOutlineStroke(var19);
    var18.setURLText("");
    java.awt.Paint var23 = var18.getLabelPaint();
    java.awt.Shape var28 = null;
    org.jfree.chart.ChartColor var32 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var33 = var32.toString();
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "", "", "", var28, (java.awt.Paint)var32);
    int var35 = var32.getAlpha();
    var18.setFillPaint((java.awt.Paint)var32);
    java.awt.image.ColorModel var37 = null;
    java.awt.Rectangle var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    java.awt.geom.AffineTransform var40 = null;
    java.awt.RenderingHints var41 = null;
    java.awt.PaintContext var42 = var32.createContext(var37, var38, var39, var40, var41);
    var0.setBaseOutlinePaint((java.awt.Paint)var32, true);
    var0.setSeriesItemLabelsVisible(2, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var33.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = var0.getSeriesToolTipGenerator(7);
    java.awt.Paint var12 = var0.getBaseLegendTextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    var0.clearSeriesStrokes(false);
    java.awt.Paint var10 = var0.getBaseItemLabelPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var0.setBaseToolTipGenerator(var11, false);
    boolean var15 = var0.isSeriesVisible(4);
    org.jfree.chart.renderer.category.BarPainter var16 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var0.setBarPainter(var16);
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var6 = var5.getShape();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6, var7);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var11 = null;
    var10.setOutlineStroke(var11);
    int var13 = var10.getSeriesIndex();
    java.awt.Stroke var14 = var10.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var6, var14, (java.awt.Paint)var19);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var30 = var28.trimWidth(0.0d);
    double var32 = var28.trimWidth(109.21460183660255d);
    boolean var34 = var28.equals((java.lang.Object)"hi!");
    var23.setInsets(var28, true);
    org.jfree.chart.entity.PlotEntity var38 = new org.jfree.chart.entity.PlotEntity(var6, (org.jfree.chart.plot.Plot)var23, "org.jfree.chart.event.ChartChangeEvent[source=-1]");
    org.jfree.chart.util.SortOrder var39 = var23.getColumnRenderingOrder();
    org.jfree.chart.util.RectangleInsets var40 = var23.getAxisOffset();
    var23.setDrawSharedDomainAxis(false);
    boolean var43 = var23.isOutlineVisible();
    org.jfree.chart.axis.ValueAxis var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var45 = var23.getRangeAxisIndex(var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     java.awt.Paint var4 = var1.getItemPaint(255, 100);
//     java.awt.Font var5 = var1.getDefaultLabelFont();
//     java.awt.Paint var7 = var1.getSeriesOutlinePaint(0);
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var10 = null;
//     var9.setOutlineStroke(var10);
//     int var12 = var9.getSeriesIndex();
//     java.awt.Color var16 = java.awt.Color.getColor("", 1);
//     java.awt.Color var17 = java.awt.Color.getColor("hi!", var16);
//     var9.setLinePaint((java.awt.Paint)var16);
//     var1.setDefaultPaint((java.awt.Paint)var16);
//     java.lang.Boolean var21 = var1.getSeriesCreateEntity(0);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    var0.setMaximumBarWidth(100.0d);
    org.jfree.chart.LegendItem var13 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var14 = null;
    var13.setOutlineStroke(var14);
    int var16 = var13.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var18 = var17.getShadowColor();
    int var19 = var18.getAlpha();
    var13.setLinePaint((java.awt.Paint)var18);
    org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var22 = var21.getShadowColor();
    int var23 = var22.getAlpha();
    java.awt.Color var24 = var22.darker();
    java.awt.image.ColorModel var25 = null;
    java.awt.Rectangle var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    java.awt.geom.AffineTransform var28 = null;
    java.awt.RenderingHints var29 = null;
    java.awt.PaintContext var30 = var24.createContext(var25, var26, var27, var28, var29);
    var13.setFillPaint((java.awt.Paint)var24);
    var0.setBaseFillPaint((java.awt.Paint)var24, true);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.configureDomainAxes();
    java.lang.Object var36 = var34.clone();
    java.awt.Stroke var37 = var34.getRangeGridlineStroke();
    boolean var38 = var0.hasListener((java.util.EventListener)var34);
    org.jfree.chart.plot.DrawingSupplier var39 = var34.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var7 = null;
//     var6.setOutlineStroke(var7);
//     var6.setURLText("");
//     var6.setToolTipText("hi!");
//     boolean var13 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.util.Layer var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var0.drawAnnotations(var1, var2, var4, var14, var15, var16);
// 
//   }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
    float var2 = var1.getShadowOpacity();
    float var3 = var1.getShadowOpacity();
    boolean var4 = var0.equals((java.lang.Object)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    java.awt.Paint var15 = var0.getDomainCrosshairPaint();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var20 = null;
    var16.setLegendTextFont(5, var20);
    java.awt.Font var22 = null;
    var16.setBaseLegendTextFont(var22);
    var16.clearSeriesStrokes(false);
    int var26 = var0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    java.lang.Boolean var28 = var16.getSeriesVisible(0);
    java.awt.Graphics2D var29 = null;
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = null;
    org.jfree.data.category.DefaultCategoryDataset var32 = new org.jfree.data.category.DefaultCategoryDataset();
    int var33 = var32.getRowCount();
    var32.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var40 = var38.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var45 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var46 = var45.getUnitType();
    var38.setTickLabelInsets(var45);
    var38.setMinorTickMarkInsideLength(0.5f);
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var51.setBaseShapesVisible(false);
    java.awt.Paint var54 = var51.getBaseItemLabelPaint();
    java.lang.Boolean var56 = var51.getSeriesShapesFilled(1);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var32, var38, var50, (org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
    org.jfree.chart.plot.PlotRenderingInfo var58 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var59 = var16.initialise(var29, var30, var31, (org.jfree.data.category.CategoryDataset)var32, var58);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var3 = var2.getDistance();
    int var4 = var2.getDistance();
    var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
    float var6 = var0.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setDomainAxisLocation(10, var8, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var0.setRenderer(255, var12, false);
    java.awt.Paint var15 = var0.getDomainCrosshairPaint();
    java.awt.Paint var16 = var0.getRangeCrosshairPaint();
    var0.configureRangeAxes();
    org.jfree.chart.util.SortOrder var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setColumnRenderingOrder(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);

  }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("");
//     var4.setDatasetIndex(0);
//     java.awt.Paint var7 = var4.getFillPaint();
//     org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var7);
//     var1.setDefaultLabelPaint(var7);
//     org.jfree.chart.ChartColor var13 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var1.setDefaultFillPaint((java.awt.Paint)var13);
//     java.awt.Stroke var16 = var1.getSeriesStroke((-1));
//     org.jfree.chart.renderer.RenderAttributes var18 = new org.jfree.chart.renderer.RenderAttributes(true);
//     org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("");
//     var21.setDatasetIndex(0);
//     java.awt.Paint var24 = var21.getFillPaint();
//     org.jfree.data.KeyedObject var25 = new org.jfree.data.KeyedObject((java.lang.Comparable)(short)10, (java.lang.Object)var24);
//     var18.setDefaultLabelPaint(var24);
//     org.jfree.chart.ChartColor var30 = new org.jfree.chart.ChartColor(10, 1, 0);
//     var18.setDefaultFillPaint((java.awt.Paint)var30);
//     var1.setDefaultOutlinePaint((java.awt.Paint)var30);
//     
//     // Checks the contract:  equals-hashcode on var4 and var21
//     assertTrue("Contract failed: equals-hashcode on var4 and var21", var4.equals(var21) ? var4.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var4
//     assertTrue("Contract failed: equals-hashcode on var21 and var4", var21.equals(var4) ? var21.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var2 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var3 = var2.getDistance();
//     int var4 = var2.getDistance();
//     var0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var2);
//     float var6 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setDomainAxisLocation(10, var8, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
//     var0.setRenderer(255, var12, false);
//     java.awt.Paint var15 = var0.getDomainCrosshairPaint();
//     java.lang.String var16 = var0.getPlotType();
//     var0.clearDomainMarkers();
//     org.jfree.data.category.DefaultCategoryDataset var18 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var19 = var18.getRowCount();
//     var18.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var26 = var24.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var31 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var32 = var31.getUnitType();
//     var24.setTickLabelInsets(var31);
//     var24.setMinorTickMarkInsideLength(0.5f);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var37.setBaseShapesVisible(false);
//     java.awt.Paint var40 = var37.getBaseItemLabelPaint();
//     java.lang.Boolean var42 = var37.getSeriesShapesFilled(1);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var18, var24, var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.data.category.AbstractCategoryDataset var44 = new org.jfree.data.category.AbstractCategoryDataset();
//     org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var48 = var47.getOutlinePaint();
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("hi!", var48);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
//     var50.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var52 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var53 = var52.getDistance();
//     int var54 = var52.getDistance();
//     var50.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var52);
//     float var56 = var50.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var58 = null;
//     var50.setDomainAxisLocation(10, var58, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
//     var50.setRenderer(255, var62, false);
//     java.awt.Paint var65 = var50.getDomainCrosshairPaint();
//     boolean var66 = var49.equals((java.lang.Object)var50);
//     boolean var67 = var44.hasListener((java.util.EventListener)var50);
//     boolean var68 = var18.equals((java.lang.Object)var44);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var69 = var0.getRendererForDataset((org.jfree.data.category.CategoryDataset)var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var50
//     assertTrue("Contract failed: equals-hashcode on var0 and var50", var0.equals(var50) ? var0.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var0
//     assertTrue("Contract failed: equals-hashcode on var50 and var0", var50.equals(var0) ? var50.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    var0.setMaximumBarWidth(100.0d);
    var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var15 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var19 = var18.getAxisLinePaint();
    var17.setBaseItemLabelPaint(var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-264), var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    java.awt.Font var4 = null;
    var0.setLegendTextFont(5, var4);
    java.awt.Font var6 = null;
    var0.setBaseLegendTextFont(var6);
    var0.clearSeriesStrokes(false);
    java.awt.Paint var10 = var0.getBaseItemLabelPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var0.setBaseToolTipGenerator(var11, false);
    boolean var15 = var0.isSeriesVisible(4);
    org.jfree.chart.renderer.category.BarPainter var16 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
    var0.setBarPainter(var16);
    org.jfree.chart.util.DefaultShadowGenerator var19 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var20 = var19.getShadowColor();
    int var21 = var20.getAlpha();
    java.awt.Color var22 = var20.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-264), (java.awt.Paint)var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.setRangeCrosshairVisible(false);
//     var0.setCrosshairDatasetIndex(255, false);
//     boolean var6 = var0.canSelectByRegion();
//     org.jfree.chart.LegendItemCollection var7 = var0.getLegendItems();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.setRangeCrosshairVisible(false);
//     var9.setCrosshairDatasetIndex(255, false);
//     boolean var15 = var9.isRangeZoomable();
//     org.jfree.chart.axis.AxisLocation var16 = var9.getRangeAxisLocation();
//     var0.setDomainAxisLocation(0, var16, false);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var21 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var22 = var21.getDistance();
//     int var23 = var21.getDistance();
//     var19.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var21);
//     float var25 = var19.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var27 = null;
//     var19.setDomainAxisLocation(10, var27, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     var19.setRenderer(255, var31, false);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.setRangeCrosshairVisible(false);
//     var35.setCrosshairDatasetIndex(255, false);
//     org.jfree.chart.axis.AxisLocation var42 = var35.getRangeAxisLocation((-1));
//     var19.setDomainAxisLocation(100, var42, true);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.configureDomainAxes();
//     org.jfree.chart.util.DefaultShadowGenerator var47 = new org.jfree.chart.util.DefaultShadowGenerator();
//     int var48 = var47.getDistance();
//     int var49 = var47.getDistance();
//     var45.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var47);
//     float var51 = var45.getForegroundAlpha();
//     org.jfree.chart.axis.AxisLocation var53 = null;
//     var45.setDomainAxisLocation(10, var53, false);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var57 = null;
//     var45.setRenderer(255, var57, false);
//     java.awt.Paint var60 = var45.getDomainCrosshairPaint();
//     org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var63 = var61.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Font var65 = null;
//     var61.setLegendTextFont(5, var65);
//     java.awt.Font var67 = null;
//     var61.setBaseLegendTextFont(var67);
//     var61.clearSeriesStrokes(false);
//     int var71 = var45.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var61);
//     var61.setIncludeBaseInRange(false);
//     java.awt.Paint var74 = var61.getBaseItemLabelPaint();
//     boolean var76 = var61.isSeriesVisibleInLegend(10);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var77 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var61};
//     var19.setRenderers(var77);
//     var0.setRenderers(var77);
//     
//     // Checks the contract:  equals-hashcode on var9 and var35
//     assertTrue("Contract failed: equals-hashcode on var9 and var35", var9.equals(var35) ? var9.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var9
//     assertTrue("Contract failed: equals-hashcode on var35 and var9", var35.equals(var9) ? var35.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var0.setBaseItemLabelPaint((java.awt.Paint)var6, true);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    boolean var13 = var10.equals((java.lang.Object)var12);
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var10);
    java.awt.Paint var18 = var0.getItemOutlinePaint((-127), 100, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    var1.setURLText("");
    java.awt.Paint var6 = var1.getLabelPaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var9 = var8.getShape();
    var1.setShape(var9);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var14 = var13.getRowCount();
    var13.setValue((-9.21460183660255d), (java.lang.Comparable)(-16777216), (java.lang.Comparable)1);
    org.jfree.data.category.CategoryDatasetSelectionState var19 = var13.getSelectionState();
    org.jfree.chart.entity.CategoryItemEntity var22 = new org.jfree.chart.entity.CategoryItemEntity(var9, "org.jfree.chart.ChartColor[r=0,g=10,b=1]", "-4,-4,4,4", (org.jfree.data.category.CategoryDataset)var13, (java.lang.Comparable)"-4,-4,4,4", (java.lang.Comparable)10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var25 = var13.isSelected(255, 4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var1.setLinePaint((java.awt.Paint)var6);
    var1.setLineVisible(false);
    java.text.AttributedString var11 = var1.getAttributedLabel();
    org.jfree.data.general.Dataset var12 = var1.getDataset();
    var1.setSeriesIndex((-127));
    java.lang.Object var15 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    java.lang.Object var2 = var0.clone();
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.util.DefaultShadowGenerator var7 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var8 = var7.getShadowColor();
    int var9 = var8.getAlpha();
    java.awt.Color var10 = var8.darker();
    int var11 = var10.getGreen();
    java.awt.Color var12 = java.awt.Color.getColor("", var10);
    java.awt.Paint[] var13 = new java.awt.Paint[] { var10};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var15 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var18 = var17.getOutlinePaint();
    boolean var19 = var15.equals((java.lang.Object)var18);
    java.awt.Paint[] var20 = new java.awt.Paint[] { var18};
    org.jfree.chart.util.DefaultShadowGenerator var22 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var23 = var22.getShadowColor();
    int var24 = var23.getAlpha();
    java.awt.Color var25 = var23.darker();
    int var26 = var25.getGreen();
    java.awt.Color var27 = java.awt.Color.getColor("", var25);
    float[] var28 = null;
    float[] var29 = var27.getComponents(var28);
    java.awt.Paint[] var30 = new java.awt.Paint[] { var27};
    java.awt.Stroke var31 = null;
    java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
    java.awt.Stroke var33 = null;
    java.awt.Stroke[] var34 = new java.awt.Stroke[] { var33};
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var37 = null;
    var36.setOutlineStroke(var37);
    int var39 = var36.getSeriesIndex();
    java.awt.Stroke var40 = var36.getOutlineStroke();
    java.awt.Shape var41 = var36.getShape();
    java.awt.Shape[] var42 = new java.awt.Shape[] { var41};
    org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var13, var20, var30, var32, var34, var42);
    java.awt.Paint var44 = var43.getNextOutlinePaint();
    java.awt.Paint var45 = var43.getNextOutlinePaint();
    java.awt.Paint var46 = var43.getNextOutlinePaint();
    var0.setSeriesPaint(4, var46);
    var0.setBaseSeriesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    int var7 = var6.getAlpha();
    var1.setLinePaint((java.awt.Paint)var6);
    var1.setLineVisible(false);
    java.text.AttributedString var11 = var1.getAttributedLabel();
    org.jfree.data.general.Dataset var12 = var1.getDataset();
    boolean var13 = var1.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(2.0d, 1.0d, 0.2d, 0.0d);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    var0.setValue((java.lang.Number)(-1L), (java.lang.Comparable)1L, (java.lang.Comparable)(byte)1);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSelected(10, 3, false);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    var0.setMaximumBarWidth(100.0d);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.setRangeCrosshairVisible(false);
    var7.setCrosshairDatasetIndex(255, false);
    boolean var13 = var7.canSelectByRegion();
    var7.clearDomainMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = var7.getRenderer(0);
    java.awt.Stroke var17 = var7.getRangeCrosshairStroke();
    var0.setSeriesOutlineStroke(0, var17, true);
    java.awt.Font var21 = var0.lookupLegendTextFont(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    boolean var3 = var0.isRangeMinorGridlinesVisible();
    org.jfree.chart.LegendItem var5 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var6 = null;
    var5.setOutlineStroke(var6);
    int var8 = var5.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var9 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var10 = var9.getShadowColor();
    var5.setLinePaint((java.awt.Paint)var10);
    var0.setOutlinePaint((java.awt.Paint)var10);
    boolean var13 = var0.isOutlineVisible();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.configureDomainAxes();
    org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var18 = var17.getDistance();
    int var19 = var17.getDistance();
    var15.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var17);
    float var21 = var15.getForegroundAlpha();
    org.jfree.chart.axis.AxisLocation var23 = null;
    var15.setDomainAxisLocation(10, var23, false);
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    var15.setRenderer(255, var27, false);
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.setRangeCrosshairVisible(false);
    var31.setCrosshairDatasetIndex(255, false);
    org.jfree.chart.axis.AxisLocation var38 = var31.getRangeAxisLocation((-1));
    var15.setDomainAxisLocation(100, var38, true);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var43 = var41.getSeriesNegativeItemLabelPosition(0);
    var41.setShadowVisible(false);
    org.jfree.chart.util.DefaultShadowGenerator var46 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var47 = var46.getShadowColor();
    int var48 = var47.getAlpha();
    var41.setBaseItemLabelPaint((java.awt.Paint)var47, true);
    var41.setMaximumBarWidth(100.0d);
    boolean var53 = var41.getBaseSeriesVisible();
    boolean var54 = var38.equals((java.lang.Object)var41);
    org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var60 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var62 = var60.trimWidth(0.0d);
    double var64 = var60.trimWidth(109.21460183660255d);
    boolean var66 = var60.equals((java.lang.Object)"hi!");
    var55.setInsets(var60, true);
    int var69 = var55.getDomainAxisCount();
    int var70 = var55.getBackgroundImageAlignment();
    org.jfree.chart.util.RectangleInsets var71 = var55.getAxisOffset();
    org.jfree.chart.plot.Marker var72 = null;
    boolean var73 = var55.removeDomainMarker(var72);
    org.jfree.chart.plot.PlotOrientation var74 = var55.getOrientation();
    java.lang.String var75 = var74.toString();
    org.jfree.chart.util.RectangleEdge var76 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var38, var74);
    java.lang.String var77 = var38.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-16777215), var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var75.equals("PlotOrientation.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var77 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT"+ "'", var77.equals("AxisLocation.BOTTOM_OR_RIGHT"));

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var5 = var4.getUnitType();
    java.lang.String var6 = var5.toString();
    java.lang.Object var7 = null;
    boolean var8 = var5.equals(var7);
    java.lang.String var9 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "UnitType.ABSOLUTE"+ "'", var6.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "UnitType.ABSOLUTE"+ "'", var9.equals("UnitType.ABSOLUTE"));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject((java.lang.Comparable)'#');
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    var0.setCrosshairDatasetIndex(255, false);
    boolean var6 = var0.canSelectByRegion();
    org.jfree.chart.util.DefaultShadowGenerator var8 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var9 = var8.getShadowColor();
    int var10 = var9.getAlpha();
    java.awt.Color var11 = var9.darker();
    int var12 = var11.getGreen();
    java.awt.Color var13 = java.awt.Color.getColor("", var11);
    java.awt.Paint[] var14 = new java.awt.Paint[] { var11};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var19 = var18.getOutlinePaint();
    boolean var20 = var16.equals((java.lang.Object)var19);
    java.awt.Paint[] var21 = new java.awt.Paint[] { var19};
    org.jfree.chart.util.DefaultShadowGenerator var23 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var24 = var23.getShadowColor();
    int var25 = var24.getAlpha();
    java.awt.Color var26 = var24.darker();
    int var27 = var26.getGreen();
    java.awt.Color var28 = java.awt.Color.getColor("", var26);
    float[] var29 = null;
    float[] var30 = var28.getComponents(var29);
    java.awt.Paint[] var31 = new java.awt.Paint[] { var28};
    java.awt.Stroke var32 = null;
    java.awt.Stroke[] var33 = new java.awt.Stroke[] { var32};
    java.awt.Stroke var34 = null;
    java.awt.Stroke[] var35 = new java.awt.Stroke[] { var34};
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var38 = null;
    var37.setOutlineStroke(var38);
    int var40 = var37.getSeriesIndex();
    java.awt.Stroke var41 = var37.getOutlineStroke();
    java.awt.Shape var42 = var37.getShape();
    java.awt.Shape[] var43 = new java.awt.Shape[] { var42};
    org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var21, var31, var33, var35, var43);
    java.awt.Stroke var45 = var44.getNextOutlineStroke();
    java.awt.Paint var46 = var44.getNextPaint();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var44, true);
    java.awt.Paint var49 = var44.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    int var4 = var1.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var5 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var6 = var5.getShadowColor();
    var1.setLinePaint((java.awt.Paint)var6);
    java.lang.Object var8 = null;
    boolean var9 = var1.equals(var8);
    java.awt.Paint var10 = var1.getFillPaint();
    org.jfree.chart.util.GradientPaintTransformer var11 = var1.getFillPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", var1);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var7 = var6.getShape();
    org.jfree.chart.JFreeChart var8 = null;
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var7, var8);
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var12 = null;
    var11.setOutlineStroke(var12);
    int var14 = var11.getSeriesIndex();
    java.awt.Stroke var15 = var11.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var17 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var18 = var17.getShadowColor();
    int var19 = var18.getAlpha();
    java.awt.Color var20 = var18.darker();
    int var21 = var20.getGreen();
    java.awt.Color var22 = java.awt.Color.getColor("", var20);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var7, var15, (java.awt.Paint)var20);
    var0.setBaseFillPaint((java.awt.Paint)var20, true);
    var0.setDrawOutlines(false);
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
    var30.setDatasetIndex(0);
    java.awt.Shape var33 = var30.getShape();
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var33, "");
    java.awt.Shape var36 = var35.getArea();
    org.jfree.chart.labels.ItemLabelPosition var37 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.text.TextAnchor var38 = var37.getRotationAnchor();
    org.jfree.chart.labels.ItemLabelAnchor var39 = var37.getItemLabelAnchor();
    boolean var40 = var35.equals((java.lang.Object)var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-16777215), var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    java.lang.Object var3 = var1.get(1);
    int var4 = var1.size();
    org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var7 = null;
    var6.setOutlineStroke(var7);
    int var9 = var6.getSeriesIndex();
    org.jfree.chart.util.DefaultShadowGenerator var10 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var11 = var10.getShadowColor();
    var6.setLinePaint((java.awt.Paint)var11);
    org.jfree.data.category.AbstractCategoryDataset var13 = new org.jfree.data.category.AbstractCategoryDataset();
    var6.setDataset((org.jfree.data.general.Dataset)var13);
    org.jfree.chart.event.DatasetChangeInfo var15 = new org.jfree.chart.event.DatasetChangeInfo();
    org.jfree.data.event.DatasetChangeEvent var16 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object)var1, (org.jfree.data.general.Dataset)var13, var15);
    java.util.EventListener var17 = null;
    boolean var18 = var13.hasListener(var17);
    org.jfree.data.category.CategoryDatasetSelectionState var19 = var13.getSelectionState();
    java.lang.Object var20 = var13.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.util.List var1 = var0.getKeys();
    int var3 = var0.getIndex((java.lang.Comparable)(short)100);
    var0.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var2 = var1.getShadowColor();
//     int var3 = var2.getAlpha();
//     java.awt.Color var4 = var2.darker();
//     int var5 = var4.getGreen();
//     java.awt.Color var6 = java.awt.Color.getColor("", var4);
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var4};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var12 = var11.getOutlinePaint();
//     boolean var13 = var9.equals((java.lang.Object)var12);
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
//     org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var17 = var16.getShadowColor();
//     int var18 = var17.getAlpha();
//     java.awt.Color var19 = var17.darker();
//     int var20 = var19.getGreen();
//     java.awt.Color var21 = java.awt.Color.getColor("", var19);
//     float[] var22 = null;
//     float[] var23 = var21.getComponents(var22);
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var21};
//     java.awt.Stroke var25 = null;
//     java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var31 = null;
//     var30.setOutlineStroke(var31);
//     int var33 = var30.getSeriesIndex();
//     java.awt.Stroke var34 = var30.getOutlineStroke();
//     java.awt.Shape var35 = var30.getShape();
//     java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
//     org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var14, var24, var26, var28, var36);
//     org.jfree.chart.util.DefaultShadowGenerator var39 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var40 = var39.getShadowColor();
//     int var41 = var40.getAlpha();
//     java.awt.Color var42 = var40.darker();
//     int var43 = var42.getGreen();
//     java.awt.Color var44 = java.awt.Color.getColor("", var42);
//     java.awt.Paint[] var45 = new java.awt.Paint[] { var42};
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var47 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("");
//     java.awt.Paint var50 = var49.getOutlinePaint();
//     boolean var51 = var47.equals((java.lang.Object)var50);
//     java.awt.Paint[] var52 = new java.awt.Paint[] { var50};
//     org.jfree.chart.util.DefaultShadowGenerator var54 = new org.jfree.chart.util.DefaultShadowGenerator();
//     java.awt.Color var55 = var54.getShadowColor();
//     int var56 = var55.getAlpha();
//     java.awt.Color var57 = var55.darker();
//     int var58 = var57.getGreen();
//     java.awt.Color var59 = java.awt.Color.getColor("", var57);
//     float[] var60 = null;
//     float[] var61 = var59.getComponents(var60);
//     java.awt.Paint[] var62 = new java.awt.Paint[] { var59};
//     java.awt.Stroke var63 = null;
//     java.awt.Stroke[] var64 = new java.awt.Stroke[] { var63};
//     java.awt.Stroke var65 = null;
//     java.awt.Stroke[] var66 = new java.awt.Stroke[] { var65};
//     org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var69 = null;
//     var68.setOutlineStroke(var69);
//     int var71 = var68.getSeriesIndex();
//     java.awt.Stroke var72 = var68.getOutlineStroke();
//     java.awt.Shape var73 = var68.getShape();
//     java.awt.Shape[] var74 = new java.awt.Shape[] { var73};
//     org.jfree.chart.plot.DefaultDrawingSupplier var75 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var52, var62, var64, var66, var74);
//     java.awt.Stroke[] var76 = null;
//     org.jfree.chart.renderer.category.BarRenderer var77 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var79 = var77.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var80 = var77.getBaseItemLabelGenerator();
//     java.awt.Color var85 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
//     var77.setSeriesItemLabelPaint(1, (java.awt.Paint)var85, false);
//     java.awt.Stroke var88 = var77.getBaseOutlineStroke();
//     java.awt.Stroke[] var89 = new java.awt.Stroke[] { var88};
//     org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem("");
//     var91.setDatasetIndex(0);
//     java.awt.Shape var94 = var91.getShape();
//     java.awt.Shape[] var95 = new java.awt.Shape[] { var94};
//     org.jfree.chart.plot.DefaultDrawingSupplier var96 = new org.jfree.chart.plot.DefaultDrawingSupplier(var14, var45, var76, var89, var95);
//     
//     // Checks the contract:  equals-hashcode on var11 and var49
//     assertTrue("Contract failed: equals-hashcode on var11 and var49", var11.equals(var49) ? var11.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var91
//     assertTrue("Contract failed: equals-hashcode on var11 and var91", var11.equals(var91) ? var11.hashCode() == var91.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var11
//     assertTrue("Contract failed: equals-hashcode on var49 and var11", var49.equals(var11) ? var49.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var91
//     assertTrue("Contract failed: equals-hashcode on var49 and var91", var49.equals(var91) ? var49.hashCode() == var91.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var91 and var11
//     assertTrue("Contract failed: equals-hashcode on var91 and var11", var91.equals(var11) ? var91.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var91 and var49
//     assertTrue("Contract failed: equals-hashcode on var91 and var49", var91.equals(var49) ? var91.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var75
//     assertTrue("Contract failed: equals-hashcode on var37 and var75", var37.equals(var75) ? var37.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var37
//     assertTrue("Contract failed: equals-hashcode on var75 and var37", var75.equals(var37) ? var75.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.chart.util.DefaultShadowGenerator var1 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var2 = var1.getShadowColor();
    int var3 = var2.getAlpha();
    java.awt.Color var4 = var2.darker();
    int var5 = var4.getGreen();
    java.awt.Color var6 = java.awt.Color.getColor("", var4);
    java.awt.Paint[] var7 = new java.awt.Paint[] { var4};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var9 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var12 = var11.getOutlinePaint();
    boolean var13 = var9.equals((java.lang.Object)var12);
    java.awt.Paint[] var14 = new java.awt.Paint[] { var12};
    org.jfree.chart.util.DefaultShadowGenerator var16 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var17 = var16.getShadowColor();
    int var18 = var17.getAlpha();
    java.awt.Color var19 = var17.darker();
    int var20 = var19.getGreen();
    java.awt.Color var21 = java.awt.Color.getColor("", var19);
    float[] var22 = null;
    float[] var23 = var21.getComponents(var22);
    java.awt.Paint[] var24 = new java.awt.Paint[] { var21};
    java.awt.Stroke var25 = null;
    java.awt.Stroke[] var26 = new java.awt.Stroke[] { var25};
    java.awt.Stroke var27 = null;
    java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var31 = null;
    var30.setOutlineStroke(var31);
    int var33 = var30.getSeriesIndex();
    java.awt.Stroke var34 = var30.getOutlineStroke();
    java.awt.Shape var35 = var30.getShape();
    java.awt.Shape[] var36 = new java.awt.Shape[] { var35};
    org.jfree.chart.plot.DefaultDrawingSupplier var37 = new org.jfree.chart.plot.DefaultDrawingSupplier(var7, var14, var24, var26, var28, var36);
    java.awt.Paint var38 = var37.getNextOutlinePaint();
    java.awt.Paint var39 = var37.getNextOutlinePaint();
    java.awt.Paint var40 = var37.getNextOutlinePaint();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var43 = var41.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var49 = var48.getUnitType();
    var41.setTickLabelInsets(var48);
    org.jfree.chart.util.RectangleInsets var55 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var57 = var55.trimWidth(0.0d);
    double var59 = var55.calculateTopInset(0.0d);
    double var61 = var55.extendWidth(100.0d);
    java.lang.String var62 = var55.toString();
    var41.setLabelInsets(var55);
    org.jfree.chart.plot.Plot var64 = var41.getPlot();
    org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
    var65.setRangeCrosshairVisible(false);
    var65.clearSelection();
    org.jfree.chart.util.SortOrder var69 = var65.getColumnRenderingOrder();
    var41.addChangeListener((org.jfree.chart.event.AxisChangeListener)var65);
    var41.setFixedDimension(1.0d);
    org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
    var73.setRangeCrosshairVisible(false);
    var73.setCrosshairDatasetIndex(255, false);
    boolean var79 = var73.canSelectByRegion();
    var73.clearDomainMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var82 = var73.getRenderer(0);
    java.awt.Stroke var83 = var73.getRangeCrosshairStroke();
    boolean var84 = var41.hasListener((java.util.EventListener)var73);
    org.jfree.chart.util.Layer var85 = null;
    java.util.Collection var86 = var73.getDomainMarkers(var85);
    org.jfree.chart.axis.AxisSpace var87 = var73.getFixedDomainAxisSpace();
    boolean var88 = var37.equals((java.lang.Object)var73);
    org.jfree.chart.axis.AxisSpace var89 = null;
    var73.setFixedDomainAxisSpace(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 109.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"+ "'", var62.equals("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var1 = var0.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var2 = var0.getItemLabelAnchor();
//     java.lang.String var3 = var2.toString();
//     boolean var5 = var2.equals((java.lang.Object)"org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     org.jfree.chart.labels.ItemLabelPosition var6 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
//     org.jfree.chart.labels.ItemLabelAnchor var8 = var6.getItemLabelAnchor();
//     org.jfree.chart.text.TextAnchor var9 = var6.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var11 = var10.getTextAnchor();
//     org.jfree.chart.labels.ItemLabelPosition var13 = new org.jfree.chart.labels.ItemLabelPosition(var2, var9, var11, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var10
//     assertTrue("Contract failed: equals-hashcode on var6 and var10", var6.equals(var10) ? var6.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var6
//     assertTrue("Contract failed: equals-hashcode on var10 and var6", var10.equals(var6) ? var10.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 1.0f, 0.0f);
    int var4 = var3.getRGB();
    int var5 = var3.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE12");
//     org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("");
//     java.awt.Stroke var4 = null;
//     var3.setOutlineStroke(var4);
//     var3.setURLText("");
//     var3.setToolTipText("hi!");
//     boolean var10 = var1.equals((java.lang.Object)var3);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var16 = var15.getFixedRangeAxisSpace();
//     var15.setWeight(10);
//     org.jfree.data.category.CategoryDataset var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = var15.getRendererForDataset(var19);
//     org.jfree.chart.axis.AxisLocation var22 = var15.getDomainAxisLocation(100);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var30 = var28.trimWidth(0.0d);
//     double var32 = var28.trimWidth(109.21460183660255d);
//     boolean var34 = var28.equals((java.lang.Object)"hi!");
//     var23.setInsets(var28, true);
//     int var37 = var23.getDomainAxisCount();
//     int var38 = var23.getBackgroundImageAlignment();
//     org.jfree.chart.util.RectangleInsets var39 = var23.getAxisOffset();
//     org.jfree.chart.plot.Marker var40 = null;
//     boolean var41 = var23.removeDomainMarker(var40);
//     org.jfree.chart.plot.PlotOrientation var42 = var23.getOrientation();
//     java.lang.String var43 = var42.toString();
//     java.lang.String var44 = var42.toString();
//     org.jfree.chart.util.RectangleEdge var45 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var22, var42);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     org.jfree.chart.axis.AxisState var47 = var1.draw(var11, 1.0d, var13, var14, var45, var46);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setRangeCrosshairVisible(false);
    org.jfree.chart.plot.CategoryMarker var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    java.lang.Object var2 = var0.clone();
    java.awt.Stroke var3 = var0.getRangeGridlineStroke();
    var0.setRangeCrosshairLockedOnData(false);
    var0.setRangeCrosshairValue(0.0d, true);
    java.lang.String var9 = var0.getNoDataMessage();
    var0.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    var0.setShadowVisible(false);
    org.jfree.chart.ChartColor var8 = new org.jfree.chart.ChartColor(0, 10, 1);
    java.lang.String var9 = var8.toString();
    int var10 = var8.getAlpha();
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var8.createContext(var11, var12, var13, var14, var15);
    var0.setShadowPaint((java.awt.Paint)var8);
    double var18 = var0.getItemMargin();
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.renderer.RenderAttributes var22 = new org.jfree.chart.renderer.RenderAttributes(true);
    java.awt.Paint var25 = var22.getItemPaint(255, 100);
    java.awt.Color var28 = java.awt.Color.getColor("", 1);
    var22.setDefaultLabelPaint((java.awt.Paint)var28);
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("");
    java.awt.Shape var37 = var36.getShape();
    org.jfree.chart.JFreeChart var38 = null;
    org.jfree.chart.event.ChartChangeEvent var39 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var37, var38);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var42 = null;
    var41.setOutlineStroke(var42);
    int var44 = var41.getSeriesIndex();
    java.awt.Stroke var45 = var41.getLineStroke();
    org.jfree.chart.util.DefaultShadowGenerator var47 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var48 = var47.getShadowColor();
    int var49 = var48.getAlpha();
    java.awt.Color var50 = var48.darker();
    int var51 = var50.getGreen();
    java.awt.Color var52 = java.awt.Color.getColor("", var50);
    org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]", "", "", "org.jfree.chart.ChartColor[r=0,g=10,b=1]", var37, var45, (java.awt.Paint)var50);
    var22.setSeriesShape(0, var37);
    var0.setBaseShape(var37, true);
    java.awt.Paint var58 = var0.lookupSeriesPaint((-1));
    java.awt.Stroke var62 = var0.getItemStroke(3, 10, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var63 = var0.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.ChartColor[r=0,g=10,b=1]"+ "'", var9.equals("org.jfree.chart.ChartColor[r=0,g=10,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
//     org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
//     org.jfree.chart.util.UnitType var8 = var7.getUnitType();
//     var0.setTickLabelInsets(var7);
//     var0.setMinorTickMarkInsideLength(0.5f);
//     double var12 = var0.getLabelAngle();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.AxisState var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.axis.AxisSpace var17 = var16.getFixedRangeAxisSpace();
//     var16.setWeight(10);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = var16.getRendererForDataset(var20);
//     org.jfree.chart.axis.AxisLocation var23 = var16.getDomainAxisLocation(100);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
//     double var31 = var29.trimWidth(0.0d);
//     double var33 = var29.trimWidth(109.21460183660255d);
//     boolean var35 = var29.equals((java.lang.Object)"hi!");
//     var24.setInsets(var29, true);
//     int var38 = var24.getDomainAxisCount();
//     int var39 = var24.getBackgroundImageAlignment();
//     org.jfree.chart.util.RectangleInsets var40 = var24.getAxisOffset();
//     org.jfree.chart.plot.Marker var41 = null;
//     boolean var42 = var24.removeDomainMarker(var41);
//     org.jfree.chart.plot.PlotOrientation var43 = var24.getOrientation();
//     java.lang.String var44 = var43.toString();
//     java.lang.String var45 = var43.toString();
//     org.jfree.chart.util.RectangleEdge var46 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var23, var43);
//     java.util.List var47 = var0.refreshTicks(var13, var14, var15, var46);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.configureDomainAxes();
    var0.setAnchorValue(10.0d, true);
    org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxisForDataset(5);
    org.jfree.chart.axis.ValueAxis var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var0.getRangeAxisIndex(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets((-1.0d), (-9.21460183660255d), (-108.42920367320511d), 109.21460183660255d);
    org.jfree.chart.util.UnitType var8 = var7.getUnitType();
    var0.setTickLabelInsets(var7);
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets((-0.7853981633974483d), 10.0d, 100.0d, (-0.7853981633974483d));
    double var16 = var14.trimWidth(0.0d);
    double var18 = var14.calculateTopInset(0.0d);
    double var20 = var14.extendWidth(100.0d);
    java.lang.String var21 = var14.toString();
    var0.setLabelInsets(var14);
    org.jfree.chart.util.DefaultShadowGenerator var24 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var25 = var24.getShadowColor();
    int var26 = var25.getAlpha();
    java.awt.Color var27 = var25.darker();
    int var28 = var27.getGreen();
    java.awt.Color var29 = java.awt.Color.getColor("", var27);
    java.awt.Paint[] var30 = new java.awt.Paint[] { var27};
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var32 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.chart.ChartColor[r=0,g=10,b=1]");
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("");
    java.awt.Paint var35 = var34.getOutlinePaint();
    boolean var36 = var32.equals((java.lang.Object)var35);
    java.awt.Paint[] var37 = new java.awt.Paint[] { var35};
    org.jfree.chart.util.DefaultShadowGenerator var39 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var40 = var39.getShadowColor();
    int var41 = var40.getAlpha();
    java.awt.Color var42 = var40.darker();
    int var43 = var42.getGreen();
    java.awt.Color var44 = java.awt.Color.getColor("", var42);
    float[] var45 = null;
    float[] var46 = var44.getComponents(var45);
    java.awt.Paint[] var47 = new java.awt.Paint[] { var44};
    java.awt.Stroke var48 = null;
    java.awt.Stroke[] var49 = new java.awt.Stroke[] { var48};
    java.awt.Stroke var50 = null;
    java.awt.Stroke[] var51 = new java.awt.Stroke[] { var50};
    org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("");
    java.awt.Stroke var54 = null;
    var53.setOutlineStroke(var54);
    int var56 = var53.getSeriesIndex();
    java.awt.Stroke var57 = var53.getOutlineStroke();
    java.awt.Shape var58 = var53.getShape();
    java.awt.Shape[] var59 = new java.awt.Shape[] { var58};
    org.jfree.chart.plot.DefaultDrawingSupplier var60 = new org.jfree.chart.plot.DefaultDrawingSupplier(var30, var37, var47, var49, var51, var59);
    java.awt.Stroke var61 = var60.getNextOutlineStroke();
    java.awt.Paint var62 = var60.getNextPaint();
    java.awt.Paint var63 = var60.getNextFillPaint();
    var0.setTickLabelPaint(var63);
    var0.setMinorTickMarkInsideLength(0.5f);
    double var67 = var0.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-9.21460183660255d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-0.7853981633974483d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 109.21460183660255d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"+ "'", var21.equals("RectangleInsets[t=-0.7853981633974483,l=10.0,b=100.0,r=-0.7853981633974483]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0.05d);

  }

}
