
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnitType var2 = null;
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(var0, 100, var2, 0, var4);
// 
//   }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(short)0, "hi!", var2, var3, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.RectangleInsets var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setInsets(var1, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 10);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     org.jfree.data.time.RegularTimePeriod var1 = null;
//     org.jfree.data.time.RegularTimePeriod var2 = null;
//     org.jfree.chart.axis.PeriodAxis var3 = new org.jfree.chart.axis.PeriodAxis("", var1, var2);
// 
//   }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 10.0f, 10.0f, var4, 1.0d, var6);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    int var2 = var0.getWeight();
    boolean var3 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-1), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.setLabel("hi!");
    java.awt.Font var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelFont(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = null;
    var0.setTimeline(var1);
    java.awt.Shape var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLeftArrow(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, (-1), (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.data.xy.XYDataset var0 = null;
    java.util.List var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var1, var2, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("hi!", "", "ThreadContext", "");

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var3 = null;
//     var2.setTimeline(var3);
//     var0.setDomainAxis((-460), (org.jfree.chart.axis.ValueAxis)var2, false);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(short)(-1), "hi!", var2, var3, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    java.awt.Paint var3 = var1.getDomainCrosshairPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(var0, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Size2D[width=0.0, height=0.0]", var1, 100.0f, 10.0f, (-1.0d), (-1.0f), 10.0f);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     var3.setMinorTickMarkInsideLength(0.0f);
//     int var6 = var1.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var3);
//     org.jfree.data.Range var7 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getYValue(0, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getInstance(var0);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.title.Title var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var2 = new org.jfree.chart.entity.TitleEntity(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     int var4 = var0.getBackgroundImageAlignment();
//     var0.setRangeCrosshairValue((-1.0d));
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     org.jfree.chart.plot.PlotState var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.draw(var7, var8, var9, var10, var11);
// 
//   }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.setLabel("hi!");
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    var0.setHeight(100.0d);
    var0.setWidth(100.0d);
    java.lang.String var5 = var0.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Size2D[width=100.0, height=100.0]"+ "'", var5.equals("Size2D[width=100.0, height=100.0]"));

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var1.setSeriesStroke(10, var4);
    java.io.ObjectOutputStream var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var4, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    var2.setMinorTickMarkInsideLength(0.0f);
    int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
    org.jfree.chart.annotations.XYAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getStartY(15, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     java.awt.Paint var6 = var4.getDomainCrosshairPaint();
//     var0.setRangeGridlinePaint(var6);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var0.drawBackground(var8, var9);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var1.setSeriesStroke(10, var4);
    boolean var6 = var1.getShapesVisible();
    var1.setBaseSeriesVisibleInLegend(false, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.getEndYValue(1, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("ThreadContext", var1, (-1.0f), 10.0f, var4, 100.0d, 0.0f, 100.0f);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    var2.setMinorTickMarkInsideLength(0.0f);
    int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setAutoRangeMinimumSize((-1.0d), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 1.0d, "Size2D[width=100.0, height=100.0]", var3, var4, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     java.awt.Paint var6 = var4.getDomainCrosshairPaint();
//     var0.setRangeGridlinePaint(var6);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var0.drawBackground(var8, var9);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("Size2D[width=0.0, height=0.0]", "ThreadContext", "", var3, "", "ThreadContext", "ThreadContext");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var1.setSeriesStroke(10, var4);
    org.jfree.chart.labels.ItemLabelPosition var7 = var1.getSeriesNegativeItemLabelPosition((-460));
    java.awt.Font var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseItemLabelFont(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getSeriesKey((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    org.jfree.data.xy.XYDataItem var5 = var2.addOrUpdate((java.lang.Number)(short)10, (java.lang.Number)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     var6.setLabel("hi!");
//     double var9 = var6.getUpperBound();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     var0.drawItem(var1, var2, var3, var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var10, 1, (-1), true, (-1));
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.util.List var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var0, var1, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var4.removeDomainMarker(10, var7, var8);
    java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("hi!", var1, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Size2D[width=100.0, height=100.0]", var1, var2);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = var1.getSurroundingItems(10, 1L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3);
//     boolean var5 = var0.isSubplot();
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var7 = null;
//     var6.setTimeline(var7);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var10 = var9.getDomainZeroBaselineStroke();
//     var6.setAxisLineStroke(var10);
//     int var12 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.util.RectangleEdge var6 = null;
//     double var7 = var0.getItemMiddle((java.lang.Comparable)'#', (java.lang.Comparable)1, var3, var4, var5, var6);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var4.removeDomainMarker(10, var7, var8);
    java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var13 = new org.jfree.chart.text.TextFragment("", var1, var10, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getY(0, 12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var3 = var2.getLabelPaint();
//     org.jfree.chart.block.LabelBlock var4 = new org.jfree.chart.block.LabelBlock("", var1, var3);
//     
//     // Checks the contract:  var4.equals(var4)
//     assertTrue("Contract failed: var4.equals(var4)", var4.equals(var4));
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100, 100, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=0.0, height=0.0]", var1, 10.0f, 1.0f, 10.0d, 1.0f, 100.0f);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var0.getXValue(12, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    java.awt.Shape var3 = null;
    var1.setLegendShape(10, var3);
    var1.setShapesVisible(true);
    org.jfree.chart.labels.XYItemLabelGenerator var7 = null;
    var1.setBaseItemLabelGenerator(var7);
    java.awt.Font var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesItemLabelFont((-460), var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)10.0d);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Size2D[width=0.0, height=0.0]", var1);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    java.awt.Shape var3 = null;
    var1.setLegendShape(10, var3);
    var1.setShapesVisible(true);
    java.awt.Font var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseItemLabelFont(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance(var0);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.LegendItemCollection var3 = var1.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var4.java2DToValue(0.0d, var6, var7);
    java.awt.Shape var9 = var4.getRightArrow();
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
    int var12 = var10.getWeight();
    boolean var13 = var10.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
    java.awt.Paint var16 = var14.getDomainCrosshairPaint();
    var10.setRangeGridlinePaint(var16);
    java.awt.Stroke var18 = null;
    java.awt.Paint var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem(var0, "", "Size2D[width=0.0, height=0.0]", "Size2D[width=100.0, height=100.0]", var9, var16, var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

//  public void test76() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var0.drawOutline(var16, var17, var18);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getFollowingDayOfWeek(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.java2DToValue(0.0d, var2, var3);
    java.awt.Shape var5 = var0.getRightArrow();
    org.jfree.chart.JFreeChart var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var7 = new org.jfree.chart.entity.JFreeChartEntity(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    var2.setMinorTickMarkInsideLength(0.0f);
    int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
    org.jfree.data.general.SeriesChangeInfo var17 = null;
    org.jfree.data.general.SeriesChangeEvent var18 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var0, var17);
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var23 = var22.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var25 = null;
    org.jfree.chart.util.Layer var26 = null;
    boolean var27 = var22.removeDomainMarker(10, var25, var26);
    java.awt.Paint var28 = var22.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var28);
    org.jfree.chart.util.Layer var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(15, (org.jfree.chart.plot.Marker)var29, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    float[] var3 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = java.awt.Color.RGBtoHSB(1, 10, 0, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     var0.drawOutline(var6, var7);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var20 = var19.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var22 = null;
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var19.removeDomainMarker(10, var22, var23);
//     java.awt.Paint var25 = var19.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var25);
//     var16.setItemPaint(var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(10);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var4 = null;
    var3.setTimeline(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.set((-460), (java.lang.Object)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Size2D[width=0.0, height=0.0]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Size2D[width=0.0, height=0.0]");

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    boolean var5 = var0.removeDomainMarker(10, var3, var4);
    java.awt.Paint var6 = var0.getDomainMinorGridlinePaint();
    org.jfree.chart.axis.AxisLocation var8 = null;
    var0.setRangeAxisLocation(100, var8, false);
    org.jfree.chart.axis.AxisLocation var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(0, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    java.awt.Shape var3 = null;
    var1.setLegendShape(10, var3);
    org.jfree.chart.labels.ItemLabelPosition var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseNegativeItemLabelPosition(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     double var6 = var5.getStartAngle();
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     org.jfree.chart.plot.PiePlotState var9 = var1.initialise(var2, var3, var5, (java.lang.Integer)1, var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-460), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setDomainCrosshairVisible(true);
    var0.setRangeCrosshairVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var10 = var0.getQuadrantPaint(4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, var2);
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var5 = null;
    var4.setTimeline(var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    var4.setAxisLineStroke(var8);
    var3.setBaseStroke(var8, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setSeriesItemLabelsVisible((-460), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     boolean var18 = var10.equals((java.lang.Object)var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=100.0, height=100.0]", var1, 0.0f, 1.0f, var8, 90.0d, 0.0f, 10.0f);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     double var2 = var1.getStartAngle();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Point2D var5 = null;
//     org.jfree.chart.plot.PlotState var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var1.draw(var3, var4, var5, var6, var7);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var5 = var1.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    int var7 = var6.getDatasetCount();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.setMinorTickMarkInsideLength(0.0f);
    int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
    org.jfree.chart.util.VerticalAlignment var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setVerticalAlignment(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var1.setSeriesStroke(10, var4);
//     org.jfree.chart.labels.XYItemLabelGenerator var7 = null;
//     var1.setSeriesItemLabelGenerator(1, var7);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
//     java.awt.Paint var12 = var10.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var13 = null;
//     var10.axisChanged(var13);
//     java.awt.Image var15 = null;
//     var10.setBackgroundImage(var15);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     java.awt.Paint var19 = var17.getDomainCrosshairPaint();
//     var10.setDomainZeroBaselinePaint(var19);
//     java.awt.Paint var21 = var10.getDomainGridlinePaint();
//     var1.setSeriesFillPaint(15, var21);
//     
//     // Checks the contract:  equals-hashcode on var3 and var17
//     assertTrue("Contract failed: equals-hashcode on var3 and var17", var3.equals(var17) ? var3.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var3
//     assertTrue("Contract failed: equals-hashcode on var17 and var3", var17.equals(var3) ? var17.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     var0.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var27 = var0.initialise(var22, var23, var24, (-1), var26);
// 
//   }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var3.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var6 = var5.getRotationAnchor();
//     var1.setLabelTextAnchor(var6);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     java.awt.Paint var10 = var9.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var16 = var15.getDomainZeroBaselineStroke();
//     var13.setSeriesStroke(10, var16);
//     boolean var18 = var13.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var19 = var13.getBasePositiveItemLabelPosition();
//     java.awt.Paint var21 = var13.lookupSeriesOutlinePaint(0);
//     var9.setSectionPaint((java.lang.Comparable)true, var21);
//     org.jfree.chart.util.RectangleInsets var23 = var9.getLabelPadding();
//     var1.setLabelOffset(var23);
//     
//     // Checks the contract:  equals-hashcode on var3 and var13
//     assertTrue("Contract failed: equals-hashcode on var3 and var13", var3.equals(var13) ? var3.hashCode() == var13.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var3 and var13.", var3.equals(var13) == var13.equals(var3));
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
    var2.setLabelTextAnchor(var7);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var13 = var12.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition(var0, var7, var13, 90.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    boolean var3 = var0.isDomainGridlinesVisible();
    org.jfree.chart.LegendItemCollection var4 = var0.getFixedLegendItems();
    org.jfree.chart.annotations.XYAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var5 = var1.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    int var7 = var6.getDatasetCount();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.setMinorTickMarkInsideLength(0.0f);
    int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
    org.jfree.chart.entity.ChartEntity var24 = new org.jfree.chart.entity.ChartEntity(var5);
    org.jfree.chart.axis.Axis var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisEntity var27 = new org.jfree.chart.entity.AxisEntity(var5, var25, "Size2D[width=0.0, height=0.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var22 = var18.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     int var24 = var23.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     var25.setMinorTickMarkInsideLength(0.0f);
//     int var28 = var23.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement(var34, var35, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var38);
//     org.jfree.chart.entity.TitleEntity var40 = new org.jfree.chart.entity.TitleEntity(var22, (org.jfree.chart.title.Title)var39);
//     org.jfree.chart.LegendItemSource[] var41 = var39.getSources();
//     var16.setSources(var41);
//     
//     // Checks the contract:  equals-hashcode on var0 and var23
//     assertTrue("Contract failed: equals-hashcode on var0 and var23", var0.equals(var23) ? var0.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var0
//     assertTrue("Contract failed: equals-hashcode on var23 and var0", var23.equals(var0) ? var23.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var33
//     assertTrue("Contract failed: equals-hashcode on var10 and var33", var10.equals(var33) ? var10.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var10
//     assertTrue("Contract failed: equals-hashcode on var33 and var10", var33.equals(var10) ? var33.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var38
//     assertTrue("Contract failed: equals-hashcode on var15 and var38", var15.equals(var38) ? var15.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var15
//     assertTrue("Contract failed: equals-hashcode on var38 and var15", var38.equals(var15) ? var38.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, var2);
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var5 = null;
    var4.setTimeline(var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    var4.setAxisLineStroke(var8);
    var3.setBaseStroke(var8, false);
    org.jfree.chart.util.GradientPaintTransformer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setGradientTransformer(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     java.awt.Paint var16 = var1.getAxisLabelPaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var19 = var18.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var18.setDomainAxisLocation(1, var21);
//     boolean var23 = var18.isSubplot();
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     var25.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var28 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var25.setStandardTickUnits(var28);
//     var18.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var25, true);
//     boolean var32 = var17.hasListener((java.util.EventListener)var18);
//     org.jfree.chart.urls.CategoryURLGenerator var33 = null;
//     var17.setBaseURLGenerator(var33);
//     org.jfree.chart.StandardChartTheme var37 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var41 = var40.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var43 = null;
//     org.jfree.chart.util.Layer var44 = null;
//     boolean var45 = var40.removeDomainMarker(10, var43, var44);
//     java.awt.Paint var46 = var40.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var47 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var46);
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var49 = var48.getLabelPaint();
//     var47.setOutlinePaint(var49);
//     var37.setChartBackgroundPaint(var49);
//     java.awt.Paint var52 = var37.getAxisLabelPaint();
//     var17.setSeriesOutlinePaint(0, var52, false);
//     var1.setGridBandPaint(var52);
//     
//     // Checks the contract:  equals-hashcode on var4 and var40
//     assertTrue("Contract failed: equals-hashcode on var4 and var40", var4.equals(var40) ? var4.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var4
//     assertTrue("Contract failed: equals-hashcode on var40 and var4", var40.equals(var4) ? var40.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var47
//     assertTrue("Contract failed: equals-hashcode on var11 and var47", var11.equals(var47) ? var11.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var11
//     assertTrue("Contract failed: equals-hashcode on var47 and var11", var47.equals(var11) ? var47.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    java.util.List var2 = var1.getSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.getStartYValue(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     boolean var3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((-1.0d), 4.0d, var2);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
    org.jfree.data.xy.XYDatasetSelectionState var6 = var4.getSelectionState();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.setRangeGridlinesVisible(true);
    var7.clearDomainMarkers();
    var4.addChangeListener((org.jfree.data.general.DatasetChangeListener)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var4, 0, 1.0d, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)10, (java.lang.Number)100, false);
    org.jfree.data.xy.XYSeries var9 = var2.createCopy(100, 0);
    double var10 = var2.getMinX();
    boolean var12 = var2.equals((java.lang.Object)(-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var2.getY(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var7 = var6.getRotationAnchor();
    var2.setLabelTextAnchor(var7);
    org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var15 = var14.getRotationAnchor();
    var10.setLabelTextAnchor(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var18 = new org.jfree.chart.labels.ItemLabelPosition(var0, var7, var15, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     double var18 = var0.getShadowYOffset();
//     boolean var19 = var0.getIncludeBaseInRange();
//     var0.setSeriesCreateEntities(4, (java.lang.Boolean)true, true);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var29 = var0.initialise(var24, var25, var26, 10, var28);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("Size2D[width=0.0, height=0.0]", "ThreadContext", "", var3, "", "ThreadContext", "ThreadContext");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.util.List var10 = null;
    var7.setContributors(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.RendererChangeEvent var13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var10, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getIntegerInstance(var0);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.util.LineUtilities var0 = new org.jfree.chart.util.LineUtilities();

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot(var3);
//     org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
//     var2.addAll(var5);
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("NOID");
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.plot.MultiplePiePlot var8 = new org.jfree.chart.plot.MultiplePiePlot(var7);
    org.jfree.chart.LegendItemCollection var9 = var8.getLegendItems();
    java.awt.Font var10 = var8.getNoDataMessageFont();
    org.jfree.chart.axis.MarkerAxisBand var11 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var2, 0.0d, (-1.0d), 1.0d, (-1.0d), var10);
    java.awt.Paint var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var13 = new org.jfree.chart.block.LabelBlock("Size2D[width=0.0, height=0.0]", var10, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.java2DToValue(0.0d, var2, var3);
    java.awt.Shape var5 = var0.getRightArrow();
    org.jfree.chart.util.RectangleAnchor var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var6, 100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var19 = var18.getDomainZeroBaselineStroke();
//     java.awt.Paint var20 = var18.getDomainCrosshairPaint();
//     var0.setBaseLegendTextPaint(var20);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     boolean var28 = var27.getIgnoreZeroValues();
//     java.awt.Paint var29 = var27.getLabelLinkPaint();
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var31 = var30.getLabelPaint();
//     var30.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var35 = null;
//     org.jfree.chart.urls.XYURLGenerator var36 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var35, var36);
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var39 = null;
//     var38.setTimeline(var39);
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var42 = var41.getDomainZeroBaselineStroke();
//     var38.setAxisLineStroke(var42);
//     var37.setBaseStroke(var42, false);
//     var30.setAxisLineStroke(var42);
//     var0.drawDomainLine(var22, var23, var24, 100.0d, var29, var42);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)10, (java.lang.Number)100, false);
    org.jfree.data.xy.XYSeries var9 = var2.createCopy(100, 0);
    var2.add(0.0d, (java.lang.Number)1L, true);
    java.lang.Object var14 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var5 = var1.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    int var7 = var6.getDatasetCount();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.setMinorTickMarkInsideLength(0.0f);
    int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
    org.jfree.chart.event.TitleChangeListener var24 = null;
    var22.removeChangeListener(var24);
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var26.java2DToValue(0.0d, var28, var29);
    java.awt.Shape var31 = var26.getRightArrow();
    java.awt.Font var32 = var26.getLabelFont();
    var22.setItemFont(var32);
    java.awt.geom.Rectangle2D var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setBounds(var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateDimensions(var3);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    var0.setSeriesItemLabelsVisible(0, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    var1.setDomainZeroBaselineVisible(true);
    boolean var18 = var1.isDomainMinorGridlinesVisible();
    org.jfree.chart.plot.Marker var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addDomainMarker(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var1 = var0.getLabelPaint();
//     var0.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var5 = null;
//     org.jfree.chart.urls.XYURLGenerator var6 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var5, var6);
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var9 = null;
//     var8.setTimeline(var9);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
//     var8.setAxisLineStroke(var12);
//     var7.setBaseStroke(var12, false);
//     var0.setAxisLineStroke(var12);
//     java.util.Date var17 = var0.getMinimumDate();
//     java.util.TimeZone var18 = null;
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year(var17, var18);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     java.awt.Font var16 = var1.getRegularFont();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     java.awt.Paint var19 = var18.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var25 = var24.getDomainZeroBaselineStroke();
//     var22.setSeriesStroke(10, var25);
//     boolean var27 = var22.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var28 = var22.getBasePositiveItemLabelPosition();
//     java.awt.Paint var30 = var22.lookupSeriesOutlinePaint(0);
//     var18.setSectionPaint((java.lang.Comparable)true, var30);
//     org.jfree.chart.util.RectangleInsets var32 = var18.getLabelPadding();
//     var1.setAxisOffset(var32);
//     
//     // Checks the contract:  equals-hashcode on var4 and var24
//     assertTrue("Contract failed: equals-hashcode on var4 and var24", var4.equals(var24) ? var4.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var4
//     assertTrue("Contract failed: equals-hashcode on var24 and var4", var24.equals(var4) ? var24.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    java.awt.geom.Point2D var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePoint2D(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = null;
    var0.setTimeline(var1);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var0.setAxisLineStroke(var4);
    java.awt.Shape var6 = var0.getLeftArrow();
    org.jfree.chart.JFreeChart var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var8 = new org.jfree.chart.entity.JFreeChartEntity(var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.XYURLGenerator var2 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, var2);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(0);
    var3.setSeriesNegativeItemLabelPosition(100, var8);
    var3.setOutline(true);
    org.jfree.chart.annotations.XYAnnotation var12 = null;
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addAnnotation(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     org.jfree.data.xy.XYSeries var11 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
//     var11.add((java.lang.Number)(short)0, (java.lang.Number)(byte)10);
//     var11.setNotify(true);
//     var11.add((java.lang.Number)(short)(-1), (java.lang.Number)(-1), false);
//     boolean var21 = var8.equals((java.lang.Object)false);
//     java.awt.geom.Rectangle2D var22 = org.jfree.chart.text.TextUtilities.drawAlignedString("Size2D[width=100.0, height=100.0]", var1, 0.0f, 100.0f, var8);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var6 = var2.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     int var8 = var7.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     var9.setMinorTickMarkInsideLength(0.0f);
//     int var12 = var7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var18 = null;
//     org.jfree.chart.util.VerticalAlignment var19 = null;
//     org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement(var18, var19, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var22);
//     org.jfree.chart.entity.TitleEntity var24 = new org.jfree.chart.entity.TitleEntity(var6, (org.jfree.chart.title.Title)var23);
//     org.jfree.chart.event.TitleChangeListener var25 = null;
//     var23.removeChangeListener(var25);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var27.java2DToValue(0.0d, var29, var30);
//     java.awt.Shape var32 = var27.getRightArrow();
//     java.awt.Font var33 = var27.getLabelFont();
//     var23.setItemFont(var33);
//     org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var37 = var36.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var39 = null;
//     var36.setDomainAxisLocation(1, var39);
//     boolean var41 = var36.isSubplot();
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
//     var43.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var46 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var43.setStandardTickUnits(var46);
//     var36.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var43, true);
//     boolean var50 = var35.hasListener((java.util.EventListener)var36);
//     org.jfree.chart.urls.CategoryURLGenerator var51 = null;
//     var35.setBaseURLGenerator(var51);
//     org.jfree.chart.StandardChartTheme var55 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var59 = var58.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var61 = null;
//     org.jfree.chart.util.Layer var62 = null;
//     boolean var63 = var58.removeDomainMarker(10, var61, var62);
//     java.awt.Paint var64 = var58.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var65 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var64);
//     org.jfree.chart.axis.DateAxis var66 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var67 = var66.getLabelPaint();
//     var65.setOutlinePaint(var67);
//     var55.setChartBackgroundPaint(var67);
//     java.awt.Paint var70 = var55.getAxisLabelPaint();
//     var35.setSeriesOutlinePaint(0, var70, false);
//     org.jfree.chart.text.TextMeasurer var75 = null;
//     org.jfree.chart.text.TextBlock var76 = org.jfree.chart.text.TextUtilities.createTextBlock("XY Plot", var33, var70, 1.0f, 12, var75);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)0, (java.lang.Number)(byte)10);
    var2.setNotify(true);
    var2.add((java.lang.Number)(short)(-1), (java.lang.Number)(-1), false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((java.lang.Number)(-1L), (java.lang.Number)(byte)10);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
    org.jfree.data.Range var4 = new org.jfree.data.Range(1.0d, 10.0d);
    var1.setRange(var4, false, true);
    java.lang.Class var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeTimePeriodClass(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
//     var5.setSeriesStroke(10, var8);
//     boolean var10 = var5.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var5.getBasePositiveItemLabelPosition();
//     java.awt.Paint var13 = var5.lookupSeriesOutlinePaint(0);
//     var1.setSectionPaint((java.lang.Comparable)true, var13);
//     boolean var15 = var1.getAutoPopulateSectionPaint();
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     java.awt.Paint var18 = var16.getDomainCrosshairPaint();
//     var1.setLabelLinkPaint(var18);
//     
//     // Checks the contract:  equals-hashcode on var7 and var16
//     assertTrue("Contract failed: equals-hashcode on var7 and var16", var7.equals(var16) ? var7.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var7
//     assertTrue("Contract failed: equals-hashcode on var16 and var7", var16.equals(var7) ? var16.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var1.setSeriesStroke(10, var4);
//     boolean var6 = var1.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var1.getBasePositiveItemLabelPosition();
//     java.awt.Paint var9 = var1.lookupSeriesOutlinePaint(0);
//     var1.setBaseSeriesVisibleInLegend(true);
//     org.jfree.chart.StandardChartTheme var13 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var19 = null;
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var16.removeDomainMarker(10, var19, var20);
//     java.awt.Paint var22 = var16.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var23 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var22);
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var25 = var24.getLabelPaint();
//     var23.setOutlinePaint(var25);
//     var13.setChartBackgroundPaint(var25);
//     var1.setBaseItemLabelPaint(var25, false);
//     
//     // Checks the contract:  equals-hashcode on var3 and var16
//     assertTrue("Contract failed: equals-hashcode on var3 and var16", var3.equals(var16) ? var3.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var3
//     assertTrue("Contract failed: equals-hashcode on var16 and var3", var16.equals(var3) ? var16.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var19 = null;
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var16.removeDomainMarker(10, var19, var20);
//     java.awt.Paint var22 = var16.getDomainMinorGridlinePaint();
//     var1.setShadowPaint(var22);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add(90.0d, (java.lang.Number)1.0f);
    org.jfree.data.xy.XYDataItem var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var7 = var2.addOrUpdate(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var1 = var0.getLabelPaint();
    java.lang.String var2 = var0.getLabelToolTip();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.axis.AxisState var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    java.util.List var7 = var0.refreshTicks(var3, var4, var5, var6);
    var0.setMinorTickMarkOutsideLength(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     double var1 = var0.getContentXOffset();
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, (-1.0d), 0.0d);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var4.removeDomainMarker(10, var7, var8);
    java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var13 = var12.getLabelPaint();
    var11.setOutlinePaint(var13);
    var1.setChartBackgroundPaint(var13);
    java.awt.Paint var16 = var1.getAxisLabelPaint();
    org.jfree.chart.plot.DrawingSupplier var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDrawingSupplier(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.data.time.TimeSeries var6 = null;
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var6);
    java.util.List var8 = var7.getSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToRangeAxes(0, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var1.setSeriesStroke(10, var4);
//     boolean var6 = var1.getShapesVisible();
//     var1.setBaseSeriesVisibleInLegend(false);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     int var12 = var11.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     var13.setMinorTickMarkInsideLength(0.0f);
//     int var16 = var11.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var13);
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var19 = var1.initialise(var9, var10, var11, var17, var18);
//     
//     // Checks the contract:  equals-hashcode on var3 and var11
//     assertTrue("Contract failed: equals-hashcode on var3 and var11", var3.equals(var11) ? var3.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var3
//     assertTrue("Contract failed: equals-hashcode on var11 and var3", var11.equals(var3) ? var11.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
    org.jfree.data.xy.XYDatasetSelectionState var6 = var4.getSelectionState();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.setRangeGridlinesVisible(true);
    var7.clearDomainMarkers();
    var4.addChangeListener((org.jfree.data.general.DatasetChangeListener)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var18 = var4.getStartX(10, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     java.awt.Paint var2 = var0.getDomainCrosshairPaint();
//     boolean var3 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.LegendItemCollection var4 = var0.getFixedLegendItems();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var0.handleClick(4, 0, var7);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var20 = null;
//     var17.setDomainAxisLocation(1, var20);
//     boolean var22 = var17.isSubplot();
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     var24.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var27 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var24.setStandardTickUnits(var27);
//     var17.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
//     boolean var31 = var16.hasListener((java.util.EventListener)var17);
//     org.jfree.chart.urls.CategoryURLGenerator var32 = null;
//     var16.setBaseURLGenerator(var32);
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var35 = var34.getDomainZeroBaselineStroke();
//     java.awt.Paint var36 = var34.getDomainCrosshairPaint();
//     var16.setBaseLegendTextPaint(var36);
//     var1.setTitlePaint(var36);
//     
//     // Checks the contract:  equals-hashcode on var4 and var34
//     assertTrue("Contract failed: equals-hashcode on var4 and var34", var4.equals(var34) ? var4.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var4
//     assertTrue("Contract failed: equals-hashcode on var34 and var4", var34.equals(var4) ? var34.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
    org.jfree.data.xy.XYDatasetSelectionState var6 = var4.getSelectionState();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.setRangeGridlinesVisible(true);
    var7.clearDomainMarkers();
    var4.addChangeListener((org.jfree.data.general.DatasetChangeListener)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var4.getXValue(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var1 = new org.jfree.chart.renderer.xy.XYItemRendererState(var0);
    org.jfree.data.xy.XYDatasetSelectionState var2 = var1.getSelectionState();
    boolean var3 = var1.getProcessVisibleItemsOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var1 = var0.getLabelPaint();
    var0.setVisible(true);
    org.jfree.chart.labels.XYToolTipGenerator var5 = null;
    org.jfree.chart.urls.XYURLGenerator var6 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var5, var6);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var9 = null;
    var8.setTimeline(var9);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
    var8.setAxisLineStroke(var12);
    var7.setBaseStroke(var12, false);
    var0.setAxisLineStroke(var12);
    java.util.Date var17 = var0.getMinimumDate();
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
    java.util.TimeZone var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var17, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Calendar var3 = null;
//     long var4 = var2.getMiddleMillisecond(var3);
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(1.0d, 10.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var4 = org.jfree.data.Range.scale(var2, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 10.0d, 0.0f, 100.0f);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("10^12.15", var1, 0.0f, (-1.0f), 0.0d, 0.0f, (-1.0f));
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
//     var5.setSeriesStroke(10, var8);
//     boolean var10 = var5.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var5.getBasePositiveItemLabelPosition();
//     java.awt.Paint var13 = var5.lookupSeriesOutlinePaint(0);
//     var1.setSectionPaint((java.lang.Comparable)true, var13);
//     var1.setPieIndex(0);
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var18 = var17.getLabelPaint();
//     var17.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var22 = null;
//     org.jfree.chart.urls.XYURLGenerator var23 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var22, var23);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var26 = null;
//     var25.setTimeline(var26);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var29 = var28.getDomainZeroBaselineStroke();
//     var25.setAxisLineStroke(var29);
//     var24.setBaseStroke(var29, false);
//     var17.setAxisLineStroke(var29);
//     java.util.Date var34 = var17.getMinimumDate();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
//     java.awt.Paint var40 = var38.getSeriesOutlinePaint(0);
//     java.awt.Stroke var44 = var38.getItemStroke(15, 12, false);
//     var1.setSectionOutlineStroke((java.lang.Comparable)var34, var44);
//     
//     // Checks the contract:  equals-hashcode on var7 and var28
//     assertTrue("Contract failed: equals-hashcode on var7 and var28", var7.equals(var28) ? var7.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var1.getEndXValue(0, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     var0.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
//     var0.setBaseToolTipGenerator(var22, true);
//     java.lang.Comparable var25 = null;
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var0.getItemMiddle(var25, (java.lang.Comparable)1417420800000L, var27, var28, var29, var30);
// 
//   }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     int var11 = var10.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     var12.setMinorTickMarkInsideLength(0.0f);
//     int var15 = var10.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.FlowArrangement var25 = new org.jfree.chart.block.FlowArrangement(var21, var22, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var25);
//     org.jfree.chart.entity.TitleEntity var27 = new org.jfree.chart.entity.TitleEntity(var9, (org.jfree.chart.title.Title)var26);
//     org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var9);
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var31 = var30.getStroke();
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     int var34 = var32.getWeight();
//     boolean var35 = var32.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var37 = var36.getDomainZeroBaselineStroke();
//     java.awt.Paint var38 = var36.getDomainCrosshairPaint();
//     var32.setRangeGridlinePaint(var38);
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("", "", "21-December-2014", "hi!", var9, var31, var38);
//     
//     // Checks the contract:  equals-hashcode on var10 and var36
//     assertTrue("Contract failed: equals-hashcode on var10 and var36", var10.equals(var36) ? var10.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var10
//     assertTrue("Contract failed: equals-hashcode on var36 and var10", var36.equals(var10) ? var36.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.StandardChartTheme var7 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var13 = null;
//     org.jfree.chart.util.Layer var14 = null;
//     boolean var15 = var10.removeDomainMarker(10, var13, var14);
//     java.awt.Paint var16 = var10.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var16);
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var19 = var18.getLabelPaint();
//     var17.setOutlinePaint(var19);
//     var7.setChartBackgroundPaint(var19);
//     java.awt.Paint var22 = var7.getAxisLabelPaint();
//     org.jfree.chart.plot.DrawingSupplier var23 = var7.getDrawingSupplier();
//     var0.setDrawingSupplier(var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.setCrosshairDistance(10.0d);
    var1.updateCrosshairX(10.0d);
    var1.setAnchorY(0.0d);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var10 = var9.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var12 = null;
    var9.setDomainAxisLocation(1, var12);
    boolean var14 = var9.isSubplot();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    var16.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var19 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var16.setStandardTickUnits(var19);
    var9.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var16, true);
    boolean var23 = var8.hasListener((java.util.EventListener)var9);
    org.jfree.chart.urls.CategoryURLGenerator var24 = null;
    var8.setBaseURLGenerator(var24);
    double var26 = var8.getShadowYOffset();
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
    java.awt.Paint var29 = var28.getBaseSectionOutlinePaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var35 = var34.getDomainZeroBaselineStroke();
    var32.setSeriesStroke(10, var35);
    boolean var37 = var32.getShapesVisible();
    org.jfree.chart.labels.ItemLabelPosition var38 = var32.getBasePositiveItemLabelPosition();
    java.awt.Paint var40 = var32.lookupSeriesOutlinePaint(0);
    var28.setSectionPaint((java.lang.Comparable)true, var40);
    var8.setWallPaint(var40);
    var8.setItemLabelAnchorOffset(5.0d);
    boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)0.0d, (java.lang.Object)5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.annotations.CategoryAnnotation var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var16, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries(var0, "ThreadContext", "Size2D[width=0.0, height=0.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     java.lang.String var4 = var0.getNoDataMessage();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var10 = null;
//     org.jfree.chart.util.Layer var11 = null;
//     boolean var12 = var7.removeDomainMarker(10, var10, var11);
//     java.awt.Paint var13 = var7.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var13);
//     var0.setRangeGridlinePaint(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Image var1 = org.jfree.chart.util.SerialUtilities.readImage(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    var1.clearSelection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var8 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var1, "NOID");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ThreadContext", var1);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("Size2D[width=100.0, height=100.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var1.setSeriesStroke(10, var4);
//     boolean var6 = var1.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var1.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.XYToolTipGenerator var9 = null;
//     org.jfree.chart.urls.XYURLGenerator var10 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var9, var10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(0);
//     var11.setSeriesNegativeItemLabelPosition(100, var16);
//     var1.setBasePositiveItemLabelPosition(var16);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var20 = var19.getDomainZeroBaselineStroke();
//     int var21 = var19.getWeight();
//     boolean var22 = var19.isRangeZeroBaselineVisible();
//     boolean var23 = var16.equals((java.lang.Object)var19);
//     
//     // Checks the contract:  equals-hashcode on var3 and var19
//     assertTrue("Contract failed: equals-hashcode on var3 and var19", var3.equals(var19) ? var3.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var3
//     assertTrue("Contract failed: equals-hashcode on var19 and var3", var19.equals(var3) ? var19.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     boolean var4 = var0.isDomainCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var0.handleClick(15, 100, var7);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var6 = var2.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    int var8 = var7.getDatasetCount();
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    var9.setMinorTickMarkInsideLength(0.0f);
    int var12 = var7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var9);
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement(var18, var19, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var22);
    org.jfree.chart.entity.TitleEntity var24 = new org.jfree.chart.entity.TitleEntity(var6, (org.jfree.chart.title.Title)var23);
    org.jfree.chart.event.TitleChangeListener var25 = null;
    var23.removeChangeListener(var25);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    double var31 = var27.java2DToValue(0.0d, var29, var30);
    java.awt.Shape var32 = var27.getRightArrow();
    java.awt.Font var33 = var27.getLabelFont();
    var23.setItemFont(var33);
    java.awt.Paint var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("21-December-2014", var33, var35, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     java.awt.Paint var3 = var0.getDomainGridlinePaint();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.drawBackground(var4, var5);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     java.text.DateFormat var1 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
//     java.text.DateFormat var4 = var3.getXDateFormat();
//     org.jfree.data.xy.XYDataset var5 = null;
//     java.lang.String var8 = var3.generateLabelString(var5, 10, 10);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.util.LogFormat var0 = new org.jfree.chart.util.LogFormat();
    java.lang.String var2 = var0.format(1417420800000L);
    java.text.ParsePosition var4 = null;
    java.lang.Number var5 = var0.parse("", var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "10^12.15"+ "'", var2.equals("10^12.15"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var1.setSeriesStroke(10, var4);
//     boolean var6 = var1.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var1.getBasePositiveItemLabelPosition();
//     java.awt.Paint var9 = var1.lookupSeriesOutlinePaint(0);
//     var1.setBaseSeriesVisibleInLegend(true);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var14 = var13.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var16 = null;
//     var13.setDomainAxisLocation(1, var16);
//     var13.clearSelection();
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var20 = null;
//     var19.setTimeline(var20);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var23 = var22.getDomainZeroBaselineStroke();
//     var19.setAxisLineStroke(var23);
//     java.awt.Shape var25 = var19.getLeftArrow();
//     org.jfree.chart.util.ObjectList var26 = new org.jfree.chart.util.ObjectList();
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     int var29 = var26.indexOf((java.lang.Object)var28);
//     boolean var30 = var19.equals((java.lang.Object)var28);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var32 = var31.getDomainZeroBaselineStroke();
//     int var33 = var31.getWeight();
//     boolean var34 = var31.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.IntervalMarker var37 = new org.jfree.chart.plot.IntervalMarker(5.0d, 100.0d);
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var39 = var31.removeRangeMarker((org.jfree.chart.plot.Marker)var37, var38);
//     java.awt.geom.Rectangle2D var40 = null;
//     var1.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.plot.Marker)var37, var40);
//     
//     // Checks the contract:  equals-hashcode on var3 and var13
//     assertTrue("Contract failed: equals-hashcode on var3 and var13", var3.equals(var13) ? var3.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var22
//     assertTrue("Contract failed: equals-hashcode on var3 and var22", var3.equals(var22) ? var3.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var31
//     assertTrue("Contract failed: equals-hashcode on var3 and var31", var3.equals(var31) ? var3.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var3
//     assertTrue("Contract failed: equals-hashcode on var13 and var3", var13.equals(var3) ? var13.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var22
//     assertTrue("Contract failed: equals-hashcode on var13 and var22", var13.equals(var22) ? var13.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var31
//     assertTrue("Contract failed: equals-hashcode on var13 and var31", var13.equals(var31) ? var13.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var3
//     assertTrue("Contract failed: equals-hashcode on var22 and var3", var22.equals(var3) ? var22.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var13
//     assertTrue("Contract failed: equals-hashcode on var22 and var13", var22.equals(var13) ? var22.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var31
//     assertTrue("Contract failed: equals-hashcode on var22 and var31", var22.equals(var31) ? var22.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var3
//     assertTrue("Contract failed: equals-hashcode on var31 and var3", var31.equals(var3) ? var31.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var13
//     assertTrue("Contract failed: equals-hashcode on var31 and var13", var31.equals(var13) ? var31.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var22
//     assertTrue("Contract failed: equals-hashcode on var31 and var22", var31.equals(var22) ? var31.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.util.LogFormat var1 = new org.jfree.chart.util.LogFormat();
    java.text.NumberFormat var2 = java.text.NumberFormat.getInstance();
    org.jfree.chart.labels.StandardPieToolTipGenerator var3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Size2D[width=0.0, height=0.0]", (java.text.NumberFormat)var1, var2);
    var2.setMinimumFractionDigits(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    int var2 = var0.getWeight();
    boolean var3 = var0.isRangeZeroBaselineVisible();
    java.lang.String var4 = var0.getNoDataMessage();
    org.jfree.chart.axis.AxisLocation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(0, var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     boolean var4 = var0.isDomainCrosshairVisible();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var0.setDomainAxes(var7);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var10 = null;
//     var9.setTimeline(var10);
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
//     var9.setAxisLineStroke(var13);
//     java.awt.Shape var15 = var9.getLeftArrow();
//     org.jfree.chart.util.ObjectList var16 = new org.jfree.chart.util.ObjectList();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     int var19 = var16.indexOf((java.lang.Object)var18);
//     boolean var20 = var9.equals((java.lang.Object)var18);
//     org.jfree.chart.axis.ValueAxis[] var21 = new org.jfree.chart.axis.ValueAxis[] { var9};
//     var0.setRangeAxes(var21);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     java.awt.Paint var2 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setDomainCrosshairVisible(true);
//     var0.setRangeCrosshairVisible(false);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var14 = null;
//     org.jfree.chart.util.Layer var15 = null;
//     boolean var16 = var11.removeDomainMarker(10, var14, var15);
//     java.awt.Paint var17 = var11.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var18 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var17);
//     java.awt.Paint var19 = var18.getLabelPaint();
//     var0.setNoDataMessagePaint(var19);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     int var22 = var21.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     var23.setMinorTickMarkInsideLength(0.0f);
//     int var26 = var21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement(var32, var33, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var36);
//     boolean var38 = var0.equals((java.lang.Object)var36);
//     
//     // Checks the contract:  equals-hashcode on var11 and var21
//     assertTrue("Contract failed: equals-hashcode on var11 and var21", var11.equals(var21) ? var11.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var11
//     assertTrue("Contract failed: equals-hashcode on var21 and var11", var21.equals(var11) ? var21.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.renderer.category.GradientBarPainter var4 = new org.jfree.chart.renderer.category.GradientBarPainter(0.0d, 100.0d, 10.0d);
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter)var4);
    var0.setBarPainter((org.jfree.chart.renderer.category.BarPainter)var4);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemLabelGenerator(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var5 = var1.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    int var7 = var6.getDatasetCount();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.setMinorTickMarkInsideLength(0.0f);
    int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
    org.jfree.chart.LegendItemSource[] var24 = var22.getSources();
    org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22);
    org.jfree.chart.util.RectangleEdge var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var22.setLegendItemGraphicEdge(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var1 = var0.getLabelPaint();
//     var0.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var5 = null;
//     org.jfree.chart.urls.XYURLGenerator var6 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var5, var6);
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var9 = null;
//     var8.setTimeline(var9);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
//     var8.setAxisLineStroke(var12);
//     var7.setBaseStroke(var12, false);
//     var0.setAxisLineStroke(var12);
//     java.util.Date var17 = var0.getMinimumDate();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     java.util.TimeZone var19 = null;
//     org.jfree.chart.axis.PeriodAxis var21 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var24 = new org.jfree.data.Range(1.0d, 10.0d);
//     var21.setRange(var24, false, true);
//     java.util.Locale var28 = var21.getLocale();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year(var17, var19, var28);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     var6.setLowerMargin(0.0d);
//     var6.setMaximumCategoryLabelWidthRatio(2.0f);
//     boolean var12 = var6.equals((java.lang.Object)(byte)100);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var2.getItemMiddle((java.lang.Comparable)10L, (java.lang.Comparable)10, var5, (org.jfree.chart.axis.CategoryAxis)var6, var13, var14);
// 
//   }

//  public void test193() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("10^12.15", var1);
//
//  }
//
  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var3 = var2.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    boolean var7 = var2.removeDomainMarker(10, var5, var6);
    java.awt.Paint var8 = var2.getDomainMinorGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("ThreadContext", var1, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    var2.setMinorTickMarkInsideLength(0.0f);
    int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
    org.jfree.chart.plot.PlotOrientation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var4.getXValue(100, 1969);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.Rotation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     java.awt.Paint var2 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setDomainCrosshairVisible(true);
//     java.awt.Paint var7 = var0.getDomainGridlinePaint();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var8.draw(var9, var10);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = null;
//     org.jfree.chart.plot.PlotState var4 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     var0.draw(var1, var2, var3, var4, var5);
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("21-December-2014", var1, 0.0f, 100.0f, 8.0d, 0.0f, 1.0f);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    int var2 = var0.getWeight();
    boolean var3 = var0.isRangeZeroBaselineVisible();
    boolean var4 = var0.isDomainCrosshairVisible();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("NOID");
    org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
    var0.setDomainAxes(var7);
    org.jfree.chart.plot.PlotOrientation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = null;
    var0.setTimeline(var1);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var0.setAxisLineStroke(var4);
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRightArrow(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(90.0d, "hi!", "Size2D[width=0.0, height=0.0]", true);
    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var4.format((java.lang.Object)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 8.0d, 5.5d, var3);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     java.awt.Paint var18 = var16.getDomainCrosshairPaint();
//     var1.setShadowPaint(var18);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var1 = var0.getLabelPaint();
    var0.setVisible(true);
    org.jfree.chart.labels.XYToolTipGenerator var5 = null;
    org.jfree.chart.urls.XYURLGenerator var6 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var5, var6);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var9 = null;
    var8.setTimeline(var9);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
    var8.setAxisLineStroke(var12);
    var7.setBaseStroke(var12, false);
    var0.setAxisLineStroke(var12);
    java.util.Date var17 = var0.getMinimumDate();
    java.text.DateFormat var18 = null;
    var0.setDateFormatOverride(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var6 = null;
    var3.setDomainAxisLocation(1, var6);
    boolean var8 = var3.isSubplot();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    var10.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var13 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var10.setStandardTickUnits(var13);
    var3.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var10, true);
    boolean var17 = var2.hasListener((java.util.EventListener)var3);
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var2.setBaseURLGenerator(var18);
    var2.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = null;
    var2.setBaseToolTipGenerator(var24, true);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var28 = var27.getLabelPaint();
    var2.setBaseOutlinePaint(var28, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("10^2.0", var1, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var8 = var7.getRotationAnchor();
//     var3.setLabelTextAnchor(var8);
//     org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var16 = var15.getRotationAnchor();
//     var11.setLabelTextAnchor(var16);
//     org.jfree.chart.axis.NumberTick var19 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(byte)(-1), "10^12.15", var8, var16, 0.0d);
//     
//     // Checks the contract:  equals-hashcode on var3 and var11
//     assertTrue("Contract failed: equals-hashcode on var3 and var11", var3.equals(var11) ? var3.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var3
//     assertTrue("Contract failed: equals-hashcode on var11 and var3", var11.equals(var3) ? var11.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var15
//     assertTrue("Contract failed: equals-hashcode on var7 and var15", var7.equals(var15) ? var7.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var7
//     assertTrue("Contract failed: equals-hashcode on var15 and var7", var15.equals(var7) ? var15.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("NOID", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    boolean var3 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var10 = null;
    org.jfree.chart.util.Layer var11 = null;
    boolean var12 = var7.removeDomainMarker(10, var10, var11);
    java.awt.Paint var13 = var7.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var13);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var16 = var15.getLabelPaint();
    var14.setOutlinePaint(var16);
    org.jfree.chart.util.Layer var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var14, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    var5.setSeriesStroke(10, var8);
    boolean var10 = var5.getShapesVisible();
    org.jfree.chart.labels.ItemLabelPosition var11 = var5.getBasePositiveItemLabelPosition();
    java.awt.Paint var13 = var5.lookupSeriesOutlinePaint(0);
    var1.setSectionPaint((java.lang.Comparable)true, var13);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var15.java2DToValue(0.0d, var17, var18);
    var15.setNegativeArrowVisible(false);
    java.awt.Stroke var22 = var15.getTickMarkStroke();
    var1.setBaseSectionOutlineStroke(var22);
    java.lang.Comparable var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var25 = var1.getSectionOutlinePaint(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     boolean var4 = var0.isDomainCrosshairVisible();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     org.jfree.chart.axis.ValueAxis[] var7 = new org.jfree.chart.axis.ValueAxis[] { var6};
//     var0.setDomainAxes(var7);
//     var0.setForegroundAlpha((-1.0f));
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.drawBackground(var11, var12);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var4.getEndY(100, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.time.RegularTimePeriod var2 = var1.getLast();
//     float var3 = var1.getMinorTickMarkOutsideLength();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var6 = var5.getDomainZeroBaselineStroke();
//     java.awt.Paint var7 = var5.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var8 = null;
//     var5.axisChanged(var8);
//     java.awt.Image var10 = null;
//     var5.setBackgroundImage(var10);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var14 = var13.getDomainZeroBaselineStroke();
//     int var15 = var13.getWeight();
//     boolean var16 = var13.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     java.awt.Paint var19 = var17.getDomainCrosshairPaint();
//     var13.setRangeGridlinePaint(var19);
//     var13.setDomainCrosshairVisible(true);
//     boolean var23 = var13.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var24 = var13.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisSpace var25 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.axis.AxisSpace var26 = var1.reserveSpace(var4, (org.jfree.chart.plot.Plot)var5, var12, var24, var25);
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Size2D[width=100.0, height=100.0]", var1, 0.0f, 2.0f, Double.POSITIVE_INFINITY, 2.0f, 100.0f);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var1.setSeriesStroke(10, var4);
//     boolean var6 = var1.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var1.getBasePositiveItemLabelPosition();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
//     var9.setSeriesStroke(10, var12);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var9.getSeriesNegativeItemLabelPosition((-460));
//     boolean var16 = var1.equals((java.lang.Object)var15);
//     
//     // Checks the contract:  equals-hashcode on var3 and var11
//     assertTrue("Contract failed: equals-hashcode on var3 and var11", var3.equals(var11) ? var3.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var3
//     assertTrue("Contract failed: equals-hashcode on var11 and var3", var11.equals(var3) ? var11.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths();
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[])var0, (java.lang.Comparable[])var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0d, 10.0f, 2.0f);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var3 = null;
//     org.jfree.chart.util.Layer var4 = null;
//     boolean var5 = var0.removeDomainMarker(10, var3, var4);
//     java.awt.Paint var6 = var0.getDomainMinorGridlinePaint();
//     org.jfree.chart.axis.AxisLocation var8 = null;
//     var0.setRangeAxisLocation(100, var8, false);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.util.List var13 = null;
//     var0.drawRangeTickBands(var11, var12, var13);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     java.awt.Paint var18 = var17.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
//     var21.setSeriesStroke(10, var24);
//     boolean var26 = var21.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var21.getBasePositiveItemLabelPosition();
//     java.awt.Paint var29 = var21.lookupSeriesOutlinePaint(0);
//     var17.setSectionPaint((java.lang.Comparable)true, var29);
//     var0.setQuadrantPaint(3, var29);
//     java.awt.Paint[] var32 = new java.awt.Paint[] { var29};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var39 = var38.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var41 = null;
//     org.jfree.chart.util.Layer var42 = null;
//     boolean var43 = var38.removeDomainMarker(10, var41, var42);
//     java.awt.Paint var44 = var38.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var45 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var44);
//     java.awt.Paint var46 = var45.getLabelPaint();
//     var34.setLegendTextPaint(0, var46);
//     java.awt.Paint[] var48 = new java.awt.Paint[] { var46};
//     org.jfree.chart.axis.PeriodAxis var50 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var53 = new org.jfree.data.Range(1.0d, 10.0d);
//     var50.setRange(var53, false, true);
//     java.awt.Stroke var57 = var50.getMinorTickMarkStroke();
//     java.awt.Stroke[] var58 = new java.awt.Stroke[] { var57};
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var60 = var59.getDomainZeroBaselineStroke();
//     java.awt.Stroke[] var61 = new java.awt.Stroke[] { var60};
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var63 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var66 = var65.getDomainZeroBaselineStroke();
//     var63.setSeriesStroke(10, var66);
//     org.jfree.chart.annotations.XYAnnotation var68 = null;
//     boolean var69 = var63.removeAnnotation(var68);
//     org.jfree.chart.axis.DateAxis var70 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var72 = null;
//     org.jfree.chart.util.RectangleEdge var73 = null;
//     double var74 = var70.java2DToValue(0.0d, var72, var73);
//     java.awt.Shape var75 = var70.getRightArrow();
//     var63.setBaseShape(var75, true);
//     java.awt.Shape[] var78 = new java.awt.Shape[] { var75};
//     org.jfree.chart.plot.DefaultDrawingSupplier var79 = new org.jfree.chart.plot.DefaultDrawingSupplier(var32, var48, var58, var61, var78);
//     
//     // Checks the contract:  equals-hashcode on var23 and var38
//     assertTrue("Contract failed: equals-hashcode on var23 and var38", var23.equals(var38) ? var23.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var59
//     assertTrue("Contract failed: equals-hashcode on var23 and var59", var23.equals(var59) ? var23.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var65
//     assertTrue("Contract failed: equals-hashcode on var23 and var65", var23.equals(var65) ? var23.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var23
//     assertTrue("Contract failed: equals-hashcode on var38 and var23", var38.equals(var23) ? var38.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var59
//     assertTrue("Contract failed: equals-hashcode on var38 and var59", var38.equals(var59) ? var38.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var65
//     assertTrue("Contract failed: equals-hashcode on var38 and var65", var38.equals(var65) ? var38.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var23
//     assertTrue("Contract failed: equals-hashcode on var59 and var23", var59.equals(var23) ? var59.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var38
//     assertTrue("Contract failed: equals-hashcode on var59 and var38", var59.equals(var38) ? var59.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var65
//     assertTrue("Contract failed: equals-hashcode on var59 and var65", var59.equals(var65) ? var59.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var23
//     assertTrue("Contract failed: equals-hashcode on var65 and var23", var65.equals(var23) ? var65.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var38
//     assertTrue("Contract failed: equals-hashcode on var65 and var38", var65.equals(var38) ? var65.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var59
//     assertTrue("Contract failed: equals-hashcode on var65 and var59", var65.equals(var59) ? var65.hashCode() == var59.hashCode() : true);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1969);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     var0.drawBackground(var18, var19, var20);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    java.util.List var2 = var1.getSeries();
    org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var8 = var1.isSelected((-460), 1969);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var0.setAxisLineStroke(var4);
//     var0.setMinorTickCount(100);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
//     int var12 = var10.getWeight();
//     boolean var13 = var10.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
//     java.awt.Paint var16 = var14.getDomainCrosshairPaint();
//     var10.setRangeGridlinePaint(var16);
//     var10.setDomainCrosshairVisible(true);
//     boolean var20 = var10.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var21 = var10.getDomainAxisEdge();
//     double var22 = var0.java2DToValue(0.0d, var9, var21);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var6 = var5.getDomainZeroBaselineStroke();
//     int var7 = var5.getWeight();
//     boolean var8 = var5.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var10 = var9.getDomainZeroBaselineStroke();
//     java.awt.Paint var11 = var9.getDomainCrosshairPaint();
//     var5.setRangeGridlinePaint(var11);
//     var5.setDomainCrosshairVisible(true);
//     boolean var15 = var5.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var16 = var5.getDomainAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.axis.AxisState var18 = var0.draw(var1, Double.POSITIVE_INFINITY, var3, var4, var16, var17);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("XY Plot", var1, var2);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var2 = var1.getLabelPaint();
    var1.setVisible(true);
    org.jfree.chart.labels.XYToolTipGenerator var6 = null;
    org.jfree.chart.urls.XYURLGenerator var7 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var6, var7);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var10 = null;
    var9.setTimeline(var10);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
    var9.setAxisLineStroke(var13);
    var8.setBaseStroke(var13, false);
    var1.setAxisLineStroke(var13);
    java.util.Date var18 = var1.getMinimumDate();
    org.jfree.data.time.Year var19 = new org.jfree.data.time.Year(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var20 = new org.jfree.data.time.Month((-1), var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     int var2 = var0.getWeight();
//     boolean var3 = var0.isRangeZeroBaselineVisible();
//     boolean var4 = var0.isDomainCrosshairVisible();
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var7 = var6.getDomainZeroBaselineStroke();
//     java.awt.Paint var8 = var6.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var6.axisChanged(var9);
//     java.awt.Image var11 = null;
//     var6.setBackgroundImage(var11);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var14 = var13.getDomainZeroBaselineStroke();
//     java.awt.Paint var15 = var13.getDomainCrosshairPaint();
//     var6.setDomainZeroBaselinePaint(var15);
//     org.jfree.chart.plot.ValueMarker var18 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var19 = var18.getStroke();
//     org.jfree.chart.util.Layer var20 = null;
//     boolean var21 = var6.removeDomainMarker((org.jfree.chart.plot.Marker)var18, var20);
//     org.jfree.chart.util.Layer var22 = null;
//     var0.addRangeMarker(10, (org.jfree.chart.plot.Marker)var18, var22, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var13
//     assertTrue("Contract failed: equals-hashcode on var0 and var13", var0.equals(var13) ? var0.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var0
//     assertTrue("Contract failed: equals-hashcode on var13 and var0", var13.equals(var0) ? var13.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, var2);
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var5 = null;
//     var4.setTimeline(var5);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
//     var4.setAxisLineStroke(var8);
//     var3.setBaseStroke(var8, false);
//     boolean var12 = var3.getAutoPopulateSeriesOutlinePaint();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
//     java.awt.Paint var16 = var14.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var14.axisChanged(var17);
//     java.awt.Image var19 = null;
//     var14.setBackgroundImage(var19);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var22 = var21.getDomainZeroBaselineStroke();
//     java.awt.Paint var23 = var21.getDomainCrosshairPaint();
//     var14.setDomainZeroBaselinePaint(var23);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     var25.centerRange(10.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var31 = var29.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var33 = var29.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     int var35 = var34.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     var36.setMinorTickMarkInsideLength(0.0f);
//     int var39 = var34.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var36);
//     org.jfree.chart.util.HorizontalAlignment var40 = null;
//     org.jfree.chart.util.VerticalAlignment var41 = null;
//     org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var45 = null;
//     org.jfree.chart.util.VerticalAlignment var46 = null;
//     org.jfree.chart.block.FlowArrangement var49 = new org.jfree.chart.block.FlowArrangement(var45, var46, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var49);
//     org.jfree.chart.entity.TitleEntity var51 = new org.jfree.chart.entity.TitleEntity(var33, (org.jfree.chart.title.Title)var50);
//     org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity(var33);
//     org.jfree.chart.entity.LegendItemEntity var53 = new org.jfree.chart.entity.LegendItemEntity(var33);
//     var25.setRightArrow(var33);
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var60 = var59.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var62 = null;
//     org.jfree.chart.util.Layer var63 = null;
//     boolean var64 = var59.removeDomainMarker(10, var62, var63);
//     java.awt.Paint var65 = var59.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var66 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var65);
//     java.awt.Paint var67 = var66.getLabelPaint();
//     org.jfree.chart.plot.IntervalMarker var68 = new org.jfree.chart.plot.IntervalMarker(90.0d, 10.0d, var67);
//     java.awt.geom.Rectangle2D var69 = null;
//     var3.drawRangeMarker(var13, var14, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.plot.Marker)var68, var69);
//     
//     // Checks the contract:  equals-hashcode on var7 and var21
//     assertTrue("Contract failed: equals-hashcode on var7 and var21", var7.equals(var21) ? var7.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var34
//     assertTrue("Contract failed: equals-hashcode on var7 and var34", var7.equals(var34) ? var7.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var59
//     assertTrue("Contract failed: equals-hashcode on var7 and var59", var7.equals(var59) ? var7.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var7
//     assertTrue("Contract failed: equals-hashcode on var21 and var7", var21.equals(var7) ? var21.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var34
//     assertTrue("Contract failed: equals-hashcode on var21 and var34", var21.equals(var34) ? var21.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var59
//     assertTrue("Contract failed: equals-hashcode on var21 and var59", var21.equals(var59) ? var21.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var7
//     assertTrue("Contract failed: equals-hashcode on var34 and var7", var34.equals(var7) ? var34.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var21
//     assertTrue("Contract failed: equals-hashcode on var34 and var21", var34.equals(var21) ? var34.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var59
//     assertTrue("Contract failed: equals-hashcode on var34 and var59", var34.equals(var59) ? var34.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var7
//     assertTrue("Contract failed: equals-hashcode on var59 and var7", var59.equals(var7) ? var59.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var21
//     assertTrue("Contract failed: equals-hashcode on var59 and var21", var59.equals(var21) ? var59.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var34
//     assertTrue("Contract failed: equals-hashcode on var59 and var34", var59.equals(var34) ? var59.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.java2DToValue(0.0d, var2, var3);
    var0.setNegativeArrowVisible(false);
    var0.setUpperMargin((-1.0d));
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 1.0d);
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 1.0d);
    org.jfree.data.Range var15 = org.jfree.data.Range.combine(var9, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var9, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
    java.lang.Comparable var3 = null;
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var7 = var6.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var9 = null;
    org.jfree.chart.util.Layer var10 = null;
    boolean var11 = var6.removeDomainMarker(10, var9, var10);
    java.awt.Paint var12 = var6.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var13 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var12);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var15 = var14.getLabelPaint();
    var13.setOutlinePaint(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSectionOutlinePaint(var3, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var0.setAxisLineStroke(var4);
//     java.awt.Shape var6 = var0.getLeftArrow();
//     org.jfree.chart.axis.DateTickUnit var7 = var0.getTickUnit();
//     var0.zoomRange(Double.POSITIVE_INFINITY, Double.NaN);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var0.setAxisLineStroke(var4);
//     org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var7 = var6.getLabelPaint();
//     java.lang.String var8 = var6.getLabelToolTip();
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var6.refreshTicks(var9, var10, var11, var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     double var16 = var15.getStartAngle();
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var20 = var19.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var22 = null;
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var19.removeDomainMarker(10, var22, var23);
//     java.awt.Paint var25 = var19.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var25);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var28 = var27.getLabelPaint();
//     var26.setOutlinePaint(var28);
//     var15.setLabelPaint(var28);
//     var6.setAxisLinePaint(var28);
//     org.jfree.chart.axis.DateTickUnit var32 = var6.getTickUnit();
//     java.util.Date var33 = var0.calculateLowestVisibleTickValue(var32);
//     
//     // Checks the contract:  equals-hashcode on var3 and var19
//     assertTrue("Contract failed: equals-hashcode on var3 and var19", var3.equals(var19) ? var3.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var3
//     assertTrue("Contract failed: equals-hashcode on var19 and var3", var19.equals(var3) ? var19.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    int var3 = var2.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var5 = var2.get(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var4 = var0.indexOf((java.lang.Comparable)10.0f);
    java.util.List var5 = null;
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 1.0d);
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var11 = org.jfree.data.Range.expandToInclude(var9, 1.0d);
    org.jfree.data.Range var12 = org.jfree.data.Range.combine(var6, var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var0, var5, var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     org.jfree.data.time.RegularTimePeriod var2 = var0.next();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    int var2 = var0.getWeight();
    boolean var3 = var0.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var11 = var10.getRotationAnchor();
    var6.setLabelTextAnchor(var11);
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var6, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     org.jfree.data.time.RegularTimePeriod var4 = var2.next();
//     int var5 = var2.getMonth();
//     var1.delete((org.jfree.data.time.RegularTimePeriod)var2);
//     java.beans.PropertyChangeListener var7 = null;
//     var1.removePropertyChangeListener(var7);
//     org.jfree.data.time.TimeSeriesDataItem var9 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var10 = var1.addOrUpdate(var9);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 12);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = null;
//     var1.addFragment(var2);
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var6 = var5.getFirstTextFragment();
//     java.lang.String var7 = var6.getText();
//     var1.addFragment(var6);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var16 = var15.getRotationAnchor();
//     org.jfree.data.xy.XYSeries var19 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
//     var19.add((java.lang.Number)(short)0, (java.lang.Number)(byte)10);
//     var19.setNotify(true);
//     var19.add((java.lang.Number)(short)(-1), (java.lang.Number)(-1), false);
//     boolean var29 = var16.equals((java.lang.Object)false);
//     var6.draw(var9, 1.0f, 1.0f, var16, 0.0f, 100.0f, 100.0d);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    int var2 = var0.getWeight();
    boolean var3 = var0.isRangeZeroBaselineVisible();
    boolean var4 = var0.isDomainCrosshairVisible();
    org.jfree.data.general.DatasetGroup var5 = var0.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
    org.jfree.data.time.RegularTimePeriod var2 = var1.getLast();
    float var3 = var1.getMinorTickMarkOutsideLength();
    var1.setMinorTickMarkInsideLength(100.0f);
    java.lang.Class var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMinorTickTimePeriodClass(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 2.0f);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("SeriesRenderingOrder.REVERSE");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     org.jfree.chart.StandardChartTheme var20 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var26 = null;
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var23.removeDomainMarker(10, var26, var27);
//     java.awt.Paint var29 = var23.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var29);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var32 = var31.getLabelPaint();
//     var30.setOutlinePaint(var32);
//     var20.setChartBackgroundPaint(var32);
//     java.awt.Paint var35 = var20.getAxisLabelPaint();
//     var0.setSeriesOutlinePaint(0, var35, false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var38 = null;
//     var0.setLegendItemURLGenerator(var38);
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var45 = var0.initialise(var40, var41, var42, (-460), var44);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Image var5 = null;
    var0.setBackgroundImage(var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    var0.setDomainZeroBaselinePaint(var9);
    org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var13 = var12.getStroke();
    org.jfree.chart.util.Layer var14 = null;
    boolean var15 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var12, var14);
    org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
    java.util.List var19 = var18.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.mapDatasetToDomainAxes(100, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin(0.0d);
    var0.addCategoryLabelToolTip((java.lang.Comparable)(-3.0d), "21-December-2014");
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 1969);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    var0.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var0.setBaseToolTipGenerator(var22, true);
    var0.setAutoPopulateSeriesOutlinePaint(true);
    var0.setMaximumBarWidth(4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    int var3 = var2.getItemCount();
    java.util.Iterator var4 = var2.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = var2.get(12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     java.awt.Paint var2 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     var0.setRangeGridlinesVisible(true);
//     var0.clearDomainMarkers();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var9 = var8.getDomainZeroBaselineStroke();
//     int var10 = var8.getWeight();
//     boolean var11 = var8.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.IntervalMarker var14 = new org.jfree.chart.plot.IntervalMarker(5.0d, 100.0d);
//     org.jfree.chart.util.Layer var15 = null;
//     boolean var16 = var8.removeRangeMarker((org.jfree.chart.plot.Marker)var14, var15);
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var0.removeDomainMarker((org.jfree.chart.plot.Marker)var14, var17);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     java.awt.Paint var16 = var1.getAxisLabelPaint();
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var20 = var19.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var22 = null;
//     org.jfree.chart.util.Layer var23 = null;
//     boolean var24 = var19.removeDomainMarker(10, var22, var23);
//     java.awt.Paint var25 = var19.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var25);
//     var1.setRangeGridlinePaint(var25);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     java.lang.String var3 = var2.getText();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     float var6 = var2.calculateBaselineOffset(var4, var5);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     java.awt.Paint var2 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var11 = new org.jfree.data.Range(1.0d, 10.0d);
//     var8.setRange(var11, false, true);
//     java.awt.Stroke var15 = var8.getMinorTickMarkStroke();
//     boolean var16 = var8.isMinorTickMarksVisible();
//     java.awt.Shape var17 = var8.getUpArrow();
//     org.jfree.data.time.RegularTimePeriod var18 = var8.getFirst();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.AxisState var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var23 = var22.getDomainZeroBaselineStroke();
//     int var24 = var22.getWeight();
//     boolean var25 = var22.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var27 = var26.getDomainZeroBaselineStroke();
//     java.awt.Paint var28 = var26.getDomainCrosshairPaint();
//     var22.setRangeGridlinePaint(var28);
//     var22.setDomainCrosshairVisible(true);
//     boolean var32 = var22.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var33 = var22.getDomainAxisEdge();
//     java.util.List var34 = var8.refreshTicks(var19, var20, var21, var33);
//     var0.drawRangeTickBands(var5, var6, var34);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = null;
    var0.setTimeline(var1);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var0.setAxisLineStroke(var4);
    java.io.ObjectOutputStream var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var4, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var1 = var0.getLabelPaint();
    java.lang.String var2 = var0.getLabelToolTip();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.axis.AxisState var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    java.util.List var7 = var0.refreshTicks(var3, var4, var5, var6);
    org.jfree.data.general.PieDataset var8 = null;
    org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
    double var10 = var9.getStartAngle();
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var14 = var13.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(10, var16, var17);
    java.awt.Paint var19 = var13.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var20 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var19);
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var22 = var21.getLabelPaint();
    var20.setOutlinePaint(var22);
    var9.setLabelPaint(var22);
    var0.setAxisLinePaint(var22);
    float var26 = var0.getTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0f);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var4 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var0, 3, 0.05d, Double.NaN);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var3 = var2.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var5 = null;
//     org.jfree.chart.util.Layer var6 = null;
//     boolean var7 = var2.removeDomainMarker(10, var5, var6);
//     java.awt.Paint var8 = var2.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var8);
//     org.jfree.chart.event.MarkerChangeEvent var10 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var9);
//     java.lang.Class var11 = null;
//     java.util.EventListener[] var12 = var9.getListeners(var11);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    var0.setMaximumBarWidth(0.0d);
    org.jfree.chart.annotations.CategoryAnnotation var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add(90.0d, (java.lang.Number)1.0f);
    double var6 = var2.getMinX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 90.0d);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin(0.0d);
    var0.addCategoryLabelToolTip((java.lang.Comparable)(-3.0d), "21-December-2014");
    org.jfree.chart.axis.CategoryLabelPositions var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCategoryLabelPositions(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.renderer.category.GradientBarPainter var20 = new org.jfree.chart.renderer.category.GradientBarPainter(0.0d, 100.0d, 10.0d);
//     org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter)var20);
//     var16.setBarPainter((org.jfree.chart.renderer.category.BarPainter)var20);
//     var1.setBarPainter((org.jfree.chart.renderer.category.BarPainter)var20);
//     org.jfree.chart.StandardChartTheme var25 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var29 = var28.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var31 = null;
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var33 = var28.removeDomainMarker(10, var31, var32);
//     java.awt.Paint var34 = var28.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var34);
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var37 = var36.getLabelPaint();
//     var35.setOutlinePaint(var37);
//     var25.setChartBackgroundPaint(var37);
//     java.awt.Font var40 = var25.getRegularFont();
//     var1.setSmallFont(var40);
//     
//     // Checks the contract:  equals-hashcode on var4 and var28
//     assertTrue("Contract failed: equals-hashcode on var4 and var28", var4.equals(var28) ? var4.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var4
//     assertTrue("Contract failed: equals-hashcode on var28 and var4", var28.equals(var4) ? var28.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var35
//     assertTrue("Contract failed: equals-hashcode on var11 and var35", var11.equals(var35) ? var11.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var11
//     assertTrue("Contract failed: equals-hashcode on var35 and var11", var35.equals(var11) ? var35.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
//     var9.setSeriesStroke(10, var12);
//     var0.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var9);
//     var0.setDomainCrosshairValue(0.0d);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     java.awt.Paint var19 = var17.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var17.axisChanged(var20);
//     java.awt.Image var22 = null;
//     var17.setBackgroundImage(var22);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var25 = var24.getDomainZeroBaselineStroke();
//     java.awt.Paint var26 = var24.getDomainCrosshairPaint();
//     var17.setDomainZeroBaselinePaint(var26);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var30 = var29.getStroke();
//     org.jfree.chart.util.Layer var31 = null;
//     boolean var32 = var17.removeDomainMarker((org.jfree.chart.plot.Marker)var29, var31);
//     var0.setParent((org.jfree.chart.plot.Plot)var17);
//     
//     // Checks the contract:  equals-hashcode on var11 and var24
//     assertTrue("Contract failed: equals-hashcode on var11 and var24", var11.equals(var24) ? var11.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var11
//     assertTrue("Contract failed: equals-hashcode on var24 and var11", var24.equals(var11) ? var24.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 10.0d);
//     var2.setRange(var5, false, true);
//     java.util.Locale var9 = var2.getLocale();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var10 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var9);
//     java.util.ResourceBundle.Control var11 = null;
//     java.util.ResourceBundle var12 = java.util.ResourceBundle.getBundle("Size2D[width=0.0, height=0.0]", var9, var11);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var1 = var0.getLabelPaint();
//     var0.setTickMarksVisible(true);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     org.jfree.chart.axis.AxisState var10 = var0.draw(var4, 8.64E7d, var6, var7, var8, var9);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var19 = var18.getDomainZeroBaselineStroke();
//     java.awt.Paint var20 = var18.getDomainCrosshairPaint();
//     var0.setBaseLegendTextPaint(var20);
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var24 = null;
//     var23.setTimeline(var24);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var27 = var26.getDomainZeroBaselineStroke();
//     var23.setAxisLineStroke(var27);
//     var23.setMinorTickCount(100);
//     java.awt.Shape var31 = var23.getLeftArrow();
//     var0.setSeriesShape(10, var31, true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var26
//     assertTrue("Contract failed: equals-hashcode on var18 and var26", var18.equals(var26) ? var18.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var18
//     assertTrue("Contract failed: equals-hashcode on var26 and var18", var26.equals(var18) ? var26.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1);
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var5.next();
//     int var8 = var5.getMonth();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     java.beans.PropertyChangeListener var10 = null;
//     var4.removePropertyChangeListener(var10);
//     double var12 = var4.getMaxY();
//     var1.removeSeries(var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var1.getYValue(10, (-460));
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     org.jfree.chart.StandardChartTheme var20 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var26 = null;
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var23.removeDomainMarker(10, var26, var27);
//     java.awt.Paint var29 = var23.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var29);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var32 = var31.getLabelPaint();
//     var30.setOutlinePaint(var32);
//     var20.setChartBackgroundPaint(var32);
//     java.awt.Paint var35 = var20.getAxisLabelPaint();
//     var0.setSeriesOutlinePaint(0, var35, false);
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var40 = null;
//     var39.setTimeline(var40);
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var43 = var42.getDomainZeroBaselineStroke();
//     var39.setAxisLineStroke(var43);
//     java.awt.Shape var45 = var39.getLeftArrow();
//     org.jfree.chart.axis.DateTickUnit var46 = var39.getTickUnit();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis3D var48 = new org.jfree.chart.axis.CategoryAxis3D();
//     var48.setLowerMargin(0.0d);
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.axis.PeriodAxis var53 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var56 = new org.jfree.data.Range(1.0d, 10.0d);
//     var53.setRange(var56, false, true);
//     java.awt.Stroke var60 = var53.getMinorTickMarkStroke();
//     boolean var61 = var53.isMinorTickMarksVisible();
//     java.awt.Shape var62 = var53.getUpArrow();
//     org.jfree.data.time.RegularTimePeriod var63 = var53.getFirst();
//     java.awt.Graphics2D var64 = null;
//     org.jfree.chart.axis.AxisState var65 = null;
//     java.awt.geom.Rectangle2D var66 = null;
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var68 = var67.getDomainZeroBaselineStroke();
//     int var69 = var67.getWeight();
//     boolean var70 = var67.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var72 = var71.getDomainZeroBaselineStroke();
//     java.awt.Paint var73 = var71.getDomainCrosshairPaint();
//     var67.setRangeGridlinePaint(var73);
//     var67.setDomainCrosshairVisible(true);
//     boolean var77 = var67.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var78 = var67.getDomainAxisEdge();
//     java.util.List var79 = var53.refreshTicks(var64, var65, var66, var78);
//     double var80 = var0.getItemMiddle((java.lang.Comparable)1417420800000L, (java.lang.Comparable)var46, var47, (org.jfree.chart.axis.CategoryAxis)var48, var51, var78);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var20 = null;
//     var17.setDomainAxisLocation(1, var20);
//     boolean var22 = var17.isSubplot();
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     var24.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var27 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var24.setStandardTickUnits(var27);
//     var17.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var24, true);
//     boolean var31 = var16.hasListener((java.util.EventListener)var17);
//     org.jfree.chart.urls.CategoryURLGenerator var32 = null;
//     var16.setBaseURLGenerator(var32);
//     var16.setMaximumBarWidth(0.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var39 = var37.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var41 = var37.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
//     int var43 = var42.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     var44.setMinorTickMarkInsideLength(0.0f);
//     int var47 = var42.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var44);
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var48, var49, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var53 = null;
//     org.jfree.chart.util.VerticalAlignment var54 = null;
//     org.jfree.chart.block.FlowArrangement var57 = new org.jfree.chart.block.FlowArrangement(var53, var54, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42, (org.jfree.chart.block.Arrangement)var52, (org.jfree.chart.block.Arrangement)var57);
//     org.jfree.chart.entity.TitleEntity var59 = new org.jfree.chart.entity.TitleEntity(var41, (org.jfree.chart.title.Title)var58);
//     org.jfree.chart.event.TitleChangeListener var60 = null;
//     var58.removeChangeListener(var60);
//     org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var64 = null;
//     org.jfree.chart.util.RectangleEdge var65 = null;
//     double var66 = var62.java2DToValue(0.0d, var64, var65);
//     java.awt.Shape var67 = var62.getRightArrow();
//     java.awt.Font var68 = var62.getLabelFont();
//     var58.setItemFont(var68);
//     var16.setBaseItemLabelFont(var68);
//     var1.setExtraLargeFont(var68);
//     
//     // Checks the contract:  equals-hashcode on var4 and var42
//     assertTrue("Contract failed: equals-hashcode on var4 and var42", var4.equals(var42) ? var4.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var4
//     assertTrue("Contract failed: equals-hashcode on var42 and var4", var42.equals(var4) ? var42.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)(-1));
//     org.jfree.data.category.CategoryDataset var5 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var9 = var8.getDomainZeroBaselineStroke();
//     int var10 = var8.getWeight();
//     boolean var11 = var8.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
//     java.awt.Paint var14 = var12.getDomainCrosshairPaint();
//     var8.setRangeGridlinePaint(var14);
//     var8.setDomainCrosshairVisible(true);
//     boolean var18 = var8.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var19 = var8.getDomainAxisEdge();
//     double var20 = var0.getCategorySeriesMiddle((java.lang.Comparable)0L, (java.lang.Comparable)(-1.0f), var5, 0.08d, var7, var19);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var1.setSeriesStroke(10, var4);
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    boolean var7 = var1.removeAnnotation(var6);
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
    java.awt.Paint var12 = var10.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var13 = null;
    var10.axisChanged(var13);
    var10.setDomainCrosshairVisible(true);
    org.jfree.data.xy.DefaultXYDataset var17 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var18 = var17.clone();
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var17);
    java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var17);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var22 = var1.initialise(var8, var9, var10, (org.jfree.data.xy.XYDataset)var17, var21);
    org.jfree.chart.plot.XYCrosshairState var23 = null;
    var22.setCrosshairState(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.data.time.TimeSeries var3 = null;
//     org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
//     var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
//     org.jfree.data.xy.XYDatasetSelectionState var6 = var4.getSelectionState();
//     double var8 = var4.getDomainLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var10 = var4.getSeries(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
// 
//   }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     double var2 = var0.calculateTopOutset((-3.0d));
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.trim(var3);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.clipLine(var0, var1);
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var10 = var9.getRotationAnchor();
//     var5.setLabelTextAnchor(var10);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(0);
//     org.jfree.chart.text.TextAnchor var17 = var16.getRotationAnchor();
//     org.jfree.data.xy.XYSeries var20 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
//     var20.add((java.lang.Number)(short)0, (java.lang.Number)(byte)10);
//     var20.setNotify(true);
//     var20.add((java.lang.Number)(short)(-1), (java.lang.Number)(-1), false);
//     boolean var30 = var17.equals((java.lang.Object)false);
//     org.jfree.chart.text.TextUtilities.drawRotatedString("December 2014", var1, 2.0f, 0.0f, var10, (-1.0d), var17);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     int var3 = var2.getItemCount();
//     java.util.Iterator var4 = var2.iterator();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot(var5);
//     org.jfree.chart.LegendItemCollection var7 = var6.getLegendItems();
//     var2.addAll(var7);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var7
//     assertTrue("Contract failed: equals-hashcode on var2 and var7", var2.equals(var7) ? var2.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var2
//     assertTrue("Contract failed: equals-hashcode on var7 and var2", var7.equals(var2) ? var7.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.chart.util.LogFormat var2 = new org.jfree.chart.util.LogFormat();
    java.text.NumberFormat var3 = java.text.NumberFormat.getInstance();
    org.jfree.chart.labels.StandardPieToolTipGenerator var4 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Size2D[width=0.0, height=0.0]", (java.text.NumberFormat)var2, var3);
    boolean var5 = var3.isGroupingUsed();
    org.jfree.chart.util.LogFormat var6 = new org.jfree.chart.util.LogFormat();
    java.lang.String var8 = var6.format(1417420800000L);
    org.jfree.chart.labels.StandardPieToolTipGenerator var9 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var3, (java.text.NumberFormat)var6);
    org.jfree.data.general.PieDataset var10 = null;
    java.lang.String var12 = var9.generateToolTip(var10, (java.lang.Comparable)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "10^12.15"+ "'", var8.equals("10^12.15"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    double var1 = var0.getShadowXOffset();
    var0.setBaseSeriesVisible(false, true);
    var0.clearSeriesPaints(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     int var5 = var3.getWeight();
//     boolean var6 = var3.isRangeZeroBaselineVisible();
//     boolean var7 = var3.isDomainCrosshairVisible();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     org.jfree.chart.axis.ValueAxis[] var10 = new org.jfree.chart.axis.ValueAxis[] { var9};
//     var3.setDomainAxes(var10);
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.plot.MultiplePiePlot var19 = new org.jfree.chart.plot.MultiplePiePlot(var18);
//     org.jfree.chart.LegendItemCollection var20 = var19.getLegendItems();
//     java.awt.Font var21 = var19.getNoDataMessageFont();
//     org.jfree.chart.axis.MarkerAxisBand var22 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var13, 0.0d, (-1.0d), 1.0d, (-1.0d), var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     var1.fillRangeGridBand(var2, var3, (org.jfree.chart.axis.ValueAxis)var13, var23, 4.0d, 0.05d);
// 
//   }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setRangeGridlinesVisible(true);
    var0.clearDomainMarkers();
    int var8 = var0.getWeight();
    org.jfree.chart.plot.ValueMarker var11 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var12 = var11.getStroke();
    org.jfree.chart.util.Layer var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(0, (org.jfree.chart.plot.Marker)var11, var13, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var0, 0, 0.14d, 5.5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.setCrosshairDistance(10.0d);
    var1.updateCrosshairX(10.0d);
    var1.updateCrosshairX(0.0d);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("Size2D[width=100.0, height=100.0]");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var1, true);
    org.jfree.data.xy.XYDataItem var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var5 = var3.addOrUpdate(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     java.awt.Paint var16 = var1.getAxisLabelPaint();
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     java.awt.Paint var19 = var17.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var17.axisChanged(var20);
//     var17.setDomainCrosshairVisible(true);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var25};
//     var17.setRenderers(var26);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var29 = var28.getDomainZeroBaselineStroke();
//     java.awt.Paint var30 = var28.getDomainCrosshairPaint();
//     var17.setBackgroundPaint(var30);
//     var1.setWallPaint(var30);
//     
//     // Checks the contract:  equals-hashcode on var4 and var28
//     assertTrue("Contract failed: equals-hashcode on var4 and var28", var4.equals(var28) ? var4.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var4
//     assertTrue("Contract failed: equals-hashcode on var28 and var4", var28.equals(var4) ? var28.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var3 = var2.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    boolean var7 = var2.removeDomainMarker(10, var5, var6);
    java.awt.Paint var8 = var2.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var9 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var8);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var11 = var10.getLabelPaint();
    var9.setOutlinePaint(var11);
    java.io.ObjectOutputStream var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var11, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     double var3 = var0.getFixedDimension();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     var0.setUpArrow(var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
//     var19.setRange(var22, false, true);
//     java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
//     boolean var27 = var19.isMinorTickMarksVisible();
//     java.awt.Shape var28 = var19.getUpArrow();
//     var17.setArea(var28);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(10, var35, var36);
//     java.awt.Paint var38 = var32.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var38);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var39.setOutlinePaint(var41);
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var28, var41);
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot(var44);
//     java.awt.Paint var46 = var45.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var52 = var51.getDomainZeroBaselineStroke();
//     var49.setSeriesStroke(10, var52);
//     boolean var54 = var49.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var55 = var49.getBasePositiveItemLabelPosition();
//     java.awt.Paint var57 = var49.lookupSeriesOutlinePaint(0);
//     var45.setSectionPaint((java.lang.Comparable)true, var57);
//     org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     double var63 = var59.java2DToValue(0.0d, var61, var62);
//     var59.setNegativeArrowVisible(false);
//     java.awt.Stroke var66 = var59.getTickMarkStroke();
//     var45.setBaseSectionOutlineStroke(var66);
//     var43.setOutlineStroke(var66);
//     
//     // Checks the contract:  equals-hashcode on var5 and var49
//     assertTrue("Contract failed: equals-hashcode on var5 and var49", var5.equals(var49) ? var5.hashCode() == var49.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var5 and var49.", var5.equals(var49) == var49.equals(var5));
//     
//     // Checks the contract:  equals-hashcode on var32 and var51
//     assertTrue("Contract failed: equals-hashcode on var32 and var51", var32.equals(var51) ? var32.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var32
//     assertTrue("Contract failed: equals-hashcode on var51 and var32", var51.equals(var32) ? var51.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    org.jfree.data.xy.DefaultXYDataset var2 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var3 = var2.clone();
    java.lang.Object var4 = var2.clone();
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var2.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var6);
    var0.setDataset((org.jfree.data.xy.XYDataset)var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var10 = var2.getSeriesKey(3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin(0.0d);
    var0.setMaximumCategoryLabelWidthRatio(2.0f);
    boolean var6 = var0.equals((java.lang.Object)(byte)100);
    org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var8 = var7.getYear();
    java.util.List var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
    int var13 = var11.getWeight();
    boolean var14 = var11.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var16 = var15.getDomainZeroBaselineStroke();
    java.awt.Paint var17 = var15.getDomainCrosshairPaint();
    var11.setRangeGridlinePaint(var17);
    var11.setDomainCrosshairVisible(true);
    boolean var21 = var11.canSelectByRegion();
    org.jfree.chart.util.RectangleEdge var22 = var11.getDomainAxisEdge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var23 = var0.getCategoryMiddle((java.lang.Comparable)var8, var9, var10, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var4 = new org.jfree.data.Range(1.0d, 10.0d);
//     var1.setRange(var4, false, true);
//     java.awt.Stroke var8 = var1.getMinorTickMarkStroke();
//     float var9 = var1.getMinorTickMarkInsideLength();
//     var1.resizeRange(8.64E7d);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    boolean var5 = var0.removeDomainMarker(10, var3, var4);
    java.lang.String var6 = var0.getNoDataMessage();
    var0.setDomainPannable(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var10 = var0.getRangeAxisForDataset(3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var19 = var18.getDomainZeroBaselineStroke();
    java.awt.Paint var20 = var18.getDomainCrosshairPaint();
    var0.setBaseLegendTextPaint(var20);
    java.awt.Paint var23 = null;
    var0.setSeriesItemLabelPaint(1, var23, true);
    org.jfree.chart.urls.CategoryURLGenerator var27 = null;
    var0.setSeriesURLGenerator(1, var27);
    var0.setBaseSeriesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    java.awt.Shape var3 = null;
    var1.setLegendShape(10, var3);
    var1.setShapesVisible(true);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    org.jfree.chart.plot.SeriesRenderingOrder var12 = var7.getSeriesRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    java.awt.Shape var16 = null;
    var14.setLegendShape(10, var16);
    boolean var18 = var14.getAutoPopulateSeriesShape();
    org.jfree.chart.labels.XYSeriesLabelGenerator var19 = var14.getLegendItemLabelGenerator();
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    double var23 = var22.getStartAngle();
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var27 = var26.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var29 = null;
    org.jfree.chart.util.Layer var30 = null;
    boolean var31 = var26.removeDomainMarker(10, var29, var30);
    java.awt.Paint var32 = var26.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var33 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var32);
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var35 = var34.getLabelPaint();
    var33.setOutlinePaint(var35);
    var22.setLabelPaint(var35);
    java.awt.Paint var38 = var22.getOutlinePaint();
    var14.setSeriesItemLabelPaint(3, var38);
    var7.setDomainMinorGridlinePaint(var38);
    var1.setBaseFillPaint(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     double var2 = var1.getStartAngle();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var6 = var5.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var8 = null;
//     org.jfree.chart.util.Layer var9 = null;
//     boolean var10 = var5.removeDomainMarker(10, var8, var9);
//     java.awt.Paint var11 = var5.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var11);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var14 = var13.getLabelPaint();
//     var12.setOutlinePaint(var14);
//     var1.setLabelPaint(var14);
//     java.awt.Paint var17 = var1.getLabelOutlinePaint();
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var19 = var18.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var21 = null;
//     org.jfree.chart.util.Layer var22 = null;
//     boolean var23 = var18.removeDomainMarker(10, var21, var22);
//     java.lang.String var24 = var18.getNoDataMessage();
//     java.lang.String var25 = var18.getPlotType();
//     java.awt.Image var26 = null;
//     var18.setBackgroundImage(var26);
//     org.jfree.chart.StandardChartTheme var29 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(10, var35, var36);
//     java.awt.Paint var38 = var32.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var38);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var39.setOutlinePaint(var41);
//     var29.setChartBackgroundPaint(var41);
//     var18.setDomainCrosshairPaint(var41);
//     var1.setShadowPaint(var41);
//     
//     // Checks the contract:  equals-hashcode on var5 and var32
//     assertTrue("Contract failed: equals-hashcode on var5 and var32", var5.equals(var32) ? var5.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var5
//     assertTrue("Contract failed: equals-hashcode on var32 and var5", var32.equals(var5) ? var32.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var39
//     assertTrue("Contract failed: equals-hashcode on var12 and var39", var12.equals(var39) ? var12.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var12
//     assertTrue("Contract failed: equals-hashcode on var39 and var12", var39.equals(var12) ? var39.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var5 = var1.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     int var7 = var6.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.setMinorTickMarkInsideLength(0.0f);
//     int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
//     org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
//     org.jfree.chart.util.RectangleAnchor var24 = var22.getLegendItemGraphicLocation();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var26.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var30 = var26.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     int var32 = var31.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
//     var33.setMinorTickMarkInsideLength(0.0f);
//     int var36 = var31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var33);
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var42 = null;
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement(var42, var43, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31, (org.jfree.chart.block.Arrangement)var41, (org.jfree.chart.block.Arrangement)var46);
//     org.jfree.chart.entity.TitleEntity var48 = new org.jfree.chart.entity.TitleEntity(var30, (org.jfree.chart.title.Title)var47);
//     org.jfree.chart.LegendItemSource[] var49 = var47.getSources();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.util.Size2D var51 = var47.arrange(var50);
//     org.jfree.chart.util.HorizontalAlignment var52 = var47.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var53 = null;
//     org.jfree.chart.block.FlowArrangement var56 = new org.jfree.chart.block.FlowArrangement(var52, var53, 4.0d, 10.0d);
//     var22.setHorizontalAlignment(var52);
//     
//     // Checks the contract:  equals-hashcode on var3 and var28
//     assertTrue("Contract failed: equals-hashcode on var3 and var28", var3.equals(var28) ? var3.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var3
//     assertTrue("Contract failed: equals-hashcode on var28 and var3", var28.equals(var3) ? var28.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var31
//     assertTrue("Contract failed: equals-hashcode on var6 and var31", var6.equals(var31) ? var6.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var6
//     assertTrue("Contract failed: equals-hashcode on var31 and var6", var31.equals(var6) ? var31.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var41
//     assertTrue("Contract failed: equals-hashcode on var16 and var41", var16.equals(var41) ? var16.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var16
//     assertTrue("Contract failed: equals-hashcode on var41 and var16", var41.equals(var16) ? var41.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var46
//     assertTrue("Contract failed: equals-hashcode on var21 and var46", var21.equals(var46) ? var21.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var21
//     assertTrue("Contract failed: equals-hashcode on var46 and var21", var46.equals(var21) ? var46.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setBottom(1.0d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    double var2 = var1.getContentXOffset();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var5 = var0.arrange(var1, var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    var7.setLabelTextAnchor(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var15 = new org.jfree.chart.labels.ItemLabelPosition(var0, var5, var12, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     double var7 = var5.calculateRightInset(100.0d);
//     double var9 = var5.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D();
//     var10.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var20 = var16.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     int var22 = var21.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     var23.setMinorTickMarkInsideLength(0.0f);
//     int var26 = var21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement(var32, var33, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var36);
//     org.jfree.chart.entity.TitleEntity var38 = new org.jfree.chart.entity.TitleEntity(var20, (org.jfree.chart.title.Title)var37);
//     org.jfree.chart.event.TitleChangeListener var39 = null;
//     var37.removeChangeListener(var39);
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var41.java2DToValue(0.0d, var43, var44);
//     java.awt.Shape var46 = var41.getRightArrow();
//     java.awt.Font var47 = var41.getLabelFont();
//     var37.setItemFont(var47);
//     org.jfree.chart.block.BlockFrame var49 = var37.getFrame();
//     org.jfree.chart.util.RectangleAnchor var50 = var37.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var51 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, (-3.0d), Double.NaN, var50);
//     java.awt.geom.Rectangle2D var54 = var5.createOutsetRectangle(var51, true, true);
//     java.awt.geom.Rectangle2D var57 = var2.createOutsetRectangle(var54, false, true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var3 = null;
//     var0.setDomainAxisLocation(1, var3);
//     java.lang.String var5 = var0.getNoDataMessage();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var9 = var8.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var11 = null;
//     org.jfree.chart.util.Layer var12 = null;
//     boolean var13 = var8.removeDomainMarker(10, var11, var12);
//     java.awt.Paint var14 = var8.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var15 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var14);
//     org.jfree.chart.event.MarkerChangeEvent var16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var15);
//     var0.markerChanged(var16);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    double var2 = var1.getStartAngle();
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var6 = var5.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var8 = null;
    org.jfree.chart.util.Layer var9 = null;
    boolean var10 = var5.removeDomainMarker(10, var8, var9);
    java.awt.Paint var11 = var5.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var11);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var14 = var13.getLabelPaint();
    var12.setOutlinePaint(var14);
    var1.setLabelPaint(var14);
    boolean var17 = var1.getAutoPopulateSectionOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     double var3 = var0.getFixedDimension();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     var0.setUpArrow(var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
//     var19.setRange(var22, false, true);
//     java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
//     boolean var27 = var19.isMinorTickMarksVisible();
//     java.awt.Shape var28 = var19.getUpArrow();
//     var17.setArea(var28);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(10, var35, var36);
//     java.awt.Paint var38 = var32.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var38);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var39.setOutlinePaint(var41);
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var28, var41);
//     java.awt.Graphics2D var44 = null;
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.plot.MultiplePiePlot var46 = new org.jfree.chart.plot.MultiplePiePlot(var45);
//     org.jfree.chart.util.RectangleInsets var47 = var46.getInsets();
//     double var49 = var47.calculateRightInset(100.0d);
//     double var51 = var47.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var52 = new org.jfree.chart.util.Size2D();
//     var52.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var58 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var60 = var58.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var62 = var58.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
//     int var64 = var63.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis();
//     var65.setMinorTickMarkInsideLength(0.0f);
//     int var68 = var63.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var65);
//     org.jfree.chart.util.HorizontalAlignment var69 = null;
//     org.jfree.chart.util.VerticalAlignment var70 = null;
//     org.jfree.chart.block.ColumnArrangement var73 = new org.jfree.chart.block.ColumnArrangement(var69, var70, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var74 = null;
//     org.jfree.chart.util.VerticalAlignment var75 = null;
//     org.jfree.chart.block.FlowArrangement var78 = new org.jfree.chart.block.FlowArrangement(var74, var75, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63, (org.jfree.chart.block.Arrangement)var73, (org.jfree.chart.block.Arrangement)var78);
//     org.jfree.chart.entity.TitleEntity var80 = new org.jfree.chart.entity.TitleEntity(var62, (org.jfree.chart.title.Title)var79);
//     org.jfree.chart.event.TitleChangeListener var81 = null;
//     var79.removeChangeListener(var81);
//     org.jfree.chart.axis.DateAxis var83 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var85 = null;
//     org.jfree.chart.util.RectangleEdge var86 = null;
//     double var87 = var83.java2DToValue(0.0d, var85, var86);
//     java.awt.Shape var88 = var83.getRightArrow();
//     java.awt.Font var89 = var83.getLabelFont();
//     var79.setItemFont(var89);
//     org.jfree.chart.block.BlockFrame var91 = var79.getFrame();
//     org.jfree.chart.util.RectangleAnchor var92 = var79.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var93 = org.jfree.chart.util.RectangleAnchor.createRectangle(var52, (-3.0d), Double.NaN, var92);
//     java.awt.geom.Rectangle2D var96 = var47.createOutsetRectangle(var93, true, true);
//     var43.draw(var44, var93);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var1.setSeriesStroke(10, var4);
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    boolean var7 = var1.removeAnnotation(var6);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    double var12 = var8.java2DToValue(0.0d, var10, var11);
    java.awt.Shape var13 = var8.getRightArrow();
    var1.setBaseShape(var13, true);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var18 = new org.jfree.chart.renderer.xy.XYItemRendererState(var17);
    org.jfree.data.xy.XYDatasetSelectionState var19 = var18.getSelectionState();
    int var20 = var18.getLastItemIndex();
    org.jfree.chart.plot.XYCrosshairState var21 = var18.getCrosshairState();
    org.jfree.data.xy.XYDatasetSelectionState var22 = null;
    var18.setSelectionState(var22);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.plot.MultiplePiePlot var25 = new org.jfree.chart.plot.MultiplePiePlot(var24);
    org.jfree.chart.util.RectangleInsets var26 = var25.getInsets();
    double var28 = var26.calculateRightInset(100.0d);
    double var30 = var26.trimHeight(5.0d);
    org.jfree.chart.util.Size2D var31 = new org.jfree.chart.util.Size2D();
    var31.setHeight(100.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var39 = var37.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var41 = var37.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
    int var43 = var42.getDatasetCount();
    org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
    var44.setMinorTickMarkInsideLength(0.0f);
    int var47 = var42.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var44);
    org.jfree.chart.util.HorizontalAlignment var48 = null;
    org.jfree.chart.util.VerticalAlignment var49 = null;
    org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var48, var49, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var53 = null;
    org.jfree.chart.util.VerticalAlignment var54 = null;
    org.jfree.chart.block.FlowArrangement var57 = new org.jfree.chart.block.FlowArrangement(var53, var54, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var42, (org.jfree.chart.block.Arrangement)var52, (org.jfree.chart.block.Arrangement)var57);
    org.jfree.chart.entity.TitleEntity var59 = new org.jfree.chart.entity.TitleEntity(var41, (org.jfree.chart.title.Title)var58);
    org.jfree.chart.event.TitleChangeListener var60 = null;
    var58.removeChangeListener(var60);
    org.jfree.chart.axis.DateAxis var62 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var64 = null;
    org.jfree.chart.util.RectangleEdge var65 = null;
    double var66 = var62.java2DToValue(0.0d, var64, var65);
    java.awt.Shape var67 = var62.getRightArrow();
    java.awt.Font var68 = var62.getLabelFont();
    var58.setItemFont(var68);
    org.jfree.chart.block.BlockFrame var70 = var58.getFrame();
    org.jfree.chart.util.RectangleAnchor var71 = var58.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var72 = org.jfree.chart.util.RectangleAnchor.createRectangle(var31, (-3.0d), Double.NaN, var71);
    java.awt.geom.Rectangle2D var75 = var26.createOutsetRectangle(var72, true, true);
    org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var77 = var76.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var79 = null;
    var76.setDomainAxisLocation(1, var79);
    java.lang.String var81 = var76.getNoDataMessage();
    org.jfree.chart.LegendItemCollection var82 = var76.getFixedLegendItems();
    org.jfree.chart.axis.DateAxis var83 = new org.jfree.chart.axis.DateAxis();
    var83.centerRange(10.0d);
    var83.setLabel("ThreadContext");
    org.jfree.chart.axis.ValueAxis var88 = null;
    org.jfree.data.xy.DefaultXYDataset var89 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var90 = var89.clone();
    java.lang.Number var91 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var89);
    var89.validateObject();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.drawItem(var16, var18, var75, var76, (org.jfree.chart.axis.ValueAxis)var83, var88, (org.jfree.data.xy.XYDataset)var89, (-460), 15, false, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.PlotRenderingInfo var3 = null;
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var4.setDomainAxisLocation(1, var7);
    boolean var9 = var4.isSubplot();
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleAnchor var13 = null;
    java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
    var4.zoomRangeAxes(0.0d, var11, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes((-1.0d), 2.0d, var3, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot(var1);
//     org.jfree.chart.util.RectangleInsets var3 = var2.getInsets();
//     double var5 = var3.calculateRightInset(100.0d);
//     double var7 = var3.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D();
//     var8.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var16 = var14.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var18 = var14.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     int var20 = var19.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
//     var21.setMinorTickMarkInsideLength(0.0f);
//     int var24 = var19.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var21);
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var30 = null;
//     org.jfree.chart.util.VerticalAlignment var31 = null;
//     org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var30, var31, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var19, (org.jfree.chart.block.Arrangement)var29, (org.jfree.chart.block.Arrangement)var34);
//     org.jfree.chart.entity.TitleEntity var36 = new org.jfree.chart.entity.TitleEntity(var18, (org.jfree.chart.title.Title)var35);
//     org.jfree.chart.event.TitleChangeListener var37 = null;
//     var35.removeChangeListener(var37);
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var39.java2DToValue(0.0d, var41, var42);
//     java.awt.Shape var44 = var39.getRightArrow();
//     java.awt.Font var45 = var39.getLabelFont();
//     var35.setItemFont(var45);
//     org.jfree.chart.block.BlockFrame var47 = var35.getFrame();
//     org.jfree.chart.util.RectangleAnchor var48 = var35.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var49 = org.jfree.chart.util.RectangleAnchor.createRectangle(var8, (-3.0d), Double.NaN, var48);
//     java.awt.geom.Rectangle2D var52 = var3.createOutsetRectangle(var49, true, true);
//     boolean var53 = org.jfree.chart.util.LineUtilities.clipLine(var0, var49);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    var0.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = null;
    var0.setBaseToolTipGenerator(var22, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.plot.CategoryPlot var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPlot(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     double var3 = var0.getFixedDimension();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     var0.setUpArrow(var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
//     var19.setRange(var22, false, true);
//     java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
//     boolean var27 = var19.isMinorTickMarksVisible();
//     java.awt.Shape var28 = var19.getUpArrow();
//     var17.setArea(var28);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(10, var35, var36);
//     java.awt.Paint var38 = var32.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var38);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var39.setOutlinePaint(var41);
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var28, var41);
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var45 = var44.getLabelPaint();
//     var43.setOutlinePaint(var45);
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var48 = var47.getLabelPaint();
//     var47.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var52 = null;
//     org.jfree.chart.urls.XYURLGenerator var53 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var54 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var52, var53);
//     org.jfree.chart.axis.DateAxis var55 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var56 = null;
//     var55.setTimeline(var56);
//     org.jfree.chart.plot.XYPlot var58 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var59 = var58.getDomainZeroBaselineStroke();
//     var55.setAxisLineStroke(var59);
//     var54.setBaseStroke(var59, false);
//     var47.setAxisLineStroke(var59);
//     var43.setOutlineStroke(var59);
//     
//     // Checks the contract:  equals-hashcode on var32 and var58
//     assertTrue("Contract failed: equals-hashcode on var32 and var58", var32.equals(var58) ? var32.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var32
//     assertTrue("Contract failed: equals-hashcode on var58 and var32", var58.equals(var32) ? var58.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)0, (java.lang.Number)(byte)10);
    double var6 = var2.getMaxX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var3 = null;
    var0.setDomainAxisLocation(1, var3);
    boolean var5 = var0.isSubplot();
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var7 = var0.removeAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     var0.peg(var1);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    var0.setBarAlignmentFactor(1.0d);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var4 = null;
    var3.setTimeline(var4);
    boolean var6 = var0.equals((java.lang.Object)var3);
    boolean var7 = var0.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var13 = var9.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    int var15 = var14.getDatasetCount();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    var16.setMinorTickMarkInsideLength(0.0f);
    int var19 = var14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var25 = null;
    org.jfree.chart.util.VerticalAlignment var26 = null;
    org.jfree.chart.block.FlowArrangement var29 = new org.jfree.chart.block.FlowArrangement(var25, var26, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
    org.jfree.chart.entity.TitleEntity var31 = new org.jfree.chart.entity.TitleEntity(var13, (org.jfree.chart.title.Title)var30);
    org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity(var13);
    org.jfree.chart.entity.LegendItemEntity var33 = new org.jfree.chart.entity.LegendItemEntity(var13);
    var0.setLegendBar(var13);
    java.awt.Shape var38 = var0.getItemShape(1969, 15, true);
    var0.setShadowXOffset(1.0d);
    java.text.DateFormat var43 = null;
    java.text.DateFormat var44 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var45 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var43, var44);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-460), (org.jfree.chart.labels.XYToolTipGenerator)var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.getCeilingTickUnit(0.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = null;
    var1.setLegendLabelToolTipGenerator(var2);
    org.jfree.data.general.PieDataset var4 = null;
    var1.setDataset(var4);
    org.jfree.chart.plot.PieLabelLinkStyle var6 = var1.getLabelLinkStyle();
    boolean var7 = var1.getLabelLinksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var7 = null;
//     org.jfree.chart.util.Layer var8 = null;
//     boolean var9 = var4.removeDomainMarker(10, var7, var8);
//     java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var13 = var12.getLabelPaint();
//     var11.setOutlinePaint(var13);
//     var1.setChartBackgroundPaint(var13);
//     java.awt.Paint var16 = var1.getAxisLabelPaint();
//     java.awt.Paint var17 = var1.getRangeGridlinePaint();
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     java.awt.Paint var20 = var19.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var26 = var25.getDomainZeroBaselineStroke();
//     var23.setSeriesStroke(10, var26);
//     boolean var28 = var23.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var29 = var23.getBasePositiveItemLabelPosition();
//     java.awt.Paint var31 = var23.lookupSeriesOutlinePaint(0);
//     var19.setSectionPaint((java.lang.Comparable)true, var31);
//     org.jfree.chart.util.RectangleInsets var33 = var19.getLabelPadding();
//     var1.setAxisOffset(var33);
//     
//     // Checks the contract:  equals-hashcode on var4 and var25
//     assertTrue("Contract failed: equals-hashcode on var4 and var25", var4.equals(var25) ? var4.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var4
//     assertTrue("Contract failed: equals-hashcode on var25 and var4", var25.equals(var4) ? var25.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     double var3 = var0.getFixedDimension();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     var0.setUpArrow(var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
//     var19.setRange(var22, false, true);
//     java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
//     boolean var27 = var19.isMinorTickMarksVisible();
//     java.awt.Shape var28 = var19.getUpArrow();
//     var17.setArea(var28);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(10, var35, var36);
//     java.awt.Paint var38 = var32.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var38);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var39.setOutlinePaint(var41);
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var28, var41);
//     java.awt.Graphics2D var44 = null;
//     org.jfree.chart.util.Size2D var45 = new org.jfree.chart.util.Size2D();
//     var45.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var51 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var53 = var51.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var55 = var51.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     int var57 = var56.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis();
//     var58.setMinorTickMarkInsideLength(0.0f);
//     int var61 = var56.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var58);
//     org.jfree.chart.util.HorizontalAlignment var62 = null;
//     org.jfree.chart.util.VerticalAlignment var63 = null;
//     org.jfree.chart.block.ColumnArrangement var66 = new org.jfree.chart.block.ColumnArrangement(var62, var63, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var67 = null;
//     org.jfree.chart.util.VerticalAlignment var68 = null;
//     org.jfree.chart.block.FlowArrangement var71 = new org.jfree.chart.block.FlowArrangement(var67, var68, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var72 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var56, (org.jfree.chart.block.Arrangement)var66, (org.jfree.chart.block.Arrangement)var71);
//     org.jfree.chart.entity.TitleEntity var73 = new org.jfree.chart.entity.TitleEntity(var55, (org.jfree.chart.title.Title)var72);
//     org.jfree.chart.event.TitleChangeListener var74 = null;
//     var72.removeChangeListener(var74);
//     org.jfree.chart.axis.DateAxis var76 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var78 = null;
//     org.jfree.chart.util.RectangleEdge var79 = null;
//     double var80 = var76.java2DToValue(0.0d, var78, var79);
//     java.awt.Shape var81 = var76.getRightArrow();
//     java.awt.Font var82 = var76.getLabelFont();
//     var72.setItemFont(var82);
//     org.jfree.chart.block.BlockFrame var84 = var72.getFrame();
//     org.jfree.chart.util.RectangleAnchor var85 = var72.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var86 = org.jfree.chart.util.RectangleAnchor.createRectangle(var45, (-3.0d), Double.NaN, var85);
//     var43.draw(var44, var86);
// 
//   }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var0.setAxisLineStroke(var4);
//     java.awt.Shape var6 = var0.getLeftArrow();
//     org.jfree.chart.axis.DateTickUnit var7 = var0.getTickUnit();
//     java.lang.String var9 = var7.valueToString(0.0d);
//     int var11 = var7.compareTo((java.lang.Object)"PieSection: 100, 1(21-December-2014)");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "12/31/69 4:00 PM"+ "'", var9.equals("12/31/69 4:00 PM"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-1));
// 
//   }

//  public void test326() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
//
//
//    java.lang.Class var0 = null;
//    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//
//  }
//
  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    var0.setBarAlignmentFactor(1.0d);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var4 = null;
    var3.setTimeline(var4);
    boolean var6 = var0.equals((java.lang.Object)var3);
    boolean var7 = var0.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var13 = var9.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    int var15 = var14.getDatasetCount();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    var16.setMinorTickMarkInsideLength(0.0f);
    int var19 = var14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var25 = null;
    org.jfree.chart.util.VerticalAlignment var26 = null;
    org.jfree.chart.block.FlowArrangement var29 = new org.jfree.chart.block.FlowArrangement(var25, var26, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
    org.jfree.chart.entity.TitleEntity var31 = new org.jfree.chart.entity.TitleEntity(var13, (org.jfree.chart.title.Title)var30);
    org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity(var13);
    org.jfree.chart.entity.LegendItemEntity var33 = new org.jfree.chart.entity.LegendItemEntity(var13);
    var0.setLegendBar(var13);
    var0.setUseYInterval(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));

  }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, var2);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(0);
//     var3.setSeriesNegativeItemLabelPosition(100, var8);
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     double var14 = var12.calculateRightInset(100.0d);
//     double var16 = var12.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var17 = new org.jfree.chart.util.Size2D();
//     var17.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var27 = var23.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     int var29 = var28.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     var30.setMinorTickMarkInsideLength(0.0f);
//     int var33 = var28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var30);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var34, var35, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var39 = null;
//     org.jfree.chart.util.VerticalAlignment var40 = null;
//     org.jfree.chart.block.FlowArrangement var43 = new org.jfree.chart.block.FlowArrangement(var39, var40, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28, (org.jfree.chart.block.Arrangement)var38, (org.jfree.chart.block.Arrangement)var43);
//     org.jfree.chart.entity.TitleEntity var45 = new org.jfree.chart.entity.TitleEntity(var27, (org.jfree.chart.title.Title)var44);
//     org.jfree.chart.event.TitleChangeListener var46 = null;
//     var44.removeChangeListener(var46);
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     double var52 = var48.java2DToValue(0.0d, var50, var51);
//     java.awt.Shape var53 = var48.getRightArrow();
//     java.awt.Font var54 = var48.getLabelFont();
//     var44.setItemFont(var54);
//     org.jfree.chart.block.BlockFrame var56 = var44.getFrame();
//     org.jfree.chart.util.RectangleAnchor var57 = var44.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var58 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, (-3.0d), Double.NaN, var57);
//     java.awt.geom.Rectangle2D var61 = var12.createOutsetRectangle(var58, true, true);
//     var3.setLegendArea((java.awt.Shape)var58);
//     
//     // Checks the contract:  equals-hashcode on var8 and var25
//     assertTrue("Contract failed: equals-hashcode on var8 and var25", var8.equals(var25) ? var8.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var8
//     assertTrue("Contract failed: equals-hashcode on var25 and var8", var25.equals(var8) ? var25.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin(0.0d);
    var0.setMaximumCategoryLabelWidthRatio(2.0f);
    var0.setUpperMargin(Double.POSITIVE_INFINITY);
    java.lang.Comparable var7 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
    var9.setSeriesStroke(10, var12);
    org.jfree.chart.annotations.XYAnnotation var14 = null;
    boolean var15 = var9.removeAnnotation(var14);
    java.awt.Graphics2D var16 = null;
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var19 = var18.getDomainZeroBaselineStroke();
    java.awt.Paint var20 = var18.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var21 = null;
    var18.axisChanged(var21);
    var18.setDomainCrosshairVisible(true);
    org.jfree.data.xy.DefaultXYDataset var25 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var26 = var25.clone();
    org.jfree.data.Range var27 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var25);
    java.lang.Number var28 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var25);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var30 = var9.initialise(var16, var17, var18, (org.jfree.data.xy.XYDataset)var25, var29);
    java.util.List var31 = var18.getAnnotations();
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.plot.MultiplePiePlot var33 = new org.jfree.chart.plot.MultiplePiePlot(var32);
    org.jfree.chart.util.RectangleInsets var34 = var33.getInsets();
    double var36 = var34.calculateRightInset(100.0d);
    double var38 = var34.trimHeight(5.0d);
    org.jfree.chart.util.Size2D var39 = new org.jfree.chart.util.Size2D();
    var39.setHeight(100.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var45 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var47 = var45.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var49 = var45.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
    int var51 = var50.getDatasetCount();
    org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis();
    var52.setMinorTickMarkInsideLength(0.0f);
    int var55 = var50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var52);
    org.jfree.chart.util.HorizontalAlignment var56 = null;
    org.jfree.chart.util.VerticalAlignment var57 = null;
    org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement(var56, var57, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var61 = null;
    org.jfree.chart.util.VerticalAlignment var62 = null;
    org.jfree.chart.block.FlowArrangement var65 = new org.jfree.chart.block.FlowArrangement(var61, var62, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50, (org.jfree.chart.block.Arrangement)var60, (org.jfree.chart.block.Arrangement)var65);
    org.jfree.chart.entity.TitleEntity var67 = new org.jfree.chart.entity.TitleEntity(var49, (org.jfree.chart.title.Title)var66);
    org.jfree.chart.event.TitleChangeListener var68 = null;
    var66.removeChangeListener(var68);
    org.jfree.chart.axis.DateAxis var70 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var72 = null;
    org.jfree.chart.util.RectangleEdge var73 = null;
    double var74 = var70.java2DToValue(0.0d, var72, var73);
    java.awt.Shape var75 = var70.getRightArrow();
    java.awt.Font var76 = var70.getLabelFont();
    var66.setItemFont(var76);
    org.jfree.chart.block.BlockFrame var78 = var66.getFrame();
    org.jfree.chart.util.RectangleAnchor var79 = var66.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var80 = org.jfree.chart.util.RectangleAnchor.createRectangle(var39, (-3.0d), Double.NaN, var79);
    java.awt.geom.Rectangle2D var83 = var34.createOutsetRectangle(var80, true, true);
    org.jfree.chart.plot.XYPlot var84 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.RectangleEdge var85 = var84.getRangeAxisEdge();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var86 = var0.getCategoryMiddle(var7, var31, var83, var85);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("10^12.15", var1);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     var0.setSeriesItemLabelsVisible(0, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var23.setDomainAxisLocation(1, var26);
//     boolean var28 = var23.isSubplot();
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     var30.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var33 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var30.setStandardTickUnits(var33);
//     var23.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var30, true);
//     boolean var37 = var22.hasListener((java.util.EventListener)var23);
//     org.jfree.chart.urls.CategoryURLGenerator var38 = null;
//     var22.setBaseURLGenerator(var38);
//     var22.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
//     var22.setBaseToolTipGenerator(var44, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var47 = var22.getBaseItemLabelGenerator();
//     org.jfree.chart.axis.NumberAxis3D var50 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     org.jfree.data.category.CategoryDataset var55 = null;
//     org.jfree.chart.plot.MultiplePiePlot var56 = new org.jfree.chart.plot.MultiplePiePlot(var55);
//     org.jfree.chart.LegendItemCollection var57 = var56.getLegendItems();
//     java.awt.Font var58 = var56.getNoDataMessageFont();
//     org.jfree.chart.axis.MarkerAxisBand var59 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var50, 0.0d, (-1.0d), 1.0d, (-1.0d), var58);
//     var22.setSeriesItemLabelFont(15, var58, true);
//     var0.setSeriesItemLabelFont(3, var58, true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var33
//     assertTrue("Contract failed: equals-hashcode on var11 and var33", var11.equals(var33) ? var11.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var11
//     assertTrue("Contract failed: equals-hashcode on var33 and var11", var33.equals(var11) ? var33.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    var0.setBarAlignmentFactor(1.0d);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var4 = null;
    var3.setTimeline(var4);
    boolean var6 = var0.equals((java.lang.Object)var3);
    boolean var7 = var0.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var13 = var9.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    int var15 = var14.getDatasetCount();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    var16.setMinorTickMarkInsideLength(0.0f);
    int var19 = var14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var16);
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var25 = null;
    org.jfree.chart.util.VerticalAlignment var26 = null;
    org.jfree.chart.block.FlowArrangement var29 = new org.jfree.chart.block.FlowArrangement(var25, var26, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
    org.jfree.chart.entity.TitleEntity var31 = new org.jfree.chart.entity.TitleEntity(var13, (org.jfree.chart.title.Title)var30);
    org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity(var13);
    org.jfree.chart.entity.LegendItemEntity var33 = new org.jfree.chart.entity.LegendItemEntity(var13);
    var0.setLegendBar(var13);
    org.jfree.chart.JFreeChart var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var36 = new org.jfree.chart.entity.JFreeChartEntity(var13, var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = var0.getSeriesToolTipGenerator(10);
    java.awt.Paint var21 = var0.getLegendTextPaint(15);
    org.jfree.data.xy.XYSeries var24 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var24.add((java.lang.Number)(short)10, (java.lang.Number)100, false);
    java.lang.Number var30 = null;
    var24.updateByIndex(0, var30);
    boolean var32 = var0.equals((java.lang.Object)0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(8.64E7d, 2.0d, 90.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var5 = var1.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    int var7 = var6.getDatasetCount();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.setMinorTickMarkInsideLength(0.0f);
    int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
    org.jfree.chart.LegendItemSource[] var24 = var22.getSources();
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.util.Size2D var26 = var22.arrange(var25);
    org.jfree.chart.util.HorizontalAlignment var27 = var22.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var28 = null;
    org.jfree.chart.block.FlowArrangement var31 = new org.jfree.chart.block.FlowArrangement(var27, var28, 4.0d, 10.0d);
    var31.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setLowerMargin(0.0d);
//     var0.setMaximumCategoryLabelWidthRatio(2.0f);
//     var0.setUpperMargin(Double.POSITIVE_INFINITY);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
//     int var12 = var10.getWeight();
//     boolean var13 = var10.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
//     java.awt.Paint var16 = var14.getDomainCrosshairPaint();
//     var10.setRangeGridlinePaint(var16);
//     boolean var18 = var10.isRangeZoomable();
//     org.jfree.chart.util.RectangleEdge var19 = var10.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisState var20 = null;
//     var0.drawTickMarks(var7, 8.0d, var9, var19, var20);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var23 = var22.getLabelPaint();
//     var22.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var27, var28);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var31 = null;
//     var30.setTimeline(var31);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var34 = var33.getDomainZeroBaselineStroke();
//     var30.setAxisLineStroke(var34);
//     var29.setBaseStroke(var34, false);
//     var22.setAxisLineStroke(var34);
//     java.util.Date var39 = var22.getMinimumDate();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     org.jfree.data.time.SerialDate var42 = var40.getNearestDayOfWeek(3);
//     org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var45 = null;
//     var44.addFragment(var45);
//     org.jfree.chart.text.TextLine var48 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var49 = var48.getFirstTextFragment();
//     java.lang.String var50 = var49.getText();
//     var44.addFragment(var49);
//     java.awt.Font var52 = var49.getFont();
//     var0.setTickLabelFont((java.lang.Comparable)3, var52);
//     
//     // Checks the contract:  equals-hashcode on var14 and var33
//     assertTrue("Contract failed: equals-hashcode on var14 and var33", var14.equals(var33) ? var14.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var14
//     assertTrue("Contract failed: equals-hashcode on var33 and var14", var33.equals(var14) ? var33.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("Size2D[width=0.0, height=0.0]");
    org.jfree.data.Range var4 = new org.jfree.data.Range(1.0d, 10.0d);
    var1.setRange(var4, false, true);
    var1.setMinorTickMarkInsideLength(1.0f);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
//     org.jfree.chart.block.Block var17 = null;
//     org.jfree.chart.util.ShapeList var18 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var19 = var18.clone();
//     var10.add(var17, var19);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var22.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var26 = var22.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     int var28 = var27.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     var29.setMinorTickMarkInsideLength(0.0f);
//     int var32 = var27.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.FlowArrangement var42 = new org.jfree.chart.block.FlowArrangement(var38, var39, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27, (org.jfree.chart.block.Arrangement)var37, (org.jfree.chart.block.Arrangement)var42);
//     org.jfree.chart.entity.TitleEntity var44 = new org.jfree.chart.entity.TitleEntity(var26, (org.jfree.chart.title.Title)var43);
//     org.jfree.chart.LegendItemSource[] var45 = var43.getSources();
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var47 = var46.getDomainZeroBaselineStroke();
//     java.awt.Paint var48 = var46.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var49 = null;
//     var46.axisChanged(var49);
//     var46.setDomainCrosshairVisible(true);
//     java.awt.Paint var53 = var46.getDomainGridlinePaint();
//     org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(var53);
//     org.jfree.chart.util.RectangleInsets var55 = var54.getInsets();
//     var43.setFrame((org.jfree.chart.block.BlockFrame)var54);
//     boolean var57 = var10.equals((java.lang.Object)var54);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var42
//     assertTrue("Contract failed: equals-hashcode on var15 and var42", var15.equals(var42) ? var15.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var15
//     assertTrue("Contract failed: equals-hashcode on var42 and var15", var42.equals(var15) ? var42.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    double var18 = var0.getShadowYOffset();
    boolean var19 = var0.getIncludeBaseInRange();
    var0.setSeriesCreateEntities(4, (java.lang.Boolean)true, true);
    org.jfree.chart.util.LogFormat var24 = new org.jfree.chart.util.LogFormat();
    boolean var25 = var0.equals((java.lang.Object)var24);
    boolean var26 = var0.getAutoPopulateSeriesPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var28 = null;
    var0.setSeriesToolTipGenerator(12, var28);
    var0.setBaseItemLabelsVisible(false);
    boolean var32 = var0.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     var1.setDomainZeroBaselineVisible(true);
//     org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var20 = var19.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var22 = null;
//     var19.setDomainAxisLocation(1, var22);
//     boolean var24 = var19.isSubplot();
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis();
//     var26.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var29 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var26.setStandardTickUnits(var29);
//     var19.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var26, true);
//     boolean var33 = var18.hasListener((java.util.EventListener)var19);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = null;
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var36.java2DToValue(0.0d, var38, var39);
//     var36.setNegativeArrowVisible(false);
//     java.awt.geom.Rectangle2D var43 = null;
//     java.awt.Paint var45 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var48 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
//     java.awt.Paint var50 = var48.getSeriesOutlinePaint(0);
//     java.awt.Stroke var54 = var48.getItemStroke(15, 12, false);
//     var18.drawRangeLine(var34, var35, (org.jfree.chart.axis.ValueAxis)var36, var43, 10.0d, var45, var54);
//     var1.setRangeMinorGridlineStroke(var54);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var1.setSeriesStroke(10, var4);
//     org.jfree.chart.labels.XYItemLabelGenerator var7 = null;
//     var1.setSeriesItemLabelGenerator(1, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
//     int var12 = var10.getWeight();
//     boolean var13 = var10.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
//     java.awt.Paint var16 = var14.getDomainCrosshairPaint();
//     var10.setRangeGridlinePaint(var16);
//     var10.setDomainCrosshairVisible(true);
//     boolean var20 = var10.isDomainZoomable();
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.plot.MultiplePiePlot var23 = new org.jfree.chart.plot.MultiplePiePlot(var22);
//     org.jfree.chart.util.RectangleInsets var24 = var23.getInsets();
//     double var26 = var24.calculateRightInset(100.0d);
//     double var28 = var24.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var29 = new org.jfree.chart.util.Size2D();
//     var29.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var35.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var39 = var35.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     int var41 = var40.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis();
//     var42.setMinorTickMarkInsideLength(0.0f);
//     int var45 = var40.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.util.HorizontalAlignment var46 = null;
//     org.jfree.chart.util.VerticalAlignment var47 = null;
//     org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var51 = null;
//     org.jfree.chart.util.VerticalAlignment var52 = null;
//     org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var51, var52, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40, (org.jfree.chart.block.Arrangement)var50, (org.jfree.chart.block.Arrangement)var55);
//     org.jfree.chart.entity.TitleEntity var57 = new org.jfree.chart.entity.TitleEntity(var39, (org.jfree.chart.title.Title)var56);
//     org.jfree.chart.event.TitleChangeListener var58 = null;
//     var56.removeChangeListener(var58);
//     org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var62 = null;
//     org.jfree.chart.util.RectangleEdge var63 = null;
//     double var64 = var60.java2DToValue(0.0d, var62, var63);
//     java.awt.Shape var65 = var60.getRightArrow();
//     java.awt.Font var66 = var60.getLabelFont();
//     var56.setItemFont(var66);
//     org.jfree.chart.block.BlockFrame var68 = var56.getFrame();
//     org.jfree.chart.util.RectangleAnchor var69 = var56.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var70 = org.jfree.chart.util.RectangleAnchor.createRectangle(var29, (-3.0d), Double.NaN, var69);
//     java.awt.geom.Rectangle2D var73 = var24.createOutsetRectangle(var70, true, true);
//     var1.fillRangeGridBand(var9, var10, var21, var70, 0.0d, 10.0d);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 10.0d);
//     var2.setRange(var5, false, true);
//     java.util.Locale var9 = var2.getLocale();
//     org.jfree.chart.labels.StandardPieToolTipGenerator var10 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var9);
//     java.util.ResourceBundle.Control var11 = null;
//     java.util.ResourceBundle var12 = java.util.ResourceBundle.getBundle("", var9, var11);
// 
//   }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("SeriesRenderingOrder.REVERSE");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.plot.SeriesRenderingOrder var5 = var0.getSeriesRenderingOrder();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    java.awt.Shape var9 = null;
    var7.setLegendShape(10, var9);
    boolean var11 = var7.getAutoPopulateSeriesShape();
    org.jfree.chart.labels.XYSeriesLabelGenerator var12 = var7.getLegendItemLabelGenerator();
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
    double var16 = var15.getStartAngle();
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var20 = var19.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var22 = null;
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var19.removeDomainMarker(10, var22, var23);
    java.awt.Paint var25 = var19.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var26 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var25);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var28 = var27.getLabelPaint();
    var26.setOutlinePaint(var28);
    var15.setLabelPaint(var28);
    java.awt.Paint var31 = var15.getOutlinePaint();
    var7.setSeriesItemLabelPaint(3, var31);
    var0.setDomainMinorGridlinePaint(var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var35 = var0.getDomainAxisForDataset(4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 4);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
    org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 10.0d);
    var2.setRange(var5, false, true);
    java.util.Locale var9 = var2.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var10 = java.util.ResourceBundle.getBundle("Size2D[width=100.0, height=100.0]", var9);
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var3 = null;
//     org.jfree.chart.util.Layer var4 = null;
//     boolean var5 = var0.removeDomainMarker(10, var3, var4);
//     java.lang.String var6 = var0.getNoDataMessage();
//     java.lang.String var7 = var0.getPlotType();
//     java.awt.Image var8 = null;
//     var0.setBackgroundImage(var8);
//     org.jfree.chart.StandardChartTheme var11 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var17 = null;
//     org.jfree.chart.util.Layer var18 = null;
//     boolean var19 = var14.removeDomainMarker(10, var17, var18);
//     java.awt.Paint var20 = var14.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var21 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var20);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var23 = var22.getLabelPaint();
//     var21.setOutlinePaint(var23);
//     var11.setChartBackgroundPaint(var23);
//     var0.setDomainCrosshairPaint(var23);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var30 = var29.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var32 = null;
//     org.jfree.chart.util.Layer var33 = null;
//     boolean var34 = var29.removeDomainMarker(10, var32, var33);
//     java.awt.Paint var35 = var29.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var36 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var35);
//     org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var38 = var37.getLabelPaint();
//     var36.setOutlinePaint(var38);
//     boolean var40 = var0.removeRangeMarker((org.jfree.chart.plot.Marker)var36);
//     
//     // Checks the contract:  equals-hashcode on var14 and var29
//     assertTrue("Contract failed: equals-hashcode on var14 and var29", var14.equals(var29) ? var14.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var14
//     assertTrue("Contract failed: equals-hashcode on var29 and var14", var29.equals(var14) ? var29.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var36
//     assertTrue("Contract failed: equals-hashcode on var21 and var36", var21.equals(var36) ? var21.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var21
//     assertTrue("Contract failed: equals-hashcode on var36 and var21", var36.equals(var21) ? var36.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)0, (java.lang.Number)(byte)10);
    org.jfree.data.xy.XYDataItem var8 = var2.addOrUpdate(0.0d, 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-460), 1969, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getPositiveItemLabelPositionFallback();
    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseFillPaint(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)10, (java.lang.Number)100, false);
    org.jfree.data.xy.XYSeries var9 = var2.createCopy(100, 0);
    double var10 = var2.getMinX();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var2.getY(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     java.awt.Paint var18 = var16.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var19 = null;
//     var16.axisChanged(var19);
//     var16.setDomainCrosshairVisible(true);
//     java.awt.Paint var23 = var16.getDomainGridlinePaint();
//     var0.setBaseOutlinePaint(var23, false);
//     org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var29 = var28.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var28.setDomainAxisLocation(1, var31);
//     boolean var33 = var28.isSubplot();
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
//     var35.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var38 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var35.setStandardTickUnits(var38);
//     var28.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var35, true);
//     boolean var42 = var27.hasListener((java.util.EventListener)var28);
//     org.jfree.chart.urls.CategoryURLGenerator var43 = null;
//     var27.setBaseURLGenerator(var43);
//     var27.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
//     var27.setBaseToolTipGenerator(var49, true);
//     org.jfree.chart.renderer.category.BarRenderer3D var54 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
//     java.awt.Paint var56 = var54.getSeriesOutlinePaint(0);
//     org.jfree.chart.labels.ItemLabelPosition var60 = var54.getPositiveItemLabelPosition(10, 0, true);
//     var27.setBaseNegativeItemLabelPosition(var60, false);
//     var0.setSeriesPositiveItemLabelPosition(1, var60, true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var28
//     assertTrue("Contract failed: equals-hashcode on var1 and var28", var1.equals(var28) ? var1.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var1
//     assertTrue("Contract failed: equals-hashcode on var28 and var1", var28.equals(var1) ? var28.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var38
//     assertTrue("Contract failed: equals-hashcode on var11 and var38", var11.equals(var38) ? var11.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var11
//     assertTrue("Contract failed: equals-hashcode on var38 and var11", var38.equals(var11) ? var38.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.JFreeChart var5 = null;
    org.jfree.chart.event.ChartChangeEvent var6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var5);
    org.jfree.chart.JFreeChart var7 = null;
    var6.setChart(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    var1.setCrosshairDistance(10.0d);
    var1.setAnchorX(1.0d);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.chart.labels.StandardPieToolTipGenerator var1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("10^2.0");
    org.jfree.data.general.PieDataset var2 = null;
    java.lang.String var4 = var1.generateToolTip(var2, (java.lang.Comparable)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var0.setAxisLineStroke(var4);
//     java.awt.Shape var6 = var0.getLeftArrow();
//     var0.setLabelURL("Size2D[width=0.0, height=0.0]");
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.plot.MultiplePiePlot var11 = new org.jfree.chart.plot.MultiplePiePlot(var10);
//     org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
//     double var14 = var12.calculateRightInset(100.0d);
//     double var16 = var12.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var17 = new org.jfree.chart.util.Size2D();
//     var17.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var27 = var23.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     int var29 = var28.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     var30.setMinorTickMarkInsideLength(0.0f);
//     int var33 = var28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var30);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var34, var35, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var39 = null;
//     org.jfree.chart.util.VerticalAlignment var40 = null;
//     org.jfree.chart.block.FlowArrangement var43 = new org.jfree.chart.block.FlowArrangement(var39, var40, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var44 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28, (org.jfree.chart.block.Arrangement)var38, (org.jfree.chart.block.Arrangement)var43);
//     org.jfree.chart.entity.TitleEntity var45 = new org.jfree.chart.entity.TitleEntity(var27, (org.jfree.chart.title.Title)var44);
//     org.jfree.chart.event.TitleChangeListener var46 = null;
//     var44.removeChangeListener(var46);
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     double var52 = var48.java2DToValue(0.0d, var50, var51);
//     java.awt.Shape var53 = var48.getRightArrow();
//     java.awt.Font var54 = var48.getLabelFont();
//     var44.setItemFont(var54);
//     org.jfree.chart.block.BlockFrame var56 = var44.getFrame();
//     org.jfree.chart.util.RectangleAnchor var57 = var44.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var58 = org.jfree.chart.util.RectangleAnchor.createRectangle(var17, (-3.0d), Double.NaN, var57);
//     java.awt.geom.Rectangle2D var61 = var12.createOutsetRectangle(var58, true, true);
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.RectangleEdge var63 = var62.getRangeAxisEdge();
//     double var64 = var0.valueToJava2D(100.0d, var61, var63);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var1.setSeriesStroke(10, var4);
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    boolean var7 = var1.removeAnnotation(var6);
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
    java.awt.Paint var12 = var10.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var13 = null;
    var10.axisChanged(var13);
    var10.setDomainCrosshairVisible(true);
    org.jfree.data.xy.DefaultXYDataset var17 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var18 = var17.clone();
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var17);
    java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var17);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var22 = var1.initialise(var8, var9, var10, (org.jfree.data.xy.XYDataset)var17, var21);
    org.jfree.data.xy.XYDatasetSelectionState var23 = var22.getSelectionState();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    var1.setDomainZeroBaselineVisible(true);
    int var18 = var1.getRendererCount();
    var1.clearSelection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(10, 4, 7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var0.setBaseURLGenerator(var16);
    double var18 = var0.getShadowYOffset();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
    java.awt.Paint var21 = var20.getBaseSectionOutlinePaint();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var27 = var26.getDomainZeroBaselineStroke();
    var24.setSeriesStroke(10, var27);
    boolean var29 = var24.getShapesVisible();
    org.jfree.chart.labels.ItemLabelPosition var30 = var24.getBasePositiveItemLabelPosition();
    java.awt.Paint var32 = var24.lookupSeriesOutlinePaint(0);
    var20.setSectionPaint((java.lang.Comparable)true, var32);
    var0.setWallPaint(var32);
    double var35 = var0.getYOffset();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendItemLabelGenerator(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 8.0d);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("NOID");
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.plot.MultiplePiePlot var7 = new org.jfree.chart.plot.MultiplePiePlot(var6);
    org.jfree.chart.LegendItemCollection var8 = var7.getLegendItems();
    java.awt.Font var9 = var7.getNoDataMessageFont();
    org.jfree.chart.axis.MarkerAxisBand var10 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var1, 0.0d, (-1.0d), 1.0d, (-1.0d), var9);
    var1.setTickMarksVisible(false);
    boolean var13 = var1.getAutoRangeIncludesZero();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var14 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var13);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var3 = var2.getLabelPaint();
    var2.setVisible(true);
    org.jfree.chart.labels.XYToolTipGenerator var7 = null;
    org.jfree.chart.urls.XYURLGenerator var8 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var7, var8);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var11 = null;
    var10.setTimeline(var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var14 = var13.getDomainZeroBaselineStroke();
    var10.setAxisLineStroke(var14);
    var9.setBaseStroke(var14, false);
    var2.setAxisLineStroke(var14);
    java.util.Date var19 = var2.getMinimumDate();
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addMonths((-1), var20);
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addMonths(0, var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
    org.jfree.data.xy.XYDatasetSelectionState var6 = var4.getSelectionState();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.setRangeGridlinesVisible(true);
    var7.clearDomainMarkers();
    var4.addChangeListener((org.jfree.data.general.DatasetChangeListener)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var4.getEndXValue(15, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = null;
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var18.java2DToValue(0.0d, var20, var21);
//     var18.setNegativeArrowVisible(false);
//     java.awt.geom.Rectangle2D var25 = null;
//     java.awt.Paint var27 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
//     java.awt.Paint var32 = var30.getSeriesOutlinePaint(0);
//     java.awt.Stroke var36 = var30.getItemStroke(15, 12, false);
//     var0.drawRangeLine(var16, var17, (org.jfree.chart.axis.ValueAxis)var18, var25, 10.0d, var27, var36);
//     var18.setRange(1.0d, Double.NaN);
//     org.jfree.chart.axis.DateTickUnit var41 = null;
//     java.util.Date var42 = var18.calculateLowestVisibleTickValue(var41);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"21-December-2014", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(7, 12);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    int var2 = var0.getWeight();
    java.awt.Paint var3 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var0.zoomDomainAxes(0.0d, var5, var6, true);
    var0.setRangeCrosshairValue(90.0d, false);
    boolean var12 = var0.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    var0.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var1.getXValue(12, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    double var4 = var2.calculateRightInset(100.0d);
    double var6 = var2.trimHeight(5.0d);
    org.jfree.chart.util.Size2D var7 = new org.jfree.chart.util.Size2D();
    var7.setHeight(100.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var17 = var13.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
    int var19 = var18.getDatasetCount();
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    var20.setMinorTickMarkInsideLength(0.0f);
    int var23 = var18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var20);
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var29 = null;
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var28, (org.jfree.chart.block.Arrangement)var33);
    org.jfree.chart.entity.TitleEntity var35 = new org.jfree.chart.entity.TitleEntity(var17, (org.jfree.chart.title.Title)var34);
    org.jfree.chart.event.TitleChangeListener var36 = null;
    var34.removeChangeListener(var36);
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var40 = null;
    org.jfree.chart.util.RectangleEdge var41 = null;
    double var42 = var38.java2DToValue(0.0d, var40, var41);
    java.awt.Shape var43 = var38.getRightArrow();
    java.awt.Font var44 = var38.getLabelFont();
    var34.setItemFont(var44);
    org.jfree.chart.block.BlockFrame var46 = var34.getFrame();
    org.jfree.chart.util.RectangleAnchor var47 = var34.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var48 = org.jfree.chart.util.RectangleAnchor.createRectangle(var7, (-3.0d), Double.NaN, var47);
    java.awt.geom.Rectangle2D var51 = var2.createOutsetRectangle(var48, true, true);
    java.io.ObjectOutputStream var52 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeShape((java.awt.Shape)var48, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
    var1.setSeriesStroke(10, var4);
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    boolean var7 = var1.removeAnnotation(var6);
    java.awt.Graphics2D var8 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
    java.awt.Paint var12 = var10.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var13 = null;
    var10.axisChanged(var13);
    var10.setDomainCrosshairVisible(true);
    org.jfree.data.xy.DefaultXYDataset var17 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var18 = var17.clone();
    org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var17);
    java.lang.Number var20 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var17);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var22 = var1.initialise(var8, var9, var10, (org.jfree.data.xy.XYDataset)var17, var21);
    org.jfree.chart.axis.AxisLocation var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setDomainAxisLocation(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var2, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
//     org.jfree.chart.LegendItemSource[] var17 = var16.getSources();
//     org.jfree.chart.util.RectangleInsets var18 = var16.getLegendItemGraphicPadding();
//     org.jfree.data.category.CategoryDataset var19 = null;
//     org.jfree.chart.plot.MultiplePiePlot var20 = new org.jfree.chart.plot.MultiplePiePlot(var19);
//     org.jfree.chart.util.RectangleInsets var21 = var20.getInsets();
//     double var23 = var21.calculateRightInset(100.0d);
//     double var25 = var21.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var26 = new org.jfree.chart.util.Size2D();
//     var26.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var34 = var32.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var36 = var32.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     int var38 = var37.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     var39.setMinorTickMarkInsideLength(0.0f);
//     int var42 = var37.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var39);
//     org.jfree.chart.util.HorizontalAlignment var43 = null;
//     org.jfree.chart.util.VerticalAlignment var44 = null;
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.FlowArrangement var52 = new org.jfree.chart.block.FlowArrangement(var48, var49, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37, (org.jfree.chart.block.Arrangement)var47, (org.jfree.chart.block.Arrangement)var52);
//     org.jfree.chart.entity.TitleEntity var54 = new org.jfree.chart.entity.TitleEntity(var36, (org.jfree.chart.title.Title)var53);
//     org.jfree.chart.event.TitleChangeListener var55 = null;
//     var53.removeChangeListener(var55);
//     org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var57.java2DToValue(0.0d, var59, var60);
//     java.awt.Shape var62 = var57.getRightArrow();
//     java.awt.Font var63 = var57.getLabelFont();
//     var53.setItemFont(var63);
//     org.jfree.chart.block.BlockFrame var65 = var53.getFrame();
//     org.jfree.chart.util.RectangleAnchor var66 = var53.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var67 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, (-3.0d), Double.NaN, var66);
//     java.awt.geom.Rectangle2D var70 = var21.createOutsetRectangle(var67, true, true);
//     java.awt.geom.Rectangle2D var73 = var18.createOutsetRectangle(var70, true, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var37
//     assertTrue("Contract failed: equals-hashcode on var0 and var37", var0.equals(var37) ? var0.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var0
//     assertTrue("Contract failed: equals-hashcode on var37 and var0", var37.equals(var0) ? var37.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var47
//     assertTrue("Contract failed: equals-hashcode on var10 and var47", var10.equals(var47) ? var10.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var10
//     assertTrue("Contract failed: equals-hashcode on var47 and var10", var47.equals(var10) ? var47.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var52
//     assertTrue("Contract failed: equals-hashcode on var15 and var52", var15.equals(var52) ? var15.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var15
//     assertTrue("Contract failed: equals-hashcode on var52 and var15", var52.equals(var15) ? var52.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getCurrencyInstance();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = var0.parseObject("10^12.15");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var4 = var3.getDomainZeroBaselineStroke();
//     var0.setAxisLineStroke(var4);
//     java.awt.Shape var6 = var0.getLeftArrow();
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var11 = new org.jfree.data.Range(1.0d, 10.0d);
//     var8.setRange(var11, false, true);
//     java.awt.Stroke var15 = var8.getMinorTickMarkStroke();
//     boolean var16 = var8.isMinorTickMarksVisible();
//     java.awt.Shape var17 = var8.getUpArrow();
//     org.jfree.data.time.RegularTimePeriod var18 = var8.getFirst();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.AxisState var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var23 = var22.getDomainZeroBaselineStroke();
//     int var24 = var22.getWeight();
//     boolean var25 = var22.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var27 = var26.getDomainZeroBaselineStroke();
//     java.awt.Paint var28 = var26.getDomainCrosshairPaint();
//     var22.setRangeGridlinePaint(var28);
//     var22.setDomainCrosshairVisible(true);
//     boolean var32 = var22.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var33 = var22.getDomainAxisEdge();
//     java.util.List var34 = var8.refreshTicks(var19, var20, var21, var33);
//     org.jfree.chart.entity.AxisEntity var37 = new org.jfree.chart.entity.AxisEntity(var6, (org.jfree.chart.axis.Axis)var8, "", "12/31/69 4:00 PM");
//     
//     // Checks the contract:  equals-hashcode on var3 and var26
//     assertTrue("Contract failed: equals-hashcode on var3 and var26", var3.equals(var26) ? var3.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var3
//     assertTrue("Contract failed: equals-hashcode on var26 and var3", var26.equals(var3) ? var26.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var5 = var1.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    int var7 = var6.getDatasetCount();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.setMinorTickMarkInsideLength(0.0f);
    int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
    java.lang.String var24 = var23.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "TitleEntity: tooltip = null"+ "'", var24.equals("TitleEntity: tooltip = null"));

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var3 = var0.containsDomainRange(1417420800000L, 10L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var5 = var1.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     int var7 = var6.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.setMinorTickMarkInsideLength(0.0f);
//     int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
//     org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
//     org.jfree.chart.LegendItemSource[] var24 = var22.getSources();
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.block.RectangleConstraint var27 = null;
//     org.jfree.chart.util.Size2D var28 = var22.arrange(var26, var27);
//     java.lang.Object var29 = var22.clone();
//     org.jfree.chart.block.BlockContainer var30 = new org.jfree.chart.block.BlockContainer();
//     double var31 = var30.getContentXOffset();
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement(var32, var33, (-1.0d), 0.0d);
//     var30.setArrangement((org.jfree.chart.block.Arrangement)var36);
//     var22.setWrapper(var30);
//     
//     // Checks the contract:  equals-hashcode on var21 and var36
//     assertTrue("Contract failed: equals-hashcode on var21 and var36", var21.equals(var36) ? var21.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var21
//     assertTrue("Contract failed: equals-hashcode on var36 and var21", var36.equals(var21) ? var36.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     boolean var2 = var1.getIgnoreZeroValues();
//     java.awt.Paint var3 = var1.getLabelLinkPaint();
//     var1.clearSectionPaints(true);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     java.awt.Paint var9 = var8.getBaseSectionOutlinePaint();
//     var1.setSectionOutlinePaint((java.lang.Comparable)1.0d, var9);
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var12 = var11.getLabelPaint();
//     java.lang.String var13 = var11.getLabelToolTip();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.AxisState var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     java.util.List var18 = var11.refreshTicks(var14, var15, var16, var17);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     double var21 = var20.getStartAngle();
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var25 = var24.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var27 = null;
//     org.jfree.chart.util.Layer var28 = null;
//     boolean var29 = var24.removeDomainMarker(10, var27, var28);
//     java.awt.Paint var30 = var24.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var30);
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var33 = var32.getLabelPaint();
//     var31.setOutlinePaint(var33);
//     var20.setLabelPaint(var33);
//     var11.setAxisLinePaint(var33);
//     var1.setLabelLinkPaint(var33);
//     
//     // Checks the contract:  equals-hashcode on var8 and var20
//     assertTrue("Contract failed: equals-hashcode on var8 and var20", var8.equals(var20) ? var8.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var8
//     assertTrue("Contract failed: equals-hashcode on var20 and var8", var20.equals(var8) ? var20.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     java.awt.Paint var2 = var0.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var0.axisChanged(var3);
//     org.jfree.chart.plot.SeriesRenderingOrder var5 = var0.getSeriesRenderingOrder();
//     org.jfree.data.xy.XYDataset var6 = null;
//     int var7 = var0.indexOf(var6);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var13 = null;
//     org.jfree.chart.util.Layer var14 = null;
//     boolean var15 = var10.removeDomainMarker(10, var13, var14);
//     java.awt.Paint var16 = var10.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var17 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var16);
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var19 = var18.getLabelPaint();
//     var17.setOutlinePaint(var19);
//     org.jfree.chart.util.GradientPaintTransformer var21 = var17.getGradientPaintTransformer();
//     org.jfree.chart.util.Layer var22 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var17, var22);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.setMargin(100.0d, 100.0d, 0.0d, (-1.0d));
    double var6 = var0.getHeight();
    org.jfree.chart.block.BlockFrame var7 = var0.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
    org.jfree.chart.renderer.category.BarPainter var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBarPainter(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var2 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var6 = var5.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var8 = null;
//     org.jfree.chart.util.Layer var9 = null;
//     boolean var10 = var5.removeDomainMarker(10, var8, var9);
//     java.awt.Paint var11 = var5.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var11);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var14 = var13.getLabelPaint();
//     var12.setOutlinePaint(var14);
//     var2.setChartBackgroundPaint(var14);
//     java.awt.Font var17 = var2.getRegularFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("index.html?series=15&amp;item=-460", var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.util.Size2D var20 = new org.jfree.chart.util.Size2D();
//     var20.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var28 = var26.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var30 = var26.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     int var32 = var31.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
//     var33.setMinorTickMarkInsideLength(0.0f);
//     int var36 = var31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var33);
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var42 = null;
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement(var42, var43, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31, (org.jfree.chart.block.Arrangement)var41, (org.jfree.chart.block.Arrangement)var46);
//     org.jfree.chart.entity.TitleEntity var48 = new org.jfree.chart.entity.TitleEntity(var30, (org.jfree.chart.title.Title)var47);
//     org.jfree.chart.event.TitleChangeListener var49 = null;
//     var47.removeChangeListener(var49);
//     org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleEdge var54 = null;
//     double var55 = var51.java2DToValue(0.0d, var53, var54);
//     java.awt.Shape var56 = var51.getRightArrow();
//     java.awt.Font var57 = var51.getLabelFont();
//     var47.setItemFont(var57);
//     org.jfree.chart.block.BlockFrame var59 = var47.getFrame();
//     org.jfree.chart.util.RectangleAnchor var60 = var47.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var61 = org.jfree.chart.util.RectangleAnchor.createRectangle(var20, (-3.0d), Double.NaN, var60);
//     org.jfree.chart.ChartTheme var62 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
//     java.lang.Object var63 = var18.draw(var19, var61, (java.lang.Object)var62);
//     
//     // Checks the contract:  equals-hashcode on var5 and var31
//     assertTrue("Contract failed: equals-hashcode on var5 and var31", var5.equals(var31) ? var5.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var5
//     assertTrue("Contract failed: equals-hashcode on var31 and var5", var31.equals(var5) ? var31.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.data.time.Year var1 = var0.getYear();
    org.jfree.data.time.RegularTimePeriod var2 = var0.next();
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "10^2.0", "TextAnchor.CENTER");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var8 = var5.createCopy((-1), 7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getPercentInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     org.jfree.chart.labels.CategoryToolTipGenerator var19 = var0.getSeriesToolTipGenerator(10);
//     java.awt.Paint var21 = var0.getLegendTextPaint(15);
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var23.setDomainAxisLocation(1, var26);
//     boolean var28 = var23.isSubplot();
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     var30.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var33 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var30.setStandardTickUnits(var33);
//     var23.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var30, true);
//     boolean var37 = var22.hasListener((java.util.EventListener)var23);
//     org.jfree.chart.urls.CategoryURLGenerator var38 = null;
//     var22.setBaseURLGenerator(var38);
//     org.jfree.chart.labels.CategoryToolTipGenerator var41 = var22.getSeriesToolTipGenerator(10);
//     java.awt.Paint var43 = var22.getLegendTextPaint(15);
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var46 = var45.getDomainZeroBaselineStroke();
//     java.awt.Paint var47 = var45.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var48 = null;
//     var45.axisChanged(var48);
//     java.awt.Image var50 = null;
//     var45.setBackgroundImage(var50);
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var53 = var52.getDomainZeroBaselineStroke();
//     java.awt.Paint var54 = var52.getDomainCrosshairPaint();
//     var45.setDomainZeroBaselinePaint(var54);
//     java.awt.Paint var56 = var45.getDomainGridlinePaint();
//     var22.setSeriesOutlinePaint(12, var56);
//     var0.setShadowPaint(var56);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var33
//     assertTrue("Contract failed: equals-hashcode on var11 and var33", var11.equals(var33) ? var11.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var11
//     assertTrue("Contract failed: equals-hashcode on var33 and var11", var33.equals(var11) ? var33.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1);
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var5.next();
//     int var8 = var5.getMonth();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     java.beans.PropertyChangeListener var10 = null;
//     var4.removePropertyChangeListener(var10);
//     double var12 = var4.getMaxY();
//     var1.removeSeries(var4);
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var17 = var16.getYear();
//     org.jfree.data.time.RegularTimePeriod var18 = var16.next();
//     int var19 = var16.getMonth();
//     var15.delete((org.jfree.data.time.RegularTimePeriod)var16);
//     org.jfree.data.time.RegularTimePeriod var21 = var16.next();
//     java.lang.String var22 = var16.toString();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1.0f);
//     int var25 = var4.getItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var22 + "' != '" + "December 2014"+ "'", var22.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var0 = new org.jfree.data.general.DatasetGroup();
//     java.lang.Object var1 = var0.clone();
//     java.lang.String var2 = var0.getID();
//     java.lang.Object var3 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getPositiveItemLabelPositionFallback();
    boolean var5 = var2.isSeriesVisible(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var3 = null;
//     org.jfree.chart.util.Layer var4 = null;
//     boolean var5 = var0.removeDomainMarker(10, var3, var4);
//     java.lang.String var6 = var0.getNoDataMessage();
//     java.lang.String var7 = var0.getPlotType();
//     java.awt.Image var8 = null;
//     var0.setBackgroundImage(var8);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var15 = null;
//     var12.setDomainAxisLocation(1, var15);
//     boolean var17 = var12.isSubplot();
//     org.jfree.chart.plot.PlotRenderingInfo var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleAnchor var21 = null;
//     java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var20, var21);
//     var12.zoomRangeAxes(0.0d, var19, var22);
//     var0.zoomRangeAxes(1.0E-100d, var11, var22, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var12
//     assertTrue("Contract failed: equals-hashcode on var0 and var12", var0.equals(var12) ? var0.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var0
//     assertTrue("Contract failed: equals-hashcode on var12 and var0", var12.equals(var0) ? var12.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 10.0d);
//     var2.setRange(var5, false, true);
//     java.awt.Stroke var9 = var2.getMinorTickMarkStroke();
//     boolean var10 = var2.isMinorTickMarksVisible();
//     java.awt.Shape var11 = var2.getUpArrow();
//     org.jfree.data.time.RegularTimePeriod var12 = var2.getFirst();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.AxisState var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     int var18 = var16.getWeight();
//     boolean var19 = var16.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var21 = var20.getDomainZeroBaselineStroke();
//     java.awt.Paint var22 = var20.getDomainCrosshairPaint();
//     var16.setRangeGridlinePaint(var22);
//     var16.setDomainCrosshairVisible(true);
//     boolean var26 = var16.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var27 = var16.getDomainAxisEdge();
//     java.util.List var28 = var2.refreshTicks(var13, var14, var15, var27);
//     org.jfree.chart.renderer.PolarItemRenderer var29 = null;
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var29);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleAnchor var35 = null;
//     java.awt.geom.Point2D var36 = org.jfree.chart.util.RectangleAnchor.coordinates(var34, var35);
//     var30.zoomRangeAxes(2.0d, 8.64E7d, var33, var36);
// 
//   }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)"NOID");
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)10, (java.lang.Number)100, false);
    org.jfree.data.xy.XYSeries var9 = var2.createCopy(100, 0);
    double var10 = var2.getMinX();
    boolean var12 = var2.equals((java.lang.Object)(-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((java.lang.Number)8.64E7d, (java.lang.Number)10.0d);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var2 = var1.getLabelPaint();
//     var1.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var6 = null;
//     org.jfree.chart.urls.XYURLGenerator var7 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var6, var7);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var10 = null;
//     var9.setTimeline(var10);
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
//     var9.setAxisLineStroke(var13);
//     var8.setBaseStroke(var13, false);
//     var1.setAxisLineStroke(var13);
//     java.util.Date var18 = var1.getMinimumDate();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year(var18);
//     long var20 = var0.toTimelineValue(var18);
//     long var21 = var0.getSegmentsGroupSize();
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var23 = var22.getLabelPaint();
//     var22.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.XYURLGenerator var28 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var27, var28);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var31 = null;
//     var30.setTimeline(var31);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var34 = var33.getDomainZeroBaselineStroke();
//     var30.setAxisLineStroke(var34);
//     var29.setBaseStroke(var34, false);
//     var22.setAxisLineStroke(var34);
//     java.util.Date var39 = var22.getMinimumDate();
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var39);
//     var0.addException(var39);
//     
//     // Checks the contract:  equals-hashcode on var12 and var33
//     assertTrue("Contract failed: equals-hashcode on var12 and var33", var12.equals(var33) ? var12.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var12
//     assertTrue("Contract failed: equals-hashcode on var33 and var12", var33.equals(var12) ? var33.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getInstance();
    int var1 = var0.getMaximumFractionDigits();
    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D();
    var2.setHeight(100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedCharacterIterator var5 = var0.formatToCharacterIterator((java.lang.Object)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 3);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    var0.setDomainCrosshairVisible(true);
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    double var9 = var8.getStartAngle();
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    boolean var17 = var12.removeDomainMarker(10, var15, var16);
    java.awt.Paint var18 = var12.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var19 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var18);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var21 = var20.getLabelPaint();
    var19.setOutlinePaint(var21);
    var8.setLabelPaint(var21);
    java.awt.Stroke var24 = var8.getLabelOutlineStroke();
    var0.setRangeCrosshairStroke(var24);
    double var26 = var0.getDomainCrosshairValue();
    org.jfree.chart.plot.DatasetRenderingOrder var27 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 90.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var4 = new org.jfree.data.Range(1.0d, 10.0d);
//     var1.setRange(var4, false, true);
//     java.awt.Stroke var8 = var1.getMinorTickMarkStroke();
//     boolean var9 = var1.isMinorTickMarksVisible();
//     java.awt.Shape var10 = var1.getUpArrow();
//     org.jfree.data.time.RegularTimePeriod var11 = var1.getFirst();
//     java.util.Calendar var12 = null;
//     long var13 = var11.getMiddleMillisecond(var12);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("12/31/69 4:00 PM");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
    var0.setBarAlignmentFactor(1.0d);
    org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var4 = null;
    var3.setTimeline(var4);
    boolean var6 = var0.equals((java.lang.Object)var3);
    boolean var7 = var0.getAutoPopulateSeriesOutlineStroke();
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseNegativeItemLabelPosition(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = null;
    var0.setTimeline(var1);
    double var3 = var0.getFixedDimension();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var9 = var5.lookupLegendShape(100);
    var0.setUpArrow(var9);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
    org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
    var19.setRange(var22, false, true);
    java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
    boolean var27 = var19.isMinorTickMarksVisible();
    java.awt.Shape var28 = var19.getUpArrow();
    var17.setArea(var28);
    org.jfree.data.general.PieDataset var30 = null;
    var17.setDataset(var30);
    java.lang.Object var32 = var17.clone();
    var17.setSectionIndex(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
    int var3 = var2.getItemCount();
    java.util.Iterator var4 = var2.iterator();
    java.util.Iterator var5 = var2.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var4.removeDomainMarker(10, var7, var8);
    java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var13 = var12.getLabelPaint();
    var11.setOutlinePaint(var13);
    var1.setChartBackgroundPaint(var13);
    java.awt.Paint var16 = var1.getAxisLabelPaint();
    org.jfree.chart.plot.DrawingSupplier var17 = var1.getDrawingSupplier();
    java.awt.Paint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendBackgroundPaint(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     double var1 = var0.getContentXOffset();
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, (-1.0d), 0.0d);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.plot.MultiplePiePlot var10 = new org.jfree.chart.plot.MultiplePiePlot(var9);
//     org.jfree.chart.util.RectangleInsets var11 = var10.getInsets();
//     double var13 = var11.calculateRightInset(100.0d);
//     double var15 = var11.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var16 = new org.jfree.chart.util.Size2D();
//     var16.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var22.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var26 = var22.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     int var28 = var27.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     var29.setMinorTickMarkInsideLength(0.0f);
//     int var32 = var27.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var29);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.ColumnArrangement var37 = new org.jfree.chart.block.ColumnArrangement(var33, var34, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.FlowArrangement var42 = new org.jfree.chart.block.FlowArrangement(var38, var39, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var27, (org.jfree.chart.block.Arrangement)var37, (org.jfree.chart.block.Arrangement)var42);
//     org.jfree.chart.entity.TitleEntity var44 = new org.jfree.chart.entity.TitleEntity(var26, (org.jfree.chart.title.Title)var43);
//     org.jfree.chart.event.TitleChangeListener var45 = null;
//     var43.removeChangeListener(var45);
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var47.java2DToValue(0.0d, var49, var50);
//     java.awt.Shape var52 = var47.getRightArrow();
//     java.awt.Font var53 = var47.getLabelFont();
//     var43.setItemFont(var53);
//     org.jfree.chart.block.BlockFrame var55 = var43.getFrame();
//     org.jfree.chart.util.RectangleAnchor var56 = var43.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var57 = org.jfree.chart.util.RectangleAnchor.createRectangle(var16, (-3.0d), Double.NaN, var56);
//     java.awt.geom.Rectangle2D var60 = var11.createOutsetRectangle(var57, true, true);
//     var0.draw(var8, var57);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     java.util.List var2 = var1.getSeries();
//     org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1, false);
//     org.jfree.data.time.TimeSeries var6 = null;
//     org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var6);
//     java.util.List var8 = var7.getSeries();
//     org.jfree.data.general.DatasetGroup var9 = var7.getGroup();
//     org.jfree.data.Range var11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var7, false);
//     org.jfree.data.time.TimePeriodAnchor var12 = var7.getXPosition();
//     var1.setXPosition(var12);
//     
//     // Checks the contract:  equals-hashcode on var3 and var9
//     assertTrue("Contract failed: equals-hashcode on var3 and var9", var3.equals(var9) ? var3.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var3
//     assertTrue("Contract failed: equals-hashcode on var9 and var3", var9.equals(var3) ? var9.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
//     var5.setSeriesStroke(10, var8);
//     boolean var10 = var5.getShapesVisible();
//     boolean var11 = var5.getPlotArea();
//     java.awt.Shape var13 = var5.lookupSeriesShape(10);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var17 = null;
//     org.jfree.chart.util.Layer var18 = null;
//     boolean var19 = var14.removeDomainMarker(10, var17, var18);
//     java.lang.String var20 = var14.getNoDataMessage();
//     java.lang.String var21 = var14.getPlotType();
//     java.awt.Image var22 = null;
//     var14.setBackgroundImage(var22);
//     org.jfree.chart.StandardChartTheme var25 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var29 = var28.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var31 = null;
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var33 = var28.removeDomainMarker(10, var31, var32);
//     java.awt.Paint var34 = var28.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var34);
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var37 = var36.getLabelPaint();
//     var35.setOutlinePaint(var37);
//     var25.setChartBackgroundPaint(var37);
//     var14.setDomainCrosshairPaint(var37);
//     org.jfree.chart.plot.ValueMarker var42 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Stroke var43 = var42.getOutlineStroke();
//     org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
//     java.awt.Paint var48 = var46.getSeriesOutlinePaint(0);
//     org.jfree.chart.text.TextLine var51 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var52 = null;
//     var51.addFragment(var52);
//     org.jfree.chart.text.TextLine var55 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var56 = var55.getFirstTextFragment();
//     java.lang.String var57 = var56.getText();
//     var51.addFragment(var56);
//     java.awt.Paint var59 = var56.getPaint();
//     var46.setSeriesFillPaint(0, var59, false);
//     org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem("PieSection: 100, 1(21-December-2014)", "ThreadContext", "TitleEntity: tooltip = null", "RectangleConstraint[LengthConstraintType.FIXED: width=5.0, height=0.0]", var13, var37, var43, var59);
//     
//     // Checks the contract:  equals-hashcode on var7 and var28
//     assertTrue("Contract failed: equals-hashcode on var7 and var28", var7.equals(var28) ? var7.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var7
//     assertTrue("Contract failed: equals-hashcode on var28 and var7", var28.equals(var7) ? var28.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    org.jfree.chart.JFreeChart var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPieChart(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("NOID");
//     int var3 = var0.indexOf((java.lang.Object)var2);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot(var5);
//     org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
//     double var9 = var7.calculateRightInset(100.0d);
//     double var11 = var7.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var12 = new org.jfree.chart.util.Size2D();
//     var12.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var18.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var22 = var18.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     int var24 = var23.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis();
//     var25.setMinorTickMarkInsideLength(0.0f);
//     int var28 = var23.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var25);
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var34 = null;
//     org.jfree.chart.util.VerticalAlignment var35 = null;
//     org.jfree.chart.block.FlowArrangement var38 = new org.jfree.chart.block.FlowArrangement(var34, var35, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var39 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var23, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var38);
//     org.jfree.chart.entity.TitleEntity var40 = new org.jfree.chart.entity.TitleEntity(var22, (org.jfree.chart.title.Title)var39);
//     org.jfree.chart.event.TitleChangeListener var41 = null;
//     var39.removeChangeListener(var41);
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var43.java2DToValue(0.0d, var45, var46);
//     java.awt.Shape var48 = var43.getRightArrow();
//     java.awt.Font var49 = var43.getLabelFont();
//     var39.setItemFont(var49);
//     org.jfree.chart.block.BlockFrame var51 = var39.getFrame();
//     org.jfree.chart.util.RectangleAnchor var52 = var39.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var53 = org.jfree.chart.util.RectangleAnchor.createRectangle(var12, (-3.0d), Double.NaN, var52);
//     java.awt.geom.Rectangle2D var56 = var7.createOutsetRectangle(var53, true, true);
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.RectangleEdge var58 = var57.getRangeAxisEdge();
//     double var59 = var2.valueToJava2D(8.0d, var56, var58);
//     
//     // Checks the contract:  equals-hashcode on var23 and var57
//     assertTrue("Contract failed: equals-hashcode on var23 and var57", var23.equals(var57) ? var23.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var23
//     assertTrue("Contract failed: equals-hashcode on var57 and var23", var57.equals(var23) ? var57.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
//     org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var4 = null;
//     var3.setTimeline(var4);
//     double var6 = var3.getFixedDimension();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var12 = var8.lookupLegendShape(100);
//     var3.setUpArrow(var12);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.entity.PieSectionEntity var20 = new org.jfree.chart.entity.PieSectionEntity(var12, var14, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
//     org.jfree.chart.axis.PeriodAxis var22 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var25 = new org.jfree.data.Range(1.0d, 10.0d);
//     var22.setRange(var25, false, true);
//     java.awt.Stroke var29 = var22.getMinorTickMarkStroke();
//     boolean var30 = var22.isMinorTickMarksVisible();
//     java.awt.Shape var31 = var22.getUpArrow();
//     var20.setArea(var31);
//     var1.setLegendItemShape(var31);
//     org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var35 = null;
//     var34.setTimeline(var35);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var38 = var37.getDomainZeroBaselineStroke();
//     var34.setAxisLineStroke(var38);
//     var34.setMinorTickCount(100);
//     java.awt.Shape var42 = var34.getLeftArrow();
//     var1.setLegendItemShape(var42);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var45 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var47 = var45.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var49 = var45.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
//     int var51 = var50.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis();
//     var52.setMinorTickMarkInsideLength(0.0f);
//     int var55 = var50.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var52);
//     org.jfree.chart.util.HorizontalAlignment var56 = null;
//     org.jfree.chart.util.VerticalAlignment var57 = null;
//     org.jfree.chart.block.ColumnArrangement var60 = new org.jfree.chart.block.ColumnArrangement(var56, var57, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var61 = null;
//     org.jfree.chart.util.VerticalAlignment var62 = null;
//     org.jfree.chart.block.FlowArrangement var65 = new org.jfree.chart.block.FlowArrangement(var61, var62, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var66 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var50, (org.jfree.chart.block.Arrangement)var60, (org.jfree.chart.block.Arrangement)var65);
//     org.jfree.chart.entity.TitleEntity var67 = new org.jfree.chart.entity.TitleEntity(var49, (org.jfree.chart.title.Title)var66);
//     org.jfree.chart.util.RectangleAnchor var68 = var66.getLegendItemGraphicLocation();
//     java.awt.Shape var71 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var42, var68, 4.0d, 12.0d);
//     
//     // Checks the contract:  equals-hashcode on var10 and var47
//     assertTrue("Contract failed: equals-hashcode on var10 and var47", var10.equals(var47) ? var10.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var10
//     assertTrue("Contract failed: equals-hashcode on var47 and var10", var47.equals(var10) ? var47.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var50
//     assertTrue("Contract failed: equals-hashcode on var37 and var50", var37.equals(var50) ? var37.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var37
//     assertTrue("Contract failed: equals-hashcode on var50 and var37", var50.equals(var37) ? var50.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(0);
    org.jfree.chart.text.TextAnchor var5 = var4.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var6 = new org.jfree.chart.labels.ItemLabelPosition(var0, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var4 = null;
    var1.setDomainAxisLocation(1, var4);
    boolean var6 = var1.isSubplot();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var8.setStandardTickUnits(var11);
    var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
    boolean var15 = var0.hasListener((java.util.EventListener)var1);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = null;
    org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var18.java2DToValue(0.0d, var20, var21);
    var18.setNegativeArrowVisible(false);
    java.awt.geom.Rectangle2D var25 = null;
    java.awt.Paint var27 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
    java.awt.Paint var32 = var30.getSeriesOutlinePaint(0);
    java.awt.Stroke var36 = var30.getItemStroke(15, 12, false);
    var0.drawRangeLine(var16, var17, (org.jfree.chart.axis.ValueAxis)var18, var25, 10.0d, var27, var36);
    var18.setRange(1.0d, Double.NaN);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setRangeWithMargins(8.64E7d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var5 = var1.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     int var7 = var6.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.setMinorTickMarkInsideLength(0.0f);
//     int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
//     org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
//     org.jfree.chart.LegendItemSource[] var24 = var22.getSources();
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.block.RectangleConstraint var27 = null;
//     org.jfree.chart.util.Size2D var28 = var22.arrange(var26, var27);
//     boolean var29 = var22.isVisible();
//     org.jfree.chart.event.TitleChangeEvent var30 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var22);
//     org.jfree.chart.block.BlockContainer var31 = new org.jfree.chart.block.BlockContainer();
//     double var32 = var31.getContentXOffset();
//     double var33 = var31.getContentYOffset();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var35.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var39 = var35.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     int var41 = var40.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis();
//     var42.setMinorTickMarkInsideLength(0.0f);
//     int var45 = var40.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var42);
//     org.jfree.chart.util.HorizontalAlignment var46 = null;
//     org.jfree.chart.util.VerticalAlignment var47 = null;
//     org.jfree.chart.block.ColumnArrangement var50 = new org.jfree.chart.block.ColumnArrangement(var46, var47, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var51 = null;
//     org.jfree.chart.util.VerticalAlignment var52 = null;
//     org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var51, var52, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var40, (org.jfree.chart.block.Arrangement)var50, (org.jfree.chart.block.Arrangement)var55);
//     org.jfree.chart.entity.TitleEntity var57 = new org.jfree.chart.entity.TitleEntity(var39, (org.jfree.chart.title.Title)var56);
//     org.jfree.chart.LegendItemSource[] var58 = var56.getSources();
//     var31.add((org.jfree.chart.block.Block)var56);
//     var22.setWrapper(var31);
//     
//     // Checks the contract:  equals-hashcode on var3 and var37
//     assertTrue("Contract failed: equals-hashcode on var3 and var37", var3.equals(var37) ? var3.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var3
//     assertTrue("Contract failed: equals-hashcode on var37 and var3", var37.equals(var3) ? var37.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var40
//     assertTrue("Contract failed: equals-hashcode on var6 and var40", var6.equals(var40) ? var6.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var6
//     assertTrue("Contract failed: equals-hashcode on var40 and var6", var40.equals(var6) ? var40.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var50
//     assertTrue("Contract failed: equals-hashcode on var16 and var50", var16.equals(var50) ? var16.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var16
//     assertTrue("Contract failed: equals-hashcode on var50 and var16", var50.equals(var16) ? var50.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var55
//     assertTrue("Contract failed: equals-hashcode on var21 and var55", var21.equals(var55) ? var21.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var21
//     assertTrue("Contract failed: equals-hashcode on var55 and var21", var55.equals(var21) ? var55.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(15, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var4 = var2.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var6 = var2.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     int var8 = var7.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis();
//     var9.setMinorTickMarkInsideLength(0.0f);
//     int var12 = var7.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var9);
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var18 = null;
//     org.jfree.chart.util.VerticalAlignment var19 = null;
//     org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement(var18, var19, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var7, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var22);
//     org.jfree.chart.entity.TitleEntity var24 = new org.jfree.chart.entity.TitleEntity(var6, (org.jfree.chart.title.Title)var23);
//     org.jfree.chart.event.TitleChangeListener var25 = null;
//     var23.removeChangeListener(var25);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var27.java2DToValue(0.0d, var29, var30);
//     java.awt.Shape var32 = var27.getRightArrow();
//     java.awt.Font var33 = var27.getLabelFont();
//     var23.setItemFont(var33);
//     org.jfree.chart.renderer.category.BarRenderer3D var35 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var37 = var36.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var39 = null;
//     var36.setDomainAxisLocation(1, var39);
//     boolean var41 = var36.isSubplot();
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
//     var43.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var46 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var43.setStandardTickUnits(var46);
//     var36.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var43, true);
//     boolean var50 = var35.hasListener((java.util.EventListener)var36);
//     org.jfree.chart.urls.CategoryURLGenerator var51 = null;
//     var35.setBaseURLGenerator(var51);
//     double var53 = var35.getShadowYOffset();
//     boolean var54 = var35.getIncludeBaseInRange();
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot var56 = new org.jfree.chart.plot.PiePlot(var55);
//     boolean var57 = var56.getIgnoreZeroValues();
//     java.awt.Paint var58 = var56.getLabelLinkPaint();
//     var35.setBaseFillPaint(var58, false);
//     org.jfree.chart.text.TextMeasurer var62 = null;
//     org.jfree.chart.text.TextBlock var63 = org.jfree.chart.text.TextUtilities.createTextBlock("", var33, var58, 10.0f, var62);
//     org.jfree.data.time.TimeSeries var65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var66 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var67 = var66.getYear();
//     org.jfree.data.time.RegularTimePeriod var68 = var66.next();
//     int var69 = var66.getMonth();
//     var65.delete((org.jfree.data.time.RegularTimePeriod)var66);
//     java.beans.PropertyChangeListener var71 = null;
//     var65.removePropertyChangeListener(var71);
//     double var73 = var65.getMaxY();
//     var65.setDescription("");
//     var65.clear();
//     boolean var77 = var63.equals((java.lang.Object)var65);
//     org.jfree.chart.util.HorizontalAlignment var78 = var63.getLineAlignment();
//     java.lang.String var79 = var78.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 4.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var77 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var79 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var79.equals("HorizontalAlignment.CENTER"));
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var1 = var0.getLabelPaint();
    java.lang.String var2 = var0.getLabelToolTip();
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var3, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.xy.XYSeries var2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)1.0d, false);
    var2.add((java.lang.Number)(short)10, (java.lang.Number)100, false);
    org.jfree.data.xy.XYSeries var9 = var2.createCopy(100, 0);
    var2.add(0.0d, (java.lang.Number)1L, true);
    double var14 = var2.getMinY();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((java.lang.Number)0.0f, (java.lang.Number)90.0d);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    boolean var5 = var0.removeDomainMarker(10, var3, var4);
    java.awt.Paint var6 = var0.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var10 = null;
    var7.axisChanged(var10);
    var7.setDomainCrosshairVisible(true);
    org.jfree.chart.renderer.xy.XYAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
    org.jfree.chart.renderer.xy.XYItemRenderer[] var16 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var15};
    var7.setRenderers(var16);
    var0.setRenderers(var16);
    java.awt.Paint var19 = var0.getRangeMinorGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
//     java.lang.Object var1 = var0.clone();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.data.time.TimeSeries var3 = null;
//     org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
//     var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
//     org.jfree.data.xy.XYDatasetSelectionState var6 = var4.getSelectionState();
//     double var8 = var4.getDomainLowerBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var4.getXValue((-1), 12);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     long var3 = var2.getFirstMillisecond();
//     var1.add((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)(short)1);
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var9 = var8.getYear();
//     org.jfree.data.time.RegularTimePeriod var10 = var8.next();
//     int var11 = var8.getMonth();
//     var7.delete((org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.time.RegularTimePeriod var13 = var8.next();
//     java.lang.String var14 = var8.toString();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var8);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var17 = var16.getYear();
//     org.jfree.data.time.RegularTimePeriod var18 = var16.next();
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var16, "10^2.0", "TextAnchor.CENTER");
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month();
//     long var25 = var24.getFirstMillisecond();
//     var23.add((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)(short)1);
//     org.jfree.data.time.TimeSeries var29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var31 = var30.getYear();
//     org.jfree.data.time.RegularTimePeriod var32 = var30.next();
//     int var33 = var30.getMonth();
//     var29.delete((org.jfree.data.time.RegularTimePeriod)var30);
//     org.jfree.data.time.RegularTimePeriod var35 = var30.next();
//     java.lang.String var36 = var30.toString();
//     org.jfree.data.time.TimeSeriesDataItem var37 = var23.getDataItem((org.jfree.data.time.RegularTimePeriod)var30);
//     org.jfree.data.time.TimeSeriesDataItem var38 = var21.addOrUpdate(var37);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add(var37);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "December 2014"+ "'", var14.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "December 2014"+ "'", var36.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.PlotRenderingInfo var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     var0.zoomDomainAxes(90.0d, var3, var4);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var10 = var9.getDomainZeroBaselineStroke();
//     var7.setSeriesStroke(10, var10);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var7.getSeriesNegativeItemLabelPosition((-460));
//     int var14 = var0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getDatasetCount();
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
    var2.setMinorTickMarkInsideLength(0.0f);
    int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var11 = null;
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
    var10.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    boolean var5 = var0.removeDomainMarker(10, var3, var4);
    java.lang.String var6 = var0.getNoDataMessage();
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getDomainMarkers(var7);
    var0.setRangeZeroBaselineVisible(true);
    var0.setDomainMinorGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.setLabel("hi!");
    double var3 = var0.getUpperBound();
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var5 = null;
    var4.setTimeline(var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    var4.setAxisLineStroke(var8);
    java.awt.Shape var10 = var4.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var11 = var4.getTickUnit();
    var0.setTickUnit(var11);
    org.jfree.chart.axis.DateTickUnitType var13 = var11.getUnitType();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
    var15.setLabel("hi!");
    double var18 = var15.getUpperBound();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var20 = null;
    var19.setTimeline(var20);
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var23 = var22.getDomainZeroBaselineStroke();
    var19.setAxisLineStroke(var23);
    java.awt.Shape var25 = var19.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var26 = var19.getTickUnit();
    var15.setTickUnit(var26);
    org.jfree.chart.axis.DateTickUnitType var28 = var26.getUnitType();
    java.text.DateFormat var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var31 = new org.jfree.chart.axis.DateTickUnit(var13, 3, var28, 3, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var15);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     int var19 = var17.getWeight();
//     boolean var20 = var17.isRangeZeroBaselineVisible();
//     int var21 = var17.getBackgroundImageAlignment();
//     boolean var22 = var10.equals((java.lang.Object)var21);
//     
//     // Checks the contract:  equals-hashcode on var0 and var17
//     assertTrue("Contract failed: equals-hashcode on var0 and var17", var0.equals(var17) ? var0.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    int var4 = var0.indexOf((java.lang.Comparable)10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var0.getItemCount(15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    java.text.DateFormat var4 = var3.getXDateFormat();
    java.lang.String var5 = var3.getFormatString();
    java.text.DateFormat var6 = var3.getXDateFormat();
    org.jfree.data.xy.DefaultXYDataset var7 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var8 = var7.clone();
    java.lang.Object var9 = var7.clone();
    org.jfree.data.time.TimeSeries var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var10);
    var7.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var15 = var3.generateLabelString((org.jfree.data.xy.XYDataset)var7, 0, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.util.LogFormat var0 = new org.jfree.chart.util.LogFormat();
    java.lang.String var2 = var0.format(1417420800000L);
    boolean var3 = var0.isParseIntegerOnly();
    java.lang.String var5 = var0.format(100.0d);
    var0.setGroupingUsed(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.parse("XY Plot");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "10^12.15"+ "'", var2.equals("10^12.15"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "10^2.0"+ "'", var5.equals("10^2.0"));

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var1 = null;
    var0.setTimeline(var1);
    double var3 = var0.getFixedDimension();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var9 = var5.lookupLegendShape(100);
    var0.setUpArrow(var9);
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
    org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
    org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
    var19.setRange(var22, false, true);
    java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
    boolean var27 = var19.isMinorTickMarksVisible();
    java.awt.Shape var28 = var19.getUpArrow();
    var17.setArea(var28);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 0.12d, (-1.0f), 100.0f);
    org.jfree.chart.JFreeChart var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var37 = new org.jfree.chart.entity.JFreeChartEntity(var28, var34, "10^2.0", "10^2.0");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     double var3 = var0.getFixedDimension();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     var0.setUpArrow(var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
//     var19.setRange(var22, false, true);
//     java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
//     boolean var27 = var19.isMinorTickMarksVisible();
//     java.awt.Shape var28 = var19.getUpArrow();
//     var17.setArea(var28);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(10, var35, var36);
//     java.awt.Paint var38 = var32.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var38);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var39.setOutlinePaint(var41);
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var28, var41);
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var45 = var44.getLabelPaint();
//     var43.setOutlinePaint(var45);
//     org.jfree.chart.renderer.category.BarRenderer3D var47 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var49 = var48.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var51 = null;
//     var48.setDomainAxisLocation(1, var51);
//     boolean var53 = var48.isSubplot();
//     org.jfree.chart.axis.DateAxis var55 = new org.jfree.chart.axis.DateAxis();
//     var55.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var58 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var55.setStandardTickUnits(var58);
//     var48.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var55, true);
//     boolean var62 = var47.hasListener((java.util.EventListener)var48);
//     org.jfree.chart.urls.CategoryURLGenerator var63 = null;
//     var47.setBaseURLGenerator(var63);
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var66 = var65.getDomainZeroBaselineStroke();
//     java.awt.Paint var67 = var65.getDomainCrosshairPaint();
//     var47.setBaseLegendTextPaint(var67);
//     var43.setFillPaint(var67);
//     
//     // Checks the contract:  equals-hashcode on var32 and var65
//     assertTrue("Contract failed: equals-hashcode on var32 and var65", var32.equals(var65) ? var32.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var32
//     assertTrue("Contract failed: equals-hashcode on var65 and var32", var65.equals(var32) ? var65.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var4.removeDomainMarker(10, var7, var8);
    java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var13 = var12.getLabelPaint();
    var11.setOutlinePaint(var13);
    var1.setChartBackgroundPaint(var13);
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.renderer.category.GradientBarPainter var20 = new org.jfree.chart.renderer.category.GradientBarPainter(0.0d, 100.0d, 10.0d);
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter((org.jfree.chart.renderer.category.BarPainter)var20);
    var16.setBarPainter((org.jfree.chart.renderer.category.BarPainter)var20);
    var1.setBarPainter((org.jfree.chart.renderer.category.BarPainter)var20);
    boolean var24 = var1.isShadowVisible();
    java.awt.Paint var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemPaint(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);

  }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.chart.axis.PeriodAxis var1 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var4 = new org.jfree.data.Range(1.0d, 10.0d);
//     var1.setRange(var4, false, true);
//     java.awt.Stroke var8 = var1.getMinorTickMarkStroke();
//     boolean var9 = var1.isMinorTickMarksVisible();
//     java.awt.Shape var10 = var1.getUpArrow();
//     org.jfree.data.time.RegularTimePeriod var11 = var1.getFirst();
//     org.jfree.data.Range var12 = var1.getDefaultAutoRange();
//     org.jfree.data.Range var13 = null;
//     var1.setRange(var13, false, true);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Stroke var2 = var1.getStroke();
    var1.setValue(0.0d);
    java.awt.Stroke var5 = var1.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var3 = var2.getDomainZeroBaselineStroke();
    int var4 = var2.getWeight();
    boolean var5 = var2.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var7 = var6.getDomainZeroBaselineStroke();
    java.awt.Paint var8 = var6.getDomainCrosshairPaint();
    var2.setRangeGridlinePaint(var8);
    var1.setLabelBackgroundPaint(var8);
    var1.setLabelLinksVisible(false);
    var1.setIgnoreNullValues(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    java.util.List var2 = var1.getSeries();
    org.jfree.data.general.DatasetGroup var4 = new org.jfree.data.general.DatasetGroup("{0}: ({1}, {2})");
    var1.setGroup(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var9 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var1, 1, 0.0d, 5.5d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    var0.setSeriesShapesVisible(10, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    boolean var4 = var0.getItemShapeFilled(1, 4);
    var0.setUseFillPaint(false);
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var8 = null;
    var7.setTimeline(var8);
    double var10 = var7.getFixedDimension();
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var14 = var12.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var16 = var12.lookupLegendShape(100);
    var7.setUpArrow(var16);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.entity.PieSectionEntity var24 = new org.jfree.chart.entity.PieSectionEntity(var16, var18, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
    org.jfree.chart.axis.PeriodAxis var26 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
    org.jfree.data.Range var29 = new org.jfree.data.Range(1.0d, 10.0d);
    var26.setRange(var29, false, true);
    java.awt.Stroke var33 = var26.getMinorTickMarkStroke();
    boolean var34 = var26.isMinorTickMarksVisible();
    java.awt.Shape var35 = var26.getUpArrow();
    var24.setArea(var35);
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var40 = var39.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var42 = null;
    org.jfree.chart.util.Layer var43 = null;
    boolean var44 = var39.removeDomainMarker(10, var42, var43);
    java.awt.Paint var45 = var39.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var46 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var45);
    org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var48 = var47.getLabelPaint();
    var46.setOutlinePaint(var48);
    org.jfree.chart.title.LegendGraphic var50 = new org.jfree.chart.title.LegendGraphic(var35, var48);
    var0.setLegendLine(var35);
    boolean var54 = var0.getItemShapeVisible(100, 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    java.lang.Object var0 = null;
    org.jfree.data.xy.DefaultXYDataset var1 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var2 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DatasetChangeEvent var3 = new org.jfree.data.general.DatasetChangeEvent(var0, (org.jfree.data.general.Dataset)var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(90.0d, "hi!", "Size2D[width=0.0, height=0.0]", true);
    var4.setMinimumIntegerDigits(1969);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Currency var7 = var4.getCurrency();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }

  }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var2 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var6 = var5.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var8 = null;
//     org.jfree.chart.util.Layer var9 = null;
//     boolean var10 = var5.removeDomainMarker(10, var8, var9);
//     java.awt.Paint var11 = var5.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var12 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var11);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var14 = var13.getLabelPaint();
//     var12.setOutlinePaint(var14);
//     var2.setChartBackgroundPaint(var14);
//     java.awt.Font var17 = var2.getRegularFont();
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("index.html?series=15&amp;item=-460", var17);
//     java.awt.Paint var19 = var18.getBackgroundPaint();
//     boolean var20 = var18.isVisible();
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var22 = var21.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var24 = null;
//     org.jfree.chart.util.Layer var25 = null;
//     boolean var26 = var21.removeDomainMarker(10, var24, var25);
//     java.lang.String var27 = var21.getNoDataMessage();
//     java.lang.String var28 = var21.getPlotType();
//     java.awt.Image var29 = null;
//     var21.setBackgroundImage(var29);
//     org.jfree.chart.StandardChartTheme var32 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var36 = var35.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var38 = null;
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var35.removeDomainMarker(10, var38, var39);
//     java.awt.Paint var41 = var35.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var41);
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var44 = var43.getLabelPaint();
//     var42.setOutlinePaint(var44);
//     var32.setChartBackgroundPaint(var44);
//     var21.setDomainCrosshairPaint(var44);
//     var18.setPaint(var44);
//     
//     // Checks the contract:  equals-hashcode on var2 and var32
//     assertTrue("Contract failed: equals-hashcode on var2 and var32", var2.equals(var32) ? var2.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var2
//     assertTrue("Contract failed: equals-hashcode on var32 and var2", var32.equals(var2) ? var32.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var35
//     assertTrue("Contract failed: equals-hashcode on var5 and var35", var5.equals(var35) ? var5.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var5
//     assertTrue("Contract failed: equals-hashcode on var35 and var5", var35.equals(var5) ? var35.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var42
//     assertTrue("Contract failed: equals-hashcode on var12 and var42", var12.equals(var42) ? var12.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var12
//     assertTrue("Contract failed: equals-hashcode on var42 and var12", var42.equals(var12) ? var42.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = new org.jfree.chart.util.Size2D();
//     var3.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var13 = var9.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     int var15 = var14.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
//     var16.setMinorTickMarkInsideLength(0.0f);
//     int var19 = var14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var16);
//     org.jfree.chart.util.HorizontalAlignment var20 = null;
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.FlowArrangement var29 = new org.jfree.chart.block.FlowArrangement(var25, var26, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var14, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var29);
//     org.jfree.chart.entity.TitleEntity var31 = new org.jfree.chart.entity.TitleEntity(var13, (org.jfree.chart.title.Title)var30);
//     org.jfree.chart.event.TitleChangeListener var32 = null;
//     var30.removeChangeListener(var32);
//     org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var34.java2DToValue(0.0d, var36, var37);
//     java.awt.Shape var39 = var34.getRightArrow();
//     java.awt.Font var40 = var34.getLabelFont();
//     var30.setItemFont(var40);
//     org.jfree.chart.block.BlockFrame var42 = var30.getFrame();
//     org.jfree.chart.util.RectangleAnchor var43 = var30.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.util.RectangleAnchor.createRectangle(var3, (-3.0d), Double.NaN, var43);
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var46 = var45.getDomainZeroBaselineStroke();
//     java.awt.Paint var47 = var45.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var48 = null;
//     var45.axisChanged(var48);
//     org.jfree.chart.JFreeChart var50 = null;
//     org.jfree.chart.event.ChartChangeEvent var51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var45, var50);
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var53 = new org.jfree.chart.renderer.xy.XYItemRendererState(var52);
//     org.jfree.data.xy.XYDatasetSelectionState var54 = var53.getSelectionState();
//     int var55 = var53.getLastItemIndex();
//     org.jfree.chart.plot.XYCrosshairState var56 = var53.getCrosshairState();
//     org.jfree.data.time.TimeSeries var57 = null;
//     org.jfree.data.time.TimeSeriesCollection var58 = new org.jfree.data.time.TimeSeriesCollection(var57);
//     java.util.List var59 = var58.getSeries();
//     var53.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var58);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var62 = var1.initialise(var2, var44, var45, (org.jfree.data.xy.XYDataset)var58, var61);
//     
//     // Checks the contract:  equals-hashcode on var14 and var45
//     assertTrue("Contract failed: equals-hashcode on var14 and var45", var14.equals(var45) ? var14.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var14
//     assertTrue("Contract failed: equals-hashcode on var45 and var14", var45.equals(var14) ? var45.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     var0.setLowerMargin(0.0d);
//     var0.setMaximumCategoryLabelWidthRatio(2.0f);
//     int var5 = var0.getMaximumCategoryLabelLines();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot(var11);
//     org.jfree.chart.util.RectangleInsets var13 = var12.getInsets();
//     double var15 = var13.calculateRightInset(100.0d);
//     double var17 = var13.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var18 = new org.jfree.chart.util.Size2D();
//     var18.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var28 = var24.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     int var30 = var29.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     var31.setMinorTickMarkInsideLength(0.0f);
//     int var34 = var29.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var31);
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.ColumnArrangement var39 = new org.jfree.chart.block.ColumnArrangement(var35, var36, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var40 = null;
//     org.jfree.chart.util.VerticalAlignment var41 = null;
//     org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement(var40, var41, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var29, (org.jfree.chart.block.Arrangement)var39, (org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.entity.TitleEntity var46 = new org.jfree.chart.entity.TitleEntity(var28, (org.jfree.chart.title.Title)var45);
//     org.jfree.chart.event.TitleChangeListener var47 = null;
//     var45.removeChangeListener(var47);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.util.RectangleEdge var52 = null;
//     double var53 = var49.java2DToValue(0.0d, var51, var52);
//     java.awt.Shape var54 = var49.getRightArrow();
//     java.awt.Font var55 = var49.getLabelFont();
//     var45.setItemFont(var55);
//     org.jfree.chart.block.BlockFrame var57 = var45.getFrame();
//     org.jfree.chart.util.RectangleAnchor var58 = var45.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var59 = org.jfree.chart.util.RectangleAnchor.createRectangle(var18, (-3.0d), Double.NaN, var58);
//     java.awt.geom.Rectangle2D var62 = var13.createOutsetRectangle(var59, true, true);
//     org.jfree.chart.axis.AxisSpace var63 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var66 = var65.getDomainZeroBaselineStroke();
//     int var67 = var65.getWeight();
//     boolean var68 = var65.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var70 = var69.getDomainZeroBaselineStroke();
//     java.awt.Paint var71 = var69.getDomainCrosshairPaint();
//     var65.setRangeGridlinePaint(var71);
//     var65.setDomainCrosshairVisible(true);
//     boolean var75 = var65.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var76 = var65.getDomainAxisEdge();
//     var63.add(5.5d, var76);
//     double var78 = var0.getCategorySeriesMiddle((-460), 10, 100, 1, 10.0d, var59, var76);
//     
//     // Checks the contract:  equals-hashcode on var29 and var69
//     assertTrue("Contract failed: equals-hashcode on var29 and var69", var29.equals(var69) ? var29.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var29
//     assertTrue("Contract failed: equals-hashcode on var69 and var29", var69.equals(var29) ? var69.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.XYURLGenerator var2 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, var2);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var8 = var6.getSeriesNegativeItemLabelPosition(0);
//     var3.setSeriesNegativeItemLabelPosition(100, var8);
//     java.awt.Font var11 = var3.getLegendTextFont(1);
//     org.jfree.chart.labels.ItemLabelPosition var12 = var3.getBaseNegativeItemLabelPosition();
//     
//     // Checks the contract:  equals-hashcode on var8 and var12
//     assertTrue("Contract failed: equals-hashcode on var8 and var12", var8.equals(var12) ? var8.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var8
//     assertTrue("Contract failed: equals-hashcode on var12 and var8", var12.equals(var8) ? var12.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("Size2D[width=0.0, height=0.0]");
//     org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat();
//     var3.setMaximumFractionDigits(10);
//     int var6 = var3.getMaximumFractionDigits();
//     org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit((-1.0d), (java.text.NumberFormat)var3);
//     var1.setTickUnit(var7, true, false);
//     java.awt.Paint var11 = var1.getTickLabelPaint();
//     var1.zoomRange(0.0d, 0.08d);
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
//     var17.setLowerMargin(0.0d);
//     var17.setMaximumCategoryLabelWidthRatio(2.0f);
//     var17.setUpperMargin(Double.POSITIVE_INFINITY);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var28 = var27.getDomainZeroBaselineStroke();
//     int var29 = var27.getWeight();
//     boolean var30 = var27.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var32 = var31.getDomainZeroBaselineStroke();
//     java.awt.Paint var33 = var31.getDomainCrosshairPaint();
//     var27.setRangeGridlinePaint(var33);
//     boolean var35 = var27.isRangeZoomable();
//     org.jfree.chart.util.RectangleEdge var36 = var27.getDomainAxisEdge();
//     org.jfree.chart.axis.AxisState var37 = null;
//     var17.drawTickMarks(var24, 8.0d, var26, var36, var37);
//     double var39 = var1.java2DToValue((-3.0d), var16, var36);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'4');
//     double var2 = var1.getMaxY();
//     var1.add(100.0d, 1.0E-100d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var0 = new org.jfree.chart.renderer.category.BarRenderer3D();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var4 = null;
//     var1.setDomainAxisLocation(1, var4);
//     boolean var6 = var1.isSubplot();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.centerRange(10.0d);
//     org.jfree.chart.axis.TickUnitSource var11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//     var8.setStandardTickUnits(var11);
//     var1.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var8, true);
//     boolean var15 = var0.hasListener((java.util.EventListener)var1);
//     org.jfree.chart.urls.CategoryURLGenerator var16 = null;
//     var0.setBaseURLGenerator(var16);
//     org.jfree.chart.StandardChartTheme var20 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var26 = null;
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var23.removeDomainMarker(10, var26, var27);
//     java.awt.Paint var29 = var23.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var29);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var32 = var31.getLabelPaint();
//     var30.setOutlinePaint(var32);
//     var20.setChartBackgroundPaint(var32);
//     java.awt.Paint var35 = var20.getAxisLabelPaint();
//     var0.setSeriesOutlinePaint(0, var35, false);
//     var0.setBaseSeriesVisible(false);
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var45 = var44.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var47 = null;
//     org.jfree.chart.util.Layer var48 = null;
//     boolean var49 = var44.removeDomainMarker(10, var47, var48);
//     java.awt.Paint var50 = var44.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var51 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var50);
//     java.awt.Paint var52 = var51.getLabelPaint();
//     org.jfree.chart.plot.IntervalMarker var53 = new org.jfree.chart.plot.IntervalMarker(90.0d, 10.0d, var52);
//     boolean var54 = var0.equals((java.lang.Object)90.0d);
//     
//     // Checks the contract:  equals-hashcode on var23 and var44
//     assertTrue("Contract failed: equals-hashcode on var23 and var44", var23.equals(var44) ? var23.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var23
//     assertTrue("Contract failed: equals-hashcode on var44 and var23", var44.equals(var23) ? var44.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("Size2D[width=0.0, height=0.0]", "ThreadContext", "", var3, "", "ThreadContext", "ThreadContext");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.util.List var10 = null;
    var7.setContributors(var10);
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("Size2D[width=0.0, height=0.0]", "ThreadContext", "", var15, "", "ThreadContext", "ThreadContext");
    java.util.List var20 = null;
    var19.setContributors(var20);
    java.util.List var22 = null;
    var19.setContributors(var22);
    var19.setCopyright("XY Plot");
    var7.addOptionalLibrary((org.jfree.chart.ui.Library)var19);
    org.jfree.chart.ui.Library[] var27 = var19.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Image var5 = null;
    var0.setBackgroundImage(var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    var0.setDomainZeroBaselinePaint(var9);
    java.awt.Paint var11 = var0.getDomainGridlinePaint();
    java.awt.Paint var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlinePaint(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    java.lang.Object var1 = var0.clone();
    java.lang.Object var2 = var0.clone();
    org.jfree.data.time.TimeSeries var3 = null;
    org.jfree.data.time.TimeSeriesCollection var4 = new org.jfree.data.time.TimeSeriesCollection(var3);
    var0.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var9 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset)var0, 1, 100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    java.util.List var2 = var1.getSeries();
    org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var1, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var1.getX(1, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    java.util.TimeZone var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = var1.getBaseSectionOutlinePaint();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
//     var5.setSeriesStroke(10, var8);
//     boolean var10 = var5.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var5.getBasePositiveItemLabelPosition();
//     java.awt.Paint var13 = var5.lookupSeriesOutlinePaint(0);
//     var1.setSectionPaint((java.lang.Comparable)true, var13);
//     org.jfree.chart.util.RectangleInsets var15 = var1.getLabelPadding();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.plot.MultiplePiePlot var17 = new org.jfree.chart.plot.MultiplePiePlot(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var17.getInsets();
//     double var20 = var18.calculateRightInset(100.0d);
//     double var22 = var18.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var23 = new org.jfree.chart.util.Size2D();
//     var23.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var31 = var29.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var33 = var29.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     int var35 = var34.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     var36.setMinorTickMarkInsideLength(0.0f);
//     int var39 = var34.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var36);
//     org.jfree.chart.util.HorizontalAlignment var40 = null;
//     org.jfree.chart.util.VerticalAlignment var41 = null;
//     org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var45 = null;
//     org.jfree.chart.util.VerticalAlignment var46 = null;
//     org.jfree.chart.block.FlowArrangement var49 = new org.jfree.chart.block.FlowArrangement(var45, var46, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var49);
//     org.jfree.chart.entity.TitleEntity var51 = new org.jfree.chart.entity.TitleEntity(var33, (org.jfree.chart.title.Title)var50);
//     org.jfree.chart.event.TitleChangeListener var52 = null;
//     var50.removeChangeListener(var52);
//     org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var56 = null;
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var54.java2DToValue(0.0d, var56, var57);
//     java.awt.Shape var59 = var54.getRightArrow();
//     java.awt.Font var60 = var54.getLabelFont();
//     var50.setItemFont(var60);
//     org.jfree.chart.block.BlockFrame var62 = var50.getFrame();
//     org.jfree.chart.util.RectangleAnchor var63 = var50.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var64 = org.jfree.chart.util.RectangleAnchor.createRectangle(var23, (-3.0d), Double.NaN, var63);
//     java.awt.geom.Rectangle2D var67 = var18.createOutsetRectangle(var64, true, true);
//     java.awt.geom.Rectangle2D var70 = var15.createInsetRectangle(var67, true, false);
//     
//     // Checks the contract:  equals-hashcode on var29 and var5
//     assertTrue("Contract failed: equals-hashcode on var29 and var5", var29.equals(var5) ? var29.hashCode() == var5.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var5.", var29.equals(var5) == var5.equals(var29));
//     
//     // Checks the contract:  equals-hashcode on var7 and var34
//     assertTrue("Contract failed: equals-hashcode on var7 and var34", var7.equals(var34) ? var7.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var7
//     assertTrue("Contract failed: equals-hashcode on var34 and var7", var34.equals(var7) ? var34.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)'4');
//     double var2 = var1.getMaxY();
//     org.jfree.data.xy.XYSeries var5 = var1.createCopy((-460), (-460));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.xy.XYDataItem var7 = var1.getDataItem((-1));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(15);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
//     org.jfree.chart.labels.XYToolTipGenerator var4 = null;
//     org.jfree.chart.urls.XYURLGenerator var5 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var4, var5);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var11 = var9.getSeriesNegativeItemLabelPosition(0);
//     var6.setSeriesNegativeItemLabelPosition(100, var11);
//     var6.setOutline(true);
//     boolean var15 = var2.equals((java.lang.Object)true);
//     org.jfree.chart.LegendItemCollection var16 = null;
//     var2.addAll(var16);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
//     double var1 = var0.getLowerMargin();
//     double var2 = var0.getSmallestValue();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.AxisState var4 = null;
//     org.jfree.chart.util.Size2D var5 = new org.jfree.chart.util.Size2D();
//     var5.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var15 = var11.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     int var17 = var16.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     var18.setMinorTickMarkInsideLength(0.0f);
//     int var21 = var16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.FlowArrangement var31 = new org.jfree.chart.block.FlowArrangement(var27, var28, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var26, (org.jfree.chart.block.Arrangement)var31);
//     org.jfree.chart.entity.TitleEntity var33 = new org.jfree.chart.entity.TitleEntity(var15, (org.jfree.chart.title.Title)var32);
//     org.jfree.chart.event.TitleChangeListener var34 = null;
//     var32.removeChangeListener(var34);
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var36.java2DToValue(0.0d, var38, var39);
//     java.awt.Shape var41 = var36.getRightArrow();
//     java.awt.Font var42 = var36.getLabelFont();
//     var32.setItemFont(var42);
//     org.jfree.chart.block.BlockFrame var44 = var32.getFrame();
//     org.jfree.chart.util.RectangleAnchor var45 = var32.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var5, (-3.0d), Double.NaN, var45);
//     org.jfree.chart.axis.AxisSpace var47 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var50 = var49.getDomainZeroBaselineStroke();
//     int var51 = var49.getWeight();
//     boolean var52 = var49.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var54 = var53.getDomainZeroBaselineStroke();
//     java.awt.Paint var55 = var53.getDomainCrosshairPaint();
//     var49.setRangeGridlinePaint(var55);
//     var49.setDomainCrosshairVisible(true);
//     boolean var59 = var49.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var60 = var49.getDomainAxisEdge();
//     var47.add(5.5d, var60);
//     java.util.List var62 = var0.refreshTicks(var3, var4, var46, var60);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 1.0f);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.setLabel("hi!");
    double var3 = var0.getUpperBound();
    org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.Timeline var5 = null;
    var4.setTimeline(var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    var4.setAxisLineStroke(var8);
    java.awt.Shape var10 = var4.getLeftArrow();
    org.jfree.chart.axis.DateTickUnit var11 = var4.getTickUnit();
    var0.setTickUnit(var11);
    org.jfree.chart.axis.DateTickUnitType var13 = var11.getUnitType();
    org.jfree.chart.axis.DateTickUnitType var15 = null;
    java.text.DateFormat var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var18 = new org.jfree.chart.axis.DateTickUnit(var13, 15, var15, 0, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var5 = var1.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     int var7 = var6.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.setMinorTickMarkInsideLength(0.0f);
//     int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
//     org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
//     org.jfree.chart.LegendItemSource[] var24 = var22.getSources();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.util.Size2D var26 = var22.arrange(var25);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var30 = var28.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var32 = var28.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot();
//     int var34 = var33.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var35 = new org.jfree.chart.axis.DateAxis();
//     var35.setMinorTickMarkInsideLength(0.0f);
//     int var38 = var33.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var35);
//     org.jfree.chart.util.HorizontalAlignment var39 = null;
//     org.jfree.chart.util.VerticalAlignment var40 = null;
//     org.jfree.chart.block.ColumnArrangement var43 = new org.jfree.chart.block.ColumnArrangement(var39, var40, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var44 = null;
//     org.jfree.chart.util.VerticalAlignment var45 = null;
//     org.jfree.chart.block.FlowArrangement var48 = new org.jfree.chart.block.FlowArrangement(var44, var45, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var49 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var33, (org.jfree.chart.block.Arrangement)var43, (org.jfree.chart.block.Arrangement)var48);
//     org.jfree.chart.entity.TitleEntity var50 = new org.jfree.chart.entity.TitleEntity(var32, (org.jfree.chart.title.Title)var49);
//     org.jfree.chart.util.RectangleAnchor var51 = var49.getLegendItemGraphicLocation();
//     var22.setLegendItemGraphicLocation(var51);
//     
//     // Checks the contract:  equals-hashcode on var3 and var30
//     assertTrue("Contract failed: equals-hashcode on var3 and var30", var3.equals(var30) ? var3.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var3
//     assertTrue("Contract failed: equals-hashcode on var30 and var3", var30.equals(var3) ? var30.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var33
//     assertTrue("Contract failed: equals-hashcode on var6 and var33", var6.equals(var33) ? var6.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var6
//     assertTrue("Contract failed: equals-hashcode on var33 and var6", var33.equals(var6) ? var33.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var43
//     assertTrue("Contract failed: equals-hashcode on var16 and var43", var16.equals(var43) ? var16.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var16
//     assertTrue("Contract failed: equals-hashcode on var43 and var16", var43.equals(var16) ? var43.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var48
//     assertTrue("Contract failed: equals-hashcode on var21 and var48", var21.equals(var48) ? var21.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var21
//     assertTrue("Contract failed: equals-hashcode on var48 and var21", var48.equals(var21) ? var48.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var5 = var1.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    int var7 = var6.getDatasetCount();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
    var8.setMinorTickMarkInsideLength(0.0f);
    int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var17 = null;
    org.jfree.chart.util.VerticalAlignment var18 = null;
    org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
    org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
    java.lang.String var24 = var23.getToolTipText();
    org.jfree.chart.title.Title var25 = var23.getTitle();
    var25.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     var0.setBottom(100.0d);
//     org.jfree.data.category.CategoryDataset var3 = null;
//     org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot(var3);
//     org.jfree.chart.util.RectangleInsets var5 = var4.getInsets();
//     double var7 = var5.calculateRightInset(100.0d);
//     double var9 = var5.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D();
//     var10.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var20 = var16.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     int var22 = var21.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis();
//     var23.setMinorTickMarkInsideLength(0.0f);
//     int var26 = var21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement(var32, var33, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var21, (org.jfree.chart.block.Arrangement)var31, (org.jfree.chart.block.Arrangement)var36);
//     org.jfree.chart.entity.TitleEntity var38 = new org.jfree.chart.entity.TitleEntity(var20, (org.jfree.chart.title.Title)var37);
//     org.jfree.chart.event.TitleChangeListener var39 = null;
//     var37.removeChangeListener(var39);
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var41.java2DToValue(0.0d, var43, var44);
//     java.awt.Shape var46 = var41.getRightArrow();
//     java.awt.Font var47 = var41.getLabelFont();
//     var37.setItemFont(var47);
//     org.jfree.chart.block.BlockFrame var49 = var37.getFrame();
//     org.jfree.chart.util.RectangleAnchor var50 = var37.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var51 = org.jfree.chart.util.RectangleAnchor.createRectangle(var10, (-3.0d), Double.NaN, var50);
//     java.awt.geom.Rectangle2D var54 = var5.createOutsetRectangle(var51, true, true);
//     org.jfree.chart.util.Size2D var55 = new org.jfree.chart.util.Size2D();
//     var55.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var61 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var63 = var61.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var65 = var61.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot();
//     int var67 = var66.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var68 = new org.jfree.chart.axis.DateAxis();
//     var68.setMinorTickMarkInsideLength(0.0f);
//     int var71 = var66.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var68);
//     org.jfree.chart.util.HorizontalAlignment var72 = null;
//     org.jfree.chart.util.VerticalAlignment var73 = null;
//     org.jfree.chart.block.ColumnArrangement var76 = new org.jfree.chart.block.ColumnArrangement(var72, var73, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var77 = null;
//     org.jfree.chart.util.VerticalAlignment var78 = null;
//     org.jfree.chart.block.FlowArrangement var81 = new org.jfree.chart.block.FlowArrangement(var77, var78, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var82 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var66, (org.jfree.chart.block.Arrangement)var76, (org.jfree.chart.block.Arrangement)var81);
//     org.jfree.chart.entity.TitleEntity var83 = new org.jfree.chart.entity.TitleEntity(var65, (org.jfree.chart.title.Title)var82);
//     org.jfree.chart.event.TitleChangeListener var84 = null;
//     var82.removeChangeListener(var84);
//     org.jfree.chart.axis.DateAxis var86 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var88 = null;
//     org.jfree.chart.util.RectangleEdge var89 = null;
//     double var90 = var86.java2DToValue(0.0d, var88, var89);
//     java.awt.Shape var91 = var86.getRightArrow();
//     java.awt.Font var92 = var86.getLabelFont();
//     var82.setItemFont(var92);
//     org.jfree.chart.block.BlockFrame var94 = var82.getFrame();
//     org.jfree.chart.util.RectangleAnchor var95 = var82.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var96 = org.jfree.chart.util.RectangleAnchor.createRectangle(var55, (-3.0d), Double.NaN, var95);
//     java.awt.geom.Rectangle2D var97 = var0.expand(var51, var96);
//     
//     // Checks the contract:  equals-hashcode on var10 and var55
//     assertTrue("Contract failed: equals-hashcode on var10 and var55", var10.equals(var55) ? var10.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var10
//     assertTrue("Contract failed: equals-hashcode on var55 and var10", var55.equals(var10) ? var55.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var63
//     assertTrue("Contract failed: equals-hashcode on var18 and var63", var18.equals(var63) ? var18.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var18
//     assertTrue("Contract failed: equals-hashcode on var63 and var18", var63.equals(var18) ? var63.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var66
//     assertTrue("Contract failed: equals-hashcode on var21 and var66", var21.equals(var66) ? var21.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var21
//     assertTrue("Contract failed: equals-hashcode on var66 and var21", var66.equals(var21) ? var66.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var76
//     assertTrue("Contract failed: equals-hashcode on var31 and var76", var31.equals(var76) ? var31.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var31
//     assertTrue("Contract failed: equals-hashcode on var76 and var31", var76.equals(var31) ? var76.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var81
//     assertTrue("Contract failed: equals-hashcode on var36 and var81", var36.equals(var81) ? var36.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var36
//     assertTrue("Contract failed: equals-hashcode on var81 and var36", var81.equals(var36) ? var81.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     int var11 = var10.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
//     var12.setMinorTickMarkInsideLength(0.0f);
//     int var15 = var10.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var12);
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.ColumnArrangement var20 = new org.jfree.chart.block.ColumnArrangement(var16, var17, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.FlowArrangement var25 = new org.jfree.chart.block.FlowArrangement(var21, var22, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var26 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var10, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var25);
//     org.jfree.chart.entity.TitleEntity var27 = new org.jfree.chart.entity.TitleEntity(var9, (org.jfree.chart.title.Title)var26);
//     org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var9);
//     org.jfree.chart.entity.LegendItemEntity var29 = new org.jfree.chart.entity.LegendItemEntity(var9);
//     org.jfree.chart.plot.XYPlot var30 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var31 = var30.getDomainZeroBaselineStroke();
//     java.awt.Paint var32 = var30.getDomainCrosshairPaint();
//     org.jfree.chart.event.AxisChangeEvent var33 = null;
//     var30.axisChanged(var33);
//     java.awt.Image var35 = null;
//     var30.setBackgroundImage(var35);
//     var30.setRangePannable(true);
//     java.awt.Stroke var39 = var30.getOutlineStroke();
//     java.awt.Paint var40 = null;
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("SerialDate.weekInMonthToString(): invalid code.", "TitleEntity: tooltip = null", "10^3.3", "12/31/69 4:00 PM", var9, var39, var40);
//     
//     // Checks the contract:  equals-hashcode on var10 and var30
//     assertTrue("Contract failed: equals-hashcode on var10 and var30", var10.equals(var30) ? var10.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var10
//     assertTrue("Contract failed: equals-hashcode on var30 and var10", var30.equals(var10) ? var30.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    boolean var1 = var0.getUseOutlinePaint();
    boolean var4 = var0.getItemShapeFilled(1, 4);
    var0.setUseFillPaint(false);
    boolean var7 = var0.getUseFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesLinesVisible(2147483647, true);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var1 = null;
//     var0.setTimeline(var1);
//     double var3 = var0.getFixedDimension();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var9 = var5.lookupLegendShape(100);
//     var0.setUpArrow(var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.entity.PieSectionEntity var17 = new org.jfree.chart.entity.PieSectionEntity(var9, var11, 100, 1, (java.lang.Comparable)"21-December-2014", "10^12.15", "XY Plot");
//     org.jfree.chart.axis.PeriodAxis var19 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var22 = new org.jfree.data.Range(1.0d, 10.0d);
//     var19.setRange(var22, false, true);
//     java.awt.Stroke var26 = var19.getMinorTickMarkStroke();
//     boolean var27 = var19.isMinorTickMarksVisible();
//     java.awt.Shape var28 = var19.getUpArrow();
//     var17.setArea(var28);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(10, var35, var36);
//     java.awt.Paint var38 = var32.getDomainMinorGridlinePaint();
//     org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var38);
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var41 = var40.getLabelPaint();
//     var39.setOutlinePaint(var41);
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var28, var41);
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var45 = var44.getLabelPaint();
//     var43.setOutlinePaint(var45);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var48 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var50 = var48.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var52 = var48.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
//     int var54 = var53.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var55 = new org.jfree.chart.axis.DateAxis();
//     var55.setMinorTickMarkInsideLength(0.0f);
//     int var58 = var53.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var55);
//     org.jfree.chart.util.HorizontalAlignment var59 = null;
//     org.jfree.chart.util.VerticalAlignment var60 = null;
//     org.jfree.chart.block.ColumnArrangement var63 = new org.jfree.chart.block.ColumnArrangement(var59, var60, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var64 = null;
//     org.jfree.chart.util.VerticalAlignment var65 = null;
//     org.jfree.chart.block.FlowArrangement var68 = new org.jfree.chart.block.FlowArrangement(var64, var65, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var53, (org.jfree.chart.block.Arrangement)var63, (org.jfree.chart.block.Arrangement)var68);
//     org.jfree.chart.entity.TitleEntity var70 = new org.jfree.chart.entity.TitleEntity(var52, (org.jfree.chart.title.Title)var69);
//     org.jfree.chart.util.RectangleAnchor var71 = var69.getLegendItemGraphicLocation();
//     var43.setShapeLocation(var71);
//     
//     // Checks the contract:  equals-hashcode on var7 and var50
//     assertTrue("Contract failed: equals-hashcode on var7 and var50", var7.equals(var50) ? var7.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var7
//     assertTrue("Contract failed: equals-hashcode on var50 and var7", var50.equals(var7) ? var50.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var53
//     assertTrue("Contract failed: equals-hashcode on var32 and var53", var32.equals(var53) ? var32.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var32
//     assertTrue("Contract failed: equals-hashcode on var53 and var32", var53.equals(var32) ? var53.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     org.jfree.data.time.RegularTimePeriod var1 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month();
//     long var5 = var4.getFirstMillisecond();
//     var3.add((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)(short)1);
//     org.jfree.chart.axis.PeriodAxis var8 = new org.jfree.chart.axis.PeriodAxis("HorizontalAlignment.CENTER", var1, (org.jfree.data.time.RegularTimePeriod)var4);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepRenderer var0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
//     boolean var1 = var0.getUseOutlinePaint();
//     var0.setUseFillPaint(true);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.util.Size2D var5 = new org.jfree.chart.util.Size2D();
//     var5.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var15 = var11.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     int var17 = var16.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis();
//     var18.setMinorTickMarkInsideLength(0.0f);
//     int var21 = var16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var18);
//     org.jfree.chart.util.HorizontalAlignment var22 = null;
//     org.jfree.chart.util.VerticalAlignment var23 = null;
//     org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var22, var23, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.FlowArrangement var31 = new org.jfree.chart.block.FlowArrangement(var27, var28, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16, (org.jfree.chart.block.Arrangement)var26, (org.jfree.chart.block.Arrangement)var31);
//     org.jfree.chart.entity.TitleEntity var33 = new org.jfree.chart.entity.TitleEntity(var15, (org.jfree.chart.title.Title)var32);
//     org.jfree.chart.event.TitleChangeListener var34 = null;
//     var32.removeChangeListener(var34);
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var36.java2DToValue(0.0d, var38, var39);
//     java.awt.Shape var41 = var36.getRightArrow();
//     java.awt.Font var42 = var36.getLabelFont();
//     var32.setItemFont(var42);
//     org.jfree.chart.block.BlockFrame var44 = var32.getFrame();
//     org.jfree.chart.util.RectangleAnchor var45 = var32.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var5, (-3.0d), Double.NaN, var45);
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var48 = var47.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.Marker var50 = null;
//     org.jfree.chart.util.Layer var51 = null;
//     boolean var52 = var47.removeDomainMarker(10, var50, var51);
//     java.lang.String var53 = var47.getNoDataMessage();
//     org.jfree.chart.util.Layer var54 = null;
//     java.util.Collection var55 = var47.getDomainMarkers(var54);
//     java.awt.Paint var56 = var47.getDomainGridlinePaint();
//     org.jfree.chart.axis.AxisSpace var57 = new org.jfree.chart.axis.AxisSpace();
//     java.lang.Object var58 = var57.clone();
//     double var59 = var57.getBottom();
//     var47.setFixedDomainAxisSpace(var57, false);
//     org.jfree.data.time.TimeSeries var62 = null;
//     org.jfree.data.time.TimeSeriesCollection var63 = new org.jfree.data.time.TimeSeriesCollection(var62);
//     java.util.List var64 = var63.getSeries();
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var66 = var0.initialise(var4, var46, var47, (org.jfree.data.xy.XYDataset)var63, var65);
//     
//     // Checks the contract:  equals-hashcode on var16 and var47
//     assertTrue("Contract failed: equals-hashcode on var16 and var47", var16.equals(var47) ? var16.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var16
//     assertTrue("Contract failed: equals-hashcode on var47 and var16", var47.equals(var16) ? var47.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     long var2 = var1.getSerialIndex();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getLastMillisecond(var3);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D();
//     var2.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var12 = var8.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     int var14 = var13.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis();
//     var15.setMinorTickMarkInsideLength(0.0f);
//     int var18 = var13.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var15);
//     org.jfree.chart.util.HorizontalAlignment var19 = null;
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.FlowArrangement var28 = new org.jfree.chart.block.FlowArrangement(var24, var25, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13, (org.jfree.chart.block.Arrangement)var23, (org.jfree.chart.block.Arrangement)var28);
//     org.jfree.chart.entity.TitleEntity var30 = new org.jfree.chart.entity.TitleEntity(var12, (org.jfree.chart.title.Title)var29);
//     org.jfree.chart.event.TitleChangeListener var31 = null;
//     var29.removeChangeListener(var31);
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     double var37 = var33.java2DToValue(0.0d, var35, var36);
//     java.awt.Shape var38 = var33.getRightArrow();
//     java.awt.Font var39 = var33.getLabelFont();
//     var29.setItemFont(var39);
//     org.jfree.chart.block.BlockFrame var41 = var29.getFrame();
//     org.jfree.chart.util.RectangleAnchor var42 = var29.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var43 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, (-3.0d), Double.NaN, var42);
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     org.jfree.chart.plot.PlotState var47 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     var0.draw(var1, var43, var46, var47, var48);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var5 = var1.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     int var7 = var6.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     var8.setMinorTickMarkInsideLength(0.0f);
//     int var11 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var8);
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var17 = null;
//     org.jfree.chart.util.VerticalAlignment var18 = null;
//     org.jfree.chart.block.FlowArrangement var21 = new org.jfree.chart.block.FlowArrangement(var17, var18, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var6, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var21);
//     org.jfree.chart.entity.TitleEntity var23 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var22);
//     org.jfree.chart.LegendItemSource[] var24 = var22.getSources();
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.block.RectangleConstraint var27 = null;
//     org.jfree.chart.util.Size2D var28 = var22.arrange(var26, var27);
//     boolean var29 = var22.isVisible();
//     org.jfree.chart.event.TitleChangeEvent var30 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var22);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var34 = var32.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var36 = var32.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     int var38 = var37.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis();
//     var39.setMinorTickMarkInsideLength(0.0f);
//     int var42 = var37.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var39);
//     org.jfree.chart.util.HorizontalAlignment var43 = null;
//     org.jfree.chart.util.VerticalAlignment var44 = null;
//     org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.FlowArrangement var52 = new org.jfree.chart.block.FlowArrangement(var48, var49, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var37, (org.jfree.chart.block.Arrangement)var47, (org.jfree.chart.block.Arrangement)var52);
//     org.jfree.chart.entity.TitleEntity var54 = new org.jfree.chart.entity.TitleEntity(var36, (org.jfree.chart.title.Title)var53);
//     org.jfree.chart.event.TitleChangeListener var55 = null;
//     var53.removeChangeListener(var55);
//     org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var57.java2DToValue(0.0d, var59, var60);
//     java.awt.Shape var62 = var57.getRightArrow();
//     java.awt.Font var63 = var57.getLabelFont();
//     var53.setItemFont(var63);
//     org.jfree.chart.block.BlockFrame var65 = var53.getFrame();
//     org.jfree.chart.util.RectangleAnchor var66 = var53.getLegendItemGraphicLocation();
//     var22.setLegendItemGraphicAnchor(var66);
//     
//     // Checks the contract:  equals-hashcode on var3 and var34
//     assertTrue("Contract failed: equals-hashcode on var3 and var34", var3.equals(var34) ? var3.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var3
//     assertTrue("Contract failed: equals-hashcode on var34 and var3", var34.equals(var3) ? var34.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var37
//     assertTrue("Contract failed: equals-hashcode on var6 and var37", var6.equals(var37) ? var6.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var6
//     assertTrue("Contract failed: equals-hashcode on var37 and var6", var37.equals(var6) ? var37.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var47
//     assertTrue("Contract failed: equals-hashcode on var16 and var47", var16.equals(var47) ? var16.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var16
//     assertTrue("Contract failed: equals-hashcode on var47 and var16", var47.equals(var16) ? var47.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var52
//     assertTrue("Contract failed: equals-hashcode on var21 and var52", var21.equals(var52) ? var21.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var21
//     assertTrue("Contract failed: equals-hashcode on var52 and var21", var52.equals(var21) ? var52.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.util.LogFormat var1 = new org.jfree.chart.util.LogFormat();
    java.text.NumberFormat var2 = java.text.NumberFormat.getInstance();
    org.jfree.chart.labels.StandardPieToolTipGenerator var3 = new org.jfree.chart.labels.StandardPieToolTipGenerator("Size2D[width=0.0, height=0.0]", (java.text.NumberFormat)var1, var2);
    boolean var4 = var2.isGroupingUsed();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.plot.MultiplePiePlot var6 = new org.jfree.chart.plot.MultiplePiePlot(var5);
    java.awt.Shape var7 = var6.getLegendItemShape();
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var10 = var9.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var12 = null;
    var9.setDomainAxisLocation(1, var12);
    boolean var14 = var9.isSubplot();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis();
    var16.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var19 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var16.setStandardTickUnits(var19);
    var9.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var16, true);
    boolean var23 = var8.hasListener((java.util.EventListener)var9);
    org.jfree.chart.urls.CategoryURLGenerator var24 = null;
    var8.setBaseURLGenerator(var24);
    var8.setSeriesItemLabelsVisible(10, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
    var8.setBaseToolTipGenerator(var30, true);
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var34 = var33.getLabelPaint();
    var8.setBaseOutlinePaint(var34, false);
    var6.setAggregatedItemsPaint(var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedCharacterIterator var38 = var2.formatToCharacterIterator((java.lang.Object)var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
//     double var4 = var2.calculateRightInset(100.0d);
//     double var6 = var2.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var7 = new org.jfree.chart.util.Size2D();
//     var7.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var13.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var17 = var13.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     int var19 = var18.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis();
//     var20.setMinorTickMarkInsideLength(0.0f);
//     int var23 = var18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var20);
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var18, (org.jfree.chart.block.Arrangement)var28, (org.jfree.chart.block.Arrangement)var33);
//     org.jfree.chart.entity.TitleEntity var35 = new org.jfree.chart.entity.TitleEntity(var17, (org.jfree.chart.title.Title)var34);
//     org.jfree.chart.event.TitleChangeListener var36 = null;
//     var34.removeChangeListener(var36);
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     double var42 = var38.java2DToValue(0.0d, var40, var41);
//     java.awt.Shape var43 = var38.getRightArrow();
//     java.awt.Font var44 = var38.getLabelFont();
//     var34.setItemFont(var44);
//     org.jfree.chart.block.BlockFrame var46 = var34.getFrame();
//     org.jfree.chart.util.RectangleAnchor var47 = var34.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var48 = org.jfree.chart.util.RectangleAnchor.createRectangle(var7, (-3.0d), Double.NaN, var47);
//     java.awt.geom.Rectangle2D var51 = var2.createOutsetRectangle(var48, true, true);
//     org.jfree.chart.util.Size2D var52 = new org.jfree.chart.util.Size2D();
//     var52.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var58 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var60 = var58.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var62 = var58.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot();
//     int var64 = var63.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis();
//     var65.setMinorTickMarkInsideLength(0.0f);
//     int var68 = var63.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var65);
//     org.jfree.chart.util.HorizontalAlignment var69 = null;
//     org.jfree.chart.util.VerticalAlignment var70 = null;
//     org.jfree.chart.block.ColumnArrangement var73 = new org.jfree.chart.block.ColumnArrangement(var69, var70, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var74 = null;
//     org.jfree.chart.util.VerticalAlignment var75 = null;
//     org.jfree.chart.block.FlowArrangement var78 = new org.jfree.chart.block.FlowArrangement(var74, var75, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var79 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var63, (org.jfree.chart.block.Arrangement)var73, (org.jfree.chart.block.Arrangement)var78);
//     org.jfree.chart.entity.TitleEntity var80 = new org.jfree.chart.entity.TitleEntity(var62, (org.jfree.chart.title.Title)var79);
//     org.jfree.chart.event.TitleChangeListener var81 = null;
//     var79.removeChangeListener(var81);
//     org.jfree.chart.axis.DateAxis var83 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var85 = null;
//     org.jfree.chart.util.RectangleEdge var86 = null;
//     double var87 = var83.java2DToValue(0.0d, var85, var86);
//     java.awt.Shape var88 = var83.getRightArrow();
//     java.awt.Font var89 = var83.getLabelFont();
//     var79.setItemFont(var89);
//     org.jfree.chart.block.BlockFrame var91 = var79.getFrame();
//     org.jfree.chart.util.RectangleAnchor var92 = var79.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var93 = org.jfree.chart.util.RectangleAnchor.createRectangle(var52, (-3.0d), Double.NaN, var92);
//     boolean var94 = org.jfree.chart.util.ShapeUtilities.contains(var48, var93);
//     
//     // Checks the contract:  equals-hashcode on var7 and var52
//     assertTrue("Contract failed: equals-hashcode on var7 and var52", var7.equals(var52) ? var7.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var7
//     assertTrue("Contract failed: equals-hashcode on var52 and var7", var52.equals(var7) ? var52.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var60
//     assertTrue("Contract failed: equals-hashcode on var15 and var60", var15.equals(var60) ? var15.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var15
//     assertTrue("Contract failed: equals-hashcode on var60 and var15", var60.equals(var15) ? var60.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var63
//     assertTrue("Contract failed: equals-hashcode on var18 and var63", var18.equals(var63) ? var18.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var18
//     assertTrue("Contract failed: equals-hashcode on var63 and var18", var63.equals(var18) ? var63.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var73
//     assertTrue("Contract failed: equals-hashcode on var28 and var73", var28.equals(var73) ? var28.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var28
//     assertTrue("Contract failed: equals-hashcode on var73 and var28", var73.equals(var28) ? var73.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var78
//     assertTrue("Contract failed: equals-hashcode on var33 and var78", var33.equals(var78) ? var33.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var33
//     assertTrue("Contract failed: equals-hashcode on var78 and var33", var78.equals(var33) ? var78.hashCode() == var33.hashCode() : true);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("Size2D[width=100.0, height=100.0]");
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var5 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var7 = null;
    org.jfree.chart.util.Layer var8 = null;
    boolean var9 = var4.removeDomainMarker(10, var7, var8);
    java.awt.Paint var10 = var4.getDomainMinorGridlinePaint();
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(100.0d, 0.0d, var10);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var13 = var12.getLabelPaint();
    var11.setOutlinePaint(var13);
    var1.setChartBackgroundPaint(var13);
    java.awt.Font var16 = var1.getRegularFont();
    org.jfree.chart.plot.DrawingSupplier var17 = var1.getDrawingSupplier();
    java.awt.Paint var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkPaint(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 1.0d);
    org.jfree.data.Range var6 = org.jfree.data.Range.combine(var0, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var9 = org.jfree.data.Range.expand(var0, 0.05d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    java.awt.Image var5 = null;
    var0.setBackgroundImage(var5);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    java.awt.Paint var9 = var7.getDomainCrosshairPaint();
    var0.setDomainZeroBaselinePaint(var9);
    var0.mapDatasetToRangeAxis(12, 10);
    org.jfree.chart.axis.AxisLocation var15 = var0.getRangeAxisLocation(7);
    org.jfree.chart.plot.PlotOrientation var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var1 = var0.getLabelPaint();
//     var0.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var5 = null;
//     org.jfree.chart.urls.XYURLGenerator var6 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var5, var6);
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var9 = null;
//     var8.setTimeline(var9);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
//     var8.setAxisLineStroke(var12);
//     var7.setBaseStroke(var12, false);
//     var0.setAxisLineStroke(var12);
//     java.util.Date var17 = var0.getMinimumDate();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.SerialDate var20 = var18.getNearestDayOfWeek(3);
//     org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
//     java.awt.Paint var22 = var21.getLabelPaint();
//     var21.setVisible(true);
//     org.jfree.chart.labels.XYToolTipGenerator var26 = null;
//     org.jfree.chart.urls.XYURLGenerator var27 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var26, var27);
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.Timeline var30 = null;
//     var29.setTimeline(var30);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     var29.setAxisLineStroke(var33);
//     var28.setBaseStroke(var33, false);
//     var21.setAxisLineStroke(var33);
//     java.util.Date var38 = var21.getMinimumDate();
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.SerialDate var41 = var39.getNearestDayOfWeek(3);
//     org.jfree.data.time.SerialDate var42 = var18.getEndOfCurrentMonth(var39);
//     
//     // Checks the contract:  equals-hashcode on var11 and var32
//     assertTrue("Contract failed: equals-hashcode on var11 and var32", var11.equals(var32) ? var11.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var11
//     assertTrue("Contract failed: equals-hashcode on var32 and var11", var32.equals(var11) ? var32.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    var0.centerRange(10.0d);
    org.jfree.chart.renderer.xy.XYStepAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(0);
    java.awt.Shape var8 = var4.lookupLegendShape(100);
    org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
    int var10 = var9.getDatasetCount();
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis();
    var11.setMinorTickMarkInsideLength(0.0f);
    int var14 = var9.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var11);
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, (-1.0d), 100.0d);
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.FlowArrangement var24 = new org.jfree.chart.block.FlowArrangement(var20, var21, (-1.0d), 0.0d);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var9, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var24);
    org.jfree.chart.entity.TitleEntity var26 = new org.jfree.chart.entity.TitleEntity(var8, (org.jfree.chart.title.Title)var25);
    org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity(var8);
    org.jfree.chart.entity.LegendItemEntity var28 = new org.jfree.chart.entity.LegendItemEntity(var8);
    var0.setRightArrow(var8);
    org.jfree.chart.JFreeChart var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var32 = new org.jfree.chart.entity.JFreeChartEntity(var8, var30, "Multiple Pie Plot");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.util.LogFormat var0 = new org.jfree.chart.util.LogFormat();
    java.lang.String var2 = var0.format(1417420800000L);
    boolean var3 = var0.isParseIntegerOnly();
    java.lang.String var5 = var0.format(100.0d);
    boolean var6 = var0.isParseIntegerOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "10^12.15"+ "'", var2.equals("10^12.15"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "10^2.0"+ "'", var5.equals("10^2.0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    int var2 = var1.getSeriesCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var5 = var1.isSelected((-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.0d, 10.0d);
    org.jfree.chart.labels.ItemLabelPosition var3 = var2.getPositiveItemLabelPositionFallback();
    double var4 = var2.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.0d);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var0.axisChanged(var3);
    org.jfree.chart.plot.SeriesRenderingOrder var5 = var0.getSeriesRenderingOrder();
    java.lang.String var6 = var5.toString();
    java.lang.String var7 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "SeriesRenderingOrder.REVERSE"+ "'", var6.equals("SeriesRenderingOrder.REVERSE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "SeriesRenderingOrder.REVERSE"+ "'", var7.equals("SeriesRenderingOrder.REVERSE"));

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
    org.jfree.chart.text.TextLine var4 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var5 = null;
    var4.addFragment(var5);
    org.jfree.chart.text.TextLine var8 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var9 = var8.getFirstTextFragment();
    java.lang.String var10 = var9.getText();
    var4.addFragment(var9);
    var1.addFragment(var9);
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var17 = null;
    var14.setDomainAxisLocation(1, var17);
    boolean var19 = var14.isSubplot();
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis();
    var21.centerRange(10.0d);
    org.jfree.chart.axis.TickUnitSource var24 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    var21.setStandardTickUnits(var24);
    var14.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis)var21, true);
    boolean var28 = var13.hasListener((java.util.EventListener)var14);
    org.jfree.chart.urls.CategoryURLGenerator var29 = null;
    var13.setBaseURLGenerator(var29);
    double var31 = var13.getShadowYOffset();
    boolean var32 = var13.getIncludeBaseInRange();
    var13.setSeriesCreateEntities(4, (java.lang.Boolean)true, true);
    org.jfree.chart.util.LogFormat var37 = new org.jfree.chart.util.LogFormat();
    boolean var38 = var13.equals((java.lang.Object)var37);
    boolean var39 = var13.getAutoPopulateSeriesPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var41 = null;
    var13.setSeriesToolTipGenerator(12, var41);
    boolean var43 = var9.equals((java.lang.Object)12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "hi!"+ "'", var10.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1);
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(short)(-1));
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.RegularTimePeriod var7 = var5.next();
//     int var8 = var5.getMonth();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var5);
//     java.beans.PropertyChangeListener var10 = null;
//     var4.removePropertyChangeListener(var10);
//     double var12 = var4.getMaxY();
//     var1.removeSeries(var4);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     java.lang.String var15 = var14.toString();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)4, false);
//     java.util.Calendar var19 = null;
//     long var20 = var14.getLastMillisecond(var19);
// 
//   }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var4 = null;
//     org.jfree.chart.plot.CrosshairState var6 = new org.jfree.chart.plot.CrosshairState(false);
//     boolean var7 = var0.render(var1, var2, (-460), var4, var6);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var9 = var8.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var11 = null;
//     var8.setDomainAxisLocation(1, var11);
//     boolean var13 = var8.isSubplot();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleAnchor var17 = null;
//     java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
//     var8.zoomRangeAxes(0.0d, var15, var18);
//     var6.setAnchor(var18);
//     
//     // Checks the contract:  equals-hashcode on var0 and var8
//     assertTrue("Contract failed: equals-hashcode on var0 and var8", var0.equals(var8) ? var0.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var0
//     assertTrue("Contract failed: equals-hashcode on var8 and var0", var8.equals(var0) ? var8.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.plot.Marker var3 = null;
    org.jfree.chart.util.Layer var4 = null;
    boolean var5 = var0.removeDomainMarker(10, var3, var4);
    java.lang.String var6 = var0.getNoDataMessage();
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var0.getDomainMarkers(var7);
    int var9 = var0.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
    org.jfree.data.time.RegularTimePeriod var2 = var1.next();
    boolean var4 = var1.equals((java.lang.Object)5.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     int var1 = var0.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis();
//     var2.setMinorTickMarkInsideLength(0.0f);
//     int var5 = var0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var2);
//     org.jfree.chart.plot.SeriesRenderingOrder var6 = var0.getSeriesRenderingOrder();
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var12 = var11.getDomainZeroBaselineStroke();
//     var9.setSeriesStroke(10, var12);
//     var0.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var9);
//     var0.setDomainCrosshairValue(0.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var21 = var20.getDomainZeroBaselineStroke();
//     var18.setSeriesStroke(10, var21);
//     boolean var23 = var18.getShapesVisible();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var18.getBasePositiveItemLabelPosition();
//     java.awt.Paint var26 = var18.lookupSeriesOutlinePaint(0);
//     var0.setDomainZeroBaselinePaint(var26);
//     
//     // Checks the contract:  equals-hashcode on var11 and var20
//     assertTrue("Contract failed: equals-hashcode on var11 and var20", var11.equals(var20) ? var11.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var11
//     assertTrue("Contract failed: equals-hashcode on var20 and var11", var20.equals(var11) ? var20.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getY((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    java.awt.Paint var1 = var0.getLabelPaint();
    var0.setUpperBound(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    java.awt.Paint var2 = var0.getDomainCrosshairPaint();
    org.jfree.chart.plot.DatasetRenderingOrder var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDatasetRenderingOrder(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.PeriodAxis var2 = new org.jfree.chart.axis.PeriodAxis("10^12.15");
//     org.jfree.data.Range var5 = new org.jfree.data.Range(1.0d, 10.0d);
//     var2.setRange(var5, false, true);
//     java.awt.Stroke var9 = var2.getMinorTickMarkStroke();
//     boolean var10 = var2.isMinorTickMarksVisible();
//     java.awt.Shape var11 = var2.getUpArrow();
//     org.jfree.data.time.RegularTimePeriod var12 = var2.getFirst();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.AxisState var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     int var18 = var16.getWeight();
//     boolean var19 = var16.isRangeZeroBaselineVisible();
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var21 = var20.getDomainZeroBaselineStroke();
//     java.awt.Paint var22 = var20.getDomainCrosshairPaint();
//     var16.setRangeGridlinePaint(var22);
//     var16.setDomainCrosshairVisible(true);
//     boolean var26 = var16.canSelectByRegion();
//     org.jfree.chart.util.RectangleEdge var27 = var16.getDomainAxisEdge();
//     java.util.List var28 = var2.refreshTicks(var13, var14, var15, var27);
//     org.jfree.chart.renderer.PolarItemRenderer var29 = null;
//     org.jfree.chart.plot.PolarPlot var30 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, var29);
//     org.jfree.data.xy.DefaultXYDataset var31 = new org.jfree.data.xy.DefaultXYDataset();
//     java.lang.Object var32 = var31.clone();
//     java.lang.Object var33 = var31.clone();
//     org.jfree.data.time.TimeSeries var34 = null;
//     org.jfree.data.time.TimeSeriesCollection var35 = new org.jfree.data.time.TimeSeriesCollection(var34);
//     var31.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var35);
//     var30.setDataset((org.jfree.data.xy.XYDataset)var31);
//     java.awt.Graphics2D var38 = null;
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.plot.MultiplePiePlot var40 = new org.jfree.chart.plot.MultiplePiePlot(var39);
//     org.jfree.chart.util.RectangleInsets var41 = var40.getInsets();
//     double var43 = var41.calculateRightInset(100.0d);
//     double var45 = var41.trimHeight(5.0d);
//     org.jfree.chart.util.Size2D var46 = new org.jfree.chart.util.Size2D();
//     var46.setHeight(100.0d);
//     org.jfree.chart.renderer.xy.XYStepAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(100);
//     org.jfree.chart.labels.ItemLabelPosition var54 = var52.getSeriesNegativeItemLabelPosition(0);
//     java.awt.Shape var56 = var52.lookupLegendShape(100);
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     int var58 = var57.getDatasetCount();
//     org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis();
//     var59.setMinorTickMarkInsideLength(0.0f);
//     int var62 = var57.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var59);
//     org.jfree.chart.util.HorizontalAlignment var63 = null;
//     org.jfree.chart.util.VerticalAlignment var64 = null;
//     org.jfree.chart.block.ColumnArrangement var67 = new org.jfree.chart.block.ColumnArrangement(var63, var64, (-1.0d), 100.0d);
//     org.jfree.chart.util.HorizontalAlignment var68 = null;
//     org.jfree.chart.util.VerticalAlignment var69 = null;
//     org.jfree.chart.block.FlowArrangement var72 = new org.jfree.chart.block.FlowArrangement(var68, var69, (-1.0d), 0.0d);
//     org.jfree.chart.title.LegendTitle var73 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57, (org.jfree.chart.block.Arrangement)var67, (org.jfree.chart.block.Arrangement)var72);
//     org.jfree.chart.entity.TitleEntity var74 = new org.jfree.chart.entity.TitleEntity(var56, (org.jfree.chart.title.Title)var73);
//     org.jfree.chart.event.TitleChangeListener var75 = null;
//     var73.removeChangeListener(var75);
//     org.jfree.chart.axis.DateAxis var77 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var79 = null;
//     org.jfree.chart.util.RectangleEdge var80 = null;
//     double var81 = var77.java2DToValue(0.0d, var79, var80);
//     java.awt.Shape var82 = var77.getRightArrow();
//     java.awt.Font var83 = var77.getLabelFont();
//     var73.setItemFont(var83);
//     org.jfree.chart.block.BlockFrame var85 = var73.getFrame();
//     org.jfree.chart.util.RectangleAnchor var86 = var73.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var87 = org.jfree.chart.util.RectangleAnchor.createRectangle(var46, (-3.0d), Double.NaN, var86);
//     java.awt.geom.Rectangle2D var90 = var41.createOutsetRectangle(var87, true, true);
//     java.awt.geom.Rectangle2D var91 = null;
//     org.jfree.chart.util.RectangleAnchor var92 = null;
//     java.awt.geom.Point2D var93 = org.jfree.chart.util.RectangleAnchor.coordinates(var91, var92);
//     org.jfree.chart.plot.PlotState var94 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var95 = null;
//     var30.draw(var38, var90, var93, var94, var95);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    var0.setLowerMargin(0.0d);
    var0.setMaximumCategoryLabelWidthRatio(2.0f);
    var0.setUpperMargin(Double.POSITIVE_INFINITY);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var11 = var10.getDomainZeroBaselineStroke();
    int var12 = var10.getWeight();
    boolean var13 = var10.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var15 = var14.getDomainZeroBaselineStroke();
    java.awt.Paint var16 = var14.getDomainCrosshairPaint();
    var10.setRangeGridlinePaint(var16);
    boolean var18 = var10.isRangeZoomable();
    org.jfree.chart.util.RectangleEdge var19 = var10.getDomainAxisEdge();
    org.jfree.chart.axis.AxisState var20 = null;
    var0.drawTickMarks(var7, 8.0d, var9, var19, var20);
    org.jfree.chart.axis.CategoryLabelPositions var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setCategoryLabelPositions(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

}
